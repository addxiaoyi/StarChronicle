package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Actual stockpile balances committed with native state; a grant alone is not production. */
public record ResourceChangeReceipt(
    UUID authorityDomainId,
    long sequence,
    UUID operationId,
    Kind kind,
    String reference,
    String category,
    String description,
    UUID actorId,
    Instant committedAt,
    List<BalanceChange> balances) {
  public enum Kind {
    ADJUSTMENT,
    GRANT,
    CONSUME,
    TRANSACTION_GRANT,
    TRANSACTION_CONSUME,
    TRANSFER
  }

  public record BalanceChange(NationId nationId, String resourceType, long before, long after) {
    public BalanceChange {
      Objects.requireNonNull(nationId, "nationId");
      if (resourceType == null || !resourceType.matches("[a-z][a-z0-9_]{0,63}"))
        throw new IllegalArgumentException("Invalid resource type");
      if (before < 0 || after < 0 || before == after)
        throw new IllegalArgumentException(
            "Resource balances must describe a real nonnegative change");
    }

    public long delta() {
      return after - before;
    }
  }

  public ResourceChangeReceipt {
    Objects.requireNonNull(authorityDomainId, "authorityDomainId");
    Objects.requireNonNull(operationId, "operationId");
    Objects.requireNonNull(kind, "kind");
    Objects.requireNonNull(committedAt, "committedAt");
    if (sequence < 1) throw new IllegalArgumentException("Nonpositive resource history sequence");
    if (reference == null
        || reference.length() > 4096
        || category == null
        || category.length() > 64
        || description == null
        || description.length() > 200)
      throw new IllegalArgumentException("Invalid resource history cause");
    balances = List.copyOf(balances);
    if (balances.isEmpty() || balances.size() > 128)
      throw new IllegalArgumentException("Resource history requires 1..128 balance changes");
    var keys = new HashSet<String>();
    for (var balance : balances)
      if (!keys.add(balance.nationId() + ":" + balance.resourceType()))
        throw new IllegalArgumentException("Duplicate resource balance change");
  }
}
