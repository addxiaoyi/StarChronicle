package dev.starcore.starcore.module.resource;

import java.util.UUID;

/** Internal provenance supplied by the native mutation, not by snapshot consumers. */
record ResourceChangeCause(
    ResourceChangeReceipt.Kind kind,
    String reference,
    String category,
    String description,
    UUID actorId) {
  static ResourceChangeCause of(ResourceChangeReceipt.Kind kind) {
    return new ResourceChangeCause(kind, "", "", "", null);
  }
}
