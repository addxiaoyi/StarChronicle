package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.logging.Logger;

final class DatabaseAwareResourceStateStorage implements ResourceStateStorage {
  private final DatabaseService databaseService;
  private final ResourceStateStorage fileStorage;
  private final ResourceStateStorage sqlStorage;
  private final boolean sqlPreferred;
  private final java.nio.file.Path sqlMarker;

  DatabaseAwareResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    this.databaseService = Objects.requireNonNull(databaseService, "databaseService");
    this.fileStorage = new PersistenceResourceStateStorage(namespace, persistenceService);
    try {
      sqlMarker = persistenceService.namespacePath(namespace).resolve("resource-sql-authority");
      String marker =
          java.nio.file.Files.exists(sqlMarker) ? java.nio.file.Files.readString(sqlMarker) : "";
      if (!marker.isEmpty() && !marker.equals("MIGRATING") && !marker.equals("READY"))
        throw new IllegalStateException("Invalid resource SQL authority marker");
      sqlPreferred = databaseService.isRunning() || !marker.isEmpty();
      sqlStorage =
          new SqlResourceStateStorage(
              namespace, databaseService, persistenceService, logger, !marker.equals("READY"));
    } catch (java.io.IOException error) {
      throw new IllegalStateException("Cannot locate resource SQL authority marker", error);
    }
  }

  @Override
  public Properties load() {
    Properties state = activeStorage().load();
    if (sqlPreferred) mark("READY");
    return state;
  }

  @Override
  public void save(Properties properties) {
    activeStorage().save(properties);
  }

  @Override
  public boolean archivesTradeExecutions() {
    return activeStorage().archivesTradeExecutions();
  }

  @Override
  public void writeTradeState(Properties state, Map<String, TradeExecution> executions) {
    activeStorage().writeTradeState(state, executions);
  }

  @Override
  public Optional<TradeExecution> archivedTradeExecution(String id) {
    return activeStorage().archivedTradeExecution(id);
  }

  @Override
  public List<TradeExecution> archivedTradeExecutions(
      dev.starcore.starcore.module.nation.model.NationId nation, long offset, int limit) {
    return activeStorage().archivedTradeExecutions(nation, offset, limit);
  }

  @Override
  public boolean archivesFactoryRuns() {
    return activeStorage().archivesFactoryRuns();
  }

  @Override
  public Optional<FactoryRun> archivedFactoryRun(String id) {
    return activeStorage().archivedFactoryRun(id);
  }

  @Override
  public void writeFactoryState(
      Properties state,
      Map<String, FactoryRun> runs,
      Map<java.util.UUID, dev.starcore.starcore.module.resource.model.Factory> factories) {
    activeStorage().writeFactoryState(state, runs, factories);
  }

  @Override
  public void validateFactoryProduction(Properties snapshot, Map<String, FactoryRun> runs) {
    activeStorage().validateFactoryProduction(snapshot, runs);
  }

  @Override
  public void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    activeStorage().saveTransfer(properties, receipt);
  }

  @Override
  public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    return activeStorage().transferReceipt(id);
  }

  @Override
  public void validateTradeDeliveries(Properties snapshot, Map<String, TradeExecution> executions) {
    activeStorage().validateTradeDeliveries(snapshot, executions);
  }

  @Override
  public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    return activeStorage().transferReceiptsAfter(sequence, limit);
  }

  @Override
  public long latestTransferSequence() {
    return activeStorage().latestTransferSequence();
  }

  @Override
  public void saveProduction(Properties properties, ProductionReceipt receipt) {
    activeStorage().saveProduction(properties, receipt);
  }

  @Override
  public Optional<ProductionReceipt> productionReceipt(String id) {
    return activeStorage().productionReceipt(id);
  }

  @Override
  public List<ProductionReceipt> productionReceiptsAfter(long sequence, int limit) {
    return activeStorage().productionReceiptsAfter(sequence, limit);
  }

  @Override
  public long latestProductionSequence() {
    return activeStorage().latestProductionSequence();
  }

  @Override
  public int transferReceiptCount() {
    return activeStorage().transferReceiptCount();
  }

  @Override
  public void saveAsync(Properties properties) {
    save(properties);
  }

  private void mark(String value) {
    try {
      dev.starcore.starcore.core.persistence.AtomicFilePersistence.replace(
          sqlMarker, temp -> java.nio.file.Files.writeString(temp, value));
    } catch (java.io.IOException error) {
      throw new IllegalStateException("Cannot pin resource SQL authority", error);
    }
  }

  private ResourceStateStorage activeStorage() {
    // A running module must never switch authority without first loading its state.
    if (sqlPreferred) {
      if (!java.nio.file.Files.exists(sqlMarker)) mark("MIGRATING");
      return sqlStorage;
    }
    return fileStorage;
  }
}
