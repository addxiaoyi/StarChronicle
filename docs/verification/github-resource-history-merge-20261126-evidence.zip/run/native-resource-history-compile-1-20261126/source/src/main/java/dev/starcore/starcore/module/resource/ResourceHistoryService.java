package dev.starcore.starcore.module.resource;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Contiguous committed changes since installation. Historical actors are never inferred. */
public interface ResourceHistoryService {
  Optional<UUID> historyAuthorityDomainId();

  /** Bounded 1..128 page, with an error when the cursor is ahead of this authority. */
  List<ResourceChangeReceipt> resourceChangesAfter(long sequence, int limit);
}
