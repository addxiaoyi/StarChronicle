package dev.starcore.starcore.module.resource;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

/** Validate inventory evidence before a permissive legacy decoder can discard or normalize it. */
final class InventorySnapshotValidator {
  private static final Set<String> STOCK_FIELDS = Set.of("nationId", "type", "amount");
  private static final Set<String> RECEIPT_FIELDS =
      Set.of(
          "id",
          "nationId",
          "operation",
          "category",
          "resources",
          "description",
          "appliedAt",
          "appliedAtInstant");

  private InventorySnapshotValidator() {}

  static void validate(Properties state, Set<String> resourceTypes) {
    int stocks = count(state, "count");
    int receipts = count(state, "transaction.count");
    long stockFields = 0;
    long receiptFields = 0;
    for (String key : state.stringPropertyNames()) {
      if (key.startsWith("stockpile.")) {
        field(key, "stockpile.", stocks, STOCK_FIELDS);
        stockFields++;
      } else if (key.startsWith("transaction.") && !key.equals("transaction.count")) {
        field(key, "transaction.", receipts, RECEIPT_FIELDS);
        receiptFields++;
      }
    }
    // Bound work by actual input fields, including when a corrupt count claims billions of rows.
    require(stockFields == stocks * 3L, "count");
    require(receiptFields >= receipts * 6L && receiptFields <= receipts * 8L, "transaction.count");
    Set<String> identities = new HashSet<>();
    for (int index = 0; index < stocks; index++) {
      String prefix = "stockpile." + index + '.';
      String nation = uuid(state, prefix + "nationId");
      String resource = required(state, prefix + "type");
      require(resourceTypes.contains(resource), prefix + "type");
      require(number(required(state, prefix + "amount"), prefix + "amount") > 0, prefix + "amount");
      require(identities.add(nation + ':' + resource), prefix);
    }
    identities.clear();
    for (int index = 0; index < receipts; index++) {
      String prefix = "transaction." + index + '.';
      String id = required(state, prefix + "id");
      require(!id.isBlank() && identities.add(id), prefix + "id");
      uuid(state, prefix + "nationId");
      enumValue(state, prefix + "operation", NationResourceTransactionService.Operation.class);
      enumValue(state, prefix + "category", NationResourceTransactionService.Category.class);
      long millis = number(required(state, prefix + "appliedAt"), prefix + "appliedAt");
      String exact = state.getProperty(prefix + "appliedAtInstant");
      if (exact != null) {
        try {
          var instant = java.time.Instant.parse(exact);
          require(
              instant.toString().equals(exact) && instant.toEpochMilli() == millis,
              prefix + "appliedAtInstant");
        } catch (java.time.DateTimeException | ArithmeticException failure) {
          throw invalid(prefix + "appliedAtInstant");
        }
      }
      String description = state.getProperty(prefix + "description", "");
      require(
          description.length() <= NationResourceTransactionService.MAX_DESCRIPTION_LENGTH,
          prefix + "description");
      Set<String> types = new HashSet<>();
      for (String item : required(state, prefix + "resources").split(";", -1)) {
        int separator = item.indexOf('=');
        require(separator > 0, prefix + "resources");
        String type = item.substring(0, separator);
        require(resourceTypes.contains(type) && types.add(type), prefix + "resources");
        require(
            number(item.substring(separator + 1), prefix + "resources") > 0, prefix + "resources");
      }
    }
  }

  private static int count(Properties state, String key) {
    String value = state.getProperty(key);
    if (value == null) return 0;
    long count = number(value, key);
    require(count >= 0 && count <= Integer.MAX_VALUE, key);
    return (int) count;
  }

  private static void field(String key, String prefix, int count, Set<String> allowed) {
    int separator = key.indexOf('.', prefix.length());
    require(separator > prefix.length(), key);
    long index = number(key.substring(prefix.length(), separator), key);
    require(index >= 0 && index < count && allowed.contains(key.substring(separator + 1)), key);
  }

  private static String required(Properties state, String key) {
    String value = state.getProperty(key);
    require(value != null, key);
    return value;
  }

  private static String uuid(Properties state, String key) {
    String value = required(state, key);
    try {
      require(UUID.fromString(value).toString().equals(value), key);
    } catch (IllegalArgumentException error) {
      throw invalid(key);
    }
    return value;
  }

  private static long number(String value, String key) {
    try {
      long number = Long.parseLong(value);
      require(Long.toString(number).equals(value), key);
      return number;
    } catch (NumberFormatException error) {
      throw invalid(key);
    }
  }

  private static <E extends Enum<E>> void enumValue(Properties state, String key, Class<E> type) {
    try {
      Enum.valueOf(type, required(state, key));
    } catch (IllegalArgumentException error) {
      throw invalid(key);
    }
  }

  private static void require(boolean valid, String key) {
    if (!valid) throw invalid(key);
  }

  private static IllegalStateException invalid(String key) {
    return new IllegalStateException("Inventory snapshot requires recovery at " + key);
  }
}
