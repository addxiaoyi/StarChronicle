package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class ResourceSqlAuthorityTest {
  @TempDir Path temp;
  private final NationId nation = NationId.random();

  @AfterEach
  void stop() {
    AbstractModuleStateStorage.shutdownNamespace("resource");
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @Test
  void firstMigrationPreservesInventoryAndTransferReceiptsTogether() {
    var source = source();
    Properties legacy = state(88);
    var receipt = receipt();
    ResourceTransferReceiptStore.append(legacy, receipt);
    var sql = new SqlResourceStateStorage(source, legacy, Logger.getAnonymousLogger());
    Properties migrated = sql.load();
    assertEquals(
        88L,
        ResourceStateCodec.fromProperties(migrated, Set.of("mineral")).get(nation).get("mineral"));
    assertEquals(receipt, sql.transferReceipt(receipt.transactionId()).orElseThrow());
    assertEquals(receipt.authorityDomainId(), migrated.getProperty("resource.authority-domain"));
    legacy.setProperty("count", "0");
    assertEquals("88", sql.load().getProperty("stockpile.0.amount"));
  }

  @Test
  void triggerFailureRollsBackInventoryHistoryAndTransferWithoutFallback() throws Exception {
    var persistence = persistence();
    var source = source();
    var database = database(source);
    var legacy = new PersistenceResourceStateStorage("resource", persistence);
    legacy.save(state(77));
    var authority =
        new DatabaseAwareResourceStateStorage(
            "resource", database, persistence, Logger.getAnonymousLogger());
    var history = new ResourceHistoryStorage(authority, temp.resolve("history"));
    var module = new ResourceModule(history);
    assertTrue(module.grant(nation, "mineral", 23));
    String before =
        Files.readString(persistence.namespacePath("resource").resolve("resources.properties"));
    try (var c = source.getConnection();
        var s = c.createStatement()) {
      s.execute(
          "CREATE TRIGGER reject_resource BEFORE INSERT ON starcore_resource_state BEGIN SELECT"
              + " RAISE(ABORT,'simulated full disk'); END");
    }
    assertFalse(module.consume(nation, "mineral", 20));
    assertEquals(100, module.amount(nation, "mineral"));
    assertEquals(1, module.resourceChangesAfter(0, 128).size());
    var request =
        new NationResourceTransactionService.TransferRequest(
            "rollback-transfer",
            nation,
            NationId.random(),
            Map.of("mineral", 20L),
            NationResourceTransactionService.Category.OTHER,
            "");
    assertEquals(
        NationResourceTransactionService.TransferStatus.UNKNOWN, module.transfer(request).status());
    assertTrue(module.transferReceipt(request.transactionId()).isEmpty());
    assertEquals(100, module.amount(nation, "mineral"));
    assertEquals(
        before,
        Files.readString(persistence.namespacePath("resource").resolve("resources.properties")));
    try (var c = source.getConnection();
        var s = c.createStatement()) {
      s.execute("DROP TRIGGER reject_resource");
    }
    assertEquals(
        NationResourceTransactionService.TransferStatus.APPLIED, module.transfer(request).status());
    assertEquals(80, module.amount(nation, "mineral"));
    var restarted =
        new ResourceModule(
            new ResourceHistoryStorage(
                new DatabaseAwareResourceStateStorage(
                    "resource", database, persistence, Logger.getAnonymousLogger()),
                temp.resolve("history")));
    assertEquals(2, restarted.resourceChangesAfter(0, 128).size());
    assertEquals(
        NationResourceTransactionService.TransferStatus.ALREADY_APPLIED,
        restarted.transfer(request).status());
  }

  @Test
  void pinnedSqlCannotResurrectStaleFilesWhenUnavailableOrEmptied() throws Exception {
    var persistence = persistence();
    var source = source();
    var database = database(source);
    new PersistenceResourceStateStorage("resource", persistence).save(state(77));
    var first =
        new DatabaseAwareResourceStateStorage(
            "resource", database, persistence, Logger.getAnonymousLogger());
    first.load();
    first.save(state(100));
    when(database.isRunning()).thenReturn(false);
    when(database.dataSource()).thenReturn(Optional.empty());
    assertThrows(
        IllegalStateException.class,
        () ->
            new DatabaseAwareResourceStateStorage(
                    "resource", database, persistence, Logger.getAnonymousLogger())
                .load());
    when(database.isRunning()).thenReturn(true);
    when(database.dataSource()).thenReturn(Optional.of(source));
    try (var c = source.getConnection();
        var s = c.createStatement()) {
      s.execute("DELETE FROM starcore_resource_state");
    }
    assertThrows(
        IllegalStateException.class,
        () ->
            new DatabaseAwareResourceStateStorage(
                    "resource", database, persistence, Logger.getAnonymousLogger())
                .load());
    assertEquals(
        "77",
        new PersistenceResourceStateStorage("resource", persistence)
            .load()
            .getProperty("stockpile.0.amount"));
  }

  @Test
  void failedInitialSqlConnectionPinsAuthorityButCanResumeMigration() throws Exception {
    var persistence = persistence();
    var source = source();
    var database = database(source);
    new PersistenceResourceStateStorage("resource", persistence).save(state(77));
    when(database.dataSource()).thenReturn(Optional.empty());
    assertThrows(
        IllegalStateException.class,
        () ->
            new DatabaseAwareResourceStateStorage(
                    "resource", database, persistence, Logger.getAnonymousLogger())
                .load());
    assertEquals(
        "MIGRATING",
        Files.readString(persistence.namespacePath("resource").resolve("resource-sql-authority")));
    when(database.dataSource()).thenReturn(Optional.of(source));
    var retry =
        new DatabaseAwareResourceStateStorage(
            "resource", database, persistence, Logger.getAnonymousLogger());
    assertEquals("77", retry.load().getProperty("stockpile.0.amount"));
    assertEquals(
        "READY",
        Files.readString(persistence.namespacePath("resource").resolve("resource-sql-authority")));
  }

  @Test
  void fileAuthorityDoesNotSwitchWhileRunningAndMigratesOnRestart() {
    var persistence = persistence();
    var source = source();
    var database = database(source);
    when(database.isRunning()).thenReturn(false);
    var file =
        new DatabaseAwareResourceStateStorage(
            "resource", database, persistence, Logger.getAnonymousLogger());
    file.load();
    file.save(state(77));
    when(database.isRunning()).thenReturn(true);
    file.save(state(88));
    assertEquals(
        "88",
        new PersistenceResourceStateStorage("resource", persistence)
            .load()
            .getProperty("stockpile.0.amount"));
    var restarted =
        new DatabaseAwareResourceStateStorage(
            "resource", database, persistence, Logger.getAnonymousLogger());
    assertEquals("88", restarted.load().getProperty("stockpile.0.amount"));
  }

  @Test
  void transferWaitsForEarlierSnapshotInTheSameSqlQueue() throws Exception {
    var source = source();
    var sql = new SqlResourceStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    sql.load();
    sql.saveAsync(state(100));
    var receipt = receipt();
    sql.saveTransfer(state(88), receipt);
    assertEquals("88", sql.load().getProperty("stockpile.0.amount"));
    assertEquals(receipt, sql.transferReceipt(receipt.transactionId()).orElseThrow());
  }

  private NationResourceTransactionService.TransferReceipt receipt() {
    return new NationResourceTransactionService.TransferReceipt(
        "legacy:1",
        UUID.randomUUID().toString(),
        1,
        nation,
        NationId.random(),
        Map.of("mineral", 12L),
        NationResourceTransactionService.Category.OTHER,
        "legacy",
        Instant.ofEpochMilli(1234));
  }

  private Properties state(long amount) {
    return ResourceStateCodec.toProperties(Map.of(nation, Map.of("mineral", amount)));
  }

  private SQLiteDataSource source() {
    var source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + temp.resolve("resource.db"));
    return source;
  }

  private DatabaseService database(SQLiteDataSource source) {
    var database = mock(DatabaseService.class);
    when(database.isRunning()).thenReturn(true);
    when(database.dataSource()).thenReturn(Optional.of(source));
    return database;
  }

  private PersistenceService persistence() {
    var plugin = mock(JavaPlugin.class);
    when(plugin.getDataFolder()).thenReturn(temp.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    var persistence = new PersistenceService(plugin, null);
    persistence.start();
    return persistence;
  }
}
