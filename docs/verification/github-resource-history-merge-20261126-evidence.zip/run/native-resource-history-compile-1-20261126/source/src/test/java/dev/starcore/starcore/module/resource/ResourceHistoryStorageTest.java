package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.module.nation.model.NationId;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ResourceHistoryStorageTest {
  @TempDir Path temp;
  private final NationId nation = NationId.random();

  @Test
  void committedInventoryMutationsAndTransferReplaySurviveFileRestart() {
    var storage = storage();
    var module = module(storage);
    NationId receiver = NationId.random();
    assertTrue(module.grant(nation, "mineral", 100));
    assertTrue(module.consume(nation, "mineral", 10));
    var request = request("research:debit", 20);
    assertEquals(NationResourceTransactionService.Status.APPLIED, module.consume(request).status());
    assertEquals(
        NationResourceTransactionService.Status.ALREADY_APPLIED, module.consume(request).status());
    var transfer =
        new NationResourceTransactionService.TransferRequest(
            "aid:1",
            nation,
            receiver,
            Map.of("mineral", 15L),
            NationResourceTransactionService.Category.OTHER,
            "aid");
    assertEquals(
        NationResourceTransactionService.TransferStatus.APPLIED,
        module.transfer(transfer).status());
    var receipt = module.transactionReceipt(request.transactionId()).orElseThrow();
    var restarted = module(storage);
    assertEquals(55, restarted.amount(nation, "mineral"));
    assertEquals(15, restarted.amount(receiver, "mineral"));
    assertEquals(receipt, restarted.transactionReceipt(request.transactionId()).orElseThrow());
    assertEquals(
        NationResourceTransactionService.TransferStatus.ALREADY_APPLIED,
        restarted.transfer(transfer).status());
    assertEquals(
        NationResourceTransactionService.Status.ALREADY_APPLIED,
        restarted.consume(request).status());
    var history = restarted.resourceChangesAfter(0, 128);
    assertEquals(4, history.size());
    assertEquals(
        List.of(
            ResourceChangeReceipt.Kind.GRANT,
            ResourceChangeReceipt.Kind.CONSUME,
            ResourceChangeReceipt.Kind.TRANSACTION_CONSUME,
            ResourceChangeReceipt.Kind.TRANSFER),
        history.stream().map(ResourceChangeReceipt::kind).toList());
    assertTrue(history.stream().allMatch(r -> r.actorId() == null));
    assertEquals(request.transactionId(), history.get(2).reference());
    assertEquals(2, history.getLast().balances().size());
    assertEquals(
        0,
        history.getLast().balances().stream()
            .mapToLong(ResourceChangeReceipt.BalanceChange::delta)
            .sum());
    assertTrue(restarted.resourceChangesAfter(4, 128).isEmpty());
  }

  @Test
  void baselineIsNotInventedHistoryAndPagesPreserveNanosecondsAndOriginalActor() {
    var delegate = storage();
    delegate.save(state(40));
    Instant time = Instant.parse("2026-11-26T01:02:03.123456789Z");
    var history =
        new ResourceHistoryStorage(
            delegate, temp.resolve("history"), Clock.fixed(time, ZoneOffset.UTC));
    history.load();
    assertTrue(history.resourceChangesAfter(0, 128).isEmpty());
    UUID actor = UUID.randomUUID();
    for (int i = 1; i <= 131; i++)
      history.saveChange(
          state(40 + i),
          new ResourceChangeCause(
              ResourceChangeReceipt.Kind.GRANT, "ref|" + i, "", "原文|:💎", actor));
    var first = history.resourceChangesAfter(0, 128);
    assertEquals(128, first.size());
    assertEquals(3, history.resourceChangesAfter(128, 128).size());
    assertEquals(40, first.getFirst().balances().getFirst().before());
    assertTrue(
        first.stream().allMatch(r -> time.equals(r.committedAt()) && actor.equals(r.actorId())));
    assertEquals("原文|:💎", first.getFirst().description());
    assertThrows(IllegalArgumentException.class, () -> history.resourceChangesAfter(0, 129));
    assertThrows(IllegalArgumentException.class, () -> history.resourceChangesAfter(-1, 1));
    assertThrows(IllegalStateException.class, () -> history.resourceChangesAfter(132, 1));
  }

  @Test
  void saturatingGrantRecordsOnlyActualDeltaAndNoChangeDoesNotEmit() {
    var delegate = storage();
    delegate.save(state(Long.MAX_VALUE - 3));
    var module = module(delegate);
    assertTrue(module.grant(nation, "mineral", 10));
    assertTrue(module.grant(nation, "mineral", 10));
    assertEquals(Long.MAX_VALUE, module.amount(nation, "mineral"));
    var history = module.resourceChangesAfter(0, 128);
    assertEquals(1, history.size());
    assertEquals(3, history.getFirst().balances().getFirst().delta());
    assertFalse(module.consume(nation, "unknown", 10));
    assertEquals(1, module.resourceChangesAfter(0, 128).size());
  }

  @Test
  void failureBeforeCommitLeavesNoHistoryAndNoInventoryChange() {
    var fault = new FaultStorage(storage());
    var module = module(fault);
    assertTrue(module.grant(nation, "mineral", 100));
    fault.failBefore = true;
    assertFalse(module.consume(nation, "mineral", 30));
    assertEquals(100, module.amount(nation, "mineral"));
    assertEquals(1, module.resourceChangesAfter(0, 128).size());
    assertTrue(module.consume(nation, "mineral", 30));
    assertEquals(70, module.amount(nation, "mineral"));
  }

  @Test
  void lostReplyIsReconciledWithoutRepeatingGrantConsumeOrTransfer() {
    var fault = new FaultStorage(storage());
    var module = module(fault);
    fault.failAfter = true;
    assertTrue(module.grant(nation, "mineral", 100));
    fault.failAfter = true;
    var debit = request("lost-reply", 30);
    assertEquals(NationResourceTransactionService.Status.APPLIED, module.consume(debit).status());
    assertEquals(
        NationResourceTransactionService.Status.ALREADY_APPLIED, module.consume(debit).status());
    var transfer =
        new NationResourceTransactionService.TransferRequest(
            "lost-transfer",
            nation,
            NationId.random(),
            Map.of("mineral", 20L),
            NationResourceTransactionService.Category.OTHER,
            "");
    fault.failAfter = true;
    assertEquals(
        NationResourceTransactionService.TransferStatus.APPLIED,
        module.transfer(transfer).status());
    assertEquals(50, module.amount(nation, "mineral"));
    assertEquals(20, module.amount(transfer.receiverNationId(), "mineral"));
    assertEquals(3, module.resourceChangesAfter(0, 128).size());
    assertEquals(3, module(fault).resourceChangesAfter(0, 128).size());
  }

  @Test
  void lostReplyWithUnavailableReadFencesPublicInventoryAndShutdownWritesUntilRestart() {
    var fault = new FaultStorage(storage());
    var module = module(fault);
    fault.failAfter = true;
    fault.failReadAfterCommit = true;
    assertThrows(IllegalStateException.class, () -> module.grant(nation, "mineral", 25));
    assertThrows(IllegalStateException.class, () -> module.amount(nation, "mineral"));
    assertThrows(IllegalStateException.class, () -> module.grant(nation, "mineral", 25));
    assertThrows(IllegalStateException.class, () -> module.resourceChangesAfter(0, 128));
    fault.failRead = false;
    var restarted = module(fault);
    assertEquals(25, restarted.amount(nation, "mineral"));
    assertEquals(1, restarted.resourceChangesAfter(0, 128).size());
  }

  @Test
  void noBalanceChangeLostReplyAlsoUsesUniqueCommitProof() {
    var fault = new FaultStorage(storage());
    var history = new ResourceHistoryStorage(fault, temp.resolve("history"));
    history.load();
    Properties state = state(0);
    state.setProperty("factory.marker", "saved");
    fault.failAfter = true;
    assertDoesNotThrow(() -> history.save(state));
    assertEquals("saved", history.load().getProperty("factory.marker"));
    assertTrue(history.resourceChangesAfter(0, 128).isEmpty());
  }

  @Test
  void pendingArchiveFailurePreservesFirstCommitAndBlocksTheNext() throws Exception {
    var delegate = storage();
    var history = new ResourceHistoryStorage(delegate, temp.resolve("history"));
    history.load();
    history.save(state(10));
    Path block =
        temp.resolve("history")
            .resolve(history.historyAuthorityDomainId().orElseThrow().toString());
    Files.writeString(block, "cannot create archive directory");
    assertThrows(IllegalStateException.class, () -> history.save(state(20)));
    assertEquals("10", delegate.load().getProperty("stockpile.0.amount"));
    Files.delete(block);
    var restarted = new ResourceHistoryStorage(delegate, temp.resolve("history"));
    restarted.load();
    assertEquals(1, restarted.resourceChangesAfter(0, 128).size());
    restarted.save(state(20));
    assertEquals(2, restarted.resourceChangesAfter(0, 128).size());
  }

  @Test
  void snapshotRollbackMissingArchiveAndWrongDomainFailClosed() throws Exception {
    var delegate = storage();
    var history = new ResourceHistoryStorage(delegate, temp.resolve("history"));
    history.load();
    Properties baseline = delegate.load();
    history.save(state(10));
    history.save(state(20));
    history.resourceChangesAfter(0, 128);
    Properties current = delegate.load();
    delegate.save(baseline);
    assertThrows(IllegalStateException.class, history::load);
    assertThrows(
        IllegalStateException.class,
        () -> new ResourceHistoryStorage(delegate, temp.resolve("history")).load());
    delegate.save(current);
    history.load();
    Path first =
        temp.resolve("history")
            .resolve(history.historyAuthorityDomainId().orElseThrow().toString())
            .resolve("0/1.receipt");
    Files.delete(first);
    assertThrows(IllegalStateException.class, () -> history.resourceChangesAfter(0, 1));
    current.setProperty("resource.history.domain", UUID.randomUUID().toString());
    delegate.save(current);
    assertThrows(
        IllegalStateException.class,
        () -> new ResourceHistoryStorage(delegate, temp.resolve("history")).load());
  }

  @Test
  void inconsistentStockpileAndOutboxOrMalformedInventoryCannotBeLoaded() {
    var delegate = storage();
    var history = new ResourceHistoryStorage(delegate, temp.resolve("history"));
    history.load();
    history.save(state(10));
    Properties wrong = delegate.load();
    wrong.setProperty("stockpile.0.amount", "11");
    delegate.save(wrong);
    assertThrows(
        IllegalStateException.class,
        () -> new ResourceHistoryStorage(delegate, temp.resolve("history")).load());
    wrong.setProperty("stockpile.0.amount", "-1");
    delegate.save(wrong);
    assertThrows(
        IllegalStateException.class,
        () -> new ResourceHistoryStorage(delegate, temp.resolve("history")).load());
  }

  @Test
  void oversizedArchiveIsRejectedWithoutReadingUnrequestedHistory() throws Exception {
    var delegate = storage();
    var history = new ResourceHistoryStorage(delegate, temp.resolve("history"));
    history.load();
    for (int i = 1; i <= 4; i++) history.save(state(i));
    history.resourceChangesAfter(0, 128);
    Path corrupt =
        temp.resolve("history")
            .resolve(history.historyAuthorityDomainId().orElseThrow().toString())
            .resolve("0/2.receipt");
    Files.writeString(corrupt, "x".repeat(65537));
    assertEquals(1, history.resourceChangesAfter(0, 1).size());
    assertEquals(1, history.resourceChangesAfter(3, 1).size());
    assertThrows(IllegalStateException.class, () -> history.resourceChangesAfter(1, 1));
  }

  private ResourceModule module(ResourceStateStorage storage) {
    return new ResourceModule(new ResourceHistoryStorage(storage, temp.resolve("history")));
  }

  private ResourceStateStorage storage() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getDataFolder()).thenReturn(temp.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    var persistence = new PersistenceService(plugin, null);
    persistence.start();
    return new PersistenceResourceStateStorage("resource", persistence);
  }

  private Properties state(long amount) {
    return ResourceStateCodec.toProperties(Map.of(nation, Map.of("mineral", amount)));
  }

  private NationResourceTransactionService.TransactionRequest request(String id, long amount) {
    return new NationResourceTransactionService.TransactionRequest(
        id,
        nation,
        Map.of("mineral", amount),
        NationResourceTransactionService.Category.RESEARCH,
        "research");
  }

  private static final class FaultStorage implements ResourceStateStorage {
    private final ResourceStateStorage delegate;
    boolean failBefore, failAfter, failRead, failReadAfterCommit;

    FaultStorage(ResourceStateStorage delegate) {
      this.delegate = delegate;
    }

    public Properties load() {
      if (failRead) throw new IllegalStateException("read unavailable");
      return delegate.load();
    }

    public void save(Properties state) {
      if (failBefore) {
        failBefore = false;
        throw new IllegalStateException("before commit");
      }
      delegate.save(state);
      if (failAfter) {
        failAfter = false;
        failRead = failReadAfterCommit;
        throw new IllegalStateException("lost commit reply");
      }
    }
  }
}
