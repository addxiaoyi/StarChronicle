# 国家资源提交历史与权威恢复

2026-11-26，候选分支新增注册服务 `ResourceHistoryService`。通过 `StarCoreApi.service(ResourceHistoryService.class)` 或原生服务注册表获取；不改变既有 `ResourceService`、单国事务和转账 API 签名。普通发放、消耗、幂等单国事务以及两国转账均记录实际库存变化；这不是工厂完成或个人生产贡献证明。

`historyAuthorityDomainId()` 提供独立 UUID；`resourceChangesAfter(after,limit)` 按连续提交序号返回最多128条 `ResourceChangeReceipt`，游标超前拒绝。回执包含操作 UUID、原因、原生事务引用／分类／说明、可空原始 actor、纳秒时间以及最多128项国家／资源的前后余额。现有原生资源入口没有个人 actor，因此当前生产记录的 actor 为 null，不推定国主。饱和发放记录实际增加量；无变化不新增历史。首次安装以已有库存为起点，不补造旧操作。

`ResourceHistoryStorage` 把单条 pending 回执、序号、独立域及唯一提交令牌与资源快照在同一 SQL／原子文件提交中保存。替换 pending 前，先幂等归档到 `resource/history/<domain>/<bucket>/<sequence>.receipt`，每目录最多1024条；`authority-domain` 和 `high-water` 约束来源及回退。查询仅打开请求范围，启动检查末尾前驱／pending／高水位，不扫描终生历史；更早的缺失／损坏在请求该页时拒绝。最后 pending 在重启时可补归档，归档失败阻止下一次资产提交。

提交抛错后只读取持久存储：唯一提交令牌、完整回执与库存匹配时确认原操作成功，不再次发放／扣除。读取不能确定时隔离进一步写入与库存读取，停服也不能用旧内存覆盖未知结果；正常重启从原权威恢复。库存读取与写入共用模块锁，避免暴露提交前中间状态。资源失败恢复仅恢复库存和幂等回执，不替换调用者可能持有的工厂／贸易对象。

SQL 权威在启动时固定；`resource/resource-sql-authority` 记录 MIGRATING／READY。SQL 已固定后，不因不可用或被清空而回读旧 Properties；普通保存与转账共用存储写入队列，SQL 故障禁止文件 fallback。首次迁移把完整库存与旧转账回执放在同一事务，修复仅先导入 authority 导致库存遗漏的路径。首次连接失败可恢复迁移，已有 SQL 迁移标记后不再读取旧文件。普通保存和转账保留全部历史元数据。单国幂等回执新增 `appliedAtInstant`，旧毫秒字段保留并交叉核对；旧数据继续使用原精度。

原生完整 `verify`：1,439套件、7,251项、零失败／错误、21项既有跳过；API兼容及Spotless检查通过，未扩大既有排除。资源专项38项，包括17项新增：文件重启、实际增量、跨128分页、纳秒、事务和转账去重、提交前故障、丢回包、读失败隔离、归档失败、旧备份／换域／坏余额、SQL触发器回滚、首次迁移、数据库缺失及文件到SQL的整服切换。日志 `target/resource-history-tests-20261126-1.log`、`target/resource-native-verify-20261126-1.log`。

配套Chronicle使用schema9保存完整回执与历史、剧情收件箱，公开查询 `resourceHistoryReceipt(eventId)`；普通资源历史不新增贡献，避免重复计入援助和贸易。三次Paper启停及最终源码／构件指纹、真实失败、归档在StarChronicle仓库的 `docs/COMMITTED-RESOURCE-HISTORY.md`。

备份时正常停服，同时复制主 `starcore.db`（或权威数据库一致备份）、resource目录内历史文件与SQL标记、国家状态以及Chronicle库。不得删除标记重新初始化，或把旧文件作为已固定SQL的替代。旧原生版本不理解资源历史协议，回退必须恢复匹配备份；没有宣称任意旧版本会主动拒绝所有资源写入。该存储协议面向单个原生模块写入者，不是多服务器共享SQL的分布式事务；未认证MySQL、全栈Folia、长期容量或生产升级。

下一步是工厂加工：扣原料、开始run、发成品和完成状态需要各自同事务；当前补偿式逐项资源调用仍有崩溃窗口，不能从库存grant推定生产。默认配方旧资源名、持久run、真实actor与实际入口也仍需补齐。不要把本次资源历史验收写成文明生产全部完成。
