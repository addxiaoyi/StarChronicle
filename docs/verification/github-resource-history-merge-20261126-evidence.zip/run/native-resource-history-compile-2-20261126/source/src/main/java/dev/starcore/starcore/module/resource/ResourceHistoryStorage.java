package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.persistence.AtomicFilePersistence;
import dev.starcore.starcore.module.nation.model.NationId;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

/**
 * Commits one history outbox entry in the same atomic snapshot as the resource state. Before
 * replacing that entry, copies it idempotently to an immutable, sequence-addressed file. A crash
 * after the state commit or after the copy is recoverable without guessing whether it committed.
 * Queries read at most 128 small files; neither startup nor paging loads the lifetime history.
 */
final class ResourceHistoryStorage implements ResourceStateStorage {
  private static final String DOMAIN = "resource.history.domain";
  private static final String SEQUENCE = "resource.history.sequence";
  private static final String COMMIT = "resource.history.commit";
  private static final String PENDING = "resource.history.pending";
  private static final int MAX_RECEIPT_BYTES = 65536;
  private final ResourceStateStorage delegate;
  private final Path directory;
  private final java.time.Clock clock;
  private UUID domain;
  private long sequence;
  private ResourceChangeReceipt pending;
  private boolean uncertainWrite;
  private UUID observedDomain;
  private long observedSequence;
  private java.util.Map<BalanceKey, Long> balances = java.util.Map.of();

  private record BalanceKey(NationId nation, String type) {}

  ResourceHistoryStorage(ResourceStateStorage delegate, Path directory) {
    this(delegate, directory, java.time.Clock.systemUTC());
  }

  ResourceHistoryStorage(ResourceStateStorage delegate, Path directory, java.time.Clock clock) {
    this.delegate = Objects.requireNonNull(delegate);
    this.directory = Objects.requireNonNull(directory);
    this.clock = Objects.requireNonNull(clock);
  }

  @Override
  public synchronized Properties load() {
    domain = null;
    uncertainWrite = true;
    Properties properties = copy(delegate.load());
    ResourceStateCodec.validateCounts(properties);
    InventorySnapshotValidator.validate(properties, ResourceModule.RESOURCE_TYPES);
    TradeSnapshotValidator.validate(properties);
    String savedDomain = properties.getProperty(DOMAIN);
    try {
      Path identity = directory.resolve("authority-domain");
      if (savedDomain == null) {
        if (properties.containsKey(SEQUENCE)
            || properties.containsKey(PENDING)
            || Files.exists(identity)) {
          throw new IllegalStateException(
              "Resource history metadata is missing; restore the matching snapshot");
        }
        UUID created = UUID.randomUUID();
        Properties initialized = copy(properties);
        initialized.setProperty(DOMAIN, created.toString());
        initialized.setProperty(SEQUENCE, "0");
        persist(initialized);
        // SQL may atomically migrate factory/trade rows into its archives during this save.
        // Return the actual committed snapshot, including those archive heads and versions.
        properties = copy(delegate.load());
        if (!created.toString().equals(properties.getProperty(DOMAIN))
            || !"0".equals(properties.getProperty(SEQUENCE)))
          throw new IllegalStateException("Resource history initialization was not retained");
        savedDomain = created.toString();
      }
      UUID restoredDomain = UUID.fromString(savedDomain);
      if (!restoredDomain.toString().equals(savedDomain))
        throw new IllegalStateException("Noncanonical resource history domain");
      long restoredSequence = Long.parseLong(properties.getProperty(SEQUENCE));
      if (observedDomain != null
          && (!observedDomain.equals(restoredDomain) || restoredSequence < observedSequence))
        throw new IllegalStateException(
            "Resource authority changed or rolled back during this process");
      if (restoredSequence < 0)
        throw new IllegalStateException("Negative resource history sequence");
      ResourceChangeReceipt restoredPending =
          properties.containsKey(PENDING) ? decode(properties.getProperty(PENDING)) : null;
      if ((restoredSequence > 0) != (restoredPending != null)
          || restoredPending != null
              && (restoredPending.sequence() != restoredSequence
                  || !restoredDomain.equals(restoredPending.authorityDomainId()))) {
        throw new IllegalStateException("Resource state and pending history disagree");
      }
      if (Files.exists(identity)) {
        if (!readBounded(identity).equals(restoredDomain.toString()))
          throw new IllegalStateException(
              "Resource state belongs to a different history authority");
      } else {
        if (restoredSequence > 1)
          throw new IllegalStateException(
              "Resource history directory is missing; restore it with the state");
        AtomicFilePersistence.replace(
            identity, temp -> Files.writeString(temp, restoredDomain.toString()));
      }
      var restoredBalances = readBalances(properties);
      if (restoredPending != null) {
        for (var balance : restoredPending.balances())
          if (restoredBalances.getOrDefault(
                  new BalanceKey(balance.nationId(), balance.resourceType()), 0L)
              != balance.after())
            throw new IllegalStateException("Resource balances disagree with committed history");
      }
      Path highWater = directory.resolve("high-water");
      if (Files.exists(highWater)) {
        String[] mark = readBounded(highWater).split("\\|", -1);
        if (mark.length != 2
            || !mark[0].equals(restoredDomain.toString())
            || Long.parseLong(mark[1]) > restoredSequence)
          throw new IllegalStateException("Resource state is behind its durable high-water mark");
      }
      domain = restoredDomain;
      sequence = restoredSequence;
      pending = restoredPending;
      if (sequence < Long.MAX_VALUE && Files.exists(receiptPath(sequence + 1)))
        throw new IllegalStateException("Resource snapshot is older than its durable history");
      if (sequence > 1) readReceipt(sequence - 1);
      drainPending();
      balances = restoredBalances;
      observedDomain = domain;
      observedSequence = sequence;
      uncertainWrite = false;
      return properties;
    } catch (IOException | IllegalArgumentException error) {
      throw new IllegalStateException("Cannot recover resource history", error);
    }
  }

  @Override
  public synchronized void save(Properties properties) {
    saveChange(properties, ResourceChangeCause.of(ResourceChangeReceipt.Kind.ADJUSTMENT));
  }

  @Override
  public synchronized void saveChange(Properties properties, ResourceChangeCause cause) {
    commit(properties, cause, null, null);
  }

  @Override
  public synchronized void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt transfer) {
    commit(
        properties,
        new ResourceChangeCause(
            ResourceChangeReceipt.Kind.TRANSFER,
            transfer.transactionId(),
            transfer.category().name(),
            transfer.description(),
            null),
        transfer,
        null);
  }

  @Override
  public synchronized void saveProduction(Properties properties, ProductionReceipt receipt) {
    commit(
        properties,
        new ResourceChangeCause(
            ResourceChangeReceipt.Kind.ADJUSTMENT,
            receipt.operationId(),
            "PRODUCTION",
            receipt.recipeId(),
            receipt.actorId()),
        null,
        receipt);
  }

  private void commit(
      Properties properties,
      ResourceChangeCause cause,
      NationResourceTransactionService.TransferReceipt transfer,
      ProductionReceipt production) {
    ensureLoaded();
    Objects.requireNonNull(cause);
    drainPending();
    var nextBalances = readBalances(properties);
    var keys = new java.util.HashSet<>(balances.keySet());
    keys.addAll(nextBalances.keySet());
    List<ResourceChangeReceipt.BalanceChange> changes = new ArrayList<>();
    for (var key : keys) {
      long before = balances.getOrDefault(key, 0L), after = nextBalances.getOrDefault(key, 0L);
      if (before != after)
        changes.add(
            new ResourceChangeReceipt.BalanceChange(key.nation(), key.type(), before, after));
    }
    changes.sort(
        java.util.Comparator.comparing(
                (ResourceChangeReceipt.BalanceChange b) -> b.nationId().toString())
            .thenComparing(ResourceChangeReceipt.BalanceChange::resourceType));
    long next = changes.isEmpty() ? sequence : Math.addExact(sequence, 1);
    ResourceChangeReceipt receipt =
        changes.isEmpty()
            ? pending
            : new ResourceChangeReceipt(
                domain,
                next,
                UUID.randomUUID(),
                cause.kind(),
                cause.reference(),
                cause.category(),
                cause.description(),
                cause.actorId(),
                clock.instant(),
                changes);
    Properties snapshot = withMetadata(properties, next, receipt);
    String commit = UUID.randomUUID().toString();
    snapshot.setProperty(COMMIT, commit);
    // The outbox and balances share the delegate's single durable transaction. A lost commit
    // response fences every later write until reload; never overwrite the unknown result.
    try {
      if (production != null) delegate.saveProduction(snapshot, production);
      else if (transfer == null) delegate.save(snapshot);
      else delegate.saveTransfer(snapshot, transfer);
    } catch (RuntimeException failure) {
      uncertainWrite = true;
      try {
        Properties restored = load();
        // Read-only reconciliation of a lost commit reply: a matching unique outbox operation
        // proves the balances committed. It never calls a grant, consume or transfer again.
        if (commit.equals(restored.getProperty(COMMIT))
            && Objects.equals(receipt, pending)
            && balances.equals(nextBalances)
            && (transfer == null
                || delegate
                    .transferReceipt(transfer.transactionId())
                    .filter(transfer::equals)
                    .isPresent())
            && (production == null
                || delegate
                    .productionReceipt(production.operationId())
                    .filter(production::equals)
                    .isPresent())) return;
      } catch (RuntimeException unavailable) {
        failure.addSuppressed(unavailable);
      }
      throw failure;
    }
    sequence = next;
    pending = receipt;
    balances = nextBalances;
    observedSequence = next;
  }

  @Override
  public synchronized boolean archivesTradeExecutions() {
    ensureLoaded();
    return delegate.archivesTradeExecutions();
  }

  @Override
  public synchronized void writeTradeState(
      Properties state, java.util.Map<String, TradeExecution> executions) {
    ensureLoaded();
    delegate.writeTradeState(state, executions);
  }

  @Override
  public synchronized Optional<TradeExecution> archivedTradeExecution(String id) {
    ensureLoaded();
    return delegate.archivedTradeExecution(id);
  }

  @Override
  public synchronized List<TradeExecution> archivedTradeExecutions(
      NationId nation, long offset, int limit) {
    ensureLoaded();
    return delegate.archivedTradeExecutions(nation, offset, limit);
  }

  @Override
  public synchronized boolean archivesFactoryRuns() {
    ensureLoaded();
    return delegate.archivesFactoryRuns();
  }

  @Override
  public synchronized Optional<FactoryRun> archivedFactoryRun(String id) {
    ensureLoaded();
    return delegate.archivedFactoryRun(id);
  }

  @Override
  public synchronized void writeFactoryState(
      Properties state,
      java.util.Map<String, FactoryRun> runs,
      java.util.Map<UUID, dev.starcore.starcore.module.resource.model.Factory> factories) {
    ensureLoaded();
    delegate.writeFactoryState(state, runs, factories);
  }

  @Override
  public synchronized void validateFactoryProduction(
      Properties snapshot, java.util.Map<String, FactoryRun> runs) {
    ensureLoaded();
    delegate.validateFactoryProduction(snapshot, runs);
  }

  @Override
  public synchronized void validateTradeDeliveries(
      Properties snapshot, java.util.Map<String, TradeExecution> executions) {
    ensureLoaded();
    delegate.validateTradeDeliveries(snapshot, executions);
  }

  @Override
  public synchronized Optional<ProductionReceipt> productionReceipt(String id) {
    ensureLoaded();
    return delegate.productionReceipt(id);
  }

  @Override
  public synchronized List<ProductionReceipt> productionReceiptsAfter(long after, int limit) {
    ensureLoaded();
    return delegate.productionReceiptsAfter(after, limit);
  }

  @Override
  public synchronized long latestProductionSequence() {
    ensureLoaded();
    return delegate.latestProductionSequence();
  }

  @Override
  public synchronized Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(
      String id) {
    ensureLoaded();
    return delegate.transferReceipt(id);
  }

  @Override
  public synchronized List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long after, int limit) {
    ensureLoaded();
    return delegate.transferReceiptsAfter(after, limit);
  }

  @Override
  public synchronized long latestTransferSequence() {
    ensureLoaded();
    return delegate.latestTransferSequence();
  }

  @Override
  public synchronized int transferReceiptCount() {
    ensureLoaded();
    return delegate.transferReceiptCount();
  }

  @Override
  public synchronized Optional<UUID> historyAuthorityDomainId() {
    ensureLoaded();
    return Optional.of(domain);
  }

  @Override
  public synchronized List<ResourceChangeReceipt> resourceChangesAfter(
      long afterSequence, int limit) {
    ensureLoaded();
    if (afterSequence < 0 || limit < 1 || limit > 128)
      throw new IllegalArgumentException(
          "History pages require a nonnegative cursor and 1..128 records");
    if (afterSequence > sequence)
      throw new IllegalStateException(
          "History cursor is ahead of the authority; restore matching backups");
    drainPending();
    List<ResourceChangeReceipt> result = new ArrayList<>(limit);
    long position = afterSequence;
    while (position < sequence && result.size() < limit) result.add(readReceipt(++position));
    return List.copyOf(result);
  }

  private Properties withMetadata(Properties state, long position, ResourceChangeReceipt receipt) {
    Properties snapshot = copy(state);
    snapshot.setProperty(DOMAIN, domain.toString());
    snapshot.setProperty(SEQUENCE, Long.toString(position));
    snapshot.remove(PENDING);
    if (receipt != null) snapshot.setProperty(PENDING, encode(receipt));
    return snapshot;
  }

  private void drainPending() {
    if (pending == null) return;
    Path target = receiptPath(pending.sequence());
    try {
      if (Files.exists(target)) {
        if (!pending.equals(readReceipt(pending.sequence())))
          throw new IllegalStateException("Resource receipt conflicts with the committed outbox");
      } else {
        String encoded = encode(pending);
        AtomicFilePersistence.replace(
            target, temp -> Files.writeString(temp, encoded, StandardCharsets.UTF_8));
      }
      Path highWater = directory.resolve("high-water");
      String expected = domain + "|" + pending.sequence();
      if (!Files.exists(highWater) || !readBounded(highWater).equals(expected))
        AtomicFilePersistence.replace(highWater, temp -> Files.writeString(temp, expected));
    } catch (IOException error) {
      throw new IllegalStateException(
          "Cannot archive committed resource change; pending entry retained", error);
    }
  }

  private ResourceChangeReceipt readReceipt(long position) {
    try {
      ResourceChangeReceipt receipt = decode(readBounded(receiptPath(position)));
      if (receipt.sequence() != position || !receipt.authorityDomainId().equals(domain))
        throw new IllegalStateException("Resource receipt identity mismatch");
      return receipt;
    } catch (IOException | IllegalArgumentException error) {
      throw new IllegalStateException(
          "Missing or corrupt resource receipt at sequence " + position, error);
    }
  }

  private Path receiptPath(long position) {
    // At most 1,024 receipts per directory, with no directory scan or growing in-memory index.
    return directory
        .resolve(domain.toString())
        .resolve(Long.toString((position - 1) / 1024))
        .resolve(position + ".receipt");
  }

  private static String readBounded(Path path) throws IOException {
    try (var input = Files.newInputStream(path)) {
      byte[] bytes = input.readNBytes(MAX_RECEIPT_BYTES + 1);
      if (bytes.length > MAX_RECEIPT_BYTES)
        throw new IOException("Oversized resource history file");
      return new String(bytes, StandardCharsets.UTF_8);
    }
  }

  private static String encode(ResourceChangeReceipt receipt) {
    String rows =
        receipt.balances().stream()
            .map(b -> b.nationId() + ":" + b.resourceType() + ":" + b.before() + ":" + b.after())
            .collect(java.util.stream.Collectors.joining(","));
    String encoded =
        String.join(
            "|",
            "1",
            receipt.authorityDomainId().toString(),
            Long.toString(receipt.sequence()),
            receipt.operationId().toString(),
            receipt.kind().name(),
            text(receipt.reference()),
            text(receipt.category()),
            text(receipt.description()),
            receipt.actorId() == null ? "-" : receipt.actorId().toString(),
            receipt.committedAt().toString(),
            rows);
    if (encoded.length() > MAX_RECEIPT_BYTES)
      throw new IllegalArgumentException("Oversized resource receipt");
    return encoded;
  }

  private static ResourceChangeReceipt decode(String value) {
    if (value == null || value.length() > MAX_RECEIPT_BYTES)
      throw new IllegalArgumentException("Invalid receipt size");
    String[] parts = value.split("\\|", -1);
    if (parts.length != 11 || !parts[0].equals("1"))
      throw new IllegalArgumentException("Invalid resource receipt format");
    List<ResourceChangeReceipt.BalanceChange> rows = new ArrayList<>();
    for (String row : parts[10].split(",", -1)) {
      String[] values = row.split(":", -1);
      if (values.length != 4) throw new IllegalArgumentException("Invalid resource balance row");
      rows.add(
          new ResourceChangeReceipt.BalanceChange(
              new NationId(UUID.fromString(values[0])),
              values[1],
              Long.parseLong(values[2]),
              Long.parseLong(values[3])));
    }
    var receipt =
        new ResourceChangeReceipt(
            UUID.fromString(parts[1]),
            Long.parseLong(parts[2]),
            UUID.fromString(parts[3]),
            ResourceChangeReceipt.Kind.valueOf(parts[4]),
            untext(parts[5]),
            untext(parts[6]),
            untext(parts[7]),
            parts[8].equals("-") ? null : UUID.fromString(parts[8]),
            Instant.parse(parts[9]),
            rows);
    if (!encode(receipt).equals(value))
      throw new IllegalArgumentException("Noncanonical resource receipt");
    return receipt;
  }

  private static java.util.Map<BalanceKey, Long> readBalances(Properties properties) {
    InventorySnapshotValidator.validate(properties, ResourceModule.RESOURCE_TYPES);
    int count = Integer.parseInt(properties.getProperty("count", "0"));
    java.util.Map<BalanceKey, Long> result = new java.util.HashMap<>();
    for (int i = 0; i < count; i++) {
      String prefix = "stockpile." + i + ".";
      String rawNation = properties.getProperty(prefix + "nationId");
      UUID nation = UUID.fromString(rawNation);
      String type = properties.getProperty(prefix + "type");
      if (!nation.toString().equals(rawNation)
          || type == null
          || !type.matches("[a-z][a-z0-9_]{0,63}"))
        throw new IllegalArgumentException("Invalid stockpile identity");
      long amount = Long.parseLong(properties.getProperty(prefix + "amount"));
      if (amount < 0
          || result.putIfAbsent(new BalanceKey(new NationId(nation), type), amount) != null)
        throw new IllegalArgumentException("Invalid or repeated stockpile balance");
    }
    return java.util.Map.copyOf(result);
  }

  private static String text(String value) {
    return Base64.getUrlEncoder()
        .withoutPadding()
        .encodeToString(value.getBytes(StandardCharsets.UTF_8));
  }

  private static String untext(String value) {
    return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
  }

  private static Properties copy(Properties source) {
    Properties result = new Properties();
    for (String key : source.stringPropertyNames())
      result.setProperty(key, source.getProperty(key));
    return result;
  }

  private void ensureLoaded() {
    if (domain == null)
      throw new IllegalStateException("Resource history must be loaded before use");
    if (uncertainWrite)
      throw new IllegalStateException(
          "Resource commit outcome is uncertain; reload before further writes");
  }

  private void persist(Properties snapshot) {
    try {
      delegate.save(snapshot);
    } catch (RuntimeException failure) {
      // A connection or filesystem error can arrive after commit. Never overwrite that outcome
      // from stale memory, including during shutdown. Recovery must consult durable storage.
      uncertainWrite = true;
      throw failure;
    }
  }
}
