package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import javax.sql.DataSource;

final class SqlResourceStateStorage extends AbstractModuleStateStorage
    implements ResourceStateStorage {

  private static final String FILE_NAME = "resources.properties";
  private static final String TABLE_NAME = "starcore_resource_state";
  private static final String TRANSFER_TABLE = "starcore_resource_transfer_receipts";
  private static final String MIGRATION_TABLE = "starcore_resource_state_migrations";
  private static final String RECEIPT_MIGRATION = "resource-transfer-receipts-v1";
  private boolean allowLegacyMigration;
  private volatile boolean archiveEnabled;
  private volatile boolean tradeArchiveEnabled;

  SqlResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    this(namespace, databaseService, persistenceService, logger, true);
  }

  SqlResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger,
      boolean allowLegacyMigration) {
    super(namespace, databaseService, persistenceService, logger);
    this.allowLegacyMigration = allowLegacyMigration;
  }

  // 测试构造函数
  SqlResourceStateStorage(DataSource dataSource, Properties legacyProperties, Logger logger) {
    this("test", mockDatabaseService(dataSource), mockPersistenceService(legacyProperties), logger);
  }

  private static DatabaseService mockDatabaseService(DataSource ds) {
    return new DatabaseService(null, null) {
      @Override
      public synchronized Optional<DataSource> dataSource() {
        return Optional.of(ds);
      }

      @Override
      public synchronized boolean isRunning() {
        return true;
      }
    };
  }

  private static PersistenceService mockPersistenceService(Properties props) {
    return new PersistenceService(null, null) {
      @Override
      public Properties loadProperties(String namespace, String fileName) {
        return props;
      }

      @Override
      public void saveProperties(String namespace, String fileName, Properties properties) {
        // 测试环境：不做实际保存
      }

      @Override
      public CompletableFuture<Void> savePropertiesAsync(
          String namespace, String fileName, Properties properties) {
        return CompletableFuture.completedFuture(null);
      }
    };
  }

  @Override
  public synchronized Properties load() {
    Properties legacy = allowLegacyMigration ? loadFromProperties() : new Properties();
    Properties state;
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      migrateLegacyTransferReceipts(connection, legacy);
      state = loadFromDatabase(connection);
      if (state.isEmpty())
        throw new IllegalStateException("Resource SQL state is empty; restore its database backup");
    } catch (Exception error) {
      return handleSqlLoadFailure(error);
    }
    long legacyHead = ProductionReceiptStore.validate(legacy);
    if (legacyHead > 0) {
      try (Connection connection = openConnection()) {
        for (long i = 1; i <= legacyHead; i++) {
          ProductionReceipt old = ProductionReceiptStore.read(legacy, i);
          if (!SqlProductionReceipts.find(connection, old.operationId())
              .filter(old::equals)
              .isPresent())
            throw new IllegalStateException(
                "Legacy production journal differs from active SQL state");
        }
      } catch (SQLException error) {
        throw new IllegalStateException("Cannot verify legacy production migration", error);
      }
    }
    archiveEnabled = "3".equals(state.getProperty(FactoryRunStore.PREFIX + "version"));
    tradeArchiveEnabled = "2".equals(state.getProperty(TradeExecutionStore.PREFIX + "version"));
    FactoryRunStore.verifyMigration(legacy, state, this);
    allowLegacyMigration = false;
    return state;
  }

  @Override
  public boolean archivesFactoryRuns() {
    return archiveEnabled;
  }

  @Override
  public boolean archivesTradeExecutions() {
    return tradeArchiveEnabled;
  }

  @Override
  public void writeTradeState(Properties state, Map<String, TradeExecution> executions) {
    try (var connection = openConnection()) {
      ensureTable(connection);
      TradeExecutionStore.writeArchived(state, executions, SqlTradeArchive.head(connection));
    } catch (SQLException error) {
      throw new IllegalStateException("Trade archive head unavailable", error);
    }
  }

  @Override
  public Optional<TradeExecution> archivedTradeExecution(String id) {
    if (!tradeArchiveEnabled) return Optional.empty();
    return readArchivedTrades(
            (connection, head) -> SqlTradeArchive.find(connection, id, head).stream().toList())
        .stream()
        .findFirst();
  }

  @Override
  public List<TradeExecution> archivedTradeExecutions(
      dev.starcore.starcore.module.nation.model.NationId nation, long offset, int limit) {
    if (!tradeArchiveEnabled) return List.of();
    return readArchivedTrades(
        (connection, head) -> SqlTradeArchive.page(connection, nation, offset, limit, head));
  }

  @FunctionalInterface
  private interface TradeSelection {
    List<TradeExecution> read(Connection connection, SqlTradeArchive.Head head) throws SQLException;
  }

  private List<TradeExecution> readArchivedTrades(TradeSelection selection) {
    try (var connection = openConnection()) {
      beginSnapshotTransaction(connection);
      try {
        var state = SqlTradeArchive.stateHead(connection);
        if (!"2".equals(state.getProperty(TradeExecutionStore.PREFIX + "version")))
          throw new IllegalStateException("Trade archive authority changed");
        var head = SqlTradeArchive.Head.from(state);
        SqlTradeArchive.validateHead(connection, head);
        var result = selection.read(connection, head);
        Map<String, TradeExecution> values = new java.util.LinkedHashMap<>();
        for (var value : result) {
          if (!value.resourceDomain().equals(state.getProperty("resource.authority-domain")))
            throw new IllegalStateException("Trade archive authority changed");
          values.put(value.executionId(), value);
        }
        validateTradeReceipts(connection, values);
        connection.commit();
        return result;
      } catch (Exception error) {
        connection.rollback();
        throw error;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Trade archive unavailable", error);
    }
  }

  @Override
  public void writeFactoryState(
      Properties state,
      Map<String, FactoryRun> runs,
      Map<java.util.UUID, dev.starcore.starcore.module.resource.model.Factory> factories) {
    try (var c = openConnection()) {
      ensureTable(c);
      FactoryRunStore.writeArchived(state, runs, factories, SqlFactoryArchive.head(c));
    } catch (SQLException error) {
      throw new IllegalStateException("Factory archive head unavailable", error);
    }
  }

  @Override
  public Optional<FactoryRun> archivedFactoryRun(String id) {
    if (!archiveEnabled) return Optional.empty();
    try (var c = openConnection()) {
      beginSnapshotTransaction(c);
      try {
        SqlFactoryArchive.validateHead(c, SqlFactoryArchive.head(c));
        var run = SqlFactoryArchive.find(c, id);
        if (run.isPresent()) {
          var value = run.get();
          var state = SqlProductionReceipts.stateHead(c);
          if (!value.authorityDomainId().equals(state.getProperty("resource.authority-domain")))
            throw new IllegalStateException("Archived factory domain changed");
          SqlProductionReceipts.validate(c, state);
          SqlProductionReceipts.validateRuns(c, Map.of(id, value));
        }
        c.commit();
        return run;
      } catch (Exception error) {
        c.rollback();
        throw error;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Factory archive unavailable", error);
    }
  }

  @Override
  protected String getTableName() {
    return TABLE_NAME;
  }

  @Override
  protected String getFileName() {
    return FILE_NAME;
  }

  @Override
  protected void ensureTable(Connection connection) throws SQLException {
    SqlProductionReceipts.ensure(connection);
    SqlFactoryArchive.ensure(connection);
    SqlTradeArchive.ensure(connection);
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_state (
              property_key VARCHAR(191) PRIMARY KEY,
              property_value TEXT NOT NULL
          )
          """);
    }
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_transfer_receipts (
              transaction_id VARCHAR(191) PRIMARY KEY,
              authority_domain_id VARCHAR(36) NOT NULL,
              sequence BIGINT NOT NULL UNIQUE,
              payer_nation_id VARCHAR(36) NOT NULL,
              receiver_nation_id VARCHAR(36) NOT NULL,
              resources TEXT NOT NULL,
              category VARCHAR(32) NOT NULL,
              description VARCHAR(200) NOT NULL,
              applied_at BIGINT NOT NULL
          )
          """);
    }
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_state_migrations (
              migration_key VARCHAR(100) PRIMARY KEY,
              completed_at BIGINT NOT NULL
          )
          """);
    }
  }

  private void migrateLegacyTransferReceipts(Connection connection, Properties legacy)
      throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    beginSnapshotTransaction(connection);
    try {
      try (PreparedStatement marker =
          connection.prepareStatement(
              "SELECT 1 FROM " + MIGRATION_TABLE + " WHERE migration_key=?")) {
        marker.setString(1, RECEIPT_MIGRATION);
        try (ResultSet result = marker.executeQuery()) {
          if (result.next()) {
            connection.commit();
            return;
          }
        }
      }

      if (!allowLegacyMigration)
        throw new IllegalStateException(
            "Pinned resource SQL migration marker is missing; restore its database backup");
      Properties database = loadFromDatabase(connection);
      // Import the entire initial snapshot before the transfer migration can make SQL nonempty.
      // Otherwise a domain-only row prevents super.load() from migrating stockpiles and factories.
      if (database.isEmpty()) {
        validateLegacyImport(legacy);
        Properties initial = copy(legacy);
        initial.setProperty("resource.sql.initialized", "1");
        writeProperties(connection, initial);
        database = loadFromDatabase(connection);
      }
      long latest = ResourceTransferReceiptStore.latestSequence(legacy);
      String legacyDomain = legacy.getProperty("resource.authority-domain");
      String databaseDomain = database.getProperty("resource.authority-domain");
      if (latest > 0L
          && legacyDomain != null
          && databaseDomain != null
          && !legacyDomain.equals(databaseDomain)) {
        throw new IllegalStateException(
            "Legacy transfer receipts use a different resource authority domain");
      }
      if (latest > 0L && databaseDomain == null && legacyDomain != null) {
        try (PreparedStatement insert =
            connection.prepareStatement(
                "INSERT INTO " + TABLE_NAME + "(property_key,property_value) VALUES(?,?)")) {
          insert.setString(1, "resource.authority-domain");
          insert.setString(2, legacyDomain);
          insert.executeUpdate();
        }
      }

      long cursor = 0L;
      while (cursor < latest) {
        List<NationResourceTransactionService.TransferReceipt> batch =
            ResourceTransferReceiptStore.after(legacy, cursor, 1000);
        if (batch.isEmpty())
          throw new IllegalStateException("Legacy transfer receipt sequence has a gap");
        for (var receipt : batch) migrateReceipt(connection, receipt);
        cursor = batch.getLast().sequence();
      }
      try (PreparedStatement insert =
          connection.prepareStatement(
              "INSERT INTO " + MIGRATION_TABLE + "(migration_key,completed_at) VALUES(?,?)")) {
        insert.setString(1, RECEIPT_MIGRATION);
        insert.setLong(2, System.currentTimeMillis());
        insert.executeUpdate();
      }
      connection.commit();
    } catch (Exception error) {
      connection.rollback();
      if (error instanceof SQLException sqlError) throw sqlError;
      throw new IllegalStateException("Legacy resource transfer receipt migration failed", error);
    } finally {
      connection.setAutoCommit(previousAutoCommit);
    }
  }

  private static void validateLegacyImport(Properties legacy) {
    InventorySnapshotValidator.validate(legacy, ResourceModule.RESOURCE_TYPES);
    TradeSnapshotValidator.validate(legacy);
    String domain = legacy.getProperty("resource.authority-domain");
    if (domain != null) {
      try {
        if (!java.util.UUID.fromString(domain).toString().equals(domain))
          throw new IllegalArgumentException("Noncanonical authority domain");
      } catch (IllegalArgumentException error) {
        throw new IllegalStateException(
            "Legacy resource authority domain requires recovery", error);
      }
    }
    ProductionReceiptStore.validate(legacy);
    var snapshot = ResourceStateCodec.snapshotFromProperties(legacy, ResourceModule.RESOURCE_TYPES);
    ResourceStateStorage file =
        new ResourceStateStorage() {
          public Properties load() {
            return legacy;
          }

          public void save(Properties ignored) {
            throw new UnsupportedOperationException();
          }
        };
    FactoryRunStore.read(legacy, snapshot.factories(), ResourceModule.RESOURCE_TYPES, file);
    TradeExecutionStore.read(legacy, file);
  }

  private static void migrateReceipt(
      Connection connection, NationResourceTransactionService.TransferReceipt receipt)
      throws SQLException {
    try (PreparedStatement select =
        connection.prepareStatement(
            "SELECT * FROM " + TRANSFER_TABLE + " WHERE transaction_id=?")) {
      select.setString(1, receipt.transactionId());
      try (ResultSet result = select.executeQuery()) {
        if (result.next()) {
          if (!receipt.equals(readTransferReceipt(result)))
            throw new IllegalStateException(
                "Legacy transfer receipt conflicts with SQL history: " + receipt.transactionId());
          return;
        }
      }
    }
    try (PreparedStatement insert =
        connection.prepareStatement(
            """
            INSERT INTO starcore_resource_transfer_receipts
              (transaction_id,authority_domain_id,sequence,payer_nation_id,receiver_nation_id,
               resources,category,description,applied_at)
            VALUES (?,?,?,?,?,?,?,?,?)
            """)) {
      insert.setString(1, receipt.transactionId());
      insert.setString(2, receipt.authorityDomainId());
      insert.setLong(3, receipt.sequence());
      insert.setString(4, receipt.payerNationId().toString());
      insert.setString(5, receipt.receiverNationId().toString());
      insert.setString(6, ResourceTransferReceiptStore.encodeResources(receipt.resources()));
      insert.setString(7, receipt.category().name());
      insert.setString(8, receipt.description());
      insert.setLong(9, receipt.appliedAt().toEpochMilli());
      if (insert.executeUpdate() != 1)
        throw new SQLException("Legacy transfer receipt was not migrated");
    }
  }

  @Override
  protected Properties loadFromDatabase(Connection connection) throws SQLException {
    Properties properties = new Properties();
    try (PreparedStatement statement =
            connection.prepareStatement(
                """
                SELECT property_key, property_value
                FROM starcore_resource_state
                ORDER BY property_key
                """);
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        properties.setProperty(rows.getString("property_key"), rows.getString("property_value"));
      }
    }
    ResourceStateCodec.validateCounts(properties);
    SqlProductionReceipts.validate(connection, properties);
    SqlTradeArchive.validateHead(connection, SqlTradeArchive.Head.from(properties));
    return properties;
  }

  @Override
  protected void writeSnapshot(Connection connection, Properties properties) throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    beginSnapshotTransaction(connection);
    try {
      writeProperties(connection, properties);
      connection.commit();
      archiveEnabled = "3".equals(properties.getProperty(FactoryRunStore.PREFIX + "version"));
      tradeArchiveEnabled =
          "2".equals(properties.getProperty(TradeExecutionStore.PREFIX + "version"));
    } catch (Exception exception) {
      connection.rollback();
      throw exception;
    } finally {
      connection.setAutoCommit(previousAutoCommit);
    }
  }

  @Override
  public void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    saveWith(properties, snapshot -> writeTransfer(snapshot, receipt));
  }

  private void writeTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      boolean previousAutoCommit = connection.getAutoCommit();
      beginSnapshotTransaction(connection);
      try {
        writeProperties(connection, properties);
        try (PreparedStatement insert =
            connection.prepareStatement(
                """
                INSERT INTO starcore_resource_transfer_receipts
                  (transaction_id,authority_domain_id,sequence,payer_nation_id,
                   receiver_nation_id,resources,category,description,applied_at)
                VALUES (?,?,?,?,?,?,?,?,?)
                """)) {
          insert.setString(1, receipt.transactionId());
          insert.setString(2, receipt.authorityDomainId());
          insert.setLong(3, receipt.sequence());
          insert.setString(4, receipt.payerNationId().toString());
          insert.setString(5, receipt.receiverNationId().toString());
          insert.setString(6, encodeResources(receipt.resources()));
          insert.setString(7, receipt.category().name());
          insert.setString(8, receipt.description());
          insert.setLong(9, receipt.appliedAt().toEpochMilli());
          if (insert.executeUpdate() != 1) {
            throw new SQLException("Transfer receipt was not inserted");
          }
        }
        connection.commit();
        archiveEnabled = "3".equals(properties.getProperty(FactoryRunStore.PREFIX + "version"));
        tradeArchiveEnabled =
            "2".equals(properties.getProperty(TradeExecutionStore.PREFIX + "version"));
      } catch (Exception error) {
        connection.rollback();
        throw error;
      } finally {
        connection.setAutoCommit(previousAutoCommit);
      }
    } catch (Exception error) {
      throw new IllegalStateException("Atomic resource transfer persistence failed", error);
    }
  }

  @Override
  public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      try (PreparedStatement statement =
          connection.prepareStatement(
              "SELECT * FROM " + TRANSFER_TABLE + " WHERE transaction_id=?")) {
        statement.setString(1, id);
        try (ResultSet result = statement.executeQuery()) {
          return result.next() ? Optional.of(readTransferReceipt(result)) : Optional.empty();
        }
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer receipt", error);
    }
  }

  @Override
  public void validateTradeDeliveries(Properties snapshot, Map<String, TradeExecution> executions) {
    try (var c = openConnection()) {
      beginSnapshotTransaction(c);
      try {
        // Pin the loaded intent domain/head and every receipt batch to one read transaction.
        var head = new Properties();
        try (var statement =
            c.prepareStatement(
                "SELECT property_key,property_value FROM "
                    + TABLE_NAME
                    + " WHERE property_key IN (?,?,?,?)")) {
          var keys =
              List.of(
                  "resource.authority-domain",
                  TradeExecutionStore.PREFIX + "version",
                  TradeExecutionStore.PREFIX + "count",
                  TradeExecutionStore.PREFIX + "head");
          for (int i = 0; i < keys.size(); i++) statement.setString(i + 1, keys.get(i));
          try (var rows = statement.executeQuery()) {
            while (rows.next()) head.setProperty(rows.getString(1), rows.getString(2));
          }
          for (String key : keys)
            if (!java.util.Objects.equals(snapshot.getProperty(key), head.getProperty(key)))
              throw new IllegalStateException("Trade execution snapshot changed");
        }
        validateTradeReceipts(c, executions);
        if ("2".equals(snapshot.getProperty(TradeExecutionStore.PREFIX + "version"))) {
          if (executions.values().stream().anyMatch(value -> value.state().terminal()))
            throw new IllegalStateException("Terminal trade left in live SQL ledger");
          if (!SqlTradeArchive.Head.from(snapshot).equals(SqlTradeArchive.head(c)))
            throw new IllegalStateException("Trade archive snapshot changed");
          SqlTradeArchive.validateAll(c, snapshot, executions);
        }
        c.commit();
      } catch (Exception error) {
        c.rollback();
        throw error;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Trade delivery journal unavailable", error);
    }
  }

  static void validateTradeReceipts(Connection connection, Map<String, TradeExecution> executions)
      throws SQLException {
    var verifier = new TradeExecutionStore.DeliveryVerifier(executions);
    var batch = new ArrayList<String>(256);
    for (String id : verifier.ids()) {
      batch.add(id);
      if (batch.size() == 256) {
        validateTradeBatch(connection, batch, verifier);
        batch.clear();
      }
    }
    if (!batch.isEmpty()) validateTradeBatch(connection, batch, verifier);
    verifier.finish();
  }

  private static void validateTradeBatch(
      Connection c, List<String> ids, TradeExecutionStore.DeliveryVerifier verifier)
      throws SQLException {
    String parameters = String.join(",", java.util.Collections.nCopies(ids.size(), "?"));
    try (var statement =
        c.prepareStatement(
            "SELECT * FROM " + TRANSFER_TABLE + " WHERE transaction_id IN (" + parameters + ")")) {
      for (int i = 0; i < ids.size(); i++) statement.setString(i + 1, ids.get(i));
      try (var rows = statement.executeQuery()) {
        while (rows.next()) verifier.accept(readTransferReceipt(rows));
      }
    }
  }

  @Override
  public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    if (sequence < 0L || limit < 1 || limit > 1000) {
      throw new IllegalArgumentException("sequence must be non-negative and limit must be 1..1000");
    }
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      try (PreparedStatement statement =
          connection.prepareStatement(
              "SELECT * FROM " + TRANSFER_TABLE + " WHERE sequence>? ORDER BY sequence LIMIT ?")) {
        statement.setLong(1, sequence);
        statement.setInt(2, limit);
        try (ResultSet result = statement.executeQuery()) {
          List<NationResourceTransactionService.TransferReceipt> receipts = new ArrayList<>();
          while (result.next()) receipts.add(readTransferReceipt(result));
          return List.copyOf(receipts);
        }
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer journal", error);
    }
  }

  @Override
  public long latestTransferSequence() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      try (Statement statement = connection.createStatement();
          ResultSet result =
              statement.executeQuery("SELECT COALESCE(MAX(sequence),0) FROM " + TRANSFER_TABLE)) {
        return result.next() ? result.getLong(1) : 0L;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer cursor", error);
    }
  }

  @Override
  public int transferReceiptCount() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      try (Statement statement = connection.createStatement();
          ResultSet result = statement.executeQuery("SELECT COUNT(*) FROM " + TRANSFER_TABLE)) {
        return result.next() ? Math.toIntExact(result.getLong(1)) : 0;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to count resource transfer receipts", error);
    }
  }

  private static void writeProperties(Connection connection, Properties properties)
      throws SQLException {
    properties = SqlProductionReceipts.prepareSnapshot(connection, properties);
    prepareFactoryArchive(connection, properties);
    prepareTradeArchive(connection, properties);
    for (String key : properties.stringPropertyNames()) {
      if (key.startsWith("resource.transfer.") || key.startsWith(ProductionReceiptStore.ROW))
        properties.remove(key);
    }
    // Keep the complete replacement semantics, but leave equal rows physically untouched.
    // Read before mutating so drivers never need a second statement on a streaming ResultSet.
    List<String> removed = new ArrayList<>();
    try (var query = connection.createStatement();
        var rows = query.executeQuery("SELECT property_key,property_value FROM " + TABLE_NAME)) {
      while (rows.next()) {
        String key = rows.getString(1);
        if (rows.getString(2).equals(properties.getProperty(key))) properties.remove(key);
        else removed.add(key);
      }
    }
    try (var delete =
        connection.prepareStatement("DELETE FROM " + TABLE_NAME + " WHERE property_key=?")) {
      int pending = 0;
      for (String key : removed) {
        delete.setString(1, key);
        delete.addBatch();
        if (++pending == 256) {
          executeSnapshotBatch(delete);
          pending = 0;
        }
      }
      if (pending > 0) executeSnapshotBatch(delete);
    }
    try (PreparedStatement insert =
        connection.prepareStatement(
            """
            INSERT INTO starcore_resource_state (property_key, property_value)
            VALUES (?, ?)
            """)) {
      int pending = 0;
      for (String key : properties.stringPropertyNames()) {
        insert.setString(1, key);
        insert.setString(2, properties.getProperty(key));
        insert.addBatch();
        if (++pending == 256) {
          executeSnapshotBatch(insert);
          pending = 0;
        }
      }
      if (pending > 0) executeSnapshotBatch(insert);
    }
  }

  private static void prepareFactoryArchive(Connection c, Properties state) throws SQLException {
    String version = state.getProperty(FactoryRunStore.PREFIX + "version");
    var previous = SqlFactoryArchive.head(c);
    if (!"3".equals(version)) {
      // A complete V1/V2 import stays readable until the first V3 business write.
      try (var s =
          c.prepareStatement(
              "SELECT property_value FROM starcore_resource_state WHERE property_key=?")) {
        s.setString(1, FactoryRunStore.PREFIX + "version");
        try (var rows = s.executeQuery()) {
          if (rows.next() && "3".equals(rows.getString(1)))
            throw new IllegalStateException("Cannot downgrade an archived factory snapshot");
        }
      }
      return;
    }
    if (!previous.equals(SqlFactoryArchive.Head.from(state)))
      throw new IllegalStateException("Factory archive head changed before save");
    SqlFactoryArchive.validateHead(c, previous);
    var factories =
        ResourceStateCodec.snapshotFromProperties(state, ResourceModule.RESOURCE_TYPES).factories();
    ResourceStateStorage validator =
        new ResourceStateStorage() {
          public Properties load() {
            throw new UnsupportedOperationException();
          }

          public void save(Properties ignored) {
            throw new UnsupportedOperationException();
          }

          public void validateFactoryProduction(Properties snapshot, Map<String, FactoryRun> runs) {
            try {
              SqlProductionReceipts.validateRuns(c, runs);
            } catch (SQLException error) {
              throw new IllegalStateException(error);
            }
          }
        };
    var runs = FactoryRunStore.read(state, factories, ResourceModule.RESOURCE_TYPES, validator);
    Properties stored = new Properties();
    try (var s = c.createStatement();
        var rows =
            s.executeQuery("SELECT property_key,property_value FROM starcore_resource_state")) {
      while (rows.next()) stored.setProperty(rows.getString(1), rows.getString(2));
    }
    if (stored.containsKey(FactoryRunStore.PREFIX + "version")) {
      ResourceStateStorage structureOnly =
          new ResourceStateStorage() {
            public Properties load() {
              throw new UnsupportedOperationException();
            }

            public void save(Properties ignored) {
              throw new UnsupportedOperationException();
            }

            public void validateFactoryProduction(
                Properties ignored, Map<String, FactoryRun> values) {}
          };
      var oldRuns =
          FactoryRunStore.read(
              stored,
              ResourceStateCodec.snapshotFromProperties(stored, ResourceModule.RESOURCE_TYPES)
                  .factories(),
              ResourceModule.RESOURCE_TYPES,
              structureOnly);
      for (var old : oldRuns.values()) {
        var nextRun = runs.get(old.runId());
        if (nextRun == null
            || (!old.equals(nextRun)
                && (old.completed()
                    || !nextRun.completed()
                    || !old.complete(nextRun.completedAt(), nextRun.completionSequence())
                        .equals(nextRun))))
          throw new IllegalStateException("Stored factory proof removed or rewritten");
      }
    }
    Map<String, FactoryRun> active = new java.util.LinkedHashMap<>();
    var next = previous;
    // Deterministic migration order; ordinary writes contain only active runs and one completion.
    for (FactoryRun run :
        runs.values().stream().sorted(java.util.Comparator.comparing(FactoryRun::runId)).toList()) {
      if (run.completed()) next = SqlFactoryArchive.append(c, next, run);
      else {
        if (SqlFactoryArchive.find(c, run.runId()).isPresent())
          throw new IllegalStateException("Archived factory cannot become active again");
        active.put(run.runId(), run);
      }
    }
    FactoryRunStore.writeArchived(state, active, factories, next);
  }

  private static void prepareTradeArchive(Connection connection, Properties state)
      throws SQLException {
    Properties stored = new Properties();
    try (var statement = connection.createStatement();
        var rows =
            statement.executeQuery("SELECT property_key,property_value FROM " + TABLE_NAME)) {
      while (rows.next()) stored.setProperty(rows.getString(1), rows.getString(2));
    }
    if (!"2".equals(state.getProperty(TradeExecutionStore.PREFIX + "version"))) {
      if ("2".equals(stored.getProperty(TradeExecutionStore.PREFIX + "version")))
        throw new IllegalStateException("Cannot downgrade an archived trade snapshot");
      return;
    }
    var previous = SqlTradeArchive.Head.from(stored);
    if (!previous.equals(SqlTradeArchive.Head.from(state)))
      throw new IllegalStateException("Trade archive head changed before save");
    SqlTradeArchive.validateHead(connection, previous);
    var values = TradeExecutionStore.readStructure(state);
    TradeExecutionStore.validateReservations(state, values);
    validateTradeReceipts(connection, values);
    var old = TradeExecutionStore.readStructure(stored);
    for (var entry : old.entrySet()) {
      var next = values.get(entry.getKey());
      if (next == null) throw new IllegalStateException("Stored trade intent removed");
      SqlTradeArchive.requireTransition(entry.getValue(), next);
    }
    Map<String, TradeExecution> active = new java.util.LinkedHashMap<>();
    var next = previous;
    for (var value :
        values.values().stream()
            .sorted(java.util.Comparator.comparing(TradeExecution::executionId))
            .toList()) {
      if (value.state().terminal()) next = SqlTradeArchive.append(connection, next, value);
      else {
        if (SqlTradeArchive.find(connection, value.executionId(), previous).isPresent())
          throw new IllegalStateException("Archived trade cannot become active again");
        active.put(value.executionId(), value);
      }
    }
    TradeExecutionStore.writeArchived(state, active, next);
  }

  private static void executeSnapshotBatch(PreparedStatement statement) throws SQLException {
    for (int count : statement.executeBatch()) {
      if (count != 1 && count != Statement.SUCCESS_NO_INFO)
        throw new SQLException("Resource snapshot row was not persisted");
    }
    statement.clearBatch();
  }

  private static void beginSnapshotTransaction(Connection connection) throws SQLException {
    if (connection.getAutoCommit()) {
      connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
      connection.setAutoCommit(false);
    } else if (connection.getTransactionIsolation() != Connection.TRANSACTION_SERIALIZABLE) {
      // Changing isolation after work has begun can commit an existing transaction on some drivers.
      throw new SQLException("Resource snapshots require a serializable transaction");
    }
  }

  private static NationResourceTransactionService.TransferReceipt readTransferReceipt(ResultSet row)
      throws SQLException {
    return new NationResourceTransactionService.TransferReceipt(
        row.getString("transaction_id"),
        row.getString("authority_domain_id"),
        row.getLong("sequence"),
        new dev.starcore.starcore.module.nation.model.NationId(
            java.util.UUID.fromString(row.getString("payer_nation_id"))),
        new dev.starcore.starcore.module.nation.model.NationId(
            java.util.UUID.fromString(row.getString("receiver_nation_id"))),
        ResourceTransferReceiptStore.decodeResources(row.getString("resources")),
        NationResourceTransactionService.Category.valueOf(row.getString("category")),
        row.getString("description"),
        java.time.Instant.ofEpochMilli(row.getLong("applied_at")));
  }

  private static String encodeResources(Map<String, Long> resources) {
    return resources.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .map(entry -> entry.getKey() + '=' + entry.getValue())
        .collect(java.util.stream.Collectors.joining(";"));
  }

  @Override
  public void saveAsync(Properties properties) {
    save(properties);
  }

  @Override
  protected void handleSqlWriteFailure(Properties properties, Exception error) {
    throw new IllegalStateException(
        "Resource SQL state write failed; file fallback is unsafe", error);
  }

  @Override
  protected Properties handleSqlLoadFailure(Exception error) {
    throw new IllegalStateException(
        "Resource SQL state load failed; file fallback is unsafe", error);
  }

  @Override
  public void saveProduction(Properties properties, ProductionReceipt receipt) {
    saveWith(
        properties,
        snapshot -> {
          try (Connection c = openConnection()) {
            ensureTable(c);
            beginSnapshotTransaction(c);
            try {
              Properties old = SqlProductionReceipts.stateHead(c);
              long n = SqlProductionReceipts.validate(c, old);
              if (receipt.sequence() != Math.addExact(n, 1)
                  || !receipt
                      .authorityDomainId()
                      .equals(old.getProperty("resource.authority-domain")))
                throw new IllegalStateException("Production authority or sequence changed");
              SqlProductionReceipts.insert(c, receipt);
              ProductionReceiptStore.head(snapshot, receipt);
              writeProperties(c, snapshot);
              c.commit();
              archiveEnabled = "3".equals(snapshot.getProperty(FactoryRunStore.PREFIX + "version"));
              tradeArchiveEnabled =
                  "2".equals(snapshot.getProperty(TradeExecutionStore.PREFIX + "version"));
            } catch (Exception error) {
              c.rollback();
              throw error;
            }
          } catch (Exception error) {
            throw new IllegalStateException("Atomic production persistence failed", error);
          }
        });
  }

  @Override
  public void validateFactoryProduction(Properties snapshot, Map<String, FactoryRun> runs) {
    try (var c = openConnection()) {
      ensureTable(c);
      c.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
      c.setAutoCommit(false);
      try {
        SqlProductionReceipts.validateFactoryProduction(c, snapshot, runs);
        if ("3".equals(snapshot.getProperty(FactoryRunStore.PREFIX + "version"))) {
          if (runs.values().stream().anyMatch(FactoryRun::completed))
            throw new IllegalStateException("Completed factory left in archived snapshot");
          var expected = SqlFactoryArchive.Head.from(snapshot);
          if (!expected.equals(SqlFactoryArchive.head(c)))
            throw new IllegalStateException("Factory archive snapshot changed");
          SqlFactoryArchive.validateAll(
              c,
              expected,
              snapshot.getProperty("resource.authority-domain"),
              ResourceStateCodec.snapshotFromProperties(snapshot, ResourceModule.RESOURCE_TYPES)
                  .factories());
          for (var run : runs.values())
            if (SqlFactoryArchive.find(c, run.runId()).isPresent())
              throw new IllegalStateException("Active batch already archived");
        }
        c.commit();
      } catch (Exception error) {
        c.rollback();
        throw error;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Factory production journal unavailable", error);
    }
  }

  @Override
  public Optional<ProductionReceipt> productionReceipt(String id) {
    try (var c = openConnection()) {
      ensureTable(c);
      SqlProductionReceipts.validate(c, SqlProductionReceipts.stateHead(c));
      return SqlProductionReceipts.find(c, id);
    } catch (Exception error) {
      throw new IllegalStateException("Production receipt unavailable", error);
    }
  }

  @Override
  public List<ProductionReceipt> productionReceiptsAfter(long sequence, int limit) {
    ProductionReceiptStore.requirePage(sequence, limit);
    try (var c = openConnection()) {
      ensureTable(c);
      SqlProductionReceipts.validate(c, SqlProductionReceipts.stateHead(c));
      return SqlProductionReceipts.after(c, sequence, limit);
    } catch (Exception error) {
      throw new IllegalStateException("Production journal unavailable", error);
    }
  }

  @Override
  public long latestProductionSequence() {
    try (var c = openConnection()) {
      ensureTable(c);
      return SqlProductionReceipts.validate(c, SqlProductionReceipts.stateHead(c));
    } catch (Exception error) {
      throw new IllegalStateException("Production cursor unavailable", error);
    }
  }
}
