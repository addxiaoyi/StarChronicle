package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.ProcessingService.*;
import dev.starcore.starcore.module.resource.model.Factory;
import java.nio.file.Path;
import java.util.*;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.sqlite.SQLiteDataSource;

class SqlFactoryPersistenceTest {
  @TempDir Path directory;
  final FactoryPersistenceTest.MutableClock clock = new FactoryPersistenceTest.MutableClock();
  final NationId nation = NationId.random();

  @AfterEach
  void shutdown() {
    dev.starcore.starcore.core.storage.AbstractModuleStateStorage.shutdownNamespace("test");
  }

  DataSource database(String engine) {
    if (engine.equals("sqlite")) {
      SQLiteDataSource db = new SQLiteDataSource();
      db.setUrl("jdbc:sqlite:" + directory.resolve("factory.db"));
      return db;
    }
    JdbcDataSource db = new JdbcDataSource();
    db.setURL("jdbc:h2:mem:factory-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
    return db;
  }

  ResourceStateStorage storage(DataSource db, Properties legacy) {
    return new SqlResourceStateStorage(db, legacy, Logger.getLogger("factory-test"));
  }

  void fund(ResourceModule module) {
    assertTrue(module.grant(nation, "mineral", 90));
    assertTrue(module.grant(nation, "energy", 30));
  }

  FactoryRequest request(UUID factoryId) {
    return new FactoryRequest("batch", factoryId, nation, null, "national_industry", 2);
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void realDatabaseRestartsAndUnrelatedWritesKeepTimedAndImmediateSources(String engine) {
    var db = database(engine);
    var st = storage(db, new Properties());
    var module = new ResourceModule(st, clock);
    var service = FactoryPersistenceTest.service(module, true);
    fund(module);
    var factory = service.buildFactory(nation, "SQL", Factory.FactoryType.SMELTER);
    var start = service.startFactoryRun(request(factory.factoryId()));
    assertEquals(FactoryStatus.STARTED, start.status());
    var immediate =
        service.process(new ProductionRequest("instant", nation, null, "national_industry", 1));
    assertEquals(ProductionStatus.APPLIED, immediate.status());
    assertEquals(
        NationResourceTransactionService.TransferStatus.APPLIED,
        module
            .transfer(
                new NationResourceTransactionService.TransferRequest(
                    "aid",
                    nation,
                    NationId.random(),
                    Map.of("mineral", 1L),
                    NationResourceTransactionService.Category.OTHER,
                    "test"))
            .status());
    var restarted = new ResourceModule(storage(db, new Properties()), clock);
    var resumed = FactoryPersistenceTest.service(restarted, false);
    assertEquals(start.run(), resumed.factoryRun("batch").orElseThrow());
    assertEquals(80, restarted.amount(nation, "mineral"));
    clock.advance(2);
    assertEquals(
        FactoryStatus.COMPLETED, resumed.completeFactoryRun("batch", nation, null).status());
    assertTrue(restarted.grant(nation, "luxury", 1));
    var last = new ResourceModule(storage(db, new Properties()), clock);
    var lastService = FactoryPersistenceTest.service(last, false);
    assertEquals(6, last.amount(nation, "industrial"));
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        lastService.completeFactoryRun("batch", nation, null).status());
    assertEquals(
        List.of("instant", "factory:batch"),
        lastService.productionReceiptsAfter(0, 10).stream()
            .map(ProductionReceipt::operationId)
            .toList());
    assertEquals(1, last.transferReceiptsAfter(0, 10).size());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void rejectedStartSnapshotRollsBackEveryInputAndFactoryRow(String engine) throws Exception {
    var db = database(engine);
    var st = storage(db, new Properties());
    var module = new ResourceModule(st, clock);
    var service = FactoryPersistenceTest.service(module, true);
    fund(module);
    var factory = service.buildFactory(nation, "SQL", Factory.FactoryType.SMELTER);
    rejectState(db, engine, "property_key='" + FactoryRunStore.rowPrefix("batch") + "id'");
    assertEquals(
        FactoryStatus.UNKNOWN, service.startFactoryRun(request(factory.factoryId())).status());
    assertEquals(90, module.amount(nation, "mineral"));
    assertEquals(30, module.amount(nation, "energy"));
    assertTrue(service.factoryRun("batch").isEmpty());
    assertFalse(service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    removeRejection(db, engine);
    var restarted = new ResourceModule(storage(db, new Properties()), clock);
    assertEquals(90, restarted.amount(nation, "mineral"));
    assertEquals(
        FactoryStatus.STARTED,
        FactoryPersistenceTest.service(restarted, true)
            .startFactoryRun(request(factory.factoryId()))
            .status());
    assertEquals(84, restarted.amount(nation, "mineral"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void rejectedCompletionSnapshotRollsBackInsertedReceiptAndOutputTogether(String engine)
      throws Exception {
    var db = database(engine);
    var st = storage(db, new Properties());
    var module = new ResourceModule(st, clock);
    var service = FactoryPersistenceTest.service(module, true);
    fund(module);
    var factory = service.buildFactory(nation, "SQL", Factory.FactoryType.SMELTER);
    service.startFactoryRun(request(factory.factoryId()));
    clock.advance(2);
    rejectState(
        db, engine, "property_key='resource.factory-runs.archive-count' AND property_value='1'");
    assertEquals(FactoryStatus.UNKNOWN, service.completeFactoryRun("batch", nation, null).status());
    assertEquals(0, module.amount(nation, "industrial"));
    assertEquals(84, module.amount(nation, "mineral"));
    assertTrue(service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertTrue(service.productionReceiptsAfter(0, 10).isEmpty());
    removeRejection(db, engine);
    var restarted = new ResourceModule(storage(db, new Properties()), clock);
    var resumed = FactoryPersistenceTest.service(restarted, false);
    assertEquals(
        FactoryStatus.COMPLETED, resumed.completeFactoryRun("batch", nation, null).status());
    assertEquals(4, restarted.amount(nation, "industrial"));
    assertEquals(1, resumed.productionReceiptsAfter(0, 10).size());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void fileToSqlMigrationKeepsActiveBatchStockpileAndBothExistingJournals(String engine) {
    var file = new ProductionPersistenceTest.MemoryStorage();
    var before = new ResourceModule(file, clock);
    var service = FactoryPersistenceTest.service(before, true);
    fund(before);
    var factory = service.buildFactory(nation, "File", Factory.FactoryType.SMELTER);
    var run = service.startFactoryRun(request(factory.factoryId())).run();
    service.process(new ProductionRequest("instant", nation, null, "national_industry", 1));
    before.transfer(
        new NationResourceTransactionService.TransferRequest(
            "aid",
            nation,
            NationId.random(),
            Map.of("mineral", 1L),
            NationResourceTransactionService.Category.OTHER,
            "test"));
    var db = database(engine);
    var sql = storage(db, file.load());
    var migrated = new ResourceModule(sql, clock);
    var resumed = FactoryPersistenceTest.service(migrated, false);
    assertEquals(run, resumed.factoryRun("batch").orElseThrow());
    assertEquals(80, migrated.amount(nation, "mineral"));
    clock.advance(2);
    assertEquals(
        FactoryStatus.COMPLETED, resumed.completeFactoryRun("batch", nation, null).status());
    assertEquals(6, migrated.amount(nation, "industrial"));
    var again = new ResourceModule(storage(db, file.load()), clock);
    assertEquals(6, again.amount(nation, "industrial"));
    assertEquals(
        2, FactoryPersistenceTest.service(again, false).productionReceiptsAfter(0, 10).size());
    assertEquals(1, again.transferReceiptsAfter(0, 10).size());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void failedCombinedMigrationRollsBackStockpileFactoryProductionAndMarker(String engine)
      throws Exception {
    var file = new ProductionPersistenceTest.MemoryStorage();
    var before = new ResourceModule(file, clock);
    var service = FactoryPersistenceTest.service(before, true);
    fund(before);
    var factory = service.buildFactory(nation, "File", Factory.FactoryType.SMELTER);
    service.startFactoryRun(request(factory.factoryId()));
    service.process(new ProductionRequest("instant", nation, null, "national_industry", 1));
    before.transfer(
        new NationResourceTransactionService.TransferRequest(
            "aid",
            nation,
            NationId.random(),
            Map.of("mineral", 1L),
            NationResourceTransactionService.Category.OTHER,
            "test"));
    var db = database(engine);
    storage(db, new Properties()).load();
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.execute("DELETE FROM starcore_resource_state_migrations");
      // Recreate a pre-migration empty database, including the new empty-state sentinel.
      s.execute("DELETE FROM starcore_resource_state");
      s.execute(
          engine.equals("sqlite")
              ? "CREATE TRIGGER reject_aid BEFORE INSERT ON starcore_resource_transfer_receipts"
                  + " BEGIN SELECT RAISE(ABORT, 'injected migration failure'); END"
              : "ALTER TABLE starcore_resource_transfer_receipts ADD CONSTRAINT reject_aid"
                  + " CHECK(transaction_id<>'aid')");
    }
    var sql = storage(db, file.load());
    assertThrows(IllegalStateException.class, sql::load);
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      for (String table :
          List.of(
              "starcore_resource_state",
              "starcore_resource_state_migrations",
              "starcore_resource_production_receipts",
              "starcore_resource_transfer_receipts")) {
        try (var r = s.executeQuery("SELECT COUNT(*) FROM " + table)) {
          assertTrue(r.next());
          assertEquals(0, r.getInt(1), table);
        }
      }
      s.execute(
          engine.equals("sqlite")
              ? "DROP TRIGGER reject_aid"
              : "ALTER TABLE starcore_resource_transfer_receipts DROP CONSTRAINT reject_aid");
    }
    var migrated = new ResourceModule(sql, clock);
    assertEquals(80, migrated.amount(nation, "mineral"));
    assertEquals(2, migrated.amount(nation, "industrial"));
    assertTrue(
        FactoryPersistenceTest.service(migrated, false)
            .activeFactoryRun(factory.factoryId())
            .isPresent());
    assertEquals(1, migrated.transferReceiptsAfter(0, 10).size());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void nonemptySqlCannotSilentlyIgnoreANewerFileBatch(String engine) {
    var db = database(engine);
    var file = new ProductionPersistenceTest.MemoryStorage();
    var resources = new ResourceModule(file, clock);
    fund(resources);
    var processing = FactoryPersistenceTest.service(resources, true);
    var factory = processing.buildFactory(nation, "SQL", Factory.FactoryType.SMELTER);
    var st = storage(db, file.load());
    new ResourceModule(st, clock);
    var fileModule = new ResourceModule(file, clock);
    assertEquals(
        FactoryStatus.STARTED,
        FactoryPersistenceTest.service(fileModule, true)
            .startFactoryRun(request(factory.factoryId()))
            .status());
    assertThrows(IllegalStateException.class, () -> storage(db, file.load()).load());
    var intact = new ResourceModule(st, clock);
    assertEquals(90, intact.amount(nation, "mineral"));
    assertFalse(
        FactoryPersistenceTest.service(intact, false)
            .getFactory(factory.factoryId())
            .orElseThrow()
            .isProcessing());
  }

  void rejectState(DataSource db, String engine, String condition) throws Exception {
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.execute(
          engine.equals("sqlite")
              ? "CREATE TRIGGER reject_factory BEFORE INSERT ON starcore_resource_state WHEN "
                  + condition
                      .replace("property_key", "NEW.property_key")
                      .replace("property_value", "NEW.property_value")
                  + " BEGIN SELECT RAISE(ABORT, 'injected factory failure'); END"
              : "ALTER TABLE starcore_resource_state ADD CONSTRAINT reject_factory CHECK(NOT("
                  + condition
                  + "))");
    }
  }

  void removeRejection(DataSource db, String engine) throws Exception {
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.execute(
          engine.equals("sqlite")
              ? "DROP TRIGGER reject_factory"
              : "ALTER TABLE starcore_resource_state DROP CONSTRAINT reject_factory");
    }
  }
}
