package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.Factory;
import dev.starcore.starcore.module.resource.model.ProcessingRecipe;
import io.github.addxiaoyi.starchronicle.core.RuleEngine;
import io.github.addxiaoyi.starchronicle.history.CommittedHistoryJournal;
import io.github.addxiaoyi.starchronicle.integration.CommittedSourceCollector;
import io.github.addxiaoyi.starchronicle.persistence.SqliteStore;
import java.lang.reflect.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.function.*;
import java.util.logging.Logger;
import org.sqlite.SQLiteDataSource;

/** Actual packaged storage and consumers; only the clock is controlled. No Minecraft server. */
public final class ResourceHistoryMergeProbe {
  static final NationId PAYER=NationId.of(new UUID(1,1)), RECEIVER=NationId.of(new UUID(1,2));
  static final String NS="starcore.resources";
  static final ProcessingRecipe RECIPE=new ProcessingRecipe("merge_recipe","Merge conversion",
      Map.of("mineral",3L,"energy",1L),Map.of("industrial",2L),1,0,1);
  static final class TestClock extends Clock {
    Instant time=Instant.parse("2026-11-26T00:00:00Z");
    public ZoneId getZone(){return ZoneOffset.UTC;} public Clock withZone(ZoneId zone){return this;}
    public Instant instant(){return time;}
  }
  static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
  static Object call(Object target,String method,Class<?>[] types,Object...args)throws Exception {
    try{return target.getClass().getMethod(method,types).invoke(target,args);}
    catch(InvocationTargetException failure){throw (Exception)failure.getCause();}
  }
  static ResourceStateStorage wrap(ResourceStateStorage storage,Path folder)throws Exception {
    var c=Class.forName("dev.starcore.starcore.module.resource.ResourceHistoryStorage").getDeclaredConstructor(ResourceStateStorage.class,Path.class);
    c.setAccessible(true);return (ResourceStateStorage)c.newInstance(storage,folder.resolve("history"));
  }
  static Object scanner(ResourceModule source,CommittedHistoryJournal journal)throws Exception {
    var c=Class.forName("io.github.addxiaoyi.starchronicle.integration.StarCoreResourceHistory").getDeclaredConstructor(Supplier.class,CommittedHistoryJournal.class);
    c.setAccessible(true);return c.newInstance((Supplier<Object>)()->source,journal);
  }
  static CommittedSourceCollector collector(ResourceModule module)throws Exception {
    var c=CommittedSourceCollector.class.getDeclaredConstructor(Function.class);c.setAccessible(true);
    var processing=new SimpleProcessingService(module,new SimpleResourcePriceService());
    return c.newInstance((Function<String,Object>)(key->key.endsWith("ProcessingService")?processing:module));
  }
  static List<?> changes(ResourceModule module)throws Exception {
    List<Object> result=new ArrayList<>();long after=0;
    for(int page=0;page<20;page++){var rows=(List<?>)call(module,"resourceChangesAfter",new Class<?>[]{long.class,int.class},after,128);
      result.addAll(rows);if(rows.size()<128)return result;
      after=(long)call(rows.getLast(),"sequence",new Class<?>[0]);}
    throw new AssertionError("Unbounded history");
  }
  static void mutate(ResourceModule module,int from,int through)throws Exception {
    for(int i=from;i<=through;i++)switch(i%5){
      case 1->check(module.grant(PAYER,"mineral",3),"grant");
      case 2->check(module.consume(PAYER,"mineral",1),"consume");
      case 3->check(module.grant(new NationResourceTransactionService.TransactionRequest("merge:grant:"+i,PAYER,Map.of("mineral",2L),NationResourceTransactionService.Category.OTHER,"原文|💎")).status()==NationResourceTransactionService.Status.APPLIED,"transaction grant");
      case 4->check(module.consume(new NationResourceTransactionService.TransactionRequest("merge:consume:"+i,PAYER,Map.of("mineral",1L),NationResourceTransactionService.Category.RESEARCH,"research")).status()==NationResourceTransactionService.Status.APPLIED,"transaction consume");
      case 0->check(module.transfer(new NationResourceTransactionService.TransferRequest("merge:transfer:"+i,PAYER,RECEIVER,Map.of("mineral",1L),NationResourceTransactionService.Category.OTHER,"aid")).status()==NationResourceTransactionService.TransferStatus.APPLIED,"transfer");
    }
  }
  public static void main(String[] args)throws Exception {
    System.setOut(new java.io.PrintStream(System.out,true,java.nio.charset.StandardCharsets.UTF_8));
    Path folder=Path.of(args[0]);Files.createDirectories(folder);String phase=args[1];
    boolean seed=phase.equals("seed");var data=new SQLiteDataSource();data.setUrl("jdbc:sqlite:"+folder.resolve("starcore.db"));
    ResourceStateStorage storage=new SqlResourceStateStorage(data,new Properties(),Logger.getAnonymousLogger());
    if(!seed)storage=wrap(storage,folder);
    var clock=new TestClock();var module=new ResourceModule(storage,clock);
    check(!module.authorityDomainId().isBlank(),"Native authority unavailable");
    if(seed){
      check(module.grant(PAYER,"mineral",1000),"seed mineral");check(module.grant(PAYER,"energy",1000),"seed energy");
      mutate(module,1,10);
      check(module.processProduction(new ProcessingService.ProductionRequest("legacy:production",PAYER,null,RECIPE.recipeId(),2),RECIPE).status()==ProcessingService.ProductionStatus.APPLIED,"seed conversion");
      var factory=module.buildNativeFactory(PAYER,"Original factory",Factory.FactoryType.SMELTER);
      var request=new ProcessingService.FactoryRequest("legacy:factory",factory.factoryId(),PAYER,null,RECIPE.recipeId(),1);
      check(module.startFactoryRun(request,RECIPE).status()==ProcessingService.FactoryStatus.STARTED,"seed factory");
      clock.time=clock.time.plusSeconds(60);
      check(module.completeFactoryRun(request.runId(),PAYER,null).status()==ProcessingService.FactoryStatus.COMPLETED,"seed completion");
    }
    if(phase.equals("append")){
      mutate(module,11,270);
      check(module.processProduction(new ProcessingService.ProductionRequest("current:production",PAYER,null,RECIPE.recipeId(),2),RECIPE).status()==ProcessingService.ProductionStatus.APPLIED,"current conversion");
      var factory=module.buildNativeFactory(PAYER,"Current factory",Factory.FactoryType.SMELTER);
      check(module.startFactoryRun(new ProcessingService.FactoryRequest("current:factory",factory.factoryId(),PAYER,null,RECIPE.recipeId(),1),RECIPE).status()==ProcessingService.FactoryStatus.STARTED,"current start");
      clock.time=clock.time.plusSeconds(120);
      check(module.completeFactoryRun("current:factory",PAYER,null).status()==ProcessingService.FactoryStatus.COMPLETED,"current completion");
    }
    try(var db=new SqliteStore(folder.resolve("chronicle.db"))) {
      var engine=new RuleEngine(db,List.of(),Clock.systemUTC());var journal=new CommittedHistoryJournal(db);
      var collector=collector(module);int transferred=0,produced=0,accepted=0;
      for(var source:List.of(CommittedSourceCollector.Source.RESOURCES,CommittedSourceCollector.Source.PRODUCTION)){
        for(int p=0;p<20;p++){int count=engine.acceptCommittedSource(collector.collect(source,engine.committedSourceCursor(source.id)).orElseThrow(),List.of());
          if(source==CommittedSourceCollector.Source.RESOURCES)transferred+=count;else produced+=count;
          if(count==0)break;check(p<19,"Unbounded legacy collection");}
      }
      if(!seed){Object scanner=scanner(module,journal);
        for(int p=0;p<20;p++){int scanned=(int)call(scanner,"scan",new Class<?>[0]);int delivered=0;
          for(var pending:journal.pending(NS,128)){engine.acceptCommittedHistory(pending,List.of());check(journal.acknowledge(pending.event().id()),"ack full receipt");delivered++;}
          accepted+=delivered;if(scanned==0&&delivered==0)break;check(p<19,"Unbounded journal collection");}
      }
      Map<String,Object> result=new TreeMap<>();result.put("phase",phase);result.put("accepted",accepted);
      result.put("new_transfers",transferred);result.put("new_productions",produced);
      result.put("native_domain",module.authorityDomainId());result.put("payer",module.stockpile(PAYER));result.put("receiver",module.stockpile(RECEIVER));
      result.put("transactions",ResourceStateCodec.snapshotFromProperties(storage.load(),ResourceModule.RESOURCE_TYPES).receipts());
      result.put("productions",storage.productionReceiptsAfter(0,128));result.put("transfers",storage.transferReceiptsAfter(0,128));
      result.put("legacy_factory",module.factoryRun("legacy:factory").orElse(null));result.put("current_factory",module.factoryRun("current:factory").orElse(null));
      result.put("transfer_cursor",engine.committedSourceCursor(NS).orElse(null));result.put("production_cursor",engine.committedSourceCursor("starcore.production").orElse(null));
      if(!seed){result.put("changes",changes(module));result.put("history_cursor",journal.cursor(NS).orElse(null));}
      result.put("counts",db.transaction(c->{Map<String,Long> counts=new TreeMap<>();for(String t:List.of("events","contributions","resource_history_receipts","committed_history_ingress")){
        try(var s=c.createStatement();var r=s.executeQuery("SELECT count(*) FROM "+t)){r.next();counts.put(t,r.getLong(1));}catch(java.sql.SQLException absent){if(!seed)throw absent;}}return counts;}));
      System.out.println(SqliteStore.json(result));
    }finally{AbstractModuleStateStorage.shutdownNamespace("test");}
  }
}
