package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.ProcessingService.*;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceHistoryCompatibilityTest {
  @TempDir Path directory;
  final NationId nation = new NationId(new UUID(0, 81));

  @AfterEach
  void stop() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  DataSource database(String engine) {
    var helper = new SqlFactoryArchiveTest();
    helper.directory = directory;
    return helper.database(engine);
  }

  ResourceHistoryStorage history(ResourceStateStorage delegate) {
    return new ResourceHistoryStorage(delegate, directory.resolve("history"));
  }

  SqlResourceStateStorage sql(DataSource db, Properties legacy) {
    return new SqlResourceStateStorage(db, legacy, Logger.getAnonymousLogger());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void legacyFactoryArchivesAndProductionCommitRetainEveryProofThroughHistoryWrapper(String engine)
      throws Exception {
    var legacy = FactorySnapshotVersionTest.legacy();
    var original = FactorySnapshotVersionTest.copy(legacy);
    var db = database(engine);
    var storage = history(sql(db, legacy));
    var module = new ResourceModule(storage, FactorySnapshotVersionTest.CLOCK);
    assertFalse(module.authorityDomainId().isBlank());
    TradeExecutionArchiveTest.flush(module);
    assertEquals(3, SqlFactoryArchiveTest.archiveCount(db));
    assertEquals(1, SqlFactoryArchiveTest.liveRuns(module));
    assertTrue(
        module.resourceChangesAfter(0, 128).isEmpty(), "Migration must not invent production");
    var before = storage.productionReceiptsAfter(0, 128);
    assertEquals(3, before.size());
    var service = FactoryPersistenceTest.service(module, false);
    var completed = service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null);
    assertEquals(FactoryStatus.COMPLETED, completed.status());
    assertEquals(4, SqlFactoryArchiveTest.archiveCount(db));
    assertEquals(0, SqlFactoryArchiveTest.liveRuns(module));
    var change = module.resourceChangesAfter(0, 128).getFirst();
    assertEquals(ResourceChangeReceipt.Kind.ADJUSTMENT, change.kind());
    assertEquals(completed.run().productionOperationId(), change.reference());
    assertEquals(completed.run().actorId(), change.actorId());
    assertEquals(2, change.balances().getFirst().delta());
    var restarted = new ResourceModule(history(sql(db, legacy)), FactorySnapshotVersionTest.CLOCK);
    var resumed = FactoryPersistenceTest.service(restarted, false);
    assertEquals(completed.run(), resumed.factoryRun("batch-3").orElseThrow());
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        resumed.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(before, resumed.productionReceiptsAfter(0, 3));
    assertEquals(List.of(change), restarted.resourceChangesAfter(0, 128));
    assertEquals(original, legacy);
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void tradeArchiveQueriesAndTransferJournalStayNativeAcrossWrapperRestart(String engine)
      throws Exception {
    var source = TradeExecutionReceiptValidationTest.fixture(131);
    var original = FactorySnapshotVersionTest.copy(source.state());
    var db = database(engine);
    var storage = history(sql(db, source.state()));
    var loaded = TradeExecutionArchiveTest.attach(storage);
    TradeExecutionArchiveTest.flush(loaded.module());
    assertEquals(4, TradeExecutionArchiveTest.resident(loaded.module()));
    assertEquals(133, TradeExecutionArchiveTest.count(db, SqlTradeArchive.TABLE));
    assertTrue(loaded.module().resourceChangesAfter(0, 128).isEmpty());
    assertTrue(loaded.module().grant(nation, "mineral", 10));
    var transfer =
        new NationResourceTransactionService.TransferRequest(
            "new-transfer",
            nation,
            TradeExecutionReceiptValidationTest.IMPORTER,
            Map.of("mineral", 2L),
            NationResourceTransactionService.Category.OTHER,
            "");
    assertEquals(
        NationResourceTransactionService.TransferStatus.APPLIED,
        loaded.module().transfer(transfer).status());
    var history = loaded.module().resourceChangesAfter(0, 128);
    var receipt = loaded.module().transferReceipt("new-transfer").orElseThrow();
    assertEquals(133, receipt.sequence());
    var restarted = TradeExecutionArchiveTest.attach(history(sql(db, source.state())));
    for (var value : source.executions().values())
      assertEquals(value, restarted.trades().tradeExecution(value.executionId()).orElseThrow());
    var expected =
        source.executions().values().stream()
            .sorted(SqlTradeArchive.ORDER)
            .skip(127)
            .limit(10)
            .toList();
    assertEquals(
        expected,
        restarted.trades().tradeExecutions(TradeExecutionReceiptValidationTest.EXPORTER, 127, 10));
    assertEquals(history, restarted.module().resourceChangesAfter(0, 128));
    assertEquals(receipt, restarted.module().transferReceipt("new-transfer").orElseThrow());
    assertEquals(
        NationResourceTransactionService.TransferStatus.ALREADY_APPLIED,
        restarted.module().transfer(transfer).status());
    assertEquals(original, source.state());
  }

  @ParameterizedTest
  @CsvSource({"sqlite,false", "sqlite,true", "h2,false", "h2,true"})
  void productionOutboxAndSqlReceiptReconcileBeforeOrAfterCommitWithoutSecondConversion(
      String engine, boolean after) throws Exception {
    var actual = database(engine);
    var armed = new AtomicBoolean();
    var faulty =
        (DataSource)
            Proxy.newProxyInstance(
                DataSource.class.getClassLoader(),
                new Class<?>[] {DataSource.class},
                (p, m, a) -> {
                  Object value = SqlFactoryArchiveTest.invoke(actual, m, a);
                  if (!(value instanceof Connection c)) return value;
                  return Proxy.newProxyInstance(
                      Connection.class.getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (proxy, method, args) -> {
                        // Only a resource write containing the new outbox uses commit while armed.
                        if (method.getName().equals("commit") && armed.compareAndSet(true, false)) {
                          if (after) SqlFactoryArchiveTest.invoke(c, method, args);
                          throw new SQLException(after ? "Lost commit reply" : "Commit rejected");
                        }
                        return SqlFactoryArchiveTest.invoke(c, method, args);
                      });
                });
    var storage = history(sql(faulty, new Properties()));
    var module = new ResourceModule(storage);
    module.grant(nation, "mineral", 30);
    module.grant(nation, "energy", 10);
    var service = new ProductionPersistenceTest().service(module);
    var request = new ProductionRequest("history-production", nation, null, "national_industry", 2);
    armed.set(true);
    var result = service.process(request);
    assertEquals(after ? ProductionStatus.APPLIED : ProductionStatus.UNKNOWN, result.status());
    assertEquals(after ? 4 : 0, module.amount(nation, "industrial"));
    assertEquals(after ? 3 : 2, module.resourceChangesAfter(0, 128).size());
    if (!after) assertEquals(ProductionStatus.APPLIED, service.process(request).status());
    var original = service.productionReceipt(request.operationId()).orElseThrow();
    var changes = module.resourceChangesAfter(0, 128);
    var restarted = new ResourceModule(history(sql(actual, new Properties())));
    var resumed = new ProductionPersistenceTest().service(restarted);
    assertEquals(ProductionStatus.ALREADY_APPLIED, resumed.process(request).status());
    assertEquals(original, resumed.productionReceipt(request.operationId()).orElseThrow());
    assertEquals(24, restarted.amount(nation, "mineral"));
    assertEquals(8, restarted.amount(nation, "energy"));
    assertEquals(4, restarted.amount(nation, "industrial"));
    assertEquals(changes, restarted.resourceChangesAfter(0, 128));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "count",
        "transaction.count",
        "factory.count",
        "agreement.count",
        "route.count",
        "embargo.count",
        "quota.count"
      })
  void corruptInitialCountsNeverEstablishAHistoryAuthority(String key) throws Exception {
    var delegate = new ProductionPersistenceTest.MemoryStorage();
    delegate.state.setProperty(key, Integer.toString(Integer.MAX_VALUE));
    var before = delegate.load();
    assertThrows(IllegalStateException.class, () -> history(delegate).load());
    assertEquals(before, delegate.load());
    assertFalse(Files.exists(directory.resolve("history/authority-domain")));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "bad",
        "2026-11-26T00:00:01Z",
        "2026-11-26T00:00:00.000Z",
        "+1000000000-12-31T23:59:59.999999999Z"
      })
  void invalidExactTimestampsCannotSilentlyReplaceOriginalMillis(String time) {
    var delegate = new ProductionPersistenceTest.MemoryStorage();
    var receipt =
        new NationResourceTransactionService.TransactionReceipt(
            "old",
            nation,
            Map.of("mineral", 1L),
            NationResourceTransactionService.Operation.GRANT,
            NationResourceTransactionService.Category.OTHER,
            "",
            Instant.parse("2026-11-26T00:00:00Z"));
    delegate.state =
        ResourceStateCodec.toProperties(
            Map.of(nation, Map.of("mineral", 1L)), Map.of("old", receipt));
    delegate.state.setProperty("transaction.0.appliedAtInstant", time);
    var before = delegate.load();
    assertThrows(IllegalStateException.class, () -> history(delegate).load());
    assertEquals(before, delegate.load());
  }

  @ParameterizedTest
  @ValueSource(strings = {"factory", "trade", "domain"})
  void damagedCoupledSnapshotRemainsUnchangedBeforeNewHistoryDomain(String kind) throws Exception {
    var delegate = new ProductionPersistenceTest.MemoryStorage();
    if (kind.equals("factory")) {
      delegate.state = FactorySnapshotVersionTest.legacy();
      delegate.state.setProperty(FactoryRunStore.PREFIX + "head", "damaged");
    } else if (kind.equals("trade")) {
      delegate.state = TradeExecutionReceiptValidationTest.fixture(2).state();
      delegate.state.setProperty(TradeExecutionStore.PREFIX + "head", "damaged");
    } else delegate.state.setProperty("resource.authority-domain", "bad-domain");
    var before = delegate.load();
    assertThrows(IllegalStateException.class, () -> history(delegate).load());
    assertEquals(before, delegate.load());
    assertFalse(Files.exists(directory.resolve("history/authority-domain")));
  }

  @Test
  void inheritedSnapshotRetainsNanosecondReceiptAndAllBalances() {
    Instant time = Instant.parse("2026-11-26T00:00:00.123456789Z");
    var receipt =
        new NationResourceTransactionService.TransactionReceipt(
            "inherited",
            nation,
            Map.of("mineral", 4L),
            NationResourceTransactionService.Operation.GRANT,
            NationResourceTransactionService.Category.OTHER,
            "old",
            time);
    Properties defaults =
        ResourceStateCodec.toProperties(
            Map.of(nation, Map.of("mineral", 4L)), Map.of("inherited", receipt));
    var delegate =
        new ProductionPersistenceTest.MemoryStorage() {
          @Override
          public Properties load() {
            return new Properties(state);
          }
        };
    delegate.state = defaults;
    var module = new ResourceModule(history(delegate));
    assertEquals(receipt, module.transactionReceipt("inherited").orElseThrow());
    assertEquals(4, module.amount(nation, "mineral"));
    assertTrue(module.grant(nation, "mineral", 1));
    var restarted = new ResourceModule(history(delegate));
    assertEquals(receipt, restarted.transactionReceipt("inherited").orElseThrow());
    assertEquals(5, restarted.amount(nation, "mineral"));
    assertEquals(1, restarted.resourceChangesAfter(0, 128).size());
  }
}
