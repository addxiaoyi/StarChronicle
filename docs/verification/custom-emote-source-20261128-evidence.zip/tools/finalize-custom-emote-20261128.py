from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1]; native=root.parent/'StarChronicle-audit/starcore-all-stages'
attempt=sys.argv[2] if len(sys.argv)>2 else 'native-custom-emote-focused-1-20261128'
tests=json.loads((root/'run'/attempt/'result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][k]==0 for k in ('failures','errors','skipped'))
frozen=root/'run/custom-emote-frozen-pair-1-20261128'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
if sys.argv[1]=='freeze':
    frozen.mkdir(); manifest={}
    for name,source,key in [('chronicle.jar',root/'run/social-data-command-frozen-pair-1-20261128/chronicle.jar',None),
            ('native.jar',native/'target/starcore-1.0.0.jar','starcore-1.0.0.jar'),
            ('original-native.jar',native/'target/original-starcore-1.0.0.jar','original-starcore-1.0.0.jar')]:
        original=sha(source)
        if key:assert tests['artifacts'][key]==original
        if key:shutil.copy2(source,frozen/name)
        else:os.link(source,frozen/name)
        assert sha(frozen/name)==original
        manifest[name]={'sha256':original,'bytes':source.stat().st_size,'source':str(source)}
    (frozen/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));sys.exit()
pair=json.loads((root/'run/custom-emote-pair-artifacts-1-20261128/result.json').read_text());assert pair['status']=='VERIFIED'
replicas=json.loads((root/'run/custom-emote-replicas-1-20261128/result.json').read_text());assert replicas['status']=='VERIFIED'
files={}
folders=[('validation',attempt),('replicas','custom-emote-replicas-1-20261128'),('pair','custom-emote-pair-artifacts-1-20261128'),('frozen',frozen.name)]
for previous in sorted((root/'run').glob('native-custom-emote-focused-*-20261128')):
    if previous.name!=attempt:folders.append(('prior-'+previous.name,previous.name))
for label,name in folders:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class','.mdmp'):files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','tools/verify-custom-emote-recovery.py','tools/CustomEmoteRecoveryProbe.java','tools/CustomEmoteLegacyProbe.java','run/validate-custom-emote-20261128.py','run/finalize-custom-emote-20261128.py','run/custom-emote-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:sha(path) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],'artifacts':json.loads((frozen/'manifest.json').read_text()),'fixtures_compiled':pair['fixtures']['count'],'replica_jvms':len(replicas['runs']),
    'limits':['Related tests only, not full StarCore regression. No Minecraft/Paper/Folia server, deployment or client acceptance.',
      'Complete custom emote state commits before publication; old bytes are retained, stale or incomplete authority is blocked. Returned custom models are detached; setters do not persist changes. Use manager update/import APIs.',
      'Legacy documents omitted createdAt and metadata. Unknown old creation time remains zero and missing metadata cannot be reconstructed. File locking coordinates cooperative writers; directory forcing is unavailable on Windows and hardware power-loss durability is not claimed.',
      'Commands capture original player identity and administrator authority on the owner, use bounded I/O for persistent mutation, and reject closed or reconnected unstarted operations. An admitted operation may finish after disconnect; no automatic retry occurs.',
      'Legacy ChangeListener remains a post-commit notification; callback failure does not roll back committed state. The production module uses the explicit checkpoint store.',
      'Menu pagination/session snapshots, main chat, activity/alliance/culture, other actual legacy schedulers and later phases remain source work.']}
out=root/'docs/verification/custom-emote-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=sha(out),files=manifest)
(root/'docs/verification/custom-emote-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))

