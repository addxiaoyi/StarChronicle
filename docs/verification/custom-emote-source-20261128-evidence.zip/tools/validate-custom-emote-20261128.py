import json
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
prior=json.loads((root/'run/native-emote-owner-focused-2-20261128/result.json').read_text());args=prior['args']
base=args[:next(i for i,x in enumerate(args) if x.startswith('-Dtest='))]
if sys.argv[1]=='format':
    log=root/'run/custom-emote-format-20261128.log'
    with log.open('w',encoding='utf-8') as out:result=subprocess.run(base+['-Dspotless.ratchetFrom=HEAD','spotless:apply'],cwd=native,stdout=out,stderr=subprocess.STDOUT)
    print(log.read_text(encoding='utf-8',errors='replace')[-1000:]);sys.exit(result.returncode)
command=[sys.executable,str(root/'tools/snapshot-maven-validation.py'),'--repo',str(native),'--output',str(root/'run'/sys.argv[1]),
    '--java-home',str(Path(args[0]).parents[1]),'--maven-home',next(x.split('=',1)[1] for x in args if x.startswith('-Dmaven.home=')),
    '--heap','320m','--metaspace','192m','--java-agent',next(x.split(':',1)[1] for x in args if x.startswith('-javaagent:'))]
extra=['CustomEmotePersistenceTest','CustomEmoteCommandTest']
command+=['--reuse-snapshot',str(root/'run/native-emote-owner-focused-2-20261128')]
for suite in prior['required_suites']+extra:command+=['--require-suite',suite]
pattern=next(x for x in args if x.startswith('-Dtest='))+','+','.join(extra)
command+=['--','-o','-DforkCount=0','-Djacoco.skip=true',pattern,'verify']
sys.exit(subprocess.call(command,cwd=root))
