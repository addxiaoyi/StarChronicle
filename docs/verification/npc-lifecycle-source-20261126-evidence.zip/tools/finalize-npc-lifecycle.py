from pathlib import Path
import hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
def add(path, name): files[name] = path.read_bytes()
counts = {}
for phase in ('baseline', 'baseline-corrected', 'targeted', 'full'):
    directory = root / 'run' / f'npc-lifecycle-{phase}-20261126'
    summary = json.loads((directory/'result.json').read_text())
    counts[phase] = summary['totals']
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.xml', '.java'):
            add(path, phase + '/' + path.relative_to(directory).as_posix())
assert counts['full'] == dict(tests=1010, failures=0, errors=0, skipped=0)
assert counts['baseline-corrected'] == dict(tests=33, failures=26, errors=0, skipped=0)
changed = subprocess.check_output(['git','diff','--name-only','-z'],cwd=root).decode().split('\0')
untracked = subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
sources = {}
for name in sorted(set(changed + untracked)):
    if name.startswith('src/') and (root/name).is_file():
        add(root/name, 'source/'+name); sources[name] = sha((root/name).read_bytes())
for name in ('pom.xml','mvnw.cmd','tools/verification_report.py','docs/NPC-INTEGRATIONS.md','docs/TEST-REPORT.md'):
    add(root/name, 'project/'+name)
add(root/'run/run-npc-lifecycle.py', 'tools/run-npc-lifecycle.py')
add(Path(__file__), 'tools/finalize-npc-lifecycle.py')
artifacts = {
    'starchronicle_sha256':sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes()),
    'sources_sha256':sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes()),
    'starcore_sha256':sha((native/'target/starcore-1.0.0.jar').read_bytes())}
assert artifacts['starcore_sha256']=='928637205bffa395a52781eade913650e767c551a04b5f1a78a6a3e86183e87b'
summary = {'date':'2026-11-26', 'scope':'NPC provider-instance lifecycle, captured player admission, observed timestamps and owned memory-site observations; source and unit tests only.',
    'baseline_commits':{'chronicle':'1c4acc06f2db299247f22b542d13037c158a3107','starcore':'b048071df580a6919e37971d340b4abd681f46d1'},
    'tests':counts,'new_tests':53,'source_hashes':sources,'artifacts':artifacts,
    'limits':['No Minecraft or actual third-party/protection-plugin execution.',
              'API-shaped test doubles do not certify specific provider binaries.',
              'Local full verify used one 256 MiB JVM, forkCount=0 and jacoco.skip=true; no local coverage result.',
              'An already admitted observation may finish after disable; committed history is not rolled back.',
              'This is not a durable provider outbox; pre-admission loss and interactions while disabled cannot be recovered.',
              'StarCore source and JAR are unchanged; the previous 1558 focused regression result is retained, not rerun or relabeled as a full native suite.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/npc-lifecycle-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in sorted(files.items()): archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
    manifest=json.loads(archive.read('manifest.json'))
    assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
    for name,digest in manifest['files'].items(): assert sha(archive.read(name))==digest
summary['evidence_zip_sha256']=sha(output.read_bytes()); summary['evidence_files']=len(files)
(output.parent/'npc-lifecycle-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# NPC 桥接生命周期与玩家会话：源码验证 2026-11-26

FancyNpcs、Citizens、Adyeshach 的旧监听器在禁用后可能继续回调；重载只按名字移除监听会误伤同名新实例。旧交互入口只保存 UUID，重新登录后可能把旧点击归到新会话上下文。本次修复这三类边界，并将纪念点老兵接入相同的观察入口。

## 当前构件与范围

| 构件 | SHA-256 |
| --- | --- |
| Chronicle 插件 | `{artifacts['starchronicle_sha256']}` |
| Chronicle 源码 | `{artifacts['sources_sha256']}` |
| 配套 StarCore，源码及构件未变 | `{artifacts['starcore_sha256']}` |
| 本轮证据 ZIP | `{summary['evidence_zip_sha256']}` |

从 Chronicle `1c4acc0` 和 StarCore `b048071d` 续接同一分支 `codex/plugin-all-stages-20261125`，保持草稿 PR #2／#3。证据包 **{len(files)} 个文件**：[ZIP](verification/npc-lifecycle-source-20261126-evidence.zip)、[机器摘要](verification/npc-lifecycle-source-20261126-summary.json)。本轮没有启动 Minecraft。

## 交互与关闭边界

- `start` 幂等、`close` 终止；按实际 Plugin 实例安装／失效监听。旧实例的迟到 disable 不移除新实例。禁用／重载后旧观察不能再次有效；单个注册失败清理残留，其他提供者继续安装。
- API 只从当前提供者的 ClassLoader 加载。MONITOR、ignoreCancelled 和回调内部取消复核保持，稳定身份限定为非空 String 或 UUID、最多 256 字符。null、任意对象和超长身份不进入历史；不操作第三方 NPC 实体。
- 桥接保留事件中的确切 Player 和观察时间。实体调度执行前发生离线或重连则拒绝，不读取替代实体；`starchronicle.use` 必需，只有 admin 权限也不能绕过。
- 在原玩家实体上取得的不可变上下文继续用于该事件，其他受众快照不再重取参与者。历史 `npc.id` 是逻辑档案，`npc.binding` 是来源稳定绑定，新增 `time_basis=OBSERVED`；旧历史不迁移或改写。
- 工作线程在调用规则引擎前再核对提供者失效和关服标志。此前已进入处理的观察可以完成，已提交历史不会因禁用回滚。单个事件被成功入库前仍无第三方持久 outbox，不能声称停用期间完整历史或端到端严格一次。
- 纪念点保留原事件 Player；配置刷新和关闭使旧观察失效，重新启用不会恢复旧观察。原 UUID 双参数回调构造器保留，使用它的外部调用者自行管理后续排队语义。

## 实际验证与保留失败

| 运行 | 测试 | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现初次夹具 | 33 | 10 | 13 | 0 |
| 补齐 Bukkit 测试线程环境，生产实现仍未修复 | 33 | 26 | 0 | 0 |
| 修复后的第一轮相关回归 | 102 | 0 | 0 | 0 |
| 最终完整 clean verify | 1,010 | 0 | 0 | 0 |

新增 **53 项**：NPC 桥接 37、生产观察入口 15、纪念点 1。三种第三方事件是明确标注的 API 形状测试替身，真实 Bukkit RegisteredListener／HandlerList 验证注册和取消；真实 RegionTasks 配合排队回调核对重连、关闭、权限、满队列、原时间与原上下文。缺少可选 API 的隔离 ClassLoader 不借用其他插件类。

初次夹具的 13 errors 来自 PluginEnable/DisableEvent 需要 Bukkit.isPrimaryThread 测试环境，不能算产品缺陷；补齐后得到 26 个真实断言失败。全部原始日志、XML 和旧源码保留在证据 ZIP。启动脚本最初有 Python Windows 路径转义语法错误，在启动 Java 前修正；该错误不计入测试结果。

最终使用单个 256 MiB 堆 JVM，命令为 `mvnw.cmd -o -B -ntp -DforkCount=0 -Djacoco.skip=true clean verify`，带 Mockito agent。插件入口 Java 21、全部主源码与源码 JAR、全部资源与插件 JAR 均通过逐项校验。发布 JAR 不包含 Bukkit、StarCore 或三种 NPC 夹具类；本机没有新增 JaCoCo 结果。完整报告见 [TEST-REPORT](TEST-REPORT.md)。

StarCore 本轮未改动；此前 1,558 项相关回归及国库／贸易／工厂契约按其原始 Chronicle 构件保存，不改称当前新 Chronicle 的再次实测。

## 剩余工作

第 8 阶段仍需要真实 NPC／领地保护版本组合的启停、事件顺序、客户端交互与区域线程验收。MONITOR 只证明当时观察到的取消状态，不替代实际保护插件行为。第 7 阶段 StarCore 全栈 Folia、其余当前构件实服流程、第三方持久来源、旧来源核对、长期压力与容量边界仍未完成。按用户选择继续源码与单元测试，不申请启动实服。
'''
(root/'docs/NPC-LIFECYCLE-SOURCE-20261126.md').write_text(report,encoding='utf-8')
checkpoint='2026-11-26 最新检查点：[NPC 生命周期与玩家会话](NPC-LIFECYCLE-SOURCE-20261126.md)。三种 NPC 桥接按实际插件实例失效，关闭后旧回调／观察不复活；原玩家实体、观察时间和上下文保留，纪念点接入同一路径。新增 53 项，Chronicle 1,010 项完整回归通过，当前 JAR `e020c1ad…964f23`。StarCore 保持 `92863720…83e87b`；原始 26 项失败证据保留。实际 NPC／保护组合与全栈 Folia 继续待验，不启动 Minecraft。'
for name in ('docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md'):
    path=root/name; text=path.read_text(encoding='utf-8'); heading,body=text.split('\n',1)
    path.write_text(heading+'\n\n'+checkpoint+'\n'+body,encoding='utf-8')
path=root/'README.md'; text=path.read_text(encoding='utf-8'); heading,body=text.split('\n',1)
path.write_text(heading+'\n\n'+checkpoint.replace('(NPC-LIFECYCLE-SOURCE-20261126.md)','(docs/NPC-LIFECYCLE-SOURCE-20261126.md)')+'\n'+body,encoding='utf-8')
path=root/'docs/HANDOFF-2026-11-25.md'; text=path.read_text(encoding='utf-8')
text=text.replace('NPC／保护钩子与边界已实现；按用户选择沿用仓库 Paper/Folia 1.21.11 与配套 StarCore 测试组合',
    'NPC／保护钩子已有；三种 NPC 插件实例失效、原玩家会话与观察时间已加固，新增 53 项、Chronicle 1,010 项完整测试通过；沿用仓库 Paper/Folia 1.21.11 与配套 StarCore 测试组合')
path.write_text(text,encoding='utf-8')
print(json.dumps({'tests':counts,'artifacts':artifacts,'evidence_files':len(files),'zip_sha256':summary['evidence_zip_sha256']}))
