package dev.starcore.starcore.essentials.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Answers;
import org.mockito.MockedStatic;

class EconomyRemainingOwnershipTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final Map<UUID, Player> online = new LinkedHashMap<>();
  private final Map<Player, State> states = new IdentityHashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private final List<String> consoleMessages = new ArrayList<>();
  private Player owner, sender, target;
  private String mode = "caller";
  private EconomyService economy;
  private FoliaCompatScheduler scheduler;
  private EconomyCommand command;
  private MockedStatic<Bukkit> bukkit;
  private int reads, changes;
  private boolean active = true;

  private static final class State {
    UUID id;
    String name;
    boolean permitted = true;
    final List<String> messages = new ArrayList<>();
  }

  private record Job(String mode, Player owner, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() {
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(plugin.getServer()).thenReturn(server);
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOnlinePlayers()).thenAnswer(i -> List.copyOf(online.values()));
    scheduler =
        mock(
            FoliaCompatScheduler.class,
            i -> {
              String name = i.getMethod().getName();
              if (name.equals("runAtEntity")) {
                jobs.add(
                    new Job(
                        "owner",
                        i.getArgument(0),
                        () -> i.<Consumer<Object>>getArgument(1).accept(null),
                        i.getArguments().length == 3 ? i.getArgument(2) : () -> {}));
              } else if (name.equals("runAsync") || name.equals("runGlobal")) {
                jobs.add(
                    new Job(
                        name.equals("runAsync") ? "async" : "global",
                        null,
                        i.getArgument(0),
                        () -> {}));
              } else if (name.equals("runAtLocation")) {
                jobs.add(
                    new Job(
                        "region",
                        null,
                        () -> i.<Consumer<Object>>getArgument(1).accept(null),
                        () -> {}));
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    economy =
        mock(
            InternalEconomyService.class,
            i -> {
              String name = i.getMethod().getName();
              if (Set.of("getBalance", "deposit", "withdraw", "setBalance").contains(name)) {
                assertEquals("async", mode, "built-in economy called from " + mode);
                if (name.equals("getBalance")) {
                  reads++;
                  return BigDecimal.TEN;
                }
                changes++;
                return true;
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    command =
        new EconomyCommand(
            plugin,
            economy,
            new BalTopService(),
            null,
            scheduler,
            EssentialsPermissions.defaults(),
            () -> active);
    sender = player("Sender", UUID.randomUUID());
    target = player("Target", UUID.randomUUID());
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(() -> Bukkit.getPlayer("Target")).thenReturn(target);
    bukkit.when(() -> Bukkit.getPlayer("Sender")).thenReturn(sender);
    bukkit.when(Bukkit::getOnlinePlayers).thenAnswer(i -> List.copyOf(online.values()));
  }

  @AfterEach
  void cleanup() {
    bukkit.close();
  }

  private Player player(String name, UUID id) {
    State state = new State();
    state.id = id;
    state.name = name;
    Player result =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (Set.of("getName", "isOnline", "getServer", "sendMessage", "hasPermission")
                  .contains(method)) {
                assertSame(i.getMock(), owner, "foreign player " + name + "." + method);
                return switch (method) {
                  case "getName" -> name;
                  case "isOnline" -> true;
                  case "getServer" -> server;
                  case "hasPermission" -> state.permitted;
                  default -> {
                    state.messages.add(text(i.getArgument(0)));
                    yield null;
                  }
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    states.put(result, state);
    online.put(id, result);
    return result;
  }

  private static String text(Object message) {
    return message instanceof Component c
        ? PlainTextComponentSerializer.plainText().serialize(c)
        : String.valueOf(message);
  }

  private void owned(Player player, Runnable action) {
    run(new Job("owner", player, action, () -> {}));
  }

  private void run(Job job) {
    Player previous = owner;
    String oldMode = mode;
    owner = job.owner;
    mode = job.mode;
    try {
      job.body.run();
    } finally {
      owner = previous;
      mode = oldMode;
    }
  }

  private void drain() {
    int remaining = 100;
    while (!jobs.isEmpty()) {
      assertTrue(remaining-- > 0);
      run(jobs.remove());
    }
  }

  private Command named(String name) {
    Command c = mock(Command.class);
    when(c.getName()).thenReturn(name);
    return c;
  }

  private void invoke(CommandSender audience, String name, String... args) {
    Command c = named(name);
    if (audience instanceof Player player)
      owned(player, () -> command.onCommand(audience, c, name, args));
    else command.onCommand(audience, c, name, args);
  }

  private List<String> complete(String name, String... args) {
    List<List<String>> result = new ArrayList<>();
    Command c = named(name);
    owned(sender, () -> result.add(command.onTabComplete(sender, c, name, args)));
    return result.getFirst();
  }

  private CommandSender console() {
    return mock(
        CommandSender.class,
        i -> {
          if (i.getMethod().getName().equals("hasPermission")) return true;
          if (i.getMethod().getName().equals("sendMessage")) {
            assertEquals("global", mode);
            consoleMessages.add(text(i.getArgument(0)));
            return null;
          }
          return Answers.RETURNS_DEFAULTS.answer(i);
        });
  }

  @Test
  void otherBalanceUsesTargetOwnerThenAsyncReadAndOriginalSenderReply() {
    invoke(sender, "balance", "Target");
    assertEquals(0, reads);
    drain();
    assertEquals(1, reads);
    assertTrue(
        states.get(sender).messages.stream()
            .anyMatch(s -> s.contains("Target") && s.contains("10.00")));
  }

  @Test
  void ownBalanceDoesNotReadEconomyOnEntityThread() {
    invoke(sender, "balance");
    assertEquals(0, reads);
    drain();
    assertEquals(1, reads);
  }

  @Test
  void targetReconnectBeforeNameCaptureDoesNotRunBalanceRead() {
    invoke(sender, "balance", "Target");
    player("Replacement", states.get(target).id);
    drain();
    assertEquals(0, reads);
  }

  @Test
  void senderReconnectBeforeFinalAdmissionDoesNotRunBalanceRead() {
    invoke(sender, "balance", "Target");
    player("Replacement", states.get(sender).id);
    drain();
    assertEquals(0, reads);
  }

  @Test
  void consoleBalanceRunsQueryOffThreadAndReplyGlobally() {
    invoke(console(), "balance", "Target");
    drain();
    assertEquals(1, reads);
    assertEquals(1, consoleMessages.size());
  }

  @ParameterizedTest
  @ValueSource(strings = {"give", "take", "set"})
  void adminActionsUseAsyncAccountsAndOriginalSender(String action) {
    invoke(sender, "eco", action, "Target", "5");
    assertEquals(0, changes);
    drain();
    assertEquals(1, changes);
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("Target")));
  }

  @Test
  void revokedAdminPermissionBeforeFinalAdmissionPreventsMutation() {
    invoke(sender, "eco", "give", "Target", "5");
    run(jobs.remove());
    states.get(sender).permitted = false;
    drain();
    assertEquals(0, changes);
  }

  @Test
  void negativeAdminAmountIsRejectedBeforeAnyProviderCall() {
    invoke(sender, "eco", "set", "Target", "-5");
    drain();
    assertEquals(0, changes);
    assertEquals(0, reads);
  }

  @Test
  void unknownAdminActionProducesOneClearResponse() {
    invoke(sender, "eco", "mystery", "Target", "5");
    drain();
    assertEquals(0, changes);
    assertEquals(1, states.get(sender).messages.size());
  }

  @Test
  void committedAdminActionDoesNotBecomeFailureWhenBalanceReadFails() {
    doThrow(new IllegalStateException("read unavailable")).when(economy).getBalance(any());
    invoke(sender, "eco", "give", "Target", "5");
    drain();
    assertEquals(1, changes);
    assertTrue(
        states.get(sender).messages.stream().anyMatch(s -> s.contains("已提交") && s.contains("余额")));
  }

  @Test
  void providerMutationExceptionIsUncertainAndIsNeverRetried() {
    doAnswer(
            i -> {
              assertEquals("async", mode);
              changes++;
              throw new IllegalStateException("lost response");
            })
        .when(economy)
        .deposit(any(), any());
    invoke(sender, "eco", "give", "Target", "5");
    drain();
    assertEquals(1, changes);
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("无法确认")));
  }

  @Test
  void stoppedModuleCannotStartQueuedAdminAction() {
    invoke(sender, "eco", "give", "Target", "5");
    active = false;
    drain();
    assertEquals(0, changes);
  }

  @Test
  void nameCompletionReadsCapturedNamesWithoutForeignEntityAccess() {
    complete("pay", "Ta");
    drain();
    assertEquals(List.of("Target"), complete("pay", "Ta"));
  }

  @Test
  void adminCompletionRespectsPermissionBeforeExposingNames() {
    states.get(sender).permitted = false;
    assertEquals(List.of(), complete("eco", "give", ""));
  }

  @Test
  void economyAliasCompletesActionsUsingTheTypedPrefix() {
    assertEquals(List.of("give"), complete("economy", "g"));
  }

  @Test
  void externalPaperPayUsesProviderGlobalThread() {
    EconomyService external = mock(EconomyService.class);
    when(external.has(any(), any()))
        .thenAnswer(
            i -> {
              assertEquals("global", mode);
              return true;
            });
    when(external.transfer(any(), any(), any()))
        .thenAnswer(
            i -> {
              assertEquals("global", mode);
              changes++;
              return true;
            });
    command = new EconomyCommand(plugin, external, new BalTopService(), null, scheduler);
    invoke(sender, "pay", "Target", "5");
    drain();
    assertEquals(1, changes);
  }

  @Test
  void foliaAdminDoesNotInvokeAnUnverifiedExternalProvider() {
    EconomyService external = mock(EconomyService.class);
    when(scheduler.isFolia()).thenReturn(true);
    command = new EconomyCommand(plugin, external, new BalTopService(), null, scheduler);
    invoke(sender, "eco", "give", "Target", "5");
    drain();
    verifyNoInteractions(external);
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("不可用")));
  }

  @Test
  void zeroIsAcceptedForSetBalance() {
    invoke(sender, "eco", "set", "Target", "0");
    drain();
    assertEquals(1, changes);
    verify(economy).setBalance(states.get(target).id, BigDecimal.ZERO);
  }

  @Test
  void consoleCanAdministerAnAccountWithGlobalFeedback() {
    invoke(console(), "eco", "give", "Target", "5");
    drain();
    assertEquals(1, changes);
    assertEquals(1, consoleMessages.size());
  }

  @Test
  void permissionRevocationAlsoProtectsOtherPlayerBalanceQueries() {
    invoke(sender, "balance", "Target");
    run(jobs.remove());
    states.get(sender).permitted = false;
    drain();
    assertEquals(0, reads);
  }

  @Test
  void providerCallbackReplayCannotRepeatAnAdminMutation() {
    invoke(sender, "eco", "give", "Target", "5");
    while (!jobs.isEmpty() && !jobs.peek().mode.equals("async")) run(jobs.remove());
    Job operation = jobs.remove();
    run(operation);
    run(operation);
    drain();
    assertEquals(1, changes);
  }

  @Test
  void lateRegisteredProviderCallbackCannotExecuteAfterRegistrationFailure() {
    doAnswer(
            i -> {
              jobs.add(new Job("async", null, i.getArgument(0), () -> {}));
              throw new IllegalStateException("late registration failure");
            })
        .when(scheduler)
        .runAsync(any());
    invoke(sender, "eco", "give", "Target", "5");
    drain();
    assertEquals(0, changes);
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("不可用")));
  }

  @Test
  void senderReconnectAfterMutationSuppressesOnlyItsFeedback() {
    invoke(sender, "eco", "give", "Target", "5");
    while (!jobs.isEmpty() && !jobs.peek().mode.equals("async")) run(jobs.remove());
    run(jobs.remove());
    player("Replacement", states.get(sender).id);
    drain();
    assertEquals(1, changes);
    assertTrue(states.get(sender).messages.isEmpty());
  }

  @Test
  void externalPaperBalancePreservesProviderMainThreadContract() {
    EconomyService external = mock(EconomyService.class);
    when(external.getBalance(any()))
        .thenAnswer(
            i -> {
              assertEquals("global", mode);
              reads++;
              return BigDecimal.TEN;
            });
    command = new EconomyCommand(plugin, external, new BalTopService(), null, scheduler);
    invoke(sender, "balance", "Target");
    drain();
    assertEquals(1, reads);
  }

  @Test
  void commandBlockBalanceReplyUsesItsRegion() {
    org.bukkit.block.Block block = mock(org.bukkit.block.Block.class);
    when(block.getLocation()).thenReturn(new Location(mock(World.class), 1, 65, 2));
    BlockCommandSender blockSender = mock(BlockCommandSender.class);
    when(blockSender.getBlock()).thenReturn(block);
    when(blockSender.hasPermission(anyString())).thenReturn(true);
    doAnswer(
            i -> {
              assertEquals("region", mode);
              return null;
            })
        .when(blockSender)
        .sendMessage(any(Component.class));
    invoke(blockSender, "balance", "Target");
    drain();
    verify(blockSender).sendMessage(any(Component.class));
  }
}
