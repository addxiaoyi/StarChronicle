package dev.starcore.starcore.essentials.player;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.Answers;

class PlayerNameDirectoryTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final Map<UUID, Player> online = new LinkedHashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private Player owner, player;
  private FoliaCompatScheduler scheduler;
  private PlayerNameDirectory directory;
  private boolean active = true, rejected;
  private int nameReads;

  private record Job(Player player, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOnlinePlayers()).thenAnswer(i -> List.copyOf(online.values()));
    scheduler = mock(FoliaCompatScheduler.class);
    doAnswer(
            i -> {
              if (rejected) throw new IllegalStateException("registration rejected");
              jobs.add(
                  new Job(
                      i.getArgument(0),
                      () -> i.<Consumer<Object>>getArgument(1).accept(null),
                      i.getArgument(2)));
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(), any(), any());
    directory = new PlayerNameDirectory(plugin, scheduler, () -> active);
    player = player("Target", UUID.randomUUID());
  }

  private Player player(String name, UUID id) {
    Player value =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (Set.of("getName", "isOnline", "getServer").contains(method)) {
                assertSame(i.getMock(), owner, "name directory read on wrong owner");
                return switch (method) {
                  case "getName" -> {
                    nameReads++;
                    yield name;
                  }
                  case "getServer" -> server;
                  default -> true;
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    online.put(id, value);
    return value;
  }

  private void owned(Player value, Runnable body) {
    Player previous = owner;
    owner = value;
    try {
      body.run();
    } finally {
      owner = previous;
    }
  }

  private void drain() {
    while (!jobs.isEmpty()) {
      Job job = jobs.remove();
      owned(job.player, job.body);
    }
  }

  @Test
  void refreshCapturesNamesOnlyOnTheirOwners() {
    directory.refresh();
    assertEquals(0, nameReads);
    assertEquals(List.of(), directory.names(null, ""));
    drain();
    assertEquals(List.of("Target"), directory.names(null, "tA"));
  }

  @Test
  void repeatedRefreshHasOnePendingCapturePerUuid() {
    directory.refresh();
    directory.refresh();
    assertEquals(1, jobs.size());
    drain();
    directory.refresh();
    assertTrue(jobs.isEmpty());
  }

  @Test
  void joinObservationIsImmediatelyAvailable() {
    owned(player, () -> directory.observe(player));
    assertEquals(List.of("Target"), directory.names(null, ""));
  }

  @Test
  void previousSessionCaptureCannotOverwriteAJoin() {
    directory.refresh();
    Player replacement = player("Replacement", player.getUniqueId());
    owned(replacement, () -> directory.observe(replacement));
    drain();
    assertEquals(List.of("Replacement"), directory.names(null, ""));
  }

  @Test
  void oldQuitPreservesTheNewSessionName() {
    Player replacement = player("Replacement", player.getUniqueId());
    owned(replacement, () -> directory.observe(replacement));
    directory.forget(player);
    assertEquals(List.of("Replacement"), directory.names(null, ""));
  }

  @Test
  void quitInvalidatesAnAlreadyQueuedCapture() {
    directory.refresh();
    directory.forget(player);
    drain();
    assertEquals(0, nameReads);
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void closeInvalidatesQueuedWorkAndFutureRefresh() {
    directory.refresh();
    directory.close();
    drain();
    directory.refresh();
    assertTrue(jobs.isEmpty());
    assertEquals(0, nameReads);
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void disabledLifetimeCannotCaptureOrReturnNames() {
    directory.refresh();
    active = false;
    drain();
    assertEquals(0, nameReads);
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void rejectedRegistrationReleasesThePendingSlot() {
    rejected = true;
    assertDoesNotThrow(directory::refresh);
    rejected = false;
    directory.refresh();
    assertEquals(1, jobs.size());
    drain();
    assertEquals(List.of("Target"), directory.names(null, ""));
  }

  @Test
  void retirementReleasesThePendingSlot() {
    directory.refresh();
    Job retired = jobs.remove();
    retired.retired.run();
    directory.refresh();
    drain();
    owned(retired.player, retired.body);
    assertEquals(1, nameReads);
    assertEquals(List.of("Target"), directory.names(null, ""));
  }

  @Test
  void failedNameCaptureReleasesThePendingSlot() {
    doThrow(new IllegalStateException("unavailable"))
        .doAnswer(i -> "Recovered")
        .when(player)
        .getName();
    directory.refresh();
    assertDoesNotThrow(this::drain);
    directory.refresh();
    drain();
    assertEquals(List.of("Recovered"), directory.names(null, ""));
  }

  @Test
  void offlinePlayerIsNeverReadForItsName() {
    doReturn(false).when(player).isOnline();
    directory.refresh();
    drain();
    assertEquals(0, nameReads);
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void replacementDuringNameReadCannotStoreTheOldSession() {
    UUID id = player.getUniqueId();
    doAnswer(
            i -> {
              player("Replacement", id);
              return "Stale";
            })
        .when(player)
        .getName();
    directory.refresh();
    drain();
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void missedQuitIsPrunedByCurrentServerIdentity() {
    owned(player, () -> directory.observe(player));
    online.clear();
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void enumerationFailureAllowsALaterRefresh() {
    doThrow(new IllegalStateException("enumeration unavailable"))
        .doAnswer(i -> List.copyOf(online.values()))
        .when(server)
        .getOnlinePlayers();
    assertDoesNotThrow(directory::refresh);
    directory.refresh();
    drain();
    assertEquals(List.of("Target"), directory.names(null, ""));
  }

  @Test
  void snapshotIsImmutableSortedAndExcludesTheRequestedUuid() {
    Player alpha = player("alpha", UUID.randomUUID());
    directory.refresh();
    drain();
    List<String> snapshot = directory.names(null, "");
    assertEquals(List.of("alpha", "Target"), snapshot);
    assertThrows(UnsupportedOperationException.class, () -> snapshot.add("Injected"));
    assertEquals(List.of("Target"), directory.names(alpha.getUniqueId(), ""));
    directory.forget(player);
    assertEquals(List.of("alpha", "Target"), snapshot);
  }

  @Test
  void closeDuringNameReadCannotRepopulateTheDirectory() {
    doAnswer(
            i -> {
              directory.close();
              return "TooLate";
            })
        .when(player)
        .getName();
    directory.refresh();
    drain();
    assertEquals(List.of(), directory.names(null, ""));
  }

  @Test
  void obsoleteCaptureCannotRemoveANewerPendingAttemptForTheSamePlayer() {
    directory.refresh();
    Job old = jobs.remove();
    directory.forget(player);
    directory.refresh();
    owned(old.player, old.body);
    directory.refresh();
    assertEquals(1, jobs.size());
    drain();
    assertEquals(List.of("Target"), directory.names(null, ""));
  }
}
