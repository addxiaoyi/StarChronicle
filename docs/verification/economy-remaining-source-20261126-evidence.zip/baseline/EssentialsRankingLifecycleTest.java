package dev.starcore.starcore.essentials;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.data.EssentialsDataManager;
import dev.starcore.starcore.foundation.economy.*;
import dev.starcore.starcore.foundation.message.MessageService;
import java.math.BigDecimal;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.MockedConstruction;

class EssentialsRankingLifecycleTest {
  private final Plugin plugin = mock(Plugin.class, RETURNS_DEEP_STUBS);
  private final StarCoreContext context = mock(StarCoreContext.class, RETURNS_DEEP_STUBS);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final List<Runnable> timers = new ArrayList<>();
  private final Deque<Runnable> work = new ArrayDeque<>();
  private MockedConstruction<EssentialsDataManager> managers;
  private boolean async;

  @BeforeEach void setup() {
    when(plugin.getName()).thenReturn("StarCore"); when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(context.configuration().getConfig()).thenReturn(new YamlConfiguration());
    doAnswer(i -> { timers.add(i.getArgument(0)); return null; }).when(scheduler).runGlobalRepeating(any(), anyLong(), anyLong());
    doAnswer(i -> { work.add(i.getArgument(0)); return null; }).when(scheduler).runAsync(any());
    managers = mockConstruction(EssentialsDataManager.class);
  }

  @AfterEach void cleanup() { managers.close(); }

  private EssentialsModule module(EconomyService economy) {
    EssentialsModule result = new EssentialsModule(plugin, scheduler, mock(MessageService.class), economy);
    result.enable(context); return result;
  }

  private void drain() { async = true; try { while (!work.isEmpty()) work.remove().run(); } finally { async = false; } }

  @Test void nativePeriodicRefreshRunsOffGlobalAndAllowsOnlyOneQueuedRead() {
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.getAllBalances()).thenAnswer(i -> { assertTrue(async); return Map.of(UUID.randomUUID(), BigDecimal.TEN); });
    EssentialsModule module = module(economy);
    timers.get(1).run(); timers.get(1).run(); assertEquals(1, work.size()); verify(economy, never()).getAllBalances();
    drain(); assertEquals(1, module.getBalTopService().size());
    timers.get(1).run(); assertEquals(1, work.size()); module.disable(context); drain(); verify(economy).getAllBalances();
  }

  @Test void externalFoliaTimerNeverInvokesProvider() {
    EconomyService economy = mock(EconomyService.class); when(scheduler.isFolia()).thenReturn(true);
    EssentialsModule module = module(economy); timers.get(1).run(); timers.get(1).run(); drain();
    verifyNoInteractions(economy); module.disable(context);
  }

  @Test void failedRefreshReleasesItsSlotForTheNextPeriod() {
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.getAllBalances()).thenAnswer(i -> { assertTrue(async); throw new IllegalStateException("snapshot unavailable"); });
    EssentialsModule module = module(economy);
    timers.get(1).run(); assertDoesNotThrow(this::drain);
    timers.get(1).run(); assertEquals(1, work.size()); assertDoesNotThrow(this::drain);
    verify(economy, times(2)).getAllBalances(); module.disable(context);
  }
}
