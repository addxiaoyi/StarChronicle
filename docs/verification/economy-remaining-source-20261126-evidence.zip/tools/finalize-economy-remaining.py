from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest();files={};runs={}
def add(path,name):files[name]=path.read_bytes()
for phase in ('baseline','compile','test-initial','compile-final','test-final','package','sbom','artifacts'):
 directory=root/'run'/('economy-remaining-'+phase+'-20261126')
 runs[phase]=json.loads((directory/'result.json').read_text(encoding='utf-8'))
 for path in sorted(directory.rglob('*')):
  if path.is_file() and path.suffix in ('.json','.xml','.java','.log','.txt'):add(path,phase+'/'+path.relative_to(directory).as_posix())
 if phase!='baseline':assert runs[phase].get('exit_code',0)==0,phase
totals=dict(tests=0,failures=0,errors=0,skipped=0);groups={'scheduler_and_essentials':0,'foundation_economy':0}
for path in (root/'run/economy-remaining-test-final-20261126/surefire').glob('*.xml'):
 suite=ET.parse(path).getroot()
 for key in totals:totals[key]+=int(suite.get(key,0))
 groups['foundation_economy' if '.foundation.economy.' in suite.get('name') else 'scheduler_and_essentials']+=int(suite.get('tests'))
assert totals==runs['test-final']['totals']==dict(tests=484,failures=0,errors=0,skipped=0)
assert groups=={'scheduler_and_essentials':441,'foundation_economy':43}
assert runs['baseline']['totals']==dict(tests=22,failures=22,errors=0,skipped=0)
assert runs['test-initial']['totals']==dict(tests=482,failures=0,errors=0,skipped=0)
names=['src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java',
 'src/main/java/dev/starcore/starcore/essentials/command/EconomyCommand.java',
 'src/main/java/dev/starcore/starcore/essentials/player/PlayerNameDirectory.java',
 'src/test/java/dev/starcore/starcore/essentials/command/EconomyRemainingOwnershipTest.java',
 'src/test/java/dev/starcore/starcore/essentials/command/EconomyCommandThreadingTest.java',
 'src/test/java/dev/starcore/starcore/essentials/EssentialsRankingLifecycleTest.java',
 'src/test/java/dev/starcore/starcore/essentials/player/PlayerNameDirectoryTest.java',
 'docs/ECONOMY-ACCOUNT-LIFECYCLE.md','docs/ECONOMY-COMMAND-OWNERSHIP.md']
for name in names+['pom.xml','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties']:add(native/name,'starcore/'+name)
for name in ('starcore-1.0.0-sbom.json','starcore-1.0.0-sbom.xml'):add(native/'target'/name,'sbom/'+name)
for name in ('run-economy-remaining.py','verify-economy-remaining-artifacts.py','finalize-economy-remaining.py'):add(root/'run'/name,'tools/'+name)
for name in ('economy-owner-ci-success-20261126.log','economy-owner-final-ci-20261126.json','economy-owner-delivery-git-20261126.json'):add(root/'run'/name,'previous-economy-ci/'+name)
files['starcore/change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=native)
plugin=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
sources=sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes())
core=sha((native/'target/starcore-1.0.0.jar').read_bytes())
assert core==runs['artifacts']['starcore_sha256']
assert plugin=='1c7b8b010c9d330c15b0882753d54095fb906e42caedb926a81055d643cd78ce'
summary={'date':'2026-11-26','scope':'Remaining Essentials balance/admin ownership, provider routing, original-session name directory/completion, and periodic ranking admission/lifetime. No Minecraft.',
 'baseline_commits':{'starchronicle':'2d1510ccfd61a5a95c24e2b74f05f501e33ada6c','starcore':'6c8decfd93b83474fa039882712f6284e1b1fec2'},
 'new_tests':52,'new_test_groups':{'account_commands':27,'names':18,'periodic_ranking':7},'tests':totals,'test_groups':groups,'baseline_tests':runs['baseline']['totals'],'intermediate_tests':runs['test-initial']['totals'],
 'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':sources,'starcore_sha256':core},'artifact_verification':runs['artifacts'],
 'source_hashes':{name:sha((native/name).read_bytes()) for name in names},
 'limits':['No real Minecraft, MySQL, external Vault/NPC/protection binaries or live Paper/Folia reload.',
  'Built-in operations are async; external providers retain Paper main-thread calls. Unverified external Folia account operations and periodic refresh are not invoked.',
  'In-memory admission guards do not provide durable request IDs, provider idempotency or recovery of uncertain player-money mutations after process failure.',
  'After admission, the captured UUID operation may finish despite reconnect/stop. Responses require the original audience; no rollback is promised.',
  'Legacy constructors populate name snapshots lazily; initial completion may be empty/partial until owner captures finish.',
  'Names are sampled snapshots. Module startup/joins populate the shared directory, quits/close invalidate original objects.',
  '484 selected tests (441 scheduler/Essentials plus 43 foundation economy), existing POM exclusions retained, not the complete native suite.',
  'Single 256 MiB JVM per operation; forkCount=0, jacoco.skip=true; no local coverage result.',
  'Chronicle main JAR and prior 1021-test local result unchanged. Earlier contracts and regressions retain their own JAR identities.',
  'Social/GUI/NPC and other business ownership, provider certainty, full hot reload and production acceptance remain.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/economy-remaining-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
 for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
 manifest=json.loads(archive.read('manifest.json'));assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
 for name,digest in manifest['files'].items():assert sha(archive.read(name))==digest
summary['evidence_files']=len(files);summary['evidence_zip_sha256']=sha(output.read_bytes())
(output.parent/'economy-remaining-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# 账户命令、名字补全与排行榜周期：源码验证 2026-11-26

原余额／管理命令直接读取另一玩家并同步调用账户操作；补全遍历在线玩家读取名字，定时排行榜也未按经济提供者区分线程。本次迁移这些 Essentials 使用链，统一账户操作的调度与准入，并分清已提交后的回读失败和无法确认的变更结果。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{core}` |
| Chronicle，主构件保持 | `{plugin}` |
| Chronicle 源码 JAR | `{sources}` |
| 证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线 Chronicle `2d1510c`、StarCore `6c8decf`。[证据 ZIP](verification/economy-remaining-source-20261126-evidence.zip) **{len(files)} 文件**；[机器摘要](verification/economy-remaining-source-20261126-summary.json)。包含源码、旧实现失败、最终 XML、构建／SBOM／API／类字节核对、工具，以及上一经济检查点 CI #181 成功日志和交付 Git 核对。没有启动 Minecraft。

## 已实现

- 余额和管理操作在目标 owner 采集名字，回原发起者 owner／控制台全局／命令方块区域复核权限后准入。重连前后的对象不混用；准入后使用捕获 UUID，晚到反馈不会进入新玩家会话。
- 自带经济账户操作异步执行；外部提供者使用 Paper 主线程契约。/pay 使用同一路由，未验证的外部 Folia 操作不会调用提供者。单次准入保护避免重复回调或注册失败后迟到回调再次执行账户变更。
- give／take 仅接受正数，set 允许零、拒绝负数；非法操作只回复一次。变更已返回成功但余额回读失败，明确提示已提交、余额暂不可用；变更抛异常则提示结果无法确认并建议核对，不自动重试。没有新增持久请求编号或承诺外部提供者的幂等／确定性。
- PlayerNameDirectory 在各原玩家 owner 采集名字，启动播种、加入更新、退出按确切对象移除，关闭后旧回调失效。补全读取不可变排序快照、过滤前缀与权限，/pay 排除自身。原会话核验仅用服务器 UUID 映射；旧退出、退休、采集失败或同玩家旧尝试不能擦除新记录。
- 每 UUID 最多一个待采集任务。原构造器保持，按需建立名字目录；首次补全可能暂为空／部分，待 owner 回调完成后可用。模块共享目录在启动／加入时预填，没有阻塞等待。
- 原生排行榜周期在异步读取快照，按本次启用只准入一个刷新。失败释放名额，注册失败后的迟到回调和已完成回调的重放不会执行或清除新尝试。停用后不发布旧结果。外部 Paper 保持全局定时调用，外部 Folia 不执行未验证刷新，每次启用仅警告一次。

玩家命令入口仍要求对应 owner；名字／金额是采样快照。已提交提示依据提供者的 boolean 成功契约，自带接口重载使用同步持久化；命令不会独立确认外部提供者的磁盘状态。已准入账户操作可以继续完成，不宣称退出或停用会回滚。对外部提供者 false 返回、进程中断后的未知结果及全栈 Folia 支持仍需单独处理。

## 验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现剩余调用链基线 | 22 | 22 | 0 | 0 |
| 初轮相关回归 | 482 | 0 | 0 | 0 |
| 补齐周期回调准入后的最终回归 | **484** | **0** | **0** | **0** |

新增 **52 项**：账户／补全调用链 27、名字目录 18、周期刷新 7。最终 441 项调度器／Essentials 加 43 项自带经济、Vault 适配器、交易账本既有测试。使用分离 owner／异步／全局／区域队列，覆盖重连、权限撤回、金额边界、提交后的回读失败、不确定结果、旧回调、注册失败、目录关闭与队列去重；22 个旧实现失败均为行为断言，原始 XML 保留。

Spotless、2,267 主源／1,091 测试源编译、484 项回归、独立打包和在线 36 组件 SBOM 通过；最终 8 个相关类与已测 target/classes 字节一致，Java 21 与旧公开方法描述符保持。新增共享名字目录构造器与目录 API。原经济线程测试适配新的队列／会话和自带提供者，既有行为断言保留。每次单个 256 MiB JVM、forkCount=0、jacoco.skip=true，无本机覆盖率；未增加 POM 排除，484 项不是全库测试。

```text
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=dev.starcore.starcore.core.scheduler.**,dev.starcore.starcore.essentials.**,InternalEconomyServiceTest,PlayerVaultEconomyServiceTest,TransactionFabricTest surefire:test
```

Chronicle 主构件沿用 NPC 检查点本地 1,021 项结果，本轮未本地重跑；新文档提交后独立跟踪 Linux CI。原 389／356／339／302／1,131 项和国库、贸易、工厂契约继续保持各自构件边界。StarCore 现有工作流不覆盖非 main 基线草稿 PR。

下一步继续社交、GUI 与其他业务所有权及经济提供者不确定结果恢复；完整热重载、实际 NPC／保护组合、当前实服、全栈 Folia 和长期容量尚待验收，十阶段未全部完成。
'''
(root/'docs/ECONOMY-REMAINING-SOURCE-20261126.md').write_text(report,encoding='utf-8')
print(json.dumps({'evidence_files':len(files),'evidence_sha256':summary['evidence_zip_sha256'],'artifacts':summary['artifacts'],'tests':totals,'groups':groups}))
