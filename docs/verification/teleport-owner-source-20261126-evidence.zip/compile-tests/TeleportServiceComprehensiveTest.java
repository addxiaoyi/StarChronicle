package dev.starcore.starcore.essentials.teleport;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** TeleportService 单元测试 */
@DisplayName("TeleportService 测试")
class TeleportServiceComprehensiveTest {

  private TeleportService service;
  private Player player;
  private Player target;
  private World world;
  private Location location;
  private JavaPlugin plugin;
  private FoliaCompatScheduler scheduler;

  @BeforeEach
  void setUp() {
    plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getLogger("test"));
    scheduler = mock(FoliaCompatScheduler.class);
    service = new TeleportService(plugin, scheduler, TeleportConfig.defaults());
    world = mock(World.class);
    location = mock(Location.class);
    when(location.getWorld()).thenReturn(world);
    when(location.clone()).thenReturn(location);
    player = mock(Player.class);
    UUID playerId = UUID.randomUUID();
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.getName()).thenReturn("Sender");
    when(player.getLocation()).thenReturn(location);
    target = mock(Player.class);
    UUID targetId = UUID.randomUUID();
    when(target.getUniqueId()).thenReturn(targetId);
    when(target.getName()).thenReturn("Target");
    Server server = mock(Server.class);
    when(player.isOnline()).thenReturn(true);
    when(target.isOnline()).thenReturn(true);
    when(player.getServer()).thenReturn(server);
    when(target.getServer()).thenReturn(server);
    when(server.getPlayer(playerId)).thenReturn(player);
    when(server.getPlayer(targetId)).thenReturn(target);
    when(player.teleportAsync(org.mockito.ArgumentMatchers.any(Location.class)))
        .thenReturn(java.util.concurrent.CompletableFuture.completedFuture(false));
    doAnswer(
            i -> {
              i.<java.util.function.Consumer<Object>>getArgument(1).accept(null);
              return null;
            })
        .when(scheduler)
        .runAtEntity(
            org.mockito.ArgumentMatchers.any(),
            org.mockito.ArgumentMatchers.any(),
            org.mockito.ArgumentMatchers.any(Runnable.class));
  }

  @Test
  void setters() {
    service.setHomeService(mock(dev.starcore.starcore.essentials.home.HomeService.class));
    service.setWarpService(mock(dev.starcore.starcore.essentials.warp.WarpService.class));
  }

  @Test
  void setSpawnPermission() {
    service.setSetSpawnPermission("foo.bar");
    assertThat(service.getSetSpawnPermission()).isEqualTo("foo.bar");
  }

  @Test
  void canSetSpawn_emptyPerm() {
    service.setSetSpawnPermission("");
    assertThat(service.canSetSpawn(player)).isTrue();
  }

  @Test
  void canSetSpawn_nullPerm() {
    service.setSetSpawnPermission(null);
    assertThat(service.canSetSpawn(player)).isTrue();
  }

  @Test
  void canSetSpawn_withPerm_true() {
    service.setSetSpawnPermission("x");
    when(player.hasPermission("x")).thenReturn(true);
    assertThat(service.canSetSpawn(player)).isTrue();
  }

  @Test
  void canSetSpawn_withPerm_false() {
    service.setSetSpawnPermission("x");
    when(player.hasPermission("x")).thenReturn(false);
    assertThat(service.canSetSpawn(player)).isFalse();
  }

  @Test
  void spawnLocation() {
    assertThat(service.getSpawnLocation()).isNull();
    service.setSpawnLocation(location);
    assertThat(service.getSpawnLocation()).isSameAs(location);
  }

  @Test
  void spawnLocationUsesDefensiveCopies() {
    Location configured = new Location(world, 10, 64, 20);
    service.setSpawnLocation(configured);
    configured.setX(99);

    Location returned = service.getSpawnLocation();
    assertThat(returned.getX()).isEqualTo(10);
    returned.setX(42);
    assertThat(service.getSpawnLocation().getX()).isEqualTo(10);
  }

  @Test
  void teleportToSpawn_unset() {
    service.teleportToSpawn(player);
  }

  @Test
  void teleportToSpawn_set() {
    service.setSpawnLocation(location);
    service.teleportToSpawn(player);
  }

  @Test
  void configuredMovementCancellationBlocksDelayedTeleport() {
    TeleportConfig config =
        new TeleportConfig(
            null,
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(5),
            Duration.ofSeconds(3),
            5,
            true,
            true);
    TeleportService configured = new TeleportService(plugin, scheduler, config);
    var homes = mock(dev.starcore.starcore.essentials.home.HomeService.class);
    Location home = new Location(world, 10, 70, 10);
    when(homes.getHome(player.getUniqueId(), "home")).thenReturn(java.util.Optional.of(home));
    configured.setHomeService(homes);
    Location start = new Location(world, 0, 64, 0);
    Location moved = new Location(world, 1, 64, 0);
    when(player.getLocation()).thenReturn(start, start, moved);

    configured.teleportToHome(player, "home");

    assertThat(configured.cancelPendingTeleportOnMove(player, moved)).isTrue();
    assertThat(configured.cancelPendingTeleportOnDamage(player)).isFalse();
    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    callback.getValue().run();
    verify(player, never()).teleportAsync(home);
  }

  @Test
  void configuredDamageCancellationBlocksDelayedTeleport() {
    TeleportConfig config =
        new TeleportConfig(
            null,
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(5),
            Duration.ofSeconds(3),
            5,
            true,
            true);
    TeleportService configured = new TeleportService(plugin, scheduler, config);
    configured.setSpawnLocation(location);
    when(player.getLocation()).thenReturn(location, location);

    configured.teleportToSpawn(player);

    assertThat(configured.cancelPendingTeleportOnDamage(player)).isTrue();
    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    callback.getValue().run();
    verify(player, never()).teleportAsync(location);
  }

  @Test
  void disabledCancellationFlagsAllowDelayedTeleportAfterMovementAndDamage() {
    TeleportConfig config =
        new TeleportConfig(
            null,
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(5),
            Duration.ofSeconds(3),
            5,
            false,
            false);
    TeleportService configured = new TeleportService(plugin, scheduler, config);
    var homes = mock(dev.starcore.starcore.essentials.home.HomeService.class);
    Location home = new Location(world, 10, 70, 10);
    when(homes.getHome(player.getUniqueId(), "home")).thenReturn(java.util.Optional.of(home));
    configured.setHomeService(homes);
    Location start = new Location(world, 0, 64, 0);
    when(player.getLocation()).thenReturn(start, start);

    configured.teleportToHome(player, "home");

    assertThat(configured.cancelPendingTeleportOnMove(player, new Location(world, 1, 64, 0)))
        .isFalse();
    assertThat(configured.cancelPendingTeleportOnDamage(player)).isFalse();
    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    callback.getValue().run();
    verify(player).teleportAsync(home);
  }

  @Test
  void unloadedDestinationWorldFailsWithPlayerFeedback() {
    TeleportService configured = new TeleportService(plugin, scheduler, TeleportConfig.defaults());
    var homes = mock(dev.starcore.starcore.essentials.home.HomeService.class);
    Location home = mock(Location.class);
    when(home.getWorld()).thenReturn(null);
    when(homes.getHome(player.getUniqueId(), "home")).thenReturn(java.util.Optional.of(home));
    configured.setHomeService(homes);

    configured.teleportToHome(player, "home");

    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    callback.getValue().run();

    verify(player, never()).teleportAsync(home);
    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(messages.getAllValues()).hasSize(2);
    assertThat(plainText(messages.getAllValues())).anyMatch(text -> text.contains("传送到家园失败"));
    assertThat(plainText(messages.getAllValues())).noneMatch(text -> text.contains("已传送到家园"));
  }

  @Test
  void cancelledTeleportReportsFailureInsteadOfSuccess() {
    TeleportService configured = new TeleportService(plugin, scheduler, TeleportConfig.defaults());
    configured.setSpawnLocation(location);
    when(player.teleportAsync(location))
        .thenReturn(java.util.concurrent.CompletableFuture.completedFuture(false));

    configured.teleportToSpawn(player);

    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    callback.getValue().run();

    verify(player).teleportAsync(location);
    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(messages.getAllValues()).hasSize(2);
    assertThat(plainText(messages.getAllValues())).anyMatch(text -> text.contains("传送到主城失败"));
    assertThat(plainText(messages.getAllValues())).noneMatch(text -> text.contains("欢迎来到主城"));
  }

  @Test
  void teleportExceptionIsLoggedAndConvertedToPlayerFeedback() {
    TeleportService configured = new TeleportService(plugin, scheduler, TeleportConfig.defaults());
    configured.setSpawnLocation(location);
    doThrow(new IllegalStateException("world unloaded")).when(player).teleportAsync(location);

    configured.teleportToSpawn(player);

    org.mockito.ArgumentCaptor<Runnable> callback =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(player),
            callback.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));
    org.assertj.core.api.Assertions.assertThatCode(callback.getValue()::run)
        .doesNotThrowAnyException();

    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(messages.getAllValues()).hasSize(2);
    assertThat(plainText(messages.getAllValues())).anyMatch(text -> text.contains("传送到主城失败"));
    assertThat(plainText(messages.getAllValues())).noneMatch(text -> text.contains("欢迎来到主城"));
  }

  @Test
  void rejectedDelayedSchedulingClearsPendingStateAndReportsFailure() {
    TeleportConfig config =
        new TeleportConfig(
            null,
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(5),
            Duration.ofSeconds(3),
            5,
            true,
            true);
    TeleportService configured = new TeleportService(plugin, scheduler, config);
    configured.setSpawnLocation(location);
    doThrow(new RejectedExecutionException("scheduler stopping"))
        .when(scheduler)
        .runEntityDelayed(
            eq(player),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(60L));

    configured.teleportToSpawn(player);

    assertThat(configured.cancelPendingTeleportOnDamage(player)).isFalse();
    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(plainText(messages.getAllValues()))
        .anyMatch(text -> text.contains("传送到主城失败：服务器无法完成该操作"));
  }

  private static java.util.List<String> plainText(java.util.List<Component> messages) {
    return messages.stream().map(PlainTextComponentSerializer.plainText()::serialize).toList();
  }

  @Test
  void recordLastLocation() {
    service.recordLastLocation(player);
  }

  @Test
  void sendTeleportRequest() {
    service.sendTeleportRequest(player, target);
  }

  @Test
  void rejectedTimeoutScheduleDoesNotLeaveEitherRequestPendingOrCooldownActive() {
    doThrow(new RejectedExecutionException("scheduler stopping"))
        .when(scheduler)
        .runDelayed(org.mockito.ArgumentMatchers.any(Runnable.class), eq(1200L));

    service.sendTeleportRequest(player, target);
    service.sendTeleportHereRequest(player, target);

    assertThat(service.pendingRequestCount()).isZero();
    assertThat(service.getRemainingCooldownSeconds(player.getUniqueId())).isZero();
    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(plainText(messages.getAllValues())).allMatch(text -> text.contains("传送请求发送失败"));
    verify(target, never()).sendMessage(org.mockito.ArgumentMatchers.any(Component.class));
  }

  @Test
  void acceptingTeleportHereSchedulesTheRecipientToMoveToTheSender() {
    when(player.isOnline()).thenReturn(true);
    when(target.isOnline()).thenReturn(true);
    Location senderLocation = new Location(world, 12, 64, -4);
    Location recipientLocation = new Location(world, -8, 70, 21);
    when(player.getLocation()).thenReturn(senderLocation);
    when(target.getLocation()).thenReturn(recipientLocation);
    when(target.teleportAsync(org.mockito.ArgumentMatchers.any(Location.class)))
        .thenReturn(java.util.concurrent.CompletableFuture.completedFuture(true));
    Server server = mock(Server.class);
    when(target.getServer()).thenReturn(server);
    when(server.getPlayer(player.getUniqueId())).thenReturn(player);
    when(server.getPlayer(target.getUniqueId())).thenReturn(target);

    service.sendTeleportHereRequest(player, target);
    service.acceptTeleportRequest(target);

    org.mockito.ArgumentCaptor<Runnable> delayedTeleport =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler)
        .runEntityDelayed(
            eq(target),
            delayedTeleport.capture(),
            org.mockito.ArgumentMatchers.any(Runnable.class),
            eq(TeleportConfig.defaults().tpaDelay() * 20L));
    delayedTeleport.getValue().run();
    verify(target).teleportAsync(senderLocation);
    verify(player, never()).teleportAsync(org.mockito.ArgumentMatchers.any(Location.class));
  }

  @Test
  void scheduledTimeoutRemovesPendingRequestAndNotifiesItsSender() {
    when(player.isOnline()).thenReturn(true);
    org.mockito.ArgumentCaptor<Runnable> timeout =
        org.mockito.ArgumentCaptor.forClass(Runnable.class);

    service.sendTeleportRequest(player, target);

    verify(scheduler).runDelayed(timeout.capture(), eq(1200L));
    assertThat(service.pendingRequestCount()).isEqualTo(1);
    timeout.getValue().run();
    assertThat(service.pendingRequestCount()).isZero();
    org.mockito.ArgumentCaptor<Component> messages =
        org.mockito.ArgumentCaptor.forClass(Component.class);
    verify(player, times(2)).sendMessage(messages.capture());
    assertThat(plainText(messages.getAllValues())).anyMatch(text -> text.contains("传送请求已过期"));
  }

  @Test
  void concurrentRequestsFromOneSenderReserveOnlyOnePendingRequest() throws Exception {
    Player secondTarget = mock(Player.class);
    when(secondTarget.getUniqueId()).thenReturn(UUID.randomUUID());
    when(secondTarget.getName()).thenReturn("SecondTarget");
    when(secondTarget.isOnline()).thenReturn(true);
    Server secondTargetServer = player.getServer();
    when(secondTarget.getServer()).thenReturn(secondTargetServer);
    when(player.getServer().getPlayer(secondTarget.getUniqueId())).thenReturn(secondTarget);
    CountDownLatch start = new CountDownLatch(1);
    var executor = Executors.newFixedThreadPool(2);
    try {
      var first =
          executor.submit(
              () -> {
                start.await();
                service.sendTeleportRequest(player, target);
                return null;
              });
      var second =
          executor.submit(
              () -> {
                start.await();
                service.sendTeleportRequest(player, secondTarget);
                return null;
              });

      start.countDown();
      first.get(5, TimeUnit.SECONDS);
      second.get(5, TimeUnit.SECONDS);

      assertThat(service.pendingRequestCount()).isEqualTo(1);
      verify(scheduler, times(1))
          .runDelayed(org.mockito.ArgumentMatchers.any(Runnable.class), eq(1200L));
    } finally {
      executor.shutdownNow();
    }
  }

  @Test
  void normalRequestCooldownIsReservedBeforeTimeoutSchedulingCompletes() throws Exception {
    assertCooldownReservedBeforeTimeoutSchedulingCompletes(false);
  }

  @Test
  void tpahereCooldownIsReservedBeforeTimeoutSchedulingCompletes() throws Exception {
    assertCooldownReservedBeforeTimeoutSchedulingCompletes(true);
  }

  private void assertCooldownReservedBeforeTimeoutSchedulingCompletes(boolean teleportHere)
      throws Exception {
    CountDownLatch timeoutSchedulingStarted = new CountDownLatch(1);
    CountDownLatch allowTimeoutSchedulingToFinish = new CountDownLatch(1);
    AtomicInteger timeoutScheduleCalls = new AtomicInteger();
    doAnswer(
            invocation -> {
              if (timeoutScheduleCalls.incrementAndGet() == 1) {
                timeoutSchedulingStarted.countDown();
                if (!allowTimeoutSchedulingToFinish.await(5, TimeUnit.SECONDS)) {
                  throw new AssertionError("Timed out waiting to release the timeout scheduler");
                }
              }
              return null;
            })
        .when(scheduler)
        .runDelayed(org.mockito.ArgumentMatchers.any(Runnable.class), eq(1200L));

    when(player.isOnline()).thenReturn(true);
    when(target.getLocation()).thenReturn(location);
    Server server = mock(Server.class);
    when(target.getServer()).thenReturn(server);
    when(server.getPlayer(player.getUniqueId())).thenReturn(player);
    when(server.getPlayer(target.getUniqueId())).thenReturn(target);

    var executor = Executors.newSingleThreadExecutor();
    try {
      var firstRequest =
          executor.submit(
              () -> {
                if (teleportHere) {
                  service.sendTeleportHereRequest(player, target);
                } else {
                  service.sendTeleportRequest(player, target);
                }
              });
      assertThat(timeoutSchedulingStarted.await(5, TimeUnit.SECONDS)).isTrue();

      // Acceptance removes the pending slot while the original request is still
      // registering its expiration task on another scheduler thread.
      service.acceptTeleportRequest(target);

      Player secondTarget = mock(Player.class);
      when(secondTarget.getUniqueId()).thenReturn(UUID.randomUUID());
      when(secondTarget.getName()).thenReturn("SecondTarget");
      when(secondTarget.isOnline()).thenReturn(true);
      Server secondTargetServer = player.getServer();
      when(secondTarget.getServer()).thenReturn(secondTargetServer);
      when(player.getServer().getPlayer(secondTarget.getUniqueId())).thenReturn(secondTarget);
      if (teleportHere) {
        service.sendTeleportHereRequest(player, secondTarget);
      } else {
        service.sendTeleportRequest(player, secondTarget);
      }

      assertThat(service.pendingRequestCount()).isZero();
      assertThat(service.getRemainingCooldownSeconds(player.getUniqueId())).isPositive();
      verify(scheduler, times(1))
          .runDelayed(org.mockito.ArgumentMatchers.any(Runnable.class), eq(1200L));
      allowTimeoutSchedulingToFinish.countDown();
      firstRequest.get(5, TimeUnit.SECONDS);
    } finally {
      allowTimeoutSchedulingToFinish.countDown();
      executor.shutdownNow();
    }
  }

  @Test
  void sendTeleportRequest_cooldown() {
    service.sendTeleportRequest(player, target);
    service.sendTeleportRequest(player, target);
  }

  @Test
  void sendTeleportRequest_usesConfiguredCooldown() {
    TeleportConfig config =
        new TeleportConfig(
            null,
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(3),
            Duration.ofSeconds(7),
            Duration.ofSeconds(3),
            5,
            true,
            true);
    TeleportService configured = new TeleportService(plugin, scheduler, config);

    configured.sendTeleportRequest(player, target);

    assertThat(configured.getRemainingCooldownSeconds(player.getUniqueId())).isBetween(1L, 7L);
  }

  @Test
  void acceptTeleportRequest_noRequest() {
    service.acceptTeleportRequest(target);
  }

  @Test
  void denyTeleportRequest_noRequest() {
    service.denyTeleportRequest(target);
  }

  @Test
  void teleportBack_noLast() {
    service.teleportBack(player);
  }

  @Test
  void cleanup() {
    service.cleanup(player.getUniqueId());
  }
}
