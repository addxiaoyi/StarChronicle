package dev.starcore.starcore.core.scheduler;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;

class FoliaCompatSchedulerBoundaryTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Entity entity = mock(Entity.class);
  private final Location location = mock(Location.class);
  private final EntityScheduler owner = mock(EntityScheduler.class);
  private final GlobalRegionScheduler global = mock(GlobalRegionScheduler.class);
  private final RegionScheduler region = mock(RegionScheduler.class);
  private final AsyncScheduler async = mock(AsyncScheduler.class);
  private final BukkitScheduler paper = mock(BukkitScheduler.class);
  private final ScheduledTask raw = mock(ScheduledTask.class);
  private final BukkitTask paperRaw = mock(BukkitTask.class);
  private MockedStatic<Bukkit> bukkit;

  @BeforeEach
  void setup() {
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(entity.getScheduler()).thenReturn(owner);
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(Bukkit::getScheduler).thenReturn(paper);
    bukkit.when(Bukkit::getGlobalRegionScheduler).thenReturn(global);
    bukkit.when(Bukkit::getRegionScheduler).thenReturn(region);
    bukkit.when(Bukkit::getAsyncScheduler).thenReturn(async);
  }

  @AfterEach
  void cleanup() {
    bukkit.close();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void zeroTickDelaysUseOneTickForEveryTickBasedPath(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    scheduler.runEntityDelayed(entity, () -> {}, 0);
    scheduler.runAtLocationDelayed(location, t -> {}, 0);
    scheduler.runGlobalDelayed(() -> {}, 0);
    scheduler.runGlobalRepeating(() -> {}, 0, 2);
    if (folia) {
      verify(owner).runDelayed(eq(plugin), any(), any(), eq(1L));
      verify(region).runDelayed(eq(plugin), eq(location), any(), eq(1L));
      verify(global).runDelayed(eq(plugin), any(), eq(1L));
      verify(global).runAtFixedRate(eq(plugin), any(), eq(1L), eq(2L));
    } else {
      verify(paper, times(3)).runTaskLater(eq(plugin), any(Runnable.class), eq(1L));
      verify(paper).runTaskTimer(eq(plugin), any(Runnable.class), eq(1L), eq(2L));
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void invalidIntervalsNeverReachAPlatformScheduler(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    assertThrows(
        IllegalArgumentException.class, () -> scheduler.runEntityDelayed(entity, () -> {}, -1));
    assertThrows(
        IllegalArgumentException.class,
        () -> scheduler.runAtLocationDelayed(location, t -> {}, -1));
    assertThrows(IllegalArgumentException.class, () -> scheduler.runGlobalDelayed(() -> {}, -1));
    assertThrows(
        IllegalArgumentException.class, () -> scheduler.runGlobalRepeating(() -> {}, -1, 1));
    assertThrows(
        IllegalArgumentException.class, () -> scheduler.runGlobalRepeating(() -> {}, 0, 0));
    assertThrows(
        IllegalArgumentException.class, () -> scheduler.runGlobalRepeating(() -> {}, 0, -1));
    assertThrows(
        IllegalArgumentException.class,
        () -> scheduler.runAsyncDelayed(() -> {}, -1, TimeUnit.MILLISECONDS));
    assertThrows(
        IllegalArgumentException.class,
        () -> scheduler.runAsyncRepeating(() -> {}, 0, 0, TimeUnit.NANOSECONDS));
    assertThrows(
        IllegalArgumentException.class,
        () -> scheduler.runAsyncRepeating(() -> {}, -1, 1, TimeUnit.SECONDS));
    assertThrows(NullPointerException.class, () -> scheduler.runAsyncDelayed(() -> {}, 1, null));
    verifyNoInteractions(owner, global, region, async, paper);
  }

  @Test
  void asyncSubtickPeriodsRoundUpOnPaperWithoutOverflow() {
    var scheduler = new FoliaCompatScheduler(plugin, false);
    scheduler.runAsyncRepeating(() -> {}, 0, 1, TimeUnit.NANOSECONDS);
    scheduler.runAsyncDelayed(() -> {}, 51, TimeUnit.MILLISECONDS);
    scheduler.runAsyncDelayed(() -> {}, Long.MAX_VALUE, TimeUnit.DAYS);
    verify(paper).runTaskTimerAsynchronously(eq(plugin), any(Runnable.class), eq(0L), eq(1L));
    verify(paper).runTaskLaterAsynchronously(eq(plugin), any(Runnable.class), eq(2L));
    verify(paper).runTaskLaterAsynchronously(eq(plugin), any(Runnable.class), eq(184467440738L));
  }

  @Test
  void asyncZeroDelayUsesRunNowOnFoliaAndRepeatingKeepsItsRealTimeUnit() {
    var scheduler = new FoliaCompatScheduler(plugin, true);
    scheduler.runAsyncDelayed(() -> {}, 0, TimeUnit.SECONDS);
    scheduler.runAsyncRepeating(() -> {}, 0, 1, TimeUnit.MICROSECONDS);
    verify(async).runNow(eq(plugin), any());
    verify(async).runAtFixedRate(eq(plugin), any(), eq(0L), eq(1L), eq(TimeUnit.MICROSECONDS));
    verify(async, never()).runDelayed(any(), any(), anyLong(), any());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void callerRetirementRunsOnceOnCancellationAndNotOnNormalCompletion(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger retirements = new AtomicInteger(), operations = new AtomicInteger();
    List<Runnable> callbacks = new ArrayList<>();
    if (folia)
      when(owner.run(eq(plugin), any(), any()))
          .thenAnswer(
              i -> {
                callbacks.add(() -> i.<Consumer<ScheduledTask>>getArgument(1).accept(raw));
                return raw;
              });
    else
      when(paper.runTask(eq(plugin), any(Runnable.class)))
          .thenAnswer(
              i -> {
                callbacks.add(i.getArgument(1));
                return paperRaw;
              });
    scheduler.runAtEntity(entity, t -> operations.incrementAndGet(), retirements::incrementAndGet);
    callbacks.getFirst().run();
    assertEquals(0, retirements.get());
    scheduler.runAtEntity(entity, t -> operations.incrementAndGet(), retirements::incrementAndGet);
    scheduler.cancelAll();
    scheduler.cancelAll();
    callbacks.getLast().run();
    assertEquals(1, retirements.get());
    assertEquals(1, operations.get());
  }

  @Test
  void nullRegistrationAndCallbackFailureRetireDetachedCallerState() {
    var scheduler = new FoliaCompatScheduler(plugin, true);
    AtomicInteger retired = new AtomicInteger();
    scheduler.runEntityDelayed(entity, () -> fail("absent"), retired::incrementAndGet, 0);
    assertEquals(1, retired.get());
    List<Consumer<ScheduledTask>> callbacks = new ArrayList<>();
    when(owner.run(eq(plugin), any(), any()))
        .thenAnswer(
            i -> {
              callbacks.add(i.getArgument(1));
              return raw;
            });
    RuntimeException failure = new IllegalStateException("body");
    scheduler.runAtEntity(
        entity,
        t -> {
          throw failure;
        },
        retired::incrementAndGet);
    assertSame(
        failure, assertThrows(RuntimeException.class, () -> callbacks.getFirst().accept(raw)));
    callbacks.getFirst().accept(raw);
    assertEquals(2, retired.get());
  }
}
