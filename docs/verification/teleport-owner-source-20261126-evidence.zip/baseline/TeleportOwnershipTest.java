package dev.starcore.starcore.essentials.teleport;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Answers;

/** Separate owner queues reject foreign player access; no Minecraft server is used. */
class TeleportOwnershipTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final World world = mock(World.class);
  private final Map<UUID, Player> online = new HashMap<>();
  private final Map<Player, State> states = new IdentityHashMap<>();
  private final Deque<Job> owners = new ArrayDeque<>();
  private final List<Job> delayed = new ArrayList<>();
  private final List<Runnable> global = new ArrayList<>();
  private Player owner, sender, target, rejectOwner;
  private boolean strict = true;
  private TeleportService service;
  private FoliaCompatScheduler scheduler;

  private static final class State {
    UUID id;
    String name;
    Location location;
    boolean online = true;
    List<String> messages = new ArrayList<>();
    List<Location> teleports = new ArrayList<>();
    CompletableFuture<Boolean> result = new CompletableFuture<>();
  }
  private record Job(Player player, Runnable body, Runnable retired, long delay) {}

  @BeforeEach
  void setup() {
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    scheduler = mock(FoliaCompatScheduler.class, i -> {
      String name = i.getMethod().getName();
      if (name.equals("runAtEntity") || name.equals("runEntityDelayed")) {
        Player player = i.getArgument(0);
        if (player == rejectOwner) throw new IllegalStateException("owner unavailable");
        Runnable retired = i.getArguments().length == (name.equals("runAtEntity") ? 3 : 4)
            ? i.getArgument(2) : () -> {};
        Runnable body = name.equals("runAtEntity")
            ? () -> i.<Consumer<Object>>getArgument(1).accept(null) : i.getArgument(1);
        long delay = name.equals("runAtEntity") ? 0 : (long) i.getArguments()[i.getArguments().length-1];
        Job job = new Job(player, body, retired, delay);
        if (name.equals("runAtEntity")) owners.add(job); else delayed.add(job);
        return null;
      }
      if (name.equals("runDelayed")) { global.add(i.getArgument(0)); return null; }
      return Answers.RETURNS_DEFAULTS.answer(i);
    });
    service = new TeleportService(plugin, scheduler, TeleportConfig.defaults());
    sender = player("Sender",UUID.randomUUID(),0);
    target = player("Target",UUID.randomUUID(),50);
  }

  private Player player(String name, UUID id, double x) {
    State state = new State(); state.id=id; state.name=name; state.location=new Location(world,x,64,0);
    Player result = mock(Player.class,i -> {
      if (i.getMethod().getName().equals("getUniqueId")) return state.id;
      if (Set.of("getName","getLocation","isOnline","getServer","sendMessage","teleport","teleportAsync").contains(i.getMethod().getName())) {
        if (strict) assertSame(i.getMock(),owner,"foreign player access: "+name+"."+i.getMethod().getName());
        switch (i.getMethod().getName()) {
          case "getName": return state.name;
          case "getLocation": return state.location.clone();
          case "isOnline": return state.online;
          case "getServer": return server;
          case "sendMessage":
            if (i.getArgument(0) instanceof Component c) state.messages.add(PlainTextComponentSerializer.plainText().serialize(c));
            return null;
          case "teleport": throw new AssertionError("synchronous player teleport is forbidden");
          case "teleportAsync": state.teleports.add(i.<Location>getArgument(0).clone()); return state.result;
        }
      }
      return Answers.RETURNS_DEFAULTS.answer(i);
    });
    states.put(result,state); online.put(id,result); return result;
  }

  private void owned(Player player, Runnable action) {
    Player previous=owner; owner=player;
    try { action.run(); } finally { owner=previous; }
  }
  private void run(Job job) { owned(job.player,job.body); }
  private void drain() {
    int limit=100;
    while (!owners.isEmpty()) { assertTrue(--limit>0,"owner loop"); run(owners.remove()); }
  }
  private void reserve(boolean here) {
    strict=false;
    owned(sender,() -> { if (here) service.sendTeleportHereRequest(sender,target); else service.sendTeleportRequest(sender,target); });
    drain(); strict=true;
    states.values().forEach(s -> s.messages.clear());
  }
  private void accept(boolean here) {
    reserve(here);
    owned(target,() -> service.acceptTeleportRequest(target));
    drain();
    assertEquals(1,delayed.size());
  }

  @ParameterizedTest @ValueSource(booleans={false,true})
  void invitationsOnlyReadAndMessagePlayersOnTheirOwnOwner(boolean here) {
    owned(sender,() -> { if (here) service.sendTeleportHereRequest(sender,target); else service.sendTeleportRequest(sender,target); });
    drain();
    assertEquals(1,service.pendingRequestCount());
    assertEquals(2,states.get(target).messages.size());
    assertEquals(1,states.get(sender).messages.size());
  }

  @Test
  void globalExpirationOnlyChangesDetachedStateBeforeOwnerNotification() {
    reserve(false);
    global.getFirst().run();
    assertEquals(0,service.pendingRequestCount());
    assertTrue(states.get(sender).messages.isEmpty());
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("已过期")));
  }

  @Test
  void denyNotifiesOriginalSenderOnItsOwner() {
    reserve(false);
    owned(target,() -> service.denyTeleportRequest(target));
    drain();
    assertEquals(0,service.pendingRequestCount());
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("拒绝")));
  }

  @ParameterizedTest @ValueSource(booleans={false,true})
  void acceptSamplesDestinationAfterDelayAndUsesAsyncTeleportOnTheMover(boolean here) {
    accept(here);
    Player mover=here?target:sender, destination=here?sender:target;
    states.get(destination).location.setX(123);
    run(delayed.getFirst()); drain();
    assertEquals(1,states.get(mover).teleports.size());
    assertEquals(123,states.get(mover).teleports.getFirst().getX());
    assertTrue(states.get(destination).teleports.isEmpty());
  }

  @Test
  void acceptedRequestCannotUseAReconnectedSender() {
    reserve(false);
    Player replacement=player("replacement",sender.getUniqueId(),200);
    owned(target,() -> service.acceptTeleportRequest(target)); drain();
    assertTrue(delayed.isEmpty());
    assertTrue(states.get(replacement).messages.isEmpty());
    assertTrue(states.get(replacement).teleports.isEmpty());
  }

  @Test
  void reconnectedRecipientCannotAcceptAnOldSessionRequest() {
    reserve(false);
    Player replacement=player("replacement",target.getUniqueId(),200);
    owned(replacement,() -> service.acceptTeleportRequest(replacement)); drain();
    assertTrue(delayed.isEmpty());
    assertTrue(states.get(sender).teleports.isEmpty());
  }

  @Test
  void senderQuitRemovesItsOutgoingRequest() {
    reserve(false);
    service.cleanup(sender.getUniqueId());
    assertEquals(0,service.pendingRequestCount());
  }

  @Test
  void destinationQuitCancelsAcceptedTeleport() {
    accept(false);
    service.cleanup(target.getUniqueId());
    run(delayed.getFirst()); drain();
    assertTrue(states.get(sender).teleports.isEmpty());
  }

  @Test
  void movementDuringDestinationLookupCancelsTheTeleport() {
    accept(false);
    run(delayed.getFirst());
    owned(sender,() -> assertTrue(service.cancelPendingTeleportOnMove(sender,new Location(world,9,64,0))));
    drain();
    assertTrue(states.get(sender).teleports.isEmpty());
  }

  @Test
  void delayedTeleportRejectsTheOriginalObjectAfterReconnect() {
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> service.teleportToSpawn(sender));
    player("replacement",sender.getUniqueId(),200);
    run(delayed.getFirst()); drain();
    assertTrue(states.get(sender).teleports.isEmpty());
  }

  @Test
  void oldSameLocationDelayCannotConsumeANewerTeleport() {
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> {service.teleportToSpawn(sender);service.teleportToSpawn(sender);});
    run(delayed.getFirst()); drain();
    assertTrue(states.get(sender).teleports.isEmpty());
    run(delayed.getLast()); drain();
    assertEquals(1,states.get(sender).teleports.size());
  }

  @Test
  void asyncResultIsReportedOnlyAfterReturningToTheOriginalPlayerOwner() {
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> service.teleportToSpawn(sender));
    run(delayed.getFirst()); drain();
    states.get(sender).messages.clear();
    states.get(sender).result.complete(true);
    assertTrue(states.get(sender).messages.isEmpty());
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("欢迎来到主城")));
  }

  @ParameterizedTest @ValueSource(booleans={false,true})
  void rejectedOrFailedAsyncTeleportNeverReportsSuccess(boolean exception) {
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> service.teleportToSpawn(sender));
    run(delayed.getFirst()); drain();
    states.get(sender).messages.clear();
    if (exception) states.get(sender).result.completeExceptionally(new IllegalStateException("cancelled"));
    else states.get(sender).result.complete(false);
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("失败")));
    assertTrue(states.get(sender).messages.stream().noneMatch(s -> s.contains("欢迎来到主城")));
  }

  @Test
  void asyncResultCannotNotifyAReconnectedSession() {
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> service.teleportToSpawn(sender));
    run(delayed.getFirst()); drain();
    states.get(sender).messages.clear();
    Player replacement=player("replacement",sender.getUniqueId(),200);
    states.get(sender).result.complete(true); drain();
    assertTrue(states.get(sender).messages.isEmpty());
    assertTrue(states.get(replacement).messages.isEmpty());
  }

  @Test
  void zeroConfiguredDelayStillUsesANextTick() {
    service=new TeleportService(plugin,scheduler,new TeleportConfig(null,Duration.ZERO,Duration.ZERO,Duration.ZERO,Duration.ZERO,Duration.ZERO,5,true,true));
    service.setSpawnLocation(new Location(world,2,64,0));
    owned(sender,() -> service.teleportToSpawn(sender));
    assertEquals(1,delayed.getFirst().delay);
  }

  @Test
  void unavailableRecipientOwnerReleasesPendingRequestAndCooldown() {
    rejectOwner=target;
    owned(sender,() -> service.sendTeleportRequest(sender,target));
    drain();
    assertEquals(0,service.pendingRequestCount());
    assertEquals(0,service.getRemainingCooldownSeconds(sender.getUniqueId()));
  }
}
