package dev.starcore.starcore.essentials.teleport;

import dev.starcore.starcore.core.extension.ExtensionRegistry;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.CancelContext;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.CancelResult;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.TeleportType;
import dev.starcore.starcore.essentials.warp.WarpService;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** 传送服务（完整版） 集成延迟和冷却系统 */
public final class TeleportService {
  private static final long TPA_REQUEST_TIMEOUT_MILLIS = 60_000L;
  private static final long TPA_REQUEST_TIMEOUT_TICKS = 60L * 20L;

  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final TeleportConfig config;
  private final EssentialsPermissions permissions;

  // 引用 HomeService（用于获取家园数据）
  private HomeService homeService;

  // 引用 WarpService（用于获取星港数据）
  private WarpService warpService;

  // 主城传送点（星核）
  private Location spawnLocation;

  // 传送请求（带去重）
  private final Map<UUID, TeleportRequest> teleportRequests = new ConcurrentHashMap<>();

  // 最后一次传送位置（用于 /back）
  private final Map<UUID, Location> lastLocations = new ConcurrentHashMap<>();

  // 待执行的延迟传送；用于按配置响应移动、受伤和退出
  private final Map<UUID, PendingTeleport> pendingTeleports = new ConcurrentHashMap<>();

  // TPA 请求冷却（防止刷屏）
  private final Map<UUID, Long> tpaCooldowns = new ConcurrentHashMap<>();

  // 设置主城的权限节点（可配置）
  private String setSpawnPermission = "starcore.setspawn";

  public TeleportService(Plugin plugin, FoliaCompatScheduler scheduler, TeleportConfig config) {
    this(plugin, scheduler, config, EssentialsPermissions.defaults());
  }

  public TeleportService(
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      TeleportConfig config,
      EssentialsPermissions permissions) {
    this.plugin = plugin;
    this.scheduler = scheduler;
    this.config = config;
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
    this.setSpawnPermission = this.permissions.setSpawn();
  }

  /** 设置设置主城的权限节点 */
  public void setSetSpawnPermission(String permission) {
    this.setSpawnPermission = permission;
  }

  /** 获取设置主城的权限节点 */
  public String getSetSpawnPermission() {
    return setSpawnPermission;
  }

  /** 检查玩家是否有设置主城的权限 */
  public boolean canSetSpawn(Player player) {
    return EssentialsPermissions.permits(player, setSpawnPermission);
  }

  /** 设置 HomeService 引用 */
  public void setHomeService(HomeService homeService) {
    this.homeService = homeService;
  }

  /** 设置 WarpService 引用 */
  public void setWarpService(WarpService warpService) {
    this.warpService = warpService;
  }

  /** 记录玩家最后位置（传送前调用） */
  public void recordLastLocation(Player player) {
    Location location = player.getLocation();
    if (location == null) {
      return;
    }
    Location snapshot = location.clone();
    if (snapshot != null) {
      lastLocations.put(player.getUniqueId(), snapshot);
    }
  }

  /** 传送到主城（星核）- 带延迟 */
  public void teleportToSpawn(Player player) {
    Location destination = getSpawnLocation();
    if (destination == null) {
      player.sendMessage(Component.text("主城传送点未设置", NamedTextColor.RED));
      return;
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text("将在 " + config.spawnDelay() + " 秒后传送到主城...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        () -> performTeleport(player, destination, "欢迎来到主城！", "传送到主城失败：目标世界不可用或传送被取消", "spawn"),
        config.spawnDelay() * 20L,
        "传送到主城失败：服务器无法完成该操作",
        "spawn");
  }

  /** 传送到家园（锚点）- 带延迟 */
  public void teleportToHome(Player player, String homeName) {
    if (homeService == null) {
      player.sendMessage(Component.text("家园系统未初始化", NamedTextColor.RED));
      return;
    }

    // 获取家园位置
    Optional<Location> homeOpt = homeService.getHome(player.getUniqueId(), homeName);
    if (homeOpt.isEmpty()) {
      player.sendMessage(Component.text("家园 '" + homeName + "' 不存在", NamedTextColor.RED));
      return;
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text(
            "将在 " + config.homeDelay() + " 秒后传送到家园: " + homeName + "...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        () ->
            performTeleport(
                player, homeOpt.get(), "已传送到家园: " + homeName, "传送到家园失败：目标世界不可用或传送被取消", "home"),
        config.homeDelay() * 20L,
        "传送到家园失败：服务器无法完成该操作",
        "home");
  }

  /** 传送到星港 - 带延迟和权限检查 */
  public void teleportToWarp(Player player, String warpName) {
    if (!canUseWarp(player)) {
      player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
      return;
    }

    if (warpService == null) {
      player.sendMessage(Component.text("星港系统未初始化", NamedTextColor.RED));
      return;
    }

    // 获取星港位置
    Optional<Location> warpOpt = warpService.getWarp(warpName);
    if (warpOpt.isEmpty()) {
      player.sendMessage(Component.text("星港 '" + warpName + "' 不存在", NamedTextColor.RED));
      return;
    }

    Location[] warpLocations = {warpOpt.get()};
    // 扩展点拦截传送取消
    try {
      ExtensionRegistry registry = ExtensionRegistry.getInstance();
      CancelContext ctx = new CancelContext(player, warpLocations[0], TeleportType.WARP);
      CancelResult extResult = registry.execute("teleport_cancel", ctx);
      if (extResult.cancelled()) {
        player.sendMessage(Component.text("传送被取消: " + extResult.reason(), NamedTextColor.RED));
        return;
      }
      if (extResult.decoratedDestination() != null) {
        warpLocations[0] = extResult.decoratedDestination();
      }
    } catch (Exception e) {
      // 扩展点失败时继续原逻辑
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text(
            "将在 " + config.warpDelay() + " 秒后传送到星港: " + warpName + "...", NamedTextColor.YELLOW));

    Location finalDestination = warpLocations[0];
    scheduleDelayedTeleport(
        player,
        () ->
            performTeleport(
                player, finalDestination, "已传送到星港: " + warpName, "传送到星港失败：目标世界不可用或传送被取消", "warp"),
        config.warpDelay() * 20L,
        "传送到星港失败：服务器无法完成该操作",
        "warp");
  }

  /** Whether the player may use a warp, including the configured empty-node policy. */
  public boolean canUseWarp(Player player) {
    return EssentialsPermissions.permits(player, permissions.warpUse());
  }

  /** Whether the player may use the spawn teleport command. */
  public boolean canUseSpawn(Player player) {
    return EssentialsPermissions.permits(player, permissions.spawnUse());
  }

  /** 玩家传送请求 - 带去重和冷却 */
  /** 获取 TPA 冷却剩余秒数，0 表示无冷却 */
  public long getRemainingCooldownSeconds(UUID requesterId) {
    Long last = tpaCooldowns.get(requesterId);
    if (last == null) return 0;
    long remainingMillis = remainingCooldownMillis(last, System.currentTimeMillis());
    return remainingMillis == 0 ? 0 : (remainingMillis + 999) / 1000;
  }

  /** 获取当前待处理传送请求数 */
  public int pendingRequestCount() {
    long now = System.currentTimeMillis();
    return (int)
        teleportRequests.values().stream()
            .filter(request -> !isRequestExpired(request, now))
            .count();
  }

  public void sendTeleportRequest(Player requester, Player target) {
    UUID requesterId = requester.getUniqueId();
    UUID targetId = target.getUniqueId();
    long now = System.currentTimeMillis();

    TeleportRequest request = new TeleportRequest(requesterId, targetId, requesterId, now);
    synchronized (teleportRequests) {
      // 检查冷却
      Long lastRequest = tpaCooldowns.get(requesterId);
      long remainingMillis = remainingCooldownMillis(lastRequest, now);
      if (remainingMillis > 0) {
        long remaining = (remainingMillis + 999) / 1000;
        requester.sendMessage(Component.text("请等待 " + remaining + " 秒后再发送请求", NamedTextColor.RED));
        return;
      }

      // 去重检查：检查请求者是否已有待处理请求
      for (Map.Entry<UUID, TeleportRequest> entry : teleportRequests.entrySet()) {
        if (entry.getValue().senderId().equals(requesterId)
            && !isRequestExpired(entry.getValue(), now)) {
          requester.sendMessage(Component.text("你已有待处理的传送请求，请等待当前请求被处理后再试", NamedTextColor.RED));
          return;
        }
      }

      // 检查目标是否已有待处理请求，并与写入放在同一临界区。
      TeleportRequest existing = teleportRequests.get(targetId);
      if (existing != null && !isRequestExpired(existing, now)) {
        requester.sendMessage(Component.text("目标玩家有待处理的传送请求", NamedTextColor.RED));
        return;
      }
      if (existing != null) {
        teleportRequests.remove(targetId, existing);
      }
      teleportRequests.put(targetId, request);
      tpaCooldowns.put(requesterId, now);
    }
    if (!scheduleRequestExpiration(targetId, request, requester, "传送请求已过期")) {
      return;
    }

    requester.sendMessage(
        Component.text("已向 " + target.getName() + " 发送传送请求", NamedTextColor.GREEN));
    target.sendMessage(Component.text(requester.getName() + " 请求传送到你的位置", NamedTextColor.YELLOW));
    target.sendMessage(Component.text("使用 /tpaccept 接受 或 /tpdeny 拒绝", NamedTextColor.GRAY));
  }

  /** 接受传送请求 */
  public void acceptTeleportRequest(Player target) {
    UUID targetId = target.getUniqueId();
    TeleportRequest request = teleportRequests.remove(targetId);

    if (request == null) {
      target.sendMessage(Component.text("没有待处理的传送请求", NamedTextColor.RED));
      return;
    }
    if (isRequestExpired(request, System.currentTimeMillis())) {
      notifyRequestExpired(target, request);
      return;
    }

    var server = target.getServer();
    Player sender = server == null ? null : server.getPlayer(request.senderId());
    if (sender == null || !sender.isOnline()) {
      target.sendMessage(Component.text("请求者已离线", NamedTextColor.RED));
      return;
    }

    target.sendMessage(Component.text("已接受传送请求", NamedTextColor.GREEN));
    sender.sendMessage(Component.text(target.getName() + " 接受了你的传送请求", NamedTextColor.GREEN));

    boolean senderTeleports = request.teleporterId().equals(request.senderId());
    Player teleporter = senderTeleports ? sender : target;
    Player destinationPlayer = senderTeleports ? target : sender;

    // 记录请求者的最后位置用于 /back
    recordLastLocation(teleporter);

    // 传送
    scheduleDelayedTeleport(
        teleporter,
        () ->
            performTeleport(
                teleporter, destinationPlayer.getLocation(), "传送成功！", "传送失败：目标世界不可用或传送被取消", "tpa"),
        config.tpaDelay() * 20L,
        "传送失败：服务器无法完成该操作",
        "tpa");
  }

  /** 拒绝传送请求 */
  public void denyTeleportRequest(Player target) {
    UUID targetId = target.getUniqueId();
    TeleportRequest request = teleportRequests.remove(targetId);

    if (request == null) {
      target.sendMessage(Component.text("没有待处理的传送请求", NamedTextColor.RED));
      return;
    }
    if (isRequestExpired(request, System.currentTimeMillis())) {
      notifyRequestExpired(target, request);
      return;
    }

    var server = target.getServer();
    Player sender = server == null ? null : server.getPlayer(request.senderId());
    if (sender != null && sender.isOnline()) {
      sender.sendMessage(Component.text(target.getName() + " 拒绝了你的传送请求", NamedTextColor.RED));
    }
    target.sendMessage(Component.text("已拒绝传送请求", NamedTextColor.YELLOW));
  }

  /** 返回上一个位置（/back 命令） */
  public void teleportBack(Player player) {
    Location lastLoc = lastLocations.remove(player.getUniqueId());

    if (lastLoc == null) {
      player.sendMessage(Component.text("没有可返回的位置", NamedTextColor.RED));
      player.sendMessage(Component.text("提示: 传送后会自动记录你的位置", NamedTextColor.GRAY));
      return;
    }

    // 检查世界是否存在
    if (lastLoc.getWorld() == null) {
      player.sendMessage(Component.text("之前的位置世界已不存在", NamedTextColor.RED));
      return;
    }

    // 记录当前位置
    recordLastLocation(player);

    player.sendMessage(
        Component.text("将在 " + config.backDelay() + " 秒后返回上一个位置...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        () -> performTeleport(player, lastLoc, "已返回上一个位置", "返回失败：目标世界不可用或传送被取消", "back"),
        config.backDelay() * 20L,
        "返回失败：服务器无法完成该操作",
        "back");
  }

  /** 设置主城传送点 */
  public void setSpawnLocation(Location location) {
    this.spawnLocation = location == null ? null : location.clone();
  }

  public Location getSpawnLocation() {
    Location location = spawnLocation;
    return location == null ? null : location.clone();
  }

  /** 清理玩家数据 */
  public void cleanup(UUID playerId) {
    teleportRequests.remove(playerId);
    lastLocations.remove(playerId);
    pendingTeleports.remove(playerId);
    tpaCooldowns.remove(playerId);
  }

  /** Cancels a delayed teleport when the player changes block, if configured. */
  public boolean cancelPendingTeleportOnMove(Player player, Location destination) {
    if (!config.cancelOnMove()) {
      return false;
    }

    UUID playerId = player.getUniqueId();
    PendingTeleport pending = pendingTeleports.get(playerId);
    if (pending == null
        || pending.startLocation() == null
        || destination == null
        || !hasMoved(pending.startLocation(), destination)) {
      return false;
    }

    if (!pendingTeleports.remove(playerId, pending)) {
      return false;
    }
    player.sendMessage(Component.text("传送已取消（你移动了）", NamedTextColor.RED));
    return true;
  }

  /** Cancels a delayed teleport when the player takes damage, if configured. */
  public boolean cancelPendingTeleportOnDamage(Player player) {
    if (!config.cancelOnDamage()) {
      return false;
    }

    PendingTeleport pending = pendingTeleports.remove(player.getUniqueId());
    if (pending == null) {
      return false;
    }
    player.sendMessage(Component.text("传送已取消（你受到了伤害）", NamedTextColor.RED));
    return true;
  }

  /** 传送请求 */
  private record TeleportRequest(
      UUID senderId, UUID recipientId, UUID teleporterId, long timestamp) {}

  /** 发送拉人传送请求（目标传送到请求者处） */
  public void sendTeleportHereRequest(Player requester, Player target) {
    UUID requesterId = requester.getUniqueId();
    UUID targetId = target.getUniqueId();
    long now = System.currentTimeMillis();

    TeleportRequest request = new TeleportRequest(requesterId, targetId, targetId, now);
    synchronized (teleportRequests) {
      Long lastRequest = tpaCooldowns.get(requesterId);
      long remainingMillis = remainingCooldownMillis(lastRequest, now);
      if (remainingMillis > 0) {
        long remaining = (remainingMillis + 999) / 1000;
        requester.sendMessage(Component.text("请等待 " + remaining + " 秒后再发送请求", NamedTextColor.RED));
        return;
      }

      for (var entry : teleportRequests.entrySet()) {
        if (entry.getValue().senderId().equals(requesterId)
            && !isRequestExpired(entry.getValue(), now)) {
          requester.sendMessage(Component.text("你已有待处理的传送请求", NamedTextColor.RED));
          return;
        }
      }

      TeleportRequest existing = teleportRequests.get(targetId);
      if (existing != null && !isRequestExpired(existing, now)) {
        requester.sendMessage(Component.text("目标玩家已有待处理的传送请求", NamedTextColor.RED));
        return;
      }
      if (existing != null) {
        teleportRequests.remove(targetId, existing);
      }
      // tpahere：target 到 requester，requester 到 target 的方向反转
      teleportRequests.put(targetId, request);
      tpaCooldowns.put(requesterId, now);
    }
    if (!scheduleRequestExpiration(targetId, request, requester, "拉人请求已过期")) {
      return;
    }

    requester.sendMessage(
        Component.text("已向 " + target.getName() + " 发送拉人请求", NamedTextColor.GREEN));
    target.sendMessage(Component.text(requester.getName() + " 想让你传送到他那里", NamedTextColor.YELLOW));
    target.sendMessage(Component.text("使用 /tpaccept 接受 或 /tpdeny 拒绝", NamedTextColor.GRAY));
  }

  private long remainingCooldownMillis(Long lastRequest, long nowMillis) {
    if (lastRequest == null) return 0;
    long elapsed = Math.max(0, nowMillis - lastRequest);
    return Math.max(0, config.tpaCooldown().toMillis() - elapsed);
  }

  private boolean scheduleRequestExpiration(
      UUID targetId,
      TeleportRequest request,
      Player notificationRecipient,
      String expirationMessage) {
    try {
      scheduler.runDelayed(
          () -> {
            if (teleportRequests.remove(targetId, request) && notificationRecipient.isOnline()) {
              notificationRecipient.sendMessage(
                  Component.text(expirationMessage, NamedTextColor.RED));
            }
          },
          TPA_REQUEST_TIMEOUT_TICKS);
      return true;
    } catch (RuntimeException failure) {
      teleportRequests.remove(targetId, request);
      tpaCooldowns.remove(request.senderId(), request.timestamp());
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "ESSENTIALS_TPA_TIMEOUT_SCHEDULE_FAILED requester="
                  + request.senderId()
                  + " target="
                  + targetId,
              failure);
      notificationRecipient.sendMessage(Component.text("传送请求发送失败：服务器无法完成该操作", NamedTextColor.RED));
      return false;
    }
  }

  private void notifyRequestExpired(Player target, TeleportRequest request) {
    target.sendMessage(Component.text("传送请求已过期", NamedTextColor.RED));
    var server = target.getServer();
    if (server == null) {
      return;
    }
    Player requester = server.getPlayer(request.senderId());
    if (requester != null && requester.isOnline()) {
      requester.sendMessage(Component.text("传送请求已过期", NamedTextColor.RED));
    }
  }

  private static boolean isRequestExpired(TeleportRequest request, long nowMillis) {
    return nowMillis - request.timestamp() >= TPA_REQUEST_TIMEOUT_MILLIS;
  }

  private void scheduleDelayedTeleport(
      Player player, Runnable task, long delayTicks, String failureMessage, String teleportType) {
    UUID playerId = player.getUniqueId();
    Location playerLocation = player.getLocation();
    Location startLocation = playerLocation == null ? null : playerLocation.clone();
    PendingTeleport pending = new PendingTeleport(startLocation);
    pendingTeleports.put(playerId, pending);
    try {
      scheduler.runEntityDelayed(
          player,
          () -> {
            if (pendingTeleports.remove(playerId, pending)) {
              try {
                task.run();
              } catch (RuntimeException failure) {
                plugin
                    .getLogger()
                    .log(
                        Level.WARNING,
                        "code=ESSENTIALS_DELAYED_TELEPORT_FAILED type="
                            + teleportType
                            + " player="
                            + playerId,
                        failure);
                player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
              }
            }
          },
          delayTicks);
    } catch (RuntimeException schedulingFailure) {
      pendingTeleports.remove(playerId, pending);
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "code=ESSENTIALS_TELEPORT_SCHEDULE_FAILED type="
                  + teleportType
                  + " player="
                  + playerId,
              schedulingFailure);
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
    }
  }

  private boolean performTeleport(
      Player player,
      Location destination,
      String successMessage,
      String failureMessage,
      String teleportType) {
    if (destination == null || destination.getWorld() == null) {
      plugin
          .getLogger()
          .warning(
              "code=ESSENTIALS_TELEPORT_DESTINATION_UNAVAILABLE type="
                  + teleportType
                  + " player="
                  + player.getUniqueId());
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
      return false;
    }

    boolean teleported;
    try {
      teleported = player.teleport(destination);
    } catch (RuntimeException failure) {
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "code=ESSENTIALS_TELEPORT_FAILED type="
                  + teleportType
                  + " player="
                  + player.getUniqueId(),
              failure);
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
      return false;
    }

    if (!teleported) {
      plugin
          .getLogger()
          .warning(
              "code=ESSENTIALS_TELEPORT_REJECTED type="
                  + teleportType
                  + " player="
                  + player.getUniqueId());
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
      return false;
    }

    player.sendMessage(Component.text(successMessage, NamedTextColor.GREEN));
    return true;
  }

  private boolean hasMoved(Location start, Location current) {
    return start.getWorld() != current.getWorld()
        || start.getBlockX() != current.getBlockX()
        || start.getBlockY() != current.getBlockY()
        || start.getBlockZ() != current.getBlockZ();
  }

  private record PendingTeleport(Location startLocation) {}
}
