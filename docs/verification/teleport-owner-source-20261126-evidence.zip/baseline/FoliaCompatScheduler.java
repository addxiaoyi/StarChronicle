package dev.starcore.starcore.core.scheduler;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Folia 兼容调度器 自动检测运行环境（Paper/Folia），使用对应的调度API
 *
 * <p>设计目标： - Paper 1.21+ 环境正常运行 - Folia 环境无需修改代码 - 性能最优化
 */
public final class FoliaCompatScheduler {
  private final Plugin plugin;
  private final boolean isFolia;
  private final Object tasksLock = new Object();
  private final Set<TrackedTask> tasks = new LinkedHashSet<>();

  public FoliaCompatScheduler(Plugin plugin) {
    this(plugin, detectFolia());
  }

  FoliaCompatScheduler(Plugin plugin, boolean isFolia) {
    this.plugin = plugin;
    this.isFolia = isFolia;

    if (isFolia) {
      plugin.getLogger().info("✅ 检测到 Folia 环境，使用区域调度器");
    } else {
      plugin.getLogger().info("✅ 检测到 Paper 环境，使用传统调度器");
    }
  }

  /** 检测是否运行在 Folia 上 */
  private static boolean detectFolia() {
    try {
      Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
      return true;
    } catch (ClassNotFoundException e) {
      return false;
    }
  }

  /** 在实体所在区域执行任务（主线程安全） */
  public void runAtEntity(Entity entity, Consumer<Object> task) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    entity
                        .getScheduler()
                        .run(plugin, t -> handle.run(() -> task.accept(t)), handle::cancel))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTask(plugin, () -> handle.run(() -> task.accept(null)))));
  }

  /** 在位置所在区域执行任务（主线程安全） */
  public void runAtLocation(Location location, Consumer<Object> task) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getRegionScheduler()
                        .run(plugin, location, t -> handle.run(() -> task.accept(t))))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTask(plugin, () -> handle.run(() -> task.accept(null)))));
  }

  /** 延迟在位置所在区域执行任务 */
  public void runAtLocationDelayed(Location location, Consumer<Object> task, long delayTicks) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getRegionScheduler()
                        .runDelayed(
                            plugin, location, t -> handle.run(() -> task.accept(t)), delayTicks))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskLater(
                            plugin, () -> handle.run(() -> task.accept(null)), delayTicks)));
  }

  /** 异步执行任务 */
  public void runAsync(Runnable task) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(Bukkit.getAsyncScheduler().runNow(plugin, t -> handle.run(task)))
                : cancellation(
                    Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> handle.run(task))));
  }

  /** 延迟异步执行 */
  public void runAsyncDelayed(Runnable task, long delay, TimeUnit unit) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getAsyncScheduler()
                        .runDelayed(plugin, t -> handle.run(task), delay, unit))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskLaterAsynchronously(
                            plugin, () -> handle.run(task), unit.toMillis(delay) / 50)));
  }

  /** 定时异步执行 */
  public void runAsyncRepeating(Runnable task, long initialDelay, long period, TimeUnit unit) {
    submit(
        true,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getAsyncScheduler()
                        .runAtFixedRate(plugin, t -> handle.run(task), initialDelay, period, unit))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskTimerAsynchronously(
                            plugin,
                            () -> handle.run(task),
                            unit.toMillis(initialDelay) / 50,
                            unit.toMillis(period) / 50)));
  }

  /** 全局任务（不依赖特定区域） */
  public void runGlobal(Runnable task) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(Bukkit.getGlobalRegionScheduler().run(plugin, t -> handle.run(task)))
                : cancellation(Bukkit.getScheduler().runTask(plugin, () -> handle.run(task))));
  }

  /** 延迟在实体所在区域执行任务 */
  public void runEntityDelayed(Entity entity, Runnable task, long delayTicks) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    entity
                        .getScheduler()
                        .runDelayed(plugin, t -> handle.run(task), handle::cancel, delayTicks))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskLater(plugin, () -> handle.run(task), delayTicks)));
  }

  /** 全局延迟任务 */
  public void runDelayed(Runnable task, long delayTicks) {
    runGlobalDelayed(task, delayTicks);
  }

  /** 全局延迟任务 */
  public void runGlobalDelayed(Runnable task, long delayTicks) {
    submit(
        false,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getGlobalRegionScheduler()
                        .runDelayed(plugin, t -> handle.run(task), delayTicks))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskLater(plugin, () -> handle.run(task), delayTicks)));
  }

  /** 全局定时任务 */
  public void runGlobalRepeating(Runnable task, long initialDelayTicks, long periodTicks) {
    submit(
        true,
        handle ->
            isFolia
                ? cancellation(
                    Bukkit.getGlobalRegionScheduler()
                        .runAtFixedRate(
                            plugin, t -> handle.run(task), initialDelayTicks, periodTicks))
                : cancellation(
                    Bukkit.getScheduler()
                        .runTaskTimer(
                            plugin, () -> handle.run(task), initialDelayTicks, periodTicks)));
  }

  /**
   * Cancel this instance's currently registered work, including entity/region tasks on Folia. Other
   * instances and plugin tasks are untouched. New submissions remain allowed; a callback already
   * admitted may finish. This is cancellation, not rollback of business work.
   */
  public void cancelAll() {
    TrackedTask[] snapshot;
    synchronized (tasksLock) {
      snapshot = tasks.toArray(TrackedTask[]::new);
      tasks.clear();
    }
    for (TrackedTask task : snapshot) {
      try {
        task.cancel();
      } catch (RuntimeException | Error failure) {
        plugin.getLogger().log(Level.WARNING, "Compatibility task cancellation failed", failure);
      }
    }
  }

  private void submit(boolean repeating, Function<TrackedTask, Runnable> registration) {
    TrackedTask handle = new TrackedTask(repeating);
    synchronized (tasksLock) {
      tasks.add(handle);
    }
    try {
      handle.attach(registration.apply(handle));
    } catch (RuntimeException | Error failure) {
      cleanupAfterFailure(handle, failure);
      throw failure;
    }
  }

  private static Runnable cancellation(ScheduledTask task) {
    return task == null ? null : task::cancel;
  }

  private static Runnable cancellation(BukkitTask task) {
    return task == null ? null : task::cancel;
  }

  private static void cleanupAfterFailure(TrackedTask task, Throwable failure) {
    try {
      task.cancel();
    } catch (RuntimeException | Error cleanupFailure) {
      if (cleanupFailure != failure) failure.addSuppressed(cleanupFailure);
    }
  }

  private final class TrackedTask {
    private final boolean repeating;
    private final AtomicBoolean active = new AtomicBoolean(true);
    private Runnable backendCancellation;
    private boolean backendCancelled;

    private TrackedTask(boolean repeating) {
      this.repeating = repeating;
    }

    private void forget() {
      synchronized (tasksLock) {
        tasks.remove(this);
      }
    }

    private synchronized void attach(Runnable cancel) {
      backendCancellation = cancel;
      if (cancel == null) cancel();
      else if (!active.get()) cancelBackend();
    }

    private synchronized void cancelBackend() {
      if (backendCancellation != null && !backendCancelled) {
        backendCancelled = true;
        backendCancellation.run();
      }
    }

    private void cancel() {
      if (!active.compareAndSet(true, false)) return;
      forget();
      cancelBackend();
    }

    private void run(Runnable operation) {
      if (repeating) {
        if (!active.get()) return;
      } else {
        if (!active.compareAndSet(true, false)) return;
        forget();
      }
      try {
        operation.run();
      } catch (RuntimeException | Error failure) {
        cleanupAfterFailure(this, failure);
        throw failure;
      }
    }
  }

  /**
   * Check whether the current thread is Paper's single server thread. Folia has no single main
   * thread; callers must use entity or region ownership checks.
   */
  public boolean isMainThread() {
    return !isFolia && Bukkit.isPrimaryThread();
  }

  /** 是否运行在 Folia */
  public boolean isFolia() {
    return isFolia;
  }
}
