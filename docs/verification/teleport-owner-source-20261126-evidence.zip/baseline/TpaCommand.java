package dev.starcore.starcore.essentials.command;

import dev.starcore.starcore.essentials.teleport.TeleportService;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** TPA传送请求命令 /tpa, /tpaccept, /tpdeny, /back */
public final class TpaCommand implements CommandExecutor, TabCompleter {
  private final TeleportService teleportService;

  public TpaCommand(TeleportService teleportService) {
    this.teleportService = teleportService;
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage(Component.text("只有玩家可以使用此命令", NamedTextColor.RED));
      return true;
    }

    String commandName = command.getName().toLowerCase(Locale.ROOT);

    if (args.length >= 1 && args[0].equalsIgnoreCase("tpahere")) {
      handleTpaHere(player, args);
      return true;
    }

    switch (commandName) {
      case "tpa" -> handleTpa(player, args);
      case "tpaccept" -> handleTpAccept(player);
      case "tpdeny" -> handleTpDeny(player);
      case "back" -> handleBack(player);
      case "cooldown", "cd" -> handleCooldown(player);
      case "spawn" -> handleSpawn(player);
      case "setspawn" -> handleSetSpawn(player);
    }

    return true;
  }

  /** 请求传送 */
  private void handleTpa(Player player, String[] args) {
    if (args.length < 1) {
      player.sendMessage(
          Component.text("用法: /tpa <玩家> 或 /tpa tpahere <玩家>", NamedTextColor.YELLOW));
      return;
    }

    Player target = Bukkit.getPlayer(args[0]);

    if (target == null || !target.isOnline()) {
      player.sendMessage(Component.text("玩家不在线: " + args[0], NamedTextColor.RED));
      return;
    }

    if (target.equals(player)) {
      player.sendMessage(Component.text("你不能传送到自己", NamedTextColor.RED));
      return;
    }

    teleportService.sendTeleportRequest(player, target);
  }

  /** 接受传送 */
  private void handleTpAccept(Player player) {
    teleportService.acceptTeleportRequest(player);
  }

  /** 拒绝传送 */
  private void handleTpDeny(Player player) {
    teleportService.denyTeleportRequest(player);
  }

  /** 返回上一个位置 */
  private void handleBack(Player player) {
    teleportService.teleportBack(player);
  }

  /** 传送到主城 */
  private void handleSpawn(Player player) {
    if (!teleportService.canUseSpawn(player)) {
      player.sendMessage(Component.text("你没有权限使用此命令", NamedTextColor.RED));
      return;
    }

    teleportService.teleportToSpawn(player);
  }

  /** 设置主城传送点 */
  private void handleSetSpawn(Player player) {
    // 检查权限
    if (!teleportService.canSetSpawn(player)) {
      player.sendMessage(Component.text("你没有权限设置主城传送点", NamedTextColor.RED));
      return;
    }

    // 设置当前位置为主城
    teleportService.setSpawnLocation(player.getLocation());
    player.sendMessage(Component.text("主城传送点已设置在你的当前位置", NamedTextColor.GREEN));
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (command.getName().equalsIgnoreCase("tpa") && args.length == 1) {
      List<String> suggestions = new ArrayList<>();
      for (Player p : Bukkit.getOnlinePlayers()) {
        if (!p.equals(sender)) {
          suggestions.add(p.getName());
        }
      }
      if ("tpahere".startsWith(args[0].toLowerCase(Locale.ROOT))) {
        suggestions.add("tpahere");
      }
      return suggestions;
    }

    return List.of();
  }

  private void handleCooldown(Player player) {
    long remaining = teleportService.getRemainingCooldownSeconds(player.getUniqueId());
    int pending = teleportService.pendingRequestCount();
    if (remaining > 0) {
      player.sendMessage(
          Component.text("§7传送冷却剩余: §e" + remaining + " §7秒", NamedTextColor.YELLOW));
    } else {
      player.sendMessage(Component.text("§a传送冷却已结束，可以发送请求", NamedTextColor.GREEN));
    }
    player.sendMessage(Component.text("§7全服待处理传送请求: §f" + pending, NamedTextColor.GRAY));
  }

  /** 发送拉人传送请求 */
  private void handleTpaHere(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage(Component.text("用法: /tpa tpahere <玩家>", NamedTextColor.YELLOW));
      return;
    }
    Player target = org.bukkit.Bukkit.getPlayer(args[1]);
    if (target == null || !target.isOnline()) {
      player.sendMessage(Component.text("玩家不在线: " + args[1], NamedTextColor.RED));
      return;
    }
    if (target.equals(player)) {
      player.sendMessage(Component.text("不能对自己发送请求", NamedTextColor.RED));
      return;
    }
    teleportService.sendTeleportHereRequest(player, target);
  }
}
