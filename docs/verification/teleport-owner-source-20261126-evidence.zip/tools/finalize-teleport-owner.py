from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest();files={};runs={}
def add(path,name):files[name]=path.read_bytes()
for phase in ('baseline','compile','test-consumers','compile-tests','test-final','package','package-final','sbom','artifacts'):
 directory=root/'run'/('teleport-owner-'+phase+'-20261126')
 runs[phase]=json.loads((directory/'result.json').read_text(encoding='utf-8'))
 for path in sorted(directory.rglob('*')):
  if path.is_file() and path.suffix in ('.json','.xml','.java','.log','.txt'):add(path,phase+'/'+path.relative_to(directory).as_posix())
 if phase not in ('baseline','test-consumers','package'):assert runs[phase].get('exit_code',0)==0,phase
totals=dict(tests=0,failures=0,errors=0,skipped=0)
for path in (root/'run/teleport-owner-test-final-20261126/surefire').glob('*.xml'):
 suite=ET.parse(path).getroot()
 for key in totals:totals[key]+=int(suite.get(key,0))
assert totals==runs['test-final']['totals']==dict(tests=339,failures=0,errors=0,skipped=0)
assert runs['baseline']['totals']==dict(tests=19,failures=19,errors=0,skipped=0)
assert runs['test-consumers']['totals']==dict(tests=339,failures=0,errors=3,skipped=0)
names=['src/main/java/dev/starcore/starcore/core/scheduler/FoliaCompatScheduler.java',
 'src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java',
 'src/main/java/dev/starcore/starcore/essentials/command/TpaCommand.java',
 'src/main/java/dev/starcore/starcore/essentials/teleport/TeleportService.java',
 'src/test/java/dev/starcore/starcore/essentials/teleport/TeleportServiceComprehensiveTest.java',
 'src/test/java/dev/starcore/starcore/essentials/teleport/TeleportOwnershipTest.java',
 'src/test/java/dev/starcore/starcore/core/scheduler/FoliaCompatSchedulerBoundaryTest.java',
 'docs/TELEPORT-OWNERSHIP.md','docs/COMPAT-SCHEDULER-LIFECYCLE.md']
for name in names+['pom.xml','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties']:add(native/name,'starcore/'+name)
for name in ('starcore-1.0.0-sbom.json','starcore-1.0.0-sbom.xml'):add(native/'target'/name,'sbom/'+name)
for name in ('run-teleport-owner.py','verify-teleport-owner-artifacts.py','finalize-teleport-owner.py'):add(root/'run'/name,'tools/'+name)
for name in ('compat-lifecycle-ci-success-20261126.log','compat-lifecycle-final-ci-20261126.json','compat-lifecycle-delivery-git-20261126.json'):add(root/'run'/name,'previous-compat-ci/'+name)
files['starcore/change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=native)
plugin=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes());sources=sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes());core=sha((native/'target/starcore-1.0.0.jar').read_bytes())
assert core==runs['artifacts']['starcore_sha256']
assert plugin=='1c7b8b010c9d330c15b0882753d54095fb906e42caedb926a81055d643cd78ce'
summary={'date':'2026-11-26','scope':'Original-session player-owned TPA, asynchronous teleport outcomes, pending-attempt identity, caller retirement and delay boundaries. No Minecraft.',
 'baseline_commits':{'starchronicle':'6478dd28e586809d60bbc1da3dac3bb4962bf904','starcore':'e15b5e743984cd6ffb4ac2acfcf34a2d950f323f'},
 'packaging_initial_failure':'First Maven Wrapper/JVM launch exhausted native memory before Maven. Original crash logs retained; final retry uses the same 256 MiB options after memory recovered. The Wrapper native-access probe also failed during SBOM startup, but Maven and the 36-component BOM completed successfully; that probe log is retained separately.',
 'new_tests':37,'tests':totals,'baseline_tests':runs['baseline']['totals'],'intermediate_tests':runs['test-consumers']['totals'],
 'intermediate_errors':'Three pre-existing concurrency cases had nested Mockito stubbing introduced while adapting their player/server fixtures. Fixed test setup only; main sources did not change after compile.',
 'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':sources,'starcore_sha256':core},'artifact_verification':runs['artifacts'],
 'source_hashes':{name:sha((native/name).read_bytes()) for name in names},
 'limits':['No real Minecraft, Paper/Folia teleport transport or third-party binaries.',
  'TeleportService public player entry points require the initiating player owner; no global-thread permission is granted.',
  'Destination is a detached snapshot on its owner, not an atomic transaction across player regions.',
  'Already admitted/submitted teleports may finish; shutdown suppresses feedback and does not undo movement.',
  '339 selected tests, existing POM exclusions retained, not the complete native suite.',
  'Single 256 MiB JVM per operation; forkCount=0, jacoco.skip=true; no local coverage result.',
  'Chronicle main JAR and prior 1021-test local result are unchanged. Earlier native contracts and regressions retain their own JAR identities.',
  'Full module command teardown, other legacy scheduler/owner migrations and production server acceptance remain.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/teleport-owner-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
 for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
 manifest=json.loads(archive.read('manifest.json'));assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
 for name,digest in manifest['files'].items():assert sha(archive.read(name))==digest
summary['evidence_files']=len(files);summary['evidence_zip_sha256']=sha(output.read_bytes())
(output.parent/'teleport-owner-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# 玩家线程与原会话传送：源码验证 2026-11-26

原 TPA 流程从发送者／接收者线程直接访问另一玩家，过期全局任务也读取在线状态并发送消息；实际传送使用同步 Player.teleport，延迟回调缺少原会话核验。本次贯穿邀请、接受／拒绝、过期、目标位置采样和异步完成反馈，按各玩家 owner 执行并保留原 Player 对象。

## 当前构件与证据

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{core}` |
| Chronicle，主构件保持 | `{plugin}` |
| Chronicle 源码 JAR | `{sources}` |
| 证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线：Chronicle `6478dd2`、StarCore `e15b5e7`。[证据 ZIP](verification/teleport-owner-source-20261126-evidence.zip) **{len(files)} 文件**，含全部测试失败与最终 XML、编译／打包／SBOM、源码、API 对照和工具；[机器摘要](verification/teleport-owner-source-20261126-summary.json)。上一检查点 Linux CI #175 成功日志和交付 Git 核对另行保留在本 ZIP。没有启动 Minecraft。

## 最终行为

- TPA／TPAHERE 保存原发送者和原接收者对象，唯一 nonce 区分同毫秒的新请求；新连接不能接受旧会话请求。每次玩家回调在该玩家 owner 上检查在线及当前 UUID 映射仍为同一对象。
- 邀请、接受／拒绝和过期通知分别在对应玩家 owner 上读取名字／在线状态并发送。全局过期任务只移除独立请求状态并派发原发送者通知；命令入口也不再读取远端目标的在线状态。
- 配置延迟结束后，在目标玩家 owner 上复制位置，再回到实际传送者 owner 核验原会话和原待执行对象，调用 teleportAsync。没有阻塞等待或同步 Player.teleport；成功、拒绝或异常结果再回原玩家 owner 显示。
- 待传送对象按身份区分，旧的相同位置回调不能消费新尝试；移动／受伤／退出可在目标查询期间取消。玩家清理移除其发出及收到的请求、涉及其 UUID 的待执行传送。Essentials 停用先关闭传送服务，再取消任务；新请求和晚到反馈会失效。
- 新增兼容调度器实体退休回调重载，取消、退休、空／拒绝注册和回调失败至多清理一次，正常单次完成不触发。清理只操作独立状态，可以运行在注册或取消线程。原公开方法保留。
- tick 类零延迟使用下一 tick，负延迟及非正周期在注册前拒绝。Paper 异步正的子 tick 时间向上取整，Folia 保留传入时间单位，异步零延迟走 runNow。TimeUnit 纳秒转换对极大值饱和，换算后不会溢出为负值／零。

公开玩家操作的入口必须已在发起者 owner 上，本次没有允许任意线程直接调用所有玩家 API。目标位置是采样时的独立快照，不承诺另一玩家在实际完成时仍位于原处，也不是跨区域共同事务。已准入／提交的传送允许完成；关闭后抑制反馈，不宣称位置回滚。

## 测试与失败保留

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现所有权基线 | 19 | 19 | 0 | 0 |
| 首次完整相关回归 | 339 | 0 | 3 | 0 |
| 修正测试设置后的最终相关回归 | **339** | **0** | **0** | **0** |

新增 **37 项**：原会话／传送使用链 28，调度器边界 9。测试使用分别排队的玩家 owner，访问其他玩家的在线状态、名字、位置、消息或传送会直接断言失败；禁止同步传送，并模拟完成回包在线程外到达。覆盖两种传送方向、移动期间取消、原对象重连、相同位置的旧回调、退休／调度拒绝释放、关闭前后、独立目标快照、命令入口以及零／负／极大／子 tick 时间。

19 个基线失败分别暴露远端实体访问、同步传送、退出后发出请求残留或零延迟行为，原始 XML 与构件 SHA 保留。首次 339 项中新增 37 项全部通过，3 errors 是适配旧并发测试时嵌套调用 Mockito 的测试设置错误；只修正测试设置并重新编译测试，生产源码未再改变。没有新增测试排除。

调度、传送、经济命令、Essentials 数据异步保存／GUI／服务共同执行；339 项不是全库测试。原平台调度器／玩家使用替身，不能当作真实 Folia 区域传送验收。

本机每次单个 256 MiB JVM，forkCount=0、jacoco.skip=true 和 Mockito agent。Spotless、2,266 主源／1,086 测试源编译成功；修正测试设置后仅重新编译测试，最终运行：

```text
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=dev.starcore.starcore.core.scheduler.**,dev.starcore.starcore.essentials.** surefire:test
mvnw.cmd -o -B -ntp -Djacoco.skip=true -Dmaven.main.skip=true -Dmaven.test.skip=true verify
mvnw.cmd -B -ntp -Djacoco.skip=true cyclonedx:makeAggregateBom@generate-sbom
```

首次打包在 Wrapper／JVM 启动时因瞬时本机内存不足失败，未进入 Maven；两个 JVM 错误日志保留，可用内存恢复后以相同 256 MiB 参数重试成功。SBOM 启动时另一个 Wrapper native-access 探测 JVM 也因内存不足退出，但 Maven 与清单生成成功，其第三份错误日志单独保留。最终打包和在线 36 组件 SBOM 成功；7 个改动类与已测试 target/classes 字节相同，Java 21 字节码通过，源码与对应冻结副本一致。旧公开方法声明／描述符全保留，仅新增两个实体调度重载和 TeleportService.shutdown；没有本机 JaCoCo 结果。

Chronicle 主构件与 NPC 检查点的本地 1,021 项结果保持，本轮未本地重跑。此前 302 项、1,131 项（9 跳过）与更早国库／贸易／工厂契约均保留其原构件边界。Chronicle 文档提交推送后跟踪独立 Linux CI；StarCore 的现有触发器不覆盖基线为非 main 的草稿 PR。

## 尚未完成

完整模块命令解绑／热重载、其余 runSync／runNextTick 使用链及其他业务所有权迁移仍需继续。当前构件实服、实际 NPC／保护版本组合、全栈 Folia 和长期并发／容量验收继续待办。按用户选择只运行源码与单元测试，十阶段没有全部完成。
'''
(root/'docs/TELEPORT-OWNER-SOURCE-20261126.md').write_text(report,encoding='utf-8')
checkpoint=f'2026-11-26 最新检查点：[玩家线程与原会话传送](TELEPORT-OWNER-SOURCE-20261126.md)。TPA 邀请／过期／接受分派到各玩家 owner，目标位置复制后使用异步传送，重连与旧延迟回调失效，补齐退休清理和时间边界。新增 37 项，339 项相关回归全部通过；StarCore `{core[:8]}…{core[-6:]}` 已打包核对。其余所有权迁移、完整热重载与实服继续待办，不启动 Minecraft。'
for name in ('README.md','docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md'):
 path=root/name;text=path.read_text(encoding='utf-8')
 text='\n'.join(line for line in text.split('\n') if not line.startswith('2026-11-26 最新检查点：[玩家线程与原会话传送]'))
 heading,body=text.split('\n',1)
 note=checkpoint.replace('(TELEPORT-OWNER-SOURCE-20261126.md)','(docs/TELEPORT-OWNER-SOURCE-20261126.md)') if name=='README.md' else checkpoint
 text=heading+'\n\n'+note+'\n\n'+body.lstrip('\n')
 text=text.replace('2026-11-26 最新检查点：[兼容调度取消与 Essentials 周期生命周期]','2026-11-26 上一兼容调度检查点：[兼容调度取消与 Essentials 周期生命周期]')
 text=text.replace('兼容调度按实例取消与 Essentials 周期停用新增 28 项、302 项回归通过 | 旧 runSync／runNextTick、TPA 通知所有权、完整热重载及其他调用链仍需逐个迁移；','兼容调度按实例取消与 Essentials 周期停用新增 28 项；随后 TPA 原会话／owner／异步传送及时间边界新增 37 项、339 项回归通过 | 旧 runSync／runNextTick、完整模块命令解绑／热重载及其他调用链仍需逐个迁移；')
 text=text.replace('随后兼容调度／Essentials 生命周期 302 项全部通过 |','随后兼容调度／Essentials 生命周期 302 项全部通过；本轮玩家 owner／传送与时间边界 339 项全部通过 |')
 text=text.replace('旧 runSync／runNextTick、TPA 通知、完整热重载及 GUI、保存、Boss 等仍需逐个审计与全链路移植。','TPA 原玩家会话、独立 owner 通知／位置采样和异步传送已补齐；旧 runSync／runNextTick、完整命令解绑／热重载及其余 GUI、保存、Boss 等仍需逐个审计与全链路移植。')
 path.write_text(text,encoding='utf-8')
print(json.dumps({'tests':totals,'files':len(files),'artifacts':summary['artifacts'],'evidence_sha256':summary['evidence_zip_sha256']}))
