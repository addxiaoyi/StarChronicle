package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.*;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceTradeOwnershipTest {
  @TempDir Path directory;
  private static final NationId EXPORTER = TradeSnapshotValidationTest.EXPORTER;
  private static final NationId IMPORTER = TradeSnapshotValidationTest.IMPORTER;
  private static final NationId EXTRA = new NationId(new UUID(0, 99));

  enum Kind {
    AGREEMENT,
    ROUTE,
    EMBARGO,
    QUOTA
  }

  static Stream<Arguments> references() {
    return Stream.of(Kind.values())
        .flatMap(
            kind ->
                Stream.of("create", "get", "list", "snapshot", "restore", "matching")
                    .filter(access -> kind != Kind.AGREEMENT || !access.equals("matching"))
                    .map(access -> Arguments.of(kind, access)));
  }

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @MethodSource("references")
  void callerMutationCannotChangeServiceState(Kind kind, String access) {
    var fixture = new Fixture();
    Object exposed = fixture.reference(kind, access);
    Properties before = encode(fixture.service);
    mutate(exposed);
    assertEquals(before, encode(fixture.service));
  }

  static Stream<Arguments> invalidRestores() {
    return Stream.of(Kind.values())
        .flatMap(
            kind ->
                Stream.of("null-key", "null-value", "wrong-key")
                    .map(damage -> Arguments.of(kind, damage)));
  }

  @ParameterizedTest
  @MethodSource("invalidRestores")
  void malformedRestoreCannotClearOrPartiallyReplaceThePreviousState(Kind kind, String damage) {
    var fixture = new Fixture();
    Properties before = encode(fixture.service);
    var input = new LinkedHashMap<UUID, Object>();
    Object original = fixture.reference(kind, "get");
    input.put(id(original), original);
    switch (damage) {
      case "null-key" -> input.put(null, original);
      case "null-value" -> input.put(new UUID(0, 999), null);
      case "wrong-key" -> input.put(new UUID(0, 999), original);
      default -> throw new AssertionError(damage);
    }
    fixture.service.markAgreementsDirtyForRetry();
    assertThrows(IllegalArgumentException.class, () -> restore(fixture.service, kind, input));
    assertTrue(fixture.service.isAgreementsDirty());
    assertEquals(before, encode(fixture.service));
  }

  @ParameterizedTest
  @EnumSource(Kind.class)
  void nullRestoreStillClearsOnlyItsCollection(Kind kind) {
    var fixture = new Fixture();
    restore(fixture.service, kind, null);
    var state = encode(fixture.service);
    for (Kind entry : Kind.values())
      assertEquals(
          entry == kind ? "0" : "1",
          state.getProperty(entry.name().toLowerCase(Locale.ROOT) + ".count"));
  }

  @Test
  void restoreAndOutputCopiesPreserveEveryHistoricalField() {
    var fixture = new Fixture();
    assertEquals(fixture.source, TradeSnapshotValidationTest.tradeFields(encode(fixture.service)));
  }

  @Test
  void referenceCannotLiftAnEmbargoAndAllowAForbiddenTrade() {
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(EXPORTER, "iron")).thenReturn(5L);
    when(resources.consume(EXPORTER, "iron", 5)).thenReturn(true);
    when(resources.grant(IMPORTER, "iron", 5)).thenReturn(true);
    var service = new SimpleResourceTradeService(resources);
    var agreement = service.createTradeAgreement(EXPORTER, IMPORTER, "iron", 5, 2, 300);
    var embargo = service.createEmbargo(EXPORTER, Set.of(IMPORTER), "iron", null, "blocked");
    service.getEmbargo(embargo.embargoId()).orElseThrow().setActive(false);
    assertFalse(service.executeTradeAgreement(agreement.agreementId()));
    verify(resources, never()).consume(any(), any(), anyLong());
    assertTrue(service.isEmbargoed(EXPORTER, IMPORTER, "iron"));
    assertTrue(service.liftEmbargo(EXPORTER, embargo.embargoId()));
    assertFalse(service.isEmbargoed(EXPORTER, IMPORTER, "iron"));
    assertTrue(embargo.isActive(), "old views retain their original state");
  }

  @Test
  void resettingAReadQuotaCannotBypassExhaustion() {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var quota = service.createQuota(EXPORTER, "iron", 5, 300, ResourceQuota.QuotaType.EXPORT);
    assertTrue(service.useQuota(quota.quotaId(), 5));
    service.getQuota(quota.quotaId()).orElseThrow().reset();
    assertFalse(service.useQuota(quota.quotaId(), 1));
    assertEquals(5, service.getQuota(quota.quotaId()).orElseThrow().currentAmount());
    assertEquals(0, quota.currentAmount(), "created views do not track later usage");
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void tradeUpdatesOwnedQuotaAndRouteWhileOldSnapshotsRemainStable(boolean delivered) {
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(EXPORTER, "iron")).thenReturn(5L);
    when(resources.consume(EXPORTER, "iron", 5)).thenReturn(true);
    when(resources.grant(IMPORTER, "iron", 5)).thenReturn(delivered);
    when(resources.grant(EXPORTER, "iron", 5)).thenReturn(true);
    var service = new SimpleResourceTradeService(resources);
    var route = service.createTradeRoute(EXPORTER, IMPORTER, "harbor");
    var exported = service.createQuota(EXPORTER, "iron", 5, 300, ResourceQuota.QuotaType.EXPORT);
    var imported = service.createQuota(IMPORTER, "iron", 5, 300, ResourceQuota.QuotaType.IMPORT);
    var agreement = service.createTradeAgreement(EXPORTER, IMPORTER, "iron", 5, 2, 300);
    var oldQuotas = service.snapshotQuotas();
    var oldRoutes = service.snapshotRoutes();
    assertEquals(delivered, service.executeTradeAgreement(agreement.agreementId()));
    long used = delivered ? 5 : 0;
    assertEquals(used, service.getQuota(exported.quotaId()).orElseThrow().currentAmount());
    assertEquals(used, service.getQuota(imported.quotaId()).orElseThrow().currentAmount());
    assertEquals(used, service.getTradeRoute(route.routeId()).orElseThrow().totalTradeVolume());
    assertEquals(0, oldQuotas.get(exported.quotaId()).currentAmount());
    assertEquals(0, oldQuotas.get(imported.quotaId()).currentAmount());
    assertEquals(0, oldRoutes.get(route.routeId()).totalTradeVolume());
    if (delivered) {
      assertFalse(service.executeTradeAgreement(agreement.agreementId()));
      verify(resources, times(1)).consume(EXPORTER, "iron", 5);
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void detachedMutationsCannotPolluteTheNextInventorySaveOrRestart(String engine) throws Exception {
    var helper = new TradeSnapshotValidationTest();
    helper.directory = directory;
    var storage = helper.seeded(engine);
    var module = TradeSnapshotValidationTest.module(storage);
    var service = (SimpleResourceTradeService) module.getTradeService();
    var before = TradeSnapshotValidationTest.tradeFields(storage.load());
    service.snapshotAgreements().values().forEach(ResourceTradeOwnershipTest::mutate);
    service.snapshotRoutes().values().forEach(ResourceTradeOwnershipTest::mutate);
    service.snapshotEmbargoes().values().forEach(ResourceTradeOwnershipTest::mutate);
    service.snapshotQuotas().values().forEach(ResourceTradeOwnershipTest::mutate);
    assertTrue(module.grant(EXPORTER, "luxury", 1));
    assertEquals(before, TradeSnapshotValidationTest.tradeFields(storage.load()));
    assertEquals(
        before,
        TradeSnapshotValidationTest.encodedTrade(TradeSnapshotValidationTest.module(storage)));
  }

  private static Properties encode(SimpleResourceTradeService service) {
    return ResourceStateCodec.toProperties(
        Map.of(),
        Map.of(),
        Map.of(),
        service.snapshotAgreements(),
        service.snapshotRoutes(),
        service.snapshotEmbargoes(),
        service.snapshotQuotas());
  }

  private static UUID id(Object value) {
    return switch (value) {
      case TradeAgreement a -> a.agreementId();
      case TradeRoute r -> r.routeId();
      case ResourceEmbargo e -> e.embargoId();
      case ResourceQuota q -> q.quotaId();
      default -> throw new AssertionError(value);
    };
  }

  private static void mutate(Object value) {
    switch (value) {
      case TradeAgreement a -> a.setAutoRenew(!a.isAutoRenew());
      case TradeRoute r -> {
        r.setEfficiency(0.5);
        r.setActive(!r.isActive());
        r.addTradeVolume(12);
      }
      case ResourceEmbargo e -> {
        e.setActive(!e.isActive());
        e.addTargetNation(EXTRA);
        e.removeTargetNation(IMPORTER);
      }
      case ResourceQuota q -> {
        q.reset();
        assertTrue(q.use(1));
      }
      default -> throw new AssertionError(value);
    }
  }

  @SuppressWarnings({"rawtypes", "unchecked"})
  private static void restore(SimpleResourceTradeService service, Kind kind, Map<UUID, ?> values) {
    switch (kind) {
      case AGREEMENT -> service.restoreAgreements((Map) values);
      case ROUTE -> service.restoreRoutes((Map) values);
      case EMBARGO -> service.restoreEmbargoes((Map) values);
      case QUOTA -> service.restoreQuotas((Map) values);
    }
  }

  private static class Fixture {
    final SimpleResourceTradeService service =
        new SimpleResourceTradeService(mock(ResourceService.class));
    final Properties source = TradeSnapshotValidationTest.validTrade();
    final ResourceStateCodec.Snapshot original;

    Fixture() {
      source.setProperty("embargo.0.active", "true");
      original = ResourceStateCodec.snapshotFromProperties(source, ResourceModule.RESOURCE_TYPES);
      service.restoreAgreements(original.agreements());
      service.restoreRoutes(original.routes());
      service.restoreEmbargoes(original.embargoes());
      service.restoreQuotas(original.quotas());
    }

    Object reference(Kind kind, String access) {
      UUID agreement = TradeSnapshotValidationTest.AGREEMENT;
      UUID route = TradeSnapshotValidationTest.ROUTE;
      UUID embargo = TradeSnapshotValidationTest.EMBARGO;
      UUID quota = TradeSnapshotValidationTest.QUOTA;
      return switch (kind) {
        case AGREEMENT ->
            switch (access) {
              case "create" ->
                  service.createTradeAgreement(EXPORTER, IMPORTER, "iron", 3, 2.5, 300);
              case "get" -> service.getTradeAgreement(agreement).orElseThrow();
              case "list" -> service.getTradeAgreements(EXPORTER).iterator().next();
              case "snapshot" -> service.snapshotAgreements().get(agreement);
              case "restore" -> original.agreements().get(agreement);
              default -> throw new AssertionError(access);
            };
        case ROUTE ->
            switch (access) {
              case "create" -> service.createTradeRoute(EXPORTER, IMPORTER, "new route");
              case "get" -> service.getTradeRoute(route).orElseThrow();
              case "list" -> service.getTradeRoutes(EXPORTER).iterator().next();
              case "snapshot" -> service.snapshotRoutes().get(route);
              case "restore" -> original.routes().get(route);
              case "matching" -> service.getTradeRouteBetween(EXPORTER, IMPORTER).orElseThrow();
              default -> throw new AssertionError(access);
            };
        case EMBARGO ->
            switch (access) {
              case "create" ->
                  service.createEmbargo(EXPORTER, Set.of(IMPORTER), "iron", null, "new embargo");
              case "get" -> service.getEmbargo(embargo).orElseThrow();
              case "list" -> service.getEmbargoesBy(EXPORTER).iterator().next();
              case "snapshot" -> service.snapshotEmbargoes().get(embargo);
              case "restore" -> original.embargoes().get(embargo);
              case "matching" -> service.getEmbargoesAgainst(IMPORTER).iterator().next();
              default -> throw new AssertionError(access);
            };
        case QUOTA ->
            switch (access) {
              case "create" ->
                  service.createQuota(IMPORTER, "iron", 10, 300, ResourceQuota.QuotaType.IMPORT);
              case "get" -> service.getQuota(quota).orElseThrow();
              case "list" -> service.getQuotas(IMPORTER).iterator().next();
              case "snapshot" -> service.snapshotQuotas().get(quota);
              case "restore" -> original.quotas().get(quota);
              case "matching" ->
                  service.getQuota(IMPORTER, "iron", ResourceQuota.QuotaType.IMPORT).orElseThrow();
              default -> throw new AssertionError(access);
            };
      };
    }
  }
}
