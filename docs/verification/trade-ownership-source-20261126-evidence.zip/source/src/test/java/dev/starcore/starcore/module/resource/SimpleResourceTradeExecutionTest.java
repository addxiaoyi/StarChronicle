package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.ResourceQuota;
import dev.starcore.starcore.module.resource.model.TradeAgreement;
import dev.starcore.starcore.module.treasury.NationTransferService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class SimpleResourceTradeExecutionTest {

  @Test
  void failedImportGrantRestoresTheExportedResourceBeforeRejecting() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(false);
    when(resources.grant(exporter, "iron", 5L)).thenReturn(true);
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThat(service.executeTradeAgreement(agreement.agreementId())).isFalse();

    verify(resources).grant(exporter, "iron", 5L);
  }

  @Test
  void failedExporterRestoreSurfacesARecoverableCriticalFailure() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(false);
    when(resources.grant(exporter, "iron", 5L)).thenReturn(false);
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThatThrownBy(() -> service.executeTradeAgreement(agreement.agreementId()))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining(agreement.agreementId().toString());
  }

  @Test
  void executionMovesTreasuryFundsAndConsumesImportAndExportQuotas() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(true);
    TreasuryService treasury = mock(TreasuryService.class);
    when(treasury.transfer(importer, exporter, new BigDecimal("50.00"))).thenReturn(true);
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources, treasury);
    ResourceQuota exportQuota =
        service.createQuota(exporter, "iron", 5, 300, ResourceQuota.QuotaType.EXPORT);
    ResourceQuota importQuota =
        service.createQuota(importer, "iron", 5, 300, ResourceQuota.QuotaType.IMPORT);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThat(service.executeTradeAgreement(agreement.agreementId())).isTrue();
    assertThat(service.getQuota(exportQuota.quotaId()).orElseThrow().currentAmount()).isEqualTo(5);
    assertThat(service.getQuota(importQuota.quotaId()).orElseThrow().currentAmount()).isEqualTo(5);
    assertThat(exportQuota.currentAmount()).isZero();
    assertThat(importQuota.currentAmount()).isZero();
    verify(treasury).transfer(importer, exporter, new BigDecimal("50.00"));
  }

  @Test
  void failedResourceDeliveryReversesTreasuryAndQuotaReservations() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(false);
    when(resources.grant(exporter, "iron", 5L)).thenReturn(true);
    TreasuryService treasury = mock(TreasuryService.class);
    when(treasury.transfer(any(), any(), eq(new BigDecimal("50.00")))).thenReturn(true);
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources, treasury);
    ResourceQuota exportQuota =
        service.createQuota(exporter, "iron", 5, 300, ResourceQuota.QuotaType.EXPORT);
    ResourceQuota importQuota =
        service.createQuota(importer, "iron", 5, 300, ResourceQuota.QuotaType.IMPORT);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThat(service.executeTradeAgreement(agreement.agreementId())).isFalse();
    assertThat(service.getQuota(exportQuota.quotaId()).orElseThrow().currentAmount()).isZero();
    assertThat(service.getQuota(importQuota.quotaId()).orElseThrow().currentAmount()).isZero();
    assertThat(exportQuota.currentAmount()).isZero();
    assertThat(importQuota.currentAmount()).isZero();
    verify(treasury, times(2)).transfer(any(), any(), eq(new BigDecimal("50.00")));
  }

  @Test
  void structuredTreasuryUsesDeterministicTradeTransactionId() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(true);
    TreasuryService treasury =
        mock(
            TreasuryService.class,
            org.mockito.Mockito.withSettings().extraInterfaces(NationTransferService.class));
    NationTransferService transfers = (NationTransferService) treasury;
    when(transfers.transfer(any()))
        .thenAnswer(
            invocation -> {
              NationTransferService.TransferRequest request = invocation.getArgument(0);
              return new NationTransferService.TransferResult(
                  NationTransferService.TransferStatus.APPLIED,
                  request.transactionId(),
                  BigDecimal.ZERO,
                  BigDecimal.ZERO);
            });
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources, treasury);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThat(service.executeTradeAgreement(agreement.agreementId())).isTrue();
    org.mockito.ArgumentCaptor<NationTransferService.TransferRequest> request =
        org.mockito.ArgumentCaptor.forClass(NationTransferService.TransferRequest.class);
    verify(transfers).transfer(request.capture());
    assertThat(request.getValue().transactionId())
        .matches("resource-trade:" + agreement.agreementId() + ":[0-9a-f-]+:debit");
  }

  @Test
  void structuredTreasuryUsesStableRollbackAfterResourceDeliveryFailure() {
    NationId exporter = NationId.random();
    NationId importer = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(false);
    when(resources.grant(exporter, "iron", 5L)).thenReturn(true);
    TreasuryService treasury =
        mock(
            TreasuryService.class,
            org.mockito.Mockito.withSettings().extraInterfaces(NationTransferService.class));
    NationTransferService transfers = (NationTransferService) treasury;
    List<String> transactionIds = new ArrayList<>();
    when(transfers.transfer(any()))
        .thenAnswer(
            invocation -> {
              NationTransferService.TransferRequest request = invocation.getArgument(0);
              transactionIds.add(request.transactionId());
              return new NationTransferService.TransferResult(
                  NationTransferService.TransferStatus.APPLIED,
                  request.transactionId(),
                  BigDecimal.ZERO,
                  BigDecimal.ZERO);
            });
    SimpleResourceTradeService service = new SimpleResourceTradeService(resources, treasury);
    TradeAgreement agreement =
        service.createTradeAgreement(exporter, importer, "iron", 5, 10.0, 300);

    assertThat(service.executeTradeAgreement(agreement.agreementId())).isFalse();
    assertThat(transactionIds).hasSize(2);
    assertThat(transactionIds.get(0))
        .matches("resource-trade:" + agreement.agreementId() + ":[0-9a-f-]+:debit");
    assertThat(transactionIds.get(1))
        .isEqualTo(transactionIds.get(0).replace(":debit", ":rollback"));
  }
}
