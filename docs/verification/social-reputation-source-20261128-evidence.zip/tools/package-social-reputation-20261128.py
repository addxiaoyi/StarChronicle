from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda data:hashlib.sha256(data).hexdigest()
tests=json.loads((root/'run/native-social-reputation-focused-2-20261128/result.json').read_text())
offline=json.loads((root/'run/social-reputation-offline-1-20261128/result.json').read_text())
pair=json.loads((root/'run/social-reputation-pair-artifacts-1-20261128/result.json').read_text())
assert tests['validation_success'] and tests['totals']==dict(tests=176,failures=0,errors=0,skipped=0)
assert offline['status']==pair['status']=='VERIFIED' and len(offline['runs'])==12
files={}
for label,name in [('validation','native-social-reputation-focused-2-20261128'),('offline','social-reputation-offline-1-20261128'),('pair','social-reputation-pair-artifacts-1-20261128'),('frozen','social-reputation-frozen-pair-1-20261128')]:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class'):
            files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['command.json','result.json','maven.log']:
    files['initial-compile-failure/'+name]=root/'run/native-social-reputation-focused-1-20261128'/name
for name in ['tools/ReputationRecoveryProbe.java','tools/verify-reputation.py','tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','run/package-social-reputation-20261128.py','run/reputation-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:sha(path.read_bytes()) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,
    'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],
    'artifacts':json.loads((root/'run/social-reputation-frozen-pair-1-20261128/manifest.json').read_text()),
    'offline_jvms':len(offline['runs']),'offline_checks':offline['checks'],'fixtures_compiled':pair['fixtures']['count'],
    'limits':['176 related tests; not the whole StarCore suite.',
              'SQLite replica verification only. MySQL and real player/server workflows are not validated.',
              'Old timestamp-keyed history API remains lossy for equal timestamps; the new list API preserves them.',
              'Rankings reflect loaded and locally committed profiles, without external-writer refresh.',
              'Shutdown waits at most five seconds; interrupted in-flight JDBC completion remains driver-dependent.',
              'No new claim for old native JAR live or unrelated offline results; Chronicle product remains 53562a2 / 1195 full tests.']}
out=root/'docs/verification/social-reputation-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,digest in manifest.items():assert sha(archive.read(name))==digest,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=sha(out.read_bytes()),files=manifest)
(root/'docs/verification/social-reputation-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','evidence_members','evidence_bytes','evidence_sha256')}))
