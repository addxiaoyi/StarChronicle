import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


text = (root / 'run/legacy-import-resource-test-20261126.log').read_text(encoding='utf-8', errors='replace')
assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text
package_log = (root / 'run/legacy-import-package-20261126.log').read_text(encoding='utf-8', errors='replace')
assert 'BUILD SUCCESS' in package_log and 'BUILD FAILURE' not in package_log
totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
by_package = {}
new_tests = None
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', text):
    report = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(report.read_bytes())
    package = 'resource' if '.resource.' in name else 'technology'
    by_package[package] = by_package.get(package, 0) + int(suite.attrib['tests'])
    for key in totals:
        totals[key] += int(suite.attrib[key])
    if name.endswith('.LegacyResourceImportValidationTest'):
        new_tests = int(suite.attrib['tests'])
    add(report, 'native-final/surefire/' + report.name)
assert new_tests == 22
assert by_package == {'resource': 962, 'technology': 13}
assert all(totals[key] == 0 for key in ('failures', 'errors', 'skipped'))
red_xml = next((root / 'run/legacy-import-red-20261126').glob('TEST-*.xml'))
red = ET.fromstring(red_xml.read_bytes())
red_totals = {key: int(red.attrib[key]) for key in totals}
assert red_totals == {'tests': 22, 'failures': 18, 'errors': 0, 'skipped': 0}
for path in (root / 'run/legacy-import-red-20261126').iterdir():
    add(path, 'red/' + path.name)
for directory in (root / 'run').glob('legacy-import-failure-*'):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.xml', '.java'):
            add(path, 'prior-failures/' + directory.name + '/' + path.name)
for path in (root / 'run').glob('legacy-import-*.log'):
    add(path, 'logs/' + path.name)
add(root / 'run/trade-lock-final-ci-20261126.json', 'github/baseline-ci.json')
directory = root / 'run/factory-contract-legacy-import-20261126-1'
contract = json.loads((directory / 'manifest.json').read_text())
assert contract['status'] == 'PASS'
for path in directory.rglob('*'):
    if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java'):
        add(path, 'factory/' + path.relative_to(directory).as_posix())
capacity_dir = root / 'run/factory-archive-legacy-import-20261126-1'
capacity = json.loads((capacity_dir / 'manifest.json').read_text())
assert capacity['status'] == 'PASS'
for path in capacity_dir.rglob('*'):
    if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java'):
        add(path, 'capacity/' + path.relative_to(capacity_dir).as_posix())
for name in ('FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
for name in ('FactoryRecoveryProbe.java', 'FactoryArchiveProbe.java', 'run-factory-archive-capacity.py', 'run-factory-stable-capacity.py', 'run-capacity-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-legacy-import-evidence.py')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
source_hashes = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        source_hashes[name] = digest((native / name).read_bytes())
starcore_hash = digest((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle_hash = digest((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore_hash == contract['artifacts']['starcore.jar']
assert chronicle_hash == contract['artifacts']['starchronicle.jar']
assert starcore_hash == capacity['artifacts']['current.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': '03d91adc7b50f2bd4f1b2f0706484988f2720a75',
                  'starcore': '2dd18c8ab9deaff532ada10922e0f1fd632d6aff'},
    'scope': 'Validate initial file snapshot before writing SQL rows and migration marker; rollback leaves all five tables empty and source unchanged, repaired source can retry without SQL cleanup; resource and research regressions, packaged factory and capacity contracts; no Minecraft',
    'red_tests': red_totals, 'native_tests': totals, 'tests_by_package': by_package,
    'new_legacy_import_tests': new_tests,
    'packaging': 'Tests and packaging ran in separate sequential 256 MiB JVMs. Fresh verify skips recompilation and tests, uses the tested class output, runs packaging and format checks. Independent online SBOM.',
    'chronicle_tests': 'Main source unchanged; previous 957-test JAR. Baseline Linux Maven verification #123 passed. No new local full verify.',
    'artifacts': {'starcore_sha256': starcore_hash, 'starchronicle_sha256': chronicle_hash},
    'factory_contract': contract, 'capacity_contract': capacity, 'native_source_hashes': source_hashes,
    'coverage': 'No current native full suite or JaCoCo; forkCount=0 and jacoco.skip=true',
    'limits': [
        'Preflight runs only while the migration marker is absent and SQL state is empty; receipt-only migration into existing SQL is preserved and live inventory can differ from retained file.',
        'Already committed invalid imports from previous builds require evidence-based recovery and are not automatically overwritten.',
        'Retained legacy file changes, arbitrary valid-format tampering and multiple writers are not authenticated by these checks.',
        'SQLite/H2 and bounded factory capacity probes do not certify sustained concurrent throughput, Folia, Minecraft, MySQL or third-party plugin stacks.'
    ]
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: digest(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/legacy-import-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(archive.read(name)) == expected
summary['evidence_zip_sha256'] = digest(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'legacy-import-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': by_package, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
