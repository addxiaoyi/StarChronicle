package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class LegacyResourceImportValidationTest {
  @TempDir Path directory;
  static final List<String> TABLES =
      List.of(
          "starcore_resource_state",
          "starcore_resource_state_migrations",
          "starcore_resource_production_receipts",
          "starcore_resource_transfer_receipts",
          "starcore_resource_factory_archive");

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static Stream<Arguments> enginesAndDamage() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(
                        "inventory",
                        "receipt",
                        "agreement",
                        "route",
                        "embargo",
                        "quota",
                        "factory-head",
                        "factory-receipt",
                        "authority",
                        "huge-count")
                    .map(damage -> Arguments.of(engine, damage)));
  }

  @ParameterizedTest
  @MethodSource("enginesAndDamage")
  void rejectedInitialFileLeavesAllSqlDataAndMigrationMarkersEmpty(String engine, String damage)
      throws Exception {
    var helper = new SqlFactoryArchiveTest();
    helper.directory = directory;
    var db = helper.database(engine);
    var source = valid();
    var original = FactorySnapshotVersionTest.copy(source);
    corrupt(source, damage);
    var damaged = FactorySnapshotVersionTest.copy(source);
    var storage = SqlFactoryArchiveTest.storage(db, source);
    assertAll(
        () -> assertThrows(IllegalStateException.class, storage::load),
        () -> assertEquals(damaged, source),
        () -> assertEmpty(db));
    // A corrected file can be imported by the same storage without deleting poisoned SQL rows.
    source.clear();
    source.putAll(original);
    var module = TradeSnapshotValidationTest.module(storage);
    assertFalse(module.authorityDomainId().isBlank());
    assertEquals(6, module.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(
        TradeSnapshotValidationTest.tradeFields(original),
        TradeSnapshotValidationTest.encodedTrade(module));
    assertEquals(3, storage.latestProductionSequence());
    assertEquals("paid", module.transactionReceipt("paid").orElseThrow().transactionId());
    assertEquals(original, source);
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void retainedLegacyInventoryMayDifferAfterSuccessfulLiveBusinessWrites(String engine)
      throws Exception {
    var helper = new SqlFactoryArchiveTest();
    helper.directory = directory;
    var source = valid();
    var original = FactorySnapshotVersionTest.copy(source);
    var storage = SqlFactoryArchiveTest.storage(helper.database(engine), source);
    var module = TradeSnapshotValidationTest.module(storage);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "luxury", 1));
    assertEquals(original, source);
    var restarted = TradeSnapshotValidationTest.module(storage);
    assertFalse(restarted.authorityDomainId().isBlank());
    assertEquals(1, restarted.amount(FactorySnapshotVersionTest.NATION, "luxury"));
    assertEquals(
        TradeSnapshotValidationTest.tradeFields(original),
        TradeSnapshotValidationTest.encodedTrade(restarted));
  }

  static Properties valid() throws Exception {
    var source = FactorySnapshotVersionTest.legacy();
    source.putAll(TradeSnapshotValidationTest.validTrade());
    source.setProperty("transaction.count", "1");
    source.setProperty("transaction.0.id", "paid");
    source.setProperty("transaction.0.nationId", FactorySnapshotVersionTest.NATION.toString());
    source.setProperty("transaction.0.operation", "CONSUME");
    source.setProperty("transaction.0.category", "RESEARCH");
    source.setProperty("transaction.0.resources", "industrial=2");
    source.setProperty("transaction.0.description", "original payment");
    source.setProperty("transaction.0.appliedAt", "123456");
    return source;
  }

  static void corrupt(Properties p, String damage) {
    switch (damage) {
      case "inventory" -> p.setProperty("stockpile.0.amount", "bad");
      case "receipt" -> p.remove("transaction.0.appliedAt");
      case "agreement", "route", "embargo", "quota" -> p.remove(damage + ".0.id");
      case "factory-head" -> p.setProperty(FactoryRunStore.PREFIX + "head", "bad");
      case "factory-receipt" -> {
        p.setProperty(FactoryRunStore.PREFIX + "row.0.inputs", "mineral=999");
        try {
          FactorySnapshotVersionTest.rehash(p);
        } catch (Exception e) {
          throw new IllegalStateException(e);
        }
      }
      case "authority" -> p.setProperty("resource.authority-domain", "invalid");
      case "huge-count" -> p.setProperty("agreement.count", Integer.toString(Integer.MAX_VALUE));
      default -> throw new IllegalArgumentException(damage);
    }
  }

  static void assertEmpty(DataSource db) throws Exception {
    try (var c = db.getConnection();
        var statement = c.createStatement()) {
      for (String table : TABLES) {
        try (var rows = statement.executeQuery("SELECT COUNT(*) FROM " + table)) {
          assertTrue(rows.next());
          assertEquals(0, rows.getLong(1), table);
        }
      }
    }
  }
}
