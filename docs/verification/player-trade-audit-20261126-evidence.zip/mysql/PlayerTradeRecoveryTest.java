package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.CREDIT_INTENT;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.DEBIT_ACKNOWLEDGED;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.DEBIT_INTENT;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.OFFERED;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.PROJECTED;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.REFUND_ACKNOWLEDGED;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.REFUND_INTENT;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.RESERVED;
import static dev.starcore.starcore.module.resource.PlayerTradeRecoveryService.State.SETTLED;
import static dev.starcore.starcore.module.resource.PlayerTradeService.ActionStatus.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.WalletOperation;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.module.treasury.TreasuryModule;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.sqlite.SQLiteDataSource;

class PlayerTradeRecoveryTest {
  @TempDir Path directory;
  private DataSource rawSource;
  private DataSource source;
  private ResourceModule resources;
  private SqlResourceStateStorage storage;
  private TreasuryModule treasury;
  private DurablePlayerTrades trades;
  private final UUID buyer = UUID.randomUUID(), seller = UUID.randomUUID();
  private final Nation buying = new Nation(NationId.random(), "Buying", buyer, "Buyer");
  private final Nation selling = new Nation(NationId.random(), "Selling", seller, "Seller");
  private final NationService nations = mock(NationService.class);
  private final Wallet wallet = new Wallet();
  private Clock clock = Clock.fixed(Instant.parse("2026-11-26T00:00:00Z"), ZoneOffset.UTC);
  private String failState;
  private boolean failAfterCommit, failReadsAfter, unavailable;
  private final AtomicBoolean faultArmed = new AtomicBoolean();
  private boolean projectionsWork = true;
  private boolean tariffsAvailable = true;
  private boolean ownerThread = true;
  private final List<UUID> notified = new ArrayList<>();
  private final Map<UUID, String> projected = new HashMap<>();
  private BigDecimal fee = new BigDecimal("1.00"), tariff = new BigDecimal("2.00");

  protected DataSource newSource() throws Exception {
    var sqlite = new SQLiteDataSource();
    sqlite.setUrl("jdbc:sqlite:" + directory.resolve("trades.db"));
    sqlite.setBusyTimeout(5000);
    try (var c = sqlite.getConnection();
        var statement = c.createStatement()) {
      statement.execute("PRAGMA journal_mode=WAL");
    }
    return sqlite;
  }

  @BeforeEach
  void setup() throws Exception {
    rawSource = newSource();
    source =
        (DataSource)
            Proxy.newProxyInstance(
                getClass().getClassLoader(),
                new Class<?>[] {DataSource.class},
                (proxy, method, args) -> {
                  if (unavailable && method.getName().equals("getConnection"))
                    throw new SQLException("store unavailable");
                  Object value = invoke(method, rawSource, args);
                  if (!(value instanceof Connection c)) return value;
                  AtomicBoolean matching = new AtomicBoolean();
                  return Proxy.newProxyInstance(
                      getClass().getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (ignored, call, parameters) -> {
                        Object answer;
                        if (call.getName().equals("commit")
                            && matching.get()
                            && faultArmed.compareAndSet(true, false)) {
                          if (failAfterCommit) invoke(call, c, parameters);
                          if (failReadsAfter) unavailable = true;
                          throw new SQLException("injected commit outcome loss");
                        }
                        answer = invoke(call, c, parameters);
                        if (answer instanceof PreparedStatement statement
                            && parameters[0]
                                .toString()
                                .startsWith("INSERT INTO starcore_player_trade_events")) {
                          return Proxy.newProxyInstance(
                              getClass().getClassLoader(),
                              new Class<?>[] {PreparedStatement.class},
                              (p, action, values) -> {
                                if (action.getName().equals("setString")
                                    && values[0].equals(4)
                                    && values[1]
                                        .toString()
                                        .contains("\"state\":\"" + failState + "\""))
                                  matching.set(true);
                                return invoke(action, statement, values);
                              });
                        }
                        return answer;
                      });
                });
    when(nations.nationOf(buyer)).thenReturn(Optional.of(buying));
    when(nations.nationOf(seller)).thenReturn(Optional.of(selling));
    wallet.balances.put(buyer, new BigDecimal("1000.00"));
    wallet.balances.put(seller, new BigDecimal("10.00"));
    restart();
    assertThat(resources.grant(selling.id(), "mineral", 200)).isTrue();
    assertThat(treasury.tryDeposit(buying.id(), new BigDecimal("10.00"))).isTrue();
  }

  @AfterEach
  void stop() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  private void restart() throws Exception {
    storage = new SqlResourceStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    resources = new ResourceModule(storage);
    Class<?> type = Class.forName("dev.starcore.starcore.module.treasury.SqlTreasuryStateStorage");
    var constructor = type.getDeclaredConstructor(DataSource.class, Properties.class, Logger.class);
    constructor.setAccessible(true);
    Object state = constructor.newInstance(source, new Properties(), Logger.getAnonymousLogger());
    treasury = new TreasuryModule();
    var field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(treasury, state);
    var load = TreasuryModule.class.getDeclaredMethod("loadState");
    load.setAccessible(true);
    load.invoke(treasury);
    var fees = mock(TradeTaxService.class);
    when(fees.calculateTaxBD(anyString(), any(), any())).thenAnswer(i -> fee);
    var tariffs =
        new ResourceTariff(
            (id, nation, tax, payer, gross) ->
                new TaxationService.TaxQuote(id, nation, tax, payer, gross, tariff),
            q -> {
              throw new AssertionError("Legacy tariff funding must not be called");
            },
            q -> {
              throw new AssertionError("Legacy tariff reversal must not be called");
            },
            (a, b, c, d, e) -> {
              throw new AssertionError("Legacy business write must not be called");
            });
    trades =
        new DurablePlayerTrades(
            resources,
            storage,
            treasury,
            wallet,
            nations,
            fees,
            () -> tariffsAvailable ? tariffs : null,
            clock,
            () -> ownerThread,
            s -> {
              if (!projectionsWork) throw new IllegalStateException("projection unavailable");
              String value = PlayerTradeRecoveryCodec.encode(s);
              assertThat(projected.putIfAbsent(s.terms().id(), value)).isIn(null, value);
              return true;
            });
    trades.setSettlementListener(s -> notified.add(s.terms().id()));
  }

  private UUID offer() {
    UUID id = UUID.randomUUID();
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.50, 300)
                .status())
        .isEqualTo(APPLIED);
    return id;
  }

  @Test
  void laterTaxationRegistrationIsResolvedAtOfferCreationAndMissingServiceFailsClosed() {
    tariffsAvailable = false;
    UUID id = UUID.randomUUID();
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .status())
        .isEqualTo(SETTLEMENT_PENDING);
    assertThat(trades.inspect(buyer, id)).isEmpty();
    tariffsAvailable = true;
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .applied())
        .isTrue();
    assertThat(state(id).terms().tariffMinor()).isEqualTo(200);
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assets(180, 20, "60", "947", "13");
  }

  private PlayerTradeRecoveryService.Snapshot state(UUID id) {
    return trades.inspect(seller, id).orElseThrow();
  }

  private void assets(
      long sellerStock, long buyerStock, String sellerMoney, String buyerMoney, String taxMoney) {
    assertThat(resources.amount(selling.id(), "mineral")).isEqualTo(sellerStock);
    assertThat(resources.amount(buying.id(), "mineral")).isEqualTo(buyerStock);
    assertThat(wallet.getBalance(seller)).isEqualByComparingTo(sellerMoney);
    assertThat(wallet.getBalance(buyer)).isEqualByComparingTo(buyerMoney);
    assertThat(treasury.balance(buying.id())).isEqualByComparingTo(taxMoney);
  }

  private void fail(PlayerTradeRecoveryService.State state, boolean after) {
    failState = state.name();
    failAfterCommit = after;
    faultArmed.set(true);
  }

  private void sql(String query) throws SQLException {
    try (var c = rawSource.getConnection();
        var s = c.createStatement()) {
      s.execute(query);
    }
  }

  @Test
  void normalSaleRestartsReplaysAndPreservesOriginalActorsExactTaxesAndFrozenTerms()
      throws Exception {
    UUID id = offer();
    fee = new BigDecimal("9.00");
    tariff = new BigDecimal("12.00");
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(APPLIED);
    assets(180, 20, "60", "947", "13");
    assertThat(treasury.creditReceipt(state(id).terms().creditId("fee")).orElseThrow().amount())
        .isEqualByComparingTo("1");
    assertThat(treasury.creditReceipt(state(id).terms().creditId("tariff")).orElseThrow().amount())
        .isEqualByComparingTo("2");
    assertThat(wallet.calls).hasSize(2);
    var receipt =
        trades.settlementsAfter(trades.authorityDomain().orElseThrow(), 0, 100).getFirst();
    assertThat(receipt.settlement().terms().seller()).isEqualTo(seller);
    assertThat(receipt.settlement().terms().buyer()).isEqualTo(buyer);
    restart();
    when(nations.nationOf(seller)).thenReturn(Optional.empty());
    assertThat(trades.resume(seller, id).status()).isEqualTo(APPLIED);
    assertThat(trades.resume(UUID.randomUUID(), id).status()).isEqualTo(UNAUTHORIZED);
    assertThat(trades.inspect(UUID.randomUUID(), id)).isEmpty();
    assertThat(trades.settlementsAfter(receipt.authorityDomain(), 0, 100)).containsExactly(receipt);
    assertThat(trades.settlementsAfter(receipt.authorityDomain(), 1, 100)).isEmpty();
    assertThat(wallet.calls).hasSize(2);
    assets(180, 20, "60", "947", "13");
  }

  @Test
  void fractionalUnitPriceRetainsRoundedGrossAcrossRestart() throws Exception {
    UUID id = UUID.randomUUID();
    fee = BigDecimal.ZERO;
    tariff = BigDecimal.ZERO;
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 3, 0.3333, 600_000)
                .status())
        .isEqualTo(APPLIED);
    restart();
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assertThat(state(id).terms().gross()).isEqualByComparingTo("1.00");
    assets(197, 3, "11", "999", "10");
  }

  @ParameterizedTest
  @EnumSource(
      value = PlayerTradeRecoveryService.State.class,
      names = {"RESERVED", "DEBIT_ACKNOWLEDGED", "CREDIT_ACKNOWLEDGED", "SETTLED"})
  void lostCommitAcknowledgementResumesOnlyKnownSafeSteps(PlayerTradeRecoveryService.State stage)
      throws Exception {
    UUID id = offer();
    fail(stage, true);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    assertThat(faultArmed).isFalse();
    restart();
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assertThat(wallet.calls).hasSize(2);
    assets(180, 20, "60", "947", "13");
  }

  @ParameterizedTest
  @EnumSource(
      value = PlayerTradeRecoveryService.State.class,
      names = {"DEBIT_INTENT", "CREDIT_INTENT", "REFUND_INTENT"})
  void lostIntentCommitNeverAuthorizesAnExternalCall(PlayerTradeRecoveryService.State stage)
      throws Exception {
    UUID id = offer();
    if (stage == REFUND_INTENT) wallet.rejectSeller = true;
    fail(stage, true);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    int calls = wallet.calls.size();
    assertThat(calls).isEqualTo(stage == DEBIT_INTENT ? 0 : stage == CREDIT_INTENT ? 1 : 2);
    restart();
    assertThat(state(id).state()).isEqualTo(stage);
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(wallet.calls).hasSize(calls);
    assertThat(resources.amount(selling.id(), "mineral")).isEqualTo(180);
    assertThat(resources.amount(buying.id(), "mineral")).isZero();
  }

  @ParameterizedTest
  @ValueSource(ints = {1, 2, 3})
  void abruptExitAfterWalletEffectKeepsIntentAndNeverGuessesFromBalance(int leg) throws Exception {
    UUID id = offer();
    wallet.rejectSeller = leg == 3;
    wallet.afterCall =
        call -> {
          if (wallet.calls.size() == leg) throw new SimulatedCrash();
        };
    assertThatThrownBy(() -> trades.resume(seller, id)).isInstanceOf(SimulatedCrash.class);
    wallet.afterCall = call -> {};
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(wallet.calls).hasSize(leg);
    assertThat(state(id).state().uncertain()).isTrue();
    assertThat(resources.amount(buying.id(), "mineral")).isZero();
    assertThat(treasury.balance(buying.id())).isEqualByComparingTo("10");
  }

  @ParameterizedTest
  @EnumSource(
      value = PlayerTradeRecoveryService.State.class,
      names = {"DEBIT_ACKNOWLEDGED", "CREDIT_ACKNOWLEDGED", "REFUND_ACKNOWLEDGED"})
  void rolledBackResponseRecordRemainsManualAfterRestart(PlayerTradeRecoveryService.State stage)
      throws Exception {
    UUID id = offer();
    wallet.rejectSeller = stage == REFUND_ACKNOWLEDGED;
    fail(stage, false);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    int calls = wallet.calls.size();
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(wallet.calls).hasSize(calls);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void nativeSettlementRollbackOrLostAcknowledgementNeverRepeatsWallet(boolean after)
      throws Exception {
    UUID id = offer();
    fail(SETTLED, after);
    failReadsAfter = true;
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    assertThat(wallet.calls).hasSize(2);
    unavailable = false;
    restart();
    assets(180, after ? 20 : 0, "60", "947", after ? "13" : "10");
    assertThat(treasury.creditReceipt(state(id).terms().creditId("fee")).isPresent())
        .isEqualTo(after);
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assets(180, 20, "60", "947", "13");
    assertThat(wallet.calls).hasSize(2);
  }

  @Test
  void definitiveSellerRejectionRefundsBuyerThenReleasesExactEscrow() throws Exception {
    UUID id = offer();
    wallet.rejectSeller = true;
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATED);
    assets(200, 0, "10", "1000", "10");
    assertThat(wallet.calls).hasSize(3);
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATED);
    assertThat(wallet.calls).hasSize(3);
    assertThat(trades.settlementsAfter(trades.authorityDomain().orElseThrow(), 0, 100)).isEmpty();
  }

  @Test
  void knownRefundSurvivesLostAcknowledgementWithoutRefundingAgain() throws Exception {
    UUID id = offer();
    wallet.rejectSeller = true;
    fail(REFUND_ACKNOWLEDGED, true);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    restart();
    assertThat(state(id).state()).isEqualTo(REFUND_ACKNOWLEDGED);
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATED);
    assertThat(wallet.calls).hasSize(3);
    assets(200, 0, "10", "1000", "10");
  }

  @Test
  void refundWithFullSellerStockpileRetainsEscrowUntilCapacityIsAvailable() throws Exception {
    UUID id = offer();
    wallet.rejectSeller = true;
    fail(REFUND_ACKNOWLEDGED, true);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    assertThat(resources.grant(selling.id(), "mineral", Long.MAX_VALUE / 2)).isTrue();
    assertThat(resources.grant(selling.id(), "mineral", Long.MAX_VALUE / 2 - 179)).isTrue();
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATION_PENDING);
    assertThat(state(id).state()).isEqualTo(REFUND_ACKNOWLEDGED);
    assertThat(resources.consume(selling.id(), "mineral", 20)).isTrue();
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATED);
    assertThat(wallet.calls).hasSize(3);
    assertThat(resources.amount(selling.id(), "mineral")).isEqualTo(Long.MAX_VALUE);
  }

  @Test
  void pendingOfferBoundSurvivesRestartAndClosedOfferReleasesOneSlot() throws Exception {
    UUID first = offer();
    for (int i = 1; i < 64; i++) offer();
    restart();
    UUID rejected = UUID.randomUUID();
    assertThat(
            trades
                .create(rejected, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .applied())
        .isFalse();
    assertThat(trades.inspect(buyer, rejected)).isEmpty();
    assertThat(trades.close(buyer, first, true)).isTrue();
    assertThat(
            trades
                .create(rejected, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .applied())
        .isTrue();
    assertThat(wallet.calls).isEmpty();
  }

  @Test
  void ambiguousSellerResponseNeverRefundsBuyerOrReleasesResources() throws Exception {
    UUID id = offer();
    wallet.afterCall =
        call -> {
          if (wallet.calls.size() == 2) throw new IllegalStateException("response lost");
        };
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assets(180, 0, "60", "947", "10");
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(wallet.calls).hasSize(2);
  }

  @Test
  void definitiveDebitRejectionReleasesEscrowWithoutAnyCredit() {
    UUID id = offer();
    wallet.rejectDebit = true;
    assertThat(trades.resume(seller, id).status()).isEqualTo(COMPENSATED);
    assets(200, 0, "10", "1000", "10");
    assertThat(wallet.calls).hasSize(1);
  }

  @Test
  void providerChangeKeepsKnownDebitAndResumesOnlyWhenOriginalProviderReturns() throws Exception {
    UUID id = offer();
    fail(DEBIT_ACKNOWLEDGED, true);
    trades.resume(seller, id);
    wallet.provider = "different";
    restart();
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    assertThat(wallet.calls).hasSize(1);
    wallet.provider = "test-wallet-v1";
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assertThat(wallet.calls).hasSize(2);
  }

  @Test
  void creationLostAcknowledgementCanReplayIdButCannotRebindTerms() throws Exception {
    UUID id = UUID.randomUUID();
    fail(OFFERED, true);
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .status())
        .isEqualTo(SETTLEMENT_PENDING);
    restart();
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 20, 2.5, 300)
                .applied())
        .isTrue();
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, selling.id(), "mineral", 21, 2.5, 300)
                .status())
        .isEqualTo(REJECTED);
    assertThat(wallet.calls).isEmpty();
  }

  @Test
  void permissionRevocationBeforeAcceptancePreventsReservation() {
    UUID id = offer();
    when(nations.nationOf(buyer)).thenReturn(Optional.empty());
    assertThat(trades.resume(seller, id).status()).isEqualTo(UNAUTHORIZED);
    assertThat(wallet.calls).isEmpty();
    assets(200, 0, "10", "1000", "10");
  }

  @Test
  void acceptedObligationSurvivesExpiryAndMembershipChange() throws Exception {
    UUID id = offer();
    fail(RESERVED, true);
    trades.resume(seller, id);
    clock = Clock.offset(clock, java.time.Duration.ofDays(2));
    restart();
    when(nations.nationOf(buyer)).thenReturn(Optional.empty());
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assets(180, 20, "60", "947", "13");
  }

  @Test
  void sameNationTradePreservesNetInventoryWithRealEscrowAndZeroTariff() throws Exception {
    var sameNation = mock(Nation.class);
    when(sameNation.id()).thenReturn(buying.id());
    when(sameNation.hasMember(seller)).thenReturn(true);
    when(sameNation.hasPermission(seller, "resource.trade")).thenReturn(true);
    when(nations.nationOf(seller)).thenReturn(Optional.of(sameNation));
    UUID id = UUID.randomUUID();
    assertThat(resources.grant(buying.id(), "mineral", 50)).isTrue();
    assertThat(
            trades
                .create(id, buyer, buying.id(), seller, buying.id(), "mineral", 20, 2.5, 300)
                .applied())
        .isTrue();
    assertThat(trades.resume(seller, id).applied()).isTrue();
    restart();
    assertThat(resources.amount(buying.id(), "mineral")).isEqualTo(50);
    assertThat(state(id).terms().tariffMinor()).isZero();
  }

  @Test
  void failedProjectionIsRetriedFromDurableReceiptWithoutWalletOrAssetReplay() throws Exception {
    UUID id = offer();
    projectionsWork = false;
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assertThat(state(id).state()).isEqualTo(SETTLED);
    assertThat(notified).isEmpty();
    restart();
    projectionsWork = true;
    trades.maintain();
    assertThat(state(id).state()).isEqualTo(PROJECTED);
    assertThat(projected).hasSize(1);
    assertThat(notified).containsExactly(id);
    restart();
    trades.maintain();
    assertThat(trades.resume(seller, id).applied()).isTrue();
    assertThat(notified).containsExactly(id);
    assertThat(wallet.calls).hasSize(2);
    assets(180, 20, "60", "947", "13");
  }

  @Test
  void settlementProjectionPreservesMillisAndImmutableHistoryAcrossRestart() throws Exception {
    var database = mock(dev.starcore.starcore.core.database.DatabaseService.class);
    when(database.getConnection()).thenAnswer(ignored -> rawSource.getConnection());
    try {
      var history = new SimpleTradeHistoryService(database, null);
      try (var c = rawSource.getConnection()) {
        if ("MySQL".equals(c.getMetaData().getDatabaseProductName()))
          sql("ALTER TABLE trade_history MODIFY COLUMN executed_at TIMESTAMP NOT NULL");
      }
      history = new SimpleTradeHistoryService(database, null);
      clock = Clock.offset(clock, java.time.Duration.ofMillis(789));
      restart();
      UUID id = offer();
      assertThat(trades.resume(seller, id).applied()).isTrue();
      var record = state(id).record();
      history.saveSourceRecord(record);
      var restarted = new SimpleTradeHistoryService(database, null);
      restarted.saveSourceRecord(record);
      assertThat(restarted.getRecord(id).orElseThrow().executedAt()).isEqualTo(clock.instant());
      assertThat(restarted.changesAfter(restarted.historyAuthorityDomain(), 0, 100)).hasSize(1);
      restarted.updateStatus(
          id,
          dev.starcore.starcore.module.resource.model.TradeRecord.TradeRecordStatus.DISPUTED,
          "review");
      assertThatThrownBy(() -> restarted.saveSourceRecord(record))
          .isInstanceOf(IllegalStateException.class);
    } finally {
      // These three projection tables are created only by this test in its owned empty catalog.
      sql("DROP TABLE IF EXISTS trade_history_changes");
      sql("DROP TABLE IF EXISTS trade_history_journal_meta");
      sql("DROP TABLE IF EXISTS trade_history");
    }
  }

  @Test
  void unsupportedMutationThreadAllowsParticipantInspectionOnly() {
    UUID id = offer();
    ownerThread = false;
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    assertThat(state(id).state()).isEqualTo(OFFERED);
    assertThat(trades.close(buyer, id, true)).isFalse();
    assertThat(trades.maintain()).isZero();
    assertThat(wallet.calls).isEmpty();
  }

  @ParameterizedTest
  @ValueSource(strings = {"cancel", "reject", "expire"})
  void closedOfferSurvivesRestartWithoutAssetEffects(String operation) throws Exception {
    UUID id = offer();
    assertThat(trades.close(UUID.randomUUID(), id, true)).isFalse();
    if (operation.equals("expire")) {
      clock = Clock.offset(clock, java.time.Duration.ofSeconds(301));
      restart();
      assertThat(trades.maintain()).isEqualTo(1);
    } else
      assertThat(
              trades.close(
                  operation.equals("cancel") ? buyer : seller, id, operation.equals("cancel")))
          .isTrue();
    restart();
    assertThat(trades.resume(seller, id).applied()).isFalse();
    assertThat(state(id).state().terminal()).isTrue();
    assertThat(wallet.calls).isEmpty();
    assets(200, 0, "10", "1000", "10");
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "DELETE FROM starcore_player_trade_events WHERE event_sequence=(SELECT last_sequence FROM"
            + " (SELECT MAX(event_sequence) AS last_sequence FROM starcore_player_trade_events) AS"
            + " committed_tail)",
        "DELETE FROM starcore_player_trade_head",
        "UPDATE starcore_player_trade_events SET snapshot_json=REPLACE(snapshot_json,'2.5','2.6')"
            + " WHERE offer_version=1",
        "DELETE FROM starcore_treasury_state WHERE property_key='credit.0.amount'",
        "UPDATE starcore_treasury_state SET property_value='9.00' WHERE"
            + " property_key='credit.0.amount'"
      })
  void incompleteOrChangedCommittedJournalBlocksRestart(String corruption) throws Exception {
    UUID id = offer();
    trades.resume(seller, id);
    sql(corruption);
    assertThatThrownBy(() -> trades.audit(seller, id)).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(this::restart).isInstanceOf(RuntimeException.class);
    assertThat(wallet.calls).hasSize(2);
  }

  @Test
  void secondServiceCannotInvokeWalletWhileFirstHasPersistedIntent() throws Exception {
    UUID id = offer();
    DurablePlayerTrades first = trades;
    restart();
    DurablePlayerTrades second = trades;
    var entered = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    wallet.afterCall =
        call -> {
          if (wallet.calls.size() == 1) {
            entered.countDown();
            try {
              if (!release.await(10, TimeUnit.SECONDS)) throw new AssertionError("timeout");
            } catch (InterruptedException interrupted) {
              throw new AssertionError(interrupted);
            }
          }
        };
    try (var pool = Executors.newSingleThreadExecutor()) {
      Future<PlayerTradeService.ActionResult> work = pool.submit(() -> first.resume(seller, id));
      assertThat(entered.await(10, TimeUnit.SECONDS)).isTrue();
      try {
        assertThat(second.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
      } finally {
        release.countDown();
      }
      assertThat(work.get(10, TimeUnit.SECONDS).applied()).isTrue();
    }
    restart();
    assertThat(wallet.calls).hasSize(2);
    assets(180, 20, "60", "947", "13");
  }

  private static Object invoke(java.lang.reflect.Method method, Object target, Object[] args)
      throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException error) {
      throw error.getCause();
    }
  }

  private static final class SimulatedCrash extends Error {}

  @Test
  void productionStorageRouterAuditsPinnedSqlAndNeverFallsBackToLegacyFiles() throws Exception {
    UUID id = offer();
    var database = mock(dev.starcore.starcore.core.database.DatabaseService.class);
    var persistence = mock(dev.starcore.starcore.core.persistence.PersistenceService.class);
    when(database.isRunning()).thenReturn(true);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(persistence.namespacePath("test")).thenReturn(directory);
    java.nio.file.Files.writeString(directory.resolve("resource-sql-authority"), "SQL");
    var router =
        new DatabaseAwareResourceStateStorage(
            "test", database, persistence, Logger.getAnonymousLogger());
    router.load();
    var before = storage.playerTradeState().orElseThrow();
    assertThat(router.playerTradeAudit(id)).contains(audit(id));
    assertThat(storage.playerTradeState().orElseThrow()).isEqualTo(before);
    verify(persistence, never()).saveProperties(any(), any(), any());
    when(database.dataSource()).thenReturn(Optional.empty());
    when(database.isRunning()).thenReturn(false);
    var restarted =
        new DatabaseAwareResourceStateStorage(
            "test", database, persistence, Logger.getAnonymousLogger());
    assertThatThrownBy(() -> restarted.playerTradeAudit(id))
        .isInstanceOf(IllegalStateException.class);
    verify(persistence, never()).loadProperties(any(), any());
    assertThat(wallet.calls).isEmpty();
  }

  private PlayerTradeAudit audit(UUID id) {
    // Inspection remains usable without a wallet, nation, treasury service or mutation thread.
    var reader =
        new DurablePlayerTrades(
            resources, storage, null, null, null, null, null, clock, () -> false, null);
    var value = reader.audit(seller, id).orElseThrow();
    assertThat(reader.audit(buyer, id)).contains(value);
    assertThat(reader.audit(UUID.randomUUID(), id)).isEmpty();
    assertThat(reader.audit(seller, UUID.randomUUID())).isEmpty();
    assertThat(value.current()).isEqualTo(state(id));
    assertThat(value.entries()).hasSize((int) value.current().version());
    return value;
  }

  @Test
  void auditExposesOnlyOriginalParticipantsAndFrozenCallsWithoutAnyMutation() throws Exception {
    UUID id = offer();
    var before = storage.playerTradeState().orElseThrow();
    when(nations.nationOf(buyer)).thenReturn(Optional.empty());
    when(nations.nationOf(seller)).thenReturn(Optional.empty());
    var value = audit(id);
    assertThat(value.headSequence()).isEqualTo(1);
    assertThat(value.headHash()).isEqualTo(before.hash());
    assertThat(value.authorityDomain()).isEqualTo(before.domain());
    assertThat(value.nextAction()).isEqualTo(PlayerTradeAudit.NextAction.SELLER_DECISION);
    assertThat(value.calls())
        .extracting(PlayerTradeAudit.Call::evidence)
        .containsOnly(PlayerTradeAudit.Evidence.NO_INTENT);
    assertThat(value.calls())
        .extracting(c -> c.operation().account())
        .containsExactly(buyer, seller, buyer);
    assertThat(value.calls())
        .extracting(c -> c.operation().amount())
        .containsExactly(new BigDecimal("53.00"), new BigDecimal("50.00"), new BigDecimal("53.00"));
    assertThat(value.calls()).allMatch(c -> c.intent() == null && c.result() == null);
    assertThat(storage.playerTradeState().orElseThrow()).isEqualTo(before);
    assertThat(wallet.calls).isEmpty();
    assets(200, 0, "10", "1000", "10");
    assertThatThrownBy(() -> value.entries().clear())
        .isInstanceOf(UnsupportedOperationException.class);
    restart();
    assertThat(audit(id)).isEqualTo(value);
  }

  @Test
  void completedAuditRetainsEveryLocalStepAndExcludesOtherOffers() throws Exception {
    UUID id = offer();
    UUID other = offer();
    trades.resume(seller, id);
    var value = audit(id);
    assertThat(value.entries())
        .extracting(e -> e.snapshot().state())
        .containsExactly(
            OFFERED,
            RESERVED,
            DEBIT_INTENT,
            DEBIT_ACKNOWLEDGED,
            CREDIT_INTENT,
            PlayerTradeRecoveryService.State.CREDIT_ACKNOWLEDGED,
            SETTLED,
            PROJECTED);
    assertThat(value.entries())
        .extracting(PlayerTradeAudit.Entry::sequence)
        .containsExactly(1L, 3L, 4L, 5L, 6L, 7L, 8L, 9L);
    assertThat(value.entries()).allMatch(e -> e.snapshot().terms().id().equals(id));
    assertThat(audit(other).entries()).hasSize(1);
    assertThat(audit(other).headSequence()).isEqualTo(value.headSequence());
    assertThat(audit(other).headHash()).isEqualTo(value.headHash());
    assertThat(value.calls())
        .extracting(PlayerTradeAudit.Call::evidence)
        .containsExactly(
            PlayerTradeAudit.Evidence.PROVIDER_ACKNOWLEDGED,
            PlayerTradeAudit.Evidence.PROVIDER_ACKNOWLEDGED,
            PlayerTradeAudit.Evidence.NO_INTENT);
    assertThat(value.nextAction()).isEqualTo(PlayerTradeAudit.NextAction.CLOSED);
    restart();
    assertThat(audit(id)).isEqualTo(value);
    assertThat(wallet.calls).hasSize(2);
    assets(180, 20, "60", "947", "13");
  }

  @ParameterizedTest
  @ValueSource(ints = {1, 2, 3})
  void auditOfInterruptedCallsNeverInfersAnOutcomeOrUnlocksEscrow(int leg) throws Exception {
    UUID id = offer();
    wallet.rejectSeller = leg == 3;
    wallet.afterCall =
        call -> {
          if (wallet.calls.size() == leg) throw new SimulatedCrash();
        };
    assertThatThrownBy(() -> trades.resume(seller, id)).isInstanceOf(SimulatedCrash.class);
    wallet.afterCall = call -> {};
    restart();
    var value = audit(id);
    var call = value.calls().get(leg - 1);
    assertThat(call.evidence()).isEqualTo(PlayerTradeAudit.Evidence.INTENT_WITHOUT_RESULT);
    assertThat(call.intent()).isEqualTo(value.entries().getLast());
    assertThat(call.result()).isNull();
    assertThat(value.nextAction())
        .isEqualTo(PlayerTradeAudit.NextAction.PROVIDER_EVIDENCE_REQUIRED);
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(audit(id)).isEqualTo(value);
    assertThat(wallet.calls).hasSize(leg);
    assertThat(resources.amount(buying.id(), "mineral")).isZero();
    assertThat(resources.amount(selling.id(), "mineral")).isEqualTo(180);
    assertThat(trades.settlementsAfter(value.authorityDomain(), 0, 100)).isEmpty();
  }

  @ParameterizedTest
  @ValueSource(ints = {1, 2, 3})
  void auditDistinguishesRecordedUnknownFromMissingResult(int leg) throws Exception {
    UUID id = offer();
    wallet.rejectSeller = leg == 3;
    wallet.afterCall =
        call -> {
          if (wallet.calls.size() == leg) throw new IllegalStateException("lost response");
        };
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    wallet.afterCall = call -> {};
    restart();
    var value = audit(id);
    var call = value.calls().get(leg - 1);
    assertThat(call.evidence()).isEqualTo(PlayerTradeAudit.Evidence.UNKNOWN);
    assertThat(call.result()).isEqualTo(value.entries().getLast());
    assertThat(call.intent().sequence()).isLessThan(call.result().sequence());
    assertThat(value.nextAction())
        .isEqualTo(PlayerTradeAudit.NextAction.PROVIDER_EVIDENCE_REQUIRED);
    assertThat(trades.resume(seller, id).status()).isEqualTo(MANUAL_REVIEW);
    assertThat(audit(id)).isEqualTo(value);
    assertThat(wallet.calls).hasSize(leg);
  }

  @Test
  void auditDoesNotDrivePendingCompensationOrProjection() throws Exception {
    UUID id = offer();
    wallet.rejectSeller = true;
    fail(REFUND_ACKNOWLEDGED, true);
    assertThat(trades.resume(seller, id).status()).isEqualTo(SETTLEMENT_PENDING);
    restart();
    var value = audit(id);
    assertThat(value.nextAction()).isEqualTo(PlayerTradeAudit.NextAction.SELLER_RESUME);
    assertThat(value.calls())
        .extracting(PlayerTradeAudit.Call::evidence)
        .containsExactly(
            PlayerTradeAudit.Evidence.PROVIDER_ACKNOWLEDGED,
            PlayerTradeAudit.Evidence.PROVIDER_REJECTED,
            PlayerTradeAudit.Evidence.PROVIDER_ACKNOWLEDGED);
    assets(180, 0, "10", "1000", "10");
    trades.resume(seller, id);
    assertThat(audit(id).entries()).hasSize(9);
    assertThat(audit(id).nextAction()).isEqualTo(PlayerTradeAudit.NextAction.CLOSED);
    wallet.rejectSeller = false;
    projectionsWork = false;
    UUID settled = offer();
    trades.resume(seller, settled);
    projectionsWork = true;
    var pending = audit(settled);
    assertThat(pending.current().state()).isEqualTo(SETTLED);
    assertThat(pending.nextAction()).isEqualTo(PlayerTradeAudit.NextAction.SELLER_RESUME);
    assertThat(projected).doesNotContainKey(settled);
    trades.resume(seller, settled);
    assertThat(audit(settled).current().state()).isEqualTo(PROJECTED);
    assertThat(wallet.calls).hasSize(5);
  }

  private final class Wallet implements EconomyService {
    final Map<UUID, BigDecimal> balances = new ConcurrentHashMap<>();
    final List<WalletOperation> calls = new CopyOnWriteArrayList<>();
    String provider = "test-wallet-v1";
    boolean rejectSeller, rejectDebit;
    Consumer<WalletOperation> afterCall = operation -> {};

    @Override
    public String walletProviderIdentity() {
      return provider;
    }

    @Override
    public WalletOperation.Outcome executeWalletOperation(WalletOperation operation) {
      calls.add(operation);
      boolean rejected =
          (rejectSeller && operation.account().equals(seller))
              || (rejectDebit && operation.direction() == WalletOperation.Direction.DEBIT);
      if (!rejected) {
        if (operation.direction() == WalletOperation.Direction.DEBIT)
          withdraw(operation.account(), operation.amount());
        else deposit(operation.account(), operation.amount());
      }
      afterCall.accept(operation);
      return rejected ? WalletOperation.Outcome.REJECTED : WalletOperation.Outcome.ACKNOWLEDGED;
    }

    @Override
    public BigDecimal getBalance(UUID account) {
      return balances.getOrDefault(account, BigDecimal.ZERO);
    }

    @Override
    public boolean has(UUID account, BigDecimal amount) {
      return getBalance(account).compareTo(amount) >= 0;
    }

    @Override
    public boolean deposit(UUID account, BigDecimal amount) {
      balances.put(account, getBalance(account).add(amount));
      return true;
    }

    @Override
    public boolean withdraw(UUID account, BigDecimal amount) {
      if (!has(account, amount)) return false;
      balances.put(account, getBalance(account).subtract(amount));
      return true;
    }

    @Override
    public boolean setBalance(UUID account, BigDecimal amount) {
      balances.put(account, amount);
      return true;
    }

    @Override
    public boolean transfer(UUID from, UUID to, BigDecimal amount) {
      throw new AssertionError("not used");
    }

    @Override
    public Map<UUID, BigDecimal> getAllBalances() {
      return Map.copyOf(balances);
    }

    @Override
    public boolean hasAccount(UUID account) {
      return balances.containsKey(account);
    }

    @Override
    public void createAccount(UUID account) {
      balances.putIfAbsent(account, BigDecimal.ZERO);
    }
  }
}
