from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda data:hashlib.sha256(data).hexdigest()
tests=json.loads((root/'run/native-social-listener-focused-3-20261128/result.json').read_text())
pair=json.loads((root/'run/social-listener-pair-artifacts-1-20261128/result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][key]==0 for key in ('failures','errors','skipped'))
assert pair['status']=='VERIFIED'
files={}
for label,name in [('validation','native-social-listener-focused-3-20261128'),('pair','social-listener-pair-artifacts-1-20261128'),('frozen','social-listener-frozen-pair-1-20261128')]:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class'):
            files[label+'/'+path.relative_to(base).as_posix()]=path
for label,name in [('first-attempt','native-social-listener-focused-1-20261128'),('second-attempt','native-social-listener-focused-2-20261128')]:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and 'source' not in path.relative_to(base).parts:
            files[label+'/'+path.relative_to(base).as_posix()]=path
    for relative in ['src/main/java/dev/starcore/starcore/social/simulation/SocialSimulationListener.java',
                     'src/test/java/dev/starcore/starcore/social/simulation/SocialListenerFixture.java',
                     'src/test/java/dev/starcore/starcore/social/simulation/SocialSimulationListenerAsyncPersistenceTest.java',
                     'src/test/java/dev/starcore/starcore/social/simulation/SocialSimulationListenerThreadingTest.java']:
        files[label+'/source/'+relative]=base/'source'/relative
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','run/validate-social-listener-20261128.py','run/freeze-social-listener-20261128.py','run/package-social-listener-20261128.py','run/social-listener-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:sha(path.read_bytes()) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,
    'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],
    'artifacts':json.loads((root/'run/social-listener-frozen-pair-1-20261128/manifest.json').read_text()),
    'fixtures_compiled':pair['fixtures']['count'],
    'limits':['Related tests only; not the entire StarCore suite.',
              'No new persistent schema. Prior database-probe results retain their own JAR fingerprints.',
              'Reputation, relationship and influence updates are separate service operations, not one distributed transaction.',
              'Help cooldown, craft/fishing milestones, death windows and kill streaks are runtime state; no restart exactly-once claim.',
              'Uncancelled crafting events are observed gameplay actions, not durable proof of item delivery.',
              'Legacy synchronous constructor is retained; the actual module injects its bounded I/O queue.',
              'Live entity event ownership, multiple players, third-party combinations and full Folia require runtime acceptance.']}
out=root/'docs/verification/social-listener-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,digest in manifest.items():assert sha(archive.read(name))==digest,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=sha(out.read_bytes()),files=manifest)
(root/'docs/verification/social-listener-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
