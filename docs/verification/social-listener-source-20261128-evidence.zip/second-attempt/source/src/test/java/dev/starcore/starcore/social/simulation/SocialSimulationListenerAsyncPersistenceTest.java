package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.junit.jupiter.api.Test;

class SocialSimulationListenerAsyncPersistenceTest {
  @Test
  void playerJoinReturnsWhileInfluencePersistenceIsBlocked() throws Exception {
    assertNonBlocking(true);
  }

  @Test
  void playerQuitReturnsWhileInfluencePersistenceIsBlocked() throws Exception {
    assertNonBlocking(false);
  }

  private void assertNonBlocking(boolean joining) throws Exception {
    var executor =
        Executors.newSingleThreadExecutor(task -> new Thread(task, "social-influence-test-io"));
    var started = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    var finished = new CountDownLatch(1);
    var thread = new AtomicReference<String>();
    try (var f = new SocialListenerFixture(task -> CompletableFuture.runAsync(task, executor))) {
      var player = f.player("player");
      var playerId = player.getUniqueId();
      doAnswer(
              ignored -> {
                thread.set(Thread.currentThread().getName());
                started.countDown();
                try {
                  assertTrue(
                      release.await(2, TimeUnit.SECONDS),
                      "Persistence was blocked on the event caller");
                } finally {
                  finished.countDown();
                }
                return null;
              })
          .when(f.influence)
          .addInfluence(playerId, joining ? 10 : -5, joining ? "上线" : "下线");
      try {
        if (joining) {
          var event = mock(PlayerJoinEvent.class);
          when(event.getPlayer()).thenReturn(player);
          f.on(player, () -> f.listener.onPlayerJoin(event));
        } else {
          var event = mock(PlayerQuitEvent.class);
          when(event.getPlayer()).thenReturn(player);
          f.on(player, () -> f.listener.onPlayerQuit(event));
        }
        assertTrue(started.await(1, TimeUnit.SECONDS));
        assertEquals(1, finished.getCount());
        assertEquals("social-influence-test-io", thread.get());
      } finally {
        release.countDown();
        assertTrue(finished.await(1, TimeUnit.SECONDS));
      }
    } finally {
      release.countDown();
      executor.shutdownNow();
      assertTrue(executor.awaitTermination(1, TimeUnit.SECONDS));
    }
  }
}
