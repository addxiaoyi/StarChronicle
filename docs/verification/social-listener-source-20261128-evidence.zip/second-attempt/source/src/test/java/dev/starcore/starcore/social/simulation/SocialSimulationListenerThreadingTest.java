package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.event.player.PlayerAttackPlayerEvent;
import dev.starcore.starcore.event.player.PlayerHelpPlayerEvent;
import java.util.*;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.junit.jupiter.api.Test;

class SocialSimulationListenerThreadingTest {
  private PlayerJoinEvent join(Player player) {
    var event = mock(PlayerJoinEvent.class);
    when(event.getPlayer()).thenReturn(player);
    return event;
  }

  private PlayerQuitEvent quit(Player player) {
    var event = mock(PlayerQuitEvent.class);
    when(event.getPlayer()).thenReturn(player);
    return event;
  }

  private PlayerDeathEvent death(Player player) {
    var event = mock(PlayerDeathEvent.class);
    when(event.getEntity()).thenReturn(player);
    return event;
  }

  @Test
  void joinNotifiesOnlyCapturedOnlineFriendsAndPublishesAfterCommittedInfluence() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("joining");
      var friend = f.player("friend");
      UUID id = player.getUniqueId();
      UUID friendId = friend.getUniqueId();
      when(f.relationships.getFriends(id)).thenReturn(Set.of(friendId, UUID.randomUUID()));
      when(f.reputation.getReputation(id)).thenReturn(120);
      when(f.influence.getStatus(id)).thenReturn(SocialInfluenceService.SocialStatus.KNOWN);
      f.on(player, () -> f.listener.onPlayerJoin(join(player)));
      verify(friend, never()).sendMessage(anyString());
      verifyNoInteractions(f.news);
      f.drainOwners();
      verify(friend).sendMessage("§a[社交] §ejoining §a上线了！");
      verify(player).sendMessage("§a你的 1 位朋友在线！");
      verifyNoInteractions(f.news);
      f.drain();
      verify(f.influence).addInfluence(id, 10, "上线");
      verify(f.news)
          .publishNews(
              eq("joining 回归了！"),
              anyString(),
              eq(id),
              eq(NewsPropagationService.NewsCategory.SOCIAL));
    }
  }

  @Test
  void failedJoinPersistenceDoesNotPublishReturnNews() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("joining");
      UUID id = player.getUniqueId();
      when(f.reputation.getReputation(id)).thenReturn(120);
      doThrow(new IllegalStateException("influence commit failed"))
          .when(f.influence)
          .addInfluence(id, 10, "上线");
      f.on(player, () -> f.listener.onPlayerJoin(join(player)));
      f.drain();
      verify(f.influence).addInfluence(id, 10, "上线");
      verifyNoInteractions(f.news);
    }
  }

  @Test
  void failedHelpRelationshipDoesNotPublishSuccessOrAwardOtherServices() {
    try (var f = new SocialListenerFixture()) {
      var helper = f.player("helper");
      var target = f.player("target");
      UUID from = helper.getUniqueId(), to = target.getUniqueId();
      doThrow(new IllegalStateException("relationship commit failed"))
          .when(f.relationships)
          .setRelationship(from, to, RelationshipNetwork.RelationshipType.FRIEND, 30);
      f.listener.onPlayerHelpPlayer(new PlayerHelpPlayerEvent(helper, target, "rescue"));
      f.drain();
      verify(f.relationships)
          .setRelationship(from, to, RelationshipNetwork.RelationshipType.FRIEND, 30);
      verifyNoInteractions(f.reputation, f.influence, f.news, f.gossip);
    }
  }

  @Test
  void lateJoinAndFriendCallbacksNeverTargetReplacementPlayers() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("old");
      var friend = f.player("old-friend");
      UUID id = player.getUniqueId();
      UUID friendId = friend.getUniqueId();
      when(f.relationships.getFriends(id)).thenReturn(Set.of(friendId));
      when(f.reputation.getReputation(id)).thenReturn(120);
      f.on(player, () -> f.listener.onPlayerJoin(join(player)));
      var replacement = f.player(id, "new");
      var newFriend = f.player(friend.getUniqueId(), "new-friend");
      f.drain();
      verify(friend, never()).sendMessage(anyString());
      verify(newFriend, never()).sendMessage(anyString());
      verify(replacement, never()).sendMessage(anyString());
      verifyNoInteractions(f.news);
    }
  }

  @Test
  void unregisterRejectsQueuedWritesAndOldCallbacksAcrossReregistration() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("player");
      f.on(player, () -> f.listener.onPlayerJoin(join(player)));
      f.listener.broadcastEventEffects(player);
      f.listener.unregister();
      f.listener.onPlayerJoin(join(player));
      f.listener.register(f.plugin);
      f.drain();
      verifyNoInteractions(f.influence);
      verify(player, never()).sendMessage(anyString());
      f.on(player, () -> f.listener.onPlayerJoin(join(player)));
      f.drain();
      verify(f.influence).addInfluence(player.getUniqueId(), 10, "上线");
      assertThrows(IllegalStateException.class, () -> f.listener.register(f.plugin));
    }
  }

  @Test
  void helpReadsBothOwnersUsesIoAndEnforcesThirtySecondCooldown() {
    try (var f = new SocialListenerFixture()) {
      var helper = f.player("helper");
      var target = f.player("target");
      UUID from = helper.getUniqueId(), to = target.getUniqueId();
      var event = new PlayerHelpPlayerEvent(helper, target, "rescue");
      doAnswer(
              ignored -> {
                assertNull(f.owner.get());
                return null;
              })
          .when(f.relationships)
          .setRelationship(from, to, RelationshipNetwork.RelationshipType.FRIEND, 30);
      f.listener.onPlayerHelpPlayer(event);
      verifyNoInteractions(f.reputation, f.relationships);
      Runnable firstOwner = f.owners.removeFirst();
      firstOwner.run();
      firstOwner.run();
      f.drain();
      f.listener.onPlayerHelpPlayer(event);
      f.drain();
      verify(f.relationships)
          .setRelationship(from, to, RelationshipNetwork.RelationshipType.FRIEND, 30);
      verify(f.reputation).addMoral(from, 5, "帮助玩家: target");
      verify(f.influence).addInfluence(from, 5, "助人为乐");
      f.now.addAndGet(30_000);
      f.listener.onPlayerHelpPlayer(event);
      f.drain();
      verify(f.reputation, times(2)).addMoral(from, 5, "帮助玩家: target");
      f.listener.onPlayerHelpPlayer(new PlayerHelpPlayerEvent(helper, helper, "self"));
      f.drain();
      verify(f.influence, times(2)).addInfluence(from, 5, "助人为乐");
    }
  }

  @Test
  void retiredHelpTargetCannotProduceDomainEffects() {
    try (var f = new SocialListenerFixture()) {
      var helper = f.player("helper");
      var target = f.player("target");
      f.listener.onPlayerHelpPlayer(new PlayerHelpPlayerEvent(helper, target, "rescue"));
      f.player(target.getUniqueId(), "replacement");
      f.drain();
      verifyNoInteractions(f.reputation, f.relationships, f.influence, f.news, f.gossip);
    }
  }

  @Test
  void attacksBecomeEnemiesOnlyAtNegativeThresholdAndKeepActualStrength() {
    try (var f = new SocialListenerFixture()) {
      var attacker = f.player("attacker");
      var victim = f.player("victim");
      UUID from = attacker.getUniqueId(), to = victim.getUniqueId();
      when(f.relationships.getRelationship(from, to))
          .thenReturn(
              new RelationshipNetwork.Relationship(
                  from, to, RelationshipNetwork.RelationshipType.FRIEND, 30, 1, 1, List.of()));
      var event = new PlayerAttackPlayerEvent(attacker, victim, 2);
      f.listener.onPlayerAttackPlayer(event);
      f.drain();
      verify(f.relationships, never()).setRelationship(any(), any(), any(), anyInt());
      when(f.relationships.getRelationship(from, to))
          .thenReturn(
              new RelationshipNetwork.Relationship(
                  from, to, RelationshipNetwork.RelationshipType.STRANGER, -40, 1, 1, List.of()));
      f.listener.onPlayerAttackPlayer(event);
      f.drain();
      verify(f.relationships)
          .setRelationship(from, to, RelationshipNetwork.RelationshipType.ENEMY, -40);
      verify(f.news, times(2))
          .publishNews(
              eq("attacker 攻击了 victim"),
              anyString(),
              eq(from),
              eq(NewsPropagationService.NewsCategory.MILITARY));
    }
  }

  @Test
  void mobKillsReachRareRewardsAndPlayerDeathsHaveOnlyTheirOwnHandler() {
    try (var f = new SocialListenerFixture()) {
      var killer = f.player("slayer");
      UUID killerId = killer.getUniqueId();
      var dragon = mock(EnderDragon.class);
      var event = mock(EntityDeathEvent.class);
      when(event.getEntity()).thenReturn(dragon);
      when(event.getEntityType()).thenReturn(EntityType.ENDER_DRAGON);
      when(dragon.getKiller()).thenReturn(killer);
      f.listener.onEntityKill(event);
      verifyNoInteractions(f.reputation);
      f.drain();
      verify(f.influence).addInfluence(killer.getUniqueId(), 500, "击杀末影龙");
      verify(f.reputation).addAbility(killer.getUniqueId(), 50, "击杀末影龙");
      verify(f.reputation).addAbility(killer.getUniqueId(), 100, "击杀: ENDER_DRAGON");
      verify(f.news)
          .publishNews(
              eq("slayer 击败了末影龙！"),
              anyString(),
              eq(killerId),
              eq(NewsPropagationService.NewsCategory.HEROIC));
      clearInvocations(f.reputation, f.influence);
      var victim = f.player("victim");
      when(event.getEntity()).thenReturn(victim);
      f.listener.onEntityKill(event);
      f.drain();
      verifyNoInteractions(f.reputation, f.influence);
    }
  }

  @Test
  void deathStreakUsesKillerOwnerAndExpiredWindowDoesNotCountOldDeaths() {
    try (var f = new SocialListenerFixture()) {
      var killer = f.player("killer");
      var victim = f.player("victim");
      UUID killerId = killer.getUniqueId();
      when(victim.getKiller())
          .thenAnswer(
              ignored -> {
                assertSame(victim, f.owner.get());
                return killer;
              });
      when(f.reputation.getReputation(victim.getUniqueId())).thenReturn(-1);
      for (int i = 0; i < 5; i++) {
        f.on(victim, () -> f.listener.onPlayerDeath(death(victim)));
        f.drain();
      }
      verify(f.news)
          .publishNews(
              eq("killer 完成五杀！"),
              anyString(),
              eq(killerId),
              eq(NewsPropagationService.NewsCategory.MILITARY));
      verify(f.influence, never()).addInfluence(victim.getUniqueId(), -10, "频繁死亡");
      f.on(victim, () -> f.listener.onPlayerDeath(death(victim)));
      f.drain();
      verify(f.influence).addInfluence(victim.getUniqueId(), -10, "频繁死亡");
      f.now.addAndGet(86_400_000);
      f.on(victim, () -> f.listener.onPlayerDeath(death(victim)));
      f.drain();
      verify(f.influence).addInfluence(victim.getUniqueId(), -10, "频繁死亡");
    }
  }

  @Test
  void delayedOldQuitCannotEraseNewSessionStreakOrChargeAgain() {
    try (var f = new SocialListenerFixture()) {
      var old = f.player("old");
      var current = f.player(old.getUniqueId(), "new");
      var victim = f.player("victim");
      f.on(current, () -> f.listener.onPlayerJoin(join(current)));
      f.drain();
      when(victim.getKiller()).thenReturn(current);
      f.on(victim, () -> f.listener.onPlayerDeath(death(victim)));
      f.drain();
      f.on(old, () -> f.listener.onPlayerQuit(quit(old)));
      f.drain();
      assertEquals(1, f.listener.getPlayerSocialStats(current.getUniqueId()).get("killStreak"));
      verify(f.influence, never()).addInfluence(current.getUniqueId(), -5, "下线");
    }
  }

  @Test
  void cancelledCraftsDoNothingAndRepeatedTenthMaterialDoesNotRepeatMilestone() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("crafter");
      var event = mock(CraftItemEvent.class);
      when(event.getWhoClicked()).thenReturn(player);
      when(event.isCancelled()).thenReturn(true);
      f.listener.onCraftItem(event);
      f.drain();
      verifyNoInteractions(f.reputation, f.influence);
      when(event.isCancelled()).thenReturn(false);
      Material[] materials = {
        Material.STONE,
        Material.DIRT,
        Material.GRANITE,
        Material.ANDESITE,
        Material.DIORITE,
        Material.COBBLESTONE,
        Material.OAK_PLANKS,
        Material.SPRUCE_PLANKS,
        Material.BIRCH_PLANKS,
        Material.ACACIA_PLANKS
      };
      for (Material material : materials) {
        var item = mock(ItemStack.class);
        when(item.getType()).thenReturn(material);
        when(event.getCurrentItem()).thenReturn(item);
        f.on(player, () -> f.listener.onCraftItem(event));
        f.drain();
      }
      f.on(player, () -> f.listener.onCraftItem(event));
      f.drain();
      verify(f.influence).addInfluence(player.getUniqueId(), 10, "初级工匠");
      verify(player).sendMessage("§6[成就] §e恭喜获得成就: 初级工匠");
      assertEquals(10, f.listener.getPlayerSocialStats(player.getUniqueId()).get("craftCount"));
    }
  }

  @Test
  void fishingCancellationAndActualLevelIncreaseControlRewards() {
    try (var f = new SocialListenerFixture()) {
      var player = f.player("fisher");
      var fish = mock(PlayerFishEvent.class);
      when(fish.getPlayer()).thenReturn(player);
      when(fish.getState()).thenReturn(PlayerFishEvent.State.CAUGHT_FISH);
      when(fish.isCancelled()).thenReturn(true);
      f.listener.onFish(fish);
      f.drain();
      verifyNoInteractions(f.reputation);
      when(fish.isCancelled()).thenReturn(false);
      f.on(player, () -> f.listener.onFish(fish));
      f.drain();
      verify(f.reputation).addCharisma(player.getUniqueId(), 1, "休闲钓鱼");
      var level = mock(PlayerLevelChangeEvent.class);
      when(level.getPlayer()).thenReturn(player);
      when(level.getOldLevel()).thenReturn(10);
      when(level.getNewLevel()).thenReturn(9);
      f.listener.onPlayerLevelChange(level);
      f.drain();
      verifyNoInteractions(f.influence);
      when(level.getNewLevel()).thenReturn(11);
      f.listener.onPlayerLevelChange(level);
      f.drain();
      verify(f.influence).addInfluence(player.getUniqueId(), 5, "升级");
    }
  }
}
