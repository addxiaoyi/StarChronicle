package dev.starcore.starcore.social.simulation;

import dev.starcore.starcore.event.player.PlayerAttackPlayerEvent;
import dev.starcore.starcore.event.player.PlayerHelpPlayerEvent;
import dev.starcore.starcore.foundation.gui.PlayerMenuTasks;
import dev.starcore.starcore.foundation.util.RandomProvider;
import dev.starcore.starcore.social.simulation.SocialEventScheduler.EventEffects;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.logging.Level;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Captures event facts on their owners, then submits domain work to the module's bounded I/O queue.
 */
public class SocialSimulationListener implements Listener {
  private final ReputationService reputationService;
  private final RelationshipNetwork relationshipNetwork;
  private final SocialInfluenceService influenceService;
  private final NewsPropagationService newsService;
  private final SocialEventScheduler eventScheduler;
  private final GossipService gossipService;
  private final SocialInfluenceWriteQueue influenceWriteQueue;
  private final LongSupplier clock;
  private final Object registrationLock = new Object();
  private volatile State state;

  private static final class State {
    final JavaPlugin plugin;
    final PlayerMenuTasks owners;
    final Map<UUID, Player> sessions = new ConcurrentHashMap<>();
    final Map<UUID, Long> helpTimes = new ConcurrentHashMap<>();
    final Map<UUID, Integer> killStreak = new ConcurrentHashMap<>();
    final Map<UUID, Deque<Long>> deaths = new ConcurrentHashMap<>();
    final Map<UUID, Set<String>> crafted = new ConcurrentHashMap<>();
    final Map<UUID, Integer> fish = new ConcurrentHashMap<>();

    State(JavaPlugin plugin) {
      this.plugin = plugin;
      owners = new PlayerMenuTasks(plugin);
    }
  }

  public SocialSimulationListener(
      ReputationService reputationService,
      RelationshipNetwork relationshipNetwork,
      SocialInfluenceService influenceService,
      NewsPropagationService newsService,
      SocialEventScheduler eventScheduler,
      CultureService cultureService,
      SocialActivityService activityService,
      GossipService gossipService) {
    this(
        reputationService,
        relationshipNetwork,
        influenceService,
        newsService,
        eventScheduler,
        cultureService,
        activityService,
        gossipService,
        SocialInfluenceWriteQueue.synchronous(influenceService));
  }

  public SocialSimulationListener(
      ReputationService reputationService,
      RelationshipNetwork relationshipNetwork,
      SocialInfluenceService influenceService,
      NewsPropagationService newsService,
      SocialEventScheduler eventScheduler,
      CultureService cultureService,
      SocialActivityService activityService,
      GossipService gossipService,
      Function<Runnable, CompletableFuture<Void>> ioSubmitter) {
    this(
        reputationService,
        relationshipNetwork,
        influenceService,
        newsService,
        eventScheduler,
        cultureService,
        activityService,
        gossipService,
        new SocialInfluenceWriteQueue(influenceService, ioSubmitter, (subject, failure) -> {}));
  }

  public SocialSimulationListener(
      ReputationService reputationService,
      RelationshipNetwork relationshipNetwork,
      SocialInfluenceService influenceService,
      NewsPropagationService newsService,
      SocialEventScheduler eventScheduler,
      CultureService cultureService,
      SocialActivityService activityService,
      GossipService gossipService,
      SocialInfluenceWriteQueue influenceWriteQueue) {
    this(
        reputationService,
        relationshipNetwork,
        influenceService,
        newsService,
        eventScheduler,
        cultureService,
        activityService,
        gossipService,
        influenceWriteQueue,
        System::currentTimeMillis);
  }

  SocialSimulationListener(
      ReputationService reputationService,
      RelationshipNetwork relationshipNetwork,
      SocialInfluenceService influenceService,
      NewsPropagationService newsService,
      SocialEventScheduler eventScheduler,
      CultureService cultureService,
      SocialActivityService activityService,
      GossipService gossipService,
      SocialInfluenceWriteQueue influenceWriteQueue,
      LongSupplier clock) {
    this.reputationService = reputationService;
    this.relationshipNetwork = relationshipNetwork;
    this.influenceService = influenceService;
    this.newsService = newsService;
    this.eventScheduler = eventScheduler;
    this.gossipService = gossipService;
    this.influenceWriteQueue = Objects.requireNonNull(influenceWriteQueue);
    this.clock = Objects.requireNonNull(clock);
  }

  public void register(JavaPlugin plugin) {
    Objects.requireNonNull(plugin, "plugin");
    State next = new State(plugin);
    try {
      synchronized (registrationLock) {
        if (state != null) throw new IllegalStateException("Social listener already registered");
        state = next;
        try {
          plugin.getServer().getPluginManager().registerEvents(this, plugin);
        } catch (RuntimeException failure) {
          state = null;
          HandlerList.unregisterAll(this);
          throw failure;
        }
      }
    } catch (RuntimeException failure) {
      next.owners.shutdown();
      throw failure;
    }
  }

  public void unregister() {
    State retired = null;
    try {
      synchronized (registrationLock) {
        retired = state;
        state = null;
        HandlerList.unregisterAll(this);
      }
    } finally {
      // Owner shutdown must run outside the registration lock: callbacks may unregister us.
      if (retired != null) retired.owners.shutdown();
    }
  }

  private boolean active(State captured) {
    return captured != null && state == captured && captured.plugin.isEnabled();
  }

  private void observe(State captured, CompletableFuture<?> future) {
    if (future == null) return;
    future.whenComplete(
        (ignored, failure) -> {
          if (failure != null && active(captured)) {
            Throwable cause = failure;
            while (cause instanceof CompletionException && cause.getCause() != null)
              cause = cause.getCause();
            if (!(cause instanceof CancellationException))
              captured
                  .plugin
                  .getLogger()
                  .log(Level.WARNING, "SOCIAL_LISTENER_OPERATION_FAILED", cause);
          }
        });
  }

  private void owner(State captured, Player original, Runnable action) {
    if (!active(captured)) return;
    observe(
        captured,
        captured.owners.execute(
            original,
            null,
            () -> {
              if (active(captured)) action.run();
            }));
  }

  private CompletableFuture<Void> io(State captured, String kind, Runnable action) {
    if (!active(captured)) return CompletableFuture.failedFuture(new CancellationException());
    var result =
        influenceWriteQueue.submitMaintenance(
            "listener-" + kind,
            () -> {
              if (active(captured)) action.run();
            });
    observe(captured, result);
    return result;
  }

  private CompletableFuture<Void> influence(State captured, UUID id, int amount, String source) {
    return io(captured, "influence", () -> influenceService.addInfluence(id, amount, source));
  }

  private void names(
      State captured, Player first, Player second, BiConsumer<String, String> action) {
    if (!active(captured) || first == null || second == null) return;
    var a = captured.owners.call(first, null, first::getName);
    var b = captured.owners.call(second, null, second::getName);
    observe(
        captured,
        a.thenCombine(
            b,
            (left, right) -> {
              if (active(captured)) action.accept(left, right);
              return null;
            }));
  }

  private void send(State captured, Player original, String message) {
    owner(captured, original, () -> original.sendMessage(message));
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerJoin(PlayerJoinEvent event) {
    State captured = state;
    Player player = event.getPlayer();
    owner(
        captured,
        player,
        () -> {
          UUID id = player.getUniqueId();
          String name = player.getName();
          captured.sessions.put(id, player);
          captured.killStreak.putIfAbsent(id, 0);
          var write = influence(captured, id, 10, "上线");
          List<CompletableFuture<Integer>> friends = new ArrayList<>();
          for (UUID friendId : relationshipNetwork.getFriends(id)) {
            Player friend = captured.plugin.getServer().getPlayer(friendId);
            if (friend != null)
              friends.add(
                  captured
                      .owners
                      .call(
                          friend,
                          null,
                          () -> {
                            if (!active(captured)) return 0;
                            friend.sendMessage("§a[社交] §e" + name + " §a上线了！");
                            return 1;
                          })
                      .exceptionally(failure -> 0));
          }
          observe(
              captured,
              CompletableFuture.allOf(friends.toArray(CompletableFuture[]::new))
                  .thenRun(
                      () -> {
                        int count = friends.stream().mapToInt(CompletableFuture::join).sum();
                        if (count > 0) send(captured, player, "§a你的 " + count + " 位朋友在线！");
                      }));
          if (reputationService.getReputation(id) > 100)
            observe(
                captured,
                write.thenRun(
                    () ->
                        owner(
                            captured,
                            player,
                            () -> {
                              if (influenceService.getStatus(id).ordinal()
                                  >= SocialInfluenceService.SocialStatus.KNOWN.ordinal())
                                newsService.publishNews(
                                    name + " 回归了！",
                                    "备受尊敬的 " + name + " 重新回到了服务器！",
                                    id,
                                    NewsPropagationService.NewsCategory.SOCIAL);
                            })));
        });
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerQuit(PlayerQuitEvent event) {
    State captured = state;
    Player original = event.getPlayer();
    if (!active(captured) || !Bukkit.isOwnedByCurrentRegion(original)) return;
    UUID id = original.getUniqueId();
    Player current = captured.plugin.getServer().getPlayer(id);
    if ((current != null && current != original)
        || (captured.sessions.containsKey(id) && captured.sessions.get(id) != original)) return;
    String name =
        original.getName(); // Quit event owns the departing player, including offline state.
    captured.sessions.remove(id, original);
    captured.killStreak.remove(id);
    influence(captured, id, -5, "下线");
    for (UUID friendId : relationshipNetwork.getFriends(id)) {
      var relation = relationshipNetwork.getRelationship(friendId, id);
      if (relation != null && relation.strength() > 50)
        send(
            captured,
            captured.plugin.getServer().getPlayer(friendId),
            "§7[社交] §e" + name + " §7下线了");
    }
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerHelpPlayer(PlayerHelpPlayerEvent event) {
    State captured = state;
    Player helper = event.getHelper(), target = event.getTarget();
    if (!active(captured) || helper.getUniqueId().equals(target.getUniqueId())) return;
    UUID from = helper.getUniqueId(), to = target.getUniqueId();
    names(
        captured,
        helper,
        target,
        (helperName, targetName) ->
            io(
                captured,
                "help",
                () -> {
                  long now = clock.getAsLong();
                  captured.helpTimes.entrySet().removeIf(entry -> now - entry.getValue() >= 30_000);
                  if (captured.helpTimes.putIfAbsent(from, now) != null) return;
                  EventEffects effects = eventScheduler.getActiveEffects();
                  var relation = relationshipNetwork.getRelationship(from, to);
                  if (relation == null
                      || relation.type() == RelationshipNetwork.RelationshipType.STRANGER)
                    relationshipNetwork.setRelationship(
                        from, to, RelationshipNetwork.RelationshipType.FRIEND, 30);
                  else relationshipNetwork.increaseStrength(from, to, 5);
                  observe(
                      captured,
                      reputationService.addMoral(
                          from,
                          (int) (5 * (1 + effects.reputationBonus())),
                          "帮助玩家: " + targetName));
                  observe(captured, reputationService.addCharisma(to, 2, "接受他人帮助"));
                  influence(captured, from, (int) (5 * effects.influenceBonus()), "助人为乐");
                  newsService.publishNews(
                      helperName + " 帮助了 " + targetName,
                      helperName + " 向 " + targetName + " 伸出了援手，展现了互助精神。",
                      from,
                      NewsPropagationService.NewsCategory.SOCIAL);
                  gossipService.createGossip(
                      from, helperName + " 帮助了 " + targetName, GossipService.GossipTopic.HEROISM);
                }));
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerAttackPlayer(PlayerAttackPlayerEvent event) {
    State captured = state;
    Player attacker = event.getAttacker(), victim = event.getTarget();
    if (!active(captured) || attacker.getUniqueId().equals(victim.getUniqueId())) return;
    UUID from = attacker.getUniqueId(), to = victim.getUniqueId();
    names(
        captured,
        attacker,
        victim,
        (attackerName, victimName) ->
            io(
                captured,
                "attack",
                () -> {
                  EventEffects effects = eventScheduler.getActiveEffects();
                  relationshipNetwork.decreaseStrength(from, to, 20);
                  var relation = relationshipNetwork.getRelationship(from, to);
                  if (relation != null && relation.strength() <= -30)
                    relationshipNetwork.setRelationship(
                        from, to, RelationshipNetwork.RelationshipType.ENEMY, relation.strength());
                  observe(
                      captured,
                      reputationService.modifyReputation(
                          from,
                          (int) (-10 * (1 + effects.reputationBonus() * .5)),
                          ReputationService.ReputationReason.ATTACK_PLAYER));
                  observe(captured, reputationService.addMoral(to, 3, "被攻击但保持克制"));
                  newsService.publishNews(
                      attackerName + " 攻击了 " + victimName,
                      "一场冲突发生在 " + attackerName + " 和 " + victimName + " 之间。",
                      from,
                      NewsPropagationService.NewsCategory.MILITARY);
                  gossipService.createGossip(
                      from, "听说 " + attackerName + " 又在欺负人了", GossipService.GossipTopic.SCANDAL);
                  Set<UUID> enemies = relationshipNetwork.getEnemies(from);
                  if (enemies.size() > 5
                      && enemies.size() > relationshipNetwork.getFriends(from).size()
                      && RandomProvider.nextDouble() < .05) {
                    newsService.publishNews(
                        "社会动荡: " + attackerName + " 引发冲突",
                        attackerName + " 与多人发生冲突，可能引发更大规模的动荡！",
                        from,
                        NewsPropagationService.NewsCategory.SOCIAL);
                    gossipService.createGossip(
                        from, "听说 " + attackerName + " 和一群人闹翻了", GossipService.GossipTopic.SCANDAL);
                    for (UUID id : enemies)
                      send(
                          captured,
                          captured.plugin.getServer().getPlayer(id),
                          "§c[社交] " + attackerName + " 引发了新的冲突");
                  }
                }));
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerExpChange(PlayerExpChangeEvent event) {
    State captured = state;
    Player player = event.getPlayer();
    int amount = event.getAmount();
    if (amount <= 0) return;
    owner(
        captured,
        player,
        () -> {
          UUID id = player.getUniqueId();
          String name = player.getName();
          io(
              captured,
              "experience",
              () -> {
                int ability =
                    (int)
                        ((amount / 10) * (1 + eventScheduler.getActiveEffects().reputationBonus()));
                if (ability > 0)
                  observe(captured, reputationService.addAbility(id, ability, "获得经验: " + amount));
                if (amount > 50) influence(captured, id, amount / 20, "高效学习");
                if (amount > 200 && RandomProvider.nextDouble() < .1)
                  newsService.publishNews(
                      name + " 取得了巨大进步！",
                      name + " 获得了大量经验，展现出惊人的学习能力！",
                      id,
                      NewsPropagationService.NewsCategory.SOCIAL);
              });
        });
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerLevelChange(PlayerLevelChangeEvent event) {
    if (event.getNewLevel() <= event.getOldLevel()) return;
    State captured = state;
    Player player = event.getPlayer();
    owner(
        captured,
        player,
        () -> {
          UUID id = player.getUniqueId();
          influence(captured, id, 5, "升级");
          List<Player> friends =
              relationshipNetwork.getFriends(id).stream()
                  .map(friend -> captured.plugin.getServer().getPlayer(friend))
                  .filter(Objects::nonNull)
                  .toList();
          if (!friends.isEmpty()) {
            Player original = friends.get(RandomProvider.nextInt(friends.size()));
            UUID friendId = original.getUniqueId();
            owner(
                captured,
                original,
                () ->
                    io(
                        captured,
                        "level-friend",
                        () -> relationshipNetwork.increaseStrength(id, friendId, 2)));
          }
        });
  }

  /** Compatibility entry point; inventory observations are not proof of cheating. */
  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onInventoryClick(InventoryClickEvent event) {}

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerDeath(PlayerDeathEvent event) {
    State captured = state;
    Player victim = event.getEntity();
    owner(
        captured,
        victim,
        () -> {
          UUID victimId = victim.getUniqueId();
          String victimName = victim.getName();
          long observedAt = clock.getAsLong();
          Player killer = victim.getKiller();
          if (killer != null && !killer.getUniqueId().equals(victimId)) {
            UUID killerId = killer.getUniqueId();
            var name =
                captured
                    .owners
                    .call(killer, null, killer::getName)
                    .exceptionally(failure -> killerId.toString().substring(0, 8));
            observe(
                captured,
                name.thenAccept(
                    killerName ->
                        io(
                            captured,
                            "player-death",
                            () -> {
                              EventEffects effects = eventScheduler.getActiveEffects();
                              if (captured.plugin.getServer().getPlayer(victimId) == victim)
                                captured.killStreak.put(victimId, 0);
                              int streak =
                                  captured.plugin.getServer().getPlayer(killerId) == killer
                                      ? captured.killStreak.merge(
                                          killerId, 1, SocialSimulationListener::addCount)
                                      : 0;
                              observe(
                                  captured,
                                  reputationService.addAbility(
                                      killerId,
                                      (int) (10 * (1 + effects.reputationBonus())),
                                      "击败: " + victimName));
                              relationshipNetwork.decreaseStrength(killerId, victimId, 15);
                              var relation =
                                  relationshipNetwork.getRelationship(victimId, killerId);
                              if (relation == null || relation.strength() > -30)
                                relationshipNetwork.decreaseStrength(victimId, killerId, 10);
                              observe(
                                  captured,
                                  reputationService.modifyReputation(
                                      victimId,
                                      (int) (-5 * (1 + effects.reputationBonus() * .5)),
                                      ReputationService.ReputationReason.ATTACK_PLAYER));
                              if (streak > 3)
                                influence(captured, killerId, streak, "连杀: " + streak);
                              if (streak == 5) {
                                newsService.publishNews(
                                    killerName + " 完成五杀！",
                                    killerName + " 以 5 连杀震惊全场！",
                                    killerId,
                                    NewsPropagationService.NewsCategory.MILITARY);
                                gossipService.createGossip(
                                    killerId,
                                    killerName + " 刚刚完成了五杀！",
                                    GossipService.GossipTopic.BATTLE);
                              }
                              deathWindow(captured, victimId, observedAt);
                            })));
          } else
            io(
                captured,
                "environment-death",
                () -> {
                  if (captured.plugin.getServer().getPlayer(victimId) == victim)
                    captured.killStreak.put(victimId, 0);
                  observe(
                      captured,
                      reputationService.modifyReputation(
                          victimId,
                          (int)
                              (-3 * (1 + eventScheduler.getActiveEffects().reputationBonus() * .3)),
                          ReputationService.ReputationReason.ATTACK_PLAYER));
                  deathWindow(captured, victimId, observedAt);
                });
        });
  }

  private void deathWindow(State captured, UUID id, long observedAt) {
    Deque<Long> recent = captured.deaths.computeIfAbsent(id, ignored -> new ArrayDeque<>());
    long now = Math.max(observedAt, recent.isEmpty() ? observedAt : recent.peekLast());
    List<Long> times = new ArrayList<>(recent);
    times.add(observedAt);
    times.removeIf(time -> now - time >= 86_400_000L);
    times.sort(Long::compareTo);
    recent.clear();
    recent.addAll(times);
    while (recent.size() > 6) recent.removeFirst();
    if (recent.size() == 6 && reputationService.getReputation(id) < 0)
      influence(captured, id, -10, "频繁死亡");
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onEntityKill(EntityDeathEvent event) {
    State captured = state;
    LivingEntity dead = event.getEntity();
    if (!active(captured) || dead instanceof Player) return;
    Player killer = dead.getKiller();
    if (killer == null) return;
    int base = getEntityReward(dead);
    String type = event.getEntityType().name();
    boolean dragon = dead instanceof EnderDragon,
        wither = dead instanceof Wither,
        guardian = dead instanceof ElderGuardian;
    owner(
        captured,
        killer,
        () -> {
          UUID id = killer.getUniqueId();
          String name = killer.getName();
          io(
              captured,
              "entity-kill",
              () -> {
                if (dragon || wither || guardian) {
                  String reason = dragon ? "击杀末影龙" : wither ? "击杀凋零" : "击杀远古守卫者";
                  influence(captured, id, dragon ? 500 : wither ? 300 : 50, reason);
                  observe(
                      captured,
                      reputationService.addAbility(id, dragon ? 50 : wither ? 30 : 10, reason));
                  if (dragon)
                    newsService.publishNews(
                        name + " 击败了末影龙！",
                        name + " 击败了沉睡的末影龙，成为了服务器传奇！",
                        id,
                        NewsPropagationService.NewsCategory.HEROIC);
                }
                int reward =
                    (int) (base * (1 + eventScheduler.getActiveEffects().reputationBonus()));
                if (reward > 0)
                  observe(captured, reputationService.addAbility(id, reward, "击杀: " + type));
              });
        });
  }

  private int getEntityReward(Entity entity) {
    if (entity instanceof EnderDragon) return 100;
    if (entity instanceof Wither) return 50;
    if (entity instanceof ElderGuardian) return 20;
    if (entity instanceof Boss) return 15;
    if (entity instanceof Monster) return 3;
    if (entity instanceof Animals) return 1;
    return 0;
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onCraftItem(CraftItemEvent event) {
    if (event.isCancelled() || !(event.getWhoClicked() instanceof Player player)) return;
    Material item = event.getCurrentItem() == null ? null : event.getCurrentItem().getType();
    if (item == null || item.isAir()) return;
    State captured = state;
    owner(
        captured,
        player,
        () -> {
          UUID id = player.getUniqueId();
          String name = player.getName();
          io(
              captured,
              "craft",
              () -> {
                Set<String> crafted =
                    captured.crafted.computeIfAbsent(id, ignored -> ConcurrentHashMap.newKeySet());
                boolean first = crafted.add(item.name());
                observe(captured, reputationService.addAbility(id, 1, "制作: " + item.name()));
                if (isValuableItem(item)) {
                  influence(
                      captured,
                      id,
                      (int) (5 * eventScheduler.getActiveEffects().influenceBonus()),
                      "制作珍贵物品");
                  for (UUID friend : relationshipNetwork.getFriends(id))
                    if (RandomProvider.nextDouble() < .1)
                      send(
                          captured,
                          captured.plugin.getServer().getPlayer(friend),
                          "§6[社交] §e" + name + " §6制作了 " + item.name());
                }
                int count = crafted.size();
                if (first && (count == 10 || count == 50 || count == 100)) {
                  String title = count == 10 ? "初级工匠" : count == 50 ? "中级工匠" : "高级工匠";
                  influence(captured, id, count, title);
                  observe(captured, reputationService.addAbility(id, count / 2, title));
                  send(captured, player, "§6[成就] §e恭喜获得成就: " + title);
                }
              });
        });
  }

  private boolean isValuableItem(Material item) {
    return switch (item) {
      case DIAMOND_HELMET,
              DIAMOND_CHESTPLATE,
              DIAMOND_LEGGINGS,
              DIAMOND_BOOTS,
              DIAMOND_SWORD,
              DIAMOND_PICKAXE,
              NETHERITE_HELMET,
              NETHERITE_CHESTPLATE,
              NETHERITE_LEGGINGS,
              NETHERITE_BOOTS,
              NETHERITE_SWORD,
              NETHERITE_PICKAXE,
              ENCHANTED_GOLDEN_APPLE,
              MUSIC_DISC_13,
              MUSIC_DISC_CAT,
              ELYTRA,
              SHULKER_BOX ->
          true;
      default -> false;
    };
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onFish(PlayerFishEvent event) {
    if (event.isCancelled()) return;
    State captured = state;
    Player player = event.getPlayer();
    PlayerFishEvent.State kind = event.getState();
    Material material =
        event.getCaught() instanceof Item item && Bukkit.isOwnedByCurrentRegion(item)
            ? item.getItemStack().getType()
            : null;
    owner(
        captured,
        player,
        () -> {
          UUID id = player.getUniqueId();
          String name = player.getName();
          io(
              captured,
              "fish",
              () -> {
                if (kind == PlayerFishEvent.State.CAUGHT_FISH) {
                  int count = captured.fish.merge(id, 1, SocialSimulationListener::addCount);
                  observe(captured, reputationService.addCharisma(id, 1, "休闲钓鱼"));
                  if (material == Material.DIAMOND || material == Material.EMERALD) {
                    observe(
                        captured, reputationService.addWealth(id, 5, "钓到贵重物品: " + material.name()));
                    influence(captured, id, 3, "幸运渔夫");
                    gossipService.createGossip(
                        id, name + " 从水里钓出了 " + material.name(), GossipService.GossipTopic.WEALTH);
                  }
                  if (count == 100 || count == 500)
                    influence(captured, id, count == 100 ? 20 : 50, count == 100 ? "钓鱼达人" : "钓鱼大师");
                } else if (kind == PlayerFishEvent.State.IN_GROUND)
                  observe(captured, reputationService.addCharisma(id, -1, "钓鱼失败"));
              });
        });
  }

  private static int addCount(int current, int delta) {
    return (int) Math.min(Integer.MAX_VALUE, (long) current + delta);
  }

  public void broadcastEventEffects(Player player) {
    State captured = state;
    owner(
        captured,
        player,
        () -> {
          EventEffects effects = eventScheduler.getActiveEffects();
          if (effects.reputationBonus() > 0 || effects.influenceBonus() > 1) {
            player.sendMessage("§6【活动加成】当前事件效果:");
            if (effects.reputationBonus() > 0)
              player.sendMessage("§7  - 声望获取: §a+" + (int) (effects.reputationBonus() * 100) + "%");
            if (effects.influenceBonus() > 1)
              player.sendMessage(
                  "§7  - 影响力获取: §a+" + (int) ((effects.influenceBonus() - 1) * 100) + "%");
          }
        });
  }

  public Map<String, Object> getPlayerSocialStats(UUID id) {
    State captured = state;
    Map<String, Object> stats = new HashMap<>();
    stats.put("reputation", reputationService.getReputation(id));
    stats.put("reputationLevel", reputationService.getLevel(id));
    stats.put("influence", influenceService.getInfluence(id));
    stats.put("socialStatus", influenceService.getStatus(id));
    stats.put("friendCount", relationshipNetwork.getFriends(id).size());
    stats.put("enemyCount", relationshipNetwork.getEnemies(id).size());
    stats.put("killStreak", captured == null ? 0 : captured.killStreak.getOrDefault(id, 0));
    stats.put(
        "craftCount", captured == null ? 0 : captured.crafted.getOrDefault(id, Set.of()).size());
    stats.put("fishCount", captured == null ? 0 : captured.fish.getOrDefault(id, 0));
    return Collections.unmodifiableMap(stats);
  }
}
