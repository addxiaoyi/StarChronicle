package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.*;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.mockito.MockedStatic;

final class SocialListenerFixture implements AutoCloseable {
  final JavaPlugin plugin = mock(JavaPlugin.class);
  final Server server = mock(Server.class);
  final ReputationService reputation = mock(ReputationService.class);
  final RelationshipNetwork relationships = mock(RelationshipNetwork.class);
  final SocialInfluenceService influence = mock(SocialInfluenceService.class);
  final NewsPropagationService news = mock(NewsPropagationService.class);
  final SocialEventScheduler events = mock(SocialEventScheduler.class);
  final GossipService gossip = mock(GossipService.class);
  final Map<UUID, Player> players = new ConcurrentHashMap<>();
  final ThreadLocal<Player> owner = new ThreadLocal<>();
  final Deque<Runnable> owners = new ArrayDeque<>(), io = new ArrayDeque<>();
  final AtomicLong now = new AtomicLong(1_000_000L);
  final MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class);
  final SocialInfluenceWriteQueue queue;
  final SocialSimulationListener listener;

  SocialListenerFixture() {
    this(null);
  }

  SocialListenerFixture(Function<Runnable, CompletableFuture<Void>> submitter) {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(java.util.logging.Logger.getLogger("social-listener-test"));
    when(server.getPluginManager()).thenReturn(mock(PluginManager.class));
    when(server.getPlayer(any(UUID.class))).thenAnswer(inv -> players.get(inv.getArgument(0)));
    when(events.getActiveEffects()).thenReturn(new SocialEventScheduler.EventEffects(0, 1, 1));
    queue =
        new SocialInfluenceWriteQueue(
            influence,
            submitter == null
                ? task -> {
                  io.add(task);
                  return new CompletableFuture<>();
                }
                : submitter,
            (subject, error) -> {});
    listener =
        new SocialSimulationListener(
            reputation,
            relationships,
            influence,
            news,
            events,
            null,
            null,
            gossip,
            queue,
            now::get);
    listener.register(plugin);
  }

  Player player(String name) {
    return player(UUID.randomUUID(), name);
  }

  Player player(UUID id, String name) {
    Player player = mock(Player.class);
    EntityScheduler scheduler = mock(EntityScheduler.class);
    when(player.getUniqueId()).thenReturn(id);
    when(player.getName())
        .thenAnswer(
            ignored -> {
              assertSame(player, owner.get());
              return name;
            });
    when(player.isOnline())
        .thenAnswer(
            ignored -> {
              assertSame(player, owner.get());
              return true;
            });
    when(player.getScheduler()).thenReturn(scheduler);
    doAnswer(
            ignored -> {
              assertSame(player, owner.get());
              return null;
            })
        .when(player)
        .sendMessage(anyString());
    bukkit
        .when(() -> Bukkit.isOwnedByCurrentRegion(player))
        .thenAnswer(ignored -> owner.get() == player);
    when(scheduler.run(eq(plugin), any(), any()))
        .thenAnswer(
            inv -> {
              Consumer<ScheduledTask> callback = inv.getArgument(1);
              ScheduledTask handle = mock(ScheduledTask.class);
              owners.add(() -> on(player, () -> callback.accept(handle)));
              return handle;
            });
    players.put(id, player);
    return player;
  }

  void on(Player player, Runnable action) {
    Player before = owner.get();
    owner.set(player);
    try {
      action.run();
    } finally {
      owner.set(before);
    }
  }

  void drainOwners() {
    while (!owners.isEmpty()) owners.removeFirst().run();
  }

  void drainIo() {
    assertNull(owner.get());
    while (!io.isEmpty()) io.removeFirst().run();
  }

  void drain() {
    for (int i = 0; i < 30; i++) {
      drainOwners();
      drainIo();
      if (owners.isEmpty() && io.isEmpty()) return;
    }
    fail("Tasks failed to quiesce");
  }

  @Override
  public void close() {
    try {
      listener.unregister();
      queue.close();
    } finally {
      bukkit.close();
    }
  }
}
