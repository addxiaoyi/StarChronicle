# Frozen V1 factory snapshot

Captured from the unchanged StarCore JAR with SHA-256
`97db36ee40dbc6df8c765c0bbbb92dadcddf8989f5b31db77505d814e31470f1`.
The paired Chronicle `tools/FactoryRecoveryProbe.java` generated three completed
batches and one active batch, using the actual V1 codec and production receipt
writer. Generator source SHA-256:
`5c61452074da32b5dd19e524eb5b51af8c76787af9298f1c2399730a7657dd14`.

The exact `factory-v1.properties` bytes have SHA-256
`0bd7cd1f1810cbf242b43d05c46b6656d05ca8f4fddfb216a685d859f3238483`.
The format-compatibility regression checks this fingerprint before reading it.
It is synthetic test evidence, contains no player data, and must not be regenerated
with the new writer to stand in for compatibility with the old writer.
