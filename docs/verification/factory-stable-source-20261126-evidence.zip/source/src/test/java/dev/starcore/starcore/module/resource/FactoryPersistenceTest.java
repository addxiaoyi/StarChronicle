package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.ProcessingService.*;
import dev.starcore.starcore.module.resource.model.Factory;
import dev.starcore.starcore.module.resource.model.ProcessingRecipe;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class FactoryPersistenceTest {
  final NationId nation = NationId.random();
  final MutableClock clock = new MutableClock();
  final ProductionPersistenceTest.MemoryStorage storage =
      new ProductionPersistenceTest.MemoryStorage();
  final ResourceModule module = new ResourceModule(storage, clock);
  final SimpleProcessingService service = service(module, true);
  final Factory factory = service.buildFactory(nation, "Factory", Factory.FactoryType.SMELTER);

  static SimpleProcessingService service(ResourceModule module, boolean defaults) {
    var service = new SimpleProcessingService(module, mock(ResourcePriceService.class));
    if (defaults) service.initializeDefaultRecipes();
    return service;
  }

  FactoryRequest request(String id) {
    return new FactoryRequest(id, factory.factoryId(), nation, null, "national_industry", 2);
  }

  void fund() {
    assertTrue(module.grant(nation, "mineral", 30));
    assertTrue(module.grant(nation, "energy", 10));
  }

  @Test
  void restartWithoutRecipeUsesFrozenInputsOutputsAndDeadlineAndEmitsOneSource() {
    fund();
    var first = service.startFactoryRun(request("pinned"));
    assertEquals(FactoryStatus.STARTED, first.status());
    assertEquals(clock.instant().plusSeconds(2), first.run().readyAt());
    assertEquals(Map.of("energy", 2L, "mineral", 6L), first.run().inputs());
    assertEquals(Map.of("industrial", 4L), first.run().outputs());
    assertEquals(24, module.amount(nation, "mineral"));
    assertEquals(0, module.amount(nation, "industrial"));
    assertTrue(service.productionReceiptsAfter(0, 10).isEmpty());
    assertTrue(service.upgradeFactory(factory.factoryId()));
    service.registerRecipe(
        new ProcessingRecipe(
            "national_industry",
            "Changed",
            Map.of("mineral", 99L),
            Map.of("industrial", 100L),
            999,
            0,
            1));
    assertEquals(
        FactoryStatus.ALREADY_STARTED, service.startFactoryRun(request("pinned")).status());
    var restarted = new ResourceModule(storage, clock);
    var resumed = service(restarted, false);
    assertEquals(first.run(), resumed.factoryRun("pinned").orElseThrow());
    assertEquals(
        FactoryStatus.NOT_READY, resumed.completeFactoryRun("pinned", nation, null).status());
    clock.advance(2);
    var completed = resumed.completeFactoryRun("pinned", nation, null);
    assertEquals(FactoryStatus.COMPLETED, completed.status());
    assertEquals(first.run().readyAt(), completed.run().completedAt());
    assertEquals(4, restarted.amount(nation, "industrial"));
    assertFalse(resumed.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertEquals(
        List.of(completed.run().productionReceipt()), resumed.productionReceiptsAfter(0, 10));
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED, resumed.startFactoryRun(request("pinned")).status());
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        resumed.completeFactoryRun("pinned", nation, null).status());
    assertTrue(restarted.grant(nation, "luxury", 1));
    var twice = new ResourceModule(storage, clock);
    assertEquals(completed.run(), service(twice, false).factoryRun("pinned").orElseThrow());
    assertEquals(4, twice.amount(nation, "industrial"));
  }

  @Test
  void exactBatchesNeverPartiallyConsumeAndIdleCompletionIsEmpty() {
    assertFalse(service.isProcessingComplete(factory.factoryId()));
    assertTrue(service.completeProcessing(factory.factoryId()).isEmpty());
    module.grant(nation, "mineral", 30);
    module.grant(nation, "energy", 1);
    assertEquals(
        FactoryStatus.INSUFFICIENT_RESOURCES, service.startFactoryRun(request("exact")).status());
    assertEquals(30, module.amount(nation, "mineral"));
    assertFalse(service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertTrue(service.factoryRun("exact").isEmpty());
    assertTrue(service.startProcessing(factory.factoryId(), "national_industry", 100));
    var run = service.activeFactoryRun(factory.factoryId()).orElseThrow();
    assertEquals(1, run.batches());
    assertNull(run.actorId());
    clock.advance(1);
    assertEquals(
        Map.of("industrial", 2L), service.completeProcessing(factory.factoryId()).orElseThrow());
    assertTrue(service.completeProcessing(factory.factoryId()).isEmpty());
  }

  @Test
  void factoryMetadataCommitsAndAllPublicSnapshotsAreDetached() {
    Factory read = service.getFactory(factory.factoryId()).orElseThrow();
    read.startProcessing("fabricated", 1);
    read.setLevel(10);
    read.setOperational(false);
    factory.setEfficiency(2);
    service.snapshotFactories().get(factory.factoryId()).startProcessing("fabricated", 1);
    service.getFactories(nation).iterator().next().finishProcessing();
    assertFalse(service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertEquals(1, service.getFactory(factory.factoryId()).orElseThrow().level());
    assertTrue(service.upgradeFactory(factory.factoryId()));
    assertTrue(service.setFactoryOperational(factory.factoryId(), false));
    Factory restored =
        service(new ResourceModule(storage, clock), false)
            .getFactory(factory.factoryId())
            .orElseThrow();
    assertEquals(2, restored.level());
    assertEquals(1.05, restored.efficiency());
    assertFalse(restored.isOperational());
    assertThrows(UnsupportedOperationException.class, () -> service.restoreFactories(Map.of()));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void startFailureBeforeOrAfterCommitReconcilesWholeStateForSameKeyRetry(boolean afterCommit) {
    fund();
    storage.failBefore = !afterCommit;
    storage.failAfter = afterCommit;
    assertEquals(FactoryStatus.UNKNOWN, service.startFactoryRun(request("start-failure")).status());
    assertEquals(afterCommit, service.factoryRun("start-failure").isPresent());
    assertEquals(afterCommit, service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertEquals(afterCommit ? 24 : 30, module.amount(nation, "mineral"));
    assertTrue(module.grant(nation, "luxury", 1));
    var restarted = new ResourceModule(storage, clock);
    var resumed = service(restarted, true);
    assertEquals(
        afterCommit ? FactoryStatus.ALREADY_STARTED : FactoryStatus.STARTED,
        resumed.startFactoryRun(request("start-failure")).status());
    assertEquals(24, restarted.amount(nation, "mineral"));
    assertEquals(8, restarted.amount(nation, "energy"));
    clock.advance(2);
    assertEquals(
        FactoryStatus.COMPLETED,
        resumed.completeFactoryRun("start-failure", nation, null).status());
    assertEquals(4, restarted.amount(nation, "industrial"));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void completionFailureReconcilesOutputsFactoryOccupancyAndReceiptTogether(boolean afterCommit) {
    fund();
    service.startFactoryRun(request("finish-failure"));
    clock.advance(2);
    storage.failBefore = !afterCommit;
    storage.failAfter = afterCommit;
    assertEquals(
        FactoryStatus.UNKNOWN, service.completeFactoryRun("finish-failure", nation, null).status());
    assertEquals(afterCommit, service.factoryRun("finish-failure").orElseThrow().completed());
    assertEquals(
        !afterCommit, service.getFactory(factory.factoryId()).orElseThrow().isProcessing());
    assertEquals(afterCommit ? 4 : 0, module.amount(nation, "industrial"));
    assertTrue(module.grant(nation, "luxury", 1));
    var restarted = new ResourceModule(storage, clock);
    var resumed = service(restarted, false);
    assertEquals(
        afterCommit ? FactoryStatus.ALREADY_COMPLETED : FactoryStatus.COMPLETED,
        resumed.completeFactoryRun("finish-failure", nation, null).status());
    assertEquals(4, restarted.amount(nation, "industrial"));
    assertEquals(24, restarted.amount(nation, "mineral"));
    assertEquals(1, resumed.productionReceiptsAfter(0, 100).size());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void unreadableUncertainStartOrCompletionBlocksAllLaterSnapshotsUntilRestart(boolean completion) {
    fund();
    if (completion) service.startFactoryRun(request("quarantine"));
    clock.advance(2);
    storage.failAfter = true;
    storage.failReadAfterCommit = true;
    var result =
        completion
            ? service.completeFactoryRun("quarantine", nation, null)
            : service.startFactoryRun(request("quarantine"));
    assertEquals(FactoryStatus.UNKNOWN, result.status());
    assertEquals("", module.authorityDomainId());
    assertEquals(
        FactoryStatus.UNAVAILABLE, service.startFactoryRun(request("quarantine")).status());
    assertThrows(IllegalStateException.class, () -> service.factoryRun("quarantine"));
    assertThrows(IllegalStateException.class, () -> service.upgradeFactory(factory.factoryId()));
    assertFalse(module.grant(nation, "mineral", 100));
    assertFalse(module.consume(nation, "mineral", 1));
    storage.unreadable = false;
    var resumedModule = new ResourceModule(storage, clock);
    var resumed = service(resumedModule, false);
    assertEquals(completion, resumed.factoryRun("quarantine").orElseThrow().completed());
    assertEquals(24, resumedModule.amount(nation, "mineral"));
    if (!completion) clock.advance(2);
    assertEquals(
        completion ? FactoryStatus.ALREADY_COMPLETED : FactoryStatus.COMPLETED,
        resumed.completeFactoryRun("quarantine", nation, null).status());
    assertEquals(4, resumedModule.amount(nation, "industrial"));
  }

  @Test
  void changedTermsOrForeignNationCannotReuseRunAndOldCompletionCannotCollectNewRun() {
    fund();
    service.startFactoryRun(request("one"));
    for (FactoryRequest changed :
        List.of(
            new FactoryRequest("one", UUID.randomUUID(), nation, null, "national_industry", 2),
            new FactoryRequest(
                "one", factory.factoryId(), NationId.random(), null, "national_industry", 2),
            new FactoryRequest(
                "one", factory.factoryId(), nation, UUID.randomUUID(), "national_industry", 2),
            new FactoryRequest("one", factory.factoryId(), nation, null, "national_chemicals", 2),
            new FactoryRequest("one", factory.factoryId(), nation, null, "national_industry", 1)))
      assertEquals(FactoryStatus.REJECTED, service.startFactoryRun(changed).status());
    assertEquals(FactoryStatus.BUSY, service.startFactoryRun(request("two")).status());
    clock.advance(2);
    assertEquals(
        FactoryStatus.REJECTED,
        service.completeFactoryRun("one", NationId.random(), null).status());
    service.completeFactoryRun("one", nation, null);
    assertEquals(FactoryStatus.STARTED, service.startFactoryRun(request("two")).status());
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED, service.completeFactoryRun("one", nation, null).status());
    assertTrue(service.activeFactoryRun(factory.factoryId()).isPresent());
    assertEquals(4, module.amount(nation, "industrial"));
    assertEquals(
        ProductionStatus.REJECTED,
        service
            .process(new ProductionRequest("factory:two", nation, null, "national_industry", 2))
            .status());
  }

  @Test
  void founderIsRecheckedAtServiceAndCompletionKeepsOriginalContributorAcrossSuccession()
      throws Exception {
    fund();
    UUID actor = UUID.randomUUID();
    UUID successor = UUID.randomUUID();
    Nation actual = new Nation(nation, "Nation", actor, "Founder");
    var nations = mock(NationService.class);
    var field = ResourceModule.class.getDeclaredField("nationService");
    field.setAccessible(true);
    field.set(module, nations);
    FactoryRequest request =
        new FactoryRequest("actor", factory.factoryId(), nation, actor, "national_industry", 2);
    assertEquals(FactoryStatus.REJECTED, service.startFactoryRun(request).status());
    when(nations.nationOf(actor)).thenReturn(Optional.of(actual));
    assertEquals(FactoryStatus.STARTED, service.startFactoryRun(request).status());
    actual.setFounderId(successor);
    when(nations.nationOf(successor)).thenReturn(Optional.of(actual));
    clock.advance(2);
    assertEquals(
        FactoryStatus.REJECTED, service.completeFactoryRun("actor", nation, actor).status());
    assertEquals(
        FactoryStatus.COMPLETED, service.completeFactoryRun("actor", nation, successor).status());
    assertEquals(actor, service.productionReceipt("factory:actor").orElseThrow().actorId());
  }

  @Test
  void invalidQuantitiesResourceTypesOrDurationOverflowDoNotDeductAnything() {
    fund();
    for (ProcessingRecipe recipe :
        List.of(
            new ProcessingRecipe("bad", "bad", Map.of(), Map.of("industrial", 1L), 1, 0, 1),
            new ProcessingRecipe(
                "bad", "bad", Map.of("mineral", -1L), Map.of("industrial", 1L), 1, 0, 1),
            new ProcessingRecipe(
                "bad", "bad", Map.of("mineral", 1L), Map.of("unknown", 1L), 1, 0, 1),
            new ProcessingRecipe(
                "bad", "bad", Map.of("mineral", 1L), Map.of("industrial", Long.MAX_VALUE), 1, 0, 1),
            new ProcessingRecipe(
                "bad",
                "bad",
                Map.of("mineral", 1L),
                Map.of("industrial", 1L),
                Long.MAX_VALUE,
                0,
                1),
            new ProcessingRecipe(
                "bad",
                "bad",
                Map.of("mineral", 1L),
                Map.of("industrial", 1L),
                Long.MAX_VALUE / 2,
                0,
                1))) {
      service.registerRecipe(recipe);
      assertEquals(
          FactoryStatus.REJECTED,
          service
              .startFactoryRun(
                  new FactoryRequest("bad", factory.factoryId(), nation, null, "bad", 2))
              .status());
    }
    assertEquals(30, module.amount(nation, "mineral"));
    assertTrue(service.factoryRun("bad").isEmpty());
  }

  @Test
  void fullOutputStockpileLeavesBatchRecoverableAndStopOrUpgradeDoesNotRewriteDeadline() {
    fund();
    var run = service.startFactoryRun(request("capacity")).run();
    service.upgradeFactory(factory.factoryId());
    service.setFactoryOperational(factory.factoryId(), false);
    assertEquals(run, service.factoryRun("capacity").orElseThrow());
    assertTrue(module.grant(nation, "industrial", Long.MAX_VALUE >>> 1));
    assertTrue(module.grant(nation, "industrial", Long.MAX_VALUE >>> 1));
    assertTrue(module.grant(nation, "industrial", 1));
    assertEquals(Long.MAX_VALUE, module.amount(nation, "industrial"));
    clock.advance(2);
    assertEquals(
        FactoryStatus.REJECTED, service.completeFactoryRun("capacity", nation, null).status());
    assertFalse(service.factoryRun("capacity").orElseThrow().completed());
    assertTrue(module.consume(nation, "industrial", 10));
    service.refreshFactories();
    assertTrue(service.factoryRun("capacity").orElseThrow().completed());
    assertEquals(Long.MAX_VALUE - 6, module.amount(nation, "industrial"));
    service.refreshFactories();
    assertEquals(1, service.productionReceiptsAfter(0, 10).size());
  }

  @Test
  void legacyActiveFactoryIsRetainedButNeverUsesCurrentRecipeToInventAnOutput() {
    Factory legacy =
        new Factory(
            factory.factoryId(),
            nation,
            "Old",
            Factory.FactoryType.SMELTER,
            clock.instant().minusSeconds(100),
            1,
            1,
            true,
            "national_industry",
            clock.instant().minusSeconds(10),
            2);
    storage.state =
        ResourceStateCodec.toProperties(
            Map.of(nation, Map.of("mineral", 24L)), Map.of(), Map.of(legacy.factoryId(), legacy));
    storage.state.setProperty("resource.authority-domain", module.authorityDomainId());
    var restarted = new ResourceModule(storage, clock);
    var resumed = service(restarted, true);
    assertEquals(
        FactoryStatus.LEGACY_REVIEW_REQUIRED, resumed.startFactoryRun(request("new")).status());
    assertFalse(resumed.isProcessingComplete(legacy.factoryId()));
    assertTrue(resumed.completeProcessing(legacy.factoryId()).isEmpty());
    resumed.refreshFactories();
    assertTrue(restarted.grant(nation, "luxury", 1));
    var again = new ResourceModule(storage, clock);
    assertTrue(service(again, true).getFactory(legacy.factoryId()).orElseThrow().isProcessing());
    assertEquals(0, again.amount(nation, "industrial"));
    assertTrue(service(again, false).productionReceiptsAfter(0, 10).isEmpty());
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "resource.factory-runs.version",
        "resource.factory-runs.count",
        "resource.factory-runs.head",
        "resource.factory-runs.row.0.id",
        "resource.factory-runs.row.0.outputs",
        "resource.factory-runs.row.0.ready",
        "factory.count",
        "factory.0.id",
        "factory.0.processingBatches",
        "resource.authority-domain"
      })
  void corruptOrMissingRunOrFactoryMetadataQuarantinesWrites(String key) {
    fund();
    service.startFactoryRun(request("corrupt"));
    String actualKey =
        key.replace("resource.factory-runs.row.0.", FactoryRunStore.rowPrefix("corrupt"));
    assertNotNull(storage.state.remove(actualKey));
    Properties before = storage.load();
    var corrupted = new ResourceModule(storage, clock);
    assertEquals("", corrupted.authorityDomainId());
    assertFalse(corrupted.grant(nation, "industrial", 1));
    assertEquals(
        FactoryStatus.UNAVAILABLE,
        service(corrupted, true).startFactoryRun(request("new")).status());
    assertEquals(before, storage.load());
  }

  @Test
  void completedRunRequiresItsMatchingProductionReceiptEvenWithValidSnapshotHash() {
    fund();
    FactoryRun active = service.startFactoryRun(request("forged")).run();
    Factory idle = service.getFactory(factory.factoryId()).orElseThrow();
    idle.finishProcessing();
    Properties forged =
        ResourceStateCodec.toProperties(
            Map.of(nation, module.stockpile(nation)), Map.of(), Map.of(idle.factoryId(), idle));
    forged.setProperty("resource.authority-domain", module.authorityDomainId());
    FactoryRunStore.write(
        forged,
        Map.of(active.runId(), active.complete(active.readyAt(), 1)),
        Map.of(idle.factoryId(), idle));
    storage.state = forged;
    var corrupted = new ResourceModule(storage, clock);
    assertEquals("", corrupted.authorityDomainId());
    assertFalse(corrupted.grant(nation, "industrial", 1));
  }

  @Test
  void concurrentRetriesDeductAndDeliverExactlyOnce() throws Exception {
    fund();
    try (var executor = Executors.newFixedThreadPool(2)) {
      var starts =
          executor.invokeAll(
              List.of(
                  () -> service.startFactoryRun(request("race")).status(),
                  () -> service.startFactoryRun(request("race")).status()));
      Set<Object> statuses = new HashSet<>();
      for (var future : starts) statuses.add(future.get(10, TimeUnit.SECONDS));
      assertEquals(Set.of(FactoryStatus.STARTED, FactoryStatus.ALREADY_STARTED), statuses);
      clock.advance(2);
      var finishes =
          executor.invokeAll(
              List.of(
                  () -> service.completeFactoryRun("race", nation, null).status(),
                  () -> service.completeFactoryRun("race", nation, null).status()));
      statuses.clear();
      for (var future : finishes) statuses.add(future.get(10, TimeUnit.SECONDS));
      assertEquals(Set.of(FactoryStatus.COMPLETED, FactoryStatus.ALREADY_COMPLETED), statuses);
    }
    assertEquals(24, module.amount(nation, "mineral"));
    assertEquals(4, module.amount(nation, "industrial"));
    assertEquals(1, service.productionReceiptsAfter(0, 10).size());
  }

  @Test
  void stockpileReadersWaitForStartTransactionAndSeeReconciledFailure() throws Exception {
    var entered = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    var readerEntered = new CountDownLatch(1);
    var blocking =
        new ProductionPersistenceTest.MemoryStorage() {
          volatile boolean block;

          @Override
          public void save(Properties p) {
            if (block) {
              block = false;
              entered.countDown();
              try {
                if (!release.await(10, TimeUnit.SECONDS))
                  throw new IllegalStateException("test timed out");
              } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e);
              }
            }
            super.save(p);
          }
        };
    var resources = new ResourceModule(blocking, clock);
    var processing = service(resources, true);
    resources.grant(nation, "mineral", 30);
    resources.grant(nation, "energy", 10);
    var f = processing.buildFactory(nation, "Blocking", Factory.FactoryType.SMELTER);
    blocking.block = true;
    blocking.failBefore = true;
    try (var executor = Executors.newFixedThreadPool(2)) {
      var start =
          executor.submit(
              () ->
                  processing.startFactoryRun(
                      new FactoryRequest(
                          "blocked", f.factoryId(), nation, null, "national_industry", 2)));
      try {
        assertTrue(entered.await(10, TimeUnit.SECONDS));
        var read =
            executor.submit(
                () -> {
                  readerEntered.countDown();
                  return resources.amount(nation, "mineral");
                });
        assertTrue(readerEntered.await(10, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> read.get(100, TimeUnit.MILLISECONDS));
        release.countDown();
        assertEquals(FactoryStatus.UNKNOWN, start.get(10, TimeUnit.SECONDS).status());
        assertEquals(30, read.get(10, TimeUnit.SECONDS));
      } finally {
        release.countDown();
      }
    }
  }

  @Test
  void legacyOrphanFactoryRowIsNotSilentlyDiscardedOnSave() {
    Properties p =
        ResourceStateCodec.toProperties(Map.of(), Map.of(), Map.of(factory.factoryId(), factory));
    p.remove("factory.count");
    p.setProperty("resource.authority-domain", module.authorityDomainId());
    storage.state = p;
    var restored = new ResourceModule(storage, clock);
    assertEquals("", restored.authorityDomainId());
    assertFalse(restored.grant(nation, "mineral", 1));
    assertEquals(p, storage.state);
  }

  static class MutableClock extends Clock {
    Instant now = Instant.parse("2026-11-26T00:00:00Z");

    void advance(long seconds) {
      now = now.plusSeconds(seconds);
    }

    @Override
    public ZoneId getZone() {
      return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zone) {
      return this;
    }

    @Override
    public Instant instant() {
      return now;
    }
  }
}
