package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.ProcessingService.FactoryStatus;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.*;
import java.util.*;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.sqlite.SQLiteDataSource;

class FactorySnapshotVersionTest {
  @TempDir Path directory;
  static final String PREFIX = FactoryRunStore.PREFIX;
  static final NationId NATION = new NationId(new UUID(0, 1));
  static final Clock CLOCK = Clock.fixed(Instant.parse("2026-11-26T00:01:00Z"), ZoneOffset.UTC);

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static Properties legacy() throws Exception {
    try (var in =
        FactorySnapshotVersionTest.class.getResourceAsStream("/resource/factory-v1.properties")) {
      assertNotNull(in);
      byte[] bytes = in.readAllBytes();
      assertEquals(
          "0bd7cd1f1810cbf242b43d05c46b6656d05ca8f4fddfb216a685d859f3238483",
          HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
      Properties p = new Properties();
      p.load(new java.io.ByteArrayInputStream(bytes));
      return p;
    }
  }

  static Properties copy(Properties p) {
    var result = new Properties();
    result.putAll(p);
    return result;
  }

  static Map<String, FactoryRun> restore(Properties p, ResourceStateStorage storage) {
    var factories =
        ResourceStateCodec.snapshotFromProperties(p, ResourceModule.RESOURCE_TYPES).factories();
    return FactoryRunStore.read(p, factories, ResourceModule.RESOURCE_TYPES, storage);
  }

  static void rewrite(Properties p, Map<String, FactoryRun> runs) {
    FactoryRunStore.write(
        p,
        runs,
        ResourceStateCodec.snapshotFromProperties(p, ResourceModule.RESOURCE_TYPES).factories());
  }

  static void rehash(Properties p) throws Exception {
    var method = FactoryRunStore.class.getDeclaredMethod("fingerprint", Properties.class);
    method.setAccessible(true);
    p.setProperty(PREFIX + "head", (String) method.invoke(null, p));
  }

  @Test
  void frozenV1LoadsWithoutWritesAndSuccessfulRewriteKeepsAllLogicalEvidence() throws Exception {
    var original = legacy();
    var before = copy(original);
    var runs = restore(original, FactoryReceiptValidationTest.SNAPSHOT_ONLY);
    assertEquals(before, original);
    assertEquals(4, runs.size());
    assertFalse(runs.get("batch-3").completed());
    assertTrue(runs.get("batch-0").completed());
    assertEquals(3, runs.get("batch-2").completionSequence());
    rewrite(original, runs);
    assertEquals("2", original.getProperty(PREFIX + "version"));
    assertFalse(original.containsKey(PREFIX + "row.0.id"));
    assertEquals(runs, restore(original, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    for (String key : before.stringPropertyNames())
      if (!key.startsWith(PREFIX)) assertEquals(before.get(key), original.get(key), key);
    var stable = copy(original);
    rewrite(original, runs);
    assertEquals(stable, original);
  }

  @Test
  void earlierIdDoesNotMoveAnyExistingV2BatchField() {
    var fixture = FactoryReceiptValidationTest.fixture(513);
    var p = copy(fixture.state());
    var runs = new LinkedHashMap<>(fixture.runs());
    var reference = runs.get("batch-0");
    var inserted = renamed(reference, "000-before-all", 515);
    runs.put(inserted.runId(), inserted);
    FactoryReceiptValidationTest.writeReceipt(p, inserted.productionReceipt());
    rewrite(p, runs);
    for (String key : fixture.state().stringPropertyNames())
      if (key.startsWith(PREFIX + "row.")) assertEquals(fixture.state().get(key), p.get(key), key);
    assertEquals(runs, restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    assertEquals(
        "000-before-all", p.getProperty(FactoryRunStore.rowPrefix(inserted.runId()) + "id"));
  }

  static FactoryRun renamed(FactoryRun r, String id, long sequence) {
    return new FactoryRun(
        id,
        r.authorityDomainId(),
        r.factoryId(),
        r.nationId(),
        r.actorId(),
        r.recipeId(),
        r.batches(),
        r.inputs(),
        r.outputs(),
        r.startedAt(),
        r.readyAt(),
        r.readyAt().plusSeconds(1),
        sequence);
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void stableKeysFitActualSqlColumnAndPreserveCaseDistinctMaximumLengthIds(String engine) {
    var fixture = FactoryReceiptValidationTest.fixture(1);
    var p = copy(fixture.state());
    var runs = new LinkedHashMap<>(fixture.runs());
    long sequence = 2;
    for (String id : List.of("A", "a", "x".repeat(96), "X".repeat(96), "a.b:c_d-e")) {
      var inserted = renamed(runs.get("batch-0"), id, ++sequence);
      runs.put(id, inserted);
      FactoryReceiptValidationTest.writeReceipt(p, inserted.productionReceipt());
      assertTrue(
          FactoryRunStore.rowPrefix(id).matches("resource\\.factory-runs\\.row\\.[0-9a-f]{64}\\."));
    }
    rewrite(p, runs);
    assertTrue(p.stringPropertyNames().stream().allMatch(k -> k.length() <= 191));
    var storage = storage(database(engine), new Properties());
    storage.load();
    storage.save(p);
    assertEquals(runs, restore(storage.load(), storage));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "v1-order",
        "v2-alias",
        "v2-duplicate-id",
        "v2-missing-id",
        "v2-extra-field",
        "v2-count",
        "future-version"
      })
  void authenticChecksumCannotConcealNoncanonicalKeysMissingFieldsOrDuplicateIds(String kind)
      throws Exception {
    var p = legacy();
    var runs = restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY);
    if (kind.equals("v1-order")) {
      var a = PREFIX + "row.0.";
      var b = PREFIX + "row.1.";
      var old = copy(p);
      for (String key : old.stringPropertyNames())
        if (key.startsWith(a)) {
          String field = key.substring(a.length());
          p.setProperty(key, old.getProperty(b + field));
          p.setProperty(b + field, old.getProperty(key));
        }
    } else {
      rewrite(p, runs);
      String row = FactoryRunStore.rowPrefix("batch-0");
      switch (kind) {
        case "v2-alias" -> {
          var old = copy(p);
          for (String key : old.stringPropertyNames())
            if (key.startsWith(row)) {
              p.remove(key);
              p.setProperty(
                  PREFIX + "row.alias." + key.substring(row.length()), old.getProperty(key));
            }
        }
        case "v2-duplicate-id" -> p.setProperty(row + "id", "batch-1");
        case "v2-missing-id" -> p.remove(row + "id");
        case "v2-extra-field" -> p.setProperty(row + "unknown", "hidden");
        case "v2-count" -> p.setProperty(PREFIX + "count", "3");
        case "future-version" -> p.setProperty(PREFIX + "version", "3");
      }
    }
    rehash(p);
    assertThrows(
        IllegalStateException.class, () -> restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
  }

  @Test
  void writeRejectsAMapThatWouldLoseOrRebindItsStableIdentifier() throws Exception {
    var p = legacy();
    var runs = restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY);
    assertThrows(
        IllegalStateException.class,
        () -> rewrite(p, Map.of("different-key", runs.get("batch-0"))));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void fileUpgradeFailureOrLostAcknowledgementReconcilesTheSameV1Run(boolean afterCommit)
      throws Exception {
    var file = new ProductionPersistenceTest.MemoryStorage();
    file.state = legacy();
    var original = file.load();
    var module = new ResourceModule(file, CLOCK);
    var service = FactoryPersistenceTest.service(module, false);
    assertEquals(original, file.load());
    file.failBefore = !afterCommit;
    file.failAfter = afterCommit;
    assertEquals(
        FactoryStatus.UNKNOWN, service.completeFactoryRun("batch-3", NATION, null).status());
    assertEquals(afterCommit ? 8 : 6, module.amount(NATION, "industrial"));
    assertEquals(afterCommit ? "2" : "1", file.load().getProperty(PREFIX + "version"));
    if (!afterCommit) assertEquals(original, file.load());
    var restarted = new ResourceModule(file, CLOCK);
    var resumed = FactoryPersistenceTest.service(restarted, false);
    assertEquals(
        afterCommit ? FactoryStatus.ALREADY_COMPLETED : FactoryStatus.COMPLETED,
        resumed.completeFactoryRun("batch-3", NATION, null).status());
    assertEquals(8, restarted.amount(NATION, "industrial"));
    assertEquals(4, resumed.productionReceiptsAfter(0, 10).size());
    assertEquals("2", file.load().getProperty(PREFIX + "version"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void rejectedV1ToV2CommitRollsBackFormatInventoryAndNewCompletionReceipt(String engine)
      throws Exception {
    var db = database(engine);
    var legacy = legacy();
    var storage = storage(db, legacy);
    var module = new ResourceModule(storage, CLOCK);
    var service = FactoryPersistenceTest.service(module, false);
    var original = storage.load();
    assertEquals("1", original.getProperty(PREFIX + "version"));
    assertEquals(3, storage.latestProductionSequence());
    var sql = new SqlFactoryPersistenceTest();
    sql.rejectState(db, engine, "property_key='" + PREFIX + "version' AND property_value='2'");
    assertEquals(
        FactoryStatus.UNKNOWN, service.completeFactoryRun("batch-3", NATION, null).status());
    assertEquals(original, storage.load());
    assertEquals(6, module.amount(NATION, "industrial"));
    assertEquals(3, storage.latestProductionSequence());
    sql.removeRejection(db, engine);
    var restarted = new ResourceModule(storage(db, legacy), CLOCK);
    var resumed = FactoryPersistenceTest.service(restarted, false);
    assertEquals(
        FactoryStatus.COMPLETED, resumed.completeFactoryRun("batch-3", NATION, null).status());
    assertEquals(8, restarted.amount(NATION, "industrial"));
    assertEquals("2", storage.load().getProperty(PREFIX + "version"));
    assertEquals(4, storage.latestProductionSequence());
    assertEquals(legacy(), legacy);
    var again = new ResourceModule(storage(db, legacy), CLOCK);
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        FactoryPersistenceTest.service(again, false)
            .completeFactoryRun("batch-3", NATION, null)
            .status());
    assertEquals(8, again.amount(NATION, "industrial"));
  }

  DataSource database(String engine) {
    if (engine.equals("sqlite")) {
      var db = new SQLiteDataSource();
      db.setUrl("jdbc:sqlite:" + directory.resolve("stable.db"));
      return db;
    }
    var db = new JdbcDataSource();
    db.setURL("jdbc:h2:mem:stable-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
    return db;
  }

  static SqlResourceStateStorage storage(DataSource db, Properties legacy) {
    return new SqlResourceStateStorage(db, legacy, Logger.getLogger("factory-version"));
  }
}
