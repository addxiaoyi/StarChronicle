package dev.starcore.starcore.essentials.social;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Set;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/** SocialService 完整测试 */
@DisplayName("SocialService 综合测试")
class SocialServiceComprehensiveTest {

  private SocialService service;
  private Player sender;
  private Player recipient;
  private UUID senderId;
  private UUID recipientId;

  @BeforeEach
  void setUp() {
    service = new SocialService();
    sender = Mockito.mock(Player.class);
    recipient = Mockito.mock(Player.class);
    senderId = UUID.randomUUID();
    recipientId = UUID.randomUUID();
    Mockito.when(sender.getUniqueId()).thenReturn(senderId);
    Mockito.when(recipient.getUniqueId()).thenReturn(recipientId);
    Mockito.when(sender.getName()).thenReturn("Sender");
    Mockito.when(recipient.getName()).thenReturn("Recipient");
  }

  @Test
  void sendMessage_ok() {
    assertThat(service.sendMessage(sender, recipient, "hi")).isTrue();
  }

  @Test
  void sendMessage_blocked() {
    // recipient 屏蔽 sender
    service.ignorePlayer(recipientId, senderId);
    assertThat(service.sendMessage(sender, recipient, "hi")).isFalse();
  }

  @Test
  void getLastMessaged_empty() {
    assertThat(service.getLastMessaged(senderId)).isEmpty();
  }

  @Test
  void ignorePlayer_ok() {
    assertThat(service.ignorePlayer(senderId, recipientId)).isTrue();
    assertThat(service.getIgnoredPlayers(senderId)).contains(recipientId);
  }

  @Test
  void ignorePlayer_self() {
    assertThat(service.ignorePlayer(senderId, senderId)).isFalse();
  }

  @Test
  void ignorePlayer_duplicate() {
    service.ignorePlayer(senderId, recipientId);
    assertThat(service.ignorePlayer(senderId, recipientId)).isFalse();
  }

  @Test
  void unignorePlayer_ok() {
    service.ignorePlayer(senderId, recipientId);
    assertThat(service.unignorePlayer(senderId, recipientId)).isTrue();
  }

  @Test
  void unignorePlayer_unknown() {
    assertThat(service.unignorePlayer(senderId, recipientId)).isFalse();
  }

  @Test
  void getIgnoredPlayers_empty() {
    assertThat(service.getIgnoredPlayers(senderId)).isEmpty();
  }

  @Test
  void getMessageHistory_empty() {
    assertThat(service.getMessageHistory(senderId)).isEmpty();
  }

  @Test
  void cleanup() {
    service.ignorePlayer(senderId, recipientId);
    service.cleanup(senderId);
    assertThat(service.getIgnoredPlayers(senderId)).isEmpty();
  }

  @Test
  void loadPlayerData() {
    service.loadPlayerData(senderId, Set.of(recipientId));
    assertThat(service.getIgnoredPlayers(senderId)).contains(recipientId);
  }

  @Test
  void loadPlayerData_null() {
    service.loadPlayerData(senderId, null);
    assertThat(service.getIgnoredPlayers(senderId)).isEmpty();
  }

  @Test
  void loadPlayerData_emptySet() {
    service.loadPlayerData(senderId, Set.of());
    assertThat(service.getIgnoredPlayers(senderId)).isEmpty();
  }

  @Test
  void getPlayerData() {
    service.ignorePlayer(senderId, recipientId);
    assertThat(service.getPlayerData(senderId)).contains(recipientId);
  }

  @Test
  void messageFormat() {
    SocialService.Message m =
        new SocialService.Message(senderId, recipientId, "hi", java.time.Instant.now());
    String s = m.format();
    assertThat(s).contains(senderId.toString()).contains(recipientId.toString()).contains("hi");
  }

  @Test
  void sendMessage_addsToHistory() {
    service.sendMessage(sender, recipient, "hi");
    assertThat(service.getMessageHistory(senderId)).hasSize(1);
    assertThat(service.getMessageHistory(recipientId)).hasSize(1);
  }

  @Test
  void getLastMessaged_present() {
    service.sendMessage(sender, recipient, "hi");
    assertThat(service.getLastMessaged(senderId)).isPresent();
  }
}
