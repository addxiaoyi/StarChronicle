package dev.starcore.starcore;

import static org.assertj.core.api.Assertions.assertThat;

import dev.starcore.starcore.social.simulation.ActivityRewardService.ActivityRewardType;
import dev.starcore.starcore.social.simulation.ActivityRewardService.HolidayType;
import dev.starcore.starcore.social.simulation.SocialActivityService.SocialActivityType;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

class StartupConfigurationTest {
  @Test
  void registersAuditLoggingBeforeModulesStart() throws IOException {
    String source = source("StarCorePlugin.java");

    assertThat(source).contains("register(AuditLogService.class");
  }

  @Test
  void auditStorageCreatesIndexesAfterTheTableWithoutLeakingConnections() throws IOException {
    String source = source("audit/AuditLogService.java");

    assertThat(source)
        .contains("DatabaseUtils.ensureIndex")
        .doesNotContain("getConnection().getMetaData()")
        .doesNotContain("catch (Exception ignored)");
    assertThat(source.indexOf("stmt.executeUpdate()"))
        .isLessThan(source.indexOf("DatabaseUtils.ensureIndex"));
  }

  @Test
  void mercenarySchemaClosesConnectionAndStatementOnEveryInitializationPath() throws IOException {
    String source = source("module/army/mercenary/MercenaryModule.java");

    assertThat(source)
        .contains("try (var conn = dataSource.getConnection();")
        .contains("var statement = conn.createStatement()")
        .contains("statement.execute(sql);")
        .doesNotContain("conn.createStatement().execute(sql);");
  }

  @Test
  void auditFlushSchedulerIsClosedBeforeDatabaseStops() throws IOException {
    String plugin = source("StarCorePlugin.java");
    String audit = source("audit/AuditLogService.java");

    assertThat(audit).contains("public void close()").contains("flushScheduler.shutdownNow()");
    assertThat(plugin).contains("find(AuditLogService.class).ifPresent(AuditLogService::close);");
    assertThat(plugin.indexOf("find(AuditLogService.class).ifPresent(AuditLogService::close);"))
        .isLessThan(plugin.indexOf("context.databaseService().stop();"));
  }

  @Test
  void persistenceAndSchedulerDrainBeforeDatabaseConnectionsClose() throws IOException {
    String plugin = source("StarCorePlugin.java");

    assertThat(plugin)
        .contains("context.persistenceService().stop();")
        .contains("context.scheduler().shutdown();")
        .contains("context.databaseService().stop();")
        .contains("context.databaseService().shutdown();");
    assertThat(plugin.indexOf("context.persistenceService().stop();"))
        .isLessThan(plugin.indexOf("context.scheduler().shutdown();"));
    assertThat(plugin.indexOf("context.scheduler().shutdown();"))
        .isLessThan(plugin.indexOf("context.databaseService().shutdown();"));
    assertThat(plugin.indexOf("context.databaseService().shutdown();"))
        .isLessThan(plugin.indexOf("context.databaseService().stop();"));
  }

  @Test
  void sqliteSchemasAvoidInlineMysqlIndexes() throws IOException {
    String court = source("government/CourtExecutionService.java");
    String lease = source("module/lease/LeaseServiceImpl.java");
    String mail = source("module/mail/attachment/MailAttachmentServiceImpl.java");
    String donation = source("module/donation/DonationServiceImpl.java");

    assertThat(court).doesNotContain("INDEX idx_");
    assertThat(lease).doesNotContain("INDEX idx_");
    assertThat(mail).doesNotContain("INDEX idx_");
    assertThat(donation).doesNotContain("INDEX idx_").doesNotContain("ENGINE=InnoDB");
  }

  @Test
  void attachmentMailUsesPortableUpsert() throws IOException {
    String storage = source("module/mail/attachment/AttachmentStorage.java");

    assertThat(storage)
        .contains("ON CONFLICT(id) DO UPDATE SET")
        .contains("ON DUPLICATE KEY UPDATE");
  }

  @Test
  void warStoresUseDifferentTables() throws IOException {
    String richWarStore = source("war/WarDatabaseStore.java");

    assertThat(richWarStore).contains("TABLE_NAME = \"starcore_wars\"");
  }

  @Test
  void bankruptcyTableExistsBeforeRecordsLoad() throws IOException {
    String source = source("module/treasury/BankruptcyServiceImpl.java");

    assertThat(source.indexOf("ensureTable(context);")).isPositive();
    assertThat(source.indexOf("ensureTable(context);"))
        .isLessThan(source.indexOf("loadRecords(context);"));
  }

  @Test
  void achievementCoreDoesNotLinkOptionalVaultTypes() throws IOException {
    String source = source("achievement/AchievementService.java");

    assertThat(source).doesNotContain("net.milkbowl.vault");
  }

  @Test
  void defaultMapStartupDoesNotPrewarmTerrainOnTheServerThread() throws IOException {
    String config = Files.readString(Path.of("src", "main", "resources", "config.yml"));

    assertThat(config).contains("terrain-prewarm-enabled: false");
  }

  @Test
  void optionalJailServiceDoesNotBreakPlayerJoin() throws IOException {
    String source = source("government/listener/CourtExecutionListener.java");

    assertThat(source).contains("jailService != null && jailService.isJailed(playerId)");
  }

  @Test
  void mercenarySchemaAvoidsInlineMysqlIndexes() throws IOException {
    String source = source("module/army/mercenary/MercenaryModule.java");

    assertThat(source).doesNotContain("INDEX idx_");
  }

  @Test
  void achievementStorageUsesPortableUpserts() throws IOException {
    String source = source("achievement/AchievementStorage.java");

    assertThat(source).contains("INSERT OR IGNORE");
    assertThat(source).contains("ON CONFLICT(player_uuid, trigger_type)");
    assertThat(source).contains("CREATE TABLE IF NOT EXISTS starcore_achievements");
    assertThat(source).contains("id %s").contains(".formatted(idColumn));");
  }

  @Test
  void dungeonListenerRegistersOnlyAfterConfigLoads() throws IOException {
    String module = source("module/dungeon/DungeonModule.java");
    String service = source("module/dungeon/DungeonServiceImpl.java");

    assertThat(module).doesNotContain("new DungeonEventListener");
    assertThat(service.indexOf("this.config = new DungeonConfig(plugin);")).isPositive();
    assertThat(service.indexOf("this.config = new DungeonConfig(plugin);"))
        .isLessThan(service.indexOf("new DungeonEventListener(this, config)"));
  }

  @Test
  void shopTransactionQueryUsesAnEmptyVarargsArray() throws IOException {
    String storage = source("module/shop/storage/ShopDatabaseStorage.java");

    assertThat(storage).doesNotContain("(Object[]) null");
  }

  @Test
  void mailCommandReceivesItsGuiListener() throws IOException {
    String module = source("social/mail/MailModule.java");

    assertThat(module).contains("mailCommand.setMailGuiListener(mailGuiListener);");
  }

  @Test
  void cultureTableExistsBeforeDefaultCulturesInitialize() throws IOException {
    String service = source("social/simulation/CultureServiceImpl.java");

    assertThat(service).contains("CREATE TABLE IF NOT EXISTS starcore_culture");
    assertThat(service.indexOf("ensureCultureTable();"))
        .isLessThan(service.indexOf("initializeDefaultCultures();"));
  }

  @Test
  void dungeonGuiListenerRegistersAfterServiceInitialization() throws IOException {
    String module = source("module/dungeon/DungeonModule.java");

    assertThat(module).contains("registerEvents(guiListener, plugin)");
    assertThat(module.indexOf("dungeonService.initialize();"))
        .isLessThan(module.indexOf("registerEvents(guiListener, plugin)"));
  }

  @Test
  void treasuryResolvesTaxationAfterDependentModulesEnable() throws IOException {
    String source = source("module/treasury/TreasuryModule.java");

    assertThat(source)
        .contains("resolveTaxationService()")
        .contains("serviceRegistry().find(TaxationService.class)")
        .contains("refreshFinancialServices()")
        .contains("serviceRegistry().find(LoanService.class)")
        .contains("serviceRegistry().find(BankruptcyService.class)")
        .contains("serviceRegistry().find(BudgetService.class)")
        .contains("resolvePolicyService()");
  }

  @Test
  void weatherTacticsCreatesTablesBeforeLoadingState() throws IOException {
    String source = source("module/army/weather/WeatherTacticsServiceImpl.java");

    assertThat(source).contains("storage.initialize();");
    assertThat(source.indexOf("storage.initialize();"))
        .isLessThan(source.indexOf("storage.load();"));
  }

  @Test
  void foundationRegistersSharedNationRankManager() throws IOException {
    String plugin = source("StarCorePlugin.java");
    String permissions = source("util/PermissionUtil.java");

    assertThat(plugin)
        .contains("new NationRankManager()")
        .contains("rankManager.initDefaultRanks()")
        .contains("register(NationRankManager.class, rankManager)");
    assertThat(permissions).contains("registry.require(NationRankManager.class)");
  }

  @Test
  void foundationExposesPersistenceToFeatureModules() throws IOException {
    String plugin = source("StarCorePlugin.java");
    String reparations = source("module/war/reparations/ReparationsModule.java");

    assertThat(plugin).contains("register(PersistenceService.class, context.persistenceService())");
    assertThat(reparations).contains("this.persistenceService = context.persistenceService();");
  }

  @Test
  void wrapperModulesRegisterEveryConstructedService() throws IOException {
    String navy = source("module/army/navy/NavyModule.java");
    String exercise = source("module/army/exercise/ExerciseModule.java");
    String social = source("social/SocialSimulationModule.java");

    assertThat(navy).contains("register(NavyService.class, navyService)");
    assertThat(exercise).contains("register(ExerciseService.class, exerciseService)");
    assertThat(social)
        .contains("register(NewsPropagationService.class, newsService)")
        .contains("register(SocialEventScheduler.class, eventScheduler)")
        .contains("register(SocialClassService.class, classService)")
        .contains("register(SocialAllianceService.class, allianceService)")
        .contains("register(SocialActivityService.class, activityService)")
        .contains("register(InfluenceLeaderboardService.class, leaderboardService)");
  }

  @Test
  void warBuildsItsBattlefieldServiceAfterArmyStarts() throws IOException {
    String war = source("module/war/WarModule.java");

    assertThat(war)
        .contains("List.of(\"nation\", \"diplomacy\", \"army\", \"treasury\")")
        .contains("new BattlefieldService(context.plugin(), warServiceImpl, warStateStorage)")
        .contains("register(BattlefieldService.class, battlefieldService)");
  }

  @Test
  void startupResourcesContainNoKnownInvalidEntries() throws IOException {
    String events = Files.readString(Path.of("src", "main", "resources", "events.yml"));
    String titles = Files.readString(Path.of("src", "main", "resources", "titles.yml"));
    String plugin = Files.readString(Path.of("src", "main", "resources", "plugin.yml"));
    String trades = source("module/resource/SimplePlayerTradeService.java");

    assertThat(events).doesNotContain("type: \"message\"");
    assertThat(titles).doesNotContain("icon: BANNER");
    assertThat(plugin).contains("  clan:");
    assertThat(trades).doesNotContain("scheduler not set at construction");
  }

  @Test
  void optionalPacketEventsLoadsBeforeStarCoreMenuDetection() throws IOException {
    String plugin = Files.readString(Path.of("src", "main", "resources", "plugin.yml"));

    assertThat(plugin).contains("softdepend:").contains("packetevents").contains("load: POSTWORLD");
  }

  @Test
  void titleStartupCompletesDeferredSocialRewards() throws IOException {
    String plugin = source("StarCorePlugin.java");
    String titles = source("title/TitleModule.java");
    String social = source("social/SocialSimulationModule.java");

    assertThat(titles).contains("register(TitleService.class, titleService)");
    assertThat(plugin).contains("socialSimulationModule.initializeActivityRewards(context)");
    assertThat(social).contains("public void initializeActivityRewards(StarCoreContext context)");
  }

  @Test
  void activityRewardDefaultsCoverEveryRuntimeConfigKey() {
    Path path = Path.of("src", "main", "resources", "activity_rewards.yml");

    assertThat(path).exists().isRegularFile();
    YamlConfiguration config = YamlConfiguration.loadConfiguration(path.toFile());

    for (SocialActivityType activity : SocialActivityType.values()) {
      String activityKey = activity.name().toLowerCase();
      for (ActivityRewardType reward :
          List.of(
              ActivityRewardType.REPUTATION,
              ActivityRewardType.INFLUENCE,
              ActivityRewardType.MONEY)) {
        String rewardKey = "rewards." + activityKey + "." + reward.name().toLowerCase();
        assertThat(config.contains(rewardKey + ".base")).as("missing %s.base", rewardKey).isTrue();
        assertThat(config.getInt(rewardKey + ".base")).as("%s.base", rewardKey).isNotNegative();
        assertThat(config.contains(rewardKey + ".variance"))
            .as("missing %s.variance", rewardKey)
            .isTrue();
        assertThat(config.getDouble(rewardKey + ".variance"))
            .as("%s.variance", rewardKey)
            .isBetween(0.0, 1.0);
      }

      String chanceKey = "rewards.item_chance." + activityKey;
      assertThat(config.contains(chanceKey)).as("missing %s", chanceKey).isTrue();
      assertThat(config.getDouble(chanceKey)).as(chanceKey).isBetween(0.0, 1.0);
    }

    for (HolidayType holiday : HolidayType.values()) {
      String holidayKey = "holidays." + holiday.name().toLowerCase();
      assertThat(config.contains(holidayKey + ".multiplier"))
          .as("missing %s.multiplier", holidayKey)
          .isTrue();
      assertThat(config.getDouble(holidayKey + ".multiplier"))
          .as("%s.multiplier", holidayKey)
          .isGreaterThanOrEqualTo(1.0);
      assertThat(config.contains(holidayKey + ".bonus_rewards"))
          .as("missing %s.bonus_rewards", holidayKey)
          .isTrue();
      assertThat(config.contains(holidayKey + ".title_reward"))
          .as("missing %s.title_reward", holidayKey)
          .isTrue();
    }
  }

  @Test
  void prosperityExportsItsPackagedDefaultsBeforeLoading() throws IOException {
    String prosperity = source("module/prosperity/ProsperityModule.java");

    assertThat(prosperity).contains("saveResource(\"prosperity.yml\", false)");
    assertThat(prosperity.indexOf("saveResource(\"prosperity.yml\", false)"))
        .isLessThan(prosperity.indexOf("YamlConfiguration.loadConfiguration(prosperityFile)"));
  }

  @Test
  void weatherSubscribesToConcretePolicyEvents() throws IOException {
    String weather = source("module/weather/WeatherModule.java");

    assertThat(weather)
        .contains("eventBus.subscribe(PolicyActivatedEvent.class")
        .contains("eventBus.subscribe(PolicyExpiredEvent.class")
        .doesNotContain(
            "Class.forName(\"dev.starcore.starcore.module.policy.event.PolicyChangeEvent\")");
  }

  @Test
  void warAndMilitaryMenusInitializeOnceDependenciesExist() throws IOException {
    String war = source("module/war/WarModule.java");
    String military = source("module/military/MilitaryModule.java");

    assertThat(countOccurrences(war, "registerWarMenu(context);")).isOne();
    assertThat(military).contains("List.of(\"nation\", \"army\", \"war\")");
  }

  @Test
  void sqliteUsesPortableInitializersAndMysqlFlywayUsesPluginClassLoader() throws IOException {
    String database = source("core/database/DatabaseService.java");
    String migrations = source("core/database/DatabaseMigrationService.java");

    assertThat(database)
        .contains("settings.type() == DatabaseType.MYSQL")
        .contains(
            "runMigrations(opened, settings,"
                + " configuration.databaseAllowKnownLegacyChecksumRepair())");
    assertThat(migrations)
        .contains("Flyway.configure(DatabaseMigrationService.class.getClassLoader())");
  }

  private static String source(String relativePath) throws IOException {
    return Files.readString(
        Path.of("src", "main", "java", "dev", "starcore", "starcore").resolve(relativePath));
  }

  private static int countOccurrences(String value, String fragment) {
    return (value.length() - value.replace(fragment, "").length()) / fragment.length();
  }
}
