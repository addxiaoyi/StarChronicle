package dev.starcore.starcore.social.emote.gui;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.gui.StarCoreMenuHolder;
import dev.starcore.starcore.social.emote.EmoteService;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.junit.jupiter.api.Test;

class EmoteMenuListenerInventorySafetyTest {

  @Test
  void matchingTitleWithoutEmoteHolderIsIgnored() {
    EmoteMenu menu = mock(EmoteMenu.class);
    EmoteMenuListener listener = listener(menu);
    Player player = mock(Player.class);
    Inventory top = inventory(null);
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    when(view.getTitle()).thenReturn("=== 动作: SOCIAL ===");
    InventoryClickEvent click = click(top, top, player, 10, ClickType.LEFT, mock(ItemStack.class));
    when(click.getView()).thenReturn(view);

    listener.onInventoryClick(click);

    verify(click, never()).setCancelled(true);
    verify(menu, never()).handleClick(player, 10, click.getCurrentItem());
  }

  @Test
  void bottomInventoryClickIsCancelledButNotRouted() {
    EmoteMenu menu = mock(EmoteMenu.class);
    EmoteMenuListener listener = listener(menu);
    Player player = mock(Player.class);
    Inventory top = inventory(new StarCoreMenuHolder());
    InventoryClickEvent click =
        click(
            top,
            mock(Inventory.class),
            player,
            top.getSize(),
            ClickType.LEFT,
            mock(ItemStack.class));

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(menu, never()).handleClick(player, top.getSize(), click.getCurrentItem());
  }

  @Test
  void numberKeyClickIsCancelledButNotRouted() {
    EmoteMenu menu = mock(EmoteMenu.class);
    EmoteMenuListener listener = listener(menu);
    Player player = mock(Player.class);
    Inventory top = inventory(new StarCoreMenuHolder());
    ItemStack item = mock(ItemStack.class);
    InventoryClickEvent click = click(top, top, player, 10, ClickType.NUMBER_KEY, item);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(menu, never()).handleClick(player, 10, item);
  }

  @Test
  void primaryTopInventoryClickIsRouted() {
    EmoteMenu menu = mock(EmoteMenu.class);
    EmoteMenuListener listener = listener(menu);
    Player player = mock(Player.class);
    Inventory top = inventory(new StarCoreMenuHolder());
    ItemStack item = mock(ItemStack.class);
    InventoryClickEvent click = click(top, top, player, 10, ClickType.LEFT, item);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(menu).handleClick(player, 10, item);
  }

  @Test
  void dragRequiresTheEmoteMenuHolder() {
    EmoteMenuListener listener = listener(mock(EmoteMenu.class));
    Inventory top = inventory(null);
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    InventoryDragEvent drag = mock(InventoryDragEvent.class);
    when(drag.getView()).thenReturn(view);

    listener.onInventoryDrag(drag);

    verify(drag, never()).setCancelled(true);
  }

  private static EmoteMenuListener listener(EmoteMenu menu) {
    return new EmoteMenuListener(menu, mock(EmoteService.class));
  }

  private static Inventory inventory(StarCoreMenuHolder holder) {
    Inventory inventory = mock(Inventory.class);
    when(inventory.getHolder()).thenReturn(holder);
    when(inventory.getSize()).thenReturn(54);
    return inventory;
  }

  private static InventoryClickEvent click(
      Inventory top, Inventory clicked, Player player, int slot, ClickType type, ItemStack item) {
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    when(view.getTitle()).thenReturn("=== 动作: SOCIAL ===");
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    when(event.getView()).thenReturn(view);
    when(event.getWhoClicked()).thenReturn(player);
    when(event.getClickedInventory()).thenReturn(clicked);
    when(event.getRawSlot()).thenReturn(slot);
    when(event.getClick()).thenReturn(type);
    when(event.getCurrentItem()).thenReturn(item);
    return event;
  }
}
