package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;

class ReputationEventTriggerDiagnosticsTest {

  @Test
  void unavailableClanManagerFallsBackAndLogsStableCode() throws Exception {
    List<String> messages = new ArrayList<>();
    Logger logger = Logger.getLogger(ReputationEventTrigger.class.getName());
    logger.setUseParentHandlers(false);
    logger.setLevel(Level.ALL);
    Handler handler =
        new Handler() {
          @Override
          public void publish(LogRecord record) {
            messages.add(record.getMessage());
          }

          @Override
          public void flush() {}

          @Override
          public void close() {}
        };
    logger.addHandler(handler);

    try {
      ReputationEventTrigger trigger =
          new ReputationEventTrigger(
              mock(ReputationService.class),
              mock(RelationshipNetwork.class),
              mock(SocialInfluenceService.class),
              mock(NewsPropagationService.class));
      Method lookup = ReputationEventTrigger.class.getDeclaredMethod("getClanManager");
      lookup.setAccessible(true);

      assertThat(lookup.invoke(trigger)).isNull();
      assertThat(messages)
          .anyMatch(message -> message.contains("code=REPUTATION_CLAN_MANAGER_LOOKUP_FAILURE"));
    } finally {
      logger.removeHandler(handler);
    }
  }
}
