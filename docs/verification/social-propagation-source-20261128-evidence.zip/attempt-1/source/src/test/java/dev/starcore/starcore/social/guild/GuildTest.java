package dev.starcore.starcore.social.guild;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Guild Tests")
class GuildTest {

  private UUID leader;
  private Guild guild;

  @BeforeEach
  void setUp() {
    leader = UUID.randomUUID();
    guild = new Guild(UUID.randomUUID(), "TestGuild", "TG", leader);
  }

  @Test
  @DisplayName("constructor sets basic fields and adds leader as member")
  void shouldInitializeWithLeader() {
    assertThat(guild.getId()).isNotNull();
    assertThat(guild.getName()).isEqualTo("TestGuild");
    assertThat(guild.getTag()).isEqualTo("TG");
    assertThat(guild.getLeader()).isEqualTo(leader);
    assertThat(guild.getMemberCount()).isEqualTo(1);
    assertThat(guild.isMember(leader)).isTrue();
    assertThat(guild.getMemberRole(leader)).isEqualTo(GuildRole.LEADER);
    assertThat(guild.getLevel()).isEqualTo(1);
    assertThat(guild.getExperience()).isEqualTo(0);
    assertThat(guild.getBalance()).isEqualTo(0.0);
    assertThat(guild.getDescription()).isEqualTo("");
  }

  @Test
  @DisplayName("addMember adds a new member with MEMBER role")
  void shouldAddMember() {
    UUID member = UUID.randomUUID();
    guild.addMember(member);

    assertThat(guild.isMember(member)).isTrue();
    assertThat(guild.getMemberRole(member)).isEqualTo(GuildRole.MEMBER);
  }

  @Test
  @DisplayName("removeMember removes member")
  void shouldRemoveMember() {
    UUID member = UUID.randomUUID();
    guild.addMember(member);
    guild.removeMember(member);

    assertThat(guild.isMember(member)).isFalse();
  }

  @Test
  @DisplayName("getMemberRole returns MEMBER for non-member by default")
  void shouldDefaultToMember() {
    UUID outsider = UUID.randomUUID();
    assertThat(guild.getMemberRole(outsider)).isEqualTo(GuildRole.MEMBER);
  }

  @Test
  @DisplayName("setMemberRole only updates existing members")
  void shouldOnlyUpdateExistingMembers() {
    UUID stranger = UUID.randomUUID();
    guild.setMemberRole(stranger, GuildRole.OFFICER);
    assertThat(guild.getMemberRole(stranger)).isEqualTo(GuildRole.MEMBER);

    UUID member = UUID.randomUUID();
    guild.addMember(member);
    guild.setMemberRole(member, GuildRole.OFFICER);
    assertThat(guild.getMemberRole(member)).isEqualTo(GuildRole.OFFICER);
  }

  @Test
  @DisplayName("permission checks: leader can invite/kick/manage")
  void shouldHaveLeaderPermissions() {
    assertThat(guild.canInvite(leader)).isTrue();
    assertThat(guild.canKick(leader)).isTrue();
    assertThat(guild.canManageRoles(leader)).isTrue();
  }

  @Test
  @DisplayName("permission checks: officer can invite/kick/manage")
  void shouldHaveOfficerPermissions() {
    UUID officer = UUID.randomUUID();
    guild.addMember(officer);
    guild.setMemberRole(officer, GuildRole.OFFICER);

    assertThat(guild.canInvite(officer)).isTrue();
    assertThat(guild.canKick(officer)).isTrue();
    assertThat(guild.canManageRoles(officer)).isTrue();
  }

  @Test
  @DisplayName("permission checks: regular member cannot invite/kick/manage")
  void shouldRestrictRegularMember() {
    UUID member = UUID.randomUUID();
    guild.addMember(member);

    assertThat(guild.canInvite(member)).isFalse();
    assertThat(guild.canKick(member)).isFalse();
    assertThat(guild.canManageRoles(member)).isFalse();
  }

  @Test
  @DisplayName("addExperience can level up guild")
  void shouldLevelUpOnEnoughExperience() {
    // L1->L2 requires 1000 XP, L2->L3 requires 2000 XP, L3->L4 requires 3000 XP
    guild.addExperience(1500);
    // 1500 / 1000 = 1 level up (remainder 500)
    assertThat(guild.getLevel()).isEqualTo(2);
    assertThat(guild.getExperience()).isEqualTo(500);

    guild.addExperience(2500);
    // 500 + 2500 = 3000 -> +1 level (to 3, 1000 remaining)
    assertThat(guild.getLevel()).isEqualTo(3);
    assertThat(guild.getExperience()).isEqualTo(1000);
  }

  @Test
  @DisplayName("deposit and withdraw on bank balance")
  void shouldManageBank() {
    guild.deposit(100.0);
    assertThat(guild.getBalance()).isEqualTo(100.0);

    boolean ok = guild.withdraw(40.0);
    assertThat(ok).isTrue();
    assertThat(guild.getBalance()).isEqualTo(60.0);

    boolean notOk = guild.withdraw(200.0);
    assertThat(notOk).isFalse();
    assertThat(guild.getBalance()).isEqualTo(60.0);
  }

  @Test
  @DisplayName("setters update state")
  void shouldUpdateViaSetters() {
    guild.setName("NewName");
    guild.setTag("NT");
    guild.setDescription("desc");
    guild.setLevel(5);
    guild.setExperience(500);
    guild.setBalance(99.9);

    assertThat(guild.getName()).isEqualTo("NewName");
    assertThat(guild.getTag()).isEqualTo("NT");
    assertThat(guild.getDescription()).isEqualTo("desc");
    assertThat(guild.getLevel()).isEqualTo(5);
    assertThat(guild.getExperience()).isEqualTo(500);
    assertThat(guild.getBalance()).isEqualTo(99.9);
  }

  @Test
  @DisplayName("setLeader updates leader and member map")
  void shouldChangeLeader() {
    UUID newLeader = UUID.randomUUID();
    guild.setLeader(newLeader);

    assertThat(guild.getLeader()).isEqualTo(newLeader);
    assertThat(guild.getMemberRole(newLeader)).isEqualTo(GuildRole.LEADER);
  }

  @Test
  @DisplayName("getMembers returns an immutable set")
  void shouldReturnMemberSnapshot() {
    UUID m1 = UUID.randomUUID();
    guild.addMember(m1);
    var members = guild.getMembers();
    assertThat(members).contains(leader, m1);

    // Mutating the returned set should not affect guild
    // E-113: Set.copyOf 返回不可变集合，mutations 抛出 UnsupportedOperationException
    assertThatThrownBy(members::clear).isInstanceOf(UnsupportedOperationException.class);
    assertThat(guild.getMemberCount()).isEqualTo(2);
  }

  @Test
  @DisplayName("D-012 disband request flow")
  void shouldTrackDisbandRequest() {
    assertThat(guild.isDisbandRequested()).isFalse();
    guild.requestDisband();
    assertThat(guild.isDisbandRequested()).isTrue();
  }

  @Test
  @DisplayName("setLevelAndExperience updates both at once")
  void shouldSetLevelAndExperience() {
    guild.setLevelAndExperience(7, 1234);
    assertThat(guild.getLevel()).isEqualTo(7);
    assertThat(guild.getExperience()).isEqualTo(1234);
  }
}
