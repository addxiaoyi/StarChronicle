package dev.starcore.starcore.social.mail;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.junit.jupiter.api.*;

/** 邮件附件领取测试 - 验证附件领取、重复领取防护、背包满处理（D-027/D-028）等。 */
@ExtendWith(MockitoExtension.class)
@DisplayName("邮件附件领取测试")
class MailServiceAttachmentClaimTest {

  private MailService mailService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();

  @BeforeEach
  void setUp() {
    DatabaseService dbService = mock(DatabaseService.class);
    PersistenceService persistenceService = mock(PersistenceService.class);
    org.bukkit.plugin.Plugin plugin = mock(org.bukkit.plugin.Plugin.class);
    when(plugin.getLogger()).thenReturn(new org.bukkit.plugin.PluginLogger(plugin));
    when(plugin.getDataFolder())
        .thenReturn(new java.io.File(System.getProperty("java.io.tmpdir"), "mail-test"));
    when(plugin.getServer()).thenReturn(mock(org.bukkit.Server.class));

    mailService = new MailService(dbService, persistenceService, plugin);
  }

  private void injectMail(UUID recipientId, Mail mail) throws Exception {
    getPlayerMailsMap().putIfAbsent(recipientId, new CopyOnWriteArrayList<>());
    getPlayerMailsMap().get(recipientId).add(0, mail);
    updateUnreadCount(recipientId);
  }

  @SuppressWarnings("unchecked")
  private Map<UUID, List<Mail>> getPlayerMailsMap() throws Exception {
    var field = MailService.class.getDeclaredField("playerMails");
    field.setAccessible(true);
    return (Map<UUID, List<Mail>>) field.get(mailService);
  }

  @SuppressWarnings("unchecked")
  private Map<UUID, Integer> getUnreadCountsMap() throws Exception {
    var field = MailService.class.getDeclaredField("unreadCounts");
    field.setAccessible(true);
    return (Map<UUID, Integer>) field.get(mailService);
  }

  private void updateUnreadCount(UUID playerId) throws Exception {
    var mails = getPlayerMailsMap().get(playerId);
    if (mails != null) {
      long count = mails.stream().filter(m -> !m.isRead() && !m.isExpired()).count();
      getUnreadCountsMap().put(playerId, (int) count);
    }
  }

  private void setAcceptingOperations(boolean value) throws Exception {
    var field = MailService.class.getDeclaredField("acceptingOperations");
    field.setAccessible(true);
    field.setBoolean(mailService, value);
  }

  // ===== 正常领取流程 =====

  @Test
  @DisplayName("claimAttachments 返回附件物品列表")
  void claimAttachments_returnsItems() throws Exception {
    setAcceptingOperations(true);

    ItemStack diamond = new ItemStack(Material.DIAMOND, 5);
    ItemStack apple = new ItemStack(Material.APPLE, 10);
    Mail mail = makeMailWithAttachments(bob, List.of(diamond, apple));
    injectMail(bob, mail);

    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());

    assertEquals(2, claimed.size());
    // 顺序与插入顺序一致
    assertEquals(Material.DIAMOND, claimed.get(0).getType());
    assertEquals(5, claimed.get(0).getAmount());
    assertEquals(Material.APPLE, claimed.get(1).getType());
    assertEquals(10, claimed.get(1).getAmount());
  }

  @Test
  @DisplayName("confirmClaimed 标记邮件为已领取")
  void confirmClaimed_setsClaimed() throws Exception {
    setAcceptingOperations(true);

    ItemStack item = new ItemStack(Material.GOLD_INGOT, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);

    // 先 claim
    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());
    assertFalse(claimed.isEmpty());
    assertFalse(mail.isClaimed(), "claimAttachments 不应直接修改 claimed 标志");

    // 再 confirm
    boolean confirmed = mailService.confirmClaimed(bob, mail.getId());

    assertTrue(confirmed);
    assertTrue(mail.isClaimed());
  }

  @Test
  @DisplayName("无附件邮件 claimAttachments 返回空列表")
  void claimAttachments_noAttachments_returnsEmpty() throws Exception {
    setAcceptingOperations(true);

    Mail mail = makeMailWithAttachments(bob, List.of());
    injectMail(bob, mail);

    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());

    assertTrue(claimed.isEmpty());
  }

  // ===== 重复领取防护 =====

  @Test
  @DisplayName("已领取邮件再次 claim 返回空列表")
  void claimAttachments_alreadyClaimed_returnsEmpty() throws Exception {
    setAcceptingOperations(true);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    mail.setClaimed(true); // 模拟已领取
    injectMail(bob, mail);

    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());

    assertTrue(claimed.isEmpty(), "已领取的邮件不应再发放附件");
  }

  @Test
  @DisplayName("重复调用 confirmClaimed 第二次返回 true 不做修改")
  void confirmClaimed_twice_secondIsIdempotent() throws Exception {
    setAcceptingOperations(true);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);
    mailService.claimAttachments(bob, mail.getId());
    mailService.confirmClaimed(bob, mail.getId()); // 第一次

    boolean second = mailService.confirmClaimed(bob, mail.getId());

    assertTrue(second);
    assertTrue(mail.isClaimed());
  }

  @Test
  @DisplayName("confirmClaimed 对不存在的邮件返回 false")
  void confirmClaimed_nonexistent_returnsFalse() throws Exception {
    setAcceptingOperations(true);

    assertFalse(mailService.confirmClaimed(bob, UUID.randomUUID()));
  }

  @Test
  @DisplayName("confirmClaimed 对其他人的邮件返回 false")
  void confirmClaimed_wrongOwner_returnsFalse() throws Exception {
    setAcceptingOperations(true);

    UUID carol = UUID.randomUUID();
    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);

    assertFalse(mailService.confirmClaimed(carol, mail.getId()));
  }

  // ===== 边界和异常 =====

  @Test
  @DisplayName("claimAttachments 时 acceptingOperations=false 返回空列表")
  void claimAttachments_whenShutdown_returnsEmpty() throws Exception {
    setAcceptingOperations(false);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);

    assertTrue(mailService.claimAttachments(bob, mail.getId()).isEmpty());
  }

  @Test
  @DisplayName("claimAttachments 对不存在的邮件返回空列表")
  void claimAttachments_nonexistent_returnsEmpty() throws Exception {
    setAcceptingOperations(true);

    assertTrue(mailService.claimAttachments(bob, UUID.randomUUID()).isEmpty());
  }

  @Test
  @DisplayName("claimAttachments 对其他人的邮件返回空列表")
  void claimAttachments_wrongOwner_returnsEmpty() throws Exception {
    setAcceptingOperations(true);

    UUID carol = UUID.randomUUID();
    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);

    assertTrue(mailService.claimAttachments(carol, mail.getId()).isEmpty());
  }

  @Test
  @DisplayName("confirmClaimed 时 acceptingOperations=false 返回 false")
  void confirmClaimed_whenShutdown_returnsFalse() throws Exception {
    setAcceptingOperations(false);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    injectMail(bob, mail);
    mailService.claimAttachments(bob, mail.getId());

    assertFalse(mailService.confirmClaimed(bob, mail.getId()));
    assertFalse(mail.isClaimed());
  }

  // ===== 安全边界（B-NEW）=====  TODO: 有很多边界场景

  @Test
  @DisplayName("每封邮件最多返回 36 个附件（MAX_ATTACHMENTS_PER_MAIL）")
  void claimAttachments_respectsMaxLimit() throws Exception {
    setAcceptingOperations(true);

    List<ItemStack> manyItems = new ArrayList<>();
    for (int i = 0; i < 50; i++) {
      manyItems.add(new ItemStack(Material.DIAMOND, 1));
    }
    Mail mail = makeMailWithAttachments(bob, manyItems);
    injectMail(bob, mail);

    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());

    assertEquals(36, claimed.size());
  }

  @Test
  @DisplayName("null ItemStack 和空气物品应被过滤掉")
  void claimAttachments_filtersNullAndAir() throws Exception {
    setAcceptingOperations(true);

    List<ItemStack> items = new ArrayList<>();
    items.add(null);
    items.add(new ItemStack(Material.AIR));
    items.add(new ItemStack(Material.DIAMOND, 1));
    items.add(new ItemStack(Material.GOLD_INGOT, 2));

    Mail mail = makeMailWithAttachments(bob, items);
    injectMail(bob, mail);

    List<ItemStack> claimed = mailService.claimAttachments(bob, mail.getId());

    assertEquals(2, claimed.size());
  }

  // ===== 已读/未读状态 =====

  @Test
  @DisplayName("领取附件不改变邮件的已读状态")
  void claimAttachments_doesNotAffectReadStatus() throws Exception {
    setAcceptingOperations(true);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    mail.setRead(false);
    injectMail(bob, mail);

    mailService.claimAttachments(bob, mail.getId());

    assertFalse(mail.isRead(), "claimAttachments 不应改变已读状态");
  }

  @Test
  @DisplayName("未读邮件领取附件后 confirmClaimed 不影响已读状态")
  void confirmClaimed_doesNotAffectReadStatus() throws Exception {
    setAcceptingOperations(true);

    ItemStack item = new ItemStack(Material.DIAMOND, 1);
    Mail mail = makeMailWithAttachments(bob, List.of(item));
    mail.setRead(false);
    injectMail(bob, mail);

    mailService.claimAttachments(bob, mail.getId());
    mailService.confirmClaimed(bob, mail.getId());

    assertFalse(mail.isRead());
    assertTrue(mail.isClaimed());
  }

  // ===== 助手 =====

  private Mail makeMailWithAttachments(UUID recipientId, List<ItemStack> items) {
    List<MailAttachment> attachments = new ArrayList<>();
    for (ItemStack item : items) {
      if (item != null) {
        attachments.add(new MailAttachment(item));
      }
    }
    return new Mail(
        UUID.randomUUID(),
        alice,
        "Alice",
        recipientId,
        "Player",
        "Attachment",
        "Please collect",
        attachments,
        java.time.Instant.now(),
        30);
  }
}
