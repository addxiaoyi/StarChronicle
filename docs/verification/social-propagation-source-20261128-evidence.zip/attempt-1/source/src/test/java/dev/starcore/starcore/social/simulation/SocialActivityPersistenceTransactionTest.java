package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.MockedStatic;
import org.mockito.invocation.InvocationOnMock;
import org.sqlite.SQLiteDataSource;

class SocialActivityPersistenceTransactionTest {

  @TempDir Path tempDir;

  @Test
  void failedParticipantInsertRollsBackReplacementAndJoinState() throws Exception {
    SQLiteDataSource source = dataSource("join.db");
    SocialActivityService service = initializedService(source);
    UUID host = UUID.randomUUID();
    UUID joiningPlayer = UUID.randomUUID();
    String activityId = service.createParty(host, "Party", "");
    execute(
        source,
        "CREATE TRIGGER reject_join BEFORE INSERT ON social_activity_participants WHEN"
            + " NEW.player_uuid = '"
            + joiningPlayer
            + "' BEGIN SELECT RAISE(ABORT, 'injected participant failure'); END");

    assertThat(service.joinActivity(joiningPlayer, activityId)).isFalse();

    assertThat(service.getActivity(activityId).orElseThrow().participants()).containsExactly(host);
    assertThat(service.getPlayerActivities(joiningPlayer)).isEmpty();
    assertThat(participants(source, activityId)).containsExactly(host.toString());
  }

  @Test
  void failedActivityDeleteKeepsParticipantRowsAndInMemoryActivity() throws Exception {
    SQLiteDataSource source = dataSource("cancel.db");
    SocialActivityService service = initializedService(source);
    UUID host = UUID.randomUUID();
    String activityId = service.createParty(host, "Party", "");
    execute(
        source,
        "CREATE TRIGGER reject_activity_delete BEFORE DELETE ON social_activities BEGIN SELECT"
            + " RAISE(ABORT, 'injected activity delete failure'); END");

    service.cancelActivity(activityId);

    assertThat(service.getActivity(activityId)).isPresent();
    assertThat(service.getPlayerActivities(host)).contains(activityId);
    assertThat(participants(source, activityId)).containsExactly(host.toString());
  }

  @Test
  void failedEndWriteDoesNotRemoveActivityOrIssueReward() throws Exception {
    SQLiteDataSource source = dataSource("end.db");
    SocialActivityService service = initializedService(source);
    UUID host = UUID.randomUUID();
    String activityId = service.createParty(host, "Party", "");
    execute(
        source,
        "CREATE TRIGGER reject_end BEFORE INSERT ON social_activity_participants BEGIN SELECT"
            + " RAISE(ABORT, 'injected end failure'); END");

    service.endActivity(activityId);

    assertThat(service.getActivity(activityId)).isPresent();
    assertThat(service.getPlayerActivities(host)).contains(activityId);
    assertThat(service.getPendingReward(host)).isNull();
    assertThat(activityStatus(source, activityId)).isEqualTo("PREPARING");
    assertThat(participants(source, activityId)).containsExactly(host.toString());
  }

  @Test
  void asyncCreatePublishesOnlyAfterDatabaseCommitAndMainThreadCallback() throws Exception {
    SQLiteDataSource source = dataSource("async-create.db");
    AsyncFixture fixture = asyncService(source);
    UUID host = UUID.randomUUID();

    CompletableFuture<String> creation =
        fixture.service().createPartyAsync(host, "Async party", "");

    assertThat(creation.isDone()).isFalse();
    assertThat(fixture.service().getAllActivities()).isEmpty();
    boolean saved = fixture.databaseOperation().get().get();
    assertThat(saved).isTrue();
    fixture.persistenceResult().complete(saved);

    assertThat(fixture.mainThreadTasks()).hasSize(1);
    assertThat(fixture.service().getAllActivities()).isEmpty();
    fixture.runMainThreadTask();

    String activityId = creation.join();
    assertThat(fixture.service().getActivity(activityId)).isPresent();
    assertThat(fixture.service().getPlayerActivities(host)).contains(activityId);
    assertThat(participants(source, activityId)).containsExactly(host.toString());
  }

  @Test
  void failedAsyncCreateDoesNotPublishActivity() throws Exception {
    SQLiteDataSource source = dataSource("async-create-failure.db");
    AsyncFixture fixture = asyncService(source);
    execute(
        source,
        "CREATE TRIGGER reject_async_create BEFORE INSERT ON social_activities BEGIN SELECT"
            + " RAISE(ABORT, 'injected activity failure'); END");

    CompletableFuture<String> creation =
        fixture.service().createPartyAsync(UUID.randomUUID(), "Rejected party", "");
    assertThat(fixture.databaseOperation().get().get()).isFalse();
    fixture.persistenceResult().complete(false);
    fixture.runMainThreadTask();

    assertThatThrownBy(creation::join).isInstanceOf(CompletionException.class);
    assertThat(fixture.service().getAllActivities()).isEmpty();
  }

  @Test
  void failedAsyncJoinKeepsMembershipAndReleasesPendingWrite() throws Exception {
    SQLiteDataSource source = dataSource("async-join-failure.db");
    AsyncFixture fixture = asyncService(source);
    UUID host = UUID.randomUUID();
    UUID joiningPlayer = UUID.randomUUID();
    String activityId = fixture.service().createParty(host, "Party", "");
    execute(
        source,
        "CREATE TRIGGER reject_async_join BEFORE INSERT ON social_activity_participants WHEN"
            + " NEW.player_uuid = '"
            + joiningPlayer
            + "' BEGIN SELECT RAISE(ABORT, 'injected async join failure'); END");

    CompletableFuture<Boolean> join =
        fixture.service().joinActivityAsync(joiningPlayer, activityId);
    assertThat(fixture.databaseOperation().get().get()).isFalse();
    fixture.persistenceResult().complete(false);
    fixture.runMainThreadTask();

    assertThatThrownBy(join::join).isInstanceOf(CompletionException.class);
    assertThat(fixture.service().getActivity(activityId).orElseThrow().participants())
        .containsExactly(host);
    assertThat(fixture.service().getPlayerActivities(joiningPlayer)).isEmpty();
    assertThat(participants(source, activityId)).containsExactly(host.toString());

    execute(source, "DROP TRIGGER reject_async_join");
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getPlayer(any(UUID.class))).thenReturn(null);
      assertThat(fixture.service().joinActivity(joiningPlayer, activityId)).isTrue();
    }
  }

  @Test
  void pendingAsyncJoinRejectsConflictingWritesAndPublishesItsSnapshot() throws Exception {
    SQLiteDataSource source = dataSource("async-join.db");
    AsyncFixture fixture = asyncService(source);
    UUID host = UUID.randomUUID();
    UUID firstJoiner = UUID.randomUUID();
    UUID secondJoiner = UUID.randomUUID();
    String activityId = fixture.service().createParty(host, "Party", "");

    CompletableFuture<Boolean> firstJoin =
        fixture.service().joinActivityAsync(firstJoiner, activityId);
    CompletableFuture<Boolean> secondJoin =
        fixture.service().joinActivityAsync(secondJoiner, activityId);

    assertThat(firstJoin.isDone()).isFalse();
    assertThat(secondJoin.join()).isFalse();
    assertThat(fixture.service().joinActivity(secondJoiner, activityId)).isFalse();
    assertThat(fixture.service().leaveActivity(host, activityId)).isFalse();
    assertThat(fixture.service().getActivity(activityId).orElseThrow().participants())
        .containsExactly(host);

    boolean saved = fixture.databaseOperation().get().get();
    assertThat(saved).isTrue();
    fixture.persistenceResult().complete(saved);
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getPlayer(any(UUID.class))).thenReturn(null);
      fixture.runMainThreadTask();
    }

    assertThat(firstJoin.join()).isTrue();
    assertThat(fixture.service().getActivity(activityId).orElseThrow().participants())
        .containsExactlyInAnyOrder(host, firstJoiner);
    assertThat(fixture.service().getPlayerActivities(firstJoiner)).contains(activityId);
    assertThat(fixture.service().getPlayerActivities(secondJoiner)).isEmpty();
    assertThat(participants(source, activityId))
        .containsExactlyInAnyOrder(host.toString(), firstJoiner.toString());
  }

  private SocialActivityService initializedService(SQLiteDataSource source) {
    DatabaseService database = database(source);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getLogger(getClass().getName()));
    SocialActivityService service = new SocialActivityService();
    service.initialize(plugin, database);
    return service;
  }

  private AsyncFixture asyncService(SQLiteDataSource source) {
    DatabaseService database = database(source);
    CompletableFuture<Boolean> persistenceResult = new CompletableFuture<>();
    AtomicReference<Supplier<Boolean>> databaseOperation = new AtomicReference<>();
    when(database.executeQueryAsync(any()))
        .thenAnswer(
            invocation -> {
              @SuppressWarnings("unchecked")
              Supplier<Boolean> operation = invocation.getArgument(0);
              databaseOperation.set(operation);
              return persistenceResult;
            });

    JavaPlugin plugin = mock(JavaPlugin.class);
    Server server = mock(Server.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    List<Runnable> mainThreadTasks = new java.util.ArrayList<>();
    when(plugin.getLogger()).thenReturn(Logger.getLogger(getClass().getName()));
    when(plugin.getServer()).thenReturn(server);
    when(server.getScheduler()).thenReturn(scheduler);
    doAnswer(
            invocation -> {
              mainThreadTasks.add(invocation.getArgument(1));
              return mock(BukkitTask.class);
            })
        .when(scheduler)
        .runTask(eq(plugin), any(Runnable.class));

    SocialActivityService service = new SocialActivityService();
    service.initialize(plugin, database);
    return new AsyncFixture(service, persistenceResult, databaseOperation, mainThreadTasks);
  }

  private record AsyncFixture(
      SocialActivityService service,
      CompletableFuture<Boolean> persistenceResult,
      AtomicReference<Supplier<Boolean>> databaseOperation,
      List<Runnable> mainThreadTasks) {
    void runMainThreadTask() {
      mainThreadTasks.remove(0).run();
    }
  }

  private DatabaseService database(SQLiteDataSource source) {
    DatabaseService database = mock(DatabaseService.class);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.isRunning()).thenReturn(true);
    when(database.getConnection()).thenAnswer(ignored -> source.getConnection());
    doAnswer(
            invocation -> {
              try (Connection connection = source.getConnection();
                  Statement statement = connection.createStatement()) {
                return statement.execute(invocation.getArgument(0));
              }
            })
        .when(database)
        .execute(anyString());
    when(database.query(anyString(), any()))
        .thenAnswer(invocation -> query(source, invocation, new Object[0]));
    when(database.query(anyString(), any(), any(Object[].class)))
        .thenAnswer(invocation -> query(source, invocation, (Object[]) invocation.getArgument(2)));
    return database;
  }

  private static Object query(
      SQLiteDataSource source, InvocationOnMock invocation, Object[] parameters) {
    String sql = invocation.getArgument(0);
    @SuppressWarnings("unchecked")
    Function<ResultSet, Object> mapper = invocation.getArgument(1);
    try (Connection connection = source.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql)) {
      for (int index = 0; index < parameters.length; index++) {
        statement.setObject(index + 1, parameters[index]);
      }
      try (ResultSet resultSet = statement.executeQuery()) {
        return mapper.apply(resultSet);
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Test database query failed", failure);
    }
  }

  private SQLiteDataSource dataSource(String fileName) {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + tempDir.resolve(fileName));
    return source;
  }

  private static void execute(SQLiteDataSource source, String sql) throws SQLException {
    try (Connection connection = source.getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  private static List<String> participants(SQLiteDataSource source, String activityId)
      throws SQLException {
    try (Connection connection = source.getConnection();
        PreparedStatement statement =
            connection.prepareStatement(
                "SELECT player_uuid FROM social_activity_participants WHERE activity_id = ?")) {
      statement.setString(1, activityId);
      try (ResultSet resultSet = statement.executeQuery()) {
        java.util.ArrayList<String> players = new java.util.ArrayList<>();
        while (resultSet.next()) players.add(resultSet.getString(1));
        return players;
      }
    }
  }

  private static String activityStatus(SQLiteDataSource source, String activityId)
      throws SQLException {
    try (Connection connection = source.getConnection();
        PreparedStatement statement =
            connection.prepareStatement("SELECT status FROM social_activities WHERE id = ?")) {
      statement.setString(1, activityId);
      try (ResultSet resultSet = statement.executeQuery()) {
        if (!resultSet.next()) throw new AssertionError("activity row missing");
        return resultSet.getString(1);
      }
    }
  }
}
