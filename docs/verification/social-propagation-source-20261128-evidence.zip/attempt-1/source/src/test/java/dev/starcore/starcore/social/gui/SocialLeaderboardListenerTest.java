package dev.starcore.starcore.social.gui;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.junit.jupiter.api.Test;

class SocialLeaderboardListenerTest {

  @Test
  void returnsFromEntryDetailsToTheCurrentLeaderboard() {
    SocialLeaderboardListener listener =
        new SocialLeaderboardListener(null, null, null, null, null);
    SocialLeaderboardGui gui = mock(SocialLeaderboardGui.class);
    Inventory top = mock(Inventory.class);
    InventoryView view = mock(InventoryView.class);
    InventoryClickEvent event = click(view, top, gui, 49);

    when(gui.isShowingEntryDetails()).thenReturn(true);
    listener.onInventoryClick(event);

    verify(event).setCancelled(true);
    verify(gui).closeEntryDetails();
  }

  @Test
  void closesEntryDetailsFromItsCloseButton() {
    SocialLeaderboardListener listener =
        new SocialLeaderboardListener(null, null, null, null, null);
    SocialLeaderboardGui gui = mock(SocialLeaderboardGui.class);
    Inventory top = mock(Inventory.class);
    InventoryView view = mock(InventoryView.class);
    InventoryClickEvent event = click(view, top, gui, 53);
    Player player = (Player) event.getWhoClicked();

    when(gui.isShowingEntryDetails()).thenReturn(true);
    listener.onInventoryClick(event);

    verify(event).setCancelled(true);
    verify(player).closeInventory();
  }

  @Test
  void closesLeaderboardFromItsCloseButton() {
    SocialLeaderboardListener listener =
        new SocialLeaderboardListener(null, null, null, null, null);
    SocialLeaderboardGui gui = mock(SocialLeaderboardGui.class);
    Inventory top = mock(Inventory.class);
    InventoryView view = mock(InventoryView.class);
    InventoryClickEvent event = click(view, top, gui, 53);
    Player player = (Player) event.getWhoClicked();

    when(gui.isShowingEntryDetails()).thenReturn(false);
    listener.onInventoryClick(event);

    verify(event).setCancelled(true);
    verify(player).closeInventory();
  }

  private static InventoryClickEvent click(
      InventoryView view, Inventory top, SocialLeaderboardGui gui, int slot) {
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    Player player = mock(Player.class);
    when(event.getView()).thenReturn(view);
    when(view.getTopInventory()).thenReturn(top);
    when(top.getHolder()).thenReturn(gui);
    when(top.getSize()).thenReturn(54);
    when(event.getClickedInventory()).thenReturn(top);
    when(event.getClick()).thenReturn(ClickType.LEFT);
    when(event.getWhoClicked()).thenReturn(player);
    when(event.getRawSlot()).thenReturn(slot);
    return event;
  }
}
