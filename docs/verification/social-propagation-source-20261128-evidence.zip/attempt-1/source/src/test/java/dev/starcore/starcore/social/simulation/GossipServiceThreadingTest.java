package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class GossipServiceThreadingTest {
  @TempDir Path root;

  @Test
  void reputationRepliesUseTheOriginalCreatorAndEachRecipientOwner() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID creator = UUID.randomUUID(), recipient = UUID.randomUUID();
      Player a = f.player(creator, "Alice"), b = f.player(recipient, "Bob");
      when(f.relations.getSocialCircle(creator, 20)).thenReturn(Set.of(recipient));
      var service = new GossipService(f.plugin, f.relations, f.reputation, () -> 0);
      String id = service.createGossip(creator, "helped", GossipService.GossipTopic.HEROISM);
      service.updateCredibility(id, 0.3);
      f.drain();
      clearInvocations(a, b);
      CompletableFuture<Boolean> future = new CompletableFuture<>();
      when(f.reputation.modifyReputation(eq(creator), anyInt(), any())).thenReturn(future);
      service.applyReputationImpact(id);
      future.complete(true);
      verify(a, never()).sendMessage(anyString());
      verify(b, never()).sendMessage(anyString());
      f.drain();
      verify(a).sendMessage(contains("声誉提升"));
      verify(b).sendMessage(contains("Alice"));
      service.close();
    }
  }

  @Test
  void reconnectionDoesNotRedirectAnInFlightReputationReply() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID creator = UUID.randomUUID();
      Player original = f.player(creator, "Before");
      var service = new GossipService(f.plugin, f.relations, f.reputation);
      String id = service.createGossip(creator, "helped", GossipService.GossipTopic.HEROISM);
      CompletableFuture<Boolean> future = new CompletableFuture<>();
      when(f.reputation.modifyReputation(eq(creator), anyInt(), any())).thenReturn(future);
      service.applyReputationImpact(id);
      Player replacement = f.player(creator, "After");
      future.complete(true);
      f.drain();
      verify(original, never()).sendMessage(anyString());
      verify(replacement, never()).sendMessage(anyString());
      service.close();
    }
  }

  @Test
  void closedServiceDiscardsQueuedAndLateRepliesAndRejectsNewChanges() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID creator = UUID.randomUUID();
      Player original = f.player(creator, "Alice");
      var service = new GossipService(f.plugin, f.relations, f.reputation);
      String id = service.createGossip(creator, "helped", GossipService.GossipTopic.HEROISM);
      CompletableFuture<Boolean> future = new CompletableFuture<>();
      when(f.reputation.modifyReputation(eq(creator), anyInt(), any())).thenReturn(future);
      service.applyReputationImpact(id);
      service.close();
      future.complete(true);
      f.drain();
      verify(original, never()).sendMessage(anyString());
      f.handles.forEach(handle -> verify(handle).cancel());
      assertThrows(
          IllegalStateException.class,
          () -> service.createGossip(creator, "late", GossipService.GossipTopic.HEROISM));
      service.saveData();
    }
  }

  @Test
  void offlineDeliveryRemainsUnreadAndNeutralTopicsDoNotLowerReputation() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID creator = UUID.randomUUID(), a = UUID.randomUUID(), b = UUID.randomUUID();
      when(f.relations.getSocialCircle(creator, 20)).thenReturn(Set.of(a, b));
      var service = new GossipService(f.plugin, f.relations, f.reputation, () -> 0);
      String id = service.createGossip(creator, "culture", GossipService.GossipTopic.CULTURE);
      assertEquals(1, service.getUnreadGossipCount(a));
      assertEquals(3, service.getGossipById(id).seenBy().size());
      assertEquals(3, service.getGossipById(id).spreadCount());
      verify(f.reputation, never()).modifyReputation(any(), anyInt(), any());
      service.close();
    }
  }
}
