package dev.starcore.starcore.social.mail;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginLogger;
import org.junit.jupiter.api.*;

/**
 * 邮件发送与接收测试 - 验证发送、读取、删除、未读计数等基础功能。
 *
 * <p>测试不依赖任何外部服务（数据库/YAML），使用反射注入模拟数据以绕过 initialize()。
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("邮件发送与接收测试")
class MailServiceSendReceiveTest {

  private MailService mailService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();

  private Player mockAlice;
  private Player mockBob;
  private Player mockStranger;

  @BeforeEach
  void setUp() {
    DatabaseService dbService = mock(DatabaseService.class);
    PersistenceService persistenceService = mock(PersistenceService.class);
    Plugin plugin = mock(Plugin.class);
    when(plugin.getLogger()).thenReturn(new PluginLogger(plugin));
    when(plugin.getDataFolder())
        .thenReturn(new java.io.File(System.getProperty("java.io.tmpdir"), "mail-test"));
    Server server = mock(Server.class);
    when(plugin.getServer()).thenReturn(server);

    mailService = new MailService(dbService, persistenceService, plugin);
    // 不调用 initialize()，直接注入测试数据

    mockAlice = mockPlayer(alice, "Alice");
    mockBob = mockPlayer(bob, "Bob");
    mockStranger = mockPlayer(UUID.randomUUID(), "Stranger");
  }

  private Player mockPlayer(UUID uuid, String name) {
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(uuid);
    when(player.getName()).thenReturn(name);
    return player;
  }

  private Player mockOfflinePlayer(String name, UUID uuid) {
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(uuid);
    when(player.getName()).thenReturn(name);
    when(player.hasPlayedBefore()).thenReturn(true);
    return player;
  }

  // ===== 反射注入工具 =====

  private void injectMail(UUID recipientId, Mail mail) throws Exception {
    var playerMails = getPlayerMailsMap();
    playerMails.putIfAbsent(recipientId, new CopyOnWriteArrayList<>());
    playerMails.get(recipientId).add(0, mail);
    updateUnreadCount(recipientId);
  }

  @SuppressWarnings("unchecked")
  private Map<UUID, List<Mail>> getPlayerMailsMap() throws Exception {
    var field = MailService.class.getDeclaredField("playerMails");
    field.setAccessible(true);
    return (Map<UUID, List<Mail>>) field.get(mailService);
  }

  @SuppressWarnings("unchecked")
  private Map<UUID, Integer> getUnreadCountsMap() throws Exception {
    var field = MailService.class.getDeclaredField("unreadCounts");
    field.setAccessible(true);
    return (Map<UUID, Integer>) field.get(mailService);
  }

  private void updateUnreadCount(UUID playerId) throws Exception {
    var mails = getPlayerMailsMap().get(playerId);
    if (mails != null) {
      long count = mails.stream().filter(m -> !m.isRead() && !m.isExpired()).count();
      getUnreadCountsMap().put(playerId, (int) count);
    }
  }

  private void setAcceptingOperations(boolean value) throws Exception {
    var field = MailService.class.getDeclaredField("acceptingOperations");
    field.setAccessible(true);
    field.setBoolean(mailService, value);
  }

  // ===== 基础功能测试 =====

  @Test
  @DisplayName("发送邮件后收件人邮箱应有 1 封邮件且未读")
  void sendMail_basic_success() throws Exception {
    setAcceptingOperations(true);

    when(Bukkit.getPlayer("Bob")).thenReturn(mockBob);
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    List<ItemStack> attachments = List.of();
    boolean result = mailService.sendMail(mockAlice, "Bob", "Hello", "Hi Bob!", attachments);

    assertTrue(result, "发送应成功");
    List<Mail> bobMails = getPlayerMailsMap().get(bob);
    assertNotNull(bobMails);
    assertEquals(1, bobMails.size());
    assertFalse(bobMails.get(0).isRead());
  }

  @Test
  @DisplayName("给自己发邮件应失败")
  void sendMail_toSelf_returnsFalse() throws Exception {
    setAcceptingOperations(true);
    when(Bukkit.getPlayer("Alice")).thenReturn(mockAlice);
    when(Bukkit.getOfflinePlayer("Alice")).thenReturn(mockOfflinePlayer("Alice", alice));

    boolean result = mailService.sendMail(mockAlice, "Alice", "Test", "content", List.of());
    assertFalse(result, "给自己发邮件应失败");
  }

  @Test
  @DisplayName("发给不存在的玩家应失败")
  void sendMail_toNonexistent_returnsFalse() throws Exception {
    setAcceptingOperations(true);
    when(Bukkit.getPlayer("Nobody")).thenReturn(null);
    when(Bukkit.getOfflinePlayer("Nobody")).thenReturn(mock(Player.class));

    boolean result = mailService.sendMail(mockAlice, "Nobody", "Test", "content", List.of());
    assertFalse(result, "发给不存在的玩家应失败");
  }

  @Test
  @DisplayName("acceptingOperations=false 时发送应失败")
  void sendMail_whenShutdown_returnsFalse() throws Exception {
    setAcceptingOperations(false);

    boolean result = mailService.sendMail(mockAlice, "Bob", "Test", "content", List.of());
    assertFalse(result, "服务停止时应拒绝发送");
  }

  @Test
  @DisplayName("readMail 应将邮件标记为已读")
  void readMail_marksAsRead() throws Exception {
    setAcceptingOperations(true);

    // 注入一封未读邮件
    Mail mail =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            bob,
            "Bob",
            "Test",
            "Content",
            List.of(),
            java.time.Instant.now(),
            30);
    injectMail(bob, mail);

    Mail read = mailService.readMail(bob, mail.getId());

    assertNotNull(read);
    assertTrue(read.isRead());
    assertEquals(0, mailService.getUnreadCount(bob));
  }

  @Test
  @DisplayName("readMail 对不存在的邮件返回 null")
  void readMail_nonexistent_returnsNull() throws Exception {
    setAcceptingOperations(true);

    assertNull(mailService.readMail(bob, UUID.randomUUID()));
  }

  @Test
  @DisplayName("readMail 对不属于自己的邮件返回 null")
  void readMail_wrongOwner_returnsNull() throws Exception {
    setAcceptingOperations(true);

    UUID carol = UUID.randomUUID();
    Mail mail =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            bob,
            "Bob",
            "Test",
            "Content",
            List.of(),
            java.time.Instant.now(),
            30);
    injectMail(bob, mail);

    // carol 尝试读 bob 的邮件
    assertNull(mailService.readMail(carol, mail.getId()));
  }

  @Test
  @DisplayName("deleteMail 应将邮件从邮箱中移除")
  void deleteMail_removesMail() throws Exception {
    setAcceptingOperations(true);

    Mail mail =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            bob,
            "Bob",
            "Test",
            "Content",
            List.of(),
            java.time.Instant.now(),
            30);
    injectMail(bob, mail);

    boolean result = mailService.deleteMail(bob, mail.getId());

    assertTrue(result);
    assertTrue(getPlayerMailsMap().get(bob).isEmpty());
  }

  @Test
  @DisplayName("deleteMail 对不存在的邮件返回 false")
  void deleteMail_nonexistent_returnsFalse() throws Exception {
    setAcceptingOperations(true);

    assertFalse(mailService.deleteMail(bob, UUID.randomUUID()));
  }

  @Test
  @DisplayName("deleteMail 对不属于自己的邮件返回 false")
  void deleteMail_wrongOwner_returnsFalse() throws Exception {
    setAcceptingOperations(true);

    UUID carol = UUID.randomUUID();
    Mail mail =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            bob,
            "Bob",
            "Test",
            "Content",
            List.of(),
            java.time.Instant.now(),
            30);
    injectMail(bob, mail);

    assertFalse(mailService.deleteMail(carol, mail.getId()));
    assertEquals(1, getPlayerMailsMap().get(bob).size());
  }

  // ===== 未读计数测试 =====

  @Test
  @DisplayName("未读计数应正确反映未读邮件数量")
  void unreadCount_correct() throws Exception {
    setAcceptingOperations(true);

    // 3 封邮件，1 封已读
    Mail m1 = makeMail(bob, false);
    Mail m2 = makeMail(bob, true);
    Mail m3 = makeMail(bob, false);
    injectMail(bob, m1);
    injectMail(bob, m2);
    injectMail(bob, m3);

    assertEquals(2, mailService.getUnreadCount(bob));
  }

  @Test
  @DisplayName("读取邮件后未读计数应减少")
  void unreadCount_decrementsOnRead() throws Exception {
    setAcceptingOperations(true);

    Mail mail = makeMail(bob, false);
    injectMail(bob, mail);
    assertEquals(1, mailService.getUnreadCount(bob));

    mailService.readMail(bob, mail.getId());

    assertEquals(0, mailService.getUnreadCount(bob));
  }

  @Test
  @DisplayName("删除邮件后未读计数应减少")
  void unreadCount_decrementsOnDelete() throws Exception {
    setAcceptingOperations(true);

    Mail mail = makeMail(bob, false);
    injectMail(bob, mail);
    assertEquals(1, mailService.getUnreadCount(bob));

    mailService.deleteMail(bob, mail.getId());

    assertEquals(0, mailService.getUnreadCount(bob));
  }

  @Test
  @DisplayName("无邮件玩家返回未读计数为 0")
  void unreadCount_noMails_returnsZero() throws Exception {
    setAcceptingOperations(true);
    assertEquals(0, mailService.getUnreadCount(bob));
  }

  // ===== getPlayerMails 测试 =====

  @Test
  @DisplayName("getPlayerMails 返回的列表是内部列表的视图")
  void getPlayerMails_returnsView() throws Exception {
    setAcceptingOperations(true);
    Mail mail = makeMail(bob, false);
    injectMail(bob, mail);

    List<Mail> mails = mailService.getPlayerMails(bob);
    assertEquals(1, mails.size());

    // 返回列表不应支持写入
    assertThrows(UnsupportedOperationException.class, () -> mails.add(makeMail(bob, false)));
  }

  // ===== 空值和边界 =====

  @Test
  @DisplayName("null playerId 返回空列表")
  void getPlayerMails_null_returnsEmptyList() throws Exception {
    setAcceptingOperations(true);
    assertEquals(List.of(), mailService.getPlayerMails(null));
  }

  @Test
  @DisplayName("readMail 时 acceptingOperations=false 返回 null")
  void readMail_whenShutdown_returnsNull() throws Exception {
    setAcceptingOperations(false);
    assertNull(mailService.readMail(bob, UUID.randomUUID()));
  }

  @Test
  @DisplayName("deleteMail 时 acceptingOperations=false 返回 false")
  void deleteMail_whenShutdown_returnsFalse() throws Exception {
    setAcceptingOperations(false);
    assertFalse(mailService.deleteMail(bob, UUID.randomUUID()));
  }

  // ===== 邮件内容长度限制 =====

  @Test
  @DisplayName("超长主题应被截断到 200 字符")
  void sendMail_subjectTruncated() throws Exception {
    setAcceptingOperations(true);
    when(Bukkit.getPlayer("Bob")).thenReturn(mockBob);
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    String longSubject = "A".repeat(500);
    mailService.sendMail(mockAlice, "Bob", longSubject, "content", List.of());

    List<Mail> mails = getPlayerMailsMap().get(bob);
    assertNotNull(mails);
    assertEquals(200, mails.get(0).getSubject().length());
  }

  @Test
  @DisplayName("超长内容应被截断到 4000 字符")
  void sendMail_contentTruncated() throws Exception {
    setAcceptingOperations(true);
    when(Bukkit.getPlayer("Bob")).thenReturn(mockBob);
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    String longContent = "B".repeat(5000);
    mailService.sendMail(mockAlice, "Bob", "subject", longContent, List.of());

    List<Mail> mails = getPlayerMailsMap().get(bob);
    assertNotNull(mails);
    assertEquals(4000, mails.get(0).getContent().length());
  }

  // ===== 过期邮件测试 =====

  @Test
  @DisplayName("过期的邮件不应计入未读")
  void expiredMail_notCountedAsUnread() throws Exception {
    setAcceptingOperations(true);

    // 创建一封 31 天前且 30 天过期的邮件（已过期）
    Mail expired =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            bob,
            "Bob",
            "Expired",
            "Content",
            List.of(),
            java.time.Instant.now().minusSeconds(31 * 86400),
            30);

    injectMail(bob, expired);

    assertTrue(expired.isExpired());
    assertEquals(0, mailService.getUnreadCount(bob));
  }

  // ===== 助手 =====

  private Mail makeMail(UUID recipientId, boolean read) {
    Mail mail =
        new Mail(
            UUID.randomUUID(),
            alice,
            "Alice",
            recipientId,
            "Player",
            "Subject",
            "Content",
            List.of(),
            java.time.Instant.now(),
            30);
    if (read) mail.setRead(true);
    return mail;
  }
}
