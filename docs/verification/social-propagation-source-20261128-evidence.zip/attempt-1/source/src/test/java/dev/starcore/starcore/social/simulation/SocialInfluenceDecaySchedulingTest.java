package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import org.bukkit.Server;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class SocialInfluenceDecaySchedulingTest {
  private static final long DECAY_INTERVAL_TICKS = 1200L * 60;

  @Test
  void paperTimerSubmitsDecayWorkToTheProvidedIoQueue() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    Server server = mock(Server.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    BukkitTask task = mock(BukkitTask.class);
    when(plugin.getServer()).thenReturn(server);
    when(server.getScheduler()).thenReturn(scheduler);
    when(scheduler.runTaskTimer(
            eq(plugin), any(Runnable.class), eq(DECAY_INTERVAL_TICKS), eq(DECAY_INTERVAL_TICKS)))
        .thenReturn(task);

    SocialInfluenceServiceImpl service = new SocialInfluenceServiceImpl(plugin, null, null, null);
    AtomicReference<Runnable> scheduledIoWork = new AtomicReference<>();
    CompletableFuture<Void> ioCompletion = new CompletableFuture<>();
    ArgumentCaptor<Runnable> timerCallback = ArgumentCaptor.forClass(Runnable.class);

    service.startDecayTask(
        ioWork -> {
          scheduledIoWork.set(ioWork);
          return ioCompletion;
        });

    verify(scheduler)
        .runTaskTimer(
            eq(plugin),
            timerCallback.capture(),
            eq(DECAY_INTERVAL_TICKS),
            eq(DECAY_INTERVAL_TICKS));
    timerCallback.getValue().run();

    assertThat(scheduledIoWork.get()).isNotNull();
    assertThat(ioCompletion).isNotCompleted();
    scheduledIoWork.get().run();
    ioCompletion.complete(null);

    service.stopDecayTask();
    verify(task).cancel();
  }

  @Test
  void compatibilityEntryUsesAsynchronousPaperTimer() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    Server server = mock(Server.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    BukkitTask task = mock(BukkitTask.class);
    when(plugin.getServer()).thenReturn(server);
    when(server.getScheduler()).thenReturn(scheduler);
    when(scheduler.runTaskTimerAsynchronously(
            eq(plugin), any(Runnable.class), eq(DECAY_INTERVAL_TICKS), eq(DECAY_INTERVAL_TICKS)))
        .thenReturn(task);

    SocialInfluenceServiceImpl service = new SocialInfluenceServiceImpl(plugin, null, null, null);
    service.startDecayTask();

    verify(scheduler)
        .runTaskTimerAsynchronously(
            eq(plugin), any(Runnable.class), eq(DECAY_INTERVAL_TICKS), eq(DECAY_INTERVAL_TICKS));
    service.stopDecayTask();
    verify(task).cancel();
  }
}
