package dev.starcore.starcore.social.gui;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.social.simulation.SocialActivityService;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.junit.jupiter.api.Test;

class ActivityRecommendationListenerInventorySafetyTest {

  @Test
  void numberKeyCannotDispatchActivityAction() {
    ActivityRecommendationGui gui = mock(ActivityRecommendationGui.class);
    ActivityRecommendationListener listener = listener();
    Player player = mock(Player.class);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, top, player, 53, ClickType.NUMBER_KEY);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verifyNoInteractions(gui);
  }

  @Test
  void bottomInventoryClickCannotDispatchActivityAction() {
    ActivityRecommendationGui gui = mock(ActivityRecommendationGui.class);
    ActivityRecommendationListener listener = listener();
    Player player = mock(Player.class);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, mock(Inventory.class), player, 54, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verifyNoInteractions(gui);
  }

  @Test
  void primaryTopCloseClickStillRoutesFromTypeDetails() {
    ActivityRecommendationGui gui = mock(ActivityRecommendationGui.class);
    when(gui.isShowingTypeDetails()).thenReturn(true);
    ActivityRecommendationListener listener = listener();
    Player player = mock(Player.class);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, top, player, 53, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(gui).closeTypeDetails();
  }

  private static ActivityRecommendationListener listener() {
    return new ActivityRecommendationListener(mock(SocialActivityService.class));
  }

  private static Inventory inventory(ActivityRecommendationGui gui) {
    Inventory top = mock(Inventory.class);
    when(top.getHolder()).thenReturn(gui);
    when(top.getSize()).thenReturn(54);
    return top;
  }

  private static InventoryClickEvent click(
      Inventory top, Inventory clicked, Player player, int rawSlot, ClickType clickType) {
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    when(event.getView()).thenReturn(view);
    when(event.getWhoClicked()).thenReturn(player);
    when(event.getClickedInventory()).thenReturn(clicked);
    when(event.getRawSlot()).thenReturn(rawSlot);
    when(event.getClick()).thenReturn(clickType);
    return event;
  }
}
