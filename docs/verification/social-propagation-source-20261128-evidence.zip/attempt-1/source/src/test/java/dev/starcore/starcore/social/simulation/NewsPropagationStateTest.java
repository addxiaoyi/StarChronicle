package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class NewsPropagationStateTest {
  @TempDir Path root;

  @Test
  void allRecipientsAreRetainedAndUnrelatedPlayersCannotReadNews() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID source = UUID.randomUUID(),
          a = UUID.randomUUID(),
          b = UUID.randomUUID(),
          outsider = UUID.randomUUID();
      when(f.relations.getSocialCircle(source, 20)).thenReturn(Set.of(a, b));
      var service = new NewsPropagationService(f.plugin, f.relations);
      String id =
          service.publishNews("h", "c", source, NewsPropagationService.NewsCategory.CULTURE);
      assertEquals(id, service.getUnreadNews(a).getFirst().id());
      assertEquals(id, service.getUnreadNews(b).getFirst().id());
      assertTrue(service.getUnreadNews(outsider).isEmpty());
      assertTrue(service.getUnreadNews(source).isEmpty());
      assertEquals(Set.of(source, a, b), service.getUnreadNews(a).getFirst().reach());
      assertThrows(
          UnsupportedOperationException.class,
          () -> service.getUnreadNews(a).getFirst().reach().clear());
      service.markAsRead(a, id);
      assertTrue(service.getUnreadNews(a).isEmpty());
      assertEquals(1, service.getUnreadNews(b).size());
      service.stop();
    }
  }

  @Test
  void concurrentLikesRemainCompleteAndHottestSortUsesMostLikesFirst() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      var service = new NewsPropagationService(f.plugin, f.relations);
      UUID source = UUID.randomUUID();
      String id =
          service.publishNews("h", "c", source, NewsPropagationService.NewsCategory.CULTURE);
      var popular = service.addComment(id, source, "popular");
      var quiet = service.addComment(id, source, "quiet");
      try (var pool = Executors.newFixedThreadPool(2)) {
        var a =
            pool.submit(
                () -> {
                  for (int i = 0; i < 70; i++)
                    service.likeComment(id, UUID.randomUUID(), popular.id());
                });
        var b =
            pool.submit(
                () -> {
                  for (int i = 0; i < 70; i++)
                    service.likeComment(id, UUID.randomUUID(), popular.id());
                });
        a.get(10, TimeUnit.SECONDS);
        b.get(10, TimeUnit.SECONDS);
      }
      var sorted = service.getComments(id, NewsPropagationService.CommentSortOrder.HOTTEST);
      assertEquals(popular.id(), sorted.getFirst().id());
      assertEquals(140, sorted.getFirst().getLikeCount());
      assertEquals(quiet.id(), sorted.getLast().id());
      assertTrue(popular.likes().isEmpty());
      assertThrows(UnsupportedOperationException.class, () -> sorted.getFirst().likes().clear());
      service.stop();
    }
  }
}
