package dev.starcore.starcore.social.party;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.social.SqlSocialStateStorage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class PartyServiceRecoveryTest {
  @TempDir Path directory;
  final MutableClock clock = new MutableClock();

  private PartyService service(SqlSocialStateStorage storage) {
    Plugin plugin = mock(Plugin.class);
    when(plugin.getDataFolder()).thenReturn(directory.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    PartyService service = new PartyService(clock);
    service.initialize(plugin);
    service.setSqlStorage(storage);
    return service;
  }

  private SqlSocialStateStorage storage() {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + directory.resolve("social.db"));
    DatabaseService database = mock(DatabaseService.class);
    when(database.dataSource()).thenReturn(java.util.Optional.of(source));
    when(database.isRunning()).thenReturn(true);
    var storage = new SqlSocialStateStorage(database, Logger.getAnonymousLogger());
    storage.ensureTables();
    return storage;
  }

  @Test
  void acceptingAnotherInviteCannotLeaveMembershipInTwoParties() {
    var service = service(null);
    UUID firstLeader = UUID.randomUUID(),
        secondLeader = UUID.randomUUID(),
        target = UUID.randomUUID();
    Party first = service.createParty(firstLeader), second = service.createParty(secondLeader);
    service.inviteMember(first.getId(), firstLeader, target);
    clock.advance(30_000);
    service.inviteMember(second.getId(), secondLeader, target);
    assertThat(service.acceptInvite(target, firstLeader)).isTrue();
    assertThatThrownBy(() -> service.acceptInvite(target, secondLeader))
        .isInstanceOf(IllegalStateException.class);
    assertThat(first.isMember(target)).isTrue();
    assertThat(second.isMember(target)).isFalse();
    assertThat(service.getPlayerParty(target)).isSameAs(first);
  }

  @Test
  void anExistingLeaderCannotAcceptAnOlderInvitation() {
    var service = service(null);
    UUID inviter = UUID.randomUUID(), target = UUID.randomUUID();
    Party first = service.createParty(inviter);
    service.inviteMember(first.getId(), inviter, target);
    Party own = service.createParty(target);
    assertThatThrownBy(() -> service.acceptInvite(target, inviter))
        .isInstanceOf(IllegalStateException.class);
    assertThat(service.getPlayerParty(target)).isSameAs(own);
    assertThat(first.isMember(target)).isFalse();
  }

  @Test
  void concurrentAcceptsClaimOnlyOneParty() throws Exception {
    var service = service(null);
    UUID firstLeader = UUID.randomUUID(),
        secondLeader = UUID.randomUUID(),
        target = UUID.randomUUID();
    Party first = service.createParty(firstLeader), second = service.createParty(secondLeader);
    service.inviteMember(first.getId(), firstLeader, target);
    clock.advance(30_000);
    service.inviteMember(second.getId(), secondLeader, target);
    var start = new CountDownLatch(1);
    try (var workers = Executors.newFixedThreadPool(2)) {
      var firstAccept =
          workers.submit(atOnce(start, () -> service.acceptInvite(target, firstLeader)));
      var secondAccept =
          workers.submit(atOnce(start, () -> service.acceptInvite(target, secondLeader)));
      start.countDown();
      assertThat(Set.of(firstAccept.get(), secondAccept.get()))
          .containsExactlyInAnyOrder(true, false);
    }
    assertThat((first.isMember(target) ? 1 : 0) + (second.isMember(target) ? 1 : 0)).isEqualTo(1);
  }

  @Test
  void concurrentCreatesCannotOverwriteTheLeadersMembership() throws Exception {
    var service = service(null);
    UUID leader = UUID.randomUUID();
    var start = new CountDownLatch(1);
    try (var workers = Executors.newFixedThreadPool(2)) {
      var first = workers.submit(atOnce(start, () -> service.createParty(leader) != null));
      var second = workers.submit(atOnce(start, () -> service.createParty(leader) != null));
      start.countDown();
      assertThat(Set.of(first.get(), second.get())).containsExactlyInAnyOrder(true, false);
    }
    assertThat(service.getAllParties()).hasSize(1);
  }

  private Callable<Boolean> atOnce(CountDownLatch start, Callable<Boolean> action) {
    return () -> {
      start.await();
      try {
        return action.call();
      } catch (IllegalStateException rejected) {
        return false;
      }
    };
  }

  @Test
  void leavingLeaderIsRemovedFromTheOldPartyAfterSuccession() {
    var service = service(null);
    UUID leader = UUID.randomUUID(), member = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, member);
    service.acceptInvite(member, leader);
    try (var bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getOfflinePlayer(member)).thenReturn(mock(OfflinePlayer.class));
      assertThat(service.leaveParty(leader)).isTrue();
    }
    assertThat(party.getMembers()).containsExactly(member);
    assertThat(party.getLeader()).isEqualTo(member);
    assertThat(service.getPlayerParty(leader)).isNull();
    assertThat(service.createParty(leader)).isNotSameAs(party);
  }

  @Test
  void kickingAnOutsiderDoesNotEraseTheirActualParty() {
    var service = service(null);
    UUID leader = UUID.randomUUID(), outsider = UUID.randomUUID();
    Party party = service.createParty(leader), other = service.createParty(outsider);
    assertThat(service.kickMember(party.getId(), leader, outsider)).isFalse();
    assertThat(service.getPlayerParty(outsider)).isSameAs(other);
  }

  @Test
  void rejectedSqlInvitationDoesNotReturnAfterReopen() {
    var storage = storage();
    var first = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = first.createParty(leader);
    first.inviteMember(party.getId(), leader, target);
    assertThat(first.rejectInvite(target, leader)).isTrue();
    var reopened = service(storage);
    reopened.loadData();
    assertThat(reopened.getPartyInvites(target)).isEmpty();
    assertThatThrownBy(() -> reopened.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void sqlReopenRetainsTheOriginalExpirationAndExactDeadline() {
    var storage = storage();
    var first = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = first.createParty(leader);
    first.inviteMember(party.getId(), leader, target);
    clock.advance(599_999);
    var reopened = service(storage);
    reopened.loadData();
    assertThat(reopened.getPartyInvites(target)).containsExactly(leader);
    clock.advance(1);
    assertThatThrownBy(() -> reopened.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
    var again = service(storage);
    again.loadData();
    assertThat(again.getPartyInvites(target)).isEmpty();
  }

  @Test
  void yamlReopenRetainsTheOriginalInvitationTime() {
    var first = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = first.createParty(leader);
    first.inviteMember(party.getId(), leader, target);
    first.saveData();
    clock.advance(599_999);
    var reopened = service(null);
    reopened.loadData();
    assertThat(reopened.getPartyInvites(target)).containsExactly(leader);
    assertThat(reopened.getPlayerParty(leader).getId()).isEqualTo(party.getId());
    assertThat(reopened.getPlayerParty(leader).getCreatedTime()).isEqualTo(party.getCreatedTime());
    clock.advance(1);
    assertThatThrownBy(() -> reopened.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void rejectingYamlInvitationIsDurableWithoutASeparateSave() {
    var first = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = first.createParty(leader);
    first.inviteMember(party.getId(), leader, target);
    first.saveData();
    assertThat(first.rejectInvite(target, leader)).isTrue();
    var reopened = service(null);
    reopened.loadData();
    assertThat(reopened.getPartyInvites(target)).isEmpty();
  }

  @Test
  void undatedLegacyYamlInvitesAreNotGrantedANewLifetime() throws Exception {
    var service = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Path file = directory.resolve("social/party-invites.yml");
    String old = target + ":\n- " + leader + "\n";
    Files.writeString(file, old);
    service.loadData();
    assertThat(service.getPartyInvites(target)).isEmpty();
    assertThat(Files.readString(file)).isEqualTo(old);
  }

  @Test
  void persistedFutureInvitationDoesNotBypassExpiration() throws Exception {
    var storage = storage();
    var service = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    service.createParty(leader);
    storage.savePartyInvite(leader, target, clock.millis() + 1);
    service.loadData();
    assertThat(service.getPartyInvites(target)).isEmpty();
  }

  @Test
  void failedSqlRejectionDoesNotReportSuccessOrForgetTheInvite() {
    var storage = mock(SqlSocialStateStorage.class);
    var service = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    doThrow(new IllegalStateException("unavailable"))
        .when(storage)
        .deletePartyInvite(leader, target);
    assertThatThrownBy(() -> service.rejectInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
    assertThat(service.getPartyInvites(target)).containsExactly(leader);
  }

  @Test
  void failedSqlInvitationCanBeRetriedWithoutInventingACooldown() {
    var storage = mock(SqlSocialStateStorage.class);
    var service = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    doThrow(new IllegalStateException("unavailable"))
        .when(storage)
        .savePartyInvite(leader, target, clock.millis());
    assertThatThrownBy(() -> service.inviteMember(party.getId(), leader, target))
        .isInstanceOf(IllegalStateException.class);
    assertThat(service.getPartyInvites(target)).isEmpty();
    doNothing().when(storage).savePartyInvite(leader, target, clock.millis());
    assertThat(service.inviteMember(party.getId(), leader, target)).isTrue();
  }

  @Test
  void disbandedPartysSqlInvitesCannotRebindToANewPartyAfterReopen() {
    var storage = storage();
    var service = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    service.disbandParty(party.getId(), leader);
    service.createParty(leader);
    var reopened = service(storage);
    reopened.loadData();
    assertThat(reopened.getPartyInvites(target)).isEmpty();
    assertThatThrownBy(() -> reopened.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void leadershipTransferRevokesTheOldLeadersPendingInvitations() {
    var service = service(null);
    UUID leader = UUID.randomUUID(), successor = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, successor);
    service.acceptInvite(successor, leader);
    service.inviteMember(party.getId(), leader, target);
    service.transferLeadership(party.getId(), leader, successor);
    assertThat(service.getPartyInvites(target)).isEmpty();
    assertThatThrownBy(() -> service.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
    assertThat(party.isMember(target)).isFalse();
  }

  @Test
  void rejectedSqlDeletionDoesNotPartiallyDisbandTheParty() {
    var storage = mock(SqlSocialStateStorage.class);
    var service = service(storage);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    doThrow(new IllegalStateException("unavailable"))
        .when(storage)
        .deletePartyInvite(leader, target);
    assertThatThrownBy(() -> service.disbandParty(party.getId(), leader))
        .isInstanceOf(IllegalStateException.class);
    assertThat(service.getPlayerParty(leader)).isSameAs(party);
    assertThat(service.getAllParties()).containsExactly(party);
  }

  private static final class MutableClock extends Clock {
    private Instant instant = Instant.parse("2026-11-26T00:00:00Z");

    void advance(long milliseconds) {
      instant = instant.plusMillis(milliseconds);
    }

    @Override
    public ZoneId getZone() {
      return ZoneOffset.UTC;
    }

    @Override
    public Clock withZone(ZoneId zone) {
      return this;
    }

    @Override
    public Instant instant() {
      return instant;
    }
  }
}
