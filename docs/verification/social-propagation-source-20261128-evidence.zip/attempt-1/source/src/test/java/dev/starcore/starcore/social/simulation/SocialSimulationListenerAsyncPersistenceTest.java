package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.junit.jupiter.api.Test;

class SocialSimulationListenerAsyncPersistenceTest {
  @Test
  void playerJoinReturnsWhileInfluencePersistenceIsBlocked() throws Exception {
    UUID playerId = UUID.randomUUID();
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(playerId);
    PlayerJoinEvent event = mock(PlayerJoinEvent.class);
    when(event.getPlayer()).thenReturn(player);

    ReputationService reputation = mock(ReputationService.class);
    when(reputation.getReputation(playerId)).thenReturn(0);
    RelationshipNetwork relationships = mock(RelationshipNetwork.class);
    when(relationships.getFriends(playerId)).thenReturn(Set.of());
    SocialInfluenceService influence = mock(SocialInfluenceService.class);

    CountDownLatch persistenceStarted = new CountDownLatch(1);
    CountDownLatch releasePersistence = new CountDownLatch(1);
    CountDownLatch persistenceFinished = new CountDownLatch(1);
    CountDownLatch joinReturned = new CountDownLatch(1);
    AtomicReference<String> persistenceThread = new AtomicReference<>();
    AtomicReference<Throwable> joinFailure = new AtomicReference<>();
    ExecutorService ioExecutor =
        Executors.newSingleThreadExecutor(task -> new Thread(task, "social-influence-test-io"));

    doAnswer(
            invocation -> {
              persistenceThread.set(Thread.currentThread().getName());
              persistenceStarted.countDown();
              try {
                if (!releasePersistence.await(2, TimeUnit.SECONDS)) {
                  throw new AssertionError("test did not release persistence");
                }
              } finally {
                persistenceFinished.countDown();
              }
              return null;
            })
        .when(influence)
        .addInfluence(playerId, 10, "上线");

    SocialSimulationListener listener =
        new SocialSimulationListener(
            reputation,
            relationships,
            influence,
            null,
            null,
            null,
            null,
            null,
            task -> CompletableFuture.runAsync(task, ioExecutor));
    Thread serverThread =
        new Thread(
            () -> {
              try {
                listener.onPlayerJoin(event);
              } catch (Throwable failure) {
                joinFailure.set(failure);
              } finally {
                joinReturned.countDown();
              }
            },
            "paper-main-test");

    try {
      serverThread.start();
      assertThat(persistenceStarted.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(joinReturned.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(joinFailure.get()).isNull();
      assertThat(releasePersistence.getCount()).isEqualTo(1);
      assertThat(persistenceThread.get()).isEqualTo("social-influence-test-io");
    } finally {
      releasePersistence.countDown();
      assertThat(persistenceFinished.await(1, TimeUnit.SECONDS)).isTrue();
      ioExecutor.shutdownNow();
      serverThread.join(1000);
    }
    assertThat(serverThread.isAlive()).isFalse();
  }

  @Test
  void playerQuitReturnsWhileInfluencePersistenceIsBlocked() throws Exception {
    UUID playerId = UUID.randomUUID();
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(playerId);
    PlayerQuitEvent event = mock(PlayerQuitEvent.class);
    when(event.getPlayer()).thenReturn(player);

    RelationshipNetwork relationships = mock(RelationshipNetwork.class);
    when(relationships.getFriends(playerId)).thenReturn(Set.of());
    SocialInfluenceService influence = mock(SocialInfluenceService.class);

    CountDownLatch persistenceStarted = new CountDownLatch(1);
    CountDownLatch releasePersistence = new CountDownLatch(1);
    CountDownLatch persistenceFinished = new CountDownLatch(1);
    CountDownLatch quitReturned = new CountDownLatch(1);
    AtomicReference<String> persistenceThread = new AtomicReference<>();
    AtomicReference<Throwable> quitFailure = new AtomicReference<>();
    ExecutorService ioExecutor =
        Executors.newSingleThreadExecutor(task -> new Thread(task, "social-influence-test-io"));

    doAnswer(
            invocation -> {
              persistenceThread.set(Thread.currentThread().getName());
              persistenceStarted.countDown();
              try {
                if (!releasePersistence.await(2, TimeUnit.SECONDS)) {
                  throw new AssertionError("test did not release persistence");
                }
              } finally {
                persistenceFinished.countDown();
              }
              return null;
            })
        .when(influence)
        .addInfluence(playerId, -5, "下线");

    SocialSimulationListener listener =
        new SocialSimulationListener(
            null,
            relationships,
            influence,
            null,
            null,
            null,
            null,
            null,
            task -> CompletableFuture.runAsync(task, ioExecutor));
    Thread serverThread =
        new Thread(
            () -> {
              try {
                listener.onPlayerQuit(event);
              } catch (Throwable failure) {
                quitFailure.set(failure);
              } finally {
                quitReturned.countDown();
              }
            },
            "paper-main-test");

    try {
      serverThread.start();
      assertThat(persistenceStarted.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(quitReturned.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(quitFailure.get()).isNull();
      assertThat(releasePersistence.getCount()).isEqualTo(1);
      assertThat(persistenceThread.get()).isEqualTo("social-influence-test-io");
    } finally {
      releasePersistence.countDown();
      assertThat(persistenceFinished.await(1, TimeUnit.SECONDS)).isTrue();
      ioExecutor.shutdownNow();
      serverThread.join(1000);
    }
    assertThat(serverThread.isAlive()).isFalse();
  }
}
