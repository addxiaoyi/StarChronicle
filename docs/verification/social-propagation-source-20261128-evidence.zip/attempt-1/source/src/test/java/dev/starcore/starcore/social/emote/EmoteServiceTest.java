package dev.starcore.starcore.social.emote;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("EmoteService (registry) Tests")
class EmoteServiceTest {

  private EmoteService service;

  @BeforeEach
  void setUp() {
    service = new EmoteService();
  }

  @Test
  @DisplayName("default emotes are registered")
  void shouldRegisterDefaultEmotes() {
    assertThat(service.getEmote("wave")).isPresent();
    assertThat(service.getEmote("bow")).isPresent();
    assertThat(service.getEmote("hug")).isPresent();
    assertThat(service.getEmote("dance")).isPresent();
  }

  @Test
  @DisplayName("emote lookup is case-insensitive")
  void shouldBeCaseInsensitive() {
    assertThat(service.getEmote("WAVE")).isPresent();
    assertThat(service.getEmote("Wave")).isPresent();
    assertThat(service.getEmote("wave")).isPresent();
  }

  @Test
  @DisplayName("unknown emote returns empty")
  void shouldReturnEmptyForUnknown() {
    assertThat(service.getEmote("nope")).isEmpty();
  }

  @Test
  @DisplayName("register and unregister custom emote")
  void shouldRegisterAndUnregister() {
    EmoteDefinition custom =
        EmoteDefinition.builder().id("custom_test_xyz").name("Custom").description("test").build();
    service.registerEmote(custom);

    assertThat(service.getEmote("custom_test_xyz")).isPresent();

    service.unregisterEmote("custom_test_xyz");
    assertThat(service.getEmote("custom_test_xyz")).isEmpty();
  }

  @Test
  @DisplayName("registerEmote ignores emote with null id or name")
  void shouldIgnoreEmoteWithNullIdOrName() {
    EmoteDefinition noId = EmoteDefinition.builder().name("X").build();
    service.registerEmote(noId);
    assertThat(service.getAllEmotes()).noneMatch(e -> e == noId);

    EmoteDefinition noName = EmoteDefinition.builder().id("x_id").build();
    service.registerEmote(noName);
    assertThat(service.getAllEmotes()).noneMatch(e -> e == noName);
  }

  @Test
  @DisplayName("unregister null id is no-op")
  void shouldHandleUnregisterNull() {
    service.unregisterEmote(null);
    // should not throw, no state change
    assertThat(service.getEmote("wave")).isPresent();
  }

  @Test
  @DisplayName("getEmotesByCategory returns only matching emotes")
  void shouldFilterByCategory() {
    assertThat(service.getEmotesByCategory("greeting")).isNotEmpty();
    assertThat(service.getEmotesByCategory("greeting"))
        .allMatch(e -> e.getCategory().equalsIgnoreCase("greeting"));
    assertThat(service.getEmotesByCategory("unknown_category")).isEmpty();
  }

  @Test
  @DisplayName("getCategories returns the distinct categories")
  void shouldReturnDistinctCategories() {
    assertThat(service.getCategories())
        .contains("greeting", "emotion", "social", "combat", "action");
  }

  @Test
  @DisplayName("getOrCreateState returns same state for same player")
  void shouldReturnSameState() {
    UUID player = UUID.randomUUID();
    EmoteState s1 = service.getOrCreateState(player);
    EmoteState s2 = service.getOrCreateState(player);
    assertThat(s1).isSameAs(s2);
  }

  @Test
  @DisplayName("clearState removes player state")
  void shouldClearState() {
    UUID player = UUID.randomUUID();
    service.getOrCreateState(player);
    service.clearState(player);
    assertThat(service.getPlayerState(player)).isEmpty();
  }

  @Test
  @DisplayName("getPlayerState returns empty when never set (uuid variant)")
  void shouldReturnEmptyForUnknownPlayerState() {
    assertThat(service.getPlayerState(UUID.randomUUID())).isEmpty();
  }

  @Test
  @DisplayName("EmoteResult enum has expected values")
  void emoteResultShouldHaveExpectedValues() {
    assertThat(EmoteService.EmoteResult.values())
        .contains(
            EmoteService.EmoteResult.SUCCESS,
            EmoteService.EmoteResult.EMOTE_NOT_FOUND,
            EmoteService.EmoteResult.NO_PERMISSION,
            EmoteService.EmoteResult.ON_COOLDOWN,
            EmoteService.EmoteResult.TARGET_REQUIRED,
            EmoteService.EmoteResult.INVALID_TARGET,
            EmoteService.EmoteResult.PLAYER_NOT_FOUND);
  }

  @Test
  @DisplayName("setAnimationHandler stores handler")
  void shouldStoreAnimationHandler() {
    EmoteAnimationHandler handler = new EmoteAnimationHandler(service);
    service.setAnimationHandler(handler);
    // no assertion crash means it stored
    assertThat(handler).isNotNull();
  }

  @Test
  @DisplayName("executeEmote returns EMOTE_NOT_FOUND for unknown emote")
  void shouldReturnNotFound() {
    // We can't easily mock Player without Bukkit, so use the Optional API instead
    Optional<EmoteDefinition> emote = service.getEmote("nope");
    assertThat(emote).isEmpty();
  }
}
