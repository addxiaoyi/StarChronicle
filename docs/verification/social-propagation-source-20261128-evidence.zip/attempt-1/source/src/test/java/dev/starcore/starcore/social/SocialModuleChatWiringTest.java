package dev.starcore.starcore.social;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.module.nation.NationService;
import java.util.Optional;
import org.junit.jupiter.api.Test;

class SocialModuleChatWiringTest {

  @Test
  void resolvesRegisteredNationServiceForChat() {
    ServiceRegistry registry = mock(ServiceRegistry.class);
    StarCoreContext context = mock(StarCoreContext.class);
    NationService nationService = mock(NationService.class);
    when(context.serviceRegistry()).thenReturn(registry);
    when(registry.find(NationService.class)).thenReturn(Optional.of(nationService));

    assertSame(nationService, SocialModule.resolveNationService(context));
  }

  @Test
  void keepsChatAvailableWhenNationServiceIsMissing() {
    ServiceRegistry registry = mock(ServiceRegistry.class);
    StarCoreContext context = mock(StarCoreContext.class);
    when(context.serviceRegistry()).thenReturn(registry);
    when(registry.find(NationService.class)).thenReturn(Optional.empty());

    assertNull(SocialModule.resolveNationService(context));
  }
}
