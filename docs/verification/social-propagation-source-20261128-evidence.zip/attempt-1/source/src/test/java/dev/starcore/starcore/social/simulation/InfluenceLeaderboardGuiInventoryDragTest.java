package dev.starcore.starcore.social.simulation;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import net.kyori.adventure.text.Component;
import org.bukkit.Server;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.junit.jupiter.api.Test;

class InfluenceLeaderboardGuiInventoryDragTest {
  @Test
  void leaderboardUsesItsHolderAndIgnoresTitleOnlyMatches() {
    Plugin plugin = mock(Plugin.class);
    Server server = mock(Server.class);
    PluginManager pluginManager = mock(PluginManager.class);
    when(plugin.getServer()).thenReturn(server);
    when(server.getPluginManager()).thenReturn(pluginManager);
    InfluenceLeaderboardGui gui =
        new InfluenceLeaderboardGui(plugin, mock(InfluenceLeaderboardService.class));

    InventoryDragEvent leaderboardDrag =
        drag("broken localized title", new InfluenceLeaderboardGui.MenuHolder(gui));
    gui.onInventoryDrag(leaderboardDrag);
    verify(leaderboardDrag).setCancelled(true);

    InventoryDragEvent unrelatedDrag = drag("§6§l影响力排行榜", mock(InventoryHolder.class));
    gui.onInventoryDrag(unrelatedDrag);
    verify(unrelatedDrag, never()).setCancelled(true);
  }

  private static InventoryDragEvent drag(String title, InventoryHolder holder) {
    Inventory top = mock(Inventory.class);
    when(top.getHolder()).thenReturn(holder);
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    when(view.title()).thenReturn(Component.text(title));
    InventoryDragEvent event = mock(InventoryDragEvent.class);
    when(event.getView()).thenReturn(view);
    return event;
  }
}
