package dev.starcore.starcore.social.simulation.gui;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import dev.starcore.starcore.social.simulation.SocialClassService;
import dev.starcore.starcore.social.simulation.SocialClassService.SocialClass;
import java.lang.reflect.Method;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** SocialClassGui 中不依赖真实 Bukkit 背包的阶层与权限映射契约。 */
class SocialClassGuiTest {
  private SocialClassGui gui;

  @BeforeEach
  void setUp() {
    gui = new SocialClassGui(mock(Player.class), mock(SocialClassService.class));
  }

  private Object invoke(String name, Class<?> type, Object value) throws Exception {
    Method method = SocialClassGui.class.getDeclaredMethod(name, type);
    method.setAccessible(true);
    return method.invoke(gui, value);
  }

  private String string(String name, String value) throws Exception {
    return (String) invoke(name, String.class, value);
  }

  private Material material(String name, String value) throws Exception {
    return (Material) invoke(name, String.class, value);
  }

  @Test
  @DisplayName("每个阶层的下一阶与解锁点数保持枚举顺序")
  void nextClassAndPointsFollowEnumOrder() throws Exception {
    assertThat(invoke("getNextClass", SocialClass.class, SocialClass.PEASANT))
        .isEqualTo(SocialClass.WORKER);
    assertThat(invoke("getNextLevelPoints", SocialClass.class, SocialClass.PEASANT))
        .isEqualTo(100);
    assertThat(invoke("getNextClass", SocialClass.class, SocialClass.WORKER))
        .isEqualTo(SocialClass.MERCHANT);
    assertThat(invoke("getNextLevelPoints", SocialClass.class, SocialClass.NOBLE))
        .isEqualTo(5000);
  }

  @Test
  @DisplayName("最高阶没有下一阶且点数上限等于自身门槛")
  void highestClassHasNoNextClass() throws Exception {
    assertThat(invoke("getNextClass", SocialClass.class, SocialClass.DIVINITY)).isNull();
    assertThat(invoke("getNextLevelPoints", SocialClass.class, SocialClass.DIVINITY))
        .isEqualTo(SocialClass.DIVINITY.requiredPoints());
  }

  @Test
  @DisplayName("阶层材质映射覆盖起始、中间和最高阶")
  void classMaterialMapping() throws Exception {
    assertThat(invoke("getClassMaterial", SocialClass.class, SocialClass.PEASANT))
        .isEqualTo(Material.DIRT);
    assertThat(invoke("getClassMaterial", SocialClass.class, SocialClass.MERCHANT))
        .isEqualTo(Material.GOLD_INGOT);
    assertThat(invoke("getClassMaterial", SocialClass.class, SocialClass.DIVINITY))
        .isEqualTo(Material.END_CRYSTAL);
  }

  @Test
  @DisplayName("下一阶材质映射在最高阶仍有稳定回退")
  void nextClassMaterialMapping() throws Exception {
    assertThat(invoke("getNextClassMaterial", SocialClass.class, SocialClass.PEASANT))
        .isEqualTo(Material.DIRT);
    assertThat(invoke("getNextClassMaterial", SocialClass.class, SocialClass.ROYALTY))
        .isEqualTo(Material.END_CRYSTAL);
    assertThat(invoke("getNextClassMaterial", SocialClass.class, SocialClass.DIVINITY))
        .isEqualTo(Material.END_CRYSTAL);
  }

  @Test
  @DisplayName("权限名称与描述覆盖已知权限并保留未知权限")
  void privilegeTextMapping() throws Exception {
    assertThat(string("formatPrivilegeName", "basic_trade")).isEqualTo("基础交易");
    assertThat(string("formatPrivilegeName", "TITLE_ROYALTY")).isEqualTo("皇室称号");
    assertThat(string("formatPrivilegeName", "unknown_privilege")).isEqualTo("unknown_privilege");
    assertThat(string("formatPrivilegeDescription", "market_access"))
        .isEqualTo("可进入和使用市场功能");
    assertThat(string("formatPrivilegeDescription", "unknown_privilege"))
        .isEqualTo("特殊权限");
  }

  @Test
  @DisplayName("权限材质映射覆盖交易、访问、事件和未知权限")
  void privilegeMaterialMapping() throws Exception {
    assertThat(material("getPrivilegeMaterial", "basic_trade")).isEqualTo(Material.CHEST);
    assertThat(material("getPrivilegeMaterial", "all_access")).isEqualTo(Material.BEACON);
    assertThat(material("getPrivilegeMaterial", "event_creator")).isEqualTo(Material.FIREWORK_ROCKET);
    assertThat(material("getPrivilegeMaterial", "unknown_privilege")).isEqualTo(Material.DIAMOND);
  }
}
