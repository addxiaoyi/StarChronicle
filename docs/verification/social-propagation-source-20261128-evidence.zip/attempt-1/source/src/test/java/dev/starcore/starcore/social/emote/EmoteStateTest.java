package dev.starcore.starcore.social.emote;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("EmoteState Tests")
class EmoteStateTest {

  private UUID playerId;
  private EmoteState state;

  @BeforeEach
  void setUp() {
    playerId = UUID.randomUUID();
    state = new EmoteState(playerId);
  }

  @Test
  @DisplayName("constructor initializes with defaults")
  void shouldInitializeWithDefaults() {
    assertThat(state.getPlayerId()).isEqualTo(playerId);
    assertThat(state.getCurrentEmoteId()).isNull();
    assertThat(state.getEmoteStartTime()).isEqualTo(0L);
    assertThat(state.getLastEmoteTime()).isEqualTo(0L);
    assertThat(state.getTargetPlayerId()).isNull();
    assertThat(state.isAnimating()).isFalse();
  }

  @Test
  @DisplayName("setCurrentEmote sets values and starts animation")
  void shouldSetCurrentEmote() {
    UUID target = UUID.randomUUID();
    state.setCurrentEmote("wave", 1000L, target);

    assertThat(state.getCurrentEmoteId()).isEqualTo("wave");
    assertThat(state.getEmoteStartTime()).isEqualTo(1000L);
    assertThat(state.getTargetPlayerId()).isEqualTo(target);
    assertThat(state.isAnimating()).isTrue();
  }

  @Test
  @DisplayName("clearEmote resets state")
  void shouldClearEmote() {
    state.setCurrentEmote("wave", 1000L, UUID.randomUUID());
    state.clearEmote();

    assertThat(state.getCurrentEmoteId()).isNull();
    assertThat(state.getEmoteStartTime()).isEqualTo(0L);
    assertThat(state.getTargetPlayerId()).isNull();
    assertThat(state.isAnimating()).isFalse();
  }

  @Test
  @DisplayName("updateLastEmoteTime sets lastEmoteTime to now")
  void shouldUpdateLastEmoteTime() {
    state.updateLastEmoteTime();
    long now = System.currentTimeMillis();
    // Allow some slack
    assertThat(state.getLastEmoteTime()).isLessThanOrEqualTo(now);
    assertThat(state.getLastEmoteTime()).isGreaterThan(now - 1000L);
  }

  @Test
  @DisplayName("isOnCooldown returns false when never used and lastEmoteTime is 0")
  void shouldNotBeOnCooldownWhenNeverUsed() {
    assertThat(state.isOnCooldown(5)).isFalse();
  }

  @Test
  @DisplayName("getRemainingCooldown returns 0 when never used")
  void shouldHaveZeroRemainingWhenNeverUsed() {
    assertThat(state.getRemainingCooldown(5)).isEqualTo(0);
  }

  @Test
  @DisplayName("per-emote cooldown check (D-046) returns false for unrecorded emote")
  void shouldNotBeOnCooldownForUnrecordedEmote() {
    assertThat(state.isOnCooldown("wave", 5)).isFalse();
  }

  @Test
  @DisplayName("per-emote cooldown check (D-046) returns true right after emote is set")
  void shouldBeOnCooldownRightAfterEmoteSet() throws InterruptedException {
    state.setCurrentEmote("wave", System.currentTimeMillis(), null);
    // immediately after, cooldown is active
    assertThat(state.isOnCooldown("wave", 10)).isTrue();
  }

  @Test
  @DisplayName("isOnCooldown returns true immediately after setCurrentEmote")
  void shouldBeOnCooldownForCurrentEmote() {
    state.setCurrentEmote("wave", System.currentTimeMillis(), null);
    // use very long cooldown to be sure it triggers
    assertThat(state.isOnCooldown(3600)).isTrue();
  }

  @Test
  @DisplayName("isOnCooldown returns false after legacy lastEmoteTime expires")
  void shouldNotBeOnCooldownAfterLegacyExpire() {
    // Simulate a legacy cooldown that has already expired: lastEmoteTime=0
    // and no current emote -> not on cooldown
    assertThat(state.isOnCooldown(5)).isFalse();
  }
}
