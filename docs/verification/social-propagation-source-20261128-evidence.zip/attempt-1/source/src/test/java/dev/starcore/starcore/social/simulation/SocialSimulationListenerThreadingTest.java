package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

class SocialSimulationListenerThreadingTest {

  @Test
  void schedulerOwnershipAndUnregistrationAreBoundToRegisteredPlugin() throws IOException {
    String source =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/simulation/SocialSimulationListener.java"));
    String compact = source.replaceAll("\\s+", "");

    assertThat(compact)
        .contains("this.registeredPlugin=Objects.requireNonNull(plugin,\"plugin\");")
        .contains("HandlerList.unregisterAll(this);")
        .contains("registeredPlugin=null;")
        .contains("JavaPluginplugin=registeredPlugin;")
        .contains("registeredPlugin==plugin&&plugin.isEnabled()")
        .contains("runLater(()->recentlyHelped.remove(helperId),600L)")
        .contains("runSync(()->{")
        .doesNotContain("Bukkit.getPluginManager().getPlugins()[0]");
  }
}
