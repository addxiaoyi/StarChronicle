package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.social.SocialSimulationModule;
import dev.starcore.starcore.social.simulation.events.ReputationChangeEvent;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import org.bukkit.Server;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.Test;

class ReputationServiceLifecycleTest {

  @Test
  void concurrentChangesAreSerializedAndCallbacksUseBukkitScheduler() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    Server server = mock(Server.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    PluginManager pluginManager = mock(PluginManager.class);
    BukkitTask callbackTask = mock(BukkitTask.class);
    when(plugin.getLogger()).thenReturn(Logger.getLogger("ReputationServiceLifecycleTest"));
    when(plugin.getServer()).thenReturn(server);
    when(server.getScheduler()).thenReturn(scheduler);
    when(server.getPluginManager()).thenReturn(pluginManager);
    when(scheduler.runTask(eq(plugin), any(Runnable.class)))
        .thenAnswer(
            invocation -> {
              invocation.getArgument(1, Runnable.class).run();
              return callbackTask;
            });

    ReputationServiceImpl service = new ReputationServiceImpl(plugin, null);
    UUID playerId = UUID.randomUUID();
    List<CompletableFuture<Boolean>> updates = new ArrayList<>();
    for (int index = 0; index < 50; index++) {
      updates.add(
          service.modifyReputation(playerId, 1, ReputationService.ReputationReason.HELP_PLAYER));
    }
    CompletableFuture.allOf(updates.toArray(CompletableFuture[]::new)).join();

    assertEquals(50, service.getReputation(playerId));
    assertEquals(
        50,
        service.getProfile(playerId).dimensions().get(ReputationService.ReputationDimension.MORAL));
    verify(scheduler, times(50)).runTask(eq(plugin), any(Runnable.class));
    verify(pluginManager, times(50)).callEvent(any(ReputationChangeEvent.class));

    service.shutdown();
    service.shutdown();
    assertTrue(
        service
            .modifyReputation(playerId, 1, ReputationService.ReputationReason.HELP_PLAYER)
            .isCompletedExceptionally());
  }

  @Test
  void socialSimulationDisableShutsDownAndUnregistersReputationService() throws Exception {
    SocialSimulationModule module = new SocialSimulationModule();
    ReputationService reputationService = mock(ReputationService.class);
    setField(module, "reputationService", reputationService);

    StarCoreContext context = mock(StarCoreContext.class);
    ServiceRegistry registry = mock(ServiceRegistry.class);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(context.serviceRegistry()).thenReturn(registry);
    when(context.plugin()).thenReturn(plugin);
    when(plugin.getLogger()).thenReturn(Logger.getLogger("ReputationServiceLifecycleTest"));

    module.disable(context);

    verify(reputationService).shutdown();
    verify(registry).unregister(ReputationService.class, reputationService);
  }

  private static void setField(Object target, String name, Object value) throws Exception {
    Field field = target.getClass().getDeclaredField(name);
    field.setAccessible(true);
    field.set(target, value);
  }
}
