package dev.starcore.starcore.social.friend;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * 好友黑名单测试 - 覆盖 addToBlacklist / removeFromBlacklist / isBlacklisted / getBlacklist
 * 的各种分支路径，包括黑名单对好友和请求的副作用验证。
 *
 * <p>测试不依赖任何外部服务（数据库/YAML），仅验证 FriendService 内部状态机逻辑。
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("好友黑名单测试")
class FriendServiceBlacklistTest {

  private FriendService friendService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();
  private final UUID carol = UUID.randomUUID();

  @BeforeEach
  void setUp() {
    friendService = new FriendService();
  }

  /** 辅助方法: 建立 alice 和 bob 之间的好友关系 */
  private void makeFriends(UUID a, UUID b) {
    friendService.sendFriendRequest(a, b);
    friendService.acceptFriendRequest(b, a);
  }

  // ===== addToBlacklist =====

  @Test
  @DisplayName("addToBlacklist: 拉黑后应返回 true")
  void addToBlacklist_success_returnsTrue() {
    assertTrue(friendService.addToBlacklist(alice, bob));
  }

  @Test
  @DisplayName("addToBlacklist: 重复拉黑同一玩家应返回 false")
  void addToBlacklist_duplicate_returnsFalse() {
    friendService.addToBlacklist(alice, bob);
    assertFalse(friendService.addToBlacklist(alice, bob));
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑自己应被拒绝")
  void addToBlacklist_self_shouldBeRejected() {
    assertThrows(IllegalArgumentException.class, () -> friendService.addToBlacklist(alice, alice));
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后 isBlacklisted 应返回 true（单向）")
  void addToBlacklist_isBlacklisted_reflectsBlacklist() {
    friendService.addToBlacklist(alice, bob);
    assertTrue(friendService.isBlacklisted(alice, bob), "alice 拉黑的玩家应显示为已拉黑");
    assertFalse(friendService.isBlacklisted(bob, alice), "bob 没有拉黑 alice，查询应为 false");
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后 getBlacklist 应包含该玩家")
  void addToBlacklist_getBlacklist_includesPlayer() {
    friendService.addToBlacklist(alice, bob);
    friendService.addToBlacklist(alice, carol);

    Set<UUID> blacklist = friendService.getBlacklist(alice);
    assertEquals(2, blacklist.size());
    assertTrue(blacklist.contains(bob));
    assertTrue(blacklist.contains(carol));
  }

  // ===== 黑名单副作用: 好友关系解除 =====

  @Test
  @DisplayName("addToBlacklist: 拉黑已存在的好友应同时解除好友关系")
  void addToBlacklist_existingFriend_removesFriendship() {
    makeFriends(alice, bob);
    assertTrue(friendService.isFriend(alice, bob));

    friendService.addToBlacklist(alice, bob);

    assertFalse(friendService.isFriend(alice, bob), "拉黑后应解除好友关系");
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后好友数应减少")
  void addToBlacklist_reducesFriendCount() {
    makeFriends(alice, bob);
    makeFriends(alice, carol);
    assertEquals(2, friendService.getFriendCount(alice));

    friendService.addToBlacklist(alice, bob);
    assertEquals(1, friendService.getFriendCount(alice), "拉黑 bob 后 alice 的好友数应减 1");
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后 getFriends 不应包含被拉黑的玩家")
  void addToBlacklist_getFriends_excludesBlocked() {
    makeFriends(alice, bob);
    friendService.addToBlacklist(alice, bob);

    Set<UUID> friends = friendService.getFriends(alice);
    assertFalse(friends.contains(bob), "getFriends 不应包含被拉黑的玩家");
  }

  // ===== 黑名单副作用: 拒绝好友请求 =====

  @Test
  @DisplayName("addToBlacklist: 拉黑后对方的好友请求应被自动拒绝")
  void addToBlacklist_pendingRequest_autoRejected() {
    friendService.sendFriendRequest(bob, alice);
    assertTrue(friendService.getFriendRequests(alice).contains(bob));

    friendService.addToBlacklist(alice, bob);

    assertFalse(friendService.getFriendRequests(alice).contains(bob), "拉黑后待处理的请求应被自动清除");
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后自己发出的请求应被清除")
  void addToBlacklist_sentRequest_autoRemoved() {
    friendService.sendFriendRequest(alice, bob);
    assertTrue(friendService.getFriendRequests(bob).contains(alice));

    friendService.addToBlacklist(alice, bob);

    assertFalse(friendService.getFriendRequests(bob).contains(alice), "拉黑后自己发出的请求应被清除");
  }

  // ===== removeFromBlacklist =====

  @Test
  @DisplayName("removeFromBlacklist: 正常移除应返回 true")
  void removeFromBlacklist_success_returnsTrue() {
    friendService.addToBlacklist(alice, bob);
    assertTrue(friendService.removeFromBlacklist(alice, bob));
  }

  @Test
  @DisplayName("removeFromBlacklist: 移除不在黑名单中的玩家应返回 false")
  void removeFromBlacklist_notListed_returnsFalse() {
    assertFalse(friendService.removeFromBlacklist(alice, bob));
  }

  @Test
  @DisplayName("removeFromBlacklist: 移除后 isBlacklisted 应返回 false")
  void removeFromBlacklist_isBlacklisted_reflectsRemoval() {
    friendService.addToBlacklist(alice, bob);
    friendService.removeFromBlacklist(alice, bob);

    assertFalse(friendService.isBlacklisted(alice, bob), "移除后 isBlacklisted 应返回 false");
  }

  @Test
  @DisplayName("removeFromBlacklist: 移除后 getBlacklist 不应包含该玩家")
  void removeFromBlacklist_getBlacklist_excludesPlayer() {
    friendService.addToBlacklist(alice, bob);
    friendService.addToBlacklist(alice, carol);
    friendService.removeFromBlacklist(alice, bob);

    Set<UUID> blacklist = friendService.getBlacklist(alice);
    assertEquals(1, blacklist.size());
    assertFalse(blacklist.contains(bob));
    assertTrue(blacklist.contains(carol));
  }

  @Test
  @DisplayName("removeFromBlacklist: 移除黑名单后可以重新加好友")
  void removeFromBlacklist_canAddFriendAfter() {
    friendService.addToBlacklist(alice, bob);
    friendService.removeFromBlacklist(alice, bob);

    assertTrue(friendService.sendFriendRequest(alice, bob), "解除黑名单后应可以重新发送好友请求");
  }

  // ===== getBlacklist =====

  @Test
  @DisplayName("getBlacklist: 未拉黑任何玩家时应返回空集合")
  void getBlacklist_empty_returnsEmptySet() {
    assertTrue(friendService.getBlacklist(alice).isEmpty());
  }

  @Test
  @DisplayName("getBlacklist: 返回的集合为副本，修改不影响内部状态")
  void getBlacklist_returnsDefensiveCopy() {
    friendService.addToBlacklist(alice, bob);
    Set<UUID> blacklist = friendService.getBlacklist(alice);
    blacklist.clear();

    assertFalse(friendService.getBlacklist(alice).isEmpty(), "清空返回集合不应影响内部状态");
  }

  // ===== isBlacklisted =====

  @Test
  @DisplayName("isBlacklisted: 未拉黑时应返回 false")
  void isBlacklisted_notListed_returnsFalse() {
    assertFalse(friendService.isBlacklisted(alice, bob));
  }

  @Test
  @DisplayName("isBlacklisted: 黑名单是单向的")
  void isBlacklisted_unidirectional() {
    friendService.addToBlacklist(alice, bob);
    assertTrue(friendService.isBlacklisted(alice, bob));
    assertFalse(friendService.isBlacklisted(bob, alice));
  }

  @Test
  @DisplayName("isBlacklisted: null 参数应抛出空指针异常")
  void isBlacklisted_nullArgument_throwsNpe() {
    assertThrows(NullPointerException.class, () -> friendService.isBlacklisted(null, bob));
    assertThrows(NullPointerException.class, () -> friendService.isBlacklisted(alice, null));
  }

  // ===== 黑名单与其他操作的交互 =====

  @Test
  @DisplayName("addToBlacklist: 双向拉黑后 removeFriend 不应抛出异常")
  void addToBlacklist_mutualBlock_thenRemoveFriend_isSafe() {
    makeFriends(alice, bob);
    friendService.addToBlacklist(alice, bob);
    friendService.addToBlacklist(bob, alice);

    assertDoesNotThrow(() -> friendService.removeFriend(alice, bob));
    assertDoesNotThrow(() -> friendService.removeFriend(bob, alice));
  }

  @Test
  @DisplayName("addToBlacklist: 拉黑后再接受待处理请求应抛出异常")
  void addToBlacklist_thenAcceptPendingRequest_throws() {
    friendService.sendFriendRequest(bob, alice);
    friendService.addToBlacklist(alice, bob);

    assertThrows(IllegalStateException.class, () -> friendService.acceptFriendRequest(alice, bob));
  }

  @Test
  @DisplayName("黑名单玩家不应出现在 getFriends 返回列表中")
  void getFriends_neverIncludesBlacklistedPlayers() {
    makeFriends(alice, bob);
    friendService.addToBlacklist(alice, carol);

    // alice 没有和 carol 是好友，carol 不在黑名单玩家的反向好友列表中
    // 但关键是: 如果 alice 拉黑了 bob，bob 仍然可以添加 alice 为好友（单向拉黑）
    friendService.addToBlacklist(alice, bob);

    Set<UUID> friends = friendService.getFriends(alice);
    assertFalse(friends.contains(bob));
  }

  // ===== cleanup 与黑名单 =====

  @Test
  @DisplayName("cleanup: 清理玩家后黑名单应被清空")
  void cleanup_clearsBlacklist() {
    friendService.addToBlacklist(alice, bob);
    friendService.addToBlacklist(alice, carol);

    friendService.cleanup(alice);

    assertTrue(friendService.getBlacklist(alice).isEmpty(), "清理后黑名单应为空");
  }

  @Test
  @DisplayName("cleanup: 被 alice 拉黑的玩家，bob 的黑名单应不受影响")
  void cleanup_doesNotAffectOtherPlayersBlacklist() {
    friendService.addToBlacklist(alice, bob);
    friendService.addToBlacklist(carol, bob);

    friendService.cleanup(alice);

    assertFalse(friendService.getBlacklist(carol).isEmpty(), "carol 的黑名单不应被 alice 的清理操作影响");
    assertTrue(friendService.isBlacklisted(carol, bob), "carol 对 bob 的拉黑应保留");
  }
}
