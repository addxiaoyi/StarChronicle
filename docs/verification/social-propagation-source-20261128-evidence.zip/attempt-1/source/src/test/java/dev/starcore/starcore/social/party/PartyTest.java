package dev.starcore.starcore.social.party;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Party Tests")
class PartyTest {

  private UUID leader;
  private Party party;

  @BeforeEach
  void setUp() {
    leader = UUID.randomUUID();
    party = new Party(UUID.randomUUID(), leader);
  }

  @Test
  @DisplayName("constructor sets initial state with leader as sole member")
  void shouldInitialize() {
    assertThat(party.getId()).isNotNull();
    assertThat(party.getLeader()).isEqualTo(leader);
    assertThat(party.getMemberCount()).isEqualTo(1);
    assertThat(party.isLeader(leader)).isTrue();
    assertThat(party.isMember(leader)).isTrue();
    assertThat(party.isFriendlyFire()).isFalse();
    assertThat(party.isExpShare()).isTrue();
    assertThat(party.getMaxMembers()).isEqualTo(8);
    assertThat(party.getCreatedTime()).isLessThanOrEqualTo(System.currentTimeMillis());
    assertThat(party.getCreatedTime()).isGreaterThan(0L);
  }

  @Test
  @DisplayName("addMember adds new members up to maxMembers")
  void shouldAddMembers() {
    for (int i = 0; i < 7; i++) {
      assertThat(party.addMember(UUID.randomUUID())).isTrue();
    }
    assertThat(party.getMemberCount()).isEqualTo(8);
    assertThat(party.isFull()).isTrue();

    // 9th member rejected
    assertThat(party.addMember(UUID.randomUUID())).isFalse();
  }

  @Test
  @DisplayName("addMember returns false for duplicate member")
  void shouldRejectDuplicate() {
    UUID dup = UUID.randomUUID();
    assertThat(party.addMember(dup)).isTrue();
    assertThat(party.addMember(dup)).isFalse();
  }

  @Test
  @DisplayName("removeMember removes a member")
  void shouldRemoveMember() {
    UUID m = UUID.randomUUID();
    party.addMember(m);

    assertThat(party.removeMember(m)).isTrue();
    assertThat(party.isMember(m)).isFalse();

    // Removing non-member returns false
    assertThat(party.removeMember(UUID.randomUUID())).isFalse();
  }

  @Test
  @DisplayName("transferLeadership only succeeds for current members")
  void shouldTransferLeadership() {
    UUID newLeader = UUID.randomUUID();
    party.addMember(newLeader);
    party.transferLeadership(newLeader);

    assertThat(party.getLeader()).isEqualTo(newLeader);
    assertThat(party.isLeader(newLeader)).isTrue();

    // Non-member cannot become leader
    UUID outsider = UUID.randomUUID();
    party.transferLeadership(outsider);
    assertThat(party.getLeader()).isEqualTo(newLeader);
  }

  @Test
  @DisplayName("isFull respects maxMembers")
  void shouldRespectMaxMembers() {
    assertThat(party.isFull()).isFalse();
    party.setMaxMembers(1);
    assertThat(party.isFull()).isTrue();
  }

  @Test
  @DisplayName("getMembers returns an immutable snapshot set")
  void shouldReturnImmutableMemberSnapshot() {
    UUID m1 = UUID.randomUUID();
    party.addMember(m1);

    var snap = party.getMembers();
    assertThat(snap).contains(leader, m1);

    // Returns an immutable set — mutating should throw
    assertThatThrownBy(snap::clear).isInstanceOf(UnsupportedOperationException.class);
    assertThat(party.getMemberCount()).isEqualTo(2);
  }

  @Test
  @DisplayName("setters update settings")
  void shouldUpdateSettings() {
    party.setFriendlyFire(true);
    party.setExpShare(false);
    party.setMaxMembers(16);

    assertThat(party.isFriendlyFire()).isTrue();
    assertThat(party.isExpShare()).isFalse();
    assertThat(party.getMaxMembers()).isEqualTo(16);
  }
}
