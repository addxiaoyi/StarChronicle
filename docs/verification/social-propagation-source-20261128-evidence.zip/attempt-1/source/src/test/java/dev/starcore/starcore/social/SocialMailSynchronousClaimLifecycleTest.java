package dev.starcore.starcore.social;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.social.mail.Mail;
import dev.starcore.starcore.social.mail.MailService;
import dev.starcore.starcore.social.mail.attachment.MailAttachmentService.AttachmentClaimResult;
import dev.starcore.starcore.social.mail.attachment.impl.MailAttachmentServiceImpl;
import java.lang.reflect.Field;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.junit.jupiter.api.Test;

class SocialMailSynchronousClaimLifecycleTest {
  private final DatabaseService database = mock(DatabaseService.class);
  private final StarCoreScheduler scheduler = mock(StarCoreScheduler.class);
  private final MailService mailService = mock(MailService.class);
  private final Player player = mock(Player.class);
  private final UUID playerId = UUID.randomUUID();
  private final UUID mailId = UUID.randomUUID();
  private final MailAttachmentServiceImpl service =
      new MailAttachmentServiceImpl(database, scheduler, mailService, Logger.getAnonymousLogger());

  @Test
  void shutdownWaitsForDirectClaimAlreadyWritingInventoryAndConfirmingMail() throws Exception {
    PlayerInventory inventory = inventoryWithAttachment();
    CountDownLatch inventoryWriteEntered = new CountDownLatch(1);
    CountDownLatch releaseInventoryWrite = new CountDownLatch(1);
    doAnswer(
            invocation -> {
              inventoryWriteEntered.countDown();
              await(releaseInventoryWrite);
              return null;
            })
        .when(inventory)
        .setStorageContents(any(ItemStack[].class));
    CompletableFuture<AttachmentClaimResult> result = new CompletableFuture<>();
    Thread owner =
        new Thread(
            () -> {
              try {
                result.complete(service.claimAttachments(player, mailId));
              } catch (Throwable failure) {
                result.completeExceptionally(failure);
              }
            },
            "social-mail-direct-owner");
    Thread shutdown = new Thread(service::shutdown, "social-mail-direct-shutdown");
    try {
      owner.start();
      assertTrue(inventoryWriteEntered.await(5, TimeUnit.SECONDS));
      assertEquals(1, pendingCount());
      shutdown.start();
      assertTrue(awaitWaiting(shutdown));
      assertFalse(result.isDone());
      verify(mailService, never()).confirmClaimed(playerId, mailId);
    } finally {
      releaseInventoryWrite.countDown();
      owner.join(TimeUnit.SECONDS.toMillis(5));
      shutdown.join(TimeUnit.SECONDS.toMillis(5));
    }

    assertFalse(owner.isAlive());
    assertFalse(shutdown.isAlive());
    assertTrue(result.join().success());
    verify(mailService).confirmClaimed(playerId, mailId);
    assertEquals(0, pendingCount());
  }

  @Test
  void synchronousClaimSharesExactlyOnePendingRegistrationWithAsyncWrapper() throws Exception {
    inventoryWithAttachment();
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              Supplier<Void> operation = invocation.getArgument(1);
              return CompletableFuture.completedFuture(operation.get());
            });
    when(mailService.confirmClaimed(playerId, mailId))
        .thenAnswer(
            invocation -> {
              assertEquals(1, pendingCount());
              return true;
            });

    assertTrue(service.claimAttachmentsAsync(player, mailId).join().success());

    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  @Test
  void synchronousOwnerFailureAlwaysCleansRegistration() throws Exception {
    doThrow(new IllegalStateException("wrong owner")).when(scheduler).requireEntityOwner(player);

    assertThrows(IllegalStateException.class, () -> service.claimAttachments(player, mailId));

    assertEquals(0, pendingCount());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void synchronousClaimFailureAlwaysCleansRegistration() throws Exception {
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId)).thenThrow(new IllegalStateException("read failed"));

    assertThrows(IllegalStateException.class, () -> service.claimAttachments(player, mailId));

    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  @Test
  void synchronousShutdownInsideConfirmationDoesNotWaitForItsOwnClaim() throws Exception {
    inventoryWithAttachment();
    when(mailService.confirmClaimed(playerId, mailId))
        .thenAnswer(
            invocation -> {
              assertEquals(1, pendingCount());
              assertThrows(IllegalStateException.class, service::shutdown);
              return true;
            });

    assertTimeout(
        Duration.ofSeconds(1),
        () -> assertTrue(service.claimAttachments(player, mailId).success()));

    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  @Test
  void asyncShutdownInsideConfirmationDoesNotWaitForItsOwnClaim() throws Exception {
    inventoryWithAttachment();
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              Supplier<Void> operation = invocation.getArgument(1);
              return CompletableFuture.completedFuture(operation.get());
            });
    when(mailService.confirmClaimed(playerId, mailId))
        .thenAnswer(
            invocation -> {
              assertEquals(1, pendingCount());
              assertThrows(IllegalStateException.class, service::shutdown);
              return true;
            });

    assertTimeout(
        Duration.ofSeconds(1),
        () -> assertTrue(service.claimAttachmentsAsync(player, mailId).join().success()));

    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  @Test
  void nestedInlineOwnerShutdownSkipsAllOperationsExecutingOnItsOwnThread() throws Exception {
    inventoryWithAttachment();
    List<Mail> mails = mailService.getPlayerMails(playerId);
    AtomicInteger reads = new AtomicInteger();
    when(mailService.getPlayerMails(playerId))
        .thenAnswer(
            invocation -> {
              if (reads.incrementAndGet() == 2) {
                assertEquals(2, pendingCount());
                assertThrows(IllegalStateException.class, service::shutdown);
                return List.of();
              }
              return mails;
            });
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              Supplier<Void> operation = invocation.getArgument(1);
              return CompletableFuture.completedFuture(operation.get());
            });
    when(mailService.confirmClaimed(playerId, mailId))
        .thenAnswer(
            invocation -> {
              assertFalse(
                  service.claimAttachmentsAsync(player, UUID.randomUUID()).join().success());
              return true;
            });

    assertTimeout(
        Duration.ofSeconds(1),
        () -> assertTrue(service.claimAttachments(player, mailId).success()));

    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  @Test
  void stoppedServiceRejectsDirectClaimWithoutRegisteringOrReadingPlayer() throws Exception {
    service.stopAcceptingOperations();

    assertFalse(service.claimAttachments(player, mailId).success());

    assertEquals(0, pendingCount());
    verifyNoInteractions(player, mailService);
  }

  @Test
  void shutdownTimeoutPreservesStartedClaimAndAllowsRetry() throws Exception {
    assertFailedDrainCanRetry(false);
  }

  @Test
  void shutdownInterruptionPreservesInterruptAndAllowsRetry() throws Exception {
    assertFailedDrainCanRetry(true);
  }

  private void assertFailedDrainCanRetry(boolean interrupt) throws Exception {
    PlayerInventory inventory = inventoryWithAttachment();
    Field waitMillis = MailAttachmentServiceImpl.class.getDeclaredField("shutdownWaitMillis");
    waitMillis.setAccessible(true);
    waitMillis.set(service, 25L);
    CountDownLatch entered = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);
    doAnswer(
            invocation -> {
              entered.countDown();
              await(release);
              return null;
            })
        .when(inventory)
        .setStorageContents(any(ItemStack[].class));
    CompletableFuture<AttachmentClaimResult> claimed = new CompletableFuture<>();
    Thread owner =
        new Thread(
            () -> {
              try {
                claimed.complete(service.claimAttachments(player, mailId));
              } catch (Throwable failure) {
                claimed.completeExceptionally(failure);
              }
            },
            "social-mail-retry-owner");
    CompletableFuture<Boolean> failedShutdown = new CompletableFuture<>();
    Thread shutdown =
        new Thread(
            () -> {
              if (interrupt) Thread.currentThread().interrupt();
              try {
                service.shutdown();
                failedShutdown.completeExceptionally(new AssertionError("shutdown should fail"));
              } catch (IllegalStateException expected) {
                failedShutdown.complete(Thread.currentThread().isInterrupted());
              }
            },
            "social-mail-retry-shutdown");
    try {
      owner.start();
      assertTrue(entered.await(5, TimeUnit.SECONDS));
      shutdown.start();
      shutdown.join(TimeUnit.SECONDS.toMillis(5));
      assertFalse(shutdown.isAlive());
      assertEquals(interrupt, failedShutdown.get(1, TimeUnit.SECONDS).booleanValue());
      assertEquals(1, pendingCount());
      assertFalse(claimed.isDone());
      assertFalse(service.claimAttachments(player, UUID.randomUUID()).success());
    } finally {
      release.countDown();
      owner.join(TimeUnit.SECONDS.toMillis(5));
      shutdown.join(TimeUnit.SECONDS.toMillis(5));
    }

    assertFalse(owner.isAlive());
    assertTrue(claimed.join().success());
    assertEquals(0, pendingCount());
    assertStoppedPromptly();
  }

  private PlayerInventory inventoryWithAttachment() {
    PlayerInventory inventory = mock(PlayerInventory.class);
    Mail mail = mock(Mail.class);
    dev.starcore.starcore.social.mail.MailAttachment attachment =
        mock(dev.starcore.starcore.social.mail.MailAttachment.class);
    ItemStack item = mock(ItemStack.class);
    when(item.getType()).thenReturn(Material.DIAMOND);
    when(item.getAmount()).thenReturn(1);
    when(item.getMaxStackSize()).thenReturn(64);
    when(item.clone()).thenReturn(item);
    when(attachment.deserializeItem()).thenReturn(item);
    when(mail.getId()).thenReturn(mailId);
    when(mail.hasAttachments()).thenReturn(true);
    when(mail.getAttachments()).thenReturn(List.of(attachment));
    when(mail.getSenderId()).thenReturn(UUID.randomUUID());
    when(mail.getSenderName()).thenReturn("sender");
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.getInventory()).thenReturn(inventory);
    when(inventory.getStorageContents()).thenReturn(new ItemStack[36]);
    when(mailService.getPlayerMails(playerId)).thenReturn(List.of(mail));
    when(mailService.confirmClaimed(playerId, mailId)).thenReturn(true);
    return inventory;
  }

  private int pendingCount() throws Exception {
    Field field = MailAttachmentServiceImpl.class.getDeclaredField("pendingEntityOperations");
    field.setAccessible(true);
    return ((Set<?>) field.get(service)).size();
  }

  private void assertStoppedPromptly() {
    assertTimeout(Duration.ofSeconds(1), service::shutdown);
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(5, TimeUnit.SECONDS))
        throw new IllegalStateException("owner release timed out");
    } catch (InterruptedException failure) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(failure);
    }
  }

  private static boolean awaitWaiting(Thread thread) {
    long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2);
    while (System.nanoTime() < deadline && thread.isAlive()) {
      if (thread.getState() == Thread.State.TIMED_WAITING) return true;
      Thread.onSpinWait();
    }
    return false;
  }
}
