package dev.starcore.starcore.social.mail.gui;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import dev.starcore.starcore.social.mail.MailService;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class MailGuiListenerStateLifecycleTest {

  @Test
  void closingOldWindowKeepsReplacementMailWindowState() throws Exception {
    MailGuiListener listener = new MailGuiListener(mock(MailService.class));
    UUID playerId = UUID.randomUUID();
    Map<UUID, MailGuiListener.GuiType> states = states(listener);
    states.put(playerId, MailGuiListener.GuiType.MAIL_LIST);

    listener.clearGuiTypeAfterCloseIfStillCurrent(
        playerId, MailGuiListener.GuiType.MAIL_SEND, mock(MailListGui.class));

    assertEquals(MailGuiListener.GuiType.MAIL_LIST, states.get(playerId));
  }

  @Test
  void closingOldWindowKeepsChatInputState() throws Exception {
    MailGuiListener listener = new MailGuiListener(mock(MailService.class));
    UUID playerId = UUID.randomUUID();
    Map<UUID, MailGuiListener.GuiType> states = states(listener);
    states.put(playerId, MailGuiListener.GuiType.MAIL_INPUT);

    listener.clearGuiTypeAfterCloseIfStillCurrent(
        playerId, MailGuiListener.GuiType.MAIL_SEND, null);

    assertEquals(MailGuiListener.GuiType.MAIL_INPUT, states.get(playerId));
  }

  @Test
  void closingLastMailWindowRemovesItsState() throws Exception {
    MailGuiListener listener = new MailGuiListener(mock(MailService.class));
    UUID playerId = UUID.randomUUID();
    Map<UUID, MailGuiListener.GuiType> states = states(listener);
    states.put(playerId, MailGuiListener.GuiType.MAIL_DETAIL);

    listener.clearGuiTypeAfterCloseIfStillCurrent(
        playerId, MailGuiListener.GuiType.MAIL_DETAIL, null);

    assertFalse(states.containsKey(playerId));
    assertTrue(states.isEmpty());
  }

  @SuppressWarnings("unchecked")
  private static Map<UUID, MailGuiListener.GuiType> states(MailGuiListener listener)
      throws Exception {
    Field field = MailGuiListener.class.getDeclaredField("playerGuiType");
    field.setAccessible(true);
    return (Map<UUID, MailGuiListener.GuiType>) field.get(listener);
  }
}
