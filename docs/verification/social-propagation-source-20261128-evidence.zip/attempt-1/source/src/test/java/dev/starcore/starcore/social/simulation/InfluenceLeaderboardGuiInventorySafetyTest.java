package dev.starcore.starcore.social.simulation;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.gui.StarCoreMenuHolder;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.junit.jupiter.api.Test;

class InfluenceLeaderboardGuiInventorySafetyTest {

  @Test
  void foreignInventoryWithMatchingTitleCannotRouteMenuAction() {
    InfluenceLeaderboardGui gui = gui();
    Player player = mock(Player.class);
    Inventory foreign = inventory(new StarCoreMenuHolder(), 27);
    InventoryClickEvent click = click(foreign, foreign, player, 26, ClickType.LEFT, "§6§l影响力排行榜");

    gui.onInventoryClick(click);

    verify(click, never()).setCancelled(true);
    verify(player, never()).closeInventory();
  }

  @Test
  void bottomInventoryClickIsCancelledWithoutRoutingMenuAction() {
    InfluenceLeaderboardGui gui = gui();
    Player player = mock(Player.class);
    Inventory top = inventory(new InfluenceLeaderboardGui.MenuHolder(gui), 27);
    InventoryClickEvent click =
        click(top, mock(Inventory.class), player, 62, ClickType.LEFT, "§6§l影响力排行榜");

    gui.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player, never()).closeInventory();
  }

  @Test
  void primaryTopClickStillRoutesCloseAction() {
    InfluenceLeaderboardGui gui = gui();
    Player player = mock(Player.class);
    Inventory top = inventory(new InfluenceLeaderboardGui.MenuHolder(gui), 27);
    InventoryClickEvent click = click(top, top, player, 26, ClickType.LEFT, "§6§l影响力排行榜");

    gui.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player).closeInventory();
  }

  private static InfluenceLeaderboardGui gui() {
    Plugin plugin = mock(Plugin.class);
    Server server = mock(Server.class);
    PluginManager pluginManager = mock(PluginManager.class);
    when(plugin.getServer()).thenReturn(server);
    when(server.getPluginManager()).thenReturn(pluginManager);
    return new InfluenceLeaderboardGui(plugin, mock(InfluenceLeaderboardService.class));
  }

  private static Inventory inventory(InventoryHolder holder, int size) {
    Inventory inventory = mock(Inventory.class);
    when(inventory.getHolder()).thenReturn(holder);
    when(inventory.getSize()).thenReturn(size);
    return inventory;
  }

  private static InventoryClickEvent click(
      Inventory top,
      Inventory clicked,
      Player player,
      int rawSlot,
      ClickType clickType,
      String title) {
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    when(view.getTitle()).thenReturn(title);
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    when(event.getView()).thenReturn(view);
    when(event.getWhoClicked()).thenReturn(player);
    when(event.getClickedInventory()).thenReturn(clicked);
    when(event.getRawSlot()).thenReturn(rawSlot);
    when(event.getClick()).thenReturn(clickType);
    return event;
  }
}
