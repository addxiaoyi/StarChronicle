package dev.starcore.starcore.social.guild;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("GuildRole Tests")
class GuildRoleTest {

  @Test
  @DisplayName("display names are correct")
  void shouldHaveDisplayNames() {
    assertThat(GuildRole.LEADER.getDisplayName()).isEqualTo("会长");
    assertThat(GuildRole.OFFICER.getDisplayName()).isEqualTo("管理");
    assertThat(GuildRole.MEMBER.getDisplayName()).isEqualTo("成员");
  }

  @Test
  @DisplayName("priorities are correctly ordered")
  void shouldHavePriorities() {
    assertThat(GuildRole.LEADER.getPriority()).isEqualTo(3);
    assertThat(GuildRole.OFFICER.getPriority()).isEqualTo(2);
    assertThat(GuildRole.MEMBER.getPriority()).isEqualTo(1);
  }

  @Test
  @DisplayName("hasHigherPriorityThan compares priorities")
  void shouldComparePriorities() {
    assertThat(GuildRole.LEADER.hasHigherPriorityThan(GuildRole.OFFICER)).isTrue();
    assertThat(GuildRole.LEADER.hasHigherPriorityThan(GuildRole.MEMBER)).isTrue();
    assertThat(GuildRole.OFFICER.hasHigherPriorityThan(GuildRole.MEMBER)).isTrue();
    assertThat(GuildRole.MEMBER.hasHigherPriorityThan(GuildRole.LEADER)).isFalse();
    assertThat(GuildRole.LEADER.hasHigherPriorityThan(GuildRole.LEADER)).isFalse();
  }
}
