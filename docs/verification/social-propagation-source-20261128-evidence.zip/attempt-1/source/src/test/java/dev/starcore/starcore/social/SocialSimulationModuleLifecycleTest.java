package dev.starcore.starcore.social;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.social.simulation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import org.bukkit.Server;
import org.bukkit.command.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class SocialSimulationModuleLifecycleTest {
  @Test
  void failedCheckpointStillClosesIngressCancelsTimersAndUnregistersServices() throws Exception {
    var module = new SocialSimulationModule();
    var gossip = mock(GossipService.class);
    var news = mock(NewsPropagationService.class);
    var reputation = mock(ReputationService.class);
    var listener = mock(SocialSimulationListener.class);
    var registry = mock(ServiceRegistry.class);
    var context = mock(StarCoreContext.class);
    when(context.serviceRegistry()).thenReturn(registry);
    set(module, "gossipService", gossip);
    set(module, "newsService", news);
    set(module, "reputationService", reputation);
    set(module, "listener", listener);
    doThrow(new IllegalStateException("disk rejected")).when(gossip).saveData();
    assertThrows(IllegalStateException.class, () -> module.disable(context));
    var order = inOrder(gossip, listener, news, reputation, registry);
    order.verify(gossip).close();
    order.verify(listener).unregister();
    order.verify(news).stop();
    order.verify(gossip).saveData();
    order.verify(reputation).shutdown();
    order.verify(registry).unregister(ReputationService.class, reputation);
    order.verify(registry).unregister(GossipService.class, gossip);
    order.verify(registry).unregister(NewsPropagationService.class, news);
    assertNull(module.gossipService());
    assertNull(module.newsService());
  }

  @Test
  void retainedCommandAndTabCompleterAreInvalidAfterDisableEvenIfRestorationFails()
      throws Exception {
    var module = new SocialSimulationModule();
    var plugin = mock(JavaPlugin.class);
    var server = mock(Server.class);
    var command = mock(PluginCommand.class);
    var executor = mock(CommandExecutor.class);
    var completer = mock(TabCompleter.class);
    var sender = mock(CommandSender.class);
    var previous = mock(CommandExecutor.class);
    var previousTab = mock(TabCompleter.class);
    AtomicReference<CommandExecutor> installed = new AtomicReference<>(previous);
    AtomicReference<TabCompleter> tab = new AtomicReference<>(previousTab);
    when(plugin.getServer()).thenReturn(server);
    when(server.getPluginCommand("socialsim")).thenReturn(command);
    when(command.getExecutor()).thenAnswer(ignored -> installed.get());
    when(command.getTabCompleter()).thenAnswer(ignored -> tab.get());
    doAnswer(
            inv -> {
              installed.set(inv.getArgument(0));
              return null;
            })
        .when(command)
        .setExecutor(any());
    doAnswer(
            inv -> {
              tab.set(inv.getArgument(0));
              return null;
            })
        .when(command)
        .setTabCompleter(any());
    set(module, "plugin", plugin);
    set(module, "running", true);
    Method bind =
        SocialSimulationModule.class.getDeclaredMethod(
            "bindCommand", String.class, CommandExecutor.class, TabCompleter.class);
    bind.setAccessible(true);
    bind.invoke(module, "socialsim", executor, completer);
    CommandExecutor old = installed.get();
    TabCompleter oldTab = tab.get();
    when(executor.onCommand(any(), any(), anyString(), any())).thenReturn(true);
    old.onCommand(sender, command, "socialsim", new String[0]);
    verify(executor).onCommand(any(), any(), anyString(), any());
    clearInvocations(executor, completer);
    doThrow(new IllegalStateException("restore rejected"))
        .when(command)
        .setExecutor(same(previous));
    var context = mock(StarCoreContext.class);
    when(context.serviceRegistry()).thenReturn(mock(ServiceRegistry.class));
    assertThrows(IllegalStateException.class, () -> module.disable(context));
    assertSame(previousTab, tab.get());
    old.onCommand(sender, command, "socialsim", new String[0]);
    assertEquals(List.of(), oldTab.onTabComplete(sender, command, "socialsim", new String[0]));
    verifyNoInteractions(executor, completer);
    set(module, "running", true);
    old.onCommand(sender, command, "socialsim", new String[0]);
    verifyNoInteractions(executor);
  }

  private static void set(Object target, String name, Object value) throws Exception {
    Field field = target.getClass().getDeclaredField(name);
    field.setAccessible(true);
    field.set(target, value);
  }
}
