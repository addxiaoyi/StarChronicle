package dev.starcore.starcore.social.mail;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("MailAttachment Tests")
class MailAttachmentTest {

  @Test
  @DisplayName("constructor initializes fields")
  void shouldInitialize() {
    MailAttachment a = new MailAttachment("diamond", 5, "material:DIAMOND,amount:5");
    assertThat(a.getItemId()).isEqualTo("diamond");
    assertThat(a.getAmount()).isEqualTo(5);
    assertThat(a.getSerializedItem()).isEqualTo("material:DIAMOND,amount:5");
  }

  @Test
  @DisplayName("toString returns human readable form")
  void shouldFormatToString() {
    MailAttachment a = new MailAttachment("gold_ingot", 3, "material:GOLD_INGOT,amount:3");
    assertThat(a.toString()).isEqualTo("gold_ingot x3");
  }
}
