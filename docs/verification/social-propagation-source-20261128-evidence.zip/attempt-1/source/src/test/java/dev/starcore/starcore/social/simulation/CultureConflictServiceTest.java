package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.social.simulation.CultureService.CultureCategory;
import dev.starcore.starcore.social.simulation.CultureService.CultureLevel;
import dev.starcore.starcore.social.simulation.CultureService.CultureTrait;
import dev.starcore.starcore.social.simulation.CultureConflictService.ConflictStatistics;
import dev.starcore.starcore.social.simulation.CultureConflictService.CultureConflictData;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * CultureConflictService 定向契约测试。
 *
 * <p>覆盖冲突检测的紧张度来源（特质矩阵、文化差距、文化等级悬殊）、封顶规则、规范化键、贸易/外交惩罚、战争风险、
 * 升级与和解、统计与清理，以及 {@link CultureConflictData} 的纯数据变换。全部在纯 JVM 下运行，不依赖服务端实例。
 */
class CultureConflictServiceTest {

  private JavaPlugin plugin;
  private CultureService cultureService;
  private CultureConflictService service;

  private NationId nationA;
  private NationId nationB;

  @BeforeEach
  void setUp() {
    plugin = mock(JavaPlugin.class);
    cultureService = mock(CultureService.class);
    service = new CultureConflictService(plugin, cultureService);
    nationA = NationId.random();
    nationB = NationId.random();

    // 默认：无特质、无文化点数、最低等级 —— 单测各自覆盖需要变化的维度
    when(cultureService.getTraits(nationA)).thenReturn(List.of());
    when(cultureService.getTraits(nationB)).thenReturn(List.of());
    when(cultureService.getCulturePoints(nationA)).thenReturn(0);
    when(cultureService.getCulturePoints(nationB)).thenReturn(0);
    when(cultureService.getLevel(nationA)).thenReturn(CultureLevel.BARBARIC);
    when(cultureService.getLevel(nationB)).thenReturn(CultureLevel.BARBARIC);
  }

  private CultureTrait trait(String name, CultureCategory category) {
    return new CultureTrait(name, name, name, category, 1, Set.of());
  }

  // ==================== 冲突检测 ====================

  @Test
  @DisplayName("两国均无文化特质时检测结果为 null")
  void detectConflictReturnsNullWhenBothNationsHaveNoTraits() {
    assertThat(service.detectConflict(nationA, nationB)).isNull();
  }

  @Test
  @DisplayName("军事 vs 宗教特质产生 30 点紧张度并标记为中等冲突")
  void detectConflictAggregatesTraitMatrixWeight() {
    when(cultureService.getTraits(nationA))
        .thenReturn(List.of(trait("军团传统", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(List.of(trait("圣典信仰", CultureCategory.RELIGION)));

    CultureConflictData conflict = service.detectConflict(nationA, nationB);

    assertThat(conflict).isNotNull();
    assertThat(conflict.tension()).isEqualTo(30);
    assertThat(conflict.maxTension()).isEqualTo(30);
    assertThat(conflict.level()).isEqualTo(ConflictLevel.MODERATE);
    assertThat(conflict.conflictingCategories())
        .containsExactlyInAnyOrder(CultureCategory.MILITARY, CultureCategory.RELIGION);
    assertThat(conflict.conflictReasons()).anyMatch(r -> r.contains("权重: 30"));
    assertThat(conflict.isResolved()).isFalse();
    assertThat(conflict.isActive()).isTrue();
    assertThat(conflict.getTensionPercent()).isEqualTo(0.30);
  }

  @Test
  @DisplayName("相同文化类别不产生冲突权重，检测结果为 null")
  void detectConflictReturnsNullForNonConflictingSameCategory() {
    when(cultureService.getTraits(nationA))
        .thenReturn(List.of(trait("军阵", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(List.of(trait("铁骑", CultureCategory.MILITARY)));

    assertThat(service.detectConflict(nationA, nationB)).isNull();
  }

  @Test
  @DisplayName("文化点数差距超过 1000 时额外增加 10 点紧张度")
  void detectConflictAddsTensionForLargeCultureGap() {
    when(cultureService.getTraits(nationA))
        .thenReturn(List.of(trait("军阵", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(List.of(trait("铁骑", CultureCategory.MILITARY)));
    when(cultureService.getCulturePoints(nationA)).thenReturn(0);
    when(cultureService.getCulturePoints(nationB)).thenReturn(1500);

    CultureConflictData conflict = service.detectConflict(nationA, nationB);

    assertThat(conflict).isNotNull();
    assertThat(conflict.tension()).isEqualTo(10);
    assertThat(conflict.level()).isEqualTo(ConflictLevel.MINOR);
    assertThat(conflict.conflictReasons()).anyMatch(r -> r.contains("文化差距过大"));
    assertThat(conflict.conflictingCategories()).isEmpty();
  }

  @Test
  @DisplayName("文化等级相差 3 级及以上时额外增加 15 点紧张度")
  void detectConflictAddsTensionForWideLevelGap() {
    when(cultureService.getTraits(nationA))
        .thenReturn(List.of(trait("军阵", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(List.of(trait("铁骑", CultureCategory.MILITARY)));
    when(cultureService.getLevel(nationA)).thenReturn(CultureLevel.BARBARIC);
    when(cultureService.getLevel(nationB)).thenReturn(CultureLevel.FLOURISHING);

    CultureConflictData conflict = service.detectConflict(nationA, nationB);

    assertThat(conflict).isNotNull();
    assertThat(conflict.tension()).isEqualTo(15);
    assertThat(conflict.conflictReasons()).anyMatch(r -> r.contains("文化发展水平悬殊"));
  }

  @Test
  @DisplayName("多组冲突特质叠加后紧张度封顶 100 并判定为严重冲突")
  void detectConflictCapsTensionAtOneHundred() {
    when(cultureService.getTraits(nationA))
        .thenReturn(
            List.of(
                trait("军团甲", CultureCategory.MILITARY),
                trait("军团乙", CultureCategory.MILITARY),
                trait("军团丙", CultureCategory.MILITARY),
                trait("军团丁", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(
            List.of(
                trait("圣典甲", CultureCategory.RELIGION),
                trait("圣典乙", CultureCategory.RELIGION),
                trait("圣典丙", CultureCategory.RELIGION),
                trait("圣典丁", CultureCategory.RELIGION)));

    CultureConflictData conflict = service.detectConflict(nationA, nationB);

    assertThat(conflict).isNotNull();
    // 16 组 × 30 = 480，封顶 100
    assertThat(conflict.tension()).isEqualTo(100);
    assertThat(conflict.level()).isEqualTo(ConflictLevel.SEVERE);
  }

  @Test
  @DisplayName("detectConflict 本身不写入冲突缓存")
  void detectConflictDoesNotPersistIntoCache() {
    when(cultureService.getTraits(nationA))
        .thenReturn(List.of(trait("军团传统", CultureCategory.MILITARY)));
    when(cultureService.getTraits(nationB))
        .thenReturn(List.of(trait("圣典信仰", CultureCategory.RELIGION)));

    service.detectConflict(nationA, nationB);

    assertThat(service.hasConflict(nationA, nationB)).isFalse();
    assertThat(service.getAllConflicts()).isEmpty();
    assertThat(service.getTradePenalty(nationA, nationB)).isEqualTo(1.0);
    assertThat(service.getRelationPenalty(nationA, nationB)).isEqualTo(0.0);
    assertThat(service.getFusionProgress(nationA, nationB)).isEqualTo(0.0);
    assertThat(service.canConflictTriggerWar(nationA, nationB)).isFalse();
  }

  // ==================== 规范化与查询 ====================

  @Test
  @DisplayName("冲突键规范化：正反顺序查询命中同一条记录")
  void conflictKeyIsCanonicalizedInBothDirections() {
    service.forceEscalate(nationA, nationB, 20, "边境摩擦");

    Optional<CultureConflictData> forward = service.getConflict(nationA, nationB);
    Optional<CultureConflictData> backward = service.getConflict(nationB, nationA);

    assertThat(forward).isPresent();
    assertThat(backward).isPresent();
    assertThat(forward.get().conflictId()).isEqualTo(backward.get().conflictId());
    assertThat(service.hasConflict(nationA, nationB)).isTrue();
    assertThat(service.hasConflict(nationB, nationA)).isTrue();
  }

  @Test
  @DisplayName("getActiveConflicts 只返回包含该国且活跃的冲突")
  void getActiveConflictsFiltersByNationAndActivity() {
    NationId nationC = NationId.random();
    when(cultureService.getTraits(nationC)).thenReturn(List.of());
    service.forceEscalate(nationA, nationB, 20, "边境摩擦");
    service.forceEscalate(nationB, nationC, 10, "商路争端");

    List<CultureConflictData> forA = service.getActiveConflicts(nationA);
    List<CultureConflictData> forB = service.getActiveConflicts(nationB);
    List<CultureConflictData> forC = service.getActiveConflicts(nationC);

    assertThat(forA).hasSize(1);
    assertThat(forB).hasSize(2);
    assertThat(forC).hasSize(1);
    assertThat(forA.get(0).involves(nationA)).isTrue();
    assertThat(forA.get(0).getOtherParty(nationA)).isEqualTo(nationB);
  }

  // ==================== 影响计算 ====================

  @Test
  @DisplayName("中等冲突同时施加贸易与外交惩罚")
  void penaltiesAppliedForModerateConflict() {
    // 无特质 → forceEscalate 创建 MINOR(10)，再升级 20 → 30 → MODERATE
    service.forceEscalate(nationA, nationB, 20, "边境摩擦");

    CultureConflictData conflict = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(conflict.level()).isEqualTo(ConflictLevel.MODERATE);
    assertThat(service.getTradePenalty(nationA, nationB)).isEqualTo(1.0 + (-0.20));
    assertThat(service.getRelationPenalty(nationA, nationB)).isEqualTo(-0.20);
  }

  @Test
  @DisplayName("轻微冲突只影响贸易，不施加外交惩罚")
  void relationPenaltySkippedForMinorConflict() {
    service.forceEscalate(nationA, nationB, 0, "轻微摩擦");

    CultureConflictData conflict = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(conflict.level()).isEqualTo(ConflictLevel.MINOR);
    assertThat(service.getTradePenalty(nationA, nationB)).isEqualTo(1.0 + (-0.10));
    assertThat(service.getRelationPenalty(nationA, nationB)).isEqualTo(0.0);
  }

  @Test
  @DisplayName("严重且紧张度≥50 的冲突可触发战争，并计入战争风险统计")
  void severeConflictTriggersWarRisk() {
    service.forceEscalate(nationA, nationB, 60, "宗教战争");

    CultureConflictData conflict = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(conflict.level()).isEqualTo(ConflictLevel.SEVERE);
    assertThat(conflict.tension()).isGreaterThanOrEqualTo(50);
    assertThat(conflict.canTriggerWar()).isTrue();
    assertThat(service.canConflictTriggerWar(nationA, nationB)).isTrue();
    assertThat(service.countWarRisks()).isEqualTo(1);
  }

  // ==================== 升级 / 和解 / 交流 ====================

  @Test
  @DisplayName("forceEscalate 在无既有冲突时人工建档并记录事件原因")
  void forceEscalateCreatesConflictWhenAbsent() {
    assertThat(service.getConflict(nationA, nationB)).isEmpty();

    service.forceEscalate(nationA, nationB, 5, "使节遇刺");

    CultureConflictData conflict = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(conflict.tension()).isEqualTo(15); // MINOR 阈值 10 + 5
    assertThat(conflict.conflictReasons()).anyMatch(r -> r.contains("事件触发: 使节遇刺"));
    assertThat(conflict.conflictReasons()).anyMatch(r -> r.contains("外部事件: 使节遇刺"));
  }

  @Test
  @DisplayName("forceEscalate 升级既有冲突时保留原类别与起始时间")
  void forceEscalatePreservesOriginalMetadata() {
    service.forceEscalate(nationA, nationB, 5, "第一次");
    CultureConflictData first = service.getConflict(nationA, nationB).orElseThrow();

    service.forceEscalate(nationA, nationB, 50, "第二次");
    CultureConflictData second = service.getConflict(nationA, nationB).orElseThrow();

    assertThat(second.conflictId()).isEqualTo(first.conflictId());
    assertThat(second.startTime()).isEqualTo(first.startTime());
    assertThat(second.tension()).isEqualTo(65);
    assertThat(second.maxTension()).isEqualTo(65);
    assertThat(second.level()).isEqualTo(ConflictLevel.SEVERE);
  }

  @Test
  @DisplayName("无冲突时和解与文化交流直接返回 false")
  void reconciliationAndExchangeRequireActiveConflict() {
    assertThat(service.attemptReconciliation(nationA, nationB, null)).isFalse();
    assertThat(service.promoteCulturalExchange(nationA, nationB, 100)).isFalse();
    verify(cultureService, times(0)).addCulturePoints(anyNation(), anyInt(), anyCategory());
  }

  @Test
  @DisplayName("文化交流按 10:1 降低紧张度并向双方各注入一半文化点数")
  void culturalExchangeReducesTensionAndSharesPoints() {
    service.forceEscalate(nationA, nationB, 40, "商路争端"); // 10 + 40 = 50
    int before = service.getConflict(nationA, nationB).orElseThrow().tension();

    boolean resolved = service.promoteCulturalExchange(nationA, nationB, 100);

    CultureConflictData after = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(after.tension()).isEqualTo(before - 10);
    assertThat(resolved).isFalse(); // 仍有余量，未彻底和解
    verify(cultureService).addCulturePoints(nationA, 50, CultureCategory.TRADE);
    verify(cultureService).addCulturePoints(nationB, 50, CultureCategory.TRADE);
  }

  @Test
  @DisplayName("文化交流足以清零时冲突被判定为已解决")
  void culturalExchangeResolvesConflictWhenTensionReachesZero() {
    service.forceEscalate(nationA, nationB, 0, "轻微摩擦"); // 紧张度 10

    boolean resolved = service.promoteCulturalExchange(nationA, nationB, 200);

    CultureConflictData after = service.getConflict(nationA, nationB).orElseThrow();
    assertThat(after.tension()).isZero();
    assertThat(after.isResolved()).isTrue();
    assertThat(after.isActive()).isFalse();
    assertThat(resolved).isTrue();
    assertThat(service.hasConflict(nationA, nationB)).isFalse();
    assertThat(service.getTradePenalty(nationA, nationB)).isEqualTo(1.0);
  }

  @Test
  @DisplayName("和解尝试不会破坏冲突一致性")
  void reconciliationKeepsConflictConsistent() {
    service.forceEscalate(nationA, nationB, 20, "边境摩擦");
    NationId mediator = NationId.random();
    when(cultureService.getLevel(mediator)).thenReturn(CultureLevel.GOLDEN_AGE);

    boolean result = service.attemptReconciliation(nationA, nationB, mediator);

    CultureConflictData after = service.getConflict(nationA, nationB).orElseThrow();
    // 结果受随机阈值影响，但状态必须始终自洽
    assertThat(after.tension()).isBetween(0, 100);
    assertThat(after.reconciliationAttempts()).isGreaterThanOrEqualTo(0);
    if (result) {
      assertThat(after.reconciliationAttempts()).isGreaterThan(0);
      assertThat(after.tension()).isLessThan(30);
    } else if (after.reconciliationAttempts() > 0) {
      // 部分和解已降低紧张度，但服务仅在完全解决时返回 true。
      assertThat(after.tension()).isLessThan(30);
    } else {
      assertThat(after.tension()).isEqualTo(30);
    }
  }

  // ==================== 融合与统计 ====================

  @Test
  @DisplayName("融合进度随持续时长与低紧张度提升")
  void fusionProgressCombinesDurationAndTension() {
    service.forceEscalate(nationA, nationB, 20, "边境摩擦"); // 紧张度 30

    double progress = service.getFusionProgress(nationA, nationB);

    // durationFactor≈0，tensionFactor=0.7 → ≈0.35
    assertThat(progress).isBetween(0.30, 0.40);
  }

  @Test
  @DisplayName("统计按等级分类统计活跃冲突")
  void statisticsClassifiesActiveConflictsByLevel() {
    NationId nationC = NationId.random();
    NationId nationD = NationId.random();
    service.forceEscalate(nationA, nationB, 0, "轻微"); // MINOR 10
    service.forceEscalate(nationA, nationC, 20, "中等"); // MODERATE 30
    service.forceEscalate(nationB, nationD, 60, "严重"); // SEVERE 70

    ConflictStatistics stats = service.getStatistics();

    assertThat(stats.totalConflicts()).isEqualTo(3);
    assertThat(stats.activeConflicts()).isEqualTo(3);
    assertThat(stats.minorConflicts()).isEqualTo(1);
    assertThat(stats.moderateConflicts()).isEqualTo(1);
    assertThat(stats.severeConflicts()).isEqualTo(1);
  }

  @Test
  @DisplayName("clearResolvedConflicts 只清理已解决记录")
  void clearResolvedConflictsKeepsActiveEntries() {
    NationId nationC = NationId.random();
    service.forceEscalate(nationA, nationB, 0, "轻微摩擦"); // 可被清零
    service.forceEscalate(nationA, nationC, 60, "严重冲突"); // 保持活跃
    service.promoteCulturalExchange(nationA, nationB, 200); // 清理第一条

    service.clearResolvedConflicts();

    assertThat(service.getConflict(nationA, nationB)).isEmpty();
    assertThat(service.getConflict(nationA, nationC)).isPresent();
    assertThat(service.getAllConflicts()).hasSize(1);
  }

  // ==================== CultureConflictData 纯数据契约 ====================

  @Test
  @DisplayName("escalate 封顶 100 并抬升 maxTension")
  void escalateCapsTensionAndRaisesMax() {
    CultureConflictData base = data(30, 30);

    CultureConflictData escalated = base.escalate(500);

    assertThat(escalated.tension()).isEqualTo(100);
    assertThat(escalated.maxTension()).isEqualTo(100);
    assertThat(escalated.level()).isEqualTo(ConflictLevel.SEVERE);
    assertThat(escalated.isResolved()).isFalse();
    assertThat(escalated.conflictReasons()).anyMatch(r -> r.contains("紧张度升级: +500"));
  }

  @Test
  @DisplayName("reconcile 下限为 0，清零即标记已解决并累计尝试次数")
  void reconcileFloorsAtZeroAndMarksResolved() {
    CultureConflictData base = data(15, 30);

    CultureConflictData partial = base.reconcile(5);
    assertThat(partial.tension()).isEqualTo(10);
    assertThat(partial.isResolved()).isFalse();
    assertThat(partial.reconciliationAttempts()).isEqualTo(base.reconciliationAttempts() + 1);

    CultureConflictData resolved = base.reconcile(999);
    assertThat(resolved.tension()).isZero();
    assertThat(resolved.level()).isEqualTo(ConflictLevel.NONE);
    assertThat(resolved.isResolved()).isTrue();
    assertThat(resolved.isActive()).isFalse();
  }

  @Test
  @DisplayName("resolveAsFusion 清空类别并标记已解决")
  void resolveAsFusionClearsCategories() {
    CultureConflictData fused = data(40, 60).resolveAsFusion();

    assertThat(fused.tension()).isZero();
    assertThat(fused.level()).isEqualTo(ConflictLevel.NONE);
    assertThat(fused.isResolved()).isTrue();
    assertThat(fused.isActive()).isFalse();
    assertThat(fused.conflictingCategories()).isEmpty();
    assertThat(fused.conflictReasons()).anyMatch(r -> r.contains("文化融合完成"));
  }

  @Test
  @DisplayName("getOtherParty 对无关国家抛异常")
  void getOtherPartyRejectsUnrelatedNation() {
    CultureConflictData conflict = data(30, 30);

    assertThatThrownBy(() -> conflict.getOtherParty(NationId.random()))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessageContaining("Nation not part of this conflict");
  }

  @Test
  @DisplayName("canTriggerWar 由 SEVERE 阈值(60)决定，tension≥50 条件实际被其覆盖")
  void canTriggerWarRequiresSeverityAndTension() {
    // ConflictLevel.fromTension: >=60 才是 SEVERE，因此 50/59 仍是 MODERATE
    assertThat(data(60, 60).canTriggerWar()).isTrue();
    assertThat(data(59, 60).canTriggerWar()).isFalse();
    assertThat(data(50, 50).canTriggerWar()).isFalse();
    assertThat(data(30, 30).canTriggerWar()).isFalse();
  }

  private CultureConflictData data(int tension, int maxTension) {
    return new CultureConflictData(
        UUID.randomUUID(),
        nationA,
        nationB,
        ConflictLevel.fromTension(tension),
        tension,
        maxTension,
        List.of("初始原因"),
        List.of(CultureCategory.MILITARY),
        java.time.Instant.now(),
        java.time.Instant.now(),
        0,
        false);
  }

  private static NationId anyNation() {
    return org.mockito.ArgumentMatchers.any(NationId.class);
  }

  private static CultureCategory anyCategory() {
    return org.mockito.ArgumentMatchers.any(CultureCategory.class);
  }
}
