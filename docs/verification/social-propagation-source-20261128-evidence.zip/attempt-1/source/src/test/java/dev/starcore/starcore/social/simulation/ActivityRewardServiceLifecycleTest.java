package dev.starcore.starcore.social.simulation;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.title.TitleService;
import java.nio.file.Path;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ActivityRewardServiceLifecycleTest {

  @TempDir Path tempDir;

  @Test
  void constructorDoesNotStartBackgroundParticipationLoad() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getDataFolder()).thenReturn(tempDir.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getLogger("ActivityRewardServiceLifecycleTest"));

    new ActivityRewardService(
        plugin,
        mock(ReputationService.class),
        mock(SocialInfluenceService.class),
        mock(EconomyService.class),
        mock(TitleService.class),
        mock(SocialActivityService.class));

    verify(plugin, never()).getServer();
  }
}
