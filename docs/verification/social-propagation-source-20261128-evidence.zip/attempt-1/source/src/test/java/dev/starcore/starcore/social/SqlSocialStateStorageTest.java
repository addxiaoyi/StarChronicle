package dev.starcore.starcore.social;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import java.sql.Connection;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import org.sqlite.SQLiteDataSource;

class SqlSocialStateStorageTest {

  @Test
  void repairsPartialSqliteSchemaAndPersistsCoreSocialState() throws Exception {
    String url =
        "jdbc:sqlite:file:social-storage-" + UUID.randomUUID() + "?mode=memory&cache=shared";
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl(url);

    try (Connection anchor = dataSource.getConnection()) {
      anchor
          .createStatement()
          .execute(
              """
              CREATE TABLE starcore_friend_relations (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  player_uuid TEXT NOT NULL,
                  friend_uuid TEXT NOT NULL,
                  created_at INTEGER NOT NULL,
                  UNIQUE(player_uuid, friend_uuid)
              )
              """);
      anchor
          .createStatement()
          .execute(
              """
              CREATE TABLE starcore_friend_requests (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  sender_uuid TEXT NOT NULL,
                  receiver_uuid TEXT NOT NULL,
                  created_at INTEGER NOT NULL,
                  expires_at INTEGER,
                  status TEXT
              )
              """);
      anchor
          .createStatement()
          .execute(
              """
              CREATE TABLE starcore_party_invites (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  party_uuid TEXT NOT NULL,
                  player_uuid TEXT NOT NULL,
                  invited_by TEXT NOT NULL,
                  created_at INTEGER NOT NULL,
                  expires_at INTEGER
              )
              """);
      anchor
          .createStatement()
          .execute(
              """
              CREATE TABLE starcore_player_status (
                  id INTEGER,
                  player_uuid TEXT PRIMARY KEY,
                  status_message TEXT,
                  last_online INTEGER,
                  online_status TEXT
              )
              """);

      DatabaseService database = mock(DatabaseService.class);
      when(database.dataSource()).thenReturn(java.util.Optional.of(dataSource));
      when(database.isRunning()).thenReturn(true);
      SqlSocialStateStorage storage =
          new SqlSocialStateStorage(database, Logger.getAnonymousLogger());

      storage.ensureTables();

      UUID target = UUID.randomUUID();
      UUID sender = UUID.randomUUID();
      storage.saveFriendRequest(target, sender, 10L);
      storage.saveFriendRequest(target, sender, 20L);
      Map<UUID, Set<UUID>> requests = new ConcurrentHashMap<>();
      storage.loadAllFriendRequests(requests);
      assertThat(requests).containsEntry(target, Set.of(sender));

      storage.savePartyInvite(sender, target, 30L);
      storage.savePartyInvite(sender, target, 40L);
      Map<UUID, Set<UUID>> invites = new ConcurrentHashMap<>();
      storage.loadAllPartyInvites(invites);
      assertThat(invites).containsEntry(target, Set.of(sender));
      Map<UUID, Map<UUID, Long>> inviteTimes = new ConcurrentHashMap<>();
      storage.loadAllPartyInvites(new ConcurrentHashMap<>(), inviteTimes);
      assertThat(inviteTimes).containsEntry(target, Map.of(sender, 40L));
      try (var statement = anchor.createStatement();
          var rows =
              statement.executeQuery("SELECT created_at, expires_at FROM starcore_party_invites")) {
        assertThat(rows.next()).isTrue();
        assertThat(rows.getLong("created_at")).isEqualTo(40L);
        assertThat(rows.getLong("expires_at")).isEqualTo(600_040L);
      }

      storage.savePlayerStatus(target, true);
      storage.savePlayerStatus(target, false);
      Map<UUID, Boolean> statuses = new ConcurrentHashMap<>();
      storage.loadAllPlayerStatus(statuses);
      assertThat(statuses).containsEntry(target, false);
    }
  }
}
