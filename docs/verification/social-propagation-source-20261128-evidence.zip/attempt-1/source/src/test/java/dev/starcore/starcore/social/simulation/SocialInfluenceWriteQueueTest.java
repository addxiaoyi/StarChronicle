package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;

class SocialInfluenceWriteQueueTest {
  @Test
  void writesRemainInSubmissionOrderWithOnlyOneIoDrain() throws Exception {
    UUID playerId = UUID.randomUUID();
    SocialInfluenceService influenceService = mock(SocialInfluenceService.class);
    List<String> sources = new CopyOnWriteArrayList<>();
    CountDownLatch firstWriteStarted = new CountDownLatch(1);
    CountDownLatch releaseFirstWrite = new CountDownLatch(1);
    doAnswer(
            invocation -> {
              String source = invocation.getArgument(2);
              sources.add(source);
              if (source.equals("first")) {
                firstWriteStarted.countDown();
                if (!releaseFirstWrite.await(2, TimeUnit.SECONDS)) {
                  throw new AssertionError("test did not release the first write");
                }
              }
              return null;
            })
        .when(influenceService)
        .addInfluence(any(UUID.class), anyInt(), anyString());

    ExecutorService ioExecutor = Executors.newFixedThreadPool(3);
    AtomicInteger submittedDrains = new AtomicInteger();
    SocialInfluenceWriteQueue queue =
        new SocialInfluenceWriteQueue(
            influenceService,
            task -> {
              submittedDrains.incrementAndGet();
              return CompletableFuture.runAsync(task, ioExecutor);
            },
            (ignoredPlayer, ignoredFailure) -> {});

    try {
      CompletableFuture<Void> first = queue.submit(playerId, 1, "first");
      assertThat(firstWriteStarted.await(1, TimeUnit.SECONDS)).isTrue();
      CompletableFuture<Void> second = queue.submit(playerId, 2, "second");

      assertThat(second).isNotCompleted();
      assertThat(submittedDrains.get()).isEqualTo(1);
      releaseFirstWrite.countDown();
      CompletableFuture.allOf(first, second).get(1, TimeUnit.SECONDS);

      assertThat(sources).containsExactly("first", "second");
      assertThat(submittedDrains.get()).isEqualTo(1);
    } finally {
      releaseFirstWrite.countDown();
      ioExecutor.shutdownNow();
      assertThat(ioExecutor.awaitTermination(1, TimeUnit.SECONDS)).isTrue();
    }
  }

  @Test
  void failedWriteDoesNotPreventLaterWritesAndIsReported() {
    UUID playerId = UUID.randomUUID();
    SocialInfluenceService influenceService = mock(SocialInfluenceService.class);
    List<String> sources = new CopyOnWriteArrayList<>();
    AtomicReference<Throwable> reportedFailure = new AtomicReference<>();
    doAnswer(
            invocation -> {
              String source = invocation.getArgument(2);
              if (source.equals("broken")) {
                throw new IllegalStateException("database unavailable");
              }
              sources.add(source);
              return null;
            })
        .when(influenceService)
        .addInfluence(any(UUID.class), anyInt(), anyString());
    AtomicReference<Runnable> scheduledDrain = new AtomicReference<>();
    CompletableFuture<Void> drainCompletion = new CompletableFuture<>();
    SocialInfluenceWriteQueue queue =
        new SocialInfluenceWriteQueue(
            influenceService,
            task -> {
              scheduledDrain.set(task);
              return drainCompletion;
            },
            (ignoredPlayer, failure) -> reportedFailure.set(failure));

    CompletableFuture<Void> failed = queue.submit(playerId, 1, "broken");
    CompletableFuture<Void> succeeded = queue.submit(playerId, 2, "healthy");
    scheduledDrain.get().run();
    drainCompletion.complete(null);

    assertThat(failed).isCompletedExceptionally();
    assertThat(succeeded).isCompleted();
    assertThat(sources).containsExactly("healthy");
    assertThat(reportedFailure.get()).hasMessage("database unavailable");
  }

  @Test
  void maintenanceTasksShareFifoOrderWithPlayerWrites() {
    UUID playerId = UUID.randomUUID();
    SocialInfluenceService influenceService = mock(SocialInfluenceService.class);
    List<String> operations = new CopyOnWriteArrayList<>();
    doAnswer(
            invocation -> {
              operations.add(invocation.getArgument(2));
              return null;
            })
        .when(influenceService)
        .addInfluence(any(UUID.class), anyInt(), anyString());

    AtomicReference<Runnable> scheduledDrain = new AtomicReference<>();
    CompletableFuture<Void> drainCompletion = new CompletableFuture<>();
    SocialInfluenceWriteQueue queue =
        new SocialInfluenceWriteQueue(
            influenceService,
            task -> {
              scheduledDrain.set(task);
              return drainCompletion;
            },
            (ignoredSubject, ignoredFailure) -> {});

    CompletableFuture<Void> before = queue.submit(playerId, 1, "before-decay");
    CompletableFuture<Void> decay = queue.submitMaintenance("decay", () -> operations.add("decay"));
    CompletableFuture<Void> after = queue.submit(playerId, 1, "after-decay");
    scheduledDrain.get().run();
    drainCompletion.complete(null);

    assertThat(CompletableFuture.allOf(before, decay, after)).isCompleted();
    assertThat(operations).containsExactly("before-decay", "decay", "after-decay");
  }
}
