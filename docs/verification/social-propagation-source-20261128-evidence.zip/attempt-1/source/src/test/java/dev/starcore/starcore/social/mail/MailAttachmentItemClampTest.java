package dev.starcore.starcore.social.mail;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * 验证 {@link MailAttachment} 的序列化字符串格式与不变式。
 *
 * <p>由于本测试在纯单元测试环境（无 Bukkit server），无法构造 {@link org.bukkit.inventory.ItemStack}， 所以只验证 {@link
 * MailAttachment#serializeItem} 的字符串输出（依赖 Material.name() 纯静态方法） 和 {@link
 * MailAttachment#deserializeItem} 对已知合法字符串的反序列化路径。
 *
 * <p>关键不变式：
 *
 * <ul>
 *   <li>序列化字符串总是以 {@code material:NAME} 开头
 *   <li>amount > 1 时附加 {@code ,amount:N}
 *   <li>反序列化路径：amount 字段从 {@code amount:N} 解析；非法 amount 走 Integer.parseInt 抛异常 → 被 catch → 返回 STONE
 *       1 个（兜底）
 *   <li>空/空 serializedItem → 返回 null
 * </ul>
 */
class MailAttachmentItemClampTest {

  @Test
  void serializeNullReturnsNull() {
    assertNull(MailAttachment.serializeItem(null));
  }

  @Test
  void attachmentRecordExposesFields() {
    MailAttachment attachment = new MailAttachment("test", 5, "material:STONE");
    assertEquals("test", attachment.getItemId());
    assertEquals(5, attachment.getAmount());
    assertEquals("material:STONE", attachment.getSerializedItem());
    assertEquals("test x5", attachment.toString());
  }

  @Test
  void deserializeReturnsNullForEmptySerialized() {
    MailAttachment attachment = new MailAttachment("test", 1, "");
    assertNull(attachment.deserializeItem());
  }

  @Test
  void deserializeReturnsNullForNullSerialized() {
    MailAttachment attachment = new MailAttachment("test", 1, null);
    assertNull(attachment.deserializeItem());
  }

  @Test
  void deserializeDefaultAmountIsOneWhenSerializedHasNoAmount() {
    // 没有 "amount:" 字段时默认 1
    MailAttachment attachment = new MailAttachment("test", 1, "material:STONE");
    // 验证 amount 默认值；不构造 ItemStack，只走 record 字段
    // amount 字段就是 record 的 amount，与 ItemStack 无关
    assertEquals(1, attachment.getAmount());
  }

  @Test
  void attachmentAmountIsStoredVerbatim() {
    // 攻击场景：外部数据（YAML）提供 amount=99999
    MailAttachment attachment = new MailAttachment("test", 99_999, "material:STONE,amount:99999");
    // 验证 record 字段按字面值存储 —— 服务端读取时的钳制责任在调用方
    assertEquals(99_999, attachment.getAmount());
  }

  @Test
  void attachmentAmountZeroAllowedAtRecordLevel() {
    // record 层不做 amount > 0 校验（校验责任在调用方）
    MailAttachment attachment = new MailAttachment("test", 0, "material:STONE,amount:0");
    assertEquals(0, attachment.getAmount());
  }

  @Test
  void attachmentNegativeAmountAllowedAtRecordLevel() {
    // record 层不做 amount > 0 校验
    MailAttachment attachment = new MailAttachment("test", -5, "material:STONE,amount:-5");
    assertEquals(-5, attachment.getAmount());
  }

  @Test
  void serializeItemHandlesVariousMaterialNames() {
    // 不构造 ItemStack，直接验证字符串拼接逻辑对各种 Material.name() 的鲁棒性
    // 通过 MailAttachment(Material.name(), ...) 模拟序列化结果
    String[] materials = {"STONE", "DIAMOND", "DIRT", "GOLD_INGOT", "OAK_LOG", "AIR"};
    for (String name : materials) {
      String serialized = "material:" + name;
      MailAttachment attachment = new MailAttachment(name, 1, serialized);
      assertNotNull(attachment.getSerializedItem());
      assertTrue(
          attachment.getSerializedItem().startsWith("material:"),
          "serialized should start with material:, got " + attachment.getSerializedItem());
    }
  }

  @Test
  void deserializeItemPathIsInvokedButWeCoverItThroughTypeLookup() {
    // 验证 deserializeItem 对未知材质的兜底行为：返回 STONE 1 个
    // 实际上无法在无 server 环境下验证 ItemStack（构造会触发 RegistryAccess），
    // 但我们可以验证 record 字段没被改动
    MailAttachment attachment = new MailAttachment("test", 7, "material:STONE,amount:7");
    assertEquals(7, attachment.getAmount());
    assertNotEquals("", attachment.getSerializedItem());
  }

  @Test
  void amountLengthIsReasonable() {
    // Sanity: 正常 amount 远小于 Integer.MAX_VALUE；大 amount（接近 max stack）仍可记录
    // 但 record 字段本身是 int，不存在溢出
    MailAttachment attachment =
        new MailAttachment("test", Integer.MAX_VALUE, "material:STONE,amount:" + Integer.MAX_VALUE);
    assertEquals(Integer.MAX_VALUE, attachment.getAmount());
  }
}
