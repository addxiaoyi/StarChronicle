package dev.starcore.starcore.social.chat;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.nio.file.Path;
import java.util.UUID;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PrivateMessageServiceLifecycleTest {

  @TempDir Path tempDir;

  @Test
  void shutdownWaitsForRunningSaveAndWritesFinalState() throws Exception {
    BlockingExecutor executor = new BlockingExecutor();
    PrivateMessageService service = new PrivateMessageService(() -> executor);
    service.initialize(plugin());

    UUID sender = UUID.randomUUID();
    UUID target = UUID.randomUUID();
    service.sendMessage(sender, target, "first");
    assertTrue(executor.awaitFirstStarted());
    service.sendMessage(sender, target, "second");

    Thread shutdownThread = new Thread(service::shutdown, "private-message-shutdown-test");
    shutdownThread.start();
    assertTrue(executor.awaitSecondSubmitted());
    assertTrue(shutdownThread.isAlive());

    executor.releaseFirst();
    shutdownThread.join(TimeUnit.SECONDS.toMillis(5));

    assertFalse(shutdownThread.isAlive());
    assertFalse(service.isInitialized());

    Path messagesPath = tempDir.resolve("social").resolve("private-messages.yml");
    YamlConfiguration messages = YamlConfiguration.loadConfiguration(messagesPath.toFile());
    assertEquals(2, messages.getList(sender.toString()).size());
    assertEquals(2, messages.getList(target.toString()).size());
  }

  @Test
  void serviceCanBeInitializedAgainAfterShutdown() {
    PrivateMessageService service = new PrivateMessageService();
    Plugin plugin = plugin();
    service.initialize(plugin);
    service.shutdown();

    service.initialize(plugin);

    assertTrue(service.isInitialized());
    service.shutdown();
  }

  private Plugin plugin() {
    Plugin plugin = mock(Plugin.class);
    when(plugin.getDataFolder()).thenReturn(tempDir.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getLogger("PrivateMessageServiceLifecycleTest"));
    return plugin;
  }

  private static final class BlockingExecutor extends AbstractExecutorService {
    private final ExecutorService delegate =
        Executors.newSingleThreadExecutor(
            runnable -> {
              Thread thread = new Thread(runnable, "private-message-blocking-test");
              thread.setDaemon(true);
              return thread;
            });
    private final AtomicInteger submissions = new AtomicInteger();
    private final CountDownLatch firstStarted = new CountDownLatch(1);
    private final CountDownLatch releaseFirst = new CountDownLatch(1);
    private final CountDownLatch secondSubmitted = new CountDownLatch(1);

    @Override
    public void execute(Runnable command) {
      int submission = submissions.incrementAndGet();
      if (submission == 2) {
        secondSubmitted.countDown();
      }
      delegate.execute(
          () -> {
            if (submission == 1) {
              firstStarted.countDown();
              try {
                releaseFirst.await();
              } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                return;
              }
            }
            command.run();
          });
    }

    boolean awaitFirstStarted() throws InterruptedException {
      return firstStarted.await(5, TimeUnit.SECONDS);
    }

    boolean awaitSecondSubmitted() throws InterruptedException {
      return secondSubmitted.await(5, TimeUnit.SECONDS);
    }

    void releaseFirst() {
      releaseFirst.countDown();
    }

    @Override
    public void shutdown() {
      delegate.shutdown();
    }

    @Override
    public java.util.List<Runnable> shutdownNow() {
      releaseFirst();
      return delegate.shutdownNow();
    }

    @Override
    public boolean isShutdown() {
      return delegate.isShutdown();
    }

    @Override
    public boolean isTerminated() {
      return delegate.isTerminated();
    }

    @Override
    public boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
      return delegate.awaitTermination(timeout, unit);
    }
  }
}
