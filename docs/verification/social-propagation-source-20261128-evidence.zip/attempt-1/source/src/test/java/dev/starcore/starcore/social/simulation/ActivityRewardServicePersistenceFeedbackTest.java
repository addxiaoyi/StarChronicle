package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.social.simulation.ActivityRewardService.ActivityRewardResult;
import dev.starcore.starcore.social.simulation.SocialActivityService.ActivityStatus;
import dev.starcore.starcore.social.simulation.SocialActivityService.SocialActivity;
import dev.starcore.starcore.social.simulation.SocialActivityService.SocialActivityType;
import dev.starcore.starcore.title.TitleService;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.MockedStatic;

class ActivityRewardServicePersistenceFeedbackTest {

  @TempDir Path tempDir;

  @Test
  void hostRewardReportsInfluenceWriteFailureToResultAndPlayer() {
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getDataFolder()).thenReturn(tempDir.toFile());
    when(plugin.getLogger())
        .thenReturn(Logger.getLogger("ActivityRewardServicePersistenceFeedbackTest"));
    Player player = mock(Player.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    UUID hostId = UUID.randomUUID();
    ReputationService reputationService = mock(ReputationService.class);
    SocialInfluenceService influenceService = mock(SocialInfluenceService.class);
    doThrow(new IllegalStateException("database unavailable"))
        .when(influenceService)
        .addInfluence(hostId, 20, "主持活动: 春季活动");
    EconomyService economyService = mock(EconomyService.class);
    TitleService titleService = mock(TitleService.class);
    SocialActivityService activityService = mock(SocialActivityService.class);
    when(activityService.getActivity("spring-party"))
        .thenReturn(
            Optional.of(
                new SocialActivity(
                    "spring-party",
                    "春季活动",
                    "",
                    SocialActivityType.PARTY,
                    hostId,
                    0,
                    0,
                    Set.of(),
                    Set.of(),
                    Set.of(),
                    ActivityStatus.ACTIVE,
                    20,
                    Map.of())));

    AtomicReference<Runnable> submittedDrain = new AtomicReference<>();
    SocialInfluenceWriteQueue queue =
        new SocialInfluenceWriteQueue(
            influenceService,
            task -> {
              submittedDrain.set(task);
              return new CompletableFuture<>();
            },
            (subject, failure) -> {});
    ActivityRewardService rewardService =
        new ActivityRewardService(
            plugin, reputationService, economyService, titleService, activityService, queue);

    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getPlayer(hostId)).thenReturn(player);
      bukkit.when(Bukkit::getScheduler).thenReturn(scheduler);
      doAnswer(
              invocation -> {
                ((Runnable) invocation.getArgument(1)).run();
                return mock(BukkitTask.class);
              })
          .when(scheduler)
          .runTask(eq(plugin), any(Runnable.class));

      ActivityRewardResult result = rewardService.grantHostReward(hostId, "spring-party", 10);

      assertThat(result.influencePersistence().toCompletableFuture()).isNotDone();
      verify(player).sendMessage(org.mockito.ArgumentMatchers.contains("影响力: §f20 §7(入账中)"));
      submittedDrain.get().run();
      assertThatThrownBy(() -> result.influencePersistence().toCompletableFuture().join())
          .isInstanceOf(CompletionException.class);
      verify(player).sendMessage("§c[活动奖励] 影响力入账失败，请联系管理员。");
      assertThat(result.formatRewards()).contains("影响力: 20 §c(入账失败)");
    }
  }
}
