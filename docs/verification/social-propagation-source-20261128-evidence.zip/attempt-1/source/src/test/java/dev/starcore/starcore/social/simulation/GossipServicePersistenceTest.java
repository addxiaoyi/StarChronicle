package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class GossipServicePersistenceTest {
  @TempDir Path root;

  @Test
  void graphPropagationRetainsEveryBranchAndReadStateAcrossIndependentReopen() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      UUID a = UUID.randomUUID(),
          b = UUID.randomUUID(),
          c = UUID.randomUUID(),
          d = UUID.randomUUID();
      when(f.relations.getSocialCircle(a, 20)).thenReturn(Set.of(b, c));
      when(f.relations.getSocialCircle(b, 20)).thenReturn(Set.of(a, d));
      when(f.relations.getSocialCircle(c, 20)).thenReturn(Set.of(d));
      var service = new GossipService(f.plugin, f.relations, f.reputation, () -> 0);
      String id = service.createGossip(a, "record", GossipService.GossipTopic.CULTURE);
      assertEquals(Set.of(a, b, c, d), service.getGossipById(id).seenBy());
      assertEquals(4, service.getGossipById(id).spreadCount());
      service.markGossipSeen(b, id);
      service.saveData();
      var reopened = new GossipService(f.plugin, f.relations, f.reputation);
      assertEquals(1, reopened.getUnreadGossipCount(c));
      assertEquals(0, reopened.getUnreadGossipCount(b));
      assertEquals(service.getGossipById(id), reopened.getGossipById(id));
      assertThrows(
          UnsupportedOperationException.class, () -> reopened.getGossipById(id).seenBy().clear());
      assertThrows(UnsupportedOperationException.class, () -> reopened.getAllGossips().clear());
      reopened.removeGossip(id);
      assertEquals(0, reopened.getUnreadGossipCount(c));
      assertFalse(reopened.hasSeenGossip(b, id));
      reopened.saveData();
    }
  }

  @Test
  void legacyUnversionedFileLoadsWithoutInventingReadStatus() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      UUID creator = UUID.randomUUID();
      var service = new GossipService(f.plugin, f.relations, f.reputation);
      String id = service.createGossip(creator, "legacy", GossipService.GossipTopic.CULTURE);
      service.saveData();
      Path file = root.resolve("gossip_data.yml");
      String raw = Files.readString(file).replace("schema-version: 1\n", "");
      int read = raw.indexOf("read:\n");
      assertTrue(read >= 0);
      raw = raw.substring(0, read);
      Files.writeString(file, raw);
      var legacy = new GossipService(f.plugin, f.relations, f.reputation);
      assertEquals(id, legacy.getPlayerGossipHistory(creator).getFirst().id());
      assertFalse(legacy.hasSeenGossip(creator, id));
      legacy.saveData();
      assertTrue(Files.readString(file).contains("schema-version: 1"));
    }
  }

  @Test
  void corruptReloadPreservesMemoryAndEvidenceAndPreventsShutdownSave() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      var service = new GossipService(f.plugin, f.relations, f.reputation);
      String id =
          service.createGossip(UUID.randomUUID(), "saved", GossipService.GossipTopic.CULTURE);
      service.saveData();
      Path file = root.resolve("gossip_data.yml");
      String valid = Files.readString(file);
      Files.writeString(file, valid + "gossips: [broken]\n");
      byte[] broken = Files.readAllBytes(file);
      assertThrows(IllegalStateException.class, service::loadData);
      assertNotNull(service.getGossipById(id));
      assertThrows(IllegalStateException.class, service::saveData);
      assertArrayEquals(broken, Files.readAllBytes(file));
      Files.writeString(file, valid);
      service.loadData();
      service.saveData();
    }
  }

  @Test
  void staleWriterMissingAuthorityAndRecoveryArtifactsAreNeverSilentlyOverwritten()
      throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      var a = new GossipService(f.plugin, f.relations, f.reputation);
      var b = new GossipService(f.plugin, f.relations, f.reputation);
      a.createGossip(UUID.randomUUID(), "one", GossipService.GossipTopic.CULTURE);
      a.saveData();
      byte[] committed = Files.readAllBytes(root.resolve("gossip_data.yml"));
      assertThrows(IllegalStateException.class, b::saveData);
      assertArrayEquals(committed, Files.readAllBytes(root.resolve("gossip_data.yml")));
      Files.writeString(root.resolve("gossip_data.yml.tmp"), "uncertain");
      assertThrows(IllegalStateException.class, a::saveData);
      assertEquals("uncertain", Files.readString(root.resolve("gossip_data.yml.tmp")));
      assertThrows(
          IllegalStateException.class,
          () -> new GossipService(f.plugin, f.relations, f.reputation));
    }
  }

  @Test
  void futureSchemaAndMissingPrimaryWithBackupAreRejected() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      Files.writeString(root.resolve("gossip_data.yml"), "schema-version: 99\n");
      assertThrows(
          IllegalStateException.class,
          () -> new GossipService(f.plugin, f.relations, f.reputation));
      Files.move(root.resolve("gossip_data.yml"), root.resolve("gossip_data.yml.bak"));
      assertThrows(
          IllegalStateException.class,
          () -> new GossipService(f.plugin, f.relations, f.reputation));
      assertFalse(Files.exists(root.resolve("gossip_data.yml")));
    }
  }

  @Test
  void concurrentCommentsAreRetainedAndReturnedRecordsCannotMutateState() throws Exception {
    try (var f = new SocialOwnerFixture(root)) {
      var service = new GossipService(f.plugin, f.relations, f.reputation);
      UUID creator = UUID.randomUUID();
      String id = service.createGossip(creator, "thread", GossipService.GossipTopic.CULTURE);
      try (var pool = Executors.newFixedThreadPool(2)) {
        var first =
            pool.submit(
                () -> {
                  for (int i = 0; i < 80; i++) service.commentOnGossip(creator, id, "a" + i);
                });
        var second =
            pool.submit(
                () -> {
                  for (int i = 0; i < 80; i++) service.commentOnGossip(creator, id, "b" + i);
                });
        first.get(10, TimeUnit.SECONDS);
        second.get(10, TimeUnit.SECONDS);
      }
      assertEquals(160, service.getGossipById(id).comments().size());
      assertThrows(
          UnsupportedOperationException.class, () -> service.getGossipById(id).comments().clear());
      assertThrows(IllegalArgumentException.class, () -> service.updateCredibility(id, Double.NaN));
      service.clearData();
      assertFalse(service.hasSeenGossip(creator, id));
    }
  }
}
