package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.EntityScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.mockito.MockedStatic;

final class SocialOwnerFixture implements AutoCloseable {
  final JavaPlugin plugin = mock(JavaPlugin.class);
  final Server server = mock(Server.class);
  final RelationshipNetwork relations = mock(RelationshipNetwork.class);
  final ReputationService reputation = mock(ReputationService.class);
  final Map<UUID, Player> players = new HashMap<>();
  final List<Runnable> callbacks = new ArrayList<>();
  final List<ScheduledTask> handles = new ArrayList<>();
  final AtomicReference<Player> owner = new AtomicReference<>();
  final MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class);

  SocialOwnerFixture(Path root) {
    when(plugin.getDataFolder()).thenReturn(root.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getLogger("social-owner-test"));
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getServer()).thenReturn(server);
    when(server.getPlayer(any(UUID.class))).thenAnswer(inv -> players.get(inv.getArgument(0)));
    when(reputation.modifyReputation(any(), anyInt(), any()))
        .thenReturn(CompletableFuture.completedFuture(true));
  }

  Player player(UUID id, String name) {
    Player player = mock(Player.class);
    EntityScheduler scheduler = mock(EntityScheduler.class);
    when(player.getUniqueId()).thenReturn(id);
    when(player.getScheduler()).thenReturn(scheduler);
    when(player.isOnline()).thenReturn(true);
    when(player.getName())
        .thenAnswer(
            ignored -> {
              assertSame(player, owner.get());
              return name;
            });
    doAnswer(
            ignored -> {
              assertSame(player, owner.get());
              return null;
            })
        .when(player)
        .sendMessage(anyString());
    bukkit
        .when(() -> Bukkit.isOwnedByCurrentRegion(player))
        .thenAnswer(ignored -> owner.get() == player);
    when(scheduler.run(same(plugin), any(), any()))
        .thenAnswer(
            inv -> {
              Consumer<ScheduledTask> callback = inv.getArgument(1);
              ScheduledTask handle = mock(ScheduledTask.class);
              handles.add(handle);
              callbacks.add(
                  () -> {
                    owner.set(player);
                    try {
                      callback.accept(handle);
                    } finally {
                      owner.set(null);
                    }
                  });
              return handle;
            });
    players.put(id, player);
    return player;
  }

  void drain() {
    while (!callbacks.isEmpty()) callbacks.removeFirst().run();
  }

  @Override
  public void close() {
    bukkit.close();
  }
}
