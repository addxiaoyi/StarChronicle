package dev.starcore.starcore.social.guild;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * 公会生命周期测试 - 覆盖 createGuild / disbandGuild / 查询 API 的各种分支路径，包括 D-012 二次确认机制。
 *
 * <p>测试不依赖任何外部服务（数据库/YAML/插件），仅验证 GuildService 内部状态机逻辑。
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("公会生命周期测试")
class GuildServiceLifecycleTest {

  private GuildService guildService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();
  private final UUID carol = UUID.randomUUID();
  private final UUID dave = UUID.randomUUID();

  @BeforeEach
  void setUp() {
    guildService = new GuildService();
  }

  // ===== createGuild =====

  @Test
  @DisplayName("createGuild: 正常创建公会应返回公会对象")
  void createGuild_success_returnsGuild() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertNotNull(guild);
    assertEquals("Alpha", guild.getName());
    assertEquals("[A]", guild.getTag());
    assertEquals(alice, guild.getLeader());
    assertEquals(1, guild.getMemberCount(), "创建者应自动成为成员");
  }

  @Test
  @DisplayName("createGuild: 创建后会长应自动加入成员列表")
  void createGuild_leaderInMembers() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertTrue(guild.isMember(alice), "会长应在成员列表中");
    assertEquals(GuildRole.LEADER, guild.getMemberRole(alice), "会长的职位应为 LEADER");
  }

  @Test
  @DisplayName("createGuild: 同一玩家不能同时加入两个公会")
  void createGuild_playerAlreadyInGuild_throws() {
    guildService.createGuild(alice, "Alpha", "[A]");

    assertThrows(IllegalStateException.class, () -> guildService.createGuild(alice, "Beta", "[B]"));
  }

  @Test
  @DisplayName("createGuild: 公会名称不能重复")
  void createGuild_duplicateName_throws() {
    guildService.createGuild(alice, "Alpha", "[A]");

    assertThrows(
        IllegalArgumentException.class, () -> guildService.createGuild(bob, "Alpha", "[B]"));
  }

  @Test
  @DisplayName("createGuild: 名称大小写不敏感")
  void createGuild_caseInsensitiveName_throws() {
    guildService.createGuild(alice, "Alpha", "[A]");

    assertThrows(
        IllegalArgumentException.class, () -> guildService.createGuild(bob, "alpha", "[B]"));
  }

  @Test
  @DisplayName("createGuild: 首次创建时公会等级和经验均为初始值")
  void createGuild_initialLevelAndExp() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertEquals(1, guild.getLevel());
    assertEquals(0, guild.getExperience());
  }

  // ===== disbandGuild（D-012 二次确认）=====

  @Test
  @DisplayName("disbandGuild: 第一次调用（confirm=false）仅标记意图，抛出异常等待确认")
  void disbandGuild_firstCall_onlyMarksIntention() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    IllegalStateException ex =
        assertThrows(
            IllegalStateException.class, () -> guildService.disbandGuild(guild.getId(), alice));
    assertTrue(ex.getMessage().contains("二次确认"), "异常消息应包含二次确认提示");
    assertTrue(guild.isDisbandRequested(), "公会应被标记为待解散");
    assertNotNull(guildService.getGuildByName("Alpha"), "公会仍可查询到（未真正解散）");
  }

  @Test
  @DisplayName("disbandGuild: 确认解散（confirm=true）后公会应被移除")
  void disbandGuild_confirmed_actuallyRemovesGuild() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");
    UUID guildId = guild.getId();

    // 第一次调用标记意图
    assertThrows(IllegalStateException.class, () -> guildService.disbandGuild(guildId, alice));

    // 第二次调用确认解散
    assertTrue(guildService.disbandGuild(guildId, alice, true));

    assertNull(guildService.getGuildByName("Alpha"), "公会应已被移除");
    assertNull(guildService.getPlayerGuild(alice), "会长的公会记录应被清除");
  }

  @Test
  @DisplayName("disbandGuild: 未先标记意图直接确认应抛出异常")
  void disbandGuild_confirmWithoutIntention_throws() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertThrows(
        IllegalStateException.class,
        () -> guildService.disbandGuild(guild.getId(), alice, true),
        "未标记意图时直接确认应抛出异常");
  }

  @Test
  @DisplayName("disbandGuild: 非会长尝试解散应抛出异常")
  void disbandGuild_nonLeader_throws() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertThrows(IllegalStateException.class, () -> guildService.disbandGuild(guild.getId(), bob));
  }

  @Test
  @DisplayName("disbandGuild: 解散后所有成员的 playerGuilds 映射应被清除")
  void disbandGuild_clearsAllMemberMappings() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");
    UUID guildId = guild.getId();

    guildService.inviteMember(guildId, alice, bob);
    guildService.acceptInvite(bob, guildId);

    // 第一次标记意图
    assertThrows(IllegalStateException.class, () -> guildService.disbandGuild(guildId, alice));

    // 确认解散
    assertTrue(guildService.disbandGuild(guildId, alice, true));

    assertNull(guildService.getPlayerGuild(alice), "会长的公会记录应被清除");
    assertNull(guildService.getPlayerGuild(bob), "成员的公会记录应被清除");
  }

  @Test
  @DisplayName("disbandGuild: 解散后所有待处理的公会邀请应被清除")
  void disbandGuild_clearsPendingInvites() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");
    UUID guildId = guild.getId();

    guildService.inviteMember(guildId, alice, bob);

    // 第一次标记意图
    assertThrows(IllegalStateException.class, () -> guildService.disbandGuild(guildId, alice));

    // 确认解散
    assertTrue(guildService.disbandGuild(guildId, alice, true));

    assertTrue(guildService.getGuildInvites(bob).isEmpty(), "解散后所有邀请应被清除");
  }

  @Test
  @DisplayName("disbandGuild: 不存在的公会应返回 false")
  void disbandGuild_nonexistent_returnsFalse() {
    assertFalse(guildService.disbandGuild(UUID.randomUUID(), alice));
  }

  // ===== 查询 API =====

  @Test
  @DisplayName("getPlayerGuild: 玩家未加入公会时应返回 null")
  void getPlayerGuild_noGuild_returnsNull() {
    assertNull(guildService.getPlayerGuild(alice));
  }

  @Test
  @DisplayName("getPlayerGuild: 加入公会后应返回对应公会")
  void getPlayerGuild_afterJoin_returnsGuild() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    assertEquals(guild.getId(), guildService.getPlayerGuild(alice).getId());
  }

  @Test
  @DisplayName("getGuildByName: 正常查询应返回公会")
  void getGuildByName_exists_returnsGuild() {
    guildService.createGuild(alice, "Alpha", "[A]");

    assertNotNull(guildService.getGuildByName("Alpha"));
  }

  @Test
  @DisplayName("getGuildByName: 不存在的公会名称应返回 null")
  void getGuildByName_notExists_returnsNull() {
    assertNull(guildService.getGuildByName("NonExistent"));
  }

  @Test
  @DisplayName("getGuildByName: 名称大小写不敏感")
  void getGuildByName_caseInsensitive() {
    guildService.createGuild(alice, "Alpha", "[A]");

    assertNotNull(guildService.getGuildByName("alpha"));
    assertNotNull(guildService.getGuildByName("ALPHA"));
  }

  @Test
  @DisplayName("getAllGuilds: 应返回所有公会的副本")
  void getAllGuilds_returnsAllGuilds() {
    guildService.createGuild(alice, "Alpha", "[A]");
    guildService.createGuild(bob, "Beta", "[B]");

    Collection<Guild> all = guildService.getAllGuilds();
    assertEquals(2, all.size());
  }

  @Test
  @DisplayName("getAllGuilds: 返回集合为不可变集合")
  void getAllGuilds_returnsImmutableCopy() {
    guildService.createGuild(alice, "Alpha", "[A]");
    Collection<Guild> all = guildService.getAllGuilds();

    // 尝试修改应抛出 UnsupportedOperationException
    assertThrows(UnsupportedOperationException.class, () -> all.clear(), "不应可以修改返回的集合");

    assertEquals(1, guildService.getAllGuilds().size(), "不可变集合不应影响内部状态");
  }

  // ===== getGuildLeaderboard =====

  @Test
  @DisplayName("getGuildLeaderboard: 应按等级降序排列")
  void getGuildLeaderboard_sortedByLevelDesc() {
    Guild guild1 = guildService.createGuild(alice, "Alpha", "[A]");
    Guild guild2 = guildService.createGuild(bob, "Beta", "[B]");
    Guild guild3 = guildService.createGuild(carol, "Gamma", "[G]");

    // 调整等级
    guild1.addExperience(2000); // 升到2级，剩余0 exp
    guild2.addExperience(500); // 1级，500 exp
    guild3.addExperience(3000); // 升到3级，剩余0 exp

    List<Guild> leaderboard = guildService.getGuildLeaderboard(10);
    assertEquals("Gamma", leaderboard.get(0).getName(), "等级最高的 Gamma 应排第一");
    assertEquals("Alpha", leaderboard.get(1).getName(), "等级次高的 Alpha 应排第二");
    assertEquals("Beta", leaderboard.get(2).getName(), "等级最低的 Beta 应排第三");
  }

  @Test
  @DisplayName("getGuildLeaderboard: 同等级时按经验降序排列")
  void getGuildLeaderboard_sameLevel_byExpDesc() {
    Guild alpha = guildService.createGuild(alice, "Alpha", "[A]");
    Guild beta = guildService.createGuild(bob, "Beta", "[B]");

    // 同一等级，不同经验
    // Alpha: 1级，800 exp
    // Beta:  1级，1200 exp
    guildService.addGuildExperience(alpha.getId(), 800);
    guildService.addGuildExperience(beta.getId(), 1200);

    List<Guild> leaderboard = guildService.getGuildLeaderboard(10);
    assertEquals("Beta", leaderboard.get(0).getName(), "经验更高的 Beta 应排第一");
    assertEquals("Alpha", leaderboard.get(1).getName());
  }

  @Test
  @DisplayName("getGuildLeaderboard: limit 参数应限制返回数量")
  void getGuildLeaderboard_respectsLimit() {
    guildService.createGuild(alice, "Alpha", "[A]");
    guildService.createGuild(bob, "Beta", "[B]");
    guildService.createGuild(carol, "Gamma", "[G]");

    List<Guild> leaderboard = guildService.getGuildLeaderboard(2);
    assertEquals(2, leaderboard.size());
  }

  @Test
  @DisplayName("getGuildLeaderboard: 无公会时应返回空列表")
  void getGuildLeaderboard_noGuilds_returnsEmpty() {
    List<Guild> leaderboard = guildService.getGuildLeaderboard(10);
    assertTrue(leaderboard.isEmpty());
  }

  // ===== addGuildExperience =====

  @Test
  @DisplayName("addGuildExperience: 达到升级阈值应自动升级")
  void addGuildExperience_triggersLevelUp() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    guildService.addGuildExperience(guild.getId(), 1500);
    // 1级升到2级需要 1000 exp，1500 exp -> 2级，500 exp 剩余

    assertEquals(2, guild.getLevel(), "应升到2级");
    assertEquals(500, guild.getExperience(), "剩余经验应为 500");
  }

  @Test
  @DisplayName("addGuildExperience: 大量经验应触发多次升级")
  void addGuildExperience_multipleLevelUps() {
    Guild guild = guildService.createGuild(alice, "Alpha", "[A]");

    // 公式: L1→L2=1000, L2→L3=2000, L3→L4=3000
    // 6500 exp: 1->2(1000剩5500), 2->3(2000剩3500), 3->4(3000剩500) = L4
    guildService.addGuildExperience(guild.getId(), 6500);
    assertEquals(4, guild.getLevel(), "应升到4级");
    assertEquals(500, guild.getExperience(), "剩余经验应为 500");
  }

  @Test
  @DisplayName("addGuildExperience: 不存在的公会应静默忽略")
  void addGuildExperience_nonexistentGuild_isSilent() {
    assertDoesNotThrow(() -> guildService.addGuildExperience(UUID.randomUUID(), 1000));
  }
}
