package dev.starcore.starcore.social;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.social.mail.Mail;
import dev.starcore.starcore.social.mail.MailService;
import dev.starcore.starcore.social.mail.attachment.MailAttachmentService.AttachmentClaimResult;
import dev.starcore.starcore.social.mail.attachment.impl.MailAttachmentServiceImpl;
import java.time.Duration;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class SocialMailAttachmentOwnerContractTest {
  private final DatabaseService databaseService = mock(DatabaseService.class);
  private final StarCoreScheduler scheduler = mock(StarCoreScheduler.class);
  private final MailService mailService = mock(MailService.class);
  private final Player player = mock(Player.class);
  private final UUID playerId = UUID.randomUUID();
  private final UUID mailId = UUID.randomUUID();
  private final MailAttachmentServiceImpl service =
      new MailAttachmentServiceImpl(
          databaseService, scheduler, mailService, Logger.getAnonymousLogger());

  @Test
  void asyncClaimUsesOriginalPlayerAndDefersPlayerAccessUntilOwnerRuns() {
    OwnerTask task = queueOwnerTask();
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId)).thenReturn(List.of());

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    verify(scheduler).callForEntity(same(player), any());
    verify(scheduler, never()).runSync(any(Runnable.class));
    verifyNoInteractions(player, mailService);
    assertFalse(result.isDone());

    task.run();

    verify(scheduler).requireEntityOwner(player);
    verify(player).getUniqueId();
    assertFalse(result.join().success());
    assertStoppedPromptly();
  }

  @Test
  void synchronousClaimRejectsWrongOwnerBeforeReadingPlayer() {
    rejectWrongOwner();

    assertThrows(IllegalStateException.class, () -> service.claimAttachments(player, mailId));

    verifyNoInteractions(player, mailService);
  }

  @Test
  void synchronousSpaceCheckRejectsWrongOwnerBeforeReadingInventory() {
    rejectWrongOwner();

    assertThrows(
        IllegalStateException.class,
        () -> service.hasInventorySpace(player, List.of(mock(ItemStack.class))));

    verifyNoInteractions(player);
  }

  @Test
  void synchronousSlotCalculationRejectsWrongOwnerBeforeReadingInventory() {
    rejectWrongOwner();

    assertThrows(
        IllegalStateException.class,
        () -> service.calculateRequiredSlots(player, List.of(mock(ItemStack.class))));

    verifyNoInteractions(player);
  }

  @Test
  void retiredEntityCompletesClaimExceptionallyWithoutTouchingPlayer() {
    OwnerTask task = queueOwnerTask();
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);
    RuntimeException failure =
        new StarCoreScheduler.EntityTaskNotAppliedException("entity retired");

    task.completion.completeExceptionally(failure);

    assertSame(failure, assertThrows(CompletionException.class, result::join).getCause());
    task.operation.get();
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void immediateSchedulerShutdownRejectionCompletesClaimExceptionally() {
    RuntimeException failure =
        new StarCoreScheduler.EntityTaskNotAppliedException("scheduler stopped");
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenReturn(CompletableFuture.failedFuture(failure));

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    assertSame(failure, assertThrows(CompletionException.class, result::join).getCause());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void schedulingExceptionCompletesClaimExceptionallyAndUntracksOperation() {
    RuntimeException failure = new IllegalStateException("scheduling failed");
    when(scheduler.<Void>callForEntity(same(player), any())).thenThrow(failure);

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    assertSame(failure, assertThrows(CompletionException.class, result::join).getCause());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void ownerOperationExceptionCompletesClaimExceptionallyAndUntracksOperation() {
    OwnerTask task = queueOwnerTask();
    RuntimeException failure = new IllegalStateException("mail read failed");
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId)).thenThrow(failure);
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    task.run();

    assertSame(failure, assertThrows(CompletionException.class, result::join).getCause());
    verify(player, never()).getInventory();
    assertStoppedPromptly();
  }

  @Test
  void stoppingCancelsQueuedOwnerTaskAndPreventsLatePlayerAccess() {
    OwnerTask task = queueOwnerTask();
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    service.stopAcceptingOperations();

    assertTrue(result.isCancelled());
    assertTrue(task.completion.isCancelled());
    assertNull(task.operation.get());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void callerCancellationCancelsQueuedOwnerTaskAndPreventsLatePlayerAccess() {
    OwnerTask task = queueOwnerTask();
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    result.cancel(false);

    assertTrue(task.completion.isCancelled());
    assertNull(task.operation.get());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void stoppingUntracksOperationBeforeNotifyingClaimContinuations() {
    queueOwnerTask();
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);
    CompletableFuture<AttachmentClaimResult> continuation =
        result.whenComplete((claimed, failure) -> service.shutdown());

    assertTimeout(Duration.ofSeconds(1), service::stopAcceptingOperations);

    assertTrue(result.isCancelled());
    assertTrue(continuation.isCompletedExceptionally());
    verifyNoInteractions(player, mailService);
  }

  @Test
  void ownerCompletionUntracksOperationBeforeNotifyingClaimContinuations() {
    OwnerTask task = queueOwnerTask();
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId)).thenReturn(List.of());
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);
    CompletableFuture<AttachmentClaimResult> continuation =
        result.whenComplete((claimed, failure) -> service.shutdown());

    assertTimeout(Duration.ofSeconds(1), task::run);

    assertFalse(continuation.join().success());
  }

  @Test
  void shutdownDuringRegistrationCancelsLateOwnerHandle() {
    OwnerTask task = new OwnerTask();
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              task.operation = invocation.getArgument(1);
              service.shutdown();
              return task.completion;
            });

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    assertTrue(result.isCancelled());
    assertTrue(task.completion.isCancelled());
    assertNull(task.operation.get());
    verifyNoInteractions(player, mailService);
    assertStoppedPromptly();
  }

  @Test
  void inlineOwnerExecutionBeforeHandleRegistrationDoesNotLeakTrackedWork() {
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId)).thenReturn(List.of());
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              Supplier<Void> operation = invocation.getArgument(1);
              return CompletableFuture.completedFuture(operation.get());
            });

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    assertFalse(result.join().success());
    verify(scheduler).requireEntityOwner(player);
    assertStoppedPromptly();
  }

  @Test
  void shutdownWaitsForStartedOwnerOperationWithoutCancellingItsFuture() throws Exception {
    OwnerTask task = queueOwnerTask();
    CountDownLatch entered = new CountDownLatch(1);
    CountDownLatch release = new CountDownLatch(1);
    when(player.getUniqueId()).thenReturn(playerId);
    when(mailService.getPlayerMails(playerId))
        .thenAnswer(
            invocation -> {
              entered.countDown();
              await(release);
              return List.of();
            });
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);
    Thread ownerThread = new Thread(task::run, "social-mail-owner-test");
    Thread shutdownThread = new Thread(service::shutdown, "social-mail-shutdown-test");
    try {
      ownerThread.start();
      assertTrue(entered.await(5, TimeUnit.SECONDS));
      shutdownThread.start();
      assertTrue(awaitWaiting(shutdownThread));
      assertFalse(result.isDone());
      assertFalse(task.completion.isDone());
    } finally {
      release.countDown();
      ownerThread.join(TimeUnit.SECONDS.toMillis(5));
      shutdownThread.join(TimeUnit.SECONDS.toMillis(5));
    }

    assertFalse(ownerThread.isAlive());
    assertFalse(shutdownThread.isAlive());
    assertFalse(result.isCancelled());
    assertFalse(result.join().success());
  }

  @Test
  void stoppedServiceRejectsNewClaimsWithoutSchedulingOrPlayerAccess() {
    service.stopAcceptingOperations();

    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    assertThrows(CompletionException.class, result::join);
    verify(scheduler, never()).callForEntity(any(), any());
    verifyNoInteractions(player, mailService);
  }

  @Test
  void invalidArgumentsRetainFailureResultWithoutSchedulingOrPlayerAccess() {
    assertFalse(service.claimAttachmentsAsync(null, mailId).join().success());
    assertFalse(service.claimAttachmentsAsync(player, null).join().success());

    verify(scheduler, never()).callForEntity(any(), any());
    verifyNoInteractions(player, mailService);
  }

  @Test
  void ownerClaimGrantsInventoryAndConfirmsMail() {
    OwnerTask task = queueOwnerTask();
    PlayerInventory inventory = inventoryWithAttachment();
    when(mailService.confirmClaimed(playerId, mailId)).thenReturn(true);
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);
    verifyNoInteractions(inventory);

    task.run();

    assertTrue(result.join().success());
    assertEquals(1, result.join().claimedCount());
    verify(scheduler).requireEntityOwner(player);
    verify(inventory).setStorageContents(any(ItemStack[].class));
    verify(mailService).confirmClaimed(playerId, mailId);
    assertStoppedPromptly();
  }

  @Test
  void ownerClaimRetainsInventoryRollbackWhenConfirmationFails() {
    OwnerTask task = queueOwnerTask();
    PlayerInventory inventory = inventoryWithAttachment();
    when(mailService.confirmClaimed(playerId, mailId)).thenReturn(false);
    CompletableFuture<AttachmentClaimResult> result = service.claimAttachmentsAsync(player, mailId);

    task.run();

    assertFalse(result.join().success());
    ArgumentCaptor<ItemStack[]> contents = ArgumentCaptor.forClass(ItemStack[].class);
    verify(inventory, times(2)).setStorageContents(contents.capture());
    assertNotNull(contents.getAllValues().getFirst()[0]);
    for (ItemStack item : contents.getAllValues().getLast()) {
      assertNull(item);
    }
    assertStoppedPromptly();
  }

  private OwnerTask queueOwnerTask() {
    OwnerTask task = new OwnerTask();
    when(scheduler.<Void>callForEntity(same(player), any()))
        .thenAnswer(
            invocation -> {
              task.operation = invocation.getArgument(1);
              return task.completion;
            });
    return task;
  }

  private void rejectWrongOwner() {
    doThrow(new IllegalStateException("wrong owner")).when(scheduler).requireEntityOwner(player);
  }

  private PlayerInventory inventoryWithAttachment() {
    PlayerInventory inventory = mock(PlayerInventory.class);
    Mail mail = mock(Mail.class);
    dev.starcore.starcore.social.mail.MailAttachment attachment =
        mock(dev.starcore.starcore.social.mail.MailAttachment.class);
    ItemStack item = mock(ItemStack.class);
    when(item.getType()).thenReturn(Material.DIAMOND);
    when(item.getAmount()).thenReturn(1);
    when(item.getMaxStackSize()).thenReturn(64);
    when(item.clone()).thenReturn(item);
    when(attachment.deserializeItem()).thenReturn(item);
    when(mail.getId()).thenReturn(mailId);
    when(mail.hasAttachments()).thenReturn(true);
    when(mail.getAttachments()).thenReturn(List.of(attachment));
    when(mail.getSenderId()).thenReturn(UUID.randomUUID());
    when(mail.getSenderName()).thenReturn("sender");
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.getInventory()).thenReturn(inventory);
    when(inventory.getStorageContents()).thenReturn(new ItemStack[36]);
    when(mailService.getPlayerMails(playerId)).thenReturn(List.of(mail));
    return inventory;
  }

  private void assertStoppedPromptly() {
    assertTimeout(Duration.ofSeconds(1), service::shutdown);
  }

  private static void await(CountDownLatch latch) {
    try {
      if (!latch.await(5, TimeUnit.SECONDS)) {
        throw new IllegalStateException("Timed out waiting for owner operation");
      }
    } catch (InterruptedException failure) {
      Thread.currentThread().interrupt();
      throw new IllegalStateException(failure);
    }
  }

  private static boolean awaitWaiting(Thread thread) {
    long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(2);
    while (System.nanoTime() < deadline && thread.isAlive()) {
      if (thread.getState() == Thread.State.TIMED_WAITING) {
        return true;
      }
      Thread.onSpinWait();
    }
    return false;
  }

  private static final class OwnerTask {
    private final CompletableFuture<Void> completion = new CompletableFuture<>();
    private Supplier<Void> operation;

    private void run() {
      try {
        completion.complete(operation.get());
      } catch (Throwable failure) {
        completion.completeExceptionally(failure);
      }
    }
  }
}
