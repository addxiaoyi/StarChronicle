package dev.starcore.starcore.social.emote;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.*;

/**
 * EmoteCooldownManager 测试 - 验证动作冷却的设置、查询、清理、序列化等功能。 D-042 之后：优先使用 EmoteService/EmoteState，也支持降级的本地
 * playerCooldowns Map。
 */
@DisplayName("动作冷却管理器测试")
class EmoteCooldownManagerTest {

  private EmoteCooldownManager manager;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();

  @BeforeEach
  void setUp() {
    manager = new EmoteCooldownManager();
  }

  // ===== 默认冷却时间 =====

  @Test
  @DisplayName("构造函数设置默认冷却时间")
  void defaultCooldowns_areSet() {
    assertEquals(3, manager.getDefaultCooldown("wave"));
    assertEquals(5, manager.getDefaultCooldown("bow"));
    assertEquals(3, manager.getDefaultCooldown("salute"));
    assertEquals(5, manager.getDefaultCooldown("laugh"));
    assertEquals(10, manager.getDefaultCooldown("cry"));
    assertEquals(8, manager.getDefaultCooldown("angry"));
    assertEquals(3, manager.getDefaultCooldown("clap"));
    assertEquals(10, manager.getDefaultCooldown("hug"));
    assertEquals(15, manager.getDefaultCooldown("kiss"));
    assertEquals(3, manager.getDefaultCooldown("handshake"));
    assertEquals(15, manager.getDefaultCooldown("dance"));
    assertEquals(20, manager.getDefaultCooldown("sit"));
    assertEquals(5, manager.getDefaultCooldown("sword"));
    assertEquals(5, manager.getDefaultCooldown("shield"));
    assertEquals(3, manager.getDefaultCooldown("attack"));
    assertEquals(2, manager.getDefaultCooldown("point"));
    assertEquals(3, manager.getDefaultCooldown("thumbsup"));
    assertEquals(5, manager.getDefaultCooldown("facepalm"));
    assertEquals(30, manager.getDefaultCooldown("sleep"));
    assertEquals(5, manager.getDefaultCooldown("eat"));
    assertEquals(5, manager.getDefaultCooldown("drink"));
    assertEquals(10, manager.getDefaultCooldown("spin"));
  }

  @Test
  @DisplayName("未知动作返回默认 5 秒")
  void unknownEmote_returnsFiveSeconds() {
    assertEquals(5, manager.getDefaultCooldown("unknownEmote123"));
  }

  @Test
  @DisplayName("setDefaultCooldown 修改指定动作的冷却时间")
  void setDefaultCooldown_updatesValue() {
    manager.setDefaultCooldown("wave", 999);
    assertEquals(999, manager.getDefaultCooldown("wave"));
  }

  @Test
  @DisplayName("动作 ID 大小写不敏感")
  void emoteId_caseInsensitive() {
    manager.setDefaultCooldown("WAVE", 7);
    assertEquals(7, manager.getDefaultCooldown("wave"));
    assertEquals(7, manager.getDefaultCooldown("Wave"));
  }

  // ===== 无 EmoteService 降级模式（本地 Map）=====  所有测试在降级模式下

  @Test
  @DisplayName("startCooldown 后 isOnCooldown 应返回 true")
  void startCooldown_thenIsOnCooldown() {
    manager.startCooldown(alice, "wave");

    assertTrue(manager.isOnCooldown(alice, "wave"));
  }

  @Test
  @DisplayName("未开始冷却时 isOnCooldown 返回 false")
  void neverStarted_isOnCooldownFalse() {
    assertFalse(manager.isOnCooldown(alice, "wave"));
  }

  @Test
  @DisplayName("冷却结束后 isOnCooldown 返回 false")
  void afterCooldown_elapsed_isOnCooldownFalse() throws Exception {
    // wave 冷却 3 秒（3000ms），用 5000ms ago 让其过期
    injectExpiredCooldown(alice, "wave", 5000);
    assertFalse(manager.isOnCooldown(alice, "wave"));
  }

  @Test
  @DisplayName("getRemainingCooldown 返回正确的秒数")
  void getRemainingCooldown_returnsSeconds() throws Exception {
    // bow 冷却 5 秒，已过 2 秒，应剩余 3 秒
    injectCooldown(alice, "bow", 5000, 2000);
    int remaining = manager.getRemainingCooldown(alice, "bow");
    assertTrue(remaining >= 2 && remaining <= 4, "剩余时间应在 2-4 秒（5-2=3 实际，可能有 clock drift）");
  }

  @Test
  @DisplayName("无冷却时 getRemainingCooldown 返回 0")
  void noCooldown_getRemainingCooldown_returnsZero() {
    assertEquals(0, manager.getRemainingCooldown(alice, "wave"));
  }

  @Test
  @DisplayName("不同玩家冷却互不影响")
  void differentPlayers_independentCooldowns() {
    manager.startCooldown(alice, "wave");
    manager.startCooldown(bob, "wave");

    assertTrue(manager.isOnCooldown(alice, "wave"));
    assertTrue(manager.isOnCooldown(bob, "wave"));
    // Bob 清冷却不影响 Alice
    manager.clearCooldown(bob, "wave");
    assertTrue(manager.isOnCooldown(alice, "wave"));
    assertFalse(manager.isOnCooldown(bob, "wave"));
  }

  @Test
  @DisplayName("不同动作冷却互不影响")
  void differentEmotes_independentCooldowns() {
    manager.startCooldown(alice, "wave");
    manager.startCooldown(alice, "bow");

    assertTrue(manager.isOnCooldown(alice, "wave"));
    assertTrue(manager.isOnCooldown(alice, "bow"));

    manager.clearCooldown(alice, "wave");
    assertFalse(manager.isOnCooldown(alice, "wave"));
    assertTrue(manager.isOnCooldown(alice, "bow"));
  }

  // ===== getPlayerCooldowns =====

  @Test
  @DisplayName("getPlayerCooldowns 返回所有活跃冷却")
  void getPlayerCooldowns_returnsActive() {
    manager.startCooldown(alice, "wave");
    manager.startCooldown(alice, "bow");

    Map<String, Integer> cooldowns = manager.getPlayerCooldowns(alice);

    assertEquals(2, cooldowns.size());
    assertTrue(cooldowns.containsKey("wave"));
    assertTrue(cooldowns.containsKey("bow"));
  }

  @Test
  @DisplayName("getPlayerCooldowns 过期冷却被清理")
  void getPlayerCooldowns_clearsExpired() throws Exception {
    injectCooldown(alice, "wave", 5000, 6000); // 5s 冷却，6s 前开始 = 已过期
    injectCooldown(alice, "bow", 5, 0); // 5s 冷却，0ms 前开始 = 刚用

    Map<String, Integer> cooldowns = manager.getPlayerCooldowns(alice);

    assertEquals(1, cooldowns.size());
    assertTrue(cooldowns.containsKey("bow"));
    assertFalse(cooldowns.containsKey("wave"));
  }

  @Test
  @DisplayName("无冷却玩家返回空 Map")
  void noCooldowns_getPlayerCooldowns_returnsEmpty() {
    assertTrue(manager.getPlayerCooldowns(alice).isEmpty());
  }

  // ===== 清理 =====

  @Test
  @DisplayName("clearCooldown 清除指定动作冷却")
  void clearCooldown_removesSpecificEmote() {
    manager.startCooldown(alice, "wave");
    manager.startCooldown(alice, "bow");

    manager.clearCooldown(alice, "wave");

    assertFalse(manager.isOnCooldown(alice, "wave"));
    assertTrue(manager.isOnCooldown(alice, "bow"));
  }

  @Test
  @DisplayName("clearPlayerCooldowns 清除所有冷却")
  void clearPlayerCooldowns_removesAll() {
    manager.startCooldown(alice, "wave");
    manager.startCooldown(alice, "bow");
    manager.startCooldown(bob, "wave");

    manager.clearPlayerCooldowns(alice);

    assertFalse(manager.isOnCooldown(alice, "wave"));
    assertFalse(manager.isOnCooldown(alice, "bow"));
    assertTrue(manager.isOnCooldown(bob, "wave"), "Bob 不应受影响");
  }

  @Test
  @DisplayName("cleanupExpiredCooldowns 清除所有过期冷却")
  void cleanupExpiredCooldowns_removesExpired() throws Exception {
    injectCooldown(alice, "wave", 5, 6000); // 过期
    injectCooldown(bob, "bow", 5, 0); // 未过期

    manager.cleanupExpiredCooldowns();

    assertFalse(manager.isOnCooldown(alice, "wave"));
    assertTrue(manager.isOnCooldown(bob, "bow"));
  }

  @Test
  @DisplayName("getActiveCooldownCount 返回有冷却的玩家数")
  void getActiveCooldownCount_returnsPlayerCount() {
    assertEquals(0, manager.getActiveCooldownCount());

    manager.startCooldown(alice, "wave");
    assertEquals(1, manager.getActiveCooldownCount());

    manager.startCooldown(bob, "wave");
    assertEquals(2, manager.getActiveCooldownCount());

    manager.clearPlayerCooldowns(alice);
    assertEquals(1, manager.getActiveCooldownCount());
  }

  // ===== 格式化 =====

  @Test
  @DisplayName("formatCooldownTime 正确格式化秒和分钟")
  void formatCooldownTime_formats() {
    assertEquals("5秒", manager.formatCooldownTime(5));
    assertEquals("60秒", manager.formatCooldownTime(60));
    assertEquals("1分59秒", manager.formatCooldownTime(119));
    assertEquals("2分钟", manager.formatCooldownTime(120));
    assertEquals("1分30秒", manager.formatCooldownTime(90));
  }

  // ===== 序列化 =====

  @Test
  @DisplayName("serialize 返回正确结构的 Map")
  void serialize_returnsCorrectStructure() throws Exception {
    manager.startCooldown(alice, "wave");
    injectCooldown(bob, "bow", 5, 0);

    Map<String, Object> data = manager.serialize();

    assertTrue(data.containsKey("playerCooldowns"));
  }

  @Test
  @DisplayName("deserialize 正确恢复数据")
  void deserialize_restoresData() throws Exception {
    // 先写入
    manager.startCooldown(alice, "wave");
    Map<String, Object> data = manager.serialize();

    // 新建 manager 并反序列化
    EmoteCooldownManager restored = new EmoteCooldownManager();
    restored.deserialize(data);

    assertTrue(restored.isOnCooldown(alice, "wave"));
    assertFalse(restored.isOnCooldown(bob, "bow")); // 不会因为 bob 在旧数据而创建
  }

  @Test
  @DisplayName("deserialize 跳过损坏条目不抛异常")
  void deserialize_toleratesCorruption() {
    Map<String, Object> badData =
        Map.of(
            "playerCooldowns",
            List.of(
                Map.of("playerId", alice.toString(), "cooldowns", List.of("wave:not_a_number"))));

    // 不应抛异常
    assertDoesNotThrow(() -> manager.deserialize(badData));
  }

  @Test
  @DisplayName("deserialize 处理 null playerCooldowns")
  void deserialize_nullPlayerCooldowns_noCrash() {
    // Map.of 不接受 null value，用 HashMap 替代
    Map<String, Object> data = new HashMap<>();
    data.put("playerCooldowns", null);

    assertDoesNotThrow(() -> manager.deserialize(data));
  }

  // ===== D-047 lastIndexOf 容忍含冒号的 emoteId =====

  @Test
  @DisplayName("deserialize 正确处理含冒号的 emoteId（D-047）")
  void deserialize_handlesEmoteIdWithColon() throws Exception {
    // 模拟 emoteId 含有冒号的数据
    // 使用未来的时间戳确保冷却未过期
    long futureTs = System.currentTimeMillis() + 60_000L;
    Map<String, Object> data =
        Map.of(
            "playerCooldowns",
            List.of(
                Map.of(
                    "playerId", alice.toString(),
                    "cooldowns", List.of("custom:emote:wave:" + futureTs))));

    manager.deserialize(data);

    // 应该能正确解析出 emoteId = "custom:emote:wave"，timestamp = futureTs
    assertTrue(manager.isOnCooldown(alice, "custom:emote:wave"), "含冒号的 emoteId 应被正确解析");
  }

  // ===== 助手：直接操作私有 playerCooldowns Map =====

  /** 注入一个已过期的冷却记录（仅用于测试过期清理逻辑）。 通过反射设置 playerCooldowns，不触发 startCooldown。 */
  @SuppressWarnings("unchecked")
  private void injectExpiredCooldown(UUID playerId, String emoteId, long msAgo) throws Exception {
    var field = EmoteCooldownManager.class.getDeclaredField("playerCooldowns");
    field.setAccessible(true);
    @SuppressWarnings("unchecked")
    Map<UUID, Map<String, Long>> map = (Map<UUID, Map<String, Long>>) field.get(manager);
    map.putIfAbsent(playerId, new java.util.concurrent.ConcurrentHashMap<>());
    map.get(playerId).put(emoteId, System.currentTimeMillis() - msAgo);
  }

  /**
   * 注入一个指定 elapsed 和 cooldown 的冷却记录。
   *
   * @param cooldownMs 冷却时长（毫秒）
   * @param elapsedMs 经过的时间（毫秒）
   */
  @SuppressWarnings("unchecked")
  private void injectCooldown(UUID playerId, String emoteId, long cooldownMs, long elapsedMs)
      throws Exception {
    var field = EmoteCooldownManager.class.getDeclaredField("playerCooldowns");
    field.setAccessible(true);
    @SuppressWarnings("unchecked")
    Map<UUID, Map<String, Long>> map = (Map<UUID, Map<String, Long>>) field.get(manager);
    map.putIfAbsent(playerId, new java.util.concurrent.ConcurrentHashMap<>());
    // startTime = now - elapsed，冷却时长由调用方在测试中断言时使用
    map.get(playerId).put(emoteId, System.currentTimeMillis() - elapsedMs);
  }
}
