package dev.starcore.starcore.social.party;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.social.SqlSocialStateStorage;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class PartyServicePersistenceIsolationTest {
  @TempDir Path directory;
  private final Clock clock = Clock.fixed(Instant.parse("2026-11-26T00:00:00Z"), ZoneOffset.UTC);

  private PartyService service(SqlSocialStateStorage storage) {
    Plugin plugin = mock(Plugin.class);
    when(plugin.getDataFolder()).thenReturn(directory.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    PartyService service = new PartyService(clock);
    service.initialize(plugin);
    service.setSqlStorage(storage);
    return service;
  }

  private Fixture database() {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + directory.resolve("social.db"));
    DatabaseService database = mock(DatabaseService.class);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.isRunning()).thenReturn(true);
    SqlSocialStateStorage storage =
        new SqlSocialStateStorage(database, Logger.getAnonymousLogger());
    storage.ensureTables();
    return new Fixture(source, database, storage);
  }

  private Path partiesFile() {
    return directory.resolve("social/parties.yml");
  }

  private Path invitesFile() {
    return directory.resolve("social/party-invites.yml");
  }

  private String yamlParty(UUID partyId, UUID leader, List<UUID> members, int capacity) {
    StringBuilder yaml = new StringBuilder(partyId + ":\n  leader: " + leader + "\n  members:\n");
    for (UUID member : members) yaml.append("  - ").append(member).append('\n');
    return yaml.append(
            "  createdTime: 1234\n  friendlyFire: true\n  expShare: false\n  maxMembers: ")
        .append(capacity)
        .append('\n')
        .toString();
  }

  @Test
  void corruptYamlOnFirstLoadBlocksWritesUntilACompleteSuccessfulReload() throws Exception {
    PartyService service = service(null);
    String corrupt = "parties: [unterminated\n";
    Files.writeString(partiesFile(), corrupt);
    Files.writeString(invitesFile(), "{}\n");

    service.loadData();

    assertThat(service.getAllParties()).isEmpty();
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.createParty(UUID.randomUUID()))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(
            () -> service.savePartyToDatabase(new Party(UUID.randomUUID(), UUID.randomUUID())))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.deletePartyFromDatabase(UUID.randomUUID()))
        .isInstanceOf(IllegalStateException.class);
    assertThat(Files.readString(partiesFile())).isEqualTo(corrupt);
    assertThat(Files.readString(invitesFile())).isEqualTo("{}\n");

    Files.writeString(partiesFile(), "{}\n");
    service.loadData();
    UUID leader = UUID.randomUUID();
    service.createParty(leader);
    PartyService reopened = service(null);
    reopened.loadData();
    assertThat(reopened.getPlayerParty(leader)).isNotNull();
  }

  @Test
  void corruptInvitesCannotPublishAnOtherwiseValidReplacementPartySnapshot() throws Exception {
    PartyService service = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party original = service.createParty(leader);
    service.inviteMember(original.getId(), leader, target);
    UUID replacement = UUID.randomUUID(), replacementLeader = UUID.randomUUID();
    String replacementYaml =
        yamlParty(replacement, replacementLeader, List.of(replacementLeader), 8);
    String corrupt = "invites: [unterminated\n";
    Files.writeString(partiesFile(), replacementYaml);
    Files.writeString(invitesFile(), corrupt);

    service.loadData();

    assertThat(service.getPlayerParty(leader)).isSameAs(original);
    assertThat(service.getPlayerParty(replacementLeader)).isNull();
    assertThat(service.getPartyInvites(target)).containsExactly(leader);
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
    assertThat(Files.readString(partiesFile())).isEqualTo(replacementYaml);
    assertThat(Files.readString(invitesFile())).isEqualTo(corrupt);
  }

  @Test
  void malformedMemberValuesAreNotSilentlyDiscardedAndSavedOver() throws Exception {
    PartyService service = service(null);
    UUID partyId = UUID.randomUUID(), leader = UUID.randomUUID();
    String malformed = partyId + ":\n  leader: " + leader + "\n  members: [123, " + leader + "]\n";
    Files.writeString(partiesFile(), malformed);

    service.loadData();

    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThat(Files.readString(partiesFile())).isEqualTo(malformed);
  }

  @Test
  void duplicateMembershipValidationDoesNotPublishOrOverwriteEitherParty() throws Exception {
    PartyService service = service(null);
    UUID first = UUID.randomUUID(), second = UUID.randomUUID();
    UUID firstLeader = UUID.randomUUID(),
        secondLeader = UUID.randomUUID(),
        shared = UUID.randomUUID();
    String invalid =
        yamlParty(first, firstLeader, List.of(firstLeader, shared), 8)
            + yamlParty(second, secondLeader, List.of(secondLeader, shared), 8);
    Files.writeString(partiesFile(), invalid);

    service.loadData();

    assertThat(service.getAllParties()).isEmpty();
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThat(Files.readString(partiesFile())).isEqualTo(invalid);
  }

  @Test
  void yamlRoundTripRetainsMembersAboveTheConfiguredLimitAndOriginalCreationTime()
      throws Exception {
    PartyService service = service(null);
    UUID partyId = UUID.randomUUID(), leader = UUID.randomUUID();
    List<UUID> members = List.of(leader, UUID.randomUUID(), UUID.randomUUID());
    Files.writeString(partiesFile(), yamlParty(partyId, leader, members, 2));

    service.loadData();
    service.saveData();
    PartyService reopened = service(null);
    reopened.loadData();

    Party restored = reopened.getPlayerParty(leader);
    assertThat(restored.getMembers()).containsExactlyInAnyOrderElementsOf(members);
    assertThat(restored.getMaxMembers()).isEqualTo(2);
    assertThat(restored.getCreatedTime()).isEqualTo(1234L);
    assertThat(restored.isFriendlyFire()).isTrue();
    assertThat(restored.isExpShare()).isFalse();
    for (UUID member : members) assertThat(reopened.getPlayerParty(member)).isSameAs(restored);
  }

  @Test
  void sqlRoundTripRetainsMembersAboveTheConfiguredLimitAndOriginalCreationTime() {
    Fixture fixture = database();
    UUID leader = UUID.randomUUID();
    Party original = new Party(UUID.randomUUID(), leader, 1234L);
    UUID second = UUID.randomUUID(), third = UUID.randomUUID();
    original.addMember(second);
    original.addMember(third);
    original.setMaxMembers(2);
    fixture.storage().saveParty(original);
    PartyService service = service(fixture.storage());

    service.loadData();
    service.saveData();
    PartyService reopened = service(fixture.storage());
    reopened.loadData();

    Party restored = reopened.getPlayerParty(leader);
    assertThat(restored.getMembers()).containsExactlyInAnyOrder(leader, second, third);
    assertThat(restored.getMaxMembers()).isEqualTo(2);
    assertThat(restored.getCreatedTime()).isEqualTo(1234L);
    assertThat(reopened.getPlayerParty(third)).isSameAs(restored);
  }

  @Test
  void configuredSqlBackendNeverFallsBackToAnOlderYamlSnapshot() throws Exception {
    UUID yamlLeader = UUID.randomUUID();
    service(null).createParty(yamlLeader);
    String originalYaml = Files.readString(partiesFile());
    Fixture fixture = database();
    UUID sqlLeader = UUID.randomUUID();
    fixture.storage().saveParty(new Party(UUID.randomUUID(), sqlLeader));
    when(fixture.database().isRunning()).thenReturn(false);
    PartyService service = service(fixture.storage());
    service.loadData();
    assertThat(service.getPlayerParty(sqlLeader)).isNotNull();
    assertThat(service.getPlayerParty(yamlLeader)).isNull();

    when(fixture.database().dataSource()).thenReturn(Optional.empty());
    service.loadData();

    assertThat(service.getPlayerParty(sqlLeader)).isNotNull();
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThat(Files.readString(partiesFile())).isEqualTo(originalYaml);
  }

  @Test
  void failedSqlInviteReadCannotReplacePartiesOrPermitADeleteAllSave() throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party original = service.createParty(leader);
    service.inviteMember(original.getId(), leader, target);
    UUID newLeader = UUID.randomUUID();
    Party replacement = new Party(UUID.randomUUID(), newLeader);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.executeUpdate("DELETE FROM starcore_party_members");
      statement.executeUpdate("DELETE FROM starcore_parties");
      statement.executeUpdate("DROP TABLE starcore_party_invites");
    }
    fixture.storage().saveParty(replacement);

    service.loadData();

    assertThat(service.getPlayerParty(leader)).isSameAs(original);
    assertThat(service.getPlayerParty(newLeader)).isNull();
    assertThat(service.getPartyInvites(target)).containsExactly(leader);
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    Map<UUID, Party> stored = new HashMap<>();
    fixture.storage().loadAllParties(stored, new HashMap<>());
    assertThat(stored).containsOnlyKeys(replacement.getId());
  }

  @Test
  void malformedSqlMemberDoesNotPublishTheEarlierRows() throws Exception {
    Fixture fixture = database();
    Party valid = new Party(UUID.randomUUID(), UUID.randomUUID());
    fixture.storage().saveParty(valid);
    UUID brokenParty = UUID.randomUUID(), brokenLeader = UUID.randomUUID();
    try (Connection connection = fixture.source().getConnection();
        PreparedStatement party =
            connection.prepareStatement(
                "INSERT INTO starcore_parties (id, leader_uuid, created_at, friendly_fire,"
                    + " exp_share, max_members) VALUES (?, ?, 1, 0, 1, 8)");
        PreparedStatement member =
            connection.prepareStatement(
                "INSERT INTO starcore_party_members (party_id, player_uuid, joined_at) VALUES (?,"
                    + " 'invalid-uuid', 1)")) {
      party.setString(1, brokenParty.toString());
      party.setString(2, brokenLeader.toString());
      party.executeUpdate();
      member.setString(1, brokenParty.toString());
      member.executeUpdate();
    }
    Party sentinel = new Party(UUID.randomUUID(), UUID.randomUUID());
    Map<UUID, Party> loaded = new HashMap<>(Map.of(sentinel.getId(), sentinel));
    Map<UUID, UUID> memberships = new HashMap<>(Map.of(sentinel.getLeader(), sentinel.getId()));

    assertThatThrownBy(() -> fixture.storage().loadAllParties(loaded, memberships))
        .isInstanceOf(IllegalStateException.class);

    assertThat(loaded).containsOnlyKeys(sentinel.getId());
    assertThat(memberships)
        .containsExactlyEntriesOf(Map.of(sentinel.getLeader(), sentinel.getId()));
  }

  @Test
  void sqlIterationFailureDoesNotExposeAPartialSnapshot() throws Exception {
    DataSource source = mock(DataSource.class);
    DatabaseService database = mock(DatabaseService.class);
    Connection connection = mock(Connection.class);
    Statement statement = mock(Statement.class);
    PreparedStatement memberStatement = mock(PreparedStatement.class);
    ResultSet rows = mock(ResultSet.class), members = mock(ResultSet.class);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(source.getConnection()).thenReturn(connection);
    when(connection.createStatement()).thenReturn(statement);
    when(statement.executeQuery("SELECT * FROM starcore_parties")).thenReturn(rows);
    when(connection.prepareStatement("SELECT * FROM starcore_party_members WHERE party_id = ?"))
        .thenReturn(memberStatement);
    when(memberStatement.executeQuery()).thenReturn(members);
    UUID partyId = UUID.randomUUID(), leader = UUID.randomUUID();
    when(rows.next()).thenReturn(true).thenThrow(new SQLException("interrupted after first row"));
    when(rows.getString("id")).thenReturn(partyId.toString());
    when(rows.getString("leader_uuid")).thenReturn(leader.toString());
    when(rows.getInt("max_members")).thenReturn(8);
    when(members.next()).thenReturn(true, false);
    when(members.getString("player_uuid")).thenReturn(leader.toString());
    SqlSocialStateStorage storage =
        new SqlSocialStateStorage(database, Logger.getAnonymousLogger());
    Map<UUID, Party> loaded = new HashMap<>();
    Map<UUID, UUID> memberships = new HashMap<>();

    assertThatThrownBy(() -> storage.loadAllParties(loaded, memberships))
        .isInstanceOf(IllegalStateException.class)
        .hasCauseInstanceOf(SQLException.class);

    assertThat(loaded).isEmpty();
    assertThat(memberships).isEmpty();
  }

  @Test
  void acceptingYamlInvitationPersistsMembershipWithoutASeparateSave() {
    PartyService service = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party original = service.createParty(leader);
    service.inviteMember(original.getId(), leader, target);

    assertThat(service.acceptInvite(target, leader)).isTrue();
    PartyService reopened = service(null);
    reopened.loadData();

    assertThat(reopened.getPlayerParty(target).getId()).isEqualTo(original.getId());
    assertThat(reopened.getPartyInvites(target)).isEmpty();
  }

  @Test
  void failedYamlMembershipWriteRetainsTheInvitationAndRollsBackMemory() throws Exception {
    PartyService service = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    String originalParty = Files.readString(partiesFile()),
        originalInvite = Files.readString(invitesFile());
    Path backup = directory.resolve("parties.backup");
    Files.move(partiesFile(), backup);
    Files.createDirectory(partiesFile());
    Files.writeString(partiesFile().resolve("blocker"), "blocker");

    assertThatThrownBy(() -> service.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);

    assertThat(party.isMember(target)).isFalse();
    assertThat(service.getPlayerParty(target)).isNull();
    assertThat(service.getPartyInvites(target)).containsExactly(leader);
    assertThat(Files.readString(backup)).isEqualTo(originalParty);
    assertThat(Files.readString(invitesFile())).isEqualTo(originalInvite);
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    Files.delete(partiesFile().resolve("blocker"));
    Files.delete(partiesFile());
    Files.move(backup, partiesFile());
    service.loadData();
    assertThat(service.acceptInvite(target, leader)).isTrue();
  }

  @Test
  void staleYamlInviteAfterCleanupFailureCannotUndoDurableAcceptance() throws Exception {
    PartyService service = service(null);
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    Path backup = directory.resolve("invites.backup");
    Files.move(invitesFile(), backup);
    Files.createDirectory(invitesFile());
    Files.writeString(invitesFile().resolve("blocker"), "blocker");

    assertThat(service.acceptInvite(target, leader)).isTrue();

    assertThat(service.getPlayerParty(target)).isSameAs(party);
    Files.delete(invitesFile().resolve("blocker"));
    Files.delete(invitesFile());
    Files.move(backup, invitesFile());
    PartyService reopened = service(null);
    reopened.loadData();
    assertThat(reopened.getPlayerParty(target).getId()).isEqualTo(party.getId());
    assertThat(reopened.getPartyInvites(target)).isEmpty();
    assertThatThrownBy(() -> reopened.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void sqlAcceptFailureRollsBackMembershipAndPreservesTheInviteForRetry() throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_party_accept BEFORE DELETE ON starcore_party_invites "
              + "BEGIN SELECT RAISE(ABORT, 'blocked'); END");
    }

    assertThatThrownBy(() -> service.acceptInvite(target, leader))
        .isInstanceOf(IllegalStateException.class);

    assertThat(party.isMember(target)).isFalse();
    assertThat(service.getPlayerParty(target)).isNull();
    assertThat(service.getPartyInvites(target)).containsExactly(leader);
    PartyService reopened = service(fixture.storage());
    reopened.loadData();
    assertThat(reopened.getPlayerParty(target)).isNull();
    assertThat(reopened.getPartyInvites(target)).containsExactly(leader);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute("DROP TRIGGER reject_party_accept");
    }
    assertThat(service.acceptInvite(target, leader)).isTrue();
    reopened.loadData();
    assertThat(reopened.getPlayerParty(target).getId()).isEqualTo(party.getId());
    assertThat(reopened.getPartyInvites(target)).isEmpty();
  }

  @Test
  void failedSqlMemberUpdatesDoNotChangeMembershipOrLeadershipBeforeDurableSuccess()
      throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), member = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, member);
    service.acceptInvite(member, leader);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_party_update BEFORE UPDATE ON starcore_parties "
              + "BEGIN SELECT RAISE(ABORT, 'blocked'); END");
    }

    assertThatThrownBy(() -> service.kickMember(party.getId(), leader, member))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.leaveParty(member)).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.transferLeadership(party.getId(), leader, member))
        .isInstanceOf(IllegalStateException.class);
    try (var bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getOfflinePlayer(member)).thenReturn(mock(OfflinePlayer.class));
      assertThatThrownBy(() -> service.leaveParty(leader))
          .isInstanceOf(IllegalStateException.class);
    }

    assertThat(party.getLeader()).isEqualTo(leader);
    assertThat(party.getMembers()).containsExactlyInAnyOrder(leader, member);
    assertThat(service.getPlayerParty(leader)).isSameAs(party);
    assertThat(service.getPlayerParty(member)).isSameAs(party);
    service.saveData();
    PartyService reopened = service(fixture.storage());
    reopened.loadData();
    assertThat(reopened.getPlayerParty(member).getLeader()).isEqualTo(leader);
    assertThat(reopened.getPlayerParty(leader).getMembers())
        .containsExactlyInAnyOrder(leader, member);
  }

  @Test
  void failedSqlDisbandRestoresTheMemberRowsAndKeepsThePublishedParty() throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), member = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, member);
    service.acceptInvite(member, leader);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_party_delete BEFORE DELETE ON starcore_parties "
              + "BEGIN SELECT RAISE(ABORT, 'blocked'); END");
    }

    assertThatThrownBy(() -> service.disbandParty(party.getId(), leader))
        .isInstanceOf(IllegalStateException.class);

    assertThat(service.getAllParties()).containsExactly(party);
    assertThat(service.getPlayerParty(member)).isSameAs(party);
    Map<UUID, Party> stored = new HashMap<>();
    fixture.storage().loadAllParties(stored, new HashMap<>());
    assertThat(stored.get(party.getId()).getMembers()).containsExactlyInAnyOrder(leader, member);
    try (Connection connection = fixture.source().getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute("DROP TRIGGER reject_party_delete");
    }
    service.saveData();
    PartyService reopened = service(fixture.storage());
    reopened.loadData();
    assertThat(reopened.getPlayerParty(member).getId()).isEqualTo(party.getId());
  }

  @Test
  void commitThatSucceedsThenThrowsBlocksOldMemoryFromOverwritingTheDurableMembership()
      throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    throwAfterSuccessfulCall(fixture, "commit");

    assertThatThrownBy(() -> service.acceptInvite(target, leader))
        .isInstanceOf(SqlSocialStateStorage.PartyPersistenceException.class);

    assertThat(service.getPlayerParty(target)).isNull();
    assertThatThrownBy(service::saveData).isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> service.createParty(UUID.randomUUID()))
        .isInstanceOf(IllegalStateException.class);
    service.loadData();
    assertThat(service.getPlayerParty(target).getId()).isEqualTo(party.getId());
    assertThat(service.getPartyInvites(target)).isEmpty();
    service.saveData();
  }

  @Test
  void closeFailureAfterSuccessfulCommitDoesNotReportTheDurableAcceptAsFailed() throws Exception {
    Fixture fixture = database();
    PartyService service = service(fixture.storage());
    UUID leader = UUID.randomUUID(), target = UUID.randomUUID();
    Party party = service.createParty(leader);
    service.inviteMember(party.getId(), leader, target);
    throwAfterSuccessfulCall(fixture, "close");

    assertThat(service.acceptInvite(target, leader)).isTrue();

    assertThat(service.getPlayerParty(target)).isSameAs(party);
    service.saveData();
    PartyService reopened = service(fixture.storage());
    reopened.loadData();
    assertThat(reopened.getPlayerParty(target).getId()).isEqualTo(party.getId());
    assertThat(reopened.getPartyInvites(target)).isEmpty();
  }

  private void throwAfterSuccessfulCall(Fixture fixture, String methodName) throws SQLException {
    DataSource source = mock(DataSource.class);
    AtomicBoolean pending = new AtomicBoolean(true);
    when(source.getConnection())
        .thenAnswer(
            ignored -> {
              Connection connection = fixture.source().getConnection();
              return Proxy.newProxyInstance(
                  Connection.class.getClassLoader(),
                  new Class<?>[] {Connection.class},
                  (proxy, method, arguments) -> {
                    Object result;
                    try {
                      result = method.invoke(connection, arguments);
                    } catch (InvocationTargetException failure) {
                      throw failure.getCause();
                    }
                    if (method.getName().equals(methodName) && pending.compareAndSet(true, false)) {
                      throw new SQLException("failure after successful " + methodName);
                    }
                    return result;
                  });
            });
    when(fixture.database().dataSource()).thenReturn(Optional.of(source));
  }

  private record Fixture(
      SQLiteDataSource source, DatabaseService database, SqlSocialStateStorage storage) {}
}
