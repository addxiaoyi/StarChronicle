package dev.starcore.starcore.social.guild;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * 公会权限与边界测试 - 验证权限校验、空值处理、ID 不存在等边界情况， 以及邀请与加入流程中的竞态和边界条件。
 *
 * <p>测试不依赖任何外部服务（数据库/YAML/插件），仅验证 GuildService 内部状态机逻辑。
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("公会权限与边界测试")
class GuildServicePermissionsTest {

  private GuildService guildService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();
  private final UUID carol = UUID.randomUUID();
  private final UUID dave = UUID.randomUUID();
  private final UUID eve = UUID.randomUUID();

  private Guild guild;

  @BeforeEach
  void setUp() {
    guildService = new GuildService();
    guild = guildService.createGuild(alice, "Alpha", "[A]");
  }

  private void joinGuild(UUID playerId) {
    guildService.inviteMember(guild.getId(), alice, playerId);
    guildService.acceptInvite(playerId, guild.getId());
  }

  // ===== 权限校验：inviteMember =====

  @Test
  @DisplayName("inviteMember: 非公会成员不能邀请")
  void inviteMember_nonMember_throws() {
    assertThrows(
        IllegalStateException.class, () -> guildService.inviteMember(guild.getId(), bob, carol));
  }

  @Test
  @DisplayName("inviteMember: 普通成员不能邀请")
  void inviteMember_memberCannotInvite_throws() {
    joinGuild(bob);

    assertThrows(
        IllegalStateException.class, () -> guildService.inviteMember(guild.getId(), bob, carol));
  }

  @Test
  @DisplayName("inviteMember: 目标已有邀请时不能重复邀请")
  void inviteMember_duplicateInvite_throws() {
    guildService.inviteMember(guild.getId(), alice, bob);
    assertThrows(
        IllegalStateException.class, () -> guildService.inviteMember(guild.getId(), alice, bob));
  }

  @Test
  @DisplayName("inviteMember: 已被踢出的玩家可以重新被邀请")
  void inviteMember_kickedCanBeReinvited() {
    joinGuild(bob);
    guildService.kickMember(guild.getId(), alice, bob);

    assertTrue(guildService.inviteMember(guild.getId(), alice, bob), "被踢出后可重新邀请");
  }

  @Test
  @DisplayName("inviteMember: 离开公会的玩家可以重新被邀请")
  void inviteMember_leftCanBeReinvited() {
    joinGuild(bob);
    guildService.leaveGuild(bob);

    assertTrue(guildService.inviteMember(guild.getId(), alice, bob), "离开后可重新邀请");
  }

  // ===== 权限校验：acceptInvite =====

  @Test
  @DisplayName("acceptInvite: 玩家已有公会时不能接受其他公会邀请")
  void acceptInvite_alreadyInGuild_throws() {
    // bob 已在 Alpha
    joinGuild(bob);
    // Alpha 邀请 carol
    guildService.inviteMember(guild.getId(), alice, carol);
    // carol 创建了 Beta（carol 已是 Beta 会长）
    Guild beta = guildService.createGuild(carol, "Beta", "[B]");

    assertThrows(
        IllegalStateException.class,
        () -> guildService.acceptInvite(carol, guild.getId()),
        "carol 已有 Beta，不能接受 Alpha 的邀请");
  }

  @Test
  @DisplayName("acceptInvite: 不存在的公会邀请应抛出异常")
  void acceptInvite_nonexistentInvite_throws() {
    assertThrows(IllegalStateException.class, () -> guildService.acceptInvite(bob, guild.getId()));
  }

  // ===== 权限校验：kickMember =====

  @Test
  @DisplayName("kickMember: 非成员不能踢人")
  void kickMember_nonMember_throws() {
    assertThrows(
        IllegalStateException.class, () -> guildService.kickMember(guild.getId(), bob, alice));
  }

  @Test
  @DisplayName("kickMember: 普通成员不能踢人")
  void kickMember_memberCannotKick_throws() {
    joinGuild(bob);
    joinGuild(carol);

    assertThrows(
        IllegalStateException.class, () -> guildService.kickMember(guild.getId(), bob, carol));
  }

  @Test
  @DisplayName("kickMember: 踢出会长应抛出异常（需先转让）")
  void kickMember_leader_throws() {
    assertThrows(
        IllegalStateException.class, () -> guildService.kickMember(guild.getId(), alice, alice));
  }

  @Test
  @DisplayName("kickMember: 踢出自己应抛出异常（需使用离开）")
  void kickMember_self_throws() {
    joinGuild(bob);

    assertThrows(
        IllegalStateException.class, () -> guildService.kickMember(guild.getId(), bob, bob));
  }

  @Test
  @DisplayName("kickMember: 目标不是公会成员应抛出异常")
  void kickMember_targetNotInGuild_throws() {
    assertThrows(
        IllegalStateException.class, () -> guildService.kickMember(guild.getId(), alice, bob));
  }

  @Test
  @DisplayName("kickMember: 踢出后目标可以接受同一公会的邀请重新加入")
  void kickMember_kickedCanRejoin() {
    joinGuild(bob);
    guildService.kickMember(guild.getId(), alice, bob);

    assertTrue(guildService.inviteMember(guild.getId(), alice, bob));
    assertTrue(guildService.acceptInvite(bob, guild.getId()));
    assertTrue(guild.isMember(bob));
  }

  // ===== 权限校验：leaveGuild =====

  @Test
  @DisplayName("leaveGuild: 非成员离开应返回 false")
  void leaveGuild_nonMember_returnsFalse() {
    assertFalse(guildService.leaveGuild(bob));
  }

  @Test
  @DisplayName("leaveGuild: 会长离开应抛出异常")
  void leaveGuild_leader_throws() {
    assertThrows(IllegalStateException.class, () -> guildService.leaveGuild(alice));
  }

  @Test
  @DisplayName("leaveGuild: 副会长离开成功")
  void leaveGuild_officer_canLeave() {
    joinGuild(bob);
    guildService.setMemberRole(guild.getId(), alice, bob, GuildRole.OFFICER);

    assertTrue(guildService.leaveGuild(bob));
    assertNull(guildService.getPlayerGuild(bob));
  }

  // ===== 权限校验：transferLeadership =====

  @Test
  @DisplayName("transferLeadership: 非会长转让应抛出异常")
  void transferLeadership_nonLeader_throws() {
    joinGuild(bob);

    assertThrows(
        IllegalStateException.class,
        () -> guildService.transferLeadership(guild.getId(), bob, alice));
  }

  @Test
  @DisplayName("transferLeadership: 转让给非成员应抛出异常")
  void transferLeadership_nonMember_throws() {
    assertThrows(
        IllegalStateException.class,
        () -> guildService.transferLeadership(guild.getId(), alice, bob));
  }

  @Test
  @DisplayName("transferLeadership: 转让给自己应抛出异常")
  void transferLeadership_self_throws() {
    assertThrows(
        IllegalStateException.class,
        () -> guildService.transferLeadership(guild.getId(), alice, alice));
  }

  @Test
  @DisplayName("transferLeadership: 转让后原会长可正常离开")
  void transferLeadership_exLeaderCanLeave() {
    joinGuild(bob);
    guildService.transferLeadership(guild.getId(), alice, bob);

    assertTrue(guildService.leaveGuild(alice), "转让后原会长可正常离开");
    assertNull(guildService.getPlayerGuild(alice));
  }

  // ===== 权限校验：setMemberRole =====

  @Test
  @DisplayName("setMemberRole: 非会长设置职位应抛出异常")
  void setMemberRole_nonLeader_throws() {
    joinGuild(bob);

    assertThrows(
        IllegalStateException.class,
        () -> guildService.setMemberRole(guild.getId(), bob, alice, GuildRole.MEMBER));
  }

  @Test
  @DisplayName("setMemberRole: 会长不能被降职")
  void setMemberRole_leaderCannotBeDemoted_throws() {
    joinGuild(bob);

    assertThrows(
        IllegalStateException.class,
        () -> guildService.setMemberRole(guild.getId(), alice, alice, GuildRole.MEMBER));
  }

  @Test
  @DisplayName("setMemberRole: 设置不存在的成员应返回 false")
  void setMemberRole_targetNotMember_returnsFalse() {
    assertFalse(guildService.setMemberRole(guild.getId(), alice, bob, GuildRole.OFFICER));
  }

  // ===== 解散权限 =====

  @Test
  @DisplayName("disbandGuild: 非会长解散应抛出异常")
  void disbandGuild_nonLeader_throws() {
    joinGuild(bob);

    assertThrows(IllegalStateException.class, () -> guildService.disbandGuild(guild.getId(), bob));
  }

  // ===== 邀请流程边界 =====

  @Test
  @DisplayName("拒绝后可以接受来自同一公会的重新邀请")
  void rejectThenAcceptSameInvite() {
    guildService.inviteMember(guild.getId(), alice, bob);
    assertTrue(guildService.rejectInvite(bob, guild.getId()));

    // 重新邀请
    assertTrue(guildService.inviteMember(guild.getId(), alice, bob));
    assertTrue(guildService.acceptInvite(bob, guild.getId()));

    assertTrue(guild.isMember(bob));
  }

  @Test
  @DisplayName("多个公会同时邀请同一玩家，只有第一个邀请被接受")
  void multipleGuildsInvite_samePlayer_onlyFirstAccepted() {
    // Alpha 邀请 bob
    guildService.inviteMember(guild.getId(), alice, bob);
    // Beta 邀请 bob
    Guild beta = guildService.createGuild(dave, "Beta", "[B]");
    guildService.inviteMember(beta.getId(), dave, bob);

    // bob 接受 Alpha
    assertTrue(guildService.acceptInvite(bob, guild.getId()));

    // bob 再接受 Beta 应失败（已在 Alpha）
    assertThrows(IllegalStateException.class, () -> guildService.acceptInvite(bob, beta.getId()));
  }

  @Test
  @DisplayName("玩家离开后再收到邀请，之前的邀请应无效")
  void leaveThenReinvite_previousInviteInvalid() {
    joinGuild(bob);
    // bob 离开
    guildService.leaveGuild(bob);

    // Alpha 再次邀请 bob
    assertTrue(guildService.inviteMember(guild.getId(), alice, bob));
    assertTrue(guildService.acceptInvite(bob, guild.getId()));

    assertTrue(guild.isMember(bob));
  }

  // ===== 成员转移场景 =====

  @Test
  @DisplayName("转让会长后原会长降为普通成员，无法再执行会长操作")
  void transferLeadership_exLeaderLosesPrivileges() {
    joinGuild(bob);
    guildService.transferLeadership(guild.getId(), alice, bob);
    // alice 现在是普通成员

    assertThrows(
        IllegalStateException.class,
        () -> guildService.inviteMember(guild.getId(), alice, carol),
        "原会长不能再邀请");
    assertThrows(
        IllegalStateException.class,
        () -> guildService.kickMember(guild.getId(), alice, bob),
        "原会长不能再踢人");
    assertThrows(
        IllegalStateException.class,
        () -> guildService.disbandGuild(guild.getId(), alice),
        "原会长不能再解散");
  }

  @Test
  @DisplayName("多次转让会长，最终只有最新会长持有权限")
  void multiTransfer_onlyLatestLeaderHasPrivileges() {
    joinGuild(bob);
    joinGuild(carol);

    // alice -> bob
    guildService.transferLeadership(guild.getId(), alice, bob);
    // bob -> carol
    guildService.transferLeadership(guild.getId(), bob, carol);

    assertEquals(carol, guild.getLeader());
    assertThrows(
        IllegalStateException.class, () -> guildService.inviteMember(guild.getId(), bob, dave));
    assertThrows(
        IllegalStateException.class, () -> guildService.inviteMember(guild.getId(), alice, dave));
    assertTrue(guildService.inviteMember(guild.getId(), carol, dave), "只有最新会长可以邀请");
  }

  // ===== getGuildInvites =====

  @Test
  @DisplayName("getGuildInvites: 无邀请时返回空集合")
  void getGuildInvites_noInvites_returnsEmptySet() {
    assertTrue(guildService.getGuildInvites(bob).isEmpty());
  }

  @Test
  @DisplayName("getGuildInvites: 返回的集合为不可变集合")
  void getGuildInvites_returnsImmutableSet() {
    guildService.inviteMember(guild.getId(), alice, bob);
    Set<GuildService.GuildInvite> invites = guildService.getGuildInvites(bob);

    // 尝试修改应抛出 UnsupportedOperationException
    assertThrows(UnsupportedOperationException.class, () -> invites.clear(), "不应可以修改返回的集合");

    assertFalse(guildService.getGuildInvites(bob).isEmpty(), "不可变集合不应影响内部状态");
  }

  // ===== 极端场景 =====

  @Test
  @DisplayName("公会只剩会长一人时会长的特殊行为")
  void lastMember_alone() {
    assertEquals(1, guild.getMemberCount(), "创建时只有会长一人");

    assertTrue(guild.canInvite(alice), "会长可以邀请");
    assertTrue(guild.canKick(alice), "会长可以踢人（虽然没意义）");
    assertTrue(guild.canManageRoles(alice), "会长可以管理职位");
  }

  @Test
  @DisplayName("不存在的公会 ID 操作应返回 false 或抛出异常")
  void nonexistentGuildId_returnsFalseOrThrows() {
    UUID fakeId = UUID.randomUUID();

    assertFalse(guildService.inviteMember(fakeId, alice, bob));
    assertFalse(guildService.disbandGuild(fakeId, alice));
    assertThrows(IllegalStateException.class, () -> guildService.acceptInvite(bob, fakeId));
    assertFalse(guildService.kickMember(fakeId, alice, bob));
    assertFalse(guildService.transferLeadership(fakeId, alice, bob));
    assertFalse(guildService.setMemberRole(fakeId, alice, bob, GuildRole.OFFICER));
  }

  @Test
  @DisplayName("转让后再踢出原会长的场景")
  void transferAndKickExLeader() {
    joinGuild(bob);
    guildService.transferLeadership(guild.getId(), alice, bob);
    // bob 是新会长，alice 是普通成员

    assertTrue(guildService.kickMember(guild.getId(), bob, alice), "新会长可以踢出原会长");
    assertFalse(guild.isMember(alice));
  }
}
