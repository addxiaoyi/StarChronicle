package dev.starcore.starcore.social.emote;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("EmoteDefinition Tests")
class EmoteDefinitionTest {

  @Test
  @DisplayName("builder builds with all defaults")
  void shouldBuildWithDefaults() {
    EmoteDefinition emote = EmoteDefinition.builder().build();

    assertThat(emote.getId()).isNull();
    assertThat(emote.getName()).isNull();
    assertThat(emote.getDescription()).isEqualTo("");
    assertThat(emote.getAnimationType()).isEqualTo("pose");
    assertThat(emote.getAnimationData()).isEqualTo("");
    assertThat(emote.getDurationTicks()).isEqualTo(40);
    assertThat(emote.getCooldownSeconds()).isEqualTo(5);
    assertThat(emote.requiresTarget()).isFalse();
    assertThat(emote.isGlobal()).isTrue();
    assertThat(emote.getPermission()).isEqualTo("");
    assertThat(emote.getCategory()).isEqualTo("emotion");
  }

  @Test
  @DisplayName("builder sets all fields")
  void shouldSetAllFields() {
    EmoteDefinition emote =
        EmoteDefinition.builder()
            .id("wave")
            .name("Wave")
            .description("Wave hello")
            .animationType("arm")
            .animationData("ARM_RAISE")
            .durationTicks(40)
            .cooldownSeconds(3)
            .requiresTarget(true)
            .isGlobal(false)
            .permission("starcore.emote.wave")
            .category("greeting")
            .build();

    assertThat(emote.getId()).isEqualTo("wave");
    assertThat(emote.getName()).isEqualTo("Wave");
    assertThat(emote.getDescription()).isEqualTo("Wave hello");
    assertThat(emote.getAnimationType()).isEqualTo("arm");
    assertThat(emote.getAnimationData()).isEqualTo("ARM_RAISE");
    assertThat(emote.getDurationTicks()).isEqualTo(40);
    assertThat(emote.getCooldownSeconds()).isEqualTo(3);
    assertThat(emote.requiresTarget()).isTrue();
    assertThat(emote.isGlobal()).isFalse();
    assertThat(emote.getPermission()).isEqualTo("starcore.emote.wave");
    assertThat(emote.getCategory()).isEqualTo("greeting");
  }
}
