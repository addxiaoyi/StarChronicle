package dev.starcore.starcore.essentials.social;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;
import java.util.concurrent.*;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;

class SocialStateConcurrencyTest {
  @Test
  void simultaneousSendersAndReadersKeepBoundedDetachedHistories() throws Exception {
    SocialService service = new SocialService();
    UUID recipientId = UUID.randomUUID();
    Player recipient = player(recipientId, "Recipient");
    try (ExecutorService pool = Executors.newFixedThreadPool(6)) {
      CountDownLatch start = new CountDownLatch(1);
      List<Future<?>> workers = new ArrayList<>();
      for (int worker = 0; worker < 5; worker++) {
        int index = worker;
        Player sender = player(UUID.randomUUID(), "Sender" + index);
        workers.add(
            pool.submit(
                () -> {
                  await(start);
                  for (int i = 0; i < 200; i++)
                    assertTrue(service.sendMessage(sender, recipient, index + ":" + i));
                }));
      }
      workers.add(
          pool.submit(
              () -> {
                await(start);
                for (int i = 0; i < 500; i++) {
                  List<SocialService.Message> snapshot = service.getMessageHistory(recipientId);
                  assertTrue(snapshot.size() <= 10);
                  assertEquals(snapshot.size(), new HashSet<>(snapshot).size());
                  assertTrue(snapshot.stream().allMatch(m -> m.recipientId().equals(recipientId)));
                }
              }));
      start.countDown();
      for (Future<?> worker : workers) worker.get(10, TimeUnit.SECONDS);
    }
    assertEquals(10, service.getMessageHistory(recipientId).size());
    List<SocialService.Message> captured = service.getMessageHistory(recipientId);
    service.cleanup(recipientId);
    assertEquals(10, captured.size());
    assertTrue(service.getMessageHistory(recipientId).isEmpty());
    assertThrows(UnsupportedOperationException.class, captured::clear);
  }

  @Test
  void slowLoadNeverPublishesPartialIgnoreState() throws Exception {
    SocialService service = new SocialService();
    UUID player = UUID.randomUUID(), previous = UUID.randomUUID(), replacement = UUID.randomUUID();
    service.loadPlayerData(player, Set.of(previous));
    CountDownLatch copying = new CountDownLatch(1), release = new CountDownLatch(1);
    Set<UUID> slow =
        new AbstractSet<>() {
          @Override
          public int size() {
            return 1;
          }

          @Override
          public Iterator<UUID> iterator() {
            return new Iterator<>() {
              boolean available = true;

              @Override
              public boolean hasNext() {
                return available;
              }

              @Override
              public UUID next() {
                copying.countDown();
                await(release);
                available = false;
                return replacement;
              }
            };
          }
        };
    try (ExecutorService pool = Executors.newSingleThreadExecutor()) {
      Future<?> task = pool.submit(() -> service.loadPlayerData(player, slow));
      try {
        assertTrue(copying.await(5, TimeUnit.SECONDS));
        assertEquals(Set.of(previous), service.getPlayerData(player));
      } finally {
        release.countDown();
      }
      task.get(5, TimeUnit.SECONDS);
    }
    assertEquals(Set.of(replacement), service.getPlayerData(player));
  }

  @Test
  void emptyReloadReplacesPriorIgnoreStateAndRemainsSaveable() {
    SocialService service = new SocialService();
    UUID player = UUID.randomUUID();
    service.loadPlayerData(player, Set.of(UUID.randomUUID()));
    service.loadPlayerData(player, Set.of());
    assertEquals(Set.of(), service.getPlayerData(player));
    assertTrue(service.getKnownPlayerIds().contains(player));
  }

  @Test
  void failedReloadPreservesPreviouslyPublishedState() {
    SocialService service = new SocialService();
    UUID player = UUID.randomUUID(), ignored = UUID.randomUUID();
    service.loadPlayerData(player, Set.of(ignored));
    Set<UUID> invalid = new HashSet<>();
    invalid.add(null);
    assertThrows(NullPointerException.class, () -> service.loadPlayerData(player, invalid));
    assertEquals(Set.of(ignored), service.getPlayerData(player));
  }

  @Test
  void transportCallsDoNotHoldSocialStateLock() {
    SocialService service = new SocialService();
    Player sender = player(UUID.randomUUID(), "Sender"),
        recipient = player(UUID.randomUUID(), "Recipient");
    doAnswer(
            i -> {
              assertFalse(Thread.holdsLock(service));
              return null;
            })
        .when(sender)
        .sendMessage(anyString());
    doAnswer(
            i -> {
              assertFalse(Thread.holdsLock(service));
              return null;
            })
        .when(recipient)
        .sendMessage(anyString());
    assertTrue(service.sendMessage(sender, recipient, "hello"));
  }

  private static Player player(UUID id, String name) {
    Player p = mock(Player.class);
    when(p.getUniqueId()).thenReturn(id);
    when(p.getName()).thenReturn(name);
    return p;
  }

  private static void await(CountDownLatch latch) {
    try {
      assertTrue(latch.await(5, TimeUnit.SECONDS));
    } catch (InterruptedException failure) {
      Thread.currentThread().interrupt();
      throw new AssertionError(failure);
    }
  }
}
