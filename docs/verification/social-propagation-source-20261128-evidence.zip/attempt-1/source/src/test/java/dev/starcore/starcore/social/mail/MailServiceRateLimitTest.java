package dev.starcore.starcore.social.mail;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.*;

/**
 * 邮件发送速率限制测试 - 验证每玩家每分钟最多 10 封邮件的限流行为。
 *
 * <p>MAX_SENDS_PER_MINUTE = 10, SEND_COOLDOWN_MS = 60,000
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("邮件速率限制测试")
class MailServiceRateLimitTest {

  private MailService mailService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();

  // 访问私有常量
  private static final int MAX_SENDS_PER_MINUTE;
  private static final long SEND_COOLDOWN_MS;

  static {
    try {
      var f1 = MailService.class.getDeclaredField("MAX_SENDS_PER_MINUTE");
      f1.setAccessible(true);
      MAX_SENDS_PER_MINUTE = f1.getInt(null);

      var f2 = MailService.class.getDeclaredField("SEND_COOLDOWN_MS");
      f2.setAccessible(true);
      SEND_COOLDOWN_MS = f2.getLong(null);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  @BeforeEach
  void setUp() {
    DatabaseService dbService = mock(DatabaseService.class);
    PersistenceService persistenceService = mock(PersistenceService.class);
    org.bukkit.plugin.Plugin plugin = mock(org.bukkit.plugin.Plugin.class);
    when(plugin.getLogger()).thenReturn(new org.bukkit.plugin.PluginLogger(plugin));
    when(plugin.getDataFolder())
        .thenReturn(new java.io.File(System.getProperty("java.io.tmpdir"), "mail-test"));
    when(plugin.getServer()).thenReturn(mock(org.bukkit.Server.class));

    mailService = new MailService(dbService, persistenceService, plugin);
  }

  private void setAcceptingOperations(boolean value) throws Exception {
    var field = MailService.class.getDeclaredField("acceptingOperations");
    field.setAccessible(true);
    field.setBoolean(mailService, value);
  }

  private Player mockPlayer(UUID uuid, String name) {
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(uuid);
    when(player.getName()).thenReturn(name);
    return player;
  }

  private org.bukkit.OfflinePlayer mockOfflinePlayer(String name, UUID uuid) {
    org.bukkit.OfflinePlayer offline = mock(org.bukkit.OfflinePlayer.class);
    when(offline.getUniqueId()).thenReturn(uuid);
    when(offline.hasPlayedBefore()).thenReturn(true);
    return offline;
  }

  // ===== 速率限制基本行为 =====

  @Test
  @DisplayName("在限制内发送邮件应全部成功")
  void underLimit_allSucceed() throws Exception {
    setAcceptingOperations(true);

    Player alicePlayer = mockPlayer(alice, "Alice");
    when(Bukkit.getPlayer("Bob")).thenReturn(mockPlayer(bob, "Bob"));
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    int successCount = 0;
    for (int i = 0; i < MAX_SENDS_PER_MINUTE; i++) {
      if (mailService.sendMail(alicePlayer, "Bob", "Test " + i, "content " + i, List.of())) {
        successCount++;
      }
    }

    assertEquals(MAX_SENDS_PER_MINUTE, successCount, "在限制内所有邮件发送都应成功");
  }

  @Test
  @DisplayName("达到上限后再发送应失败")
  void atLimit_nextSendFails() throws Exception {
    setAcceptingOperations(true);

    Player alicePlayer = mockPlayer(alice, "Alice");
    when(Bukkit.getPlayer("Bob")).thenReturn(mockPlayer(bob, "Bob"));
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    // 先发满上限
    for (int i = 0; i < MAX_SENDS_PER_MINUTE; i++) {
      mailService.sendMail(alicePlayer, "Bob", "Test " + i, "content " + i, List.of());
    }

    // 再发一封应被限流
    boolean overLimit =
        mailService.sendMail(alicePlayer, "Bob", "Over limit", "content", List.of());

    assertFalse(overLimit, "超过上限后发送应被限流");
  }

  @Test
  @DisplayName("不同玩家独立限流")
  void differentPlayers_independentLimits() throws Exception {
    setAcceptingOperations(true);

    UUID carol = UUID.randomUUID();
    Player alicePlayer = mockPlayer(alice, "Alice");
    Player carolPlayer = mockPlayer(carol, "Carol");

    when(Bukkit.getPlayer("Bob")).thenReturn(mockPlayer(bob, "Bob"));
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    // alice 发满上限
    for (int i = 0; i < MAX_SENDS_PER_MINUTE; i++) {
      mailService.sendMail(alicePlayer, "Bob", "From Alice " + i, "c", List.of());
    }

    // alice 被限流，但 carol 不受影响
    boolean aliceBlocked = mailService.sendMail(alicePlayer, "Bob", "Blocked", "c", List.of());
    boolean carolOk = mailService.sendMail(carolPlayer, "Bob", "From Carol", "c", List.of());

    assertFalse(aliceBlocked, "Alice 应被限流");
    assertTrue(carolOk, "Carol 不应受影响");
  }

  @Test
  @DisplayName("每分钟窗口独立")
  void eachMinute_windowIndependent() throws Exception {
    setAcceptingOperations(true);

    Player alicePlayer = mockPlayer(alice, "Alice");
    when(Bukkit.getPlayer("Bob")).thenReturn(mockPlayer(bob, "Bob"));
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    // 发满上限
    for (int i = 0; i < MAX_SENDS_PER_MINUTE; i++) {
      mailService.sendMail(alicePlayer, "Bob", "Test " + i, "c", List.of());
    }

    // 耗尽后应失败
    assertFalse(mailService.sendMail(alicePlayer, "Bob", "T1", "c", List.of()));

    // 操作期间再次发送也失败（仍在同一窗口）
    assertFalse(mailService.sendMail(alicePlayer, "Bob", "T2", "c", List.of()));
  }

  @Test
  @DisplayName("发给不存在的玩家时也消耗限流配额")
  void nonexistentPlayer_consumesSlot() throws Exception {
    setAcceptingOperations(true);

    Player alicePlayer = mockPlayer(alice, "Alice");
    when(Bukkit.getPlayer("Nobody")).thenReturn(null);
    when(Bukkit.getOfflinePlayer("Nobody")).thenReturn(mock(org.bukkit.OfflinePlayer.class));

    // 用无效收件人耗尽配额
    for (int i = 0; i < MAX_SENDS_PER_MINUTE; i++) {
      mailService.sendMail(alicePlayer, "Nobody", "Test", "c", List.of());
    }

    // 再发一封给有效玩家也应失败
    when(Bukkit.getPlayer("Bob")).thenReturn(mockPlayer(bob, "Bob"));
    when(Bukkit.getOfflinePlayer("Bob")).thenReturn(mockOfflinePlayer("Bob", bob));

    boolean blocked = mailService.sendMail(alicePlayer, "Bob", "Should be blocked", "c", List.of());

    assertFalse(blocked, "即使有效收件人，耗尽配额后也应被限流");
  }

  // ===== 边界 =====

  @Test
  @DisplayName("acceptingOperations=false 时不消耗限流配额")
  void acceptingOperationsFalse_noSlotConsumed() throws Exception {
    setAcceptingOperations(false);

    Player alicePlayer = mockPlayer(alice, "Alice");

    boolean result = mailService.sendMail(alicePlayer, "Bob", "Test", "c", List.of());

    assertFalse(result);
    // 再次调用（模拟恢复后）应正常成功
    // 由于不实际调用 Bukkit，这里只验证返回值符合预期
  }

  @Test
  @DisplayName("MAX_SENDS_PER_MINUTE 为 10")
  void maxSendsPerMinute_isTen() {
    assertEquals(10, MAX_SENDS_PER_MINUTE);
  }

  @Test
  @DisplayName("SEND_COOLDOWN_MS 为 60000（1 分钟）")
  void sendCooldownMs_isSixtySeconds() {
    assertEquals(60_000L, SEND_COOLDOWN_MS);
  }
}
