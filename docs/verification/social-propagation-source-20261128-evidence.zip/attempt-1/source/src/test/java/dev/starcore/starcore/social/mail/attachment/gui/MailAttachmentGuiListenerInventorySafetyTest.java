package dev.starcore.starcore.social.mail.attachment.gui;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.social.mail.MailService;
import dev.starcore.starcore.social.mail.attachment.MailAttachmentService;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.junit.jupiter.api.Test;

class MailAttachmentGuiListenerInventorySafetyTest {

  @Test
  void untrackedPreviewIsCancelledButCannotDispatchActions() throws Exception {
    MailAttachmentService service = mock(MailAttachmentService.class);
    MailAttachmentGuiListener listener = listener(service);
    Player player = player();
    MailAttachmentPreviewGui gui = gui(player);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, top, player, 53, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player, never()).closeInventory();
    verifyNoInteractions(service);
  }

  @Test
  void differentTrackedPreviewIsCancelledButCannotDispatchActions() throws Exception {
    MailAttachmentGuiListener listener = listener(mock(MailAttachmentService.class));
    Player player = player();
    MailAttachmentPreviewGui trackedGui = gui(player);
    MailAttachmentPreviewGui displayedGui = gui(player);
    track(listener, player, trackedGui);
    Inventory top = inventory(displayedGui);
    InventoryClickEvent click = click(top, top, player, 53, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player, never()).closeInventory();
  }

  @Test
  void bottomInventoryClickCannotDispatchPreviewAction() throws Exception {
    MailAttachmentGuiListener listener = listener(mock(MailAttachmentService.class));
    Player player = player();
    MailAttachmentPreviewGui gui = gui(player);
    track(listener, player, gui);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, mock(Inventory.class), player, 53, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player, never()).closeInventory();
  }

  @Test
  void numberKeyCannotTriggerClaimAction() throws Exception {
    MailAttachmentGuiListener listener = listener(mock(MailAttachmentService.class));
    Player player = player();
    MailAttachmentPreviewGui gui = gui(player);
    track(listener, player, gui);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, top, player, 37, ClickType.NUMBER_KEY);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(gui, never()).executeClaim();
  }

  @Test
  void primaryTopCloseClickStillRoutes() throws Exception {
    MailAttachmentGuiListener listener = listener(mock(MailAttachmentService.class));
    Player player = player();
    MailAttachmentPreviewGui gui = gui(player);
    track(listener, player, gui);
    Inventory top = inventory(gui);
    InventoryClickEvent click = click(top, top, player, 53, ClickType.LEFT);

    listener.onInventoryClick(click);

    verify(click).setCancelled(true);
    verify(player).closeInventory();
  }

  private static MailAttachmentGuiListener listener(MailAttachmentService service) {
    return new MailAttachmentGuiListener(mock(MailService.class), service);
  }

  private static Player player() {
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(UUID.randomUUID());
    return player;
  }

  private static MailAttachmentPreviewGui gui(Player player) {
    MailAttachmentPreviewGui gui = mock(MailAttachmentPreviewGui.class);
    when(gui.getPlayer()).thenReturn(player);
    return gui;
  }

  private static Inventory inventory(MailAttachmentPreviewGui gui) {
    Inventory top = mock(Inventory.class);
    when(top.getHolder()).thenReturn(gui);
    when(top.getSize()).thenReturn(MailAttachmentPreviewGui.SIZE);
    return top;
  }

  private static InventoryClickEvent click(
      Inventory top, Inventory clicked, Player player, int rawSlot, ClickType clickType) {
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(top);
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    when(event.getView()).thenReturn(view);
    when(event.getWhoClicked()).thenReturn(player);
    when(event.getClickedInventory()).thenReturn(clicked);
    when(event.getRawSlot()).thenReturn(rawSlot);
    when(event.getClick()).thenReturn(clickType);
    return event;
  }

  @SuppressWarnings("unchecked")
  private static void track(
      MailAttachmentGuiListener listener, Player player, MailAttachmentPreviewGui gui)
      throws Exception {
    Field field = MailAttachmentGuiListener.class.getDeclaredField("openGuis");
    field.setAccessible(true);
    ((Map<UUID, MailAttachmentPreviewGui>) field.get(listener)).put(player.getUniqueId(), gui);
  }
}
