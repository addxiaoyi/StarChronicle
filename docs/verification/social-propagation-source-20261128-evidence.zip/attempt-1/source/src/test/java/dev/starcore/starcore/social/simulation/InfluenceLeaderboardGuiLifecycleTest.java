package dev.starcore.starcore.social.simulation;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Method;
import org.bukkit.Server;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

class InfluenceLeaderboardGuiLifecycleTest {

  @Test
  void shutdownCancelsOwnedTasksAndRejectsNewOnes() throws Exception {
    Plugin plugin = mock(Plugin.class);
    Server server = mock(Server.class);
    PluginManager pluginManager = mock(PluginManager.class);
    BukkitScheduler scheduler = mock(BukkitScheduler.class);
    BukkitTask task = mock(BukkitTask.class);
    Runnable action = mock(Runnable.class);

    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenReturn(true);
    when(server.getPluginManager()).thenReturn(pluginManager);
    when(server.getScheduler()).thenReturn(scheduler);
    when(scheduler.runTask(eq(plugin), any(Runnable.class))).thenReturn(task);

    InfluenceLeaderboardGui gui =
        new InfluenceLeaderboardGui(plugin, mock(InfluenceLeaderboardService.class));
    Method runSync = InfluenceLeaderboardGui.class.getDeclaredMethod("runSync", Runnable.class);
    runSync.setAccessible(true);

    runSync.invoke(gui, action);
    verify(scheduler).runTask(eq(plugin), any(Runnable.class));

    try (MockedStatic<HandlerList> handlers = mockStatic(HandlerList.class)) {
      gui.shutdown();
      handlers.verify(() -> HandlerList.unregisterAll(gui));
    }

    verify(task).cancel();
    runSync.invoke(gui, action);

    verify(scheduler, times(1)).runTask(eq(plugin), any(Runnable.class));
    verify(action, never()).run();
  }
}
