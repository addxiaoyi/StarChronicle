package dev.starcore.starcore.social.guild;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("GuildData Tests")
class GuildDataTest {

  @Test
  @DisplayName("fromGuild captures all fields")
  void shouldCaptureAllFields() {
    UUID leader = UUID.randomUUID();
    UUID officer = UUID.randomUUID();
    UUID member = UUID.randomUUID();
    Guild guild = new Guild(UUID.randomUUID(), "G", "G", leader);
    guild.setDescription("desc");
    guild.setLevel(3);
    guild.setExperience(50);
    guild.setBalance(99.5);
    guild.addMember(officer);
    guild.setMemberRole(officer, GuildRole.OFFICER);
    guild.addMember(member);

    GuildData data = GuildData.fromGuild(guild);

    assertThat(data.getId()).isEqualTo(guild.getId());
    assertThat(data.getName()).isEqualTo("G");
    assertThat(data.getTag()).isEqualTo("G");
    assertThat(data.getLeader()).isEqualTo(leader);
    assertThat(data.getDescription()).isEqualTo("desc");
    assertThat(data.getLevel()).isEqualTo(3);
    assertThat(data.getExperience()).isEqualTo(50);
    assertThat(data.getBalance()).isEqualTo(99.5);
    assertThat(data.getMembers()).containsEntry(leader.toString(), "LEADER");
    assertThat(data.getMembers()).containsEntry(officer.toString(), "OFFICER");
    assertThat(data.getMembers()).containsEntry(member.toString(), "MEMBER");
  }

  @Test
  @DisplayName("toGuild round-trips members and state")
  void shouldRoundTrip() {
    UUID leader = UUID.randomUUID();
    UUID officer = UUID.randomUUID();
    Guild original = new Guild(UUID.randomUUID(), "Name", "Tag", leader);
    original.setDescription("hello");
    original.setLevel(4);
    original.setExperience(75);
    original.setBalance(1234.5);
    original.addMember(officer);
    original.setMemberRole(officer, GuildRole.OFFICER);

    GuildData data = GuildData.fromGuild(original);
    Guild restored = data.toGuild();

    assertThat(restored.getId()).isEqualTo(original.getId());
    assertThat(restored.getName()).isEqualTo("Name");
    assertThat(restored.getTag()).isEqualTo("Tag");
    assertThat(restored.getLeader()).isEqualTo(leader);
    assertThat(restored.getDescription()).isEqualTo("hello");
    assertThat(restored.getLevel()).isEqualTo(4);
    assertThat(restored.getExperience()).isEqualTo(75);
    assertThat(restored.getBalance()).isEqualTo(1234.5);
    assertThat(restored.getMembers()).contains(leader, officer);
    assertThat(restored.getMemberRole(leader)).isEqualTo(GuildRole.LEADER);
    assertThat(restored.getMemberRole(officer)).isEqualTo(GuildRole.OFFICER);
  }

  @Test
  @DisplayName("toGuild falls back to MEMBER for unknown role strings")
  void shouldDefaultUnknownRoleToMember() {
    UUID leader = UUID.randomUUID();
    UUID stranger = UUID.randomUUID();
    GuildData data = new GuildData();
    data.setId(UUID.randomUUID());
    data.setName("G");
    data.setTag("T");
    data.setLeader(leader);
    data.setMembers(new HashMap<>());
    data.getMembers().put(leader.toString(), "LEADER");
    data.getMembers().put(stranger.toString(), "BOGUS_ROLE");
    data.setLevel(1);
    data.setExperience(0);
    data.setBalance(0.0);

    Guild guild = data.toGuild();
    assertThat(guild.getMemberRole(stranger)).isEqualTo(GuildRole.MEMBER);
  }

  @Test
  @DisplayName("serialize then deserialize round trips")
  void shouldSerializeAndDeserialize() {
    UUID leader = UUID.randomUUID();
    UUID officer = UUID.randomUUID();
    Guild original = new Guild(UUID.randomUUID(), "Name", "Tag", leader);
    original.setDescription("desc");
    original.setLevel(2);
    original.setExperience(123);
    original.setBalance(456.78);
    original.addMember(officer);
    original.setMemberRole(officer, GuildRole.OFFICER);

    Map<String, Object> map = GuildData.fromGuild(original).serialize();
    GuildData data = GuildData.deserialize(map);

    assertThat(data.getId()).isEqualTo(original.getId());
    assertThat(data.getName()).isEqualTo("Name");
    assertThat(data.getTag()).isEqualTo("Tag");
    assertThat(data.getLeader()).isEqualTo(leader);
    assertThat(data.getDescription()).isEqualTo("desc");
    assertThat(data.getLevel()).isEqualTo(2);
    assertThat(data.getExperience()).isEqualTo(123);
    assertThat(data.getBalance()).isEqualTo(456.78);
    assertThat(data.getMembers()).containsEntry(leader.toString(), "LEADER");
    assertThat(data.getMembers()).containsEntry(officer.toString(), "OFFICER");
  }

  @Test
  @DisplayName("deserialize handles missing optional fields with defaults")
  void shouldUseDefaultsForMissingFields() {
    Map<String, Object> map = new HashMap<>();
    UUID id = UUID.randomUUID();
    UUID leader = UUID.randomUUID();
    map.put("id", id.toString());
    map.put("name", "N");
    map.put("tag", "T");
    map.put("leader", leader.toString());
    // level, experience, balance, members, createdTime, description all absent

    GuildData data = GuildData.deserialize(map);

    assertThat(data.getId()).isEqualTo(id);
    assertThat(data.getLeader()).isEqualTo(leader);
    assertThat(data.getLevel()).isEqualTo(1);
    assertThat(data.getExperience()).isEqualTo(0);
    assertThat(data.getBalance()).isEqualTo(0.0);
    assertThat(data.getMembers()).isEmpty();
  }
}
