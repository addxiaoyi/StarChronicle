package dev.starcore.starcore.social.simulation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.AsyncScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class NewsPropagationServiceLifecycleTest {
  @TempDir Path root;

  @Test
  void startIsIdempotentAndStopCancelsTimerAndOriginalPlayerNotifications() {
    try (var f = new SocialOwnerFixture(root)) {
      AsyncScheduler scheduler = mock(AsyncScheduler.class);
      ScheduledTask timer = mock(ScheduledTask.class);
      when(f.server.getAsyncScheduler()).thenReturn(scheduler);
      when(scheduler.runAtFixedRate(
              eq(f.plugin), any(), eq(300000L), eq(300000L), eq(TimeUnit.MILLISECONDS)))
          .thenReturn(timer);
      UUID source = UUID.randomUUID(), target = UUID.randomUUID();
      Player player = f.player(target, "Target");
      when(f.relations.getSocialCircle(source, 20)).thenReturn(Set.of(target));
      var service = new NewsPropagationService(f.plugin, f.relations);
      service.start();
      service.start();
      service.publishNews(
          "headline", "content", source, NewsPropagationService.NewsCategory.SOCIAL);
      service.stop();
      service.stop();
      f.drain();
      verify(scheduler, times(1)).runAtFixedRate(eq(f.plugin), any(), anyLong(), anyLong(), any());
      verify(timer).cancel();
      f.handles.forEach(handle -> verify(handle).cancel());
      verify(player, never()).sendMessage(anyString());
      assertThrows(
          IllegalStateException.class,
          () ->
              service.publishNews(
                  "late", "content", source, NewsPropagationService.NewsCategory.SOCIAL));
    }
  }

  @Test
  void stopDuringRegistrationCancelsTheLateHandleAndOldGenerationCannotSpread() {
    try (var f = new SocialOwnerFixture(root)) {
      AsyncScheduler scheduler = mock(AsyncScheduler.class);
      ScheduledTask timer = mock(ScheduledTask.class);
      when(f.server.getAsyncScheduler()).thenReturn(scheduler);
      var service = new NewsPropagationService(f.plugin, f.relations);
      List<Consumer<ScheduledTask>> callbacks = new ArrayList<>();
      when(scheduler.runAtFixedRate(eq(f.plugin), any(), anyLong(), anyLong(), any()))
          .thenAnswer(
              inv -> {
                callbacks.add(inv.getArgument(1));
                service.stop();
                return timer;
              });
      service.start();
      verify(timer).cancel();
      doAnswer(
              inv -> {
                callbacks.add(inv.getArgument(1));
                return mock(ScheduledTask.class);
              })
          .when(scheduler)
          .runAtFixedRate(eq(f.plugin), any(), anyLong(), anyLong(), any());
      service.start();
      UUID source = UUID.randomUUID();
      service.publishNews("new", "content", source, NewsPropagationService.NewsCategory.SOCIAL);
      clearInvocations(f.relations);
      callbacks.getFirst().accept(timer);
      verifyNoInteractions(f.relations);
      service.stop();
    }
  }

  @Test
  void rejectedRegistrationCanBeRetried() {
    try (var f = new SocialOwnerFixture(root)) {
      AsyncScheduler scheduler = mock(AsyncScheduler.class);
      when(f.server.getAsyncScheduler()).thenReturn(scheduler);
      var service = new NewsPropagationService(f.plugin, f.relations);
      assertThrows(IllegalStateException.class, service::start);
      ScheduledTask timer = mock(ScheduledTask.class);
      when(scheduler.runAtFixedRate(eq(f.plugin), any(), anyLong(), anyLong(), any()))
          .thenReturn(timer);
      service.start();
      service.stop();
      verify(timer).cancel();
    }
  }

  @Test
  void shareReadsSharerNameOnItsOwnerAndDoesNotNotifyReconnectedTarget() {
    try (var f = new SocialOwnerFixture(root)) {
      UUID source = UUID.randomUUID(), target = UUID.randomUUID();
      Player sharer = f.player(source, "Sharer"), original = f.player(target, "Before");
      var service = new NewsPropagationService(f.plugin, f.relations);
      String id =
          service.publishNews(
              "headline", "content", source, NewsPropagationService.NewsCategory.SOCIAL);
      assertTrue(service.shareNews(id, source, target));
      verify(sharer, never()).getName();
      Player replacement = f.player(target, "After");
      f.drain();
      verify(sharer).getName();
      verify(original, never()).sendMessage(anyString());
      verify(replacement, never()).sendMessage(anyString());
      assertEquals(id, service.getUnreadNews(target).getFirst().id());
      service.stop();
    }
  }
}
