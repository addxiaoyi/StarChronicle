package dev.starcore.starcore.social.friend;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * 好友操作变更测试 - 覆盖 sendFriendRequest / acceptFriendRequest / rejectFriendRequest / removeFriend
 * 的各种分支路径，包括错误处理、状态一致性和边界条件。
 *
 * <p>测试不依赖任何外部服务（数据库/YAML），仅验证 FriendService 内部状态机逻辑。
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("好友操作变更测试")
class FriendServiceMutationsTest {

  private FriendService friendService;
  private final UUID alice = UUID.randomUUID();
  private final UUID bob = UUID.randomUUID();
  private final UUID carol = UUID.randomUUID();

  @BeforeEach
  void setUp() {
    friendService = new FriendService();
  }

  // ===== sendFriendRequest =====

  @Test
  @DisplayName("sendFriendRequest: 成功发送后请求应出现在接收者的请求列表")
  void sendFriendRequest_success_requestAppearsInInbox() {
    assertTrue(friendService.sendFriendRequest(alice, bob));
    Set<UUID> requests = friendService.getFriendRequests(bob);
    assertTrue(requests.contains(alice), "bob 收件箱应包含来自 alice 的请求");
  }

  @Test
  @DisplayName("sendFriendRequest: 发送后请求者也应在其请求列表中(发送记录)")
  void sendFriendRequest_senderAlsoRecordsRequest() {
    friendService.sendFriendRequest(alice, bob);
    Set<UUID> aliceRequests = friendService.getFriendRequests(alice);
    assertTrue(aliceRequests.contains(bob), "alice 的请求列表应记录已发送的请求");
  }

  @Test
  @DisplayName("sendFriendRequest: 接收者已发送过请求给发送者，应自动建立好友关系")
  void sendFriendRequest_mutualRequestAutoAccepts() {
    friendService.sendFriendRequest(alice, bob);
    friendService.sendFriendRequest(bob, alice);

    assertTrue(friendService.isFriend(alice, bob), "双向请求应自动建立好友关系");
    assertTrue(friendService.isFriend(bob, alice));
  }

  @Test
  @DisplayName("sendFriendRequest: 目标已在拉黑列表中应抛出异常")
  void sendFriendRequest_targetBlacklisted_throws() {
    friendService.addToBlacklist(bob, alice);
    assertThrows(IllegalStateException.class, () -> friendService.sendFriendRequest(alice, bob));
  }

  @Test
  @DisplayName("sendFriendRequest: 自己在对方黑名单中应抛出异常")
  void sendFriendRequest_senderBlacklisted_throws() {
    friendService.addToBlacklist(bob, alice);
    assertThrows(IllegalStateException.class, () -> friendService.sendFriendRequest(alice, bob));
  }

  @Test
  @DisplayName("sendFriendRequest: 双方已是好友不应重复发送请求")
  void sendFriendRequest_alreadyFriends_throws() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);

    assertThrows(IllegalStateException.class, () -> friendService.sendFriendRequest(alice, bob));
  }

  @Test
  @DisplayName("sendFriendRequest: null 参数应抛出空指针异常")
  void sendFriendRequest_nullArguments_throwsNpe() {
    assertThrows(NullPointerException.class, () -> friendService.sendFriendRequest(null, bob));
    assertThrows(NullPointerException.class, () -> friendService.sendFriendRequest(alice, null));
  }

  // ===== acceptFriendRequest =====

  @Test
  @DisplayName("acceptFriendRequest: 成功接受后双方应成为好友")
  void acceptFriendRequest_success_createsBidirectionalFriendship() {
    friendService.sendFriendRequest(alice, bob);
    assertTrue(friendService.acceptFriendRequest(bob, alice));

    assertTrue(friendService.isFriend(alice, bob));
    assertTrue(friendService.isFriend(bob, alice));
  }

  @Test
  @DisplayName("acceptFriendRequest: 接受后请求应从收件箱移除")
  void acceptFriendRequest_removesRequestFromInbox() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);

    Set<UUID> requests = friendService.getFriendRequests(bob);
    assertFalse(requests.contains(alice), "接受后请求应从收件箱移除");
  }

  @Test
  @DisplayName("acceptFriendRequest: 不存在的请求应返回 false")
  void acceptFriendRequest_noPendingRequest_returnsFalse() {
    assertFalse(friendService.acceptFriendRequest(bob, alice), "没有待处理的请求时应返回 false");
  }

  @Test
  @DisplayName("acceptFriendRequest: 双方已是好友时不应重复接受")
  void acceptFriendRequest_alreadyFriends_returnsFalse() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);

    assertFalse(friendService.acceptFriendRequest(bob, alice), "已是好友时再次接受应返回 false");
  }

  @Test
  @DisplayName("acceptFriendRequest: 自己接受自己的请求应抛出异常")
  void acceptFriendRequest_selfRequest_throws() {
    // sendFriendRequest(alice, alice) 自身应抛 IllegalArgumentException
    assertThrows(
        IllegalArgumentException.class, () -> friendService.sendFriendRequest(alice, alice));
  }

  @Test
  @DisplayName("acceptFriendRequest: 目标已拉黑发送者应抛出异常")
  void acceptFriendRequest_targetBlocked_throws() {
    friendService.sendFriendRequest(alice, bob);
    friendService.addToBlacklist(bob, alice);

    assertThrows(IllegalStateException.class, () -> friendService.acceptFriendRequest(bob, alice));
  }

  @Test
  @DisplayName("acceptFriendRequest: 接收者已拉黑发送者应抛出异常")
  void acceptFriendRequest_senderBlockedByReceiver_throws() {
    friendService.sendFriendRequest(alice, bob);
    friendService.addToBlacklist(bob, alice);

    assertThrows(IllegalStateException.class, () -> friendService.acceptFriendRequest(bob, alice));
  }

  // ===== rejectFriendRequest =====

  @Test
  @DisplayName("rejectFriendRequest: 拒绝后请求应从收件箱移除")
  void rejectFriendRequest_removesRequestFromInbox() {
    friendService.sendFriendRequest(alice, bob);
    friendService.rejectFriendRequest(bob, alice);

    Set<UUID> requests = friendService.getFriendRequests(bob);
    assertFalse(requests.contains(alice), "拒绝后请求应从收件箱移除");
  }

  @Test
  @DisplayName("rejectFriendRequest: 拒绝后双方不应成为好友")
  void rejectFriendRequest_noFriendshipCreated() {
    friendService.sendFriendRequest(alice, bob);
    friendService.rejectFriendRequest(bob, alice);

    assertFalse(friendService.isFriend(alice, bob));
    assertFalse(friendService.isFriend(bob, alice));
  }

  @Test
  @DisplayName("rejectFriendRequest: 不存在的请求应返回 false")
  void rejectFriendRequest_noPendingRequest_returnsFalse() {
    assertFalse(friendService.rejectFriendRequest(bob, alice));
  }

  @Test
  @DisplayName("rejectFriendRequest: 拒绝后可重新发送请求")
  void rejectFriendRequest_thenResend_isAllowed() {
    friendService.sendFriendRequest(alice, bob);
    friendService.rejectFriendRequest(bob, alice);
    assertTrue(friendService.sendFriendRequest(alice, bob));
  }

  // ===== removeFriend =====

  @Test
  @DisplayName("removeFriend: 移除后好友数应减1")
  void removeFriend_decreasesFriendCount() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);
    assertEquals(1, friendService.getFriendCount(alice));

    friendService.removeFriend(alice, bob);
    assertEquals(0, friendService.getFriendCount(alice));
    assertEquals(0, friendService.getFriendCount(bob));
  }

  @Test
  @DisplayName("removeFriend: 移除不存在的关系应返回 false")
  void removeFriend_nonExistent_returnsFalse() {
    assertFalse(friendService.removeFriend(alice, bob));
  }

  @Test
  @DisplayName("removeFriend: 只能从自己的好友列表中移除")
  void removeFriend_cannotRemoveOthersFriendship() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);

    // carol 尝试移除 alice-bob 的关系（carol 与 bob 不是好友）
    assertFalse(friendService.removeFriend(carol, bob));
  }

  // ===== getFriendCount =====

  @Test
  @DisplayName("getFriendCount: 应返回正确的好友数量")
  void getFriendCount_returnsCorrectSize() {
    assertEquals(0, friendService.getFriendCount(alice));
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);
    assertEquals(1, friendService.getFriendCount(alice));

    friendService.sendFriendRequest(alice, carol);
    friendService.acceptFriendRequest(carol, alice);
    assertEquals(2, friendService.getFriendCount(alice));
  }

  @Test
  @DisplayName("getKnownPlayerIds: 返回社交状态中出现的所有玩家且不暴露内部集合")
  void getKnownPlayerIds_returnsAllReferencedPlayers() {
    UUID blocked = UUID.randomUUID();
    friendService.sendFriendRequest(alice, bob);
    friendService.addToBlacklist(carol, blocked);
    friendService.setOnlineStatus(alice, true);

    Set<UUID> known = friendService.getKnownPlayerIds();

    assertTrue(known.contains(alice));
    assertTrue(known.contains(bob));
    assertTrue(known.contains(carol));
    assertTrue(known.contains(blocked));
    assertThrows(UnsupportedOperationException.class, () -> known.add(UUID.randomUUID()));
  }

  // ===== getFriendRequests =====

  @Test
  @DisplayName("getFriendRequests: 应仅返回未处理的请求")
  void getFriendRequests_returnsOnlyPending() {
    friendService.sendFriendRequest(alice, bob);
    friendService.sendFriendRequest(carol, bob);

    Set<UUID> requests = friendService.getFriendRequests(bob);
    assertEquals(2, requests.size());
    assertTrue(requests.contains(alice));
    assertTrue(requests.contains(carol));
  }

  @Test
  @DisplayName("getFriendRequests: 返回的集合为副本，修改不影响内部状态")
  void getFriendRequests_returnsDefensiveCopy() {
    friendService.sendFriendRequest(alice, bob);
    Set<UUID> requests = friendService.getFriendRequests(bob);
    requests.clear();

    assertFalse(friendService.getFriendRequests(bob).isEmpty(), "清空返回集合不应影响内部状态");
  }

  // ===== isFriend =====

  @Test
  @DisplayName("isFriend: 未建立关系时返回 false")
  void isFriend_noRelationship_returnsFalse() {
    assertFalse(friendService.isFriend(alice, bob));
  }

  @Test
  @DisplayName("isFriend: 双向好友关系建立后双向查询均返回 true")
  void isFriend_bidirectionalReturnsTrue() {
    friendService.sendFriendRequest(alice, bob);
    friendService.acceptFriendRequest(bob, alice);

    assertTrue(friendService.isFriend(alice, bob));
    assertTrue(friendService.isFriend(bob, alice));
  }

  @Test
  @DisplayName("isFriend: 单向请求时（未接受）不应显示为好友")
  void isFriend_pendingRequestNotFriend() {
    friendService.sendFriendRequest(alice, bob);

    assertFalse(friendService.isFriend(alice, bob), "请求未接受时不应为好友");
    assertFalse(friendService.isFriend(bob, alice), "请求未接受时不应为好友");
  }

  @Test
  @DisplayName("isFriend: null 参数应抛出空指针异常")
  void isFriend_nullArgument_throwsNpe() {
    assertThrows(NullPointerException.class, () -> friendService.isFriend(null, bob));
  }
}
