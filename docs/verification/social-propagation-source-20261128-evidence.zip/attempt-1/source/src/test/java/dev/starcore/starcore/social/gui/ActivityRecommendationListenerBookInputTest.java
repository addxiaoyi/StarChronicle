package dev.starcore.starcore.social.gui;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.social.simulation.SocialActivityService;
import dev.starcore.starcore.social.simulation.SocialActivityService.SocialActivityType;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.BookMeta;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

class ActivityRecommendationListenerBookInputTest {

  @Test
  void invalidBookInputIsRejectedWithoutCreatingAnActivity() throws Exception {
    UUID playerId = UUID.randomUUID();
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(playerId);
    SocialActivityService service = serviceWithEmptyActivities();
    ActivityRecommendationListener listener = new ActivityRecommendationListener(service);
    pendingTypes(listener).put(playerId, SocialActivityType.PARTY);

    PlayerEditBookEvent event = bookEdit(player, "X".repeat(49), "too long");
    try (var ignored =
        mockConstruction(
            ActivityRecommendationGui.class,
            (menu, context) -> when(menu.getInventory()).thenReturn(mock(Inventory.class)))) {
      listener.onActivityCreateBookEdit(event);
    }

    verify(event).setCancelled(true);
    verify(player).sendMessage(any(Component.class));
    verify(service, never()).createPartyAsync(any(UUID.class), anyString(), anyString());
  }

  @Test
  void validBookInputCreatesTheSelectedActivityAndReturnsToGui() throws Exception {
    UUID playerId = UUID.randomUUID();
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.isOnline()).thenReturn(true);
    SocialActivityService service = serviceWithEmptyActivities();
    when(service.createPartyAsync(playerId, "Smoke Party", "Book-created activity"))
        .thenReturn(CompletableFuture.completedFuture("activity-1"));
    when(service.getActivity("activity-1")).thenReturn(Optional.empty());
    ActivityRecommendationListener listener = new ActivityRecommendationListener(service);
    pendingTypes(listener).put(playerId, SocialActivityType.PARTY);

    PlayerEditBookEvent event = bookEdit(player, "Smoke Party", "Book-created activity");
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class);
        var ignored =
            mockConstruction(
                ActivityRecommendationGui.class,
                (menu, context) -> when(menu.getInventory()).thenReturn(mock(Inventory.class)))) {
      bukkit.when(Bukkit::isPrimaryThread).thenReturn(true);
      listener.onActivityCreateBookEdit(event);
    }

    verify(event).setCancelled(true);
    verify(service).createPartyAsync(playerId, "Smoke Party", "Book-created activity");
    verify(player).sendMessage(any(Component.class));
    verify(player).openInventory(any(Inventory.class));
  }

  private static SocialActivityService serviceWithEmptyActivities() {
    SocialActivityService service = mock(SocialActivityService.class);
    when(service.getPublicActivities()).thenReturn(List.of());
    when(service.getPlayerActivities(any(UUID.class))).thenReturn(Set.of());
    return service;
  }

  @SuppressWarnings("unchecked")
  private static Map<UUID, SocialActivityType> pendingTypes(ActivityRecommendationListener listener)
      throws Exception {
    Field field = ActivityRecommendationListener.class.getDeclaredField("pendingCreateTypes");
    field.setAccessible(true);
    return (Map<UUID, SocialActivityType>) field.get(listener);
  }

  private static PlayerEditBookEvent bookEdit(Player player, String... pages) {
    BookMeta meta = mock(BookMeta.class);
    when(meta.getPages()).thenReturn(List.of(pages));
    PlayerEditBookEvent event = mock(PlayerEditBookEvent.class);
    when(event.getPlayer()).thenReturn(player);
    when(event.getNewBookMeta()).thenReturn(meta);
    return event;
  }
}
