package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseSettings;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class SocialInfluencePersistenceFailureTest {
  @Test
  void propagationPersistsNewAndExistingFriends(@TempDir Path directory) throws Exception {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + directory.resolve("propagation.db"));
    UUID player = UUID.randomUUID();
    UUID fresh = UUID.randomUUID();
    UUID existing = UUID.randomUUID();
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE player_influence (player_id TEXT PRIMARY KEY, influence INTEGER, last_decay"
              + " INTEGER)");
      statement.execute(
          "CREATE TABLE influence_sources (player_id TEXT, source TEXT, amount INTEGER, timestamp"
              + " INTEGER)");
      statement.execute("INSERT INTO player_influence VALUES ('" + existing + "', 7, 123)");
    }
    DatabaseService database = mock(DatabaseService.class);
    when(database.settings()).thenReturn(DatabaseSettings.disabled());
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.query(anyString(), any())).thenReturn(Map.of(existing, 7));
    when(database.query(anyString(), any(), any(Object[].class))).thenReturn(List.of());
    RelationshipNetwork network = mock(RelationshipNetwork.class);
    when(network.getFriends(player)).thenReturn(Set.of(fresh, existing));
    when(network.getFriends(fresh)).thenReturn(Set.of());
    when(network.getFriends(existing)).thenReturn(Set.of());
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    SocialInfluenceServiceImpl service =
        new SocialInfluenceServiceImpl(plugin, null, network, database);
    service.addInfluence(player, 20, "test");
    assertThat(service.getInfluence(fresh)).isEqualTo(5);
    assertThat(service.getInfluence(existing)).isEqualTo(12);
    try (var connection = source.getConnection();
        var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT player_id, influence, last_decay FROM player_influence")) {
      Map<String, Integer> values = new java.util.HashMap<>();
      long existingDecay = 0;
      while (rows.next()) {
        values.put(rows.getString(1), rows.getInt(2));
        if (rows.getString(1).equals(existing.toString())) existingDecay = rows.getLong(3);
      }
      assertThat(values).containsEntry(fresh.toString(), 5).containsEntry(existing.toString(), 12);
      assertThat(existingDecay).isEqualTo(123);
    }
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_friend BEFORE UPDATE ON player_influence WHEN OLD.player_id = '"
              + fresh
              + "' BEGIN SELECT RAISE(ABORT, 'injected'); END");
    }
    assertThatThrownBy(() -> service.addInfluence(player, 20, "failed"))
        .hasMessage("SOCIAL_INFLUENCE_WRITE_FAILED");
    for (UUID id : List.of(player, fresh, existing)) {
      assertThatThrownBy(() -> service.getInfluence(id))
          .hasMessage("SOCIAL_INFLUENCE_RELOAD_REQUIRED");
    }
    try (var connection = source.getConnection();
        var statement = connection.createStatement();
        var rows = statement.executeQuery("SELECT player_id, influence FROM player_influence")) {
      Map<String, Integer> values = new java.util.HashMap<>();
      while (rows.next()) values.put(rows.getString(1), rows.getInt(2));
      assertThat(values)
          .containsEntry(player.toString(), 20)
          .containsEntry(fresh.toString(), 5)
          .containsEntry(existing.toString(), 12);
    }
    try (var connection = source.getConnection();
        var statement = connection.createStatement();
        var rows = statement.executeQuery("SELECT COUNT(*) FROM influence_sources")) {
      assertThat(rows.next()).isTrue();
      assertThat(rows.getInt(1)).isEqualTo(1);
    }
  }

  @Test
  void failedInfluenceWriteDoesNotChangeCachedValue() {
    DatabaseService database = mock(DatabaseService.class);
    when(database.settings()).thenReturn(DatabaseSettings.disabled());
    when(database.dataSource()).thenReturn(Optional.empty());
    when(database.query(anyString(), any())).thenReturn(Map.of());
    when(database.query(anyString(), any(), any(Object[].class))).thenReturn(List.of(10));
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    SocialInfluenceServiceImpl service =
        new SocialInfluenceServiceImpl(plugin, null, null, database);
    UUID player = UUID.randomUUID();
    assertThat(service.getInfluence(player)).isEqualTo(10);
    assertThatThrownBy(() -> service.addInfluence(player, -5, "quit"))
        .hasMessage("SOCIAL_INFLUENCE_WRITE_FAILED");
    assertThatThrownBy(() -> service.getInfluence(player))
        .hasMessage("SOCIAL_INFLUENCE_RELOAD_REQUIRED");
  }

  @Test
  void sourceFailureRollsBackInfluence(@TempDir Path directory) throws Exception {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + directory.resolve("influence.db"));
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE player_influence (player_id TEXT PRIMARY KEY, influence INTEGER, last_decay"
              + " INTEGER)");
      statement.execute(
          "CREATE TABLE influence_sources (player_id TEXT, source TEXT, amount INTEGER, timestamp"
              + " INTEGER)");
    }
    DatabaseService database = mock(DatabaseService.class);
    when(database.settings()).thenReturn(DatabaseSettings.disabled());
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.query(anyString(), any())).thenReturn(Map.of());
    when(database.query(anyString(), any(), any(Object[].class))).thenReturn(List.of(10));
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    SocialInfluenceServiceImpl service =
        new SocialInfluenceServiceImpl(plugin, null, null, database);
    UUID player = UUID.randomUUID();
    service.addInfluence(player, -2, "first");
    assertThat(service.getInfluence(player)).isEqualTo(8);
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_source BEFORE INSERT ON influence_sources BEGIN SELECT"
              + " RAISE(ABORT, 'injected'); END");
    }
    assertThatThrownBy(() -> service.addInfluence(player, -5, "quit"))
        .hasMessage("SOCIAL_INFLUENCE_WRITE_FAILED");
    try (var connection = source.getConnection();
        var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT influence, (SELECT COUNT(*) FROM influence_sources) FROM"
                    + " player_influence")) {
      assertThat(rows.next()).isTrue();
      assertThat(rows.getInt(1)).isEqualTo(8);
      assertThat(rows.getInt(2)).isEqualTo(1);
    }
    assertThatThrownBy(() -> service.getInfluence(player))
        .hasMessage("SOCIAL_INFLUENCE_RELOAD_REQUIRED");
  }

  @Test
  void failedStartupReadDoesNotEnablePartialCache(@TempDir Path directory) throws Exception {
    SQLiteDataSource source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + directory.resolve("startup.db"));
    UUID player = UUID.randomUUID();
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE player_influence (player_id TEXT PRIMARY KEY, influence INTEGER, last_decay"
              + " INTEGER)");
      statement.execute("INSERT INTO player_influence VALUES ('" + player + "', 42, 0)");
      statement.execute("INSERT INTO player_influence VALUES ('invalid', 10, 0)");
    }
    DatabaseService database = mock(DatabaseService.class);
    when(database.settings()).thenReturn(DatabaseSettings.disabled());
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.query(anyString(), any()))
        .thenAnswer(
            invocation -> {
              java.util.function.Function<java.sql.ResultSet, ?> mapper = invocation.getArgument(1);
              try (var connection = source.getConnection();
                  var statement = connection.createStatement();
                  var rows = statement.executeQuery(invocation.getArgument(0))) {
                return mapper.apply(rows);
              }
            });
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    SocialInfluenceServiceImpl service =
        new SocialInfluenceServiceImpl(plugin, null, null, database);
    assertThatThrownBy(() -> service.getInfluence(player))
        .hasMessage("SOCIAL_INFLUENCE_READ_FAILED");
    assertThatThrownBy(() -> service.addInfluence(player, -5, "quit"))
        .hasMessage("SOCIAL_INFLUENCE_READ_FAILED");
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.execute("DELETE FROM player_influence WHERE player_id = 'invalid'");
    }
    SocialInfluenceServiceImpl recovered =
        new SocialInfluenceServiceImpl(plugin, null, null, database);
    assertThat(recovered.getInfluence(player)).isEqualTo(42);
  }

  @Test
  void singlePlayerReadFailureDoesNotBecomeZero() throws Exception {
    DatabaseService database = mock(DatabaseService.class);
    when(database.settings()).thenReturn(DatabaseSettings.disabled());
    when(database.dataSource()).thenReturn(Optional.empty());
    when(database.query(anyString(), any())).thenReturn(Map.of());
    java.sql.ResultSet rows = mock(java.sql.ResultSet.class);
    when(rows.next()).thenThrow(new java.sql.SQLException("result set failed"));
    when(database.query(anyString(), any(), any(Object[].class)))
        .thenAnswer(
            invocation -> {
              java.util.function.Function<java.sql.ResultSet, ?> mapper = invocation.getArgument(1);
              return mapper.apply(rows);
            });
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    SocialInfluenceServiceImpl service =
        new SocialInfluenceServiceImpl(plugin, null, null, database);
    UUID player = UUID.randomUUID();
    assertThatThrownBy(() -> service.addInfluence(player, 5, "join"))
        .hasMessage("SOCIAL_INFLUENCE_READ_FAILED");
    assertThatThrownBy(() -> service.getInfluence(player))
        .hasMessage("SOCIAL_INFLUENCE_READ_FAILED");
  }
}
