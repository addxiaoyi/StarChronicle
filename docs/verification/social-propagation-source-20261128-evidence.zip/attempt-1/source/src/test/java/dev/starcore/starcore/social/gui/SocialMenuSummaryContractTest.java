package dev.starcore.starcore.social.gui;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

class SocialMenuSummaryContractTest {

  @Test
  void chatOnlySocialActionsRouteToGuiSummaryOrHistoryPages() throws Exception {
    String source =
        Files.readString(
            Path.of("src/main/java/dev/starcore/starcore/social/gui/SocialMenuListener.java"));

    assertThat(source)
        .contains("openSummaryPage(player, \"guild\")")
        .contains("openSummaryPage(player, \"party\")")
        .contains("openSummaryPage(player, \"stats\")")
        .contains("openChatHistoryPage(player)")
        .contains("setActivityService(SocialActivityService activityService)")
        .contains("STATE_SUMMARY")
        .contains("handleSummaryClick(player, slot)");
  }

  @Test
  void socialListenerUsesAnOwnedHolderInsteadOfTheSharedMenuHolder() throws Exception {
    String source =
        Files.readString(
            Path.of("src/main/java/dev/starcore/starcore/social/gui/SocialMenuListener.java"));

    assertThat(source)
        .contains("instanceof SocialMenuHolder")
        .doesNotContain("instanceof StarCoreMenuHolder")
        .doesNotContain("new StarCoreMenuHolder()")
        .contains("slot != 38");
  }

  @Test
  void closingAnOldPageDoesNotEraseTheStateOfANewSocialPage() throws Exception {
    String source =
        Files.readString(
            Path.of("src/main/java/dev/starcore/starcore/social/gui/SocialMenuListener.java"));

    String closeHandler =
        source.substring(
            source.indexOf("public void onInventoryClose"),
            source.indexOf("private void handleAction"));
    assertThat(closeHandler)
        .contains("openMenus.remove(player.getUniqueId())")
        .doesNotContain("playerMenuState.remove")
        .doesNotContain("playerChatTarget.remove")
        .doesNotContain("summaryKinds.remove");
  }

  @Test
  void unavailableActivityAndLeaderboardUseGuiFallbackPages() throws Exception {
    String source =
        Files.readString(
            Path.of("src/main/java/dev/starcore/starcore/social/gui/SocialMenuListener.java"));

    assertThat(source)
        .contains("openUnavailablePage(")
        .contains("Activity unavailable")
        .contains("Leaderboard unavailable")
        .contains("summaryKinds.put(player.getUniqueId(), \"unavailable\")");
  }

  @Test
  void activityTypeActionsOpenGuiCategoryPagesInsteadOfChatCommands() throws Exception {
    String listener =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/gui/ActivityRecommendationListener.java"));
    String gui =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/gui/ActivityRecommendationGui.java"));
    assertThat(listener)
        .contains("gui.showTypeDetails(SocialActivityType.valueOf(action.name()))")
        .contains("activityGui.isShowingTypeDetails()")
        .contains("activityGui.getTypeActivityFromSlot(slot)");
    assertThat(gui)
        .contains("showTypeDetails(SocialActivityType type)")
        .contains("closeTypeDetails()")
        .contains("typeEntries.put(slot, activity)");
  }

  @Test
  void activityOverviewActionsUseReadOnlyOrJoinableGuiPages() throws Exception {
    String listener =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/gui/ActivityRecommendationListener.java"));
    String gui =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/gui/ActivityRecommendationGui.java"));
    assertThat(listener)
        .contains("gui.showActivityList(\"My activities\", activities, false)")
        .contains("gui.showActivityList(\"Popular activities\", activities, true)")
        .contains("gui.showStatsPage(")
        .contains("gui.showCreateGuidePage()");
    assertThat(listener)
        .contains("BookInputSupport.prepare(player, \"Activity details\", \"\")")
        .contains("onActivityCreateBookEdit")
        .contains("PlayerEditBookEvent event")
        .contains("activityService.createPartyAsync(host, name, description)")
        .contains("activityService.createCelebrationAsync(host, name, description, 4)")
        .contains("SocialActivityService.CompetitionType.DUEL")
        .contains("activityService.createCompetitionAsync(");
    assertThat(gui)
        .contains("case 22 -> SocialActivityType.PARTY")
        .contains("case 23 -> SocialActivityType.CELEBRATION")
        .contains("case 24 -> SocialActivityType.COMPETITION");
    assertThat(gui)
        .contains(
            "showActivityList(String title, List<SocialActivity> activities, boolean joinable)")
        .contains("showCreateGuidePage()");
  }
}
