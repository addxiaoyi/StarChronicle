package dev.starcore.starcore.social.gui;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.social.chat.PrivateMessageService;
import dev.starcore.starcore.social.friend.FriendService;
import dev.starcore.starcore.social.guild.GuildService;
import dev.starcore.starcore.social.party.PartyService;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** SocialMenuListener 的槽位和物品 Lore 解析契约。 */
class SocialMenuListenerTest {
  private SocialMenuListener listener;

  @BeforeEach
  void setUp() {
    listener = new SocialMenuListener(mock(FriendService.class), mock(GuildService.class),
        mock(PartyService.class), mock(PrivateMessageService.class));
  }

  private Object invoke(String name, Class<?>[] types, Object... args) throws Exception {
    Method method = SocialMenuListener.class.getDeclaredMethod(name, types);
    method.setAccessible(true);
    return method.invoke(listener, args);
  }

  @Test
  @DisplayName("列表槽位覆盖 10..43 但排除返回槽 38")
  void listEntrySlotBounds() throws Exception {
    assertThat(invoke("isListEntrySlot", new Class<?>[] {int.class}, 10)).isEqualTo(true);
    assertThat(invoke("isListEntrySlot", new Class<?>[] {int.class}, 43)).isEqualTo(true);
    assertThat(invoke("isListEntrySlot", new Class<?>[] {int.class}, 38)).isEqualTo(false);
    assertThat(invoke("isListEntrySlot", new Class<?>[] {int.class}, 9)).isEqualTo(false);
    assertThat(invoke("isListEntrySlot", new Class<?>[] {int.class}, 44)).isEqualTo(false);
  }

  @Test
  @DisplayName("null 物品或无元数据时 UUID 与值解析安全返回 null")
  void nullItemReturnsNull() throws Exception {
    assertThat(invoke("extractUUIDFromLore", new Class<?>[] {ItemStack.class}, (Object) null)).isNull();
    assertThat(invoke("extractValueFromLore", new Class<?>[] {ItemStack.class, String.class}, null, "ID: ")).isNull();
    ItemStack item = mock(ItemStack.class);
    when(item.hasItemMeta()).thenReturn(false);
    assertThat(invoke("extractUUIDFromLore", new Class<?>[] {ItemStack.class}, item)).isNull();
  }

  @Test
  @DisplayName("从 Lore 的 ID 行解析合法 UUID")
  void extractsUuidFromLore() throws Exception {
    UUID expected = UUID.randomUUID();
    ItemStack item = itemWithLore("§7玩家 ID: " + expected);
    assertThat(invoke("extractUUIDFromLore", new Class<?>[] {ItemStack.class}, item)).isEqualTo(expected);
  }

  @Test
  @DisplayName("无效 UUID 不会抛异常并返回 null")
  void invalidUuidReturnsNull() throws Exception {
    ItemStack item = itemWithLore("ID: not-a-uuid");
    assertThat(invoke("extractUUIDFromLore", new Class<?>[] {ItemStack.class}, item)).isNull();
  }

  @Test
  @DisplayName("UUID 前缀之后的多余文本会被严格拒绝")
  void uuidWithTrailingTextIsRejected() throws Exception {
    ItemStack item = itemWithLore("ID: " + UUID.randomUUID() + " extra");
    assertThat(invoke("extractUUIDFromLore", new Class<?>[] {ItemStack.class}, item)).isNull();
  }

  @Test
  @DisplayName("按前缀提取 Lore 值并去除首尾空格")
  void extractsValueByPrefix() throws Exception {
    ItemStack item = itemWithLore("Target:   Aurora  ");
    assertThat(invoke("extractValueFromLore", new Class<?>[] {ItemStack.class, String.class}, item, "Target:"))
        .isEqualTo("Aurora");
    assertThat(invoke("extractValueFromLore", new Class<?>[] {ItemStack.class, String.class}, item, "Missing:"))
        .isNull();
  }

  @Test
  @DisplayName("仅匹配 Lore 行开头的前缀，不匹配中间文本")
  void prefixMustStartAtLineBeginning() throws Exception {
    ItemStack item = itemWithLore("说明 Target: Aurora");
    assertThat(invoke("extractValueFromLore", new Class<?>[] {ItemStack.class, String.class}, item, "Target:"))
        .isNull();
  }

  private ItemStack itemWithLore(String... lines) {
    ItemStack item = mock(ItemStack.class);
    ItemMeta meta = mock(ItemMeta.class);
    when(item.hasItemMeta()).thenReturn(true);
    when(item.getItemMeta()).thenReturn(meta);
    List<Component> lore = new java.util.ArrayList<>();
    for (String line : lines) {
      lore.add(Component.text(line));
    }
    when(meta.lore()).thenReturn(lore);
    return item;
  }
}
