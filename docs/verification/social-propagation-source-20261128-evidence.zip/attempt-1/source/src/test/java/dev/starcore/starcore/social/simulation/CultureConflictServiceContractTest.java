package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.module.diplomacy.DiplomacyRelationService;
import dev.starcore.starcore.module.nation.NationService;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class CultureConflictServiceContractTest {

  @Test
  void lazyDiplomacyLookupUsesTheRelationNarrowContract() throws Exception {
    JavaPlugin plugin = mock(JavaPlugin.class);
    CultureService cultures = mock(CultureService.class);
    NationService nations = mock(NationService.class);
    ServiceRegistry registry = mock(ServiceRegistry.class);
    DiplomacyRelationService relations = mock(DiplomacyRelationService.class);
    when(nations.nations()).thenReturn(List.of());
    when(registry.find(DiplomacyRelationService.class)).thenReturn(Optional.of(relations));

    CultureConflictService service =
        new CultureConflictService(plugin, cultures, nations, registry);
    Method lookup = CultureConflictService.class.getDeclaredMethod("getDiplomacyService");
    lookup.setAccessible(true);

    assertThat(lookup.invoke(service)).isSameAs(relations);
    verify(registry).find(DiplomacyRelationService.class);
  }
}
