package dev.starcore.starcore.social.simulation;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class InfluenceRankNotificationThrottleTest {

  private static final Duration COOLDOWN = Duration.ofMinutes(30);

  @Test
  void unchangedRanksDoNotCreateNotifications() {
    InfluenceRankNotificationThrottle throttle = new InfluenceRankNotificationThrottle(COOLDOWN);
    UUID playerId = UUID.randomUUID();
    Map<LeaderboardPeriod, Integer> ranks = ranks(10);

    assertThat(throttle.claim(playerId, ranks, ranks, 0L)).isEmpty();
    assertThat(throttle.claim(playerId, ranks, ranks, COOLDOWN.toMillis())).isEmpty();
  }

  @Test
  void changedRanksNotifyOnceUntilCooldownExpires() {
    InfluenceRankNotificationThrottle throttle = new InfluenceRankNotificationThrottle(COOLDOWN);
    UUID playerId = UUID.randomUUID();
    Map<LeaderboardPeriod, Integer> previous = ranks(10);
    Map<LeaderboardPeriod, Integer> firstChange = ranks(9);
    Map<LeaderboardPeriod, Integer> secondChange = ranks(8);

    assertThat(throttle.claim(playerId, previous, previous, 0L)).isEmpty();
    assertThat(throttle.claim(playerId, firstChange, previous, 1L)).contains(previous);
    assertThat(throttle.claim(playerId, secondChange, previous, COOLDOWN.toMillis())).isEmpty();
    assertThat(throttle.claim(playerId, secondChange, previous, COOLDOWN.toMillis() + 1))
        .contains(firstChange);
    assertThat(throttle.claim(playerId, secondChange, previous, COOLDOWN.toMillis() + 2)).isEmpty();
  }

  private static Map<LeaderboardPeriod, Integer> ranks(int alltimeRank) {
    EnumMap<LeaderboardPeriod, Integer> ranks = new EnumMap<>(LeaderboardPeriod.class);
    for (LeaderboardPeriod period : LeaderboardPeriod.values()) {
      ranks.put(period, -1);
    }
    ranks.put(LeaderboardPeriod.ALLTIME, alltimeRank);
    return ranks;
  }
}
