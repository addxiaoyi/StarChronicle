package dev.starcore.starcore.social.gui;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;

class SocialLeaderboardGuiContractTest {

  @Test
  void renderedEntriesKeepTheirSlotMappingForDetailClicks() throws Exception {
    String gui =
        Files.readString(
            Path.of("src/main/java/dev/starcore/starcore/social/gui/SocialLeaderboardGui.java"));
    String listener =
        Files.readString(
            Path.of(
                "src/main/java/dev/starcore/starcore/social/gui/SocialLeaderboardListener.java"));

    assertThat(gui)
        .contains("entriesBySlot.put(slot, entry)")
        .contains("Optional<LeaderboardEntry> entryAt(int slot)")
        .contains("void showEntryDetails(int slot)")
        .contains("friendService.getKnownPlayerIds()")
        .doesNotContain("getDeclaredField(\"friendships\")")
        .contains("if (leaderboardService == null)")
        .contains("返回排行榜");
    assertThat(listener)
        .contains("case VIEW_ENTRY ->")
        .contains("gui.showEntryDetails(slot)")
        .doesNotContain("排行榜详情功能开发中");
  }
}
