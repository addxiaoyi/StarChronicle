package dev.starcore.starcore.social;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.event.player.*;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.social.simulation.*;
import dev.starcore.starcore.social.simulation.command.InfluenceLeaderboardCommand;
import dev.starcore.starcore.social.simulation.command.SocialSimCommand;
import dev.starcore.starcore.social.simulation.events.*;
import dev.starcore.starcore.title.TitleService;
import java.util.List;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * 社会模拟模块
 *
 * <p>提供真实的社会互动模拟，包括: - 声望系统: 玩家通过行为积累声望 - 关系网络: 追踪玩家间的复杂关系 - 社会影响力: 玩家的社交影响力 - 文化系统: 国家文化发展 - 新闻传播:
 * 信息在社会中的流动 - 社会事件: 节日、庆典、抗议等 - 社会阶层: 玩家社会地位系统 - 社交联盟: 玩家联盟组织 - 八卦传播: 流言蜚语系统 - 社交活动: 聚会、庆典、比赛等
 */
public final class SocialSimulationModule implements StarCoreModule {

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "social-simulation",
          "社会模拟",
          ModuleLayer.MODULE,
          List.of("nation", "social"),
          List.of(
              ReputationService.class,
              RelationshipNetwork.class,
              SocialInfluenceService.class,
              CultureService.class,
              NewsPropagationService.class,
              SocialEventScheduler.class,
              SocialClassService.class,
              SocialAllianceService.class,
              GossipService.class,
              SocialActivityService.class,
              GossipVerificationService.class,
              InfluenceLeaderboardService.class),
          "Realistic social simulation: reputation, relationships, influence, culture, news, class,"
              + " alliance, gossip, activities, leaderboard.");

  private JavaPlugin plugin;
  private volatile boolean running;
  private volatile long generation;
  private StarCoreContext activeContext;
  private final java.util.List<Runnable> commandCleanup = new java.util.ArrayList<>();
  private ReputationService reputationService;
  private RelationshipNetwork relationshipNetwork;
  private SocialInfluenceService influenceService;
  private SocialInfluenceWriteQueue influenceWriteQueue;
  private CultureService cultureService;
  private NewsPropagationService newsService;
  private SocialEventScheduler eventScheduler;
  private SocialSimulationListener listener;

  // 新增服务
  private SocialClassService classService;
  private SocialAllianceService allianceService;
  private GossipService gossipService;
  private SocialActivityService activityService;
  private ActivityRewardService activityRewardService;
  private CultureConflictService cultureConflictService;
  private TitleService titleService;
  private GossipVerificationService gossipVerificationService;

  // 影响力排行榜
  private InfluenceLeaderboardService leaderboardService;
  private InfluenceLeaderboardGui leaderboardGui;

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  @Override
  public void enable(StarCoreContext context) {
    if (activeContext != null) disable(activeContext);
    activeContext = context;
    running = false;
    generation++;
    this.plugin = context.plugin();
    try {
      enableServices(context);
    } catch (RuntimeException | Error failure) {
      try {
        disable(context);
      } catch (RuntimeException cleanup) {
        failure.addSuppressed(cleanup);
      }
      throw failure;
    }
  }

  private void enableServices(StarCoreContext context) {

    // 获取可选服务
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    DatabaseService databaseService = context.databaseService();

    try {
      // 初始化核心服务
      this.reputationService = new ReputationServiceImpl(plugin, databaseService);
      this.relationshipNetwork = new RelationshipNetworkImpl(plugin, databaseService);
      this.influenceService =
          new SocialInfluenceServiceImpl(
              plugin, reputationService, relationshipNetwork, databaseService);
    } catch (Exception e) {
      plugin
          .getLogger()
          .severe("Failed to initialize social simulation core services: " + e.getMessage());
      plugin.getLogger().warning("Social simulation module will have limited functionality");
      // 使用最小化配置继续
      this.reputationService = new ReputationServiceImpl(plugin, null);
      this.relationshipNetwork = new RelationshipNetworkImpl(plugin, null);
      this.influenceService = null;
    }
    this.influenceWriteQueue =
        new SocialInfluenceWriteQueue(
            influenceService,
            task ->
                context
                    .scheduler()
                    .runIoAsync(
                        () -> {
                          task.run();
                          return null;
                        }),
            (subject, failure) ->
                plugin
                    .getLogger()
                    .log(
                        java.util.logging.Level.SEVERE,
                        "SOCIAL_INFLUENCE_WRITE_FAILED " + subject,
                        failure));

    // CultureService 需要 NationService，如果不可用则使用简化版本
    if (nationService != null) {
      this.cultureService = new CultureServiceImpl(plugin, nationService, databaseService);
    } else {
      this.cultureService = new CultureServiceImpl(plugin);
      plugin
          .getLogger()
          .warning("NationService not available, CultureService will have limited functionality");
    }

    this.newsService = new NewsPropagationService(plugin, relationshipNetwork);
    this.eventScheduler =
        new SocialEventScheduler(plugin, reputationService, relationshipNetwork, cultureService);
    // 初始化事件调度器的持久化
    this.eventScheduler.initializePersistence(plugin, databaseService);

    // 初始化新服务
    this.classService = new SocialClassService(plugin);
    // 初始化联盟服务（带数据库持久化）
    this.allianceService = new SocialAllianceService(plugin, databaseService, context.scheduler());
    this.gossipService = new GossipService(plugin, relationshipNetwork, reputationService);
    this.activityService = new SocialActivityService();
    // 初始化活动服务的持久化
    this.activityService.initialize(plugin, databaseService);

    initializeActivityRewards(context);

    // 初始化文化冲突服务（如果 nationService 可用）
    if (nationService != null && context.serviceRegistry() != null) {
      this.cultureConflictService =
          new CultureConflictService(
              plugin, cultureService, nationService, context.serviceRegistry());
    } else {
      this.cultureConflictService = new CultureConflictService(plugin, cultureService);
    }

    // 初始化八卦验证服务
    this.gossipVerificationService =
        new GossipVerificationService(gossipService, reputationService, relationshipNetwork);

    // 初始化影响力排行榜服务
    this.leaderboardService =
        new InfluenceLeaderboardService(plugin, databaseService, influenceService);
    this.leaderboardGui = new InfluenceLeaderboardGui(plugin, leaderboardService);

    // 初始化监听器
    this.listener =
        new SocialSimulationListener(
            reputationService,
            relationshipNetwork,
            influenceService,
            newsService,
            eventScheduler,
            cultureService,
            activityService,
            gossipService,
            influenceWriteQueue);
    listener.register(plugin);

    // 启动定时任务
    eventScheduler.start();

    // 启动新闻传播
    newsService.start();

    // 启动影响力衰减
    if (influenceService != null) {
      influenceService.startDecayTask(task -> influenceWriteQueue.submitMaintenance("decay", task));
    }

    // 注册社会模拟服务到服务注册表
    registerSocialSimulationServices(context);

    // 注册命令
    running = true;
    registerCommands(context);

    plugin.getLogger().info("社会模拟模块已启用: 声望/关系/影响力/文化/新闻/阶层/联盟/八卦/活动");
  }

  public void initializeActivityRewards(StarCoreContext context) {
    if (activeContext != context) return;
    if (activityRewardService != null) {
      return;
    }
    this.titleService = context.serviceRegistry().find(TitleService.class).orElse(null);
    if (titleService == null) {
      plugin.getLogger().info("Activity rewards deferred until the title service is ready");
      return;
    }
    if (reputationService == null || influenceService == null || activityService == null) {
      plugin
          .getLogger()
          .warning(
              "Activity rewards cannot start because a required social service is unavailable");
      return;
    }
    this.activityRewardService =
        new ActivityRewardService(
            plugin,
            reputationService,
            context.economyService(),
            titleService,
            activityService,
            influenceWriteQueue);
    this.activityRewardService.loadParticipationData();
    plugin.getLogger().info("Activity reward service initialized");
  }

  /** 注册社会模拟服务到服务注册表 */
  private void registerSocialSimulationServices(StarCoreContext context) {
    var registry = context.serviceRegistry();
    if (reputationService != null) {
      registry.register(ReputationService.class, reputationService);
    }
    if (gossipService != null) {
      registry.register(GossipService.class, gossipService);
    }
    if (influenceService != null) {
      registry.register(SocialInfluenceService.class, influenceService);
    }
    if (cultureService != null) {
      registry.register(CultureService.class, cultureService);
    }
    if (relationshipNetwork != null) {
      registry.register(RelationshipNetwork.class, relationshipNetwork);
    }
    if (newsService != null) {
      registry.register(NewsPropagationService.class, newsService);
    }
    if (eventScheduler != null) {
      registry.register(SocialEventScheduler.class, eventScheduler);
    }
    if (classService != null) {
      registry.register(SocialClassService.class, classService);
    }
    if (allianceService != null) {
      registry.register(SocialAllianceService.class, allianceService);
    }
    if (activityService != null) {
      registry.register(SocialActivityService.class, activityService);
    }
    if (gossipVerificationService != null) {
      registry.register(GossipVerificationService.class, gossipVerificationService);
    }
    if (leaderboardService != null) {
      registry.register(InfluenceLeaderboardService.class, leaderboardService);
    }
    plugin.getLogger().info("社会模拟服务已注册到服务注册表");
  }

  @Override
  public void disable(StarCoreContext context) {
    running = false;
    generation++;
    activeContext = null;
    java.util.List<Runnable> cleanup = new java.util.ArrayList<>(commandCleanup);
    commandCleanup.clear();
    // Stop ingress and invalidate delayed player work before saving; one failure cannot skip
    // cleanup.
    if (gossipService != null) cleanup.add(gossipService::close);
    if (listener != null) cleanup.add(listener::unregister);
    if (eventScheduler != null) cleanup.add(eventScheduler::stop);
    if (newsService != null) cleanup.add(newsService::stop);
    if (influenceService != null) cleanup.add(influenceService::stopDecayTask);
    if (leaderboardGui != null) cleanup.add(leaderboardGui::shutdown);
    if (leaderboardService != null) cleanup.add(leaderboardService::shutdown);
    if (classService != null) cleanup.add(classService::saveData);
    if (gossipService != null) cleanup.add(gossipService::saveData);
    if (cultureService instanceof CultureServiceImpl culture) cleanup.add(culture::saveCultures);
    if (activityRewardService != null) cleanup.add(activityRewardService::saveParticipationData);
    if (reputationService != null) cleanup.add(reputationService::shutdown);
    var registry = context.serviceRegistry();
    if (reputationService != null)
      cleanup.add(() -> registry.unregister(ReputationService.class, reputationService));
    if (gossipService != null)
      cleanup.add(() -> registry.unregister(GossipService.class, gossipService));
    if (influenceService != null)
      cleanup.add(() -> registry.unregister(SocialInfluenceService.class, influenceService));
    if (cultureService != null)
      cleanup.add(() -> registry.unregister(CultureService.class, cultureService));
    if (relationshipNetwork != null)
      cleanup.add(() -> registry.unregister(RelationshipNetwork.class, relationshipNetwork));
    if (newsService != null)
      cleanup.add(() -> registry.unregister(NewsPropagationService.class, newsService));
    if (eventScheduler != null)
      cleanup.add(() -> registry.unregister(SocialEventScheduler.class, eventScheduler));
    if (classService != null)
      cleanup.add(() -> registry.unregister(SocialClassService.class, classService));
    if (allianceService != null)
      cleanup.add(() -> registry.unregister(SocialAllianceService.class, allianceService));
    if (activityService != null)
      cleanup.add(() -> registry.unregister(SocialActivityService.class, activityService));
    if (gossipVerificationService != null)
      cleanup.add(
          () -> registry.unregister(GossipVerificationService.class, gossipVerificationService));
    if (leaderboardService != null)
      cleanup.add(() -> registry.unregister(InfluenceLeaderboardService.class, leaderboardService));
    RuntimeException failure = null;
    for (Runnable action : cleanup) {
      try {
        action.run();
      } catch (RuntimeException error) {
        if (failure == null) failure = error;
        else failure.addSuppressed(error);
      }
    }
    reputationService = null;
    relationshipNetwork = null;
    influenceService = null;
    influenceWriteQueue = null;
    cultureService = null;
    newsService = null;
    eventScheduler = null;
    listener = null;
    classService = null;
    allianceService = null;
    gossipService = null;
    activityService = null;
    activityRewardService = null;
    cultureConflictService = null;
    titleService = null;
    gossipVerificationService = null;
    leaderboardService = null;
    leaderboardGui = null;
    if (failure != null) throw failure;
    context.plugin().getLogger().info("社会模拟模块已关闭并保存数据");
  }

  /** 注册命令 */
  private void registerCommands(StarCoreContext context) {
    SocialSimCommand command =
        new SocialSimCommand(
            this,
            reputationService,
            relationshipNetwork,
            influenceService,
            classService,
            allianceService,
            gossipService,
            activityService,
            newsService);

    bindCommand("socialsim", command, command);
    InfluenceLeaderboardCommand leaderboard = new InfluenceLeaderboardCommand(leaderboardGui);
    bindCommand("influencelb", leaderboard, leaderboard);
  }

  private void bindCommand(
      String name,
      org.bukkit.command.CommandExecutor executor,
      org.bukkit.command.TabCompleter completer) {
    var command = plugin.getServer().getPluginCommand(name);
    if (command == null) return;
    long epoch = generation;
    var oldExecutor = command.getExecutor();
    var oldCompleter = command.getTabCompleter();
    org.bukkit.command.CommandExecutor guarded =
        (sender, cmd, label, args) ->
            !running || generation != epoch || executor.onCommand(sender, cmd, label, args);
    org.bukkit.command.TabCompleter guardedCompleter =
        (sender, cmd, alias, args) ->
            running && generation == epoch
                ? completer.onTabComplete(sender, cmd, alias, args)
                : List.of();
    commandCleanup.add(
        () -> {
          if (command.getExecutor() == guarded) command.setExecutor(oldExecutor);
        });
    commandCleanup.add(
        () -> {
          if (command.getTabCompleter() == guardedCompleter) command.setTabCompleter(oldCompleter);
        });
    command.setExecutor(guarded);
    command.setTabCompleter(guardedCompleter);
  }

  // 服务获取方法
  public ReputationService reputationService() {
    return reputationService;
  }

  public RelationshipNetwork relationshipNetwork() {
    return relationshipNetwork;
  }

  public SocialInfluenceService influenceService() {
    return influenceService;
  }

  public CultureService cultureService() {
    return cultureService;
  }

  public CultureConflictService cultureConflictService() {
    return cultureConflictService;
  }

  public NewsPropagationService newsService() {
    return newsService;
  }

  public SocialEventScheduler eventScheduler() {
    return eventScheduler;
  }

  public SocialClassService classService() {
    return classService;
  }

  public SocialAllianceService allianceService() {
    return allianceService;
  }

  public GossipService gossipService() {
    return gossipService;
  }

  public SocialActivityService activityService() {
    return activityService;
  }

  public ActivityRewardService activityRewardService() {
    return activityRewardService;
  }

  public GossipVerificationService gossipVerificationService() {
    return gossipVerificationService;
  }

  public InfluenceLeaderboardService leaderboardService() {
    return leaderboardService;
  }

  public InfluenceLeaderboardGui leaderboardGui() {
    return leaderboardGui;
  }
}
