package dev.starcore.starcore.social.friend;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * 好友服务（星链系统）
 *
 * <p>支持两种持久化模式： 1. YAML 文件持久化（默认，兼容性更好） 2. 数据库持久化（通过 SqlSocialStateStorage）
 */
public final class FriendService {
  // 好友关系（玩家UUID -> 好友UUID列表）
  private final Map<UUID, Set<UUID>> friendships = new ConcurrentHashMap<>();

  // 好友请求（目标UUID -> 请求者UUID列表）
  private final Map<UUID, Set<UUID>> friendRequests = new ConcurrentHashMap<>();

  // 黑名单（玩家UUID -> 黑名单UUID列表）
  private final Map<UUID, Set<UUID>> blacklist = new ConcurrentHashMap<>();

  // 在线状态追踪（玩家UUID -> 是否在线）
  private final Map<UUID, Boolean> onlineStatus = new ConcurrentHashMap<>();

  // 好友上限
  private final int maxFriends = 100;

  // 数据库存储引用（可选）
  private dev.starcore.starcore.social.SqlSocialStateStorage sqlStorage;

  /** 设置数据库存储（用于数据库持久化） */
  public void setSqlStorage(dev.starcore.starcore.social.SqlSocialStateStorage sqlStorage) {
    this.sqlStorage = sqlStorage;
  }

  /** 检查数据库是否可用 */
  public boolean isDatabaseAvailable() {
    return sqlStorage != null && sqlStorage.isDatabaseAvailable();
  }

  /** 发送好友请求 */
  public boolean sendFriendRequest(UUID senderId, UUID targetId) {
    Objects.requireNonNull(senderId, "senderId");
    Objects.requireNonNull(targetId, "targetId");

    // 不能添加自己
    if (senderId.equals(targetId)) {
      throw new IllegalArgumentException("不能添加自己为好友");
    }

    // 检查是否已经是好友
    if (isFriend(senderId, targetId)) {
      throw new IllegalStateException("你们已经是好友了");
    }

    // 检查双向黑名单：目标拉黑发送者 或 发送者拉黑目标，均拒绝
    if (isBlacklisted(targetId, senderId) || isBlacklisted(senderId, targetId)) {
      throw new IllegalStateException("无法发送好友请求");
    }

    // 检查反向请求：若 target 已向 sender 发出请求（targetId 的请求列表里包含 senderId），则自动结为好友
    Set<UUID> fromTarget = friendRequests.get(targetId);
    if (fromTarget != null && fromTarget.remove(senderId)) {
      if (fromTarget.isEmpty()) friendRequests.remove(targetId);
      // 清理 senderId 反向记录（之前 sender→target 写入了双向）
      Set<UUID> fromSender = friendRequests.get(senderId);
      if (fromSender != null) {
        fromSender.remove(targetId);
        if (fromSender.isEmpty()) friendRequests.remove(senderId);
      }
      // 直接建立双向好友（不走 acceptFriendRequest，避免依赖请求列表）
      addFriendshipDirect(senderId, targetId);
      return true;
    }

    // 检查好友上限
    if (getFriendCount(senderId) >= maxFriends) {
      throw new IllegalStateException("好友数量已达上限");
    }

    // 添加请求：双向记录
    friendRequests.computeIfAbsent(targetId, k -> new CopyOnWriteArraySet<>()).add(senderId);
    friendRequests.computeIfAbsent(senderId, k -> new CopyOnWriteArraySet<>()).add(targetId);

    saveFriendRequestToDatabase(targetId, senderId);
    return true;
  }

  /** 接受好友请求 */
  public boolean acceptFriendRequest(UUID playerId, UUID requesterId) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(requesterId, "requesterId");
    if (playerId.equals(requesterId)) {
      throw new IllegalArgumentException("不能添加自己为好友");
    }

    // 黑名单校验优先于请求存在性检查（避免 addToBlacklist 后请求被清理导致 throw 被掩盖）
    if (isBlacklisted(playerId, requesterId) || isBlacklisted(requesterId, playerId)) {
      throw new IllegalStateException("无法接受好友请求：黑名单中包含对方");
    }

    // 检查请求是否存在
    Set<UUID> requests = friendRequests.get(playerId);
    if (requests == null || !requests.remove(requesterId)) {
      return false;
    }
    if (requests.isEmpty()) {
      friendRequests.remove(playerId);
    }

    // 清理请求方"已发送"记录
    Set<UUID> senderBox = friendRequests.get(requesterId);
    if (senderBox != null) {
      senderBox.remove(playerId);
      if (senderBox.isEmpty()) friendRequests.remove(requesterId);
    }

    // 双方均校验上限
    if (getFriendCount(playerId) >= maxFriends) {
      throw new IllegalStateException("你的好友数量已达上限");
    }
    if (getFriendCount(requesterId) >= maxFriends) {
      throw new IllegalStateException("对方好友数量已达上限");
    }

    // 已是好友则返回 false（幂等）
    if (isFriend(playerId, requesterId)) {
      return false;
    }

    // 建立双向好友关系
    friendships.computeIfAbsent(playerId, k -> new CopyOnWriteArraySet<>()).add(requesterId);
    friendships.computeIfAbsent(requesterId, k -> new CopyOnWriteArraySet<>()).add(playerId);

    deleteFriendRequestFromDatabase(playerId, requesterId);
    saveFriendToDatabase(playerId, requesterId);
    saveFriendToDatabase(requesterId, playerId);
    return true;
  }

  /** 拒绝好友请求 */
  public boolean rejectFriendRequest(UUID playerId, UUID requesterId) {
    Set<UUID> requests = friendRequests.get(playerId);
    boolean removed = requests != null && requests.remove(requesterId);
    if (removed) {
      deleteFriendRequestFromDatabase(playerId, requesterId);
    }
    return removed;
  }

  /** 删除好友 */
  public boolean removeFriend(UUID playerId, UUID friendId) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(friendId, "friendId");

    // 只能从自己的好友列表中移除
    Set<UUID> friends1 = friendships.get(playerId);
    if (friends1 == null || !friends1.contains(friendId)) {
      return false;
    }

    boolean removed1 = false;
    boolean removed2 = false;

    if (friends1 != null) {
      removed1 = friends1.remove(friendId);
    }

    Set<UUID> friends2 = friendships.get(friendId);
    if (friends2 != null) {
      removed2 = friends2.remove(playerId);
    }

    if (removed1 || removed2) {
      deleteFriendFromDatabase(playerId, friendId);
    }
    return removed1 || removed2;
  }

  /** 检查是否是好友 */
  public boolean isFriend(UUID playerId, UUID targetId) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(targetId, "targetId");
    Set<UUID> friends = friendships.get(playerId);
    return friends != null && friends.contains(targetId);
  }

  /** 获取好友列表 */
  public Set<UUID> getFriends(UUID playerId) {
    Set<UUID> friends = friendships.get(playerId);
    return friends != null ? new HashSet<>(friends) : Collections.emptySet();
  }

  /** Returns a snapshot of every player referenced by the in-memory social state. */
  public Set<UUID> getKnownPlayerIds() {
    Set<UUID> playerIds = new HashSet<>();
    playerIds.addAll(friendships.keySet());
    playerIds.addAll(friendRequests.keySet());
    playerIds.addAll(blacklist.keySet());
    playerIds.addAll(onlineStatus.keySet());
    friendships.values().forEach(playerIds::addAll);
    friendRequests.values().forEach(playerIds::addAll);
    blacklist.values().forEach(playerIds::addAll);
    return Set.copyOf(playerIds);
  }

  /** 获取好友数量 */
  public int getFriendCount(UUID playerId) {
    Set<UUID> friends = friendships.get(playerId);
    return friends != null ? friends.size() : 0;
  }

  /** 获取好友请求列表 */
  public Set<UUID> getFriendRequests(UUID playerId) {
    Set<UUID> requests = friendRequests.get(playerId);
    return requests != null ? new HashSet<>(requests) : Collections.emptySet();
  }

  /** 添加到黑名单（单向） */
  public boolean addToBlacklist(UUID playerId, UUID targetId) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(targetId, "targetId");
    if (playerId.equals(targetId)) {
      throw new IllegalArgumentException("不能拉黑自己");
    }
    // 重复拉黑返回 false（幂等）
    if (isBlacklisted(playerId, targetId)) {
      return false;
    }

    // 双向移除好友关系
    Set<UUID> playerFriends = friendships.get(playerId);
    boolean playerRemoved = false;
    if (playerFriends != null) {
      playerRemoved = playerFriends.remove(targetId);
    }
    Set<UUID> targetFriends = friendships.get(targetId);
    boolean targetRemoved = false;
    if (targetFriends != null) {
      targetRemoved = targetFriends.remove(playerId);
    }
    if (playerRemoved || targetRemoved) {
      deleteFriendFromDatabase(playerId, targetId);
    }

    // 双向清除待处理好友请求
    clearFriendRequestsBetween(playerId, targetId);

    // 单向拉黑
    blacklist.computeIfAbsent(playerId, k -> new CopyOnWriteArraySet<UUID>()).add(targetId);

    saveBlacklistToDatabase(playerId, targetId);
    return true;
  }

  /** 清除两人之间的待处理好友请求（双向） */
  private void clearFriendRequestsBetween(UUID playerId, UUID targetId) {
    Set<UUID> aToB = friendRequests.get(playerId);
    if (aToB != null) {
      aToB.remove(targetId);
      if (aToB.isEmpty()) friendRequests.remove(playerId);
    }
    Set<UUID> bToA = friendRequests.get(targetId);
    if (bToA != null) {
      bToA.remove(playerId);
      if (bToA.isEmpty()) friendRequests.remove(targetId);
    }
  }

  /** 直接建立双向好友关系（不写请求记录） */
  private void addFriendshipDirect(UUID playerId, UUID targetId) {
    friendships.computeIfAbsent(playerId, k -> new CopyOnWriteArraySet<>()).add(targetId);
    friendships.computeIfAbsent(targetId, k -> new CopyOnWriteArraySet<>()).add(playerId);
  }

  /** 从黑名单移除 */
  public boolean removeFromBlacklist(UUID playerId, UUID targetId) {
    Set<UUID> list = blacklist.get(playerId);
    boolean removed = list != null && list.remove(targetId);
    if (removed) {
      deleteBlacklistFromDatabase(playerId, targetId);
    }
    return removed;
  }

  /** 检查是否在黑名单 */
  public boolean isBlacklisted(UUID playerId, UUID targetId) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(targetId, "targetId");
    Set<UUID> list = blacklist.get(playerId);
    return list != null && list.contains(targetId);
  }

  /** 获取黑名单 */
  public Set<UUID> getBlacklist(UUID playerId) {
    Set<UUID> list = blacklist.get(playerId);
    return list != null ? new HashSet<>(list) : Collections.emptySet();
  }

  /** 获取在线好友 */
  public Set<UUID> getOnlineFriends(UUID playerId, Set<UUID> onlinePlayers) {
    Set<UUID> friends = getFriends(playerId);
    Set<UUID> online = new HashSet<>();

    for (UUID friendId : friends) {
      if (onlinePlayers.contains(friendId)) {
        online.add(friendId);
      }
    }

    return online;
  }

  /** 清理玩家数据 */
  public void cleanup(UUID playerId) {
    // 先取出玩家自己的列表，避免遍历时删自己造成并发修改
    Set<UUID> myFriends = friendships.remove(playerId);
    friendRequests.remove(playerId);
    blacklist.remove(playerId);
    onlineStatus.remove(playerId);

    // 仅清理自己列表里引用的玩家（friendships/requests 是双向图，需要两侧都清）
    if (myFriends != null) {
      for (UUID friendId : myFriends) {
        Set<UUID> other = friendships.get(friendId);
        if (other != null) other.remove(playerId);
      }
    }
    // friendRequests/onlineStatus 是 key 索引式结构，无需反向清理

    // 注意：黑名单不双向清理。alice 拉黑了 bob，cleanup(alice) 不应清掉 carol 对 bob 的黑名单。
  }

  // ========== 持久化支持 ==========

  /** 导出所有好友关系（用于保存）。 */
  public Map<UUID, Set<UUID>> exportFriendships() {
    Map<UUID, Set<UUID>> snapshot = new java.util.HashMap<>();
    for (Map.Entry<UUID, Set<UUID>> e : friendships.entrySet()) {
      snapshot.put(e.getKey(), new HashSet<>(e.getValue()));
    }
    return snapshot;
  }

  /** 直接建立双向好友关系（用于加载，跳过校验）。 */
  public void loadFriendship(UUID a, UUID b) {
    friendships.computeIfAbsent(a, k -> new CopyOnWriteArraySet<>()).add(b);
    friendships.computeIfAbsent(b, k -> new CopyOnWriteArraySet<>()).add(a);
  }

  public void loadFromDatabase() {
    if (sqlStorage != null) {
      sqlStorage.loadAllFriendRelations(friendships);
    }
  }

  public void saveFriendToDatabase(UUID playerId, UUID friendId) {
    if (sqlStorage != null) {
      sqlStorage.saveFriendRelation(playerId, friendId, System.currentTimeMillis());
    }
  }

  public void deleteFriendFromDatabase(UUID playerId, UUID friendId) {
    if (sqlStorage != null) {
      sqlStorage.deleteFriendRelation(playerId, friendId);
    }
  }

  public void saveAllToDatabase() {
    if (sqlStorage != null) {
      sqlStorage.saveAllFriends(friendships);
    }
  }

  // ========== 好友请求持久化 ==========

  public Map<UUID, Set<UUID>> exportFriendRequests() {
    Map<UUID, Set<UUID>> snapshot = new java.util.HashMap<>();
    for (Map.Entry<UUID, Set<UUID>> e : friendRequests.entrySet()) {
      snapshot.put(e.getKey(), new HashSet<>(e.getValue()));
    }
    return snapshot;
  }

  public void loadFriendRequest(UUID targetId, UUID requesterId) {
    friendRequests.computeIfAbsent(targetId, k -> new CopyOnWriteArraySet<>()).add(requesterId);
  }

  public void loadFriendRequestsFromDatabase() {
    if (sqlStorage != null) {
      sqlStorage.loadAllFriendRequests(friendRequests);
    }
  }

  public void saveFriendRequestToDatabase(UUID targetId, UUID senderId) {
    if (sqlStorage != null) {
      sqlStorage.saveFriendRequest(targetId, senderId, System.currentTimeMillis());
    }
  }

  public void deleteFriendRequestFromDatabase(UUID targetId, UUID senderId) {
    if (sqlStorage != null) {
      sqlStorage.deleteFriendRequest(targetId, senderId);
    }
  }

  public void clearFriendRequests(UUID playerId) {
    friendRequests.remove(playerId);
  }

  // ========== 黑名单持久化 ==========

  public Map<UUID, Set<UUID>> exportBlacklist() {
    Map<UUID, Set<UUID>> snapshot = new java.util.HashMap<>();
    for (Map.Entry<UUID, Set<UUID>> e : blacklist.entrySet()) {
      snapshot.put(e.getKey(), new HashSet<>(e.getValue()));
    }
    return snapshot;
  }

  public void loadBlacklistEntry(UUID playerId, UUID blockedId) {
    blacklist.computeIfAbsent(playerId, k -> new CopyOnWriteArraySet<>()).add(blockedId);
  }

  public void loadBlacklistFromDatabase() {
    if (sqlStorage != null) {
      sqlStorage.loadAllBlacklist(blacklist);
    }
  }

  public void saveBlacklistToDatabase(UUID playerId, UUID blockedId) {
    if (sqlStorage != null) {
      sqlStorage.saveBlacklistEntry(playerId, blockedId, System.currentTimeMillis());
    }
  }

  public void deleteBlacklistFromDatabase(UUID playerId, UUID blockedId) {
    if (sqlStorage != null) {
      sqlStorage.deleteBlacklistEntry(playerId, blockedId);
    }
  }

  public void clearBlacklist(UUID playerId) {
    blacklist.remove(playerId);
  }

  // ========== 在线状态追踪持久化 ==========

  public Map<UUID, Boolean> exportOnlineStatus() {
    return new java.util.HashMap<>(onlineStatus);
  }

  public void loadOnlineStatus(UUID playerId, boolean isOnline) {
    onlineStatus.put(playerId, isOnline);
  }

  public void setOnlineStatus(UUID playerId, boolean isOnline) {
    onlineStatus.put(playerId, isOnline);
    saveOnlineStatusToDatabase(playerId, isOnline);
  }

  public boolean getOnlineStatus(UUID playerId) {
    return onlineStatus.getOrDefault(playerId, false);
  }

  public void loadOnlineStatusFromDatabase() {
    if (sqlStorage != null) {
      sqlStorage.loadAllPlayerStatus(onlineStatus);
    }
  }

  public void saveOnlineStatusToDatabase(UUID playerId, boolean isOnline) {
    if (sqlStorage != null) {
      sqlStorage.savePlayerStatus(playerId, isOnline);
    }
  }

  public Map<UUID, Boolean> getAllOnlineStatus() {
    return new java.util.HashMap<>(onlineStatus);
  }
}
