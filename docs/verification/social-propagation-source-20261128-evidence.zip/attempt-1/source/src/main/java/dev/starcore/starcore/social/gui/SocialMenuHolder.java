package dev.starcore.starcore.social.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Identifies social pages without claiming other StarCore menus. */
final class SocialMenuHolder implements InventoryHolder {
  @Override
  public Inventory getInventory() {
    return null;
  }
}
