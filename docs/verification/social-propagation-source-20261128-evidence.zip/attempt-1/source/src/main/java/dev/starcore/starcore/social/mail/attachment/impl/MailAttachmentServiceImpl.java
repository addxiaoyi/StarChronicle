package dev.starcore.starcore.social.mail.attachment.impl;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseUtils;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.social.mail.Mail;
import dev.starcore.starcore.social.mail.MailService;
import dev.starcore.starcore.social.mail.attachment.MailAttachmentService;
import dev.starcore.starcore.social.mail.attachment.MailAttachmentService.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * 邮件附件服务实现
 *
 * <p>功能： 1. 附件序列化与反序列化 2. 附件验证与限制检查 3. 附件领取逻辑 4. 附件价值估算 5. 领取历史记录
 */
public final class MailAttachmentServiceImpl implements MailAttachmentService {

  // 附件相关配置常量
  private static final int MAX_ATTACHMENTS_PER_MAIL = 27; // 最多27个物品
  private static final int MAX_STACK_SIZE = 64;
  private static final long ATTACHMENT_EXPIRATION_DAYS = 30;
  private static final long MAX_ATTACHMENT_VALUE = 1_000_000_000L; // 10亿金币上限
  private static final long SHUTDOWN_WAIT_MILLIS = 5_000L;

  // 禁止传输的物品类型
  private static final Set<Material> FORBIDDEN_MATERIALS =
      EnumSet.of(
          Material.AIR,
          Material.WRITTEN_BOOK,
          Material.WRITABLE_BOOK,
          Material.FILLED_MAP,
          Material.MAP,
          Material.OMINOUS_BOTTLE,
          Material.AXOLOTL_BUCKET,
          Material.TADPOLE_BUCKET,
          Material.POWDER_SNOW_BUCKET,
          Material.LAVA_BUCKET,
          Material.WATER_BUCKET,
          Material.MILK_BUCKET);

  private final DatabaseService databaseService;
  private final StarCoreScheduler scheduler;
  private final MailService mailService;
  private final Logger logger;
  private volatile boolean running = true;
  private final Set<PendingEntityOperation<?>> pendingEntityOperations =
      ConcurrentHashMap.newKeySet();
  private final Set<CompletableFuture<?>> pendingPersistenceWrites = ConcurrentHashMap.newKeySet();
  private final Object lifecycleMonitor = new Object();
  private final ThreadLocal<Set<PendingEntityOperation<?>>> executingOperations =
      new ThreadLocal<>();
  private long shutdownWaitMillis = SHUTDOWN_WAIT_MILLIS;

  // 领取记录缓存: playerId -> List<ClaimRecord>
  private final Map<UUID, List<AttachmentClaimRecord>> claimHistoryCache =
      new ConcurrentHashMap<>();

  // 物品价值估算表（常用物品）
  private static final Map<String, Long> ITEM_VALUE_TABLE = new ConcurrentHashMap<>();

  static {
    // 矿物类
    ITEM_VALUE_TABLE.put("DIAMOND", 1000L);
    ITEM_VALUE_TABLE.put("EMERALD", 500L);
    ITEM_VALUE_TABLE.put("GOLD_INGOT", 100L);
    ITEM_VALUE_TABLE.put("IRON_INGOT", 50L);
    ITEM_VALUE_TABLE.put("COPPER_INGOT", 20L);

    // 附魔类
    ITEM_VALUE_TABLE.put("ENCHANTED_GOLDEN_APPLE", 50000L);
    ITEM_VALUE_TABLE.put("GOLDEN_APPLE", 5000L);
    ITEM_VALUE_TABLE.put("ENCHANTED_BOOK", 2000L);

    // 稀有物品
    ITEM_VALUE_TABLE.put("NETHER_STAR", 10000L);
    ITEM_VALUE_TABLE.put("DRAGON_BREATH", 2000L);
    ITEM_VALUE_TABLE.put("SHULKER_BOX", 5000L);
    ITEM_VALUE_TABLE.put("ELYTRA", 10000L);
    ITEM_VALUE_TABLE.put("NETHERITE_INGOT", 50000L);
    ITEM_VALUE_TABLE.put("NETHERITE_SWORD", 100000L);
    ITEM_VALUE_TABLE.put("NETHERITE_HELMET", 80000L);
    ITEM_VALUE_TABLE.put("NETHERITE_CHESTPLATE", 100000L);
    ITEM_VALUE_TABLE.put("NETHERITE_LEGGINGS", 90000L);
    ITEM_VALUE_TABLE.put("NETHERITE_BOOTS", 80000L);

    // 常规物品默认值
    ITEM_VALUE_TABLE.put("DEFAULT", 10L);
  }

  public MailAttachmentServiceImpl(
      DatabaseService databaseService,
      StarCoreScheduler scheduler,
      MailService mailService,
      Logger logger) {
    this.databaseService = databaseService;
    this.scheduler = scheduler;
    this.mailService = mailService;
    this.logger = logger;

    // 初始化数据库表
    ensureTables();
  }

  /** 创建数据库表 */
  private void ensureTables() {
    if (!databaseService.isRunning()) {
      logger.info("邮件附件系统使用缓存模式（数据库不可用）");
      return;
    }

    try {
      databaseService
          .dataSource()
          .ifPresent(
              ds -> {
                try (Connection conn = ds.getConnection();
                    Statement stmt = conn.createStatement()) {
                  String idColumn =
                      DatabaseUtils.autoIncrementPrimaryKey(DatabaseUtils.detectDatabaseType(conn));

                  // 附件领取记录表
                  stmt.execute(
                          """
                              CREATE TABLE IF NOT EXISTS starcore_mail_attachment_claims (
                                  id %s,
                                  record_id VARCHAR(36) NOT NULL UNIQUE,
                                  player_id VARCHAR(36) NOT NULL,
                                  mail_id VARCHAR(36) NOT NULL,
                                  sender_id VARCHAR(36),
                                  sender_name VARCHAR(64),
                                  attachment_data TEXT,
                                  claimed_at BIGINT NOT NULL,
                                  total_value BIGINT DEFAULT 0
                              )
                          """
                          .formatted(idColumn));
                  DatabaseUtils.ensureIndex(
                      conn,
                      "starcore_mail_attachment_claims",
                      "idx_player_attachment",
                      "player_id");
                  DatabaseUtils.ensureIndex(
                      conn, "starcore_mail_attachment_claims", "idx_mail_attachment", "mail_id");
                  DatabaseUtils.ensureIndex(
                      conn, "starcore_mail_attachment_claims", "idx_claimed_at", "claimed_at");

                  logger.info("邮件附件系统数据库表已初始化");
                } catch (SQLException e) {
                  logger.warning("初始化邮件附件数据库表失败: " + e.getMessage());
                }
              });
    } catch (Exception e) {
      logger.warning("邮件附件系统数据库初始化失败: " + e.getMessage());
    }
  }

  @Override
  public AttachmentValidationResult validateAttachments(List<ItemStack> items) {
    if (items == null || items.isEmpty()) {
      return AttachmentValidationResult.success(0);
    }

    List<String> warnings = new ArrayList<>();
    int validCount = 0;
    int invalidCount = 0;

    // 检查数量限制
    if (items.size() > MAX_ATTACHMENTS_PER_MAIL) {
      return AttachmentValidationResult.failure("附件数量超过限制（最多 " + MAX_ATTACHMENTS_PER_MAIL + " 个）");
    }

    for (int i = 0; i < items.size(); i++) {
      ItemStack item = items.get(i);
      if (item == null || isAir(item)) {
        invalidCount++;
        continue;
      }

      // 检查禁止的物品类型
      if (FORBIDDEN_MATERIALS.contains(item.getType())) {
        invalidCount++;
        warnings.add("物品 [" + (i + 1) + "] " + item.getType().name() + " 禁止传输");
        continue;
      }

      // 检查数量合理性
      if (item.getAmount() <= 0 || item.getAmount() > MAX_STACK_SIZE * 64) {
        invalidCount++;
        warnings.add("物品 [" + (i + 1) + "] 数量异常");
        continue;
      }

      validCount++;
    }

    if (invalidCount > 0 && validCount == 0) {
      return AttachmentValidationResult.failure("所有附件均无效");
    }

    return AttachmentValidationResult.partialSuccess(validCount, invalidCount, warnings);
  }

  @Override
  public List<MailAttachment> serializeAttachments(List<ItemStack> items) {
    if (items == null || items.isEmpty()) {
      return List.of();
    }

    List<MailAttachment> attachments = new ArrayList<>();
    for (ItemStack item : items) {
      if (item != null && !isAir(item) && !FORBIDDEN_MATERIALS.contains(item.getType())) {
        MailAttachment attachment = MailAttachment.fromItemStack(item);
        if (attachment != null) {
          attachments.add(attachment);
        }
      }
    }
    return attachments;
  }

  @Override
  public List<ItemStack> deserializeAttachments(List<MailAttachment> attachments) {
    if (attachments == null || attachments.isEmpty()) {
      return List.of();
    }

    List<ItemStack> items = new ArrayList<>();
    for (MailAttachment attachment : attachments) {
      if (attachment != null) {
        ItemStack item = attachment.toItemStack();
        if (item != null && !isAir(item)) {
          items.add(item);
        }
      }
    }
    return items;
  }

  @Override
  public AttachmentClaimResult claimAttachments(Player player, UUID mailId) {
    if (!running) {
      return AttachmentClaimResult.failure("附件服务正在关闭");
    }
    if (player == null || mailId == null) {
      return AttachmentClaimResult.failure("参数错误");
    }
    return runSynchronousOperation(
        () -> claimAttachmentsOnOwner(player, mailId), AttachmentClaimResult.failure("附件服务正在关闭"));
  }

  private AttachmentClaimResult claimAttachmentsOnOwner(Player player, UUID mailId) {
    scheduler.requireEntityOwner(player);

    Mail targetMail = null;
    for (Mail mail : mailService.getPlayerMails(player.getUniqueId())) {
      if (mail.getId().equals(mailId)) {
        targetMail = mail;
        break;
      }
    }
    if (targetMail == null) {
      return AttachmentClaimResult.failure("邮件不存在");
    }
    if (!targetMail.hasAttachments()) {
      return AttachmentClaimResult.noAttachments();
    }
    if (targetMail.isClaimed()) {
      return AttachmentClaimResult.alreadyClaimed();
    }

    List<ItemStack> items = new ArrayList<>();
    for (var attachment : targetMail.getAttachments()) {
      ItemStack item = attachment.deserializeItem();
      if (item != null && !isAir(item)) {
        items.add(item);
      }
    }
    if (items.isEmpty()) {
      return AttachmentClaimResult.noAttachments();
    }

    ItemStack[] originalContents = cloneStorageContents(player);
    ItemStack[] updatedContents = mergeIntoStorage(originalContents, items);
    if (updatedContents == null) {
      return AttachmentClaimResult.failure("背包空间不足，请清理背包后重试");
    }
    if (!running) {
      return AttachmentClaimResult.failure("附件服务正在关闭");
    }

    try {
      player.getInventory().setStorageContents(updatedContents);
    } catch (RuntimeException exception) {
      logger.warning("发放邮件附件失败: " + exception.getMessage());
      return AttachmentClaimResult.failure("附件发放失败，请稍后重试");
    }

    if (!mailService.confirmClaimed(player.getUniqueId(), mailId)) {
      try {
        player.getInventory().setStorageContents(originalContents);
      } catch (RuntimeException rollbackFailure) {
        logger.severe("回滚邮件附件失败: " + rollbackFailure.getMessage());
      }
      return AttachmentClaimResult.failure("附件状态保存失败，请稍后重试");
    }

    logAttachmentClaimInternal(player.getUniqueId(), mailId, serializeAttachments(items));
    return AttachmentClaimResult.success(items, items.size());
  }

  @Override
  public CompletableFuture<AttachmentClaimResult> claimAttachmentsAsync(
      Player player, UUID mailId) {
    if (player == null || mailId == null) {
      return running
          ? CompletableFuture.completedFuture(AttachmentClaimResult.failure("参数错误"))
          : CompletableFuture.failedFuture(
              new IllegalStateException("Mail attachment service is stopped"));
    }
    return supplyOnPlayerOwner(player, () -> claimAttachments(player, mailId));
  }

  @Override
  public void stopAcceptingOperations() {
    List<PendingEntityOperation<?>> pendingOperations;
    synchronized (lifecycleMonitor) {
      running = false;
      pendingOperations = List.copyOf(pendingEntityOperations);
    }
    for (PendingEntityOperation<?> pending : pendingOperations) {
      if (pending.cancelIfNotStarted()) {
        finishOperation(pending);
        pending.cancelFuture();
      }
    }
  }

  @Override
  public void shutdown() {
    stopAcceptingOperations();
    awaitTrackedWork();
  }

  private <T> T runSynchronousOperation(Supplier<T> supplier, T stoppedResult) {
    if (executingOperations.get() != null) return supplier.get();
    PendingEntityOperation<T> pending = new PendingEntityOperation<>(new CompletableFuture<>());
    synchronized (lifecycleMonitor) {
      if (!running) return stoppedResult;
      pending.beginExecution();
      pendingEntityOperations.add(pending);
    }
    beginLocalExecution(pending);
    try {
      return supplier.get();
    } finally {
      finishLocalExecution(pending);
      finishOperation(pending);
    }
  }

  private <T> CompletableFuture<T> supplyOnPlayerOwner(Player player, Supplier<T> supplier) {
    CompletableFuture<T> future = new CompletableFuture<>();
    PendingEntityOperation<T> pending = new PendingEntityOperation<>(future);
    synchronized (lifecycleMonitor) {
      if (!running) {
        future.completeExceptionally(
            new IllegalStateException("Mail attachment service is stopped"));
        return future;
      }
      pendingEntityOperations.add(pending);
    }
    future.whenComplete(
        (result, failure) -> {
          if (future.isCancelled() && pending.cancelIfNotStarted()) {
            finishOperation(pending);
          }
        });
    try {
      CompletableFuture<Void> task =
          scheduler.callForEntity(
              player,
              () -> {
                if (!pending.beginExecution()) {
                  return null;
                }
                T result = null;
                Throwable failure = null;
                boolean cancelled = false;
                beginLocalExecution(pending);
                try {
                  if (!running || future.isCancelled()) cancelled = true;
                  else result = supplier.get();
                } catch (Throwable throwable) {
                  failure = throwable;
                } finally {
                  finishLocalExecution(pending);
                  finishOperation(pending);
                }
                if (cancelled) pending.cancelFuture();
                else if (failure != null) future.completeExceptionally(failure);
                else future.complete(result);
                return null;
              });
      pending.setTask(task);
      task.whenComplete(
          (result, failure) -> {
            if (pending.beginExecution()) {
              finishOperation(pending);
              if (failure == null) {
                pending.cancelFuture();
              } else {
                future.completeExceptionally(failure);
              }
            }
          });
    } catch (RuntimeException | Error exception) {
      if (pending.beginExecution()) {
        finishOperation(pending);
        future.completeExceptionally(exception);
      }
    }
    return future;
  }

  private void finishOperation(PendingEntityOperation<?> pending) {
    pendingEntityOperations.remove(pending);
    signalLifecycleChange();
  }

  private void beginLocalExecution(PendingEntityOperation<?> pending) {
    Set<PendingEntityOperation<?>> operations = executingOperations.get();
    if (operations == null) {
      operations = new HashSet<>();
      executingOperations.set(operations);
    }
    operations.add(pending);
  }

  private void finishLocalExecution(PendingEntityOperation<?> pending) {
    Set<PendingEntityOperation<?>> operations = executingOperations.get();
    operations.remove(pending);
    if (operations.isEmpty()) executingOperations.remove();
  }

  private static final class PendingEntityOperation<T> {
    private final CompletableFuture<T> future;
    private final AtomicBoolean started = new AtomicBoolean();
    private volatile CompletableFuture<?> task;
    private volatile boolean cancelledBeforeExecution;

    private PendingEntityOperation(CompletableFuture<T> future) {
      this.future = future;
    }

    private void setTask(CompletableFuture<?> task) {
      this.task = task;
      if (cancelledBeforeExecution) {
        cancelTask();
      }
    }

    private boolean beginExecution() {
      return started.compareAndSet(false, true);
    }

    private boolean cancelIfNotStarted() {
      if (!started.compareAndSet(false, true)) {
        return false;
      }
      cancelledBeforeExecution = true;
      cancelTask();
      return true;
    }

    private void cancelTask() {
      CompletableFuture<?> current = task;
      if (current != null) {
        current.cancel(false);
      }
    }

    private void cancelFuture() {
      future.completeExceptionally(
          new CancellationException("Mail attachment operation cancelled"));
    }
  }

  private static boolean isAir(ItemStack item) {
    if (item == null) {
      return true;
    }
    Material type = item.getType();
    return type == null
        || type == Material.AIR
        || type == Material.CAVE_AIR
        || type == Material.VOID_AIR;
  }

  @Override
  public boolean hasInventorySpace(Player player, List<ItemStack> items) {
    if (player == null || items == null || items.isEmpty()) {
      return true;
    }
    scheduler.requireEntityOwner(player);
    int emptySlots = 0;
    for (ItemStack item : player.getInventory().getStorageContents()) {
      if (item == null || isAir(item)) {
        emptySlots++;
      }
    }
    return emptySlots >= calculateRequiredSlots(player, items);
  }

  @Override
  public int calculateRequiredSlots(Player player, List<ItemStack> items) {
    if (player == null || items == null || items.isEmpty()) {
      return 0;
    }
    scheduler.requireEntityOwner(player);

    List<ItemStack> virtualStacks = new ArrayList<>();
    for (ItemStack existing : player.getInventory().getStorageContents()) {
      if (existing != null && !isAir(existing)) {
        virtualStacks.add(existing.clone());
      }
    }

    int requiredSlots = 0;
    for (ItemStack source : items) {
      if (source == null || isAir(source)) {
        continue;
      }
      ItemStack incoming = source.clone();
      int remaining = incoming.getAmount();
      for (ItemStack existing : virtualStacks) {
        if (!existing.isSimilar(incoming)) {
          continue;
        }
        int capacity = existing.getMaxStackSize() - existing.getAmount();
        if (capacity <= 0) {
          continue;
        }
        int moved = Math.min(capacity, remaining);
        existing.setAmount(existing.getAmount() + moved);
        remaining -= moved;
        if (remaining == 0) {
          break;
        }
      }
      while (remaining > 0) {
        int amount = Math.min(incoming.getMaxStackSize(), remaining);
        ItemStack newStack = incoming.clone();
        newStack.setAmount(amount);
        virtualStacks.add(newStack);
        requiredSlots++;
        remaining -= amount;
      }
    }
    return requiredSlots;
  }

  private ItemStack[] cloneStorageContents(Player player) {
    ItemStack[] contents = player.getInventory().getStorageContents();
    ItemStack[] copy = new ItemStack[contents.length];
    for (int index = 0; index < contents.length; index++) {
      copy[index] = contents[index] == null ? null : contents[index].clone();
    }
    return copy;
  }

  private ItemStack[] mergeIntoStorage(ItemStack[] original, List<ItemStack> items) {
    ItemStack[] updated = new ItemStack[original.length];
    for (int index = 0; index < original.length; index++) {
      updated[index] = original[index] == null ? null : original[index].clone();
    }

    for (ItemStack source : items) {
      if (source == null || isAir(source)) {
        continue;
      }
      ItemStack incoming = source.clone();
      int remaining = incoming.getAmount();
      for (ItemStack existing : updated) {
        if (existing == null || !existing.isSimilar(incoming)) {
          continue;
        }
        int capacity = existing.getMaxStackSize() - existing.getAmount();
        if (capacity <= 0) {
          continue;
        }
        int moved = Math.min(capacity, remaining);
        existing.setAmount(existing.getAmount() + moved);
        remaining -= moved;
        if (remaining == 0) {
          break;
        }
      }
      while (remaining > 0) {
        int emptySlot = firstEmptySlot(updated);
        if (emptySlot < 0) {
          return null;
        }
        int amount = Math.min(incoming.getMaxStackSize(), remaining);
        ItemStack newStack = incoming.clone();
        newStack.setAmount(amount);
        updated[emptySlot] = newStack;
        remaining -= amount;
      }
    }
    return updated;
  }

  private int firstEmptySlot(ItemStack[] contents) {
    for (int index = 0; index < contents.length; index++) {
      ItemStack item = contents[index];
      if (item == null || isAir(item)) {
        return index;
      }
    }
    return -1;
  }

  @Override
  public long estimateTotalValue(List<MailAttachment> attachments) {
    if (attachments == null || attachments.isEmpty()) {
      return 0L;
    }

    long totalValue = 0L;
    for (MailAttachment attachment : attachments) {
      if (attachment == null) {
        continue;
      }
      String itemId = attachment.itemId();
      long itemValue =
          ITEM_VALUE_TABLE.getOrDefault(itemId, ITEM_VALUE_TABLE.getOrDefault("DEFAULT", 10L));
      totalValue += itemValue * attachment.amount();

      // 安全检查
      if (totalValue > MAX_ATTACHMENT_VALUE) {
        return MAX_ATTACHMENT_VALUE;
      }
    }

    return totalValue;
  }

  @Override
  public void logAttachmentClaim(UUID playerId, UUID mailId, List<MailAttachment> attachments) {
    if (!running || playerId == null || mailId == null) {
      return;
    }
    logAttachmentClaimInternal(playerId, mailId, attachments);
  }

  private void logAttachmentClaimInternal(
      UUID playerId, UUID mailId, List<MailAttachment> attachments) {
    if (playerId == null || mailId == null) {
      return;
    }

    // 获取邮件发送者信息
    String senderId = "";
    String senderName = "";
    List<Mail> mails = mailService.getPlayerMails(playerId);
    for (Mail mail : mails) {
      if (mail.getId().equals(mailId)) {
        senderId = mail.getSenderId().toString();
        senderName = mail.getSenderName();
        break;
      }
    }

    // 计算总价值
    long totalValue = estimateTotalValue(attachments);

    // 创建记录
    AttachmentClaimRecord record =
        new AttachmentClaimRecord(
            UUID.randomUUID(),
            playerId,
            mailId,
            senderId.isEmpty() ? null : UUID.fromString(senderId),
            senderName,
            attachments,
            System.currentTimeMillis(),
            totalValue);

    // 保存到数据库
    saveClaimRecord(record);

    // 更新缓存
    claimHistoryCache.computeIfAbsent(playerId, k -> new ArrayList<>()).add(0, record);
  }

  /** 保存领取记录到数据库 */
  private void saveClaimRecord(AttachmentClaimRecord record) {
    if (!databaseService.isRunning()) {
      return;
    }

    try {
      CompletableFuture<Void> write =
          scheduler.runIoAsync(
              () -> {
                try {
                  databaseService
                      .dataSource()
                      .ifPresent(
                          dataSource -> {
                            String sql =
                                """
    INSERT INTO starcore_mail_attachment_claims
    (record_id, player_id, mail_id, sender_id, sender_name, attachment_data, claimed_at, total_value)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""";
                            try (Connection connection = dataSource.getConnection();
                                PreparedStatement statement = connection.prepareStatement(sql)) {
                              statement.setString(1, record.recordId().toString());
                              statement.setString(2, record.playerId().toString());
                              statement.setString(3, record.mailId().toString());
                              statement.setString(
                                  4,
                                  record.senderId() != null ? record.senderId().toString() : null);
                              statement.setString(5, record.senderName());
                              statement.setString(
                                  6, serializeAttachmentsToJson(record.attachments()));
                              statement.setLong(7, record.claimedAt());
                              statement.setLong(8, record.totalValue());
                              statement.executeUpdate();
                            } catch (SQLException exception) {
                              logger.warning("保存附件领取记录失败: " + exception.getMessage());
                            }
                          });
                } catch (RuntimeException exception) {
                  logger.warning("保存附件领取记录失败: " + exception.getMessage());
                }
                return null;
              });
      trackPersistenceWrite(write);
    } catch (RuntimeException exception) {
      logger.warning("提交附件领取记录失败: " + exception.getMessage());
    }
  }

  private void trackPersistenceWrite(CompletableFuture<?> future) {
    pendingPersistenceWrites.add(future);
    future.whenComplete(
        (ignored, throwable) -> {
          pendingPersistenceWrites.remove(future);
          signalLifecycleChange();
        });
  }

  private void signalLifecycleChange() {
    synchronized (lifecycleMonitor) {
      lifecycleMonitor.notifyAll();
    }
  }

  private void awaitTrackedWork() {
    Set<PendingEntityOperation<?>> current = executingOperations.get();
    if (current != null && !current.isEmpty()) {
      throw new IllegalStateException(
          "Shutdown cannot complete inside a mail operation; retry from outside the operation");
    }
    long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(shutdownWaitMillis);
    synchronized (lifecycleMonitor) {
      while (!pendingEntityOperations.isEmpty() || !pendingPersistenceWrites.isEmpty()) {
        long remaining = deadline - System.nanoTime();
        if (remaining <= 0L) {
          logger.warning(
              "等待邮件附件任务结束超时: entity="
                  + pendingEntityOperations.size()
                  + ", persistence="
                  + pendingPersistenceWrites.size());
          throw new IllegalStateException(
              "Mail attachment operations still running; retry shutdown");
        }
        try {
          TimeUnit.NANOSECONDS.timedWait(lifecycleMonitor, remaining);
        } catch (InterruptedException exception) {
          Thread.currentThread().interrupt();
          logger.warning("等待邮件附件任务结束时被中断");
          throw new IllegalStateException(
              "Mail attachment shutdown interrupted; retry shutdown", exception);
        }
      }
    }
  }

  /** 序列化附件为 JSON 字符串 */
  private String serializeAttachmentsToJson(List<MailAttachment> attachments) {
    if (attachments == null || attachments.isEmpty()) {
      return "[]";
    }

    StringBuilder sb = new StringBuilder("[");
    for (int i = 0; i < attachments.size(); i++) {
      MailAttachment attach = attachments.get(i);
      if (i > 0) sb.append(",");
      sb.append("{")
          .append("\"itemId\":\"")
          .append(attach.itemId())
          .append("\",")
          .append("\"amount\":")
          .append(attach.amount())
          .append(",")
          .append("\"serializedItem\":\"")
          .append(escapeJson(attach.serializedItem()))
          .append("\",")
          .append("\"attachedAt\":")
          .append(attach.attachedAt())
          .append("}");
    }
    sb.append("]");
    return sb.toString();
  }

  /** JSON 字符串转义 */
  private String escapeJson(String str) {
    if (str == null) return "";
    return str.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r");
  }

  @Override
  public List<AttachmentClaimRecord> getClaimHistory(UUID playerId, int limit) {
    if (playerId == null) {
      return List.of();
    }

    // 检查缓存
    List<AttachmentClaimRecord> cached = claimHistoryCache.get(playerId);
    if (cached != null && cached.size() >= limit) {
      return cached.subList(0, Math.min(limit, cached.size()));
    }

    // 从数据库加载
    if (databaseService.isRunning()) {
      try {
        return loadClaimHistoryFromDb(playerId, limit);
      } catch (Exception e) {
        logger.warning("加载领取历史失败: " + e.getMessage());
      }
    }

    return cached != null ? cached : List.of();
  }

  @Override
  public AttachmentClaimStatistics getClaimStatistics() {
    if (databaseService.isRunning()) {
      try {
        Optional<javax.sql.DataSource> dataSource = databaseService.dataSource();
        if (dataSource.isPresent()) {
          String sql =
              "SELECT COUNT(*), COALESCE(SUM(total_value), 0), "
                  + "COUNT(DISTINCT player_id), COUNT(DISTINCT mail_id) "
                  + "FROM starcore_mail_attachment_claims";
          try (Connection connection = dataSource.get().getConnection();
              Statement statement = connection.createStatement();
              ResultSet resultSet = statement.executeQuery(sql)) {
            if (resultSet.next()) {
              return new AttachmentClaimStatistics(
                  resultSet.getLong(1),
                  resultSet.getLong(2),
                  resultSet.getLong(3),
                  resultSet.getLong(4));
            }
          }
        }
      } catch (SQLException | RuntimeException exception) {
        logger.warning("加载全局附件统计失败，回退到内存缓存: " + exception.getMessage());
      }
    }

    Set<UUID> players = new HashSet<>();
    Set<UUID> mails = new HashSet<>();
    long totalClaims = 0L;
    long totalValue = 0L;
    for (List<AttachmentClaimRecord> records : claimHistoryCache.values()) {
      for (AttachmentClaimRecord record : records) {
        totalClaims++;
        totalValue += record.totalValue();
        players.add(record.playerId());
        mails.add(record.mailId());
      }
    }
    return new AttachmentClaimStatistics(totalClaims, totalValue, players.size(), mails.size());
  }

  /** 从数据库加载领取历史 */
  private List<AttachmentClaimRecord> loadClaimHistoryFromDb(UUID playerId, int limit) {
    List<AttachmentClaimRecord> records = new ArrayList<>();

    try {
      databaseService
          .dataSource()
          .ifPresent(
              ds -> {
                String sql =
                    """
                        SELECT * FROM starcore_mail_attachment_claims
                        WHERE player_id = ?
                        ORDER BY claimed_at DESC
                        LIMIT ?
                    """;

                try (Connection conn = ds.getConnection();
                    PreparedStatement stmt = conn.prepareStatement(sql)) {

                  stmt.setString(1, playerId.toString());
                  stmt.setInt(2, limit);

                  try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                      String recordIdStr = rs.getString("record_id");
                      String mailIdStr = rs.getString("mail_id");
                      String senderIdStr = rs.getString("sender_id");
                      String senderName = rs.getString("sender_name");
                      String attachmentData = rs.getString("attachment_data");
                      long claimedAt = rs.getLong("claimed_at");
                      long totalValue = rs.getLong("total_value");

                      List<MailAttachment> attachments = parseAttachmentsFromJson(attachmentData);

                      AttachmentClaimRecord record =
                          new AttachmentClaimRecord(
                              UUID.fromString(recordIdStr),
                              playerId,
                              UUID.fromString(mailIdStr),
                              senderIdStr != null ? UUID.fromString(senderIdStr) : null,
                              senderName,
                              attachments,
                              claimedAt,
                              totalValue);
                      records.add(record);
                    }
                  }
                } catch (SQLException e) {
                  logger.warning("查询领取历史失败: " + e.getMessage());
                }
              });
    } catch (Exception e) {
      logger.warning("加载领取历史失败: " + e.getMessage());
    }

    return records;
  }

  /** 从 JSON 解析附件列表 */
  private List<MailAttachment> parseAttachmentsFromJson(String json) {
    List<MailAttachment> attachments = new ArrayList<>();
    if (json == null || json.isEmpty() || json.equals("[]")) {
      return attachments;
    }

    try {
      // 简单的 JSON 解析（不依赖外部库）
      json = json.trim();
      if (!json.startsWith("[") || !json.endsWith("]")) {
        return attachments;
      }

      String content = json.substring(1, json.length() - 1);
      if (content.isEmpty()) {
        return attachments;
      }

      // 分割对象
      int depth = 0;
      int start = 0;
      for (int i = 0; i < content.length(); i++) {
        char c = content.charAt(i);
        if (c == '{') depth++;
        else if (c == '}') {
          depth--;
          if (depth == 0) {
            String obj = content.substring(start, i + 1);
            MailAttachment attach = parseAttachmentObject(obj);
            if (attach != null) {
              attachments.add(attach);
            }
            start = i + 1;
            // 跳过逗号
            while (start < content.length()
                && (content.charAt(start) == ',' || content.charAt(start) == ' ')) {
              start++;
            }
            i = start - 1;
          }
        }
      }
    } catch (Exception e) {
      logger.warning("解析附件 JSON 失败: " + e.getMessage());
    }

    return attachments;
  }

  /** 解析单个附件对象 */
  private MailAttachment parseAttachmentObject(String obj) {
    if (obj == null || obj.isBlank()) {
      logger.warning("code=MAIL_ATTACHMENT_OBJECT_PARSE_FAILURE reason=empty_object");
      return null;
    }

    try {
      String itemId = extractJsonString(obj, "itemId");
      int amount = extractJsonNumber(obj, "amount").intValue();
      String serializedItem = extractJsonString(obj, "serializedItem");
      long attachedAt = extractJsonNumber(obj, "attachedAt").longValue();

      if (itemId == null || itemId.isBlank()) {
        logger.warning("code=MAIL_ATTACHMENT_OBJECT_PARSE_FAILURE reason=missing_item_id");
        return null;
      }

      return new MailAttachment(itemId, amount, serializedItem, attachedAt);
    } catch (IllegalArgumentException | IndexOutOfBoundsException exception) {
      logger.log(
          java.util.logging.Level.WARNING,
          "code=MAIL_ATTACHMENT_OBJECT_PARSE_FAILURE reason=invalid_fields",
          exception);
      return null;
    }
  }

  /** 从 JSON 对象中提取字符串值 */
  private String extractJsonString(String obj, String key) {
    String pattern = "\"" + key + "\"";
    int keyIndex = obj.indexOf(pattern);
    if (keyIndex == -1) {
      // 尝试无引号版本
      pattern = key + ":";
      keyIndex = obj.indexOf(pattern);
      if (keyIndex == -1) return null;
      keyIndex += pattern.length();
    } else {
      keyIndex += pattern.length() + 1; // 跳过引号
    }

    // 跳过空白
    while (keyIndex < obj.length() && Character.isWhitespace(obj.charAt(keyIndex))) {
      keyIndex++;
    }

    if (keyIndex >= obj.length() || obj.charAt(keyIndex) != '"') {
      return null;
    }

    keyIndex++; // 跳过开始引号
    int endIndex = keyIndex;
    boolean escaped = false;
    while (endIndex < obj.length()) {
      char c = obj.charAt(endIndex);
      if (escaped) {
        escaped = false;
      } else if (c == '\\') {
        escaped = true;
      } else if (c == '"') {
        break;
      }
      endIndex++;
    }

    return obj.substring(keyIndex, endIndex);
  }

  /** 从 JSON 对象中提取数字值 */
  private Number extractJsonNumber(String obj, String key) {
    String pattern = "\"" + key + "\":";
    int keyIndex = obj.indexOf(pattern);
    if (keyIndex == -1) {
      throw new IllegalArgumentException("missing numeric field: " + key);
    }

    keyIndex += pattern.length();
    while (keyIndex < obj.length()
        && (Character.isWhitespace(obj.charAt(keyIndex))
            || obj.charAt(keyIndex) == ','
            || obj.charAt(keyIndex) == '}')) {
      keyIndex++;
    }

    if (keyIndex >= obj.length()) {
      throw new IllegalArgumentException("missing numeric value: " + key);
    }

    int endIndex = keyIndex;
    while (endIndex < obj.length()
        && (Character.isDigit(obj.charAt(endIndex))
            || obj.charAt(endIndex) == '.'
            || obj.charAt(endIndex) == '-')) {
      endIndex++;
    }

    if (endIndex == keyIndex) {
      throw new IllegalArgumentException("invalid numeric value: " + key);
    }

    String numStr = obj.substring(keyIndex, endIndex);
    try {
      if (numStr.contains(".")) {
        return Double.parseDouble(numStr);
      } else {
        return Long.parseLong(numStr);
      }
    } catch (NumberFormatException exception) {
      throw new IllegalArgumentException("invalid numeric value: " + key, exception);
    }
  }
}
