package dev.starcore.starcore.social.simulation;

import dev.starcore.starcore.core.persistence.AtomicFilePersistence;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.DoubleSupplier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Gossip state is detached from players; notifications retain the original player session. */
public class GossipService {
  private static final Object[] FILE_LOCKS = new Object[32];

  static {
    Arrays.setAll(FILE_LOCKS, ignored -> new Object());
  }

  private final Object stateLock = new Object();
  private final JavaPlugin plugin;
  private final RelationshipNetwork relationshipNetwork;
  private final ReputationService reputationService;
  private final SocialPlayerMessages messages;
  private final DoubleSupplier random;
  private final Map<String, Gossip> gossips = new HashMap<>();
  private final Map<UUID, Set<String>> playerGossipHistory = new HashMap<>();
  private final Map<UUID, Set<String>> playerSeenGossips = new HashMap<>();
  private final Path dataFile;
  private String expectedFile;
  private boolean rejected;
  private volatile boolean closed;

  public GossipService(
      JavaPlugin plugin, RelationshipNetwork relationships, ReputationService reputation) {
    this(plugin, relationships, reputation, () -> ThreadLocalRandom.current().nextDouble());
  }

  GossipService(
      JavaPlugin plugin,
      RelationshipNetwork relationships,
      ReputationService reputation,
      DoubleSupplier random) {
    this.plugin = Objects.requireNonNull(plugin);
    relationshipNetwork = Objects.requireNonNull(relationships);
    reputationService = Objects.requireNonNull(reputation);
    this.random = Objects.requireNonNull(random);
    messages = new SocialPlayerMessages(plugin);
    dataFile =
        plugin.getDataFolder().toPath().resolve("gossip_data.yml").toAbsolutePath().normalize();
    loadData();
  }

  private void requireWritable() {
    if (closed || rejected)
      throw new IllegalStateException("Gossip service stopped or storage rejected");
  }

  public void close() {
    synchronized (stateLock) {
      closed = true;
    }
    messages.close();
  }

  public String createGossip(UUID creator, String content, GossipTopic topic) {
    String id = UUID.randomUUID().toString();
    synchronized (stateLock) {
      requireWritable();
      double credibility =
          Math.min(
              0.95,
              Math.max(
                  0.1,
                  0.5
                      + Math.min(0.3, reputationService.getReputation(creator) / 1000.0)
                      + topic.credibilityBonus()
                      + Math.min(0.1, relationshipNetwork.getFriends(creator).size() * 0.01)));
      gossips.put(
          id,
          new Gossip(
              id,
              creator,
              content,
              topic,
              System.currentTimeMillis(),
              credibility,
              Set.of(creator),
              1,
              5,
              List.of()));
      playerGossipHistory.computeIfAbsent(creator, ignored -> new HashSet<>()).add(id);
      playerSeenGossips.computeIfAbsent(creator, ignored -> new HashSet<>()).add(id);
    }
    spreadGossip(id, creator, 1);
    return id;
  }

  public void spreadGossip(String gossipId, UUID spreader, int depth) {
    if (depth < 1) throw new IllegalArgumentException("Invalid gossip depth");
    record Hop(UUID player, int depth) {}
    record Delivery(Player player, UUID id, Gossip gossip) {}
    List<Delivery> deliveries = new ArrayList<>();
    List<Gossip> impacts = new ArrayList<>();
    synchronized (stateLock) {
      requireWritable();
      Gossip initial = gossips.get(gossipId);
      if (initial == null || !initial.seenBy().contains(spreader)) return;
      ArrayDeque<Hop> queue = new ArrayDeque<>();
      queue.add(new Hop(spreader, depth));
      while (!queue.isEmpty()) {
        Hop hop = queue.removeFirst();
        Gossip gossip = gossips.get(gossipId);
        if (hop.depth() > gossip.maxDepth()) continue;
        for (UUID target : relationshipNetwork.getSocialCircle(hop.player(), 20)) {
          gossip = gossips.get(gossipId);
          if (gossip.seenBy().contains(target)) continue;
          var relation = relationshipNetwork.getRelationship(hop.player(), target);
          double chance =
              relation == null
                  ? 0.2
                  : Math.min(1.0, Math.abs((double) relation.strength()) / 100.0);
          if (random.getAsDouble() >= chance * gossip.credibility()) continue;
          Set<UUID> reached = new HashSet<>(gossip.seenBy());
          reached.add(target);
          Gossip updated =
              new Gossip(
                  gossip.id(),
                  gossip.creator(),
                  gossip.content(),
                  gossip.topic(),
                  gossip.timestamp(),
                  gossip.credibility(),
                  reached,
                  Math.incrementExact(gossip.spreadCount()),
                  gossip.maxDepth(),
                  gossip.comments());
          gossips.put(gossipId, updated);
          playerGossipHistory.computeIfAbsent(target, ignored -> new HashSet<>()).add(gossipId);
          deliveries.add(new Delivery(messages.capture(target), target, updated));
          queue.addLast(new Hop(target, hop.depth() + 1));
          if (updated.spreadCount() % 3 == 0) impacts.add(updated);
        }
      }
    }
    for (Delivery delivery : deliveries) {
      Gossip gossip = delivery.gossip();
      messages
          .send(
              delivery.player(),
              "§5§l【八卦】§d" + gossip.topic().emoji() + " " + gossip.content(),
              "§7可信度: "
                  + getCredibilityBar(gossip.credibility())
                  + " §7传播: "
                  + gossip.spreadCount()
                  + "次")
          .thenRun(
              () -> {
                synchronized (stateLock) {
                  if (!closed && !rejected && gossips.containsKey(gossipId))
                    playerSeenGossips
                        .computeIfAbsent(delivery.id(), ignored -> new HashSet<>())
                        .add(gossipId);
                }
              });
    }
    impacts.forEach(this::applyReputationImpact);
  }

  private String getCredibilityBar(double credibility) {
    int bars = (int) (credibility * 10);
    return "§a|".repeat(bars) + "§7|".repeat(10 - bars);
  }

  public void commentOnGossip(UUID commenter, String gossipId, String comment) {
    synchronized (stateLock) {
      requireWritable();
      Gossip gossip = gossips.get(gossipId);
      if (gossip == null) return;
      List<String> comments = new ArrayList<>(gossip.comments());
      comments.add(commenter + ": " + Objects.requireNonNull(comment));
      gossips.put(
          gossipId,
          new Gossip(
              gossip.id(),
              gossip.creator(),
              gossip.content(),
              gossip.topic(),
              gossip.timestamp(),
              gossip.credibility(),
              gossip.seenBy(),
              gossip.spreadCount(),
              gossip.maxDepth(),
              comments));
    }
  }

  public List<Gossip> getPlayerGossipHistory(UUID playerId) {
    synchronized (stateLock) {
      return playerGossipHistory.getOrDefault(playerId, Set.of()).stream()
          .map(gossips::get)
          .filter(Objects::nonNull)
          .sorted(Comparator.comparingLong(Gossip::timestamp).reversed())
          .limit(20)
          .toList();
    }
  }

  public List<Gossip> getTrendingGossip() {
    synchronized (stateLock) {
      return gossips.values().stream()
          .sorted(Comparator.comparingInt(Gossip::spreadCount).reversed())
          .limit(10)
          .toList();
    }
  }

  public void updateCredibility(String gossipId, double change) {
    if (!Double.isFinite(change))
      throw new IllegalArgumentException("Nonfinite credibility change");
    synchronized (stateLock) {
      requireWritable();
      Gossip gossip = gossips.get(gossipId);
      if (gossip == null) return;
      gossips.put(
          gossipId,
          new Gossip(
              gossip.id(),
              gossip.creator(),
              gossip.content(),
              gossip.topic(),
              gossip.timestamp(),
              Math.min(1.0, Math.max(0.1, gossip.credibility() + change)),
              gossip.seenBy(),
              gossip.spreadCount(),
              gossip.maxDepth(),
              gossip.comments()));
    }
  }

  public Gossip getGossipById(String id) {
    synchronized (stateLock) {
      return gossips.get(id);
    }
  }

  public Collection<Gossip> getAllGossips() {
    synchronized (stateLock) {
      return List.copyOf(gossips.values());
    }
  }

  public int getGossipCount() {
    synchronized (stateLock) {
      return gossips.size();
    }
  }

  public int getSavedGossipCount() {
    return getGossipCount();
  }

  public void removeGossip(String id) {
    synchronized (stateLock) {
      requireWritable();
      gossips.remove(id);
      playerGossipHistory.values().forEach(ids -> ids.remove(id));
      playerSeenGossips.values().forEach(ids -> ids.remove(id));
      pruneEmpty();
    }
  }

  public void applyReputationImpact(String id) {
    Gossip gossip;
    synchronized (stateLock) {
      if (closed || rejected) return;
      gossip = gossips.get(id);
    }
    if (gossip != null) applyReputationImpact(gossip);
  }

  private void applyReputationImpact(Gossip gossip) {
    if (closed) return;
    int amount = calculateReputationImpact(gossip);
    if (amount == 0) return;
    Player creator = messages.capture(gossip.creator());
    List<Player> recipients =
        gossip.seenBy().stream()
            .filter(id -> !id.equals(gossip.creator()))
            .map(messages::capture)
            .filter(Objects::nonNull)
            .toList();
    var name = messages.name(creator, gossip.creator());
    reputationService
        .modifyReputation(gossip.creator(), amount, ReputationService.ReputationReason.CUSTOM)
        .thenAccept(
            success -> {
              if (!Boolean.TRUE.equals(success) || closed) return;
              messages.send(
                  creator,
                  "§5【八卦影响】§d你的八卦传播后，你的声誉"
                      + (amount > 0 ? "提升" : "下降")
                      + "了 "
                      + Math.abs(amount)
                      + " 点");
              if (gossip.credibility() > 0.7)
                name.thenAccept(
                    display -> {
                      if (!closed)
                        for (Player recipient : recipients)
                          messages.send(
                              recipient,
                              "§5【八卦新闻】§d听说 §e"
                                  + display
                                  + " §d"
                                  + gossip.topic().getName()
                                  + "八卦...");
                    });
            });
  }

  private int calculateReputationImpact(Gossip gossip) {
    int base =
        switch (gossip.topic()) {
          case HEROISM -> 3;
          case CELEBRITY -> 2;
          case TRADING -> 1;
          case POWER -> -1;
          case POLITICS, BATTLE -> -2;
          case SCANDAL -> -5;
          case TRAGEDY -> -3;
          default -> 0;
        };
    if (base == 0) return 0;
    int result = (int) (base * (0.5 + gossip.credibility()));
    return result + Integer.signum(base) * Math.min(5, gossip.spreadCount() / 2);
  }

  public boolean hasSeenGossip(UUID player, String id) {
    synchronized (stateLock) {
      return playerSeenGossips.getOrDefault(player, Set.of()).contains(id);
    }
  }

  public void markGossipSeen(UUID player, String id) {
    synchronized (stateLock) {
      requireWritable();
      if (playerGossipHistory.getOrDefault(player, Set.of()).contains(id)
          && gossips.containsKey(id))
        playerSeenGossips.computeIfAbsent(player, ignored -> new HashSet<>()).add(id);
    }
  }

  public int getUnreadGossipCount(UUID player) {
    synchronized (stateLock) {
      Set<String> seen = playerSeenGossips.getOrDefault(player, Set.of());
      return (int)
          playerGossipHistory.getOrDefault(player, Set.of()).stream()
              .filter(gossips::containsKey)
              .filter(id -> !seen.contains(id))
              .count();
    }
  }

  /** A checkpoint, also permitted after close; rejected storage is never overwritten. */
  public void saveData() {
    synchronized (stateLock) {
      if (rejected) throw new IllegalStateException("Gossip storage requires verified reload");
      withFileLock(
          () -> {
            checkArtifacts();
            if (!Objects.equals(expectedFile, fingerprint()))
              throw new IOException("Gossip file changed since load");
            YamlConfiguration data = new YamlConfiguration();
            data.set("schema-version", 1);
            int index = 0;
            for (Gossip gossip :
                gossips.values().stream().sorted(Comparator.comparing(Gossip::id)).toList()) {
              String key = "gossips." + index++;
              data.set(key + ".id", gossip.id());
              data.set(key + ".creator", gossip.creator().toString());
              data.set(key + ".content", gossip.content());
              data.set(key + ".topic", gossip.topic().name());
              data.set(key + ".timestamp", gossip.timestamp());
              data.set(key + ".credibility", gossip.credibility());
              data.set(key + ".spread_count", gossip.spreadCount());
              data.set(key + ".max_depth", gossip.maxDepth());
              data.set(
                  key + ".seen_by", gossip.seenBy().stream().map(UUID::toString).sorted().toList());
              data.set(key + ".comments", gossip.comments());
            }
            playerGossipHistory.forEach(
                (player, ids) -> data.set("history." + player, ids.stream().sorted().toList()));
            playerSeenGossips.forEach(
                (player, ids) -> data.set("read." + player, ids.stream().sorted().toList()));
            AtomicFilePersistence.replace(dataFile, target -> data.save(target.toFile()));
            expectedFile = fingerprint();
          });
    }
  }

  public void loadData() {
    synchronized (stateLock) {
      if (closed) throw new IllegalStateException("Gossip service stopped");
      withFileLock(
          () -> {
            checkArtifacts();
            String loaded = fingerprint();
            YamlConfiguration data = new YamlConfiguration();
            if (!loaded.equals("missing")) {
              String yaml = Files.readString(dataFile);
              var options = new org.yaml.snakeyaml.LoaderOptions();
              options.setAllowDuplicateKeys(false);
              new org.yaml.snakeyaml.Yaml(
                      new org.yaml.snakeyaml.constructor.SafeConstructor(options))
                  .load(yaml);
              data.loadFromString(yaml);
            }
            if (data.contains("schema-version") && number(data, "schema-version", 0) != 1)
              throw new IllegalArgumentException("Unsupported gossip schema");
            Map<String, Gossip> candidate = new HashMap<>();
            ConfigurationSection section = section(data, "gossips");
            if (section != null)
              for (String index : section.getKeys(false)) {
                String key = "gossips." + index;
                String id = required(data, key + ".id");
                Set<UUID> seen = new HashSet<>();
                for (String player : strings(data, key + ".seen_by"))
                  seen.add(UUID.fromString(player));
                double credibility =
                    new java.math.BigDecimal(required(data, key + ".credibility")).doubleValue();
                Gossip gossip =
                    new Gossip(
                        id,
                        UUID.fromString(required(data, key + ".creator")),
                        required(data, key + ".content"),
                        GossipTopic.valueOf(required(data, key + ".topic")),
                        number(data, key + ".timestamp", 0),
                        credibility,
                        seen,
                        Math.toIntExact(number(data, key + ".spread_count", 1)),
                        Math.toIntExact(number(data, key + ".max_depth", 5)),
                        strings(data, key + ".comments"));
                if (candidate.put(id, gossip) != null)
                  throw new IllegalArgumentException("Duplicate gossip ID");
              }
            Map<UUID, Set<String>> history = readIndex(data, "history");
            Map<UUID, Set<String>> seen = readIndex(data, "read");
            gossips.clear();
            gossips.putAll(candidate);
            playerGossipHistory.clear();
            playerGossipHistory.putAll(history);
            playerSeenGossips.clear();
            playerSeenGossips.putAll(seen);
            expectedFile = loaded;
            rejected = false;
          });
    }
  }

  private void withFileLock(FileOperation operation) {
    synchronized (FILE_LOCKS[Math.floorMod(dataFile.hashCode(), FILE_LOCKS.length)]) {
      try {
        Files.createDirectories(dataFile.getParent());
        try (var channel =
                FileChannel.open(
                    dataFile.resolveSibling(dataFile.getFileName() + ".lock"),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE);
            var lock = channel.lock()) {
          operation.run();
        }
      } catch (Exception failure) {
        rejected = true;
        throw new IllegalStateException("Gossip storage unavailable; evidence retained", failure);
      }
    }
  }

  @FunctionalInterface
  private interface FileOperation {
    void run() throws Exception;
  }

  private String fingerprint() throws Exception {
    if (Files.notExists(dataFile)) return "missing";
    try (var input = Files.newInputStream(dataFile)) {
      var digest = java.security.MessageDigest.getInstance("SHA-256");
      byte[] buffer = new byte[8192];
      int count;
      while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
      return HexFormat.of().formatHex(digest.digest());
    }
  }

  private void checkArtifacts() throws IOException {
    for (String suffix : List.of(".tmp", ".delete", ".bak.tmp"))
      if (Files.exists(dataFile.resolveSibling(dataFile.getFileName() + suffix)))
        throw new IOException("Unresolved gossip write artifact");
    if (Files.notExists(dataFile)
        && (expectedFile != null && !expectedFile.equals("missing")
            || Files.exists(AtomicFilePersistence.backup(dataFile))))
      throw new IOException("Missing gossip authority");
  }

  private static ConfigurationSection section(YamlConfiguration data, String key) {
    if (!data.contains(key)) return null;
    ConfigurationSection section = data.getConfigurationSection(key);
    if (section == null) throw new IllegalArgumentException("Expected section: " + key);
    return section;
  }

  private static String required(YamlConfiguration data, String key) {
    Object value = data.get(key);
    if (value == null) throw new IllegalArgumentException("Missing gossip field: " + key);
    return value.toString();
  }

  private static long number(YamlConfiguration data, String key, long fallback) {
    return data.contains(key)
        ? new java.math.BigDecimal(required(data, key)).longValueExact()
        : fallback;
  }

  private static List<String> strings(YamlConfiguration data, String key) {
    if (!data.contains(key)) return List.of();
    if (!(data.get(key) instanceof List<?> values))
      throw new IllegalArgumentException("Expected list: " + key);
    List<String> result = new ArrayList<>();
    for (Object value : values) {
      if (!(value instanceof String text))
        throw new IllegalArgumentException("Expected text: " + key);
      result.add(text);
    }
    return List.copyOf(result);
  }

  private static Map<UUID, Set<String>> readIndex(YamlConfiguration data, String key) {
    Map<UUID, Set<String>> result = new HashMap<>();
    ConfigurationSection section = section(data, key);
    if (section != null)
      for (String player : section.getKeys(false))
        result.put(UUID.fromString(player), new HashSet<>(strings(data, key + "." + player)));
    return result;
  }

  public void clearData() {
    synchronized (stateLock) {
      requireWritable();
      gossips.clear();
      playerGossipHistory.clear();
      playerSeenGossips.clear();
    }
  }

  public void cleanupOldGossip(long maxAgeMillis) {
    if (maxAgeMillis < 0) throw new IllegalArgumentException("Negative gossip age");
    synchronized (stateLock) {
      requireWritable();
      long cutoff = System.currentTimeMillis() - maxAgeMillis;
      gossips.values().removeIf(gossip -> gossip.timestamp() < cutoff);
      playerGossipHistory.values().forEach(ids -> ids.retainAll(gossips.keySet()));
      playerSeenGossips.values().forEach(ids -> ids.retainAll(gossips.keySet()));
      pruneEmpty();
    }
  }

  private void pruneEmpty() {
    playerGossipHistory.values().removeIf(Set::isEmpty);
    playerSeenGossips.values().removeIf(Set::isEmpty);
  }

  public record Gossip(
      String id,
      UUID creator,
      String content,
      GossipTopic topic,
      long timestamp,
      double credibility,
      Set<UUID> seenBy,
      int spreadCount,
      int maxDepth,
      List<String> comments) {
    public Gossip {
      if (id == null || id.isBlank()) throw new IllegalArgumentException("Missing gossip ID");
      Objects.requireNonNull(creator);
      Objects.requireNonNull(content);
      Objects.requireNonNull(topic);
      seenBy = Set.copyOf(seenBy);
      comments = List.copyOf(comments);
      if (timestamp < 0
          || !Double.isFinite(credibility)
          || credibility < 0
          || credibility > 1
          || spreadCount < 0
          || maxDepth < 0
          || maxDepth > 100) throw new IllegalArgumentException("Invalid gossip state");
    }

    public String getAgeText() {
      long hours = (System.currentTimeMillis() - timestamp) / 3600000;
      return hours < 1 ? "刚刚" : hours < 24 ? hours + "小时前" : hours / 24 + "天前";
    }
  }

  public enum GossipTopic {
    ROMANCE("爱情", "§d♥", 0.1),
    WEALTH("财富", "§6✦", 0.0),
    POWER("权力", "§c⚔", 0.2),
    BATTLE("战斗", "§4†", 0.15),
    POLITICS("政治", "§c♛", 0.25),
    CULTURE("文化", "§b⚑", 0.05),
    SCANDAL("丑闻", "§5⊘", 0.3),
    HEROISM("英雄事迹", "§a✦", 0.1),
    TRAGEDY("悲剧", "§7☠", 0.2),
    MYSTERY("神秘", "§5◍", 0.15),
    CELEBRITY("名人", "§6★", 0.1),
    TRADING("交易", "§e▦", 0.0);

    private final String name;
    private final String emoji;
    private final double credibilityBonus;

    GossipTopic(String name, String emoji, double bonus) {
      this.name = name;
      this.emoji = emoji;
      this.credibilityBonus = bonus;
    }

    public String getName() {
      return name;
    }

    public String emoji() {
      return emoji;
    }

    public double credibilityBonus() {
      return credibilityBonus;
    }
  }
}
