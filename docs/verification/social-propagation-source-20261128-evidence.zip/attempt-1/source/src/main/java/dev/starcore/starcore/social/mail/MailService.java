package dev.starcore.starcore.social.mail;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * 邮件系统核心服务
 *
 * <p>功能： 1. 邮件发送接收 2. 附件系统 3. 已读未读状态 4. 邮件过期清理
 */
public final class MailService {

  // 默认邮件过期天数
  private static final long DEFAULT_EXPIRATION_DAYS = 30;
  // 邮件内容长度限制，防止内存耗尽和客户端崩溃
  private static final int MAX_SUBJECT_LENGTH = 200;
  private static final int MAX_CONTENT_LENGTH = 4000;
  // 每玩家邮箱容量上限
  private static final int MAX_MAILS_PER_PLAYER = 500;
  // 发送速率限制：每玩家每分钟最多发送邮件数
  private static final int MAX_SENDS_PER_MINUTE = 10;
  private static final long SEND_COOLDOWN_MS = 60_000L;
  // audit B-NEW: 单封邮件附件数量上限。攻击者可能塞 N 个空 ItemStack 让收件人
  //   claimAttachments 时一次性加载到内存/背包，导致 OOM 或客户端崩溃。
  private static final int MAX_ATTACHMENTS_PER_MAIL = 36;

  // 玩家邮件缓存: playerId -> List<Mail>
  private final Map<UUID, List<Mail>> playerMails = new ConcurrentHashMap<>();

  // 在线玩家未读邮件数量缓存
  private final Map<UUID, Integer> unreadCounts = new ConcurrentHashMap<>();

  // 发送速率限制: playerId -> (lastSendTimestamp, sendCount)
  private final Map<UUID, long[]> sendRateTracker = new ConcurrentHashMap<>();

  private final DatabaseService databaseService;
  private final PersistenceService persistenceService;
  private final Logger logger;
  private final Plugin plugin;

  private SqlMailStorage sqlStorage;
  private File mailsFile;
  private boolean useDatabase = false;
  private BukkitTask expirationCleanupTask;
  private BukkitTask cacheCleanupTask;
  private volatile boolean acceptingOperations = true;
  private volatile boolean shutdownComplete = false;

  public MailService(
      DatabaseService databaseService, PersistenceService persistenceService, Plugin plugin) {
    this.databaseService = databaseService;
    this.persistenceService = persistenceService;
    this.plugin = plugin;
    this.logger = plugin.getLogger();
  }

  /** 初始化邮件服务 */
  public void initialize() {
    // 初始化数据库存储
    if (databaseService != null && databaseService.isRunning()) {
      sqlStorage = new SqlMailStorage(databaseService, logger);
      sqlStorage.ensureTables();
      useDatabase = true;
      logger.info("邮件系统使用数据库存储");
    } else {
      // 创建邮件数据文件
      File mailDir = new File(plugin.getDataFolder(), "social");
      if (!mailDir.exists()) mailDir.mkdirs();
      mailsFile = new File(mailDir, "mails.yml");
      useDatabase = false;
      logger.info("邮件系统使用YAML存储（数据库不可用）");
    }

    // 注册过期清理任务（每小时执行）
    scheduleExpirationCleanup();
  }

  /** 加载玩家邮件 */
  public void loadMailsForPlayer(UUID playerId) {
    if (playerId == null) {
      return;
    }
    synchronized (yamlSaveLock) {
      if (!acceptingOperations || playerMails.containsKey(playerId)) {
        return;
      }
      List<Mail> loaded;
      if (useDatabase && sqlStorage != null) {
        loaded = sqlStorage.loadMailsForPlayer(playerId);
      } else {
        loaded = loadFromYamlLocked(playerId);
      }
      playerMails.putIfAbsent(playerId, new CopyOnWriteArrayList<>(loaded));
      updateUnreadCount(playerId);
    }
  }

  /** 获取玩家邮件列表 */
  /** 获取玩家邮件列表。 D-029: 避免 computeIfAbsent 内部 put 触发 ConcurrentHashMap RecursiveUpdate。 */
  public List<Mail> getPlayerMails(UUID playerId) {
    if (playerId == null) {
      return List.of();
    }
    synchronized (yamlSaveLock) {
      List<Mail> existing = playerMails.get(playerId);
      if (existing != null) {
        return existing;
      }
      if (!acceptingOperations) {
        return List.of();
      }
      loadMailsForPlayer(playerId);
      return playerMails.getOrDefault(playerId, List.of());
    }
  }

  /** 获取玩家的未读邮件数量 */
  public int getUnreadCount(UUID playerId) {
    return unreadCounts.getOrDefault(playerId, 0);
  }

  /** 更新未读计数 */
  private void updateUnreadCount(UUID playerId) {
    List<Mail> mails = playerMails.get(playerId);
    if (mails != null) {
      long count = mails.stream().filter(m -> !m.isRead() && !m.isExpired()).count();
      unreadCounts.put(playerId, (int) count);
    }
  }

  /**
   * 发送邮件
   *
   * @param sender 发送者
   * @param recipientName 接收者名称
   * @param subject 主题
   * @param content 内容
   * @param attachments 附件物品
   * @return 成功返回 true
   */
  public boolean sendMail(
      Player sender,
      String recipientName,
      String subject,
      String content,
      List<ItemStack> attachments) {
    if (!acceptingOperations
        || sender == null
        || recipientName == null
        || recipientName.isBlank()) {
      return false;
    }

    UUID recipientId = null;
    Player recipientPlayer = Bukkit.getPlayer(recipientName);
    if (recipientPlayer != null) {
      recipientId = recipientPlayer.getUniqueId();
    } else {
      OfflinePlayer offline = Bukkit.getOfflinePlayer(recipientName);
      if (offline != null && offline.hasPlayedBefore()) {
        recipientId = offline.getUniqueId();
      }
    }
    if (recipientId == null || recipientId.equals(sender.getUniqueId())) {
      return false;
    }

    // 内容长度限制
    String safeSubject = subject != null ? subject : "";
    if (safeSubject.length() > MAX_SUBJECT_LENGTH) {
      safeSubject = safeSubject.substring(0, MAX_SUBJECT_LENGTH);
    }
    String safeContent = content != null ? content : "";
    if (safeContent.length() > MAX_CONTENT_LENGTH) {
      safeContent = safeContent.substring(0, MAX_CONTENT_LENGTH);
    }

    // 发送速率限制：每玩家每分钟最多10封
    if (!tryAcquireSendSlot(sender.getUniqueId())) {
      return false;
    }

    List<MailAttachment> mailAttachments = new ArrayList<>();
    if (attachments != null) {
      for (ItemStack item : attachments) {
        if (item != null && !item.getType().isAir()) {
          // audit B-NEW: 钳制 amount 到 [1, maxStackSize]，防止溢出的 ItemStack
          //   amount 进序列化字符串、claimAttachments 时生成非法物品导致客户端崩溃。
          int maxStack = Math.max(1, item.getType().getMaxStackSize());
          int safeAmount = Math.min(Math.max(item.getAmount(), 1), maxStack);
          ItemStack clamped = item.clone();
          clamped.setAmount(safeAmount);
          mailAttachments.add(new MailAttachment(clamped));
          if (mailAttachments.size() >= MAX_ATTACHMENTS_PER_MAIL) {
            break;
          }
        }
      }
    }

    Mail mail =
        new Mail(
            UUID.randomUUID(),
            sender.getUniqueId(),
            sender.getName(),
            recipientId,
            recipientName,
            safeSubject,
            safeContent,
            mailAttachments,
            Instant.now(),
            DEFAULT_EXPIRATION_DAYS);

    synchronized (yamlSaveLock) {
      if (!acceptingOperations) {
        return false;
      }
      List<Mail> mails = playerMails.get(recipientId);
      if (mails == null) {
        loadMailsForPlayer(recipientId);
        mails = playerMails.computeIfAbsent(recipientId, ignored -> new CopyOnWriteArrayList<>());
      }
      // 邮箱容量上限：超出时删除最旧的已读邮件
      if (mails.size() >= MAX_MAILS_PER_PLAYER) {
        mails.removeIf(m -> m.isRead());
        // 如果删除已读后仍满，拒绝发送
        if (mails.size() >= MAX_MAILS_PER_PLAYER) {
          return false;
        }
      }
      mails.add(0, mail);

      boolean persisted =
          useDatabase && sqlStorage != null ? sqlStorage.saveMail(mail) : saveAllToYamlLocked();
      if (!persisted) {
        mails.remove(mail);
        updateUnreadCount(recipientId);
        return false;
      }
      updateUnreadCount(recipientId);
    }

    if (recipientPlayer != null && acceptingOperations) {
      recipientPlayer.sendMessage("§a[邮件] §f你收到了一封新邮件，来自: " + sender.getName());
      recipientPlayer.sendMessage("§e主题: " + mail.getSubject());
    }
    return true;
  }

  /** 速率限制检查：每玩家每分钟最多10封邮件 */
  private boolean tryAcquireSendSlot(UUID playerId) {
    long now = System.currentTimeMillis();
    long[] tracker = sendRateTracker.computeIfAbsent(playerId, k -> new long[] {0L, 0L});
    synchronized (tracker) {
      if (now - tracker[0] >= SEND_COOLDOWN_MS) {
        tracker[0] = now;
        tracker[1] = 1;
        return true;
      }
      if (tracker[1] >= MAX_SENDS_PER_MINUTE) {
        return false;
      }
      tracker[1]++;
      return true;
    }
  }

  /** 读取邮件（标记为已读） */
  public Mail readMail(UUID playerId, UUID mailId) {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations || playerId == null || mailId == null) {
        return null;
      }
      List<Mail> mails = playerMails.get(playerId);
      if (mails == null) {
        return null;
      }
      for (Mail mail : mails) {
        if (!mail.getId().equals(mailId)) {
          continue;
        }
        if (!mail.isRead()) {
          mail.setRead(true);
          boolean persisted =
              useDatabase && sqlStorage != null
                  ? sqlStorage.markAsRead(mailId)
                  : saveAllToYamlLocked();
          if (!persisted) {
            mail.setRead(false);
            return null;
          }
          updateUnreadCount(playerId);
        }
        return mail;
      }
      return null;
    }
  }

  /** 删除邮件 */
  public boolean deleteMail(UUID playerId, UUID mailId) {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations || playerId == null || mailId == null) {
        return false;
      }
      List<Mail> mails = playerMails.get(playerId);
      if (mails == null) {
        return false;
      }
      int index = -1;
      Mail removed = null;
      for (int i = 0; i < mails.size(); i++) {
        if (mails.get(i).getId().equals(mailId)) {
          index = i;
          removed = mails.remove(i);
          break;
        }
      }
      if (removed == null) {
        return false;
      }

      boolean persisted =
          useDatabase && sqlStorage != null ? sqlStorage.deleteMail(mailId) : saveAllToYamlLocked();
      if (!persisted) {
        mails.add(index, removed);
        updateUnreadCount(playerId);
        return false;
      }
      updateUnreadCount(playerId);
      return true;
    }
  }

  /** 领取附件 */
  /** 领取附件。 D-027: 背包满时通过 addAll 检查剩余物品，剩余物品不标记为已领取，避免物品丢失。 D-028: per-player CAS 锁防止并发双击造成重复领取。 */
  public List<ItemStack> claimAttachments(UUID playerId, UUID mailId) {
    if (!acceptingOperations || playerId == null || mailId == null) {
      return Collections.emptyList();
    }
    if (claimLocks.putIfAbsent(playerId, Boolean.TRUE) != null) {
      return Collections.emptyList();
    }
    try {
      synchronized (yamlSaveLock) {
        if (!acceptingOperations) {
          return Collections.emptyList();
        }
        List<Mail> mails = playerMails.get(playerId);
        if (mails == null) {
          return Collections.emptyList();
        }
        for (Mail mail : mails) {
          if (mail.getId().equals(mailId)) {
            if (!mail.hasAttachments() || mail.isClaimed()) {
              return Collections.emptyList();
            }
            List<ItemStack> items = new ArrayList<>();
            for (MailAttachment attachment : mail.getAttachments()) {
              ItemStack item = attachment.deserializeItem();
              if (item != null) {
                // audit B-NEW: 防御性钳制 amount —— 即使 YAML 损坏或旧版本序列化
                //   残留了 amount > maxStackSize 的物品，claim 时也只生成合法物品。
                int maxStack = Math.max(1, item.getType().getMaxStackSize());
                if (item.getAmount() < 1) {
                  item.setAmount(1);
                } else if (item.getAmount() > maxStack) {
                  item.setAmount(maxStack);
                }
                items.add(item);
                if (items.size() >= MAX_ATTACHMENTS_PER_MAIL) {
                  break;
                }
              }
            }
            return items;
          }
        }
        return Collections.emptyList();
      }
    } finally {
      claimLocks.remove(playerId);
    }
  }

  /** 确认附件已成功入背包（由调用方在 addItem 后调用）。 D-027: 背包满时调用方不应调用此方法，物品保留在邮件中。 返回 false 表示邮件不存在或已被领取。 */
  public boolean confirmClaimed(UUID playerId, UUID mailId) {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations || playerId == null || mailId == null) {
        return false;
      }
      List<Mail> mails = playerMails.get(playerId);
      if (mails == null) {
        return false;
      }
      for (Mail mail : mails) {
        if (!mail.getId().equals(mailId)) {
          continue;
        }
        if (mail.isClaimed()) {
          return true;
        }
        mail.setClaimed(true);
        boolean persisted =
            useDatabase && sqlStorage != null
                ? sqlStorage.markAsClaimed(mailId)
                : saveAllToYamlLocked();
        if (!persisted) {
          mail.setClaimed(false);
          return false;
        }
        updateUnreadCount(playerId);
        return true;
      }
      return false;
    }
  }

  // D-028 per-player CAS 锁，避免并发双击重复领取
  private final Map<UUID, Boolean> claimLocks = new ConcurrentHashMap<>();

  /** 获取玩家的未读邮件提示 */
  public String getUnreadMailHint(UUID playerId) {
    int count = getUnreadCount(playerId);
    if (count > 0) {
      return "§a[邮件] §f你有 " + count + " 封未读邮件";
    }
    return "";
  }

  /** 安排过期邮件清理任务 */
  private synchronized void scheduleExpirationCleanup() {
    if (expirationCleanupTask != null || cacheCleanupTask != null) {
      return;
    }
    expirationCleanupTask =
        plugin
            .getServer()
            .getScheduler()
            .runTaskTimerAsynchronously(
                plugin,
                () -> {
                  synchronized (yamlSaveLock) {
                    if (acceptingOperations && useDatabase && sqlStorage != null) {
                      sqlStorage.cleanupExpiredMails();
                    }
                  }
                },
                72000L,
                72000L); // 数据库清理保持异步
    cacheCleanupTask =
        plugin
            .getServer()
            .getScheduler()
            .runTaskTimer(
                plugin,
                this::cleanupExpiredMailsInCache,
                72000L,
                72000L); // Bukkit 在线状态检查与缓存变更在主线程执行
  }

  /** 清理缓存中的过期邮件 */
  /** 清理缓存中的过期邮件，并 unload 离线玩家的邮件缓存以回收内存（D-030）。 */
  private void cleanupExpiredMailsInCache() {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations) {
        return;
      }
      var iterator = playerMails.entrySet().iterator();
      while (iterator.hasNext()) {
        var entry = iterator.next();
        entry.getValue().removeIf(Mail::isExpired);
        updateUnreadCount(entry.getKey());
        if (Bukkit.getPlayer(entry.getKey()) == null) {
          iterator.remove();
          unreadCounts.remove(entry.getKey());
        }
      }
    }
  }

  /** 保存所有数据。YAML 模式批量保存；DB 模式下 mail 状态变更已即时落盘，无需重复。 */
  public void saveAll() {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations) {
        return;
      }
      if (!useDatabase) {
        saveAllToYamlLocked();
      }
    }
  }

  public void shutdown() {
    stopAcceptingOperations();

    BukkitTask databaseCleanup;
    BukkitTask cacheCleanup;
    synchronized (yamlSaveLock) {
      databaseCleanup = expirationCleanupTask;
      expirationCleanupTask = null;
      cacheCleanup = cacheCleanupTask;
      cacheCleanupTask = null;
    }
    cancelTask(databaseCleanup);
    cancelTask(cacheCleanup);

    synchronized (yamlSaveLock) {
      if (shutdownComplete) {
        return;
      }
      if (!useDatabase) {
        saveAllToYamlLocked();
      }
      shutdownComplete = true;
    }
  }

  public void stopAcceptingOperations() {
    synchronized (yamlSaveLock) {
      acceptingOperations = false;
    }
  }

  public boolean isAcceptingOperations() {
    return acceptingOperations;
  }

  private void cancelTask(BukkitTask task) {
    if (task == null) {
      return;
    }
    try {
      task.cancel();
    } catch (IllegalStateException ignored) {
      // Already completed or cancelled.
    }
  }

  // ========== YAML 持久化方法 ==========

  private void loadFromYaml(UUID playerId) {
    synchronized (yamlSaveLock) {
      if (playerMails.containsKey(playerId)) {
        return;
      }
      playerMails.put(playerId, new CopyOnWriteArrayList<>(loadFromYamlLocked(playerId)));
      updateUnreadCount(playerId);
    }
  }

  private Mail loadMailFromYaml(org.bukkit.configuration.file.YamlConfiguration yml, String path) {
    String idStr = yml.getString(path + ".id");
    String senderId = yml.getString(path + ".senderId");
    String recipientId = yml.getString(path + ".recipientId");
    if (idStr == null || senderId == null || recipientId == null) {
      return null;
    }

    List<MailAttachment> attachments = new ArrayList<>();
    if (yml.contains(path + ".attachments")) {
      for (String attachStr : yml.getStringList(path + ".attachments")) {
        attachments.add(new MailAttachment(null, 1, attachStr));
      }
    }

    Mail mail =
        new Mail(
            UUID.fromString(idStr),
            UUID.fromString(senderId),
            yml.getString(path + ".senderName", ""),
            UUID.fromString(recipientId),
            yml.getString(path + ".recipientName", ""),
            yml.getString(path + ".subject", ""),
            yml.getString(path + ".content", ""),
            attachments,
            Instant.ofEpochMilli(yml.getLong(path + ".createdAt")),
            yml.getLong(path + ".expirationDays", DEFAULT_EXPIRATION_DAYS));
    mail.setRead(yml.getBoolean(path + ".read", false));
    mail.setClaimed(yml.getBoolean(path + ".claimed", attachments.isEmpty()));
    return mail;
  }

  private void saveMailToYaml(Mail mail) {
    synchronized (yamlSaveLock) {
      saveAllToYamlLocked();
    }
  }

  // D-034: YAML 持久化同步锁，避免异步任务与读写线程并发写文件损坏 yml
  private final Object yamlSaveLock = new Object();

  private List<Mail> loadFromYamlLocked(UUID playerId) {
    if (mailsFile == null || !mailsFile.exists()) {
      return List.of();
    }
    try {
      org.bukkit.configuration.file.YamlConfiguration yml =
          org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(mailsFile);
      List<Mail> mails = new ArrayList<>();
      String path = playerId.toString();
      org.bukkit.configuration.ConfigurationSection section = yml.getConfigurationSection(path);
      if (section != null) {
        for (String mailId : section.getKeys(false)) {
          try {
            Mail mail = loadMailFromYaml(yml, path + "." + mailId);
            if (mail != null && !mail.isExpired()) {
              mails.add(mail);
            }
          } catch (RuntimeException exception) {
            logger.warning("加载邮件失败: " + exception.getMessage());
          }
        }
      }
      mails.sort((left, right) -> right.getCreatedAt().compareTo(left.getCreatedAt()));
      return mails;
    } catch (RuntimeException exception) {
      logger.warning("加载邮件数据失败: " + exception.getMessage());
      return List.of();
    }
  }

  private boolean saveAllToYamlLocked() {
    if (mailsFile == null) {
      return false;
    }
    try {
      org.bukkit.configuration.file.YamlConfiguration yml =
          mailsFile.exists()
              ? org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(mailsFile)
              : new org.bukkit.configuration.file.YamlConfiguration();

      for (Map.Entry<UUID, List<Mail>> entry : playerMails.entrySet()) {
        String playerPath = entry.getKey().toString();
        yml.set(playerPath, null);
        for (Mail mail : entry.getValue()) {
          if (!mail.isExpired()) {
            writeMailToYaml(yml, playerPath + "." + mail.getId(), mail);
          }
        }
      }
      return saveYamlAtomically(yml);
    } catch (RuntimeException exception) {
      logger.warning("保存所有邮件失败: " + exception.getMessage());
      return false;
    }
  }

  private void writeMailToYaml(
      org.bukkit.configuration.file.YamlConfiguration yml, String path, Mail mail) {
    yml.set(path + ".id", mail.getId().toString());
    yml.set(path + ".senderId", mail.getSenderId().toString());
    yml.set(path + ".senderName", mail.getSenderName());
    yml.set(path + ".recipientId", mail.getRecipientId().toString());
    yml.set(path + ".recipientName", mail.getRecipientName());
    yml.set(path + ".subject", mail.getSubject());
    yml.set(path + ".content", mail.getContent());
    yml.set(path + ".createdAt", mail.getCreatedAt().toEpochMilli());
    yml.set(path + ".expirationDays", mail.getExpirationDays());
    yml.set(path + ".read", mail.isRead());
    yml.set(path + ".claimed", mail.isClaimed());

    List<String> attachments = new ArrayList<>();
    for (MailAttachment attachment : mail.getAttachments()) {
      attachments.add(attachment.getSerializedItem());
    }
    yml.set(path + ".attachments", attachments);
  }

  private boolean saveYamlAtomically(org.bukkit.configuration.file.YamlConfiguration yml) {
    Path target = mailsFile.toPath();
    Path temporary = target.resolveSibling(target.getFileName() + ".tmp");
    try {
      Path parent = target.getParent();
      if (parent != null) {
        Files.createDirectories(parent);
      }
      Files.writeString(
          temporary,
          yml.saveToString(),
          StandardCharsets.UTF_8,
          StandardOpenOption.CREATE,
          StandardOpenOption.TRUNCATE_EXISTING,
          StandardOpenOption.WRITE);
      try {
        Files.move(
            temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
      } catch (AtomicMoveNotSupportedException exception) {
        Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
      }
      return true;
    } catch (IOException exception) {
      try {
        Files.deleteIfExists(temporary);
      } catch (IOException ignored) {
        // Preserve the original write failure.
      }
      logger.warning("原子保存邮件失败: " + exception.getMessage());
      return false;
    }
  }

  private void saveAllToYaml() {
    synchronized (yamlSaveLock) {
      saveAllToYamlLocked();
    }
  }

  /** 清理玩家数据（当玩家离开时） */
  public void cleanup(UUID playerId) {
    synchronized (yamlSaveLock) {
      if (!acceptingOperations) {
        return;
      }
      playerMails.remove(playerId);
      unreadCounts.remove(playerId);
    }
  }

  /** 获取已加载的玩家邮箱数量 */
  public int loadedMailboxCount() {
    return playerMails.size();
  }

  /** 获取指定玩家的邮件总数 */
  public int getPlayerMailCount(UUID playerId) {
    List<Mail> mails = playerMails.get(playerId);
    return mails != null ? mails.size() : 0;
  }

  /** 获取指定玩家的未读邮件数 */
  public int getPlayerUnreadCount(UUID playerId) {
    return getUnreadCount(playerId);
  }

  /** 获取指定玩家有附件未领取的邮件数 */
  public long getPlayerPendingAttachmentCount(UUID playerId) {
    List<Mail> mails = playerMails.get(playerId);
    if (mails == null) return 0;
    return mails.stream()
        .filter(m -> m.hasAttachments() && !m.isClaimed() && !m.isExpired())
        .count();
  }
}
