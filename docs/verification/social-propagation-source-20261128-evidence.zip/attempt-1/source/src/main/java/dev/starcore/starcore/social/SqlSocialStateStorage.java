package dev.starcore.starcore.social;

import dev.starcore.starcore.core.database.DatabaseService;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * 社交系统 SQL 存储实现
 *
 * <p>支持：好友、公会、派对数据的数据库持久化
 */
public final class SqlSocialStateStorage {

  private final DatabaseService databaseService;
  private final Logger logger;

  public SqlSocialStateStorage(DatabaseService databaseService, Logger logger) {
    this.databaseService = databaseService;
    this.logger = logger;
  }

  private Connection getConnection() throws SQLException {
    return databaseService
        .dataSource()
        .orElseThrow(() -> new SQLException("Database not available"))
        .getConnection();
  }

  /** 创建所有必要的表 (迁移脚本已完成，主要用于 SQLite 兼容性检查) */
  public void ensureTables() {
    // 表已在迁移脚本中创建 (V7 for MySQL, V10 for SQLite)
    // 这里仅检查表是否存在，不创建
    try (Connection conn = getConnection();
        Statement stmt = conn.createStatement()) {

      // 检查是否需要 SQLite 兼容模式
      DatabaseMetaData meta = conn.getMetaData();
      String dbProduct = meta.getDatabaseProductName();
      boolean isSQLite = "SQLite".equalsIgnoreCase(dbProduct);

      if (isSQLite) {
        // CREATE IF NOT EXISTS also repairs partially initialized databases.
        createSqliteTables(stmt);
      } else {
        // MySQL 模式下，迁移脚本已创建表
        logger.info("社交系统数据库表已初始化 (MySQL/其他)");
      }
    } catch (Exception e) {
      logger.warning("检查社交系统数据库表失败: " + e.getMessage());
    }
  }

  /** 创建 SQLite 兼容的表 */
  private void createSqliteTables(Statement stmt) throws SQLException {
    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_friend_relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                player_uuid TEXT NOT NULL,
                friend_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(player_uuid, friend_uuid)
            )
        """);
    stmt.execute(
        "CREATE INDEX IF NOT EXISTS idx_friend_player ON starcore_friend_relations(player_uuid)");

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_friend_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_uuid TEXT NOT NULL,
                sender_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(target_uuid, sender_uuid)
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                player_uuid TEXT NOT NULL,
                blocked_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(player_uuid, blocked_uuid)
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_player_status (
                player_uuid TEXT PRIMARY KEY,
                is_online INTEGER NOT NULL DEFAULT 0,
                last_seen INTEGER NOT NULL,
                last_server TEXT
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_guilds (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                tag TEXT NOT NULL,
                leader_uuid TEXT NOT NULL,
                level INTEGER NOT NULL DEFAULT 1,
                experience INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                description TEXT
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_guild_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                player_uuid TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'MEMBER',
                joined_at INTEGER NOT NULL,
                UNIQUE(guild_id, player_uuid)
            )
        """);
    stmt.execute("CREATE INDEX IF NOT EXISTS idx_guild ON starcore_guild_members(guild_id)");

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_guild_invites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                inviter_uuid TEXT NOT NULL,
                target_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(guild_id, target_uuid)
            )
        """);
    stmt.execute(
        "CREATE INDEX IF NOT EXISTS idx_invite_target ON starcore_guild_invites(target_uuid)");

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_parties (
                id TEXT PRIMARY KEY,
                leader_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                friendly_fire INTEGER NOT NULL DEFAULT 0,
                exp_share INTEGER NOT NULL DEFAULT 1,
                max_members INTEGER NOT NULL DEFAULT 10
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_party_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                party_id TEXT NOT NULL,
                player_uuid TEXT NOT NULL,
                joined_at INTEGER NOT NULL,
                UNIQUE(party_id, player_uuid)
            )
        """);

    stmt.execute(
        """
            CREATE TABLE IF NOT EXISTS starcore_party_invites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inviter_uuid TEXT NOT NULL,
                target_uuid TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(inviter_uuid, target_uuid)
            )
        """);

    repairSqliteSchema(stmt.getConnection());
    stmt.execute(
        "CREATE INDEX IF NOT EXISTS idx_friend_req_target ON"
            + " starcore_friend_requests(target_uuid)");
    logger.info("社交系统 SQLite 兼容表已创建并完成旧列修复");
  }

  private void repairSqliteSchema(Connection connection) throws SQLException {
    boolean hasReceiver = hasColumn(connection, "starcore_friend_requests", "receiver_uuid");
    addColumnIfMissing(connection, "starcore_friend_requests", "target_uuid", "TEXT");
    if (hasReceiver) {
      execute(
          connection,
          "UPDATE starcore_friend_requests SET target_uuid = COALESCE(target_uuid, receiver_uuid)");
    }

    boolean hasLegacyPartyTarget = hasColumn(connection, "starcore_party_invites", "player_uuid");
    boolean hasLegacyPartyInviter = hasColumn(connection, "starcore_party_invites", "invited_by");
    addColumnIfMissing(connection, "starcore_party_invites", "inviter_uuid", "TEXT");
    addColumnIfMissing(connection, "starcore_party_invites", "target_uuid", "TEXT");
    if (hasLegacyPartyTarget) {
      execute(
          connection,
          "UPDATE starcore_party_invites SET target_uuid = COALESCE(target_uuid, player_uuid)");
    }
    if (hasLegacyPartyInviter) {
      execute(
          connection,
          "UPDATE starcore_party_invites SET inviter_uuid = COALESCE(inviter_uuid, invited_by)");
    }

    boolean hasLegacyLastOnline = hasColumn(connection, "starcore_player_status", "last_online");
    boolean hasLegacyOnlineStatus =
        hasColumn(connection, "starcore_player_status", "online_status");
    addColumnIfMissing(
        connection, "starcore_player_status", "is_online", "INTEGER NOT NULL DEFAULT 0");
    addColumnIfMissing(
        connection, "starcore_player_status", "last_seen", "INTEGER NOT NULL DEFAULT 0");
    if (hasLegacyLastOnline || hasLegacyOnlineStatus) {
      execute(
          connection,
          """
UPDATE starcore_player_status
SET last_seen = CASE WHEN last_seen = 0 THEN COALESCE(last_online, 0) ELSE last_seen END,
    is_online = CASE
        WHEN LOWER(COALESCE(CAST(online_status AS TEXT), '')) IN ('1', 'true', 'online') THEN 1
        ELSE is_online
    END
""");
    }
  }

  private boolean hasColumn(Connection connection, String tableName, String columnName)
      throws SQLException {
    try (Statement statement = connection.createStatement();
        ResultSet columns = statement.executeQuery("PRAGMA table_info('" + tableName + "')")) {
      while (columns.next()) {
        if (columnName.equalsIgnoreCase(columns.getString("name"))) {
          return true;
        }
      }
    }
    return false;
  }

  private void addColumnIfMissing(
      Connection connection, String tableName, String columnName, String definition)
      throws SQLException {
    if (!hasColumn(connection, tableName, columnName)) {
      execute(
          connection, "ALTER TABLE " + tableName + " ADD COLUMN " + columnName + " " + definition);
    }
  }

  private void execute(Connection connection, String sql) throws SQLException {
    try (Statement statement = connection.createStatement()) {
      statement.executeUpdate(sql);
    }
  }

  // ==================== 好友关系操作 ====================

  public void saveFriendRelation(UUID playerId, UUID friendId, long createdAt) {
    try (Connection conn = getConnection()) {
      portableUpsert(
          conn,
          "UPDATE starcore_friend_relations SET created_at = ? WHERE player_uuid = ? AND"
              + " friend_uuid = ?",
          new Object[] {createdAt, playerId.toString(), friendId.toString()},
          "INSERT INTO starcore_friend_relations (player_uuid, friend_uuid, created_at) VALUES (?,"
              + " ?, ?)",
          new Object[] {playerId.toString(), friendId.toString(), createdAt});
    } catch (Exception e) {
      logger.warning("保存好友关系失败: " + e.getMessage());
    }
  }

  public void deleteFriendRelation(UUID playerId, UUID friendId) {
    String sql =
        "DELETE FROM starcore_friend_relations WHERE (player_uuid = ? AND friend_uuid = ?) OR"
            + " (player_uuid = ? AND friend_uuid = ?)";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, playerId.toString());
      stmt.setString(2, friendId.toString());
      stmt.setString(3, friendId.toString());
      stmt.setString(4, playerId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      logger.warning("删除好友关系失败: " + e.getMessage());
    }
  }

  public void loadAllFriendRelations(java.util.Map<UUID, java.util.Set<UUID>> friendships) {
    String sql = "SELECT player_uuid, friend_uuid FROM starcore_friend_relations";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID playerId = UUID.fromString(rs.getString("player_uuid"));
        UUID friendId = UUID.fromString(rs.getString("friend_uuid"));
        friendships
            .computeIfAbsent(playerId, k -> java.util.concurrent.ConcurrentHashMap.newKeySet())
            .add(friendId);
      }
    } catch (Exception e) {
      logger.warning("加载好友关系失败: " + e.getMessage());
    }
  }

  // ==================== 好友请求操作 ====================

  public void saveFriendRequest(UUID targetId, UUID senderId, long createdAt) {
    try (Connection conn = getConnection()) {
      boolean hasReceiver = hasColumn(conn, "starcore_friend_requests", "receiver_uuid");
      boolean hasExpiry = hasColumn(conn, "starcore_friend_requests", "expires_at");
      boolean hasStatus = hasColumn(conn, "starcore_friend_requests", "status");
      List<String> columns = new ArrayList<>(List.of("target_uuid", "sender_uuid", "created_at"));
      List<Object> values =
          new ArrayList<>(List.of(targetId.toString(), senderId.toString(), createdAt));
      if (hasReceiver) {
        columns.add("receiver_uuid");
        values.add(targetId.toString());
      }
      if (hasExpiry) {
        columns.add("expires_at");
        values.add(Long.MAX_VALUE);
      }
      if (hasStatus) {
        columns.add("status");
        values.add("PENDING");
      }
      String placeholders = String.join(", ", Collections.nCopies(columns.size(), "?"));
      portableUpsert(
          conn,
          "UPDATE starcore_friend_requests SET created_at = ? WHERE target_uuid = ? AND sender_uuid"
              + " = ?",
          new Object[] {createdAt, targetId.toString(), senderId.toString()},
          "INSERT INTO starcore_friend_requests ("
              + String.join(", ", columns)
              + ") VALUES ("
              + placeholders
              + ")",
          values.toArray());
    } catch (Exception e) {
      logger.warning("保存好友请求失败: " + e.getMessage());
    }
  }

  public void deleteFriendRequest(UUID targetId, UUID senderId) {
    String sql = "DELETE FROM starcore_friend_requests WHERE target_uuid = ? AND sender_uuid = ?";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, targetId.toString());
      stmt.setString(2, senderId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      logger.warning("删除好友请求失败: " + e.getMessage());
    }
  }

  public void loadAllFriendRequests(java.util.Map<UUID, java.util.Set<UUID>> requests) {
    String sql = "SELECT target_uuid, sender_uuid FROM starcore_friend_requests";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID targetId = UUID.fromString(rs.getString("target_uuid"));
        UUID senderId = UUID.fromString(rs.getString("sender_uuid"));
        requests
            .computeIfAbsent(targetId, k -> java.util.concurrent.ConcurrentHashMap.newKeySet())
            .add(senderId);
      }
    } catch (Exception e) {
      logger.warning("加载好友请求失败: " + e.getMessage());
    }
  }

  // ==================== 黑名单操作 ====================

  public void saveBlacklistEntry(UUID playerId, UUID blockedId, long createdAt) {
    try (Connection conn = getConnection()) {
      portableUpsert(
          conn,
          "UPDATE starcore_blacklist SET created_at = ? WHERE player_uuid = ? AND blocked_uuid = ?",
          new Object[] {createdAt, playerId.toString(), blockedId.toString()},
          "INSERT INTO starcore_blacklist (player_uuid, blocked_uuid, created_at) VALUES (?, ?, ?)",
          new Object[] {playerId.toString(), blockedId.toString(), createdAt});
    } catch (Exception e) {
      logger.warning("保存黑名单失败: " + e.getMessage());
    }
  }

  public void deleteBlacklistEntry(UUID playerId, UUID blockedId) {
    String sql = "DELETE FROM starcore_blacklist WHERE player_uuid = ? AND blocked_uuid = ?";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, playerId.toString());
      stmt.setString(2, blockedId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      logger.warning("删除黑名单失败: " + e.getMessage());
    }
  }

  public void loadAllBlacklist(java.util.Map<UUID, java.util.Set<UUID>> blacklist) {
    String sql = "SELECT player_uuid, blocked_uuid FROM starcore_blacklist";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID playerId = UUID.fromString(rs.getString("player_uuid"));
        UUID blockedId = UUID.fromString(rs.getString("blocked_uuid"));
        blacklist
            .computeIfAbsent(playerId, k -> java.util.concurrent.ConcurrentHashMap.newKeySet())
            .add(blockedId);
      }
    } catch (Exception e) {
      logger.warning("加载黑名单失败: " + e.getMessage());
    }
  }

  // ==================== 公会操作 ====================

  public void saveGuild(dev.starcore.starcore.social.guild.Guild guild) {
    String insertSql =
        "INSERT INTO starcore_guilds (id, name, tag, leader_uuid, level, experience, created_at,"
            + " description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    String updateSql =
        "UPDATE starcore_guilds SET name = ?, tag = ?, leader_uuid = ?, level = ?, experience = ?, "
            + "created_at = ?, description = ? WHERE id = ?";
    String memberSql =
        "INSERT INTO starcore_guild_members (guild_id, player_uuid, role, joined_at) VALUES (?, ?,"
            + " ?, ?)";

    try (Connection conn = getConnection()) {
      conn.setAutoCommit(false);
      String description = guild.getDescription() != null ? guild.getDescription() : "";
      portableUpsert(
          conn,
          updateSql,
          new Object[] {
            guild.getName(),
            guild.getTag(),
            guild.getLeader().toString(),
            guild.getLevel(),
            guild.getExperience(),
            guild.getCreatedTime(),
            description,
            guild.getId().toString()
          },
          insertSql,
          new Object[] {
            guild.getId().toString(),
            guild.getName(),
            guild.getTag(),
            guild.getLeader().toString(),
            guild.getLevel(),
            guild.getExperience(),
            guild.getCreatedTime(),
            description
          });

      try (PreparedStatement deleteMembers =
          conn.prepareStatement("DELETE FROM starcore_guild_members WHERE guild_id = ?")) {
        deleteMembers.setString(1, guild.getId().toString());
        deleteMembers.executeUpdate();
      }

      try (PreparedStatement memberStmt = conn.prepareStatement(memberSql)) {
        for (UUID memberId : guild.getMembers()) {
          memberStmt.setString(1, guild.getId().toString());
          memberStmt.setString(2, memberId.toString());
          memberStmt.setString(3, guild.getMemberRole(memberId).name());
          memberStmt.setLong(4, System.currentTimeMillis());
          memberStmt.addBatch();
        }
        memberStmt.executeBatch();
      }
      conn.commit();
    } catch (Exception e) {
      logger.warning("保存公会失败: " + e.getMessage());
    }
  }

  public void deleteGuild(UUID guildId) {
    String sql = "DELETE FROM starcore_guilds WHERE id = ?";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, guildId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      logger.warning("删除公会失败: " + e.getMessage());
    }
  }

  public void loadAllGuilds(
      java.util.Map<UUID, dev.starcore.starcore.social.guild.Guild> guilds,
      java.util.Map<String, UUID> guildNames,
      java.util.Map<UUID, UUID> playerGuilds) {
    String guildSql = "SELECT * FROM starcore_guilds";
    String memberSql = "SELECT * FROM starcore_guild_members WHERE guild_id = ?";

    try (Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        ResultSet guildRs = stmt.executeQuery(guildSql)) {

      while (guildRs.next()) {
        UUID guildId = UUID.fromString(guildRs.getString("id"));
        String name = guildRs.getString("name");
        String tag = guildRs.getString("tag");
        UUID leaderId = UUID.fromString(guildRs.getString("leader_uuid"));
        int level = guildRs.getInt("level");
        int exp = guildRs.getInt("experience");
        long createdAt = guildRs.getLong("created_at");
        String description = guildRs.getString("description");

        dev.starcore.starcore.social.guild.Guild guild =
            new dev.starcore.starcore.social.guild.Guild(guildId, name, tag, leaderId);
        guild.setLevel(level);
        guild.setExperience(exp);
        if (description != null && !description.isEmpty()) {
          guild.setDescription(description);
        }

        // 加载成员
        try (PreparedStatement memberStmt = conn.prepareStatement(memberSql)) {
          memberStmt.setString(1, guildId.toString());
          try (ResultSet memberRs = memberStmt.executeQuery()) {
            while (memberRs.next()) {
              UUID memberId = UUID.fromString(memberRs.getString("player_uuid"));
              String roleStr = memberRs.getString("role");
              guild.addMember(memberId);
              if (roleStr != null) {
                try {
                  guild.setMemberRole(
                      memberId, dev.starcore.starcore.social.guild.GuildRole.valueOf(roleStr));
                } catch (IllegalArgumentException e) {
                  logger.warning("加载公会成员角色失败，未知角色: " + roleStr + " - " + e.getMessage());
                }
              }
              playerGuilds.put(memberId, guildId);
            }
          }
        }

        guilds.put(guildId, guild);
        guildNames.put(name.toLowerCase(), guildId);
      }
    } catch (Exception e) {
      logger.warning("加载公会失败: " + e.getMessage());
    }
  }

  // ==================== 派对操作 ====================

  public void saveParty(dev.starcore.starcore.social.party.Party party) {
    persistParty(party, null, null);
  }

  public void acceptPartyInvite(
      dev.starcore.starcore.social.party.Party party, UUID inviterId, UUID targetId) {
    persistParty(party, inviterId, targetId);
  }

  private void persistParty(
      dev.starcore.starcore.social.party.Party party, UUID inviterId, UUID targetId) {
    partyTransaction(
        "保存派对失败",
        conn -> {
          writeParty(conn, party);
          if (inviterId != null) {
            executeUpdate(
                conn,
                "DELETE FROM starcore_party_invites WHERE inviter_uuid = ? AND target_uuid = ?",
                new Object[] {inviterId.toString(), targetId.toString()});
          }
        });
  }

  private void partyTransaction(String message, PartyTransaction transaction) {
    Connection connection = null;
    boolean commitAttempted = false;
    try {
      connection = getConnection();
      connection.setAutoCommit(false);
      transaction.write(connection);
      commitAttempted = true;
      connection.commit();
    } catch (Exception failure) {
      boolean outcomeUnknown = commitAttempted;
      if (connection != null) {
        try {
          connection.rollback();
        } catch (SQLException rollbackFailure) {
          failure.addSuppressed(rollbackFailure);
          outcomeUnknown = true;
        }
      }
      throw new PartyPersistenceException(message, failure, outcomeUnknown);
    } finally {
      if (connection != null) {
        try {
          connection.close();
        } catch (Exception closeFailure) {
          logger.warning("关闭派对存储连接失败: " + closeFailure.getMessage());
        }
      }
    }
  }

  @FunctionalInterface
  private interface PartyTransaction {
    void write(Connection connection) throws SQLException;
  }

  public static final class PartyPersistenceException extends IllegalStateException {
    private final boolean outcomeUnknown;

    private PartyPersistenceException(String message, Throwable cause, boolean outcomeUnknown) {
      super(message, cause);
      this.outcomeUnknown = outcomeUnknown;
    }

    public boolean isOutcomeUnknown() {
      return outcomeUnknown;
    }
  }

  private void writeParty(Connection conn, dev.starcore.starcore.social.party.Party party)
      throws SQLException {
    String insertSql =
        "INSERT INTO starcore_parties (id, leader_uuid, created_at, friendly_fire, exp_share,"
            + " max_members) VALUES (?, ?, ?, ?, ?, ?)";
    String updateSql =
        "UPDATE starcore_parties SET leader_uuid = ?, created_at = ?, friendly_fire = ?, "
            + "exp_share = ?, max_members = ? WHERE id = ?";

    portableUpsert(
        conn,
        updateSql,
        new Object[] {
          party.getLeader().toString(),
          party.getCreatedTime(),
          party.isFriendlyFire(),
          party.isExpShare(),
          party.getMaxMembers(),
          party.getId().toString()
        },
        insertSql,
        new Object[] {
          party.getId().toString(),
          party.getLeader().toString(),
          party.getCreatedTime(),
          party.isFriendlyFire(),
          party.isExpShare(),
          party.getMaxMembers()
        });

    try (PreparedStatement deleteMembers =
        conn.prepareStatement("DELETE FROM starcore_party_members WHERE party_id = ?")) {
      deleteMembers.setString(1, party.getId().toString());
      deleteMembers.executeUpdate();
    }

    String memberSql =
        "INSERT INTO starcore_party_members (party_id, player_uuid, joined_at) VALUES (?, ?, ?)";
    try (PreparedStatement memberStmt = conn.prepareStatement(memberSql)) {
      for (UUID memberId : party.getMembers()) {
        memberStmt.setString(1, party.getId().toString());
        memberStmt.setString(2, memberId.toString());
        memberStmt.setLong(3, System.currentTimeMillis());
        memberStmt.addBatch();
      }
      memberStmt.executeBatch();
    }
  }

  public void deleteParty(UUID partyId) {
    partyTransaction(
        "删除派对失败",
        conn -> {
          executeUpdate(
              conn,
              "DELETE FROM starcore_party_members WHERE party_id = ?",
              new Object[] {partyId.toString()});
          executeUpdate(
              conn, "DELETE FROM starcore_parties WHERE id = ?", new Object[] {partyId.toString()});
        });
  }

  public void loadAllParties(
      java.util.Map<UUID, dev.starcore.starcore.social.party.Party> parties,
      java.util.Map<UUID, UUID> playerParties) {
    String partySql = "SELECT * FROM starcore_parties";
    String memberSql = "SELECT * FROM starcore_party_members WHERE party_id = ?";
    java.util.Map<UUID, dev.starcore.starcore.social.party.Party> loaded =
        new java.util.HashMap<>();
    java.util.Map<UUID, UUID> loadedMemberships = new java.util.HashMap<>();

    try (Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        ResultSet partyRs = stmt.executeQuery(partySql)) {

      while (partyRs.next()) {
        UUID partyId = UUID.fromString(partyRs.getString("id"));
        UUID leaderId = UUID.fromString(partyRs.getString("leader_uuid"));
        long createdAt = partyRs.getLong("created_at");
        boolean friendlyFire = partyRs.getBoolean("friendly_fire");
        boolean expShare = partyRs.getBoolean("exp_share");
        int maxMembers = partyRs.getInt("max_members");

        var data = new dev.starcore.starcore.social.party.PartyService.PartyData();
        data.setId(partyId);
        data.setLeader(leaderId);
        data.setCreatedTime(createdAt);
        data.setFriendlyFire(friendlyFire);
        data.setExpShare(expShare);
        data.setMaxMembers(maxMembers);
        List<String> members = new ArrayList<>();

        // 加载成员
        try (PreparedStatement memberStmt = conn.prepareStatement(memberSql)) {
          memberStmt.setString(1, partyId.toString());
          try (ResultSet memberRs = memberStmt.executeQuery()) {
            while (memberRs.next()) {
              members.add(memberRs.getString("player_uuid"));
            }
          }
        }

        data.setMembers(members);
        var party = data.toParty();
        if (!party.isMember(leaderId)) throw new IllegalStateException("派对队长不在成员中");
        for (UUID member : party.getMembers()) {
          if (loadedMemberships.putIfAbsent(member, partyId) != null)
            throw new IllegalStateException("玩家同时属于多个派对");
        }
        loaded.put(partyId, party);
      }
    } catch (Exception e) {
      throw new IllegalStateException("加载派对失败", e);
    }
    parties.putAll(loaded);
    playerParties.putAll(loadedMemberships);
  }

  // ==================== 邀请操作 ====================

  public void saveGuildInvite(UUID guildId, UUID inviterId, UUID targetId, long timestamp) {
    try (Connection conn = getConnection()) {
      portableUpsert(
          conn,
          "UPDATE starcore_guild_invites SET inviter_uuid = ?, created_at = ? WHERE guild_id = ?"
              + " AND target_uuid = ?",
          new Object[] {inviterId.toString(), timestamp, guildId.toString(), targetId.toString()},
          "INSERT INTO starcore_guild_invites (guild_id, inviter_uuid, target_uuid, created_at)"
              + " VALUES (?, ?, ?, ?)",
          new Object[] {guildId.toString(), inviterId.toString(), targetId.toString(), timestamp});
    } catch (Exception e) {
      logger.warning("保存公会邀请失败: " + e.getMessage());
    }
  }

  public void deleteGuildInvite(UUID guildId, UUID targetId) {
    String sql = "DELETE FROM starcore_guild_invites WHERE guild_id = ? AND target_uuid = ?";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, guildId.toString());
      stmt.setString(2, targetId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      logger.warning("删除公会邀请失败: " + e.getMessage());
    }
  }

  public void loadAllGuildInvites(
      java.util.Map<
              UUID, java.util.Set<dev.starcore.starcore.social.guild.GuildService.GuildInvite>>
          invites) {
    String sql =
        "SELECT guild_id, inviter_uuid, target_uuid, created_at FROM starcore_guild_invites";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID guildId = UUID.fromString(rs.getString("guild_id"));
        UUID inviterId = UUID.fromString(rs.getString("inviter_uuid"));
        UUID targetId = UUID.fromString(rs.getString("target_uuid"));
        long timestamp = rs.getLong("created_at");
        var invite =
            new dev.starcore.starcore.social.guild.GuildService.GuildInvite(
                guildId, inviterId, targetId, timestamp);
        invites
            .computeIfAbsent(targetId, k -> java.util.concurrent.ConcurrentHashMap.newKeySet())
            .add(invite);
      }
    } catch (Exception e) {
      logger.warning("加载公会邀请失败: " + e.getMessage());
    }
  }

  public void savePartyInvite(UUID inviterId, UUID targetId, long timestamp) {
    try (Connection conn = getConnection()) {
      boolean hasPartyId = hasColumn(conn, "starcore_party_invites", "party_uuid");
      boolean hasPlayerId = hasColumn(conn, "starcore_party_invites", "player_uuid");
      boolean hasLegacyInviter = hasColumn(conn, "starcore_party_invites", "invited_by");
      boolean hasExpiry = hasColumn(conn, "starcore_party_invites", "expires_at");
      List<String> columns = new ArrayList<>(List.of("inviter_uuid", "target_uuid", "created_at"));
      List<Object> values =
          new ArrayList<>(List.of(inviterId.toString(), targetId.toString(), timestamp));
      if (hasPartyId) {
        columns.add("party_uuid");
        values.add(targetId.toString());
      }
      if (hasPlayerId) {
        columns.add("player_uuid");
        values.add(targetId.toString());
      }
      if (hasLegacyInviter) {
        columns.add("invited_by");
        values.add(inviterId.toString());
      }
      if (hasExpiry) {
        columns.add("expires_at");
        values.add(Math.addExact(timestamp, 10L * 60 * 1000));
      }
      String placeholders = String.join(", ", Collections.nCopies(columns.size(), "?"));
      String update = "UPDATE starcore_party_invites SET created_at = ?";
      List<Object> updateValues = new ArrayList<>(List.of(timestamp));
      if (hasExpiry) {
        update += ", expires_at = ?";
        updateValues.add(Math.addExact(timestamp, 10L * 60 * 1000));
      }
      update += " WHERE inviter_uuid = ? AND target_uuid = ?";
      updateValues.add(inviterId.toString());
      updateValues.add(targetId.toString());
      portableUpsert(
          conn,
          update,
          updateValues.toArray(),
          "INSERT INTO starcore_party_invites ("
              + String.join(", ", columns)
              + ") VALUES ("
              + placeholders
              + ")",
          values.toArray());
    } catch (Exception e) {
      throw new IllegalStateException("保存派对邀请失败", e);
    }
  }

  public void deletePartyInvite(UUID inviterId, UUID targetId) {
    String sql = "DELETE FROM starcore_party_invites WHERE inviter_uuid = ? AND target_uuid = ?";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
      stmt.setString(1, inviterId.toString());
      stmt.setString(2, targetId.toString());
      stmt.executeUpdate();
    } catch (Exception e) {
      throw new IllegalStateException("删除派对邀请失败", e);
    }
  }

  public void loadAllPartyInvites(java.util.Map<UUID, java.util.Set<UUID>> invites) {
    loadAllPartyInvites(invites, new java.util.HashMap<>());
  }

  public void loadAllPartyInvites(
      java.util.Map<UUID, java.util.Set<UUID>> invites,
      java.util.Map<UUID, java.util.Map<UUID, Long>> timestamps) {
    String sql = "SELECT inviter_uuid, target_uuid, created_at FROM starcore_party_invites";
    java.util.Map<UUID, java.util.Set<UUID>> loaded = new java.util.HashMap<>();
    java.util.Map<UUID, java.util.Map<UUID, Long>> loadedTimes = new java.util.HashMap<>();
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID inviterId = UUID.fromString(rs.getString("inviter_uuid"));
        UUID targetId = UUID.fromString(rs.getString("target_uuid"));
        loaded
            .computeIfAbsent(targetId, k -> java.util.concurrent.ConcurrentHashMap.newKeySet())
            .add(inviterId);
        loadedTimes
            .computeIfAbsent(targetId, ignored -> new java.util.HashMap<>())
            .put(inviterId, rs.getLong("created_at"));
      }
    } catch (Exception e) {
      throw new IllegalStateException("加载派对邀请失败", e);
    }
    invites.putAll(loaded);
    timestamps.putAll(loadedTimes);
  }

  // ==================== 在线状态操作 ====================

  public void savePlayerStatus(UUID playerId, boolean isOnline) {
    String playerUuid = playerId.toString();
    long lastSeen = System.currentTimeMillis();
    try (Connection conn = getConnection()) {
      boolean hasLegacyLastOnline = hasColumn(conn, "starcore_player_status", "last_online");
      boolean hasLegacyOnlineStatus = hasColumn(conn, "starcore_player_status", "online_status");
      String status = isOnline ? "ONLINE" : "OFFLINE";
      String update = "UPDATE starcore_player_status SET is_online = ?, last_seen = ?";
      List<Object> updateValues = new ArrayList<>(List.of(isOnline, lastSeen));
      if (hasLegacyLastOnline) {
        update += ", last_online = ?";
        updateValues.add(lastSeen);
      }
      if (hasLegacyOnlineStatus) {
        update += ", online_status = ?";
        updateValues.add(status);
      }
      update += " WHERE player_uuid = ?";
      updateValues.add(playerUuid);

      List<String> columns = new ArrayList<>(List.of("player_uuid", "is_online", "last_seen"));
      List<Object> values = new ArrayList<>(List.of(playerUuid, isOnline, lastSeen));
      if (hasLegacyLastOnline) {
        columns.add("last_online");
        values.add(lastSeen);
      }
      if (hasLegacyOnlineStatus) {
        columns.add("online_status");
        values.add(status);
      }
      String placeholders = String.join(", ", Collections.nCopies(columns.size(), "?"));
      portableUpsert(
          conn,
          update,
          updateValues.toArray(),
          "INSERT INTO starcore_player_status ("
              + String.join(", ", columns)
              + ") VALUES ("
              + placeholders
              + ")",
          values.toArray());
    } catch (Exception e) {
      logger.warning("保存玩家状态失败: " + e.getMessage());
    }
  }

  public void loadAllPlayerStatus(java.util.Map<UUID, Boolean> statusMap) {
    String sql = "SELECT player_uuid, is_online FROM starcore_player_status";
    try (Connection conn = getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery()) {
      while (rs.next()) {
        UUID playerId = UUID.fromString(rs.getString("player_uuid"));
        statusMap.put(playerId, rs.getBoolean("is_online"));
      }
    } catch (Exception e) {
      logger.warning("加载玩家状态失败: " + e.getMessage());
    }
  }

  // ==================== 批量操作（用于定期保存）====================

  public void saveAllFriends(java.util.Map<UUID, java.util.Set<UUID>> friendships) {
    try (Connection conn = getConnection()) {
      conn.setAutoCommit(false);
      try (Statement stmt = conn.createStatement()) {
        stmt.execute("DELETE FROM starcore_friend_relations");
      }

      String sql =
          "INSERT INTO starcore_friend_relations (player_uuid, friend_uuid, created_at) VALUES (?,"
              + " ?, ?)";
      try (PreparedStatement stmt = conn.prepareStatement(sql)) {
        long now = System.currentTimeMillis();
        for (var entry : friendships.entrySet()) {
          for (UUID friendId : entry.getValue()) {
            stmt.setString(1, entry.getKey().toString());
            stmt.setString(2, friendId.toString());
            stmt.setLong(3, now);
            stmt.addBatch();
          }
        }
        stmt.executeBatch();
      }
      conn.commit();
    } catch (Exception e) {
      logger.warning("批量保存好友关系失败: " + e.getMessage());
    }
  }

  public void saveAllGuilds(java.util.Collection<dev.starcore.starcore.social.guild.Guild> guilds) {
    try (Connection conn = getConnection()) {
      conn.setAutoCommit(false);
      try (Statement stmt = conn.createStatement()) {
        stmt.execute("DELETE FROM starcore_guild_members");
        stmt.execute("DELETE FROM starcore_guilds");
      }

      String guildSql =
          "INSERT INTO starcore_guilds (id, name, tag, leader_uuid, level, experience, created_at,"
              + " description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      String memberSql =
          "INSERT INTO starcore_guild_members (guild_id, player_uuid, role, joined_at) VALUES (?,"
              + " ?, ?, ?)";

      for (dev.starcore.starcore.social.guild.Guild guild : guilds) {
        try (PreparedStatement guildStmt = conn.prepareStatement(guildSql)) {
          guildStmt.setString(1, guild.getId().toString());
          guildStmt.setString(2, guild.getName());
          guildStmt.setString(3, guild.getTag());
          guildStmt.setString(4, guild.getLeader().toString());
          guildStmt.setInt(5, guild.getLevel());
          guildStmt.setInt(6, guild.getExperience());
          guildStmt.setLong(7, guild.getCreatedTime());
          guildStmt.setString(8, guild.getDescription() != null ? guild.getDescription() : "");
          guildStmt.executeUpdate();
        }

        try (PreparedStatement memberStmt = conn.prepareStatement(memberSql)) {
          for (UUID memberId : guild.getMembers()) {
            memberStmt.setString(1, guild.getId().toString());
            memberStmt.setString(2, memberId.toString());
            memberStmt.setString(3, guild.getMemberRole(memberId).name());
            memberStmt.setLong(4, System.currentTimeMillis());
            memberStmt.addBatch();
          }
          memberStmt.executeBatch();
        }
      }
      conn.commit();
    } catch (Exception e) {
      logger.warning("批量保存公会失败: " + e.getMessage());
    }
  }

  public void saveAllParties(
      java.util.Collection<dev.starcore.starcore.social.party.Party> parties) {
    partyTransaction(
        "批量保存派对失败",
        conn -> {
          try (Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM starcore_party_members");
            stmt.execute("DELETE FROM starcore_parties");
          }
          for (dev.starcore.starcore.social.party.Party party : parties) {
            writeParty(conn, party);
          }
        });
  }

  private static void portableUpsert(
      Connection connection,
      String updateSql,
      Object[] updateValues,
      String insertSql,
      Object[] insertValues)
      throws SQLException {
    if (executeUpdate(connection, updateSql, updateValues) > 0) {
      return;
    }
    try {
      executeUpdate(connection, insertSql, insertValues);
    } catch (SQLException insertFailure) {
      // A concurrent first write may win between the UPDATE and INSERT.
      if (executeUpdate(connection, updateSql, updateValues) == 0) {
        throw insertFailure;
      }
    }
  }

  private static int executeUpdate(Connection connection, String sql, Object[] values)
      throws SQLException {
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
      for (int index = 0; index < values.length; index++) {
        statement.setObject(index + 1, values[index]);
      }
      return statement.executeUpdate();
    }
  }

  /** 检查数据库是否可用 */
  public boolean isDatabaseAvailable() {
    return databaseService.isRunning();
  }
}
