package dev.starcore.starcore.social.simulation;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.BiConsumer;
import java.util.function.Function;

/** Serializes social influence mutations on the configured I/O executor. */
public final class SocialInfluenceWriteQueue {
  private static final int MAX_PENDING_WRITES = 4096;

  private final SocialInfluenceService influenceService;
  private final Function<Runnable, CompletableFuture<Void>> ioSubmitter;
  private final BiConsumer<String, Throwable> failureLogger;
  private final Object lock = new Object();
  private final Deque<PendingWrite> pendingWrites = new ArrayDeque<>();

  private boolean drainScheduled;

  public SocialInfluenceWriteQueue(
      SocialInfluenceService influenceService,
      Function<Runnable, CompletableFuture<Void>> ioSubmitter,
      BiConsumer<String, Throwable> failureLogger) {
    this.influenceService = influenceService;
    this.ioSubmitter = Objects.requireNonNull(ioSubmitter, "ioSubmitter");
    this.failureLogger = Objects.requireNonNull(failureLogger, "failureLogger");
  }

  public static SocialInfluenceWriteQueue synchronous(SocialInfluenceService influenceService) {
    return synchronous(influenceService, (subject, failure) -> {});
  }

  public static SocialInfluenceWriteQueue synchronous(
      SocialInfluenceService influenceService, BiConsumer<String, Throwable> failureLogger) {
    return new SocialInfluenceWriteQueue(
        influenceService,
        task -> {
          try {
            task.run();
            return CompletableFuture.completedFuture(null);
          } catch (RuntimeException failure) {
            return CompletableFuture.failedFuture(failure);
          }
        },
        failureLogger);
  }

  public CompletableFuture<Void> submit(UUID playerId, int amount, String source) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(source, "source");
    if (influenceService == null) {
      return CompletableFuture.completedFuture(null);
    }

    return enqueue(
        "player=" + playerId, () -> influenceService.addInfluence(playerId, amount, source));
  }

  public CompletableFuture<Void> submitMaintenance(String taskName, Runnable task) {
    Objects.requireNonNull(taskName, "taskName");
    Objects.requireNonNull(task, "task");
    return enqueue("task=" + taskName, task);
  }

  private CompletableFuture<Void> enqueue(String subject, Runnable task) {
    PendingWrite write = new PendingWrite(subject, task);
    boolean scheduleDrain = false;
    RejectedExecutionException rejection = null;
    synchronized (lock) {
      if (pendingWrites.size() >= MAX_PENDING_WRITES) {
        rejection = new RejectedExecutionException("Social influence write queue is full");
      } else {
        pendingWrites.addLast(write);
        if (!drainScheduled) {
          drainScheduled = true;
          scheduleDrain = true;
        }
      }
    }

    if (rejection != null) {
      fail(write, rejection);
      return write.completion();
    }
    if (scheduleDrain) {
      scheduleDrain(subject);
    }
    return write.completion();
  }

  private void scheduleDrain(String subject) {
    try {
      CompletableFuture<Void> scheduled =
          Objects.requireNonNull(ioSubmitter.apply(this::drain), "I/O submission returned null");
      scheduled.whenComplete(
          (ignored, failure) -> {
            if (failure != null) {
              failPending(subject, failure);
            }
          });
    } catch (RuntimeException failure) {
      failPending(subject, failure);
    }
  }

  private void drain() {
    while (true) {
      PendingWrite write;
      synchronized (lock) {
        write = pendingWrites.pollFirst();
        if (write == null) {
          drainScheduled = false;
          return;
        }
      }

      try {
        write.task().run();
        write.completion().complete(null);
      } catch (RuntimeException failure) {
        fail(write, failure);
      }
    }
  }

  private void failPending(String subject, Throwable failure) {
    List<PendingWrite> failedWrites;
    synchronized (lock) {
      drainScheduled = false;
      failedWrites = new ArrayList<>(pendingWrites);
      pendingWrites.clear();
    }
    failedWrites.forEach(write -> fail(write, failure));
    if (failedWrites.isEmpty()) {
      logFailure(subject, failure);
    }
  }

  private void fail(PendingWrite write, Throwable failure) {
    logFailure(write.subject(), failure);
    write.completion().completeExceptionally(failure);
  }

  private void logFailure(String subject, Throwable failure) {
    try {
      failureLogger.accept(subject, failure);
    } catch (RuntimeException ignored) {
      // Logging must not prevent the remaining queued writes from draining.
    }
  }

  private record PendingWrite(String subject, Runnable task, CompletableFuture<Void> completion) {
    private PendingWrite(String subject, Runnable task) {
      this(subject, task, new CompletableFuture<>());
    }
  }
}
