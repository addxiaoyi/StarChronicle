package dev.starcore.starcore.social.party;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.Clock;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

/**
 * 派对服务
 *
 * <p>支持两种持久化模式： 1. YAML 文件持久化（默认，兼容性更好） 2. 数据库持久化（通过 SqlSocialStateStorage）
 */
public final class PartyService {
  private final Clock clock;

  public PartyService() {
    this(Clock.systemUTC());
  }

  PartyService(Clock clock) {
    this.clock = Objects.requireNonNull(clock);
  }

  // 所有派对（派对ID -> 派对）
  private final Map<UUID, Party> parties = new ConcurrentHashMap<>();

  // 玩家派对映射（玩家UUID -> 派对ID）
  private final Map<UUID, UUID> playerParties = new ConcurrentHashMap<>();

  // 派对邀请（目标UUID -> 邀请者UUID列表）
  private final Map<UUID, Set<UUID>> partyInvites = new ConcurrentHashMap<>();

  // 派对邀请冷却（玩家UUID -> 上次邀请时间），D-019 防止重复邀请
  private final Map<UUID, Long> lastInviteTime = new ConcurrentHashMap<>();

  // 派对邀请时间戳（target UUID -> 邀请者 UUID -> 邀请时间），D-024 邀请 TTL（10 分钟）
  private final Map<UUID, Map<UUID, Long>> partyInviteTimestamps = new ConcurrentHashMap<>();
  private static final long PARTY_INVITE_TTL_MS = 10L * 60 * 1000; // 10 分钟
  private static final long PARTY_INVITE_COOLDOWN_MS = 30_000L; // 30 秒冷却

  // 持久化相关
  private Plugin plugin;
  private File partiesFile;
  private File invitesFile;
  private boolean persistenceBlocked;

  // 数据库存储引用（可选）
  private dev.starcore.starcore.social.SqlSocialStateStorage sqlStorage;

  /** 设置数据库存储（用于数据库持久化） */
  public synchronized void setSqlStorage(
      dev.starcore.starcore.social.SqlSocialStateStorage sqlStorage) {
    this.sqlStorage = sqlStorage;
  }

  /** 检查数据库是否可用 */
  public boolean isDatabaseAvailable() {
    return sqlStorage != null && sqlStorage.isDatabaseAvailable();
  }

  /** 初始化持久化 */
  public void initialize(Plugin plugin) {
    this.plugin = plugin;
    File dir = new File(plugin.getDataFolder(), "social");
    if (!dir.exists()) dir.mkdirs();
    this.partiesFile = new File(dir, "parties.yml");
    this.invitesFile = new File(dir, "party-invites.yml");
  }

  /** 加载派对数据 */
  public synchronized void loadData() {
    persistenceBlocked = true;
    try {
      if (sqlStorage != null) {
        loadFromDatabase();
      } else {
        loadFromYaml();
      }
      persistenceBlocked = false;
    } catch (Exception failure) {
      if (plugin != null) {
        plugin.getLogger().warning("加载派对数据失败，持久化已隔离: " + failure.getMessage());
      }
    }
  }

  /** 保存派对数据 */
  public synchronized void saveData() {
    requireWritable();
    if (sqlStorage != null) {
      saveToDatabase();
    } else {
      saveToYaml();
    }
  }

  /** 从 YAML 加载派对数据 */
  private void loadFromYaml() throws Exception {
    Map<UUID, Party> loadedParties = loadPartiesYaml();
    Map<UUID, Set<UUID>> loadedInvites = new HashMap<>();
    Map<UUID, Map<UUID, Long>> timestamps = new HashMap<>();
    loadInvitesYaml(loadedInvites, timestamps);
    restoreState(loadedParties, loadedInvites, timestamps);
  }

  /** 保存派对数据到 YAML */
  private void saveToYaml() {
    savePartiesYaml();
    saveInvitesYaml();
  }

  /** 从数据库加载派对数据 */
  private void loadFromDatabase() {
    if (sqlStorage != null) {
      Map<UUID, Party> loadedParties = new HashMap<>();
      Map<UUID, UUID> loadedMemberships = new HashMap<>();
      sqlStorage.loadAllParties(loadedParties, loadedMemberships);
      Map<UUID, Set<UUID>> loaded = new HashMap<>();
      Map<UUID, Map<UUID, Long>> timestamps = new HashMap<>();
      sqlStorage.loadAllPartyInvites(loaded, timestamps);
      restoreState(loadedParties, loaded, timestamps);
      if (plugin != null) plugin.getLogger().info("已从数据库加载 " + parties.size() + " 个派对");
    }
  }

  /** 保存派对数据到数据库 */
  private void saveToDatabase() {
    if (sqlStorage != null) {
      try {
        sqlStorage.saveAllParties(parties.values());
      } catch (RuntimeException failure) {
        isolateUnknownWrite(failure);
        throw failure;
      }
    }
  }

  /** 保存单个派对到数据库 */
  public synchronized void savePartyToDatabase(Party party) {
    requireWritable();
    try {
      if (sqlStorage != null) {
        sqlStorage.saveParty(party);
      } else {
        Map<UUID, Party> snapshot = new HashMap<>(parties);
        snapshot.put(party.getId(), party);
        savePartiesYaml(snapshot.values());
      }
    } catch (RuntimeException failure) {
      isolateUnknownWrite(failure);
      throw failure;
    }
  }

  /** 从数据库删除派对 */
  public synchronized void deletePartyFromDatabase(UUID partyId) {
    requireWritable();
    try {
      if (sqlStorage != null) {
        sqlStorage.deleteParty(partyId);
      } else {
        Map<UUID, Party> snapshot = new HashMap<>(parties);
        snapshot.remove(partyId);
        savePartiesYaml(snapshot.values());
      }
    } catch (RuntimeException failure) {
      isolateUnknownWrite(failure);
      throw failure;
    }
  }

  /** 保存派对邀请到数据库 */
  public synchronized void savePartyInviteToDatabase(UUID inviterId, UUID targetId) {
    requireWritable();
    if (sqlStorage != null) {
      Long timestamp = partyInviteTimestamps.getOrDefault(targetId, Map.of()).get(inviterId);
      if (timestamp == null) throw new IllegalStateException("邀请缺少原始时间");
      sqlStorage.savePartyInvite(inviterId, targetId, timestamp);
    }
  }

  /** 从数据库删除派对邀请 */
  public synchronized void deletePartyInviteFromDatabase(UUID inviterId, UUID targetId) {
    requireWritable();
    if (sqlStorage != null) {
      sqlStorage.deletePartyInvite(inviterId, targetId);
    }
  }

  /** 加载派对数据（YAML） */
  private Map<UUID, Party> loadPartiesYaml() throws Exception {
    Map<UUID, Party> loaded = new HashMap<>();
    if (partiesFile == null || !partiesFile.exists()) return loaded;
    YamlConfiguration yml = new YamlConfiguration();
    yml.load(partiesFile);
    for (String key : yml.getKeys(false)) {
      UUID partyId = UUID.fromString(key);
      Object dataObj = yml.get(key);
      PartyData data = dataObj instanceof PartyData legacy ? legacy : null;
      if (dataObj instanceof org.bukkit.configuration.ConfigurationSection section) {
        data = new PartyData();
        data.setId(partyId);
        data.setLeader(UUID.fromString(section.getString("leader", "")));
        if (!(section.get("members") instanceof List<?> memberValues)
            || memberValues.stream().anyMatch(member -> !(member instanceof String))) {
          throw new IllegalStateException("无效派对成员列表");
        }
        data.setMembers(memberValues.stream().map(String.class::cast).toList());
        data.setCreatedTime(section.getLong("createdTime"));
        data.setFriendlyFire(section.getBoolean("friendlyFire"));
        data.setExpShare(section.getBoolean("expShare", true));
        data.setMaxMembers(section.getInt("maxMembers", 8));
      }
      if (data == null || data.getId() == null) throw new IllegalStateException("无效派对数据");
      Party party = data.toParty();
      if (party == null || !partyId.equals(party.getId())) {
        throw new IllegalStateException("派对编号不匹配");
      }
      loaded.put(partyId, party);
    }
    return loaded;
  }

  /** 保存派对数据（YAML） */
  private void savePartiesYaml() {
    savePartiesYaml(parties.values());
  }

  private void savePartiesYaml(Collection<Party> snapshot) {
    if (partiesFile == null) return;
    try {
      YamlConfiguration yml = new YamlConfiguration();
      for (Party party : snapshot) {
        PartyData data = PartyData.fromParty(party);
        var section = yml.createSection(party.getId().toString());
        section.set("leader", data.getLeader().toString());
        section.set("members", data.getMembers());
        section.set("createdTime", data.getCreatedTime());
        section.set("friendlyFire", data.isFriendlyFire());
        section.set("expShare", data.isExpShare());
        section.set("maxMembers", data.getMaxMembers());
      }
      saveYamlAtomically(yml, partiesFile);
    } catch (IOException ex) {
      throw new IllegalStateException("保存派对数据失败", ex);
    }
  }

  /** 加载派对邀请数据（YAML） */
  private void loadInvitesYaml(Map<UUID, Set<UUID>> loaded, Map<UUID, Map<UUID, Long>> timestamps)
      throws Exception {
    if (invitesFile == null || !invitesFile.exists()) return;
    YamlConfiguration yml = new YamlConfiguration();
    yml.load(invitesFile);
    for (String key : yml.getKeys(false)) {
      UUID targetId = UUID.fromString(key);
      var section = yml.getConfigurationSection(key);
      if (section == null) {
        if (yml.isList(key)) continue;
        throw new IllegalStateException("无效派对邀请数据");
      }
      for (String inviterStr : section.getKeys(false)) {
        UUID inviter = UUID.fromString(inviterStr);
        if (!(section.get(inviterStr) instanceof Number)) {
          throw new IllegalStateException("无效邀请时间");
        }
        loaded.computeIfAbsent(targetId, ignored -> new HashSet<>()).add(inviter);
        timestamps
            .computeIfAbsent(targetId, ignored -> new HashMap<>())
            .put(inviter, section.getLong(inviterStr));
      }
    }
  }

  /** 保存派对邀请数据（YAML） */
  private void saveInvitesYaml() {
    if (invitesFile == null) return;
    try {
      YamlConfiguration yml = new YamlConfiguration();
      for (Map.Entry<UUID, Set<UUID>> entry : partyInvites.entrySet()) {
        for (UUID inviterId : entry.getValue()) {
          Long timestamp =
              partyInviteTimestamps.getOrDefault(entry.getKey(), Map.of()).get(inviterId);
          if (timestamp != null) yml.set(entry.getKey() + "." + inviterId, timestamp);
        }
      }
      saveYamlAtomically(yml, invitesFile);
    } catch (IOException ex) {
      throw new IllegalStateException("保存派对邀请数据失败", ex);
    }
  }

  private void saveYamlAtomically(YamlConfiguration yml, File destination) throws IOException {
    var temporary = Files.createTempFile(destination.toPath().getParent(), "party-", ".tmp");
    boolean moveAttempted = false;
    try {
      yml.save(temporary.toFile());
      moveAttempted = true;
      try {
        Files.move(
            temporary,
            destination.toPath(),
            StandardCopyOption.ATOMIC_MOVE,
            StandardCopyOption.REPLACE_EXISTING);
      } catch (java.nio.file.AtomicMoveNotSupportedException unavailable) {
        Files.move(temporary, destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
      }
    } catch (IOException | RuntimeException failure) {
      if (moveAttempted) persistenceBlocked = true;
      throw failure;
    } finally {
      try {
        Files.deleteIfExists(temporary);
      } catch (IOException cleanupFailure) {
        if (plugin != null)
          plugin.getLogger().warning("清理派对临时文件失败: " + cleanupFailure.getMessage());
      }
    }
  }

  private void requireWritable() {
    if (persistenceBlocked) throw new IllegalStateException("派对数据加载失败，请恢复存储后重新加载");
  }

  private void isolateUnknownWrite(RuntimeException failure) {
    if (failure
            instanceof
            dev.starcore.starcore.social.SqlSocialStateStorage.PartyPersistenceException sqlFailure
        && sqlFailure.isOutcomeUnknown()) {
      persistenceBlocked = true;
    }
  }

  private boolean validInviteTime(Long timestamp) {
    long now = clock.millis();
    return timestamp != null
        && timestamp > 0
        && timestamp <= now
        && now - timestamp < PARTY_INVITE_TTL_MS;
  }

  private void restoreState(
      Map<UUID, Party> loaded,
      Map<UUID, Set<UUID>> loadedInvites,
      Map<UUID, Map<UUID, Long>> timestamps) {
    Map<UUID, UUID> memberships = new HashMap<>();
    for (Map.Entry<UUID, Party> entry : loaded.entrySet()) {
      Party party = entry.getValue();
      if (party == null || !entry.getKey().equals(party.getId())) {
        throw new IllegalStateException("派对编号不匹配");
      }
      if (!party.isMember(party.getLeader())) throw new IllegalStateException("派对队长不在成员中");
      for (UUID member : party.getMembers()) {
        if (memberships.putIfAbsent(member, party.getId()) != null)
          throw new IllegalStateException("玩家同时属于多个派对");
      }
    }
    Map<UUID, Set<UUID>> restoredInvites = new HashMap<>();
    Map<UUID, Map<UUID, Long>> restoredTimes = new HashMap<>();
    Map<UUID, Long> restoredCooldowns = new HashMap<>();
    loadedInvites.forEach(
        (target, inviters) ->
            inviters.forEach(
                inviter -> {
                  Long timestamp = timestamps.getOrDefault(target, Map.of()).get(inviter);
                  if (validInviteTime(timestamp) && !memberships.containsKey(target)) {
                    restoredInvites
                        .computeIfAbsent(target, ignored -> ConcurrentHashMap.newKeySet())
                        .add(inviter);
                    restoredTimes
                        .computeIfAbsent(target, ignored -> new ConcurrentHashMap<>())
                        .put(inviter, timestamp);
                    restoredCooldowns.merge(target, timestamp, Math::max);
                  }
                }));
    parties.clear();
    parties.putAll(loaded);
    playerParties.clear();
    playerParties.putAll(memberships);
    partyInvites.clear();
    partyInvites.putAll(restoredInvites);
    partyInviteTimestamps.clear();
    partyInviteTimestamps.putAll(restoredTimes);
    lastInviteTime.clear();
    lastInviteTime.putAll(restoredCooldowns);
  }

  /** 派对数据序列化类 */
  public static class PartyData {
    private UUID id;
    private UUID leader;
    private List<String> members;
    private long createdTime;
    private boolean friendlyFire;
    private boolean expShare;
    private int maxMembers;

    public PartyData() {}

    public static PartyData fromParty(Party party) {
      PartyData data = new PartyData();
      data.id = party.getId();
      data.leader = party.getLeader();
      data.members = new ArrayList<>();
      for (UUID member : party.getMembers()) {
        data.members.add(member.toString());
      }
      data.createdTime = party.getCreatedTime();
      data.friendlyFire = party.isFriendlyFire();
      data.expShare = party.isExpShare();
      data.maxMembers = party.getMaxMembers();
      return data;
    }

    public Party toParty() {
      if (id == null || leader == null || members == null) {
        return null;
      }
      Party party = new Party(id, leader, createdTime);
      party.setMaxMembers(Math.max(maxMembers, members.size() + 1));
      // 清空默认添加的队长
      party.removeMember(leader);
      // 重新添加所有成员
      for (String memberStr : members) {
        party.addMember(UUID.fromString(memberStr));
      }
      // 如果成员为空，说明是旧数据，需要重新添加队长
      if (party.getMembers().isEmpty()) {
        party.addMember(leader);
      }
      party.setFriendlyFire(friendlyFire);
      party.setExpShare(expShare);
      party.setMaxMembers(maxMembers);
      return party;
    }

    // Getters and Setters
    public UUID getId() {
      return id;
    }

    public void setId(UUID id) {
      this.id = id;
    }

    public UUID getLeader() {
      return leader;
    }

    public void setLeader(UUID leader) {
      this.leader = leader;
    }

    public List<String> getMembers() {
      return members;
    }

    public void setMembers(List<String> members) {
      this.members = members;
    }

    public long getCreatedTime() {
      return createdTime;
    }

    public void setCreatedTime(long createdTime) {
      this.createdTime = createdTime;
    }

    public boolean isFriendlyFire() {
      return friendlyFire;
    }

    public void setFriendlyFire(boolean friendlyFire) {
      this.friendlyFire = friendlyFire;
    }

    public boolean isExpShare() {
      return expShare;
    }

    public void setExpShare(boolean expShare) {
      this.expShare = expShare;
    }

    public int getMaxMembers() {
      return maxMembers;
    }

    public void setMaxMembers(int maxMembers) {
      this.maxMembers = maxMembers;
    }
  }

  /** 创建派对 */
  public synchronized Party createParty(UUID leaderId) {
    requireWritable();
    // 检查是否已在派对中
    if (playerParties.containsKey(leaderId)) {
      throw new IllegalStateException("你已经在一个派对中");
    }

    // 创建派对
    UUID partyId = UUID.randomUUID();
    Party party = new Party(partyId, leaderId);

    parties.put(partyId, party);
    playerParties.put(leaderId, partyId);

    try {
      savePartyToDatabase(party);
    } catch (RuntimeException failure) {
      parties.remove(partyId);
      playerParties.remove(leaderId, partyId);
      throw failure;
    }

    return party;
  }

  /** 解散派对 */
  public synchronized boolean disbandParty(UUID partyId, UUID leaderId) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    // 只有队长可以解散
    if (!party.isLeader(leaderId)) {
      throw new IllegalStateException("只有队长可以解散派对");
    }

    // 收集成员，解散时清除这些成员发送的派对邀请
    Set<UUID> members = party.getMembers();
    for (UUID memberId : members) removePlayerInvites(memberId);
    deletePartyFromDatabase(partyId);
    // 移除所有成员
    for (UUID memberId : members) {
      playerParties.remove(memberId, partyId);
    }

    // 清理已解散派对的邀请：删除所有由本派对成员发出的 pending 邀请
    parties.remove(partyId);

    return true;
  }

  /** 邀请玩家 */
  public synchronized boolean inviteMember(UUID partyId, UUID inviterId, UUID targetId) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    // 检查权限（只有队长可以邀请）
    if (!party.isLeader(inviterId)) {
      throw new IllegalStateException("只有队长可以邀请玩家");
    }

    // 检查派对是否已满
    if (party.isFull()) {
      throw new IllegalStateException("派对已满");
    }

    // 检查目标是否已在派对中
    if (playerParties.containsKey(targetId)) {
      throw new IllegalStateException("该玩家已在其他派对中");
    }

    // 重复邀请检测：若已存在该玩家对该 inviter 的邀请（且未过期），拒绝再次发出
    long now = clock.millis();
    Set<UUID> invites = partyInvites.get(targetId);
    Map<UUID, Long> stamps = partyInviteTimestamps.get(targetId);
    boolean priorInvite = invites != null && invites.contains(inviterId);
    Long priorTimestamp = stamps == null ? null : stamps.get(inviterId);
    if (invites != null && invites.contains(inviterId)) {
      Long ts = stamps == null ? null : stamps.get(inviterId);
      if (validInviteTime(ts)) {
        throw new IllegalStateException("已向该玩家发送过邀请，请等待 30 秒");
      }
    }

    // 30 秒冷却，防止对同玩家刷屏
    Long last = lastInviteTime.get(targetId);
    if (last != null && (now - last) < PARTY_INVITE_COOLDOWN_MS) {
      throw new IllegalStateException("邀请冷却中，请稍候再试");
    }

    // 添加邀请
    partyInvites.computeIfAbsent(targetId, k -> ConcurrentHashMap.newKeySet()).add(inviterId);
    partyInviteTimestamps
        .computeIfAbsent(targetId, k -> new ConcurrentHashMap<>())
        .put(inviterId, now);
    lastInviteTime.put(targetId, now);

    try {
      if (sqlStorage != null) savePartyInviteToDatabase(inviterId, targetId);
      else saveInvitesYaml();
    } catch (RuntimeException failure) {
      if (!priorInvite) partyInvites.get(targetId).remove(inviterId);
      if (priorTimestamp == null) partyInviteTimestamps.get(targetId).remove(inviterId);
      else partyInviteTimestamps.get(targetId).put(inviterId, priorTimestamp);
      if (last == null) lastInviteTime.remove(targetId);
      else lastInviteTime.put(targetId, last);
      throw failure;
    }

    return true;
  }

  /** 接受邀请 */
  public boolean acceptInvite(UUID playerId, UUID inviterId) {
    // 同步块防止并发 accept 满员派对造成超员
    synchronized (this) {
      requireWritable();
      if (playerParties.containsKey(playerId)) {
        throw new IllegalStateException("你已经在一个派对中");
      }
      // 检查邀请是否存在
      Set<UUID> invites = partyInvites.get(playerId);
      if (invites == null || !invites.contains(inviterId)) {
        throw new IllegalStateException("邀请不存在");
      }

      // 校验邀请是否过期
      Map<UUID, Long> stamps = partyInviteTimestamps.get(playerId);
      Long ts = stamps == null ? null : stamps.get(inviterId);
      if (!validInviteTime(ts)) {
        // 过期邀请，直接清理
        removeInvite(playerId, inviterId);
        throw new IllegalStateException("邀请已过期");
      }

      // 获取邀请者的派对
      UUID partyId = playerParties.get(inviterId);
      if (partyId == null) {
        // 邀请者已离开/解散派对，清理邀请
        removeInvite(playerId, inviterId);
        throw new IllegalStateException("派对不存在");
      }

      Party party = parties.get(partyId);
      if (party == null || !party.isLeader(inviterId)) {
        removeInvite(playerId, inviterId);
        throw new IllegalStateException("派对不存在");
      }

      // 检查是否已满（移除 invites 之前再次校验，避免并发超员）
      if (party.isFull()) {
        throw new IllegalStateException("派对已满");
      }

      // 加入派对
      if (!party.addMember(playerId)) throw new IllegalStateException("无法加入派对");
      playerParties.put(playerId, partyId);
      try {
        if (sqlStorage != null) sqlStorage.acceptPartyInvite(party, inviterId, playerId);
        else savePartiesYaml();
      } catch (RuntimeException failure) {
        isolateUnknownWrite(failure);
        party.removeMember(playerId);
        playerParties.remove(playerId, partyId);
        throw failure;
      }
      if (sqlStorage != null) {
        removeInviteFromMemory(playerId, inviterId);
      } else {
        try {
          removeInvite(playerId, inviterId);
        } catch (RuntimeException failure) {
          if (plugin != null)
            plugin.getLogger().warning("派对成员已保存，邀请清理将重试: " + failure.getMessage());
        }
      }

      return true;
    }
  }

  /** 拒绝邀请 */
  public synchronized boolean rejectInvite(UUID playerId, UUID inviterId) {
    requireWritable();
    return removeInvite(playerId, inviterId);
  }

  private boolean removeInvite(UUID targetId, UUID inviterId) {
    requireWritable();
    Set<UUID> invites = partyInvites.get(targetId);
    if (invites == null || !invites.contains(inviterId)) return false;
    if (sqlStorage != null) deletePartyInviteFromDatabase(inviterId, targetId);
    Map<UUID, Long> timestamps = partyInviteTimestamps.get(targetId);
    Long timestamp = timestamps == null ? null : timestamps.remove(inviterId);
    invites.remove(inviterId);
    try {
      if (sqlStorage == null) saveInvitesYaml();
    } catch (RuntimeException failure) {
      invites.add(inviterId);
      if (timestamp != null)
        partyInviteTimestamps
            .computeIfAbsent(targetId, ignored -> new ConcurrentHashMap<>())
            .put(inviterId, timestamp);
      throw failure;
    }
    removeInviteFromMemory(targetId, inviterId);
    return true;
  }

  private void removeInviteFromMemory(UUID targetId, UUID inviterId) {
    Set<UUID> invites = partyInvites.get(targetId);
    Map<UUID, Long> timestamps = partyInviteTimestamps.get(targetId);
    if (invites != null) {
      invites.remove(inviterId);
      if (invites.isEmpty()) partyInvites.remove(targetId);
    }
    if (timestamps != null) {
      timestamps.remove(inviterId);
      if (timestamps.isEmpty()) partyInviteTimestamps.remove(targetId);
    }
  }

  private void removePlayerInvites(UUID playerId) {
    Set<UUID> incoming = Set.copyOf(partyInvites.getOrDefault(playerId, Set.of()));
    for (UUID inviter : incoming) removeInvite(playerId, inviter);
    for (UUID target : Set.copyOf(partyInvites.keySet())) removeInvite(target, playerId);
  }

  /** 踢出成员 */
  public synchronized boolean kickMember(UUID partyId, UUID kickerId, UUID targetId) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    // 只有队长可以踢人
    if (!party.isLeader(kickerId)) {
      throw new IllegalStateException("只有队长可以踢出成员");
    }

    // 不能踢出队长自己
    if (party.isLeader(targetId)) {
      throw new IllegalStateException("不能踢出队长");
    }

    // 不能踢自己（用 leave）
    if (kickerId.equals(targetId)) {
      throw new IllegalStateException("不能踢出自己，请使用离开命令");
    }

    if (!party.isMember(targetId)) return false;
    removePlayerInvites(targetId);
    Party replacement = PartyData.fromParty(party).toParty();
    replacement.removeMember(targetId);
    savePartyToDatabase(replacement);
    party.removeMember(targetId);
    playerParties.remove(targetId, partyId);
    return true;
  }

  /** 离开派对 */
  public synchronized boolean leaveParty(UUID playerId) {
    requireWritable();
    UUID partyId = playerParties.get(playerId);
    if (partyId == null) return false;

    Party party = parties.get(partyId);
    if (party == null) return false;
    removePlayerInvites(playerId);

    // 如果是队长，转让或解散
    if (party.isLeader(playerId)) {
      if (party.getMemberCount() > 1) {
        // 优先转让给在线且最近活跃的成员
        UUID newLeader =
            party.getMembers().stream()
                .filter(id -> !id.equals(playerId))
                .min(Comparator.comparingLong(id -> -lastOnlineTime(id)))
                .orElse(null);

        if (newLeader != null) {
          Party replacement = PartyData.fromParty(party).toParty();
          replacement.transferLeadership(newLeader);
          replacement.removeMember(playerId);
          savePartyToDatabase(replacement);
          party.transferLeadership(newLeader);
          party.removeMember(playerId);
        } else {
          deletePartyFromDatabase(partyId);
          parties.remove(partyId);
        }
      } else {
        // 解散派对
        deletePartyFromDatabase(partyId);
        parties.remove(partyId);
      }
    } else {
      Party replacement = PartyData.fromParty(party).toParty();
      replacement.removeMember(playerId);
      savePartyToDatabase(replacement);
      party.removeMember(playerId);
    }

    playerParties.remove(playerId, partyId);
    return true;
  }

  /** 获取玩家最近在线时间（在线=now，离线使用 Bukkit 离线记录）；最后在线越晚越优先 */
  private long lastOnlineTime(UUID id) {
    if (org.bukkit.Bukkit.getPlayer(id) != null) return System.currentTimeMillis();
    return org.bukkit.Bukkit.getOfflinePlayer(id).getLastPlayed();
  }

  /** 转让队长 */
  public synchronized boolean transferLeadership(UUID partyId, UUID currentLeader, UUID newLeader) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    // 只有队长可以转让
    if (!party.isLeader(currentLeader)) {
      throw new IllegalStateException("只有队长可以转让职位");
    }

    // 新队长必须是成员
    if (!party.isMember(newLeader)) {
      throw new IllegalStateException("新队长必须是派对成员");
    }

    for (UUID target : Set.copyOf(partyInvites.keySet())) removeInvite(target, currentLeader);
    Party replacement = PartyData.fromParty(party).toParty();
    replacement.transferLeadership(newLeader);
    savePartyToDatabase(replacement);
    party.transferLeadership(newLeader);
    return true;
  }

  /** 获取玩家派对 */
  public synchronized Party getPlayerParty(UUID playerId) {
    UUID partyId = playerParties.get(playerId);
    return partyId != null ? parties.get(partyId) : null;
  }

  /** 检查是否在同一派对 */
  public synchronized boolean areInSameParty(UUID player1, UUID player2) {
    UUID party1 = playerParties.get(player1);
    UUID party2 = playerParties.get(player2);
    return party1 != null && party1.equals(party2);
  }

  /** 获取派对邀请列表 */
  public synchronized Set<UUID> getPartyInvites(UUID playerId) {
    Set<UUID> invites = partyInvites.get(playerId);
    for (UUID inviter : Set.copyOf(invites == null ? Set.of() : invites)) {
      if (!persistenceBlocked
          && !validInviteTime(partyInviteTimestamps.getOrDefault(playerId, Map.of()).get(inviter)))
        removeInvite(playerId, inviter);
    }
    return invites != null ? Set.copyOf(invites) : Set.of();
  }

  /** 设置友军伤害 */
  public synchronized boolean setFriendlyFire(UUID partyId, UUID playerId, boolean enabled) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    if (!party.isLeader(playerId)) {
      throw new IllegalStateException("只有队长可以修改设置");
    }

    party.setFriendlyFire(enabled);
    return true;
  }

  /** 设置经验共享 */
  public synchronized boolean setExpShare(UUID partyId, UUID playerId, boolean enabled) {
    requireWritable();
    Party party = parties.get(partyId);
    if (party == null) return false;

    if (!party.isLeader(playerId)) {
      throw new IllegalStateException("只有队长可以修改设置");
    }

    party.setExpShare(enabled);
    return true;
  }

  /** 获取所有派对 */
  public synchronized Collection<Party> getAllParties() {
    return List.copyOf(parties.values());
  }
}
