package dev.starcore.starcore.social.gui;

import dev.starcore.starcore.foundation.gui.BookInputSupport;
import dev.starcore.starcore.social.simulation.SocialActivityService;
import dev.starcore.starcore.social.simulation.SocialActivityService.*;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

/** 活动推荐 GUI 监听器 */
public final class ActivityRecommendationListener implements Listener {
  private final SocialActivityService activityService;
  private Consumer<Player> socialMenuOpener;
  private final Map<UUID, SocialActivityType> pendingCreateTypes = new ConcurrentHashMap<>();

  // 跟踪打开的活动推荐菜单
  private final WeakHashMap<Player, ActivityRecommendationGui> openMenus = new WeakHashMap<>();

  public ActivityRecommendationListener(SocialActivityService activityService) {
    this.activityService = activityService;
  }

  @EventHandler(priority = EventPriority.NORMAL)
  public void onInventoryDrag(@NotNull InventoryDragEvent event) {
    if (event.getView().getTopInventory().getHolder() instanceof ActivityRecommendationGui) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.NORMAL)
  public void onInventoryClick(@NotNull InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    Inventory topInventory = event.getView().getTopInventory();
    if (!(topInventory.getHolder() instanceof ActivityRecommendationGui activityGui)) {
      return;
    }

    // 阻止玩家移动物品
    event.setCancelled(true);

    int slot = event.getRawSlot();
    if (event.getClickedInventory() != topInventory
        || slot < 0
        || slot >= topInventory.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)) {
      return;
    }

    if (activityGui.isShowingTypeDetails()) {
      if (slot == 53) {
        activityGui.closeTypeDetails();
        return;
      }
      if (activityGui.isShowingCreateGuide()) {
        SocialActivityType type = activityGui.getCreatableTypeFromSlot(slot);
        if (type != null) {
          pendingCreateTypes.put(player.getUniqueId(), type);
          BookInputSupport.prepare(player, "Activity details", "");
        }
        return;
      }
      SocialActivity activity = activityGui.getTypeActivityFromSlot(slot);
      if (activity != null) {
        joinActivity(player, activity);
      }
      return;
    }
    ActivityRecommendationGui.ActivityAction action =
        ActivityRecommendationGui.getActionFromSlot(slot);

    handleAction(player, action, activityGui);
  }

  @EventHandler
  public void onActivityCreateBookEdit(@NotNull PlayerEditBookEvent event) {
    Player player = event.getPlayer();
    SocialActivityType type = pendingCreateTypes.remove(player.getUniqueId());
    if (type == null) return;

    event.setCancelled(true);
    BookInputSupport.restore(player);
    String content = String.join("\n", event.getNewBookMeta().getPages()).strip();
    String[] fields = content.split("\\R", 2);
    String name = fields[0].strip();
    String description = fields.length > 1 ? fields[1].strip() : "";
    if (name.isBlank() || name.length() > 48 || description.length() > 240) {
      player.sendMessage(
          Component.text(
              "Activity name must be 1-48 characters; description is limited to 240.",
              NamedTextColor.RED));
      openMenu(player);
      return;
    }

    UUID host = player.getUniqueId();
    CompletableFuture<String> creation;
    try {
      creation =
          switch (type) {
            case PARTY -> activityService.createPartyAsync(host, name, description);
            case CELEBRATION -> activityService.createCelebrationAsync(host, name, description, 4);
            case COMPETITION ->
                activityService.createCompetitionAsync(
                    host, name, description, SocialActivityService.CompetitionType.DUEL);
            default ->
                throw new IllegalArgumentException("Unsupported activity creation type: " + type);
          };
    } catch (RuntimeException failure) {
      org.bukkit.Bukkit.getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Failed to create social activity type " + type,
              failure);
      player.sendMessage(
          Component.text("Activity creation failed. Please try again.", NamedTextColor.RED));
      openMenu(player);
      return;
    }

    creation.whenComplete(
        (activityId, failure) -> {
          if (!org.bukkit.Bukkit.isPrimaryThread() || !player.isOnline()) return;
          if (failure != null) {
            org.bukkit.Bukkit.getLogger()
                .log(
                    java.util.logging.Level.SEVERE,
                    "Failed to create social activity type " + type,
                    failure);
            player.sendMessage(
                Component.text("Activity creation failed. Please try again.", NamedTextColor.RED));
            openMenu(player);
            return;
          }

          player.sendMessage(Component.text("Activity created: " + name, NamedTextColor.GREEN));
          openMenu(player);
          ActivityRecommendationGui menu = openMenus.get(player);
          if (menu != null) {
            activityService
                .getActivity(activityId)
                .ifPresent(
                    created ->
                        menu.showActivityList(
                            "Activity created", java.util.List.of(created), false));
          }
        });
  }

  @EventHandler
  public void onActivityCreateQuit(@NotNull PlayerQuitEvent event) {
    pendingCreateTypes.remove(event.getPlayer().getUniqueId());
    BookInputSupport.clear(event.getPlayer());
  }

  @EventHandler
  public void onInventoryClose(@NotNull InventoryCloseEvent event) {
    if (event.getPlayer() instanceof Player player) {
      openMenus.remove(player);
    }
  }

  private void handleAction(
      Player player,
      ActivityRecommendationGui.ActivityAction action,
      ActivityRecommendationGui gui) {
    if (action == ActivityRecommendationGui.ActivityAction.PARTY
        || action == ActivityRecommendationGui.ActivityAction.CELEBRATION
        || action == ActivityRecommendationGui.ActivityAction.COMPETITION
        || action == ActivityRecommendationGui.ActivityAction.GATHERING
        || action == ActivityRecommendationGui.ActivityAction.SOCIAL_MISSION
        || action == ActivityRecommendationGui.ActivityAction.NETWORKING) {
      gui.showTypeDetails(SocialActivityType.valueOf(action.name()));
      return;
    }
    switch (action) {
      case PARTY, CELEBRATION, COMPETITION, GATHERING, SOCIAL_MISSION, NETWORKING -> {
        return;
      }
      case MY_ACTIVITIES -> {
        java.util.List<SocialActivity> activities =
            activityService.getPlayerActivities(player.getUniqueId()).stream()
                .map(activityService::getActivity)
                .filter(java.util.Optional::isPresent)
                .map(java.util.Optional::get)
                .toList();
        gui.showActivityList("My activities", activities, false);
      }
      case HOT_ACTIVITIES -> {
        java.util.List<SocialActivity> activities =
            activityService.getPublicActivities().stream()
                .sorted(
                    java.util.Comparator.comparingInt(SocialActivity::participantCount).reversed())
                .toList();
        gui.showActivityList("Popular activities", activities, true);
      }
      case JOIN_ACTIVITY -> {
        // JOIN_ACTIVITY 槽位是 28-33，获取第一个活动的详细信息
        SocialActivity firstActivity = gui.getActivityFromSlot(28);
        if (firstActivity != null) {
          joinActivity(player, firstActivity);
        } else {
          player.sendMessage(Component.text("当前没有可加入的活动", NamedTextColor.GRAY));
        }
      }
      case STATS -> {
        gui.showStatsPage(
            activityService.getPublicActivities().size(),
            activityService.getPlayerActivities(player.getUniqueId()).size());
      }
      case CREATE -> {
        gui.showCreateGuidePage();
      }
      case BACK -> {
        Consumer<Player> parentOpener = socialMenuOpener;
        if (parentOpener == null) {
          player.closeInventory();
        } else {
          parentOpener.accept(player);
        }
      }
      case NONE -> {
        // 不做任何操作
      }
    }
  }

  private void joinActivity(Player player, SocialActivity activity) {
    activityService
        .joinActivityAsync(player.getUniqueId(), activity.id())
        .whenComplete(
            (joined, failure) -> {
              if (!org.bukkit.Bukkit.isPrimaryThread() || !player.isOnline()) return;
              if (failure == null && Boolean.TRUE.equals(joined)) {
                player.sendMessage(
                    Component.text("成功加入活动: " + activity.name(), NamedTextColor.GREEN));
                player.sendMessage(
                    Component.text(
                        "活动类型: " + activity.type().getName() + " " + activity.type().emoji(),
                        NamedTextColor.GRAY));
                return;
              }

              if (failure != null) {
                org.bukkit.Bukkit.getLogger()
                    .log(
                        java.util.logging.Level.SEVERE,
                        "Failed to join social activity " + activity.id(),
                        failure);
              }
              player.sendMessage(Component.text("加入活动失败！", NamedTextColor.RED));
              if (activity.participantCount() >= activity.maxParticipants()) {
                player.sendMessage(Component.text("活动已满员", NamedTextColor.GRAY));
              } else if (activity.status() == ActivityStatus.ENDED) {
                player.sendMessage(Component.text("活动已结束", NamedTextColor.GRAY));
              }
            });
  }

  /** 打开活动推荐菜单 */
  public void openMenu(Player player) {
    ActivityRecommendationGui menu = new ActivityRecommendationGui(player, activityService);
    openMenus.put(player, menu);
    player.openInventory(menu.getInventory());
  }

  public void setSocialMenuOpener(Consumer<Player> socialMenuOpener) {
    this.socialMenuOpener = socialMenuOpener;
  }
}
