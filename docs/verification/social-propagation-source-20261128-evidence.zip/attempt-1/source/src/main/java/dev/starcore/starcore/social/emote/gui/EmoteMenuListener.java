package dev.starcore.starcore.social.emote.gui;

import dev.starcore.starcore.foundation.gui.StarCoreMenuHolder;
import dev.starcore.starcore.social.emote.EmoteService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

/** 动作菜单点击监听器 */
public class EmoteMenuListener implements Listener {
  private final EmoteMenu emoteMenu;
  private final EmoteService emoteService;

  public EmoteMenuListener(EmoteMenu emoteMenu, EmoteService emoteService) {
    this.emoteMenu = emoteMenu;
    this.emoteService = emoteService;
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getView().getTopInventory().getHolder() instanceof StarCoreMenuHolder
        && event.getView().getTitle().contains("动作")) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    Inventory top = event.getView().getTopInventory();
    if (!(top.getHolder() instanceof StarCoreMenuHolder)
        || !event.getView().getTitle().contains("动作")) {
      return;
    }

    event.setCancelled(true);

    int slot = event.getRawSlot();
    if (event.getClickedInventory() != top
        || slot < 0
        || slot >= top.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)
        || event.getCurrentItem() == null) {
      return;
    }

    emoteMenu.handleClick(player, slot, event.getCurrentItem());
  }
}
