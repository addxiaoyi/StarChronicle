package dev.starcore.starcore.social.simulation;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * 新闻传播服务
 *
 * <p>管理信息在社会中的传播: - 新闻创建 - 传播算法 (基于社交网络) - 真实性与偏见 - 新闻衰减
 */
public class NewsPropagationService {

  private final JavaPlugin plugin;
  private final RelationshipNetwork relationshipNetwork;
  private final Map<String, NewsItem> news = new ConcurrentHashMap<>();
  private final Map<UUID, Set<String>> playerNewsSeen = new ConcurrentHashMap<>();

  // 评论系统
  private final Map<String, List<NewsComment>> newsComments = new ConcurrentHashMap<>();

  // 新闻分享记录
  private final Map<String, NewsShare> newsShares = new ConcurrentHashMap<>();

  private final Object stateLock = new Object();
  private ScheduledTask spreadTask;
  private SocialPlayerMessages messages;
  private boolean running;
  private boolean closed;
  private long generation;

  public NewsPropagationService(JavaPlugin plugin, RelationshipNetwork relationshipNetwork) {
    this.plugin = Objects.requireNonNull(plugin, "plugin");
    this.relationshipNetwork = Objects.requireNonNull(relationshipNetwork, "relationshipNetwork");
    this.messages = new SocialPlayerMessages(plugin);
  }

  public void start() {
    long epoch;
    synchronized (stateLock) {
      if (running) return;
      running = true;
      if (closed) messages = new SocialPlayerMessages(plugin);
      closed = false;
      epoch = ++generation;
    }
    ScheduledTask task;
    try {
      task =
          plugin
              .getServer()
              .getAsyncScheduler()
              .runAtFixedRate(
                  plugin,
                  ignored -> processNewsSpread(epoch),
                  300000L,
                  300000L,
                  TimeUnit.MILLISECONDS);
      if (task == null) throw new IllegalStateException("News timer rejected");
    } catch (RuntimeException | Error error) {
      SocialPlayerMessages retiring = null;
      synchronized (stateLock) {
        if (generation == epoch) {
          running = false;
          closed = true;
          generation++;
          retiring = messages;
        }
      }
      if (retiring != null) retiring.close();
      throw error;
    }
    boolean stale;
    synchronized (stateLock) {
      stale = !running || generation != epoch;
      if (!stale) spreadTask = task;
    }
    if (stale) task.cancel();
  }

  public void stop() {
    ScheduledTask task;
    SocialPlayerMessages retiring;
    synchronized (stateLock) {
      running = false;
      closed = true;
      generation++;
      task = spreadTask;
      spreadTask = null;
      retiring = messages;
    }
    try {
      if (task != null) task.cancel();
    } finally {
      retiring.close();
    }
  }

  private void requireOpen() {
    if (closed) throw new IllegalStateException("News service stopped");
  }

  /** 发布新闻 */
  public String publishNews(String headline, String content, UUID source, NewsCategory category) {
    List<Delivery> deliveries = new ArrayList<>();
    String id = UUID.randomUUID().toString();
    synchronized (stateLock) {
      requireOpen();
      NewsItem item =
          new NewsItem(
              id,
              headline,
              content,
              source,
              category,
              System.currentTimeMillis(),
              1.0,
              source == null ? Set.of() : Set.of(source));
      news.put(id, item);
      if (source != null) {
        playerNewsSeen.computeIfAbsent(source, ignored -> new HashSet<>()).add(id);
        for (UUID target : relationshipNetwork.getSocialCircle(source, 20)) {
          Delivery delivery = deliverNews(target, id);
          if (delivery != null) deliveries.add(delivery);
        }
      }
    }
    deliveries.forEach(this::notifyDelivery);
    return id;
  }

  /** 获取玩家未读新闻 */
  public List<NewsItem> getUnreadNews(UUID playerId) {
    synchronized (stateLock) {
      Set<String> seen = playerNewsSeen.getOrDefault(playerId, Set.of());
      return news.values().stream()
          .filter(n -> !seen.contains(n.id()))
          .filter(n -> n.reach().contains(playerId)) // 只显示已经传播到玩家的新闻
          .sorted(Comparator.comparing(NewsItem::timestamp).reversed())
          .limit(10)
          .toList();
    }
  }

  /** 标记新闻已读 */
  public void markAsRead(UUID playerId, String newsId) {
    synchronized (stateLock) {
      requireOpen();
      playerNewsSeen.computeIfAbsent(playerId, k -> new HashSet<>()).add(newsId);
    }
  }

  // ==================== 评论功能 ====================

  /** 添加评论 */
  public NewsComment addComment(String newsId, UUID commenter, String content) {
    synchronized (stateLock) {
      requireOpen();
      if (!news.containsKey(newsId)) {
        return null;
      }

      String commentId = UUID.randomUUID().toString();
      NewsComment comment =
          new NewsComment(
              commentId, newsId, commenter, content, System.currentTimeMillis(), new HashSet<>());

      newsComments.computeIfAbsent(newsId, k -> new ArrayList<>()).add(comment);
      return comment;
    }
  }

  /**
   * 获取新闻的所有评论
   *
   * @param newsId 新闻ID
   * @param sortOrder 排序方式 (NEWEST, HOTTEST)
   */
  public List<NewsComment> getComments(String newsId, CommentSortOrder sortOrder) {
    synchronized (stateLock) {
      List<NewsComment> comments = newsComments.getOrDefault(newsId, new ArrayList<>());

      return switch (sortOrder) {
        case NEWEST ->
            comments.stream()
                .sorted(Comparator.comparingLong(NewsComment::timestamp).reversed())
                .collect(Collectors.toList());
        case HOTTEST ->
            comments.stream()
                .sorted(
                    Comparator.comparingLong((NewsComment c) -> c.likes().size())
                        .reversed()
                        .thenComparing(Comparator.comparingLong(NewsComment::timestamp).reversed()))
                .collect(Collectors.toList());
      };
    }
  }

  /** 获取评论数量 */
  public int getCommentCount(String newsId) {
    synchronized (stateLock) {
      return newsComments.getOrDefault(newsId, List.of()).size();
    }
  }

  /** 点赞评论 */
  public boolean likeComment(String newsId, UUID liker, String commentId) {
    synchronized (stateLock) {
      requireOpen();
      List<NewsComment> comments = newsComments.get(newsId);
      if (comments == null) return false;

      for (int i = 0; i < comments.size(); i++) {
        NewsComment comment = comments.get(i);
        if (comment.id().equals(commentId)) {
          Set<UUID> likes = new HashSet<>(comment.likes());
          if (likes.contains(liker)) {
            // 取消点赞
            likes.remove(liker);
          } else {
            // 添加点赞
            likes.add(liker);
          }

          NewsComment updated =
              new NewsComment(
                  comment.id(),
                  comment.newsId(),
                  comment.commenter(),
                  comment.content(),
                  comment.timestamp(),
                  likes);
          comments.set(i, updated);
          return true;
        }
      }
      return false;
    }
  }

  /** 检查玩家是否已点赞评论 */
  public boolean hasLikedComment(String newsId, UUID playerId, String commentId) {
    synchronized (stateLock) {
      List<NewsComment> comments = newsComments.get(newsId);
      if (comments == null) return false;

      return comments.stream()
          .filter(c -> c.id().equals(commentId))
          .anyMatch(c -> c.likes().contains(playerId));
    }
  }

  // ==================== 新闻分享功能 ====================

  /** 分享新闻给其他玩家 */
  public boolean shareNews(String newsId, UUID sharer, UUID targetPlayer) {
    NewsItem item;
    SocialPlayerMessages dispatch;
    Player originalSharer;
    Player originalTarget;
    synchronized (stateLock) {
      requireOpen();
      item = news.get(newsId);
      if (item == null) return false;
      String shareId = UUID.randomUUID().toString();
      newsShares.put(
          shareId,
          new NewsShare(shareId, newsId, sharer, targetPlayer, System.currentTimeMillis()));
      deliverNews(targetPlayer, newsId);
      dispatch = messages;
      originalSharer = dispatch.capture(sharer);
      originalTarget = dispatch.capture(targetPlayer);
    }
    dispatch
        .name(originalSharer, sharer)
        .thenAccept(
            name ->
                dispatch.send(
                    originalTarget,
                    "§b§l【新闻分享】§f" + name + " §7分享了一篇新闻给你:",
                    "§6" + item.headline()));
    return true;
  }

  /** 获取玩家收到的新闻分享 */
  public List<NewsShare> getSharedNews(UUID playerId) {
    synchronized (stateLock) {
      return newsShares.values().stream()
          .filter(s -> s.targetPlayer().equals(playerId))
          .sorted(Comparator.comparing(NewsShare::timestamp).reversed())
          .collect(Collectors.toList());
    }
  }

  /** 获取玩家发起的分享记录 */
  public List<NewsShare> getPlayerShares(UUID playerId) {
    synchronized (stateLock) {
      return newsShares.values().stream()
          .filter(s -> s.sharer().equals(playerId))
          .sorted(Comparator.comparing(NewsShare::timestamp).reversed())
          .collect(Collectors.toList());
    }
  }

  // ==================== 情感分析 ====================

  /** 分析新闻情感 */
  public NewsSentiment analyzeSentiment(String content) {
    String lower = content.toLowerCase();

    int positiveScore = 0;
    int negativeScore = 0;

    for (String word : POSITIVE_WORDS) {
      if (lower.contains(word)) positiveScore++;
    }
    for (String word : NEGATIVE_WORDS) {
      if (lower.contains(word)) negativeScore++;
    }

    if (positiveScore > negativeScore + 1) {
      return NewsSentiment.POSITIVE;
    } else if (negativeScore > positiveScore + 1) {
      return NewsSentiment.NEGATIVE;
    }
    return NewsSentiment.NEUTRAL;
  }

  private static final Set<String> POSITIVE_WORDS =
      Set.of(
          "胜利",
          "成功",
          "和平",
          "繁荣",
          "伟大",
          "喜悦",
          "幸福",
          "增长",
          "victory",
          "success",
          "peace",
          "prosperity",
          "great",
          "joy",
          "happy",
          "growth");

  private static final Set<String> NEGATIVE_WORDS =
      Set.of(
          "失败",
          "战争",
          "灾难",
          "危机",
          "死亡",
          "悲伤",
          "贫困",
          "衰退",
          "defeat",
          "war",
          "disaster",
          "crisis",
          "death",
          "sad",
          "poverty",
          "decline");

  // Called under stateLock; always merge against the current stored item, never a spread snapshot.
  private Delivery deliverNews(UUID playerId, String id) {
    NewsItem item = news.get(id);
    if (item == null || item.reach().contains(playerId)) return null;
    Set<UUID> reach = new HashSet<>(item.reach());
    reach.add(playerId);
    NewsItem updated =
        new NewsItem(
            item.id(),
            item.headline(),
            item.content(),
            item.source(),
            item.category(),
            item.timestamp(),
            item.credibility(),
            reach);
    news.put(id, updated);
    return running ? new Delivery(messages, messages.capture(playerId), updated) : null;
  }

  private void notifyDelivery(Delivery delivery) {
    NewsItem item = delivery.item();
    delivery
        .dispatch()
        .send(
            delivery.player(),
            "§6§l【社会新闻】§e" + item.headline(),
            "§7" + item.content().substring(0, Math.min(50, item.content().length())) + "...");
  }

  private record Delivery(SocialPlayerMessages dispatch, Player player, NewsItem item) {}

  private void processNewsSpread(long epoch) {
    List<Delivery> deliveries = new ArrayList<>();
    synchronized (stateLock) {
      if (!running || generation != epoch) return;
      long now = System.currentTimeMillis();
      for (NewsItem item : List.copyOf(news.values())) {
        if (now - item.timestamp() > 86400000L) {
          news.remove(item.id());
          newsComments.remove(item.id());
          newsShares.values().removeIf(share -> share.newsId().equals(item.id()));
          playerNewsSeen.values().forEach(seen -> seen.remove(item.id()));
          continue;
        }
        double credibility =
            item.credibility() > 0.3
                ? Math.max(0.3, item.credibility() * 0.99)
                : item.credibility();
        NewsItem updated =
            new NewsItem(
                item.id(),
                item.headline(),
                item.content(),
                item.source(),
                item.category(),
                item.timestamp(),
                credibility,
                item.reach());
        news.put(item.id(), updated);
        if (credibility < 0.5) continue;
        for (UUID reached : item.reach()) {
          for (UUID friend : relationshipNetwork.getFriends(reached)) {
            var rel = relationshipNetwork.getRelationship(reached, friend);
            if (rel != null
                && rel.strength() > 30
                && ThreadLocalRandom.current().nextDouble() < credibility) {
              Delivery delivery = deliverNews(friend, item.id());
              if (delivery != null) deliveries.add(delivery);
            }
          }
        }
      }
      playerNewsSeen.values().removeIf(Set::isEmpty);
    }
    deliveries.forEach(this::notifyDelivery);
  }

  // ==================== 数据类 ====================

  public enum NewsCategory {
    POLITICS("政治", "§c"),
    MILITARY("军事", "§4"),
    ECONOMY("经济", "§6"),
    SOCIAL("社会", "§e"),
    CULTURE("文化", "§d"),
    SCANDAL("丑闻", "§5"),
    HEROIC("英雄事迹", "§a"),
    TRAGEDY("悲剧", "§7"),
    CONFLICT("冲突", "§4");

    private final String name;
    private final String color;

    NewsCategory(String name, String color) {
      this.name = name;
      this.color = color;
    }

    public String getName() {
      return name;
    }

    public String getColor() {
      return color;
    }
  }

  public record NewsItem(
      String id,
      String headline,
      String content,
      UUID source,
      NewsCategory category,
      long timestamp,
      double credibility,
      Set<UUID> reach) {
    public NewsItem {
      Objects.requireNonNull(id);
      Objects.requireNonNull(headline);
      Objects.requireNonNull(content);
      Objects.requireNonNull(category);
      reach = Set.copyOf(reach);
      if (!Double.isFinite(credibility) || credibility < 0 || credibility > 1)
        throw new IllegalArgumentException("Invalid news credibility");
    }

    public String getAgeText() {
      long age = System.currentTimeMillis() - timestamp();
      long hours = age / (60 * 60 * 1000);
      if (hours < 1) return "刚刚";
      if (hours < 24) return hours + "小时前";
      return (hours / 24) + "天前";
    }

    public int getCommentCount(NewsPropagationService service) {
      return service.getCommentCount(id);
    }

    public NewsSentiment getSentiment(NewsPropagationService service) {
      return service.analyzeSentiment(content);
    }
  }

  // ==================== 评论数据结构 ====================

  public record NewsComment(
      String id, // 评论ID
      String newsId, // 所属新闻ID
      UUID commenter, // 评论者
      String content, // 评论内容
      long timestamp, // 评论时间
      Set<UUID> likes // 点赞玩家集合
      ) {
    public NewsComment {
      likes = Set.copyOf(likes);
    }

    public String getAgeText() {
      long age = System.currentTimeMillis() - timestamp();
      long minutes = age / (60 * 1000);
      if (minutes < 1) return "刚刚";
      if (minutes < 60) return minutes + "分钟前";
      long hours = minutes / 60;
      if (hours < 24) return hours + "小时前";
      return (hours / 24) + "天前";
    }

    public int getLikeCount() {
      return likes.size();
    }
  }

  // ==================== 新闻分享数据结构 ====================

  public record NewsShare(
      String id, // 分享ID
      String newsId, // 分享的新闻ID
      UUID sharer, // 分享者
      UUID targetPlayer, // 接收者
      long timestamp // 分享时间
      ) {
    public String getAgeText() {
      long age = System.currentTimeMillis() - timestamp();
      long minutes = age / (60 * 1000);
      if (minutes < 1) return "刚刚";
      if (minutes < 60) return minutes + "分钟前";
      long hours = minutes / 60;
      if (hours < 24) return hours + "小时前";
      return (hours / 24) + "天前";
    }
  }

  // ==================== 枚举定义 ====================

  /** 新闻情感分析 */
  public enum NewsSentiment {
    POSITIVE("积极", "§a"),
    NEUTRAL("中性", "§f"),
    NEGATIVE("消极", "§c");

    private final String name;
    private final String color;

    NewsSentiment(String name, String color) {
      this.name = name;
      this.color = color;
    }

    public String getName() {
      return name;
    }

    public String getColor() {
      return color;
    }
  }

  /** 评论排序方式 */
  public enum CommentSortOrder {
    NEWEST("最新优先"),
    HOTTEST("最热优先");

    private final String name;

    CommentSortOrder(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }
}
