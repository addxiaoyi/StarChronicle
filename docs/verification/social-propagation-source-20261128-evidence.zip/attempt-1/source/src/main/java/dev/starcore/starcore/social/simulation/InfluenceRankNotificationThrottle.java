package dev.starcore.starcore.social.simulation;

import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Keeps rank-change notifications quiet while preserving the latest notified baseline. */
final class InfluenceRankNotificationThrottle {

  private final long cooldownMillis;
  private final Map<UUID, Snapshot> snapshots = new java.util.HashMap<>();

  InfluenceRankNotificationThrottle(Duration cooldown) {
    Objects.requireNonNull(cooldown, "cooldown");
    if (cooldown.isNegative()) {
      throw new IllegalArgumentException("cooldown must not be negative");
    }
    this.cooldownMillis = cooldown.toMillis();
  }

  synchronized Optional<Map<LeaderboardPeriod, Integer>> claim(
      UUID playerId,
      Map<LeaderboardPeriod, Integer> currentRanks,
      Map<LeaderboardPeriod, Integer> initialRanks,
      long nowMillis) {
    Objects.requireNonNull(playerId, "playerId");
    Map<LeaderboardPeriod, Integer> current = copyRanks(currentRanks);
    Map<LeaderboardPeriod, Integer> initial = copyRanks(initialRanks);
    Snapshot previous =
        snapshots.computeIfAbsent(playerId, ignored -> new Snapshot(initial, Long.MIN_VALUE));

    if (previous.ranks().equals(current)) {
      return Optional.empty();
    }

    long elapsed = nowMillis - previous.lastNotifiedAt();
    if (previous.lastNotifiedAt() != Long.MIN_VALUE && elapsed < cooldownMillis) {
      return Optional.empty();
    }

    snapshots.put(playerId, new Snapshot(current, nowMillis));
    return Optional.of(previous.ranks());
  }

  private Map<LeaderboardPeriod, Integer> copyRanks(Map<LeaderboardPeriod, Integer> ranks) {
    Objects.requireNonNull(ranks, "ranks");
    EnumMap<LeaderboardPeriod, Integer> copy = new EnumMap<>(LeaderboardPeriod.class);
    copy.putAll(ranks);
    return Map.copyOf(copy);
  }

  private record Snapshot(Map<LeaderboardPeriod, Integer> ranks, long lastNotifiedAt) {}
}
