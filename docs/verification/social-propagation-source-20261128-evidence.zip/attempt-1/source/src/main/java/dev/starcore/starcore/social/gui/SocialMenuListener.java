package dev.starcore.starcore.social.gui;

import dev.starcore.starcore.foundation.gui.ButtonFactory;
import dev.starcore.starcore.social.chat.PrivateMessageService;
import dev.starcore.starcore.social.friend.FriendService;
import dev.starcore.starcore.social.guild.GuildService;
import dev.starcore.starcore.social.party.PartyService;
import dev.starcore.starcore.social.simulation.SocialActivityService;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.NotNull;

public final class SocialMenuListener implements Listener {

  private static final String STATE_MAIN = "main";
  private static final String STATE_FRIEND_REQUESTS = "friend_requests";
  private static final String STATE_FRIEND_LIST = "friend_list";
  private static final String STATE_GUILD_MEMBERS = "guild_members";
  private static final String STATE_GUILD_INVITES = "guild_invites";
  private static final String STATE_PARTY_MEMBERS = "party_members";
  private static final String STATE_PARTY_INVITES = "party_invites";
  private static final String STATE_BLOCKED_PLAYERS = "blocked_players";
  private static final String STATE_CHAT_HISTORY = "chat_history";
  private static final String STATE_SUMMARY = "summary";

  private static final int GUI_SIZE = 54;

  private final FriendService friendService;
  private final GuildService guildService;
  private final PartyService partyService;
  private final PrivateMessageService messageService;
  private SocialActivityService activityService;

  private ActivityRecommendationListener activityListener;
  private SocialLeaderboardListener leaderboardListener;

  private final Map<UUID, SocialMenuGui> openMenus = new HashMap<>();
  private final Map<UUID, String> playerMenuState = new ConcurrentHashMap<>();
  private final Map<UUID, UUID> playerChatTarget = new ConcurrentHashMap<>();
  private final Map<UUID, String> summaryKinds = new ConcurrentHashMap<>();

  public SocialMenuListener(
      FriendService friendService,
      GuildService guildService,
      PartyService partyService,
      PrivateMessageService messageService) {
    this(friendService, guildService, partyService, messageService, null);
  }

  public SocialMenuListener(
      FriendService friendService,
      GuildService guildService,
      PartyService partyService,
      PrivateMessageService messageService,
      SocialActivityService activityService) {
    this.friendService = friendService;
    this.guildService = guildService;
    this.partyService = partyService;
    this.messageService = messageService;
    this.activityService = activityService;
  }

  @EventHandler(priority = EventPriority.NORMAL)
  public void onInventoryDrag(@NotNull InventoryDragEvent event) {
    if (event.getView().getTopInventory().getHolder() instanceof SocialMenuGui
        || event.getView().getTopInventory().getHolder() instanceof SocialMenuHolder) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.NORMAL)
  public void onInventoryClick(@NotNull InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    Inventory topInventory = event.getView().getTopInventory();
    if (!(topInventory.getHolder() instanceof SocialMenuGui)
        && !(topInventory.getHolder() instanceof SocialMenuHolder)) {
      return;
    }

    event.setCancelled(true);

    int slot = event.getRawSlot();
    if (event.getClickedInventory() != topInventory
        || slot < 0
        || slot >= topInventory.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)) {
      return;
    }

    String state = playerMenuState.getOrDefault(player.getUniqueId(), STATE_MAIN);

    switch (state) {
      case STATE_MAIN -> handleMainMenuClick(player, slot);
      case STATE_FRIEND_REQUESTS -> handleFriendRequestsClick(player, slot);
      case STATE_FRIEND_LIST -> handleFriendListClick(player, slot);
      case STATE_GUILD_MEMBERS -> handleGuildMembersClick(player, slot);
      case STATE_GUILD_INVITES -> handleGuildInvitesClick(player, slot);
      case STATE_PARTY_MEMBERS -> handlePartyMembersClick(player, slot);
      case STATE_PARTY_INVITES -> handlePartyInvitesClick(player, slot);
      case STATE_BLOCKED_PLAYERS -> handleBlockedPlayersClick(player, slot);
      case STATE_CHAT_HISTORY -> handleChatHistoryClick(player, slot);
      case STATE_SUMMARY -> handleSummaryClick(player, slot);
      default -> handleMainMenuClick(player, slot);
    }
  }

  @EventHandler
  public void onInventoryClose(@NotNull InventoryCloseEvent event) {
    if (event.getPlayer() instanceof Player player) {
      openMenus.remove(player.getUniqueId());
    }
  }

  private void handleAction(Player player, SocialMenuGui.SocialAction action) {
    switch (action) {
      case FRIENDS -> {
        openFriendListPage(player);
        return;
      }
      case GUILD -> {
        openSummaryPage(player, "guild");
        return;
      }
      case PARTY -> {
        openSummaryPage(player, "party");
        return;
      }
      case PRIVATE_CHAT -> {
        openChatHistoryPage(player);
        return;
      }
      case STATS -> {
        openSummaryPage(player, "stats");
        return;
      }
      default -> {
        // The remaining actions already have dedicated GUI routes below.
      }
    }
    switch (action) {
      case FRIENDS -> player.sendMessage(Component.text("§e好友系统: 请点击下方按钮管理好友"));
      case FRIEND_REQUESTS -> openFriendRequestsPage(player);
      case FRIEND_LIST -> openFriendListPage(player);
      case GUILD -> {
        var guild = guildService.getPlayerGuild(player.getUniqueId());
        if (guild != null) {
          player.sendMessage(Component.text("§6=== 公会 " + guild.getName() + " ==="));
          player.sendMessage(
              Component.text("§7等级: " + guild.getLevel() + " 经验: " + guild.getExperience()));
          player.sendMessage(Component.text("§7成员: " + guild.getMemberCount()));
        } else {
          player.sendMessage(Component.text("§6=== 公会系统 ==="));
          player.sendMessage(Component.text("§7你还没有加入公会，使用 /guild create 创建或 /guild list 查看公会"));
        }
      }
      case GUILD_MEMBERS -> openGuildMembersPage(player);
      case GUILD_INVITES -> openGuildInvitesPage(player);
      case PARTY -> {
        var party = partyService.getPlayerParty(player.getUniqueId());
        if (party != null) {
          player.sendMessage(Component.text("§b=== 派对 ==="));
          player.sendMessage(
              Component.text("§7成员: " + party.getMemberCount() + "/" + party.getMaxMembers()));
        } else {
          player.sendMessage(Component.text("§b=== 派对系统 ==="));
          player.sendMessage(Component.text("§7你还没有加入派对，使用 /party create 创建或 /party invite 邀请"));
        }
      }
      case PARTY_MEMBERS -> openPartyMembersPage(player);
      case PARTY_INVITES -> openPartyInvitesPage(player);
      case PRIVATE_CHAT -> player.sendMessage(Component.text("§a私聊系统: 使用 /msg <玩家> <消息> 发送私聊"));
      case CHAT_HISTORY -> openChatHistoryPage(player);
      case BLOCKED_PLAYERS -> openBlockedPlayersPage(player);
      case ACTIVITY -> openActivityMenu(player);
      case LEADERBOARD -> openLeaderboardMenu(player);
      case STATS -> {
        player.sendMessage(Component.text("§6=== 社交统计 ==="));
        player.sendMessage(
            Component.text("好友: " + friendService.getFriendCount(player.getUniqueId())));
        player.sendMessage(
            Component.text(
                "公会: "
                    + (guildService.getPlayerGuild(player.getUniqueId()) != null ? "已加入" : "未加入")));
        player.sendMessage(
            Component.text(
                "派对: "
                    + (partyService.getPlayerParty(player.getUniqueId()) != null ? "已加入" : "未加入")));
      }
      case CLOSE -> player.closeInventory();
      case NONE -> {}
    }
  }

  private void openSummaryPage(Player player, String kind) {
    summaryKinds.put(player.getUniqueId(), kind);
    playerMenuState.put(player.getUniqueId(), STATE_SUMMARY);

    String title;
    Material icon;
    List<String> lines = new ArrayList<>();
    switch (kind) {
      case "guild" -> {
        title = "Guild overview";
        icon = Material.BEACON;
        var guild = guildService.getPlayerGuild(player.getUniqueId());
        if (guild == null) {
          lines.add("No guild membership is active.");
          lines.add("Use the guild pages to browse available guilds.");
        } else {
          lines.add("Name: " + guild.getName() + " [" + guild.getTag() + "]");
          lines.add("Level: " + guild.getLevel());
          lines.add("Experience: " + guild.getExperience());
          lines.add("Members: " + guild.getMemberCount());
        }
      }
      case "party" -> {
        title = "Party overview";
        icon = Material.PLAYER_HEAD;
        var party = partyService.getPlayerParty(player.getUniqueId());
        if (party == null) {
          lines.add("No party membership is active.");
          lines.add("Use the party pages to manage invitations.");
        } else {
          lines.add("Members: " + party.getMemberCount() + "/" + party.getMaxMembers());
        }
      }
      case "stats" -> {
        title = "Social statistics";
        icon = Material.PAPER;
        lines.add("Friends: " + friendService.getFriendCount(player.getUniqueId()));
        lines.add(
            "Guild: "
                + (guildService.getPlayerGuild(player.getUniqueId()) == null ? "None" : "Joined"));
        lines.add(
            "Party: "
                + (partyService.getPlayerParty(player.getUniqueId()) == null ? "None" : "Joined"));
      }
      default -> throw new IllegalArgumentException("Unknown social summary: " + kind);
    }

    Inventory inventory = Bukkit.createInventory(new SocialMenuHolder(), 27, Component.text(title));
    fillBorder(inventory, Material.GRAY_STAINED_GLASS_PANE);
    inventory.setItem(4, createPageTitle(title, icon));
    for (int i = 0; i < lines.size(); i++) {
      inventory.setItem(10 + i, createInfoItem(Material.PAPER, lines.get(i), null));
    }
    inventory.setItem(18, createBackButton());
    inventory.setItem(26, createCloseButton());
    player.openInventory(inventory);
  }

  private void handleSummaryClick(Player player, int slot) {
    if (slot == 18) {
      openMainSocialMenu(player);
    } else if (slot == 26) {
      player.closeInventory();
    }
  }

  private void handleMainMenuClick(Player player, int slot) {
    SocialMenuGui.SocialAction action = SocialMenuGui.getActionFromSlot(slot);
    handleAction(player, action);
  }

  private void openFriendRequestsPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_FRIEND_REQUESTS);
    var requests = friendService.getFriendRequests(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§e好友请求"));
    fillBorder(inv, Material.YELLOW_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle("§e好友请求", Material.PAPER));

    if (requests.isEmpty()) {
      inv.setItem(22, createEmptyStateItem("§7没有待处理的好友请求", null));
    } else {
      int slot = 10;
      for (UUID requesterId : requests) {
        if (slot >= 44) break;
        inv.setItem(slot, createFriendRequestItem(player, requesterId));
        slot++;
      }
      inv.setItem(21, createInfoItem(Material.PAPER, "§7共 " + requests.size() + " 条请求", null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createFriendRequestItem(Player player, UUID requesterId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(requesterId);
    String name =
        offlinePlayer.getName() != null ? offlinePlayer.getName() : requesterId.toString();
    boolean online = offlinePlayer.isOnline();

    ItemStack item = new ItemStack(Material.PAPER);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(name, online ? NamedTextColor.GREEN : NamedTextColor.GRAY));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("ID: " + requesterId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text(online ? "§a[在线]" : "§7[离线]"));
      lore.add(Component.text(""));
      lore.add(Component.text("§a[点击接受]  §c[Shift+点击拒绝]", NamedTextColor.YELLOW));

      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return item;
  }

  private void handleFriendRequestsClick(Player player, int slot) {
    if (isListEntrySlot(slot)) {
      ItemStack item = player.getOpenInventory().getTopInventory().getItem(slot);
      if (item == null) return;
      UUID requesterId = extractUUIDFromLore(item);
      if (requesterId != null) {
        try {
          if (player.isSneaking()) {
            friendService.rejectFriendRequest(player.getUniqueId(), requesterId);
            player.sendMessage(Component.text("§7已拒绝 " + getPlayerName(requesterId) + " 的好友请求"));
          } else {
            friendService.acceptFriendRequest(player.getUniqueId(), requesterId);
            player.sendMessage(Component.text("§a已接受 " + getPlayerName(requesterId) + " 的好友请求"));
          }
        } catch (Exception e) {
          player.sendMessage(Component.text("§c操作失败: " + e.getMessage()));
        }
        openFriendRequestsPage(player);
      }
    } else if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openFriendListPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_FRIEND_LIST);
    var friends = friendService.getFriends(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§e好友列表"));
    fillBorder(inv, Material.GREEN_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle("§e我的好友", Material.PLAYER_HEAD));

    if (friends.isEmpty()) {
      inv.setItem(22, createEmptyStateItem("§7你还没有好友", "§e使用 /friend add 添加好友"));
    } else {
      int slot = 10;
      for (UUID friendId : friends) {
        if (slot >= 44) break;
        inv.setItem(slot, createFriendListItem(player, friendId));
        slot++;
      }
      inv.setItem(21, createInfoItem(Material.PAPER, "§7共 " + friends.size() + " 位好友", null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createFriendListItem(Player player, UUID friendId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(friendId);
    String name = offlinePlayer.getName() != null ? offlinePlayer.getName() : friendId.toString();
    boolean online = offlinePlayer.isOnline();

    ItemStack item = new ItemStack(Material.PLAYER_HEAD);
    if (item.getItemMeta() instanceof SkullMeta skullMeta) {
      skullMeta.setOwningPlayer(offlinePlayer);
      skullMeta.displayName(
          Component.text(name, online ? NamedTextColor.GREEN : NamedTextColor.GRAY));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("ID: " + friendId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text(online ? "§a[在线]" : "§7[离线]"));
      lore.add(Component.text(""));
      lore.add(Component.text("§7点击查看私聊记录", NamedTextColor.YELLOW));

      skullMeta.lore(lore);
      item.setItemMeta(skullMeta);
    }
    return item;
  }

  private void handleFriendListClick(Player player, int slot) {
    if (isListEntrySlot(slot)) {
      ItemStack item = player.getOpenInventory().getTopInventory().getItem(slot);
      if (item == null) return;
      UUID friendId = extractUUIDFromLore(item);
      if (friendId != null) {
        playerChatTarget.put(player.getUniqueId(), friendId);
        openChatHistoryPage(player);
      }
    } else if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openGuildMembersPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_GUILD_MEMBERS);
    var guild = guildService.getPlayerGuild(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§6公会成员"));
    fillBorder(inv, Material.YELLOW_STAINED_GLASS_PANE);

    inv.setItem(
        4, createPageTitle(guild != null ? "§6" + guild.getName() : "§6公会成员", Material.BEACON));

    if (guild == null) {
      inv.setItem(22, createEmptyStateItem("§c你不在任何公会", "§e使用 /guild create 创建公会"));
    } else {
      int slot = 10;
      for (UUID memberId : guild.getMembers()) {
        if (slot >= 44) break;
        inv.setItem(slot, createGuildMemberItem(guild, memberId));
        slot++;
      }
      inv.setItem(21, createInfoItem(Material.BEACON, "§7成员: " + guild.getMemberCount(), null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createGuildMemberItem(
      dev.starcore.starcore.social.guild.Guild guild, UUID memberId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(memberId);
    String name = offlinePlayer.getName() != null ? offlinePlayer.getName() : memberId.toString();
    boolean online = offlinePlayer.isOnline();
    var role = guild.getMemberRole(memberId);

    ItemStack item = new ItemStack(Material.PLAYER_HEAD);
    if (item.getItemMeta() instanceof SkullMeta skullMeta) {
      skullMeta.setOwningPlayer(offlinePlayer);
      skullMeta.displayName(
          Component.text(name, online ? NamedTextColor.GREEN : NamedTextColor.GRAY));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("ID: " + memberId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text("§7职位: " + role.getDisplayName()));
      lore.add(Component.text(online ? "§a[在线]" : "§7[离线]"));

      skullMeta.lore(lore);
      item.setItemMeta(skullMeta);
    }
    return item;
  }

  private void handleGuildMembersClick(Player player, int slot) {
    if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openGuildInvitesPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_GUILD_INVITES);
    var invites = guildService.getGuildInvites(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§6公会邀请"));
    fillBorder(inv, Material.PURPLE_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle("§6公会邀请", Material.ENDER_PEARL));

    if (invites.isEmpty()) {
      inv.setItem(22, createEmptyStateItem("§7没有待处理的公会邀请", null));
    } else {
      int slot = 10;
      for (var invite : invites) {
        if (slot >= 44) break;
        inv.setItem(slot, createGuildInviteItem(invite));
        slot++;
      }
      inv.setItem(21, createInfoItem(Material.ENDER_PEARL, "§7共 " + invites.size() + " 条邀请", null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createGuildInviteItem(GuildService.GuildInvite invite) {
    var guild =
        guildService.getAllGuilds().stream()
            .filter(g -> g.getId().equals(invite.guildId()))
            .findFirst()
            .orElse(null);
    String guildName = guild != null ? guild.getName() : "Unknown";

    var inviterPlayer = Bukkit.getOfflinePlayer(invite.inviterId());
    String inviterName =
        inviterPlayer.getName() != null ? inviterPlayer.getName() : invite.inviterId().toString();

    ItemStack item = new ItemStack(Material.ENDER_PEARL);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(guildName, NamedTextColor.LIGHT_PURPLE));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("公会ID: " + invite.guildId(), NamedTextColor.DARK_GRAY));
      lore.add(Component.text("邀请者ID: " + invite.inviterId(), NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text("§7邀请来自: " + inviterName));
      lore.add(Component.text(""));
      lore.add(Component.text("§a[点击接受]  §c[Shift+点击拒绝]", NamedTextColor.YELLOW));

      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return item;
  }

  private void handleGuildInvitesClick(Player player, int slot) {
    if (isListEntrySlot(slot)) {
      ItemStack item = player.getOpenInventory().getTopInventory().getItem(slot);
      if (item == null) return;
      String guildId = extractValueFromLore(item, "公会ID: ");
      if (guildId != null) {
        try {
          UUID guildUuid = UUID.fromString(guildId);
          if (player.isSneaking()) {
            guildService.rejectInvite(player.getUniqueId(), guildUuid);
            player.sendMessage(Component.text("§7已拒绝公会邀请"));
          } else {
            guildService.acceptInvite(player.getUniqueId(), guildUuid);
            player.sendMessage(Component.text("§a已接受公会邀请"));
          }
        } catch (Exception e) {
          player.sendMessage(Component.text("§c操作失败: " + e.getMessage()));
        }
        openGuildInvitesPage(player);
      }
    } else if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openPartyMembersPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_PARTY_MEMBERS);
    var party = partyService.getPlayerParty(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§b派对成员"));
    fillBorder(inv, Material.CYAN_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle(party != null ? "§b派对成员" : "§b派对", Material.NETHER_STAR));

    if (party == null) {
      inv.setItem(22, createEmptyStateItem("§c你不在任何派对", "§e使用 /party create 创建派对"));
    } else {
      int slot = 10;
      for (UUID memberId : party.getMembers()) {
        if (slot >= 44) break;
        inv.setItem(slot, createPartyMemberItem(party, memberId));
        slot++;
      }
      inv.setItem(
          21,
          createInfoItem(
              Material.NETHER_STAR,
              "§7成员: " + party.getMemberCount() + "/" + party.getMaxMembers(),
              null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createPartyMemberItem(
      dev.starcore.starcore.social.party.Party party, UUID memberId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(memberId);
    String name = offlinePlayer.getName() != null ? offlinePlayer.getName() : memberId.toString();
    boolean online = offlinePlayer.isOnline();
    boolean leader = party.isLeader(memberId);

    ItemStack item = new ItemStack(Material.PLAYER_HEAD);
    if (item.getItemMeta() instanceof SkullMeta skullMeta) {
      skullMeta.setOwningPlayer(offlinePlayer);
      skullMeta.displayName(
          Component.text(name, online ? NamedTextColor.GREEN : NamedTextColor.GRAY));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("ID: " + memberId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      if (leader) {
        lore.add(Component.text("§6[队长]"));
      }
      lore.add(Component.text(online ? "§a[在线]" : "§7[离线]"));

      skullMeta.lore(lore);
      item.setItemMeta(skullMeta);
    }
    return item;
  }

  private void handlePartyMembersClick(Player player, int slot) {
    if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openPartyInvitesPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_PARTY_INVITES);
    var invites = partyService.getPartyInvites(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§b派对邀请"));
    fillBorder(inv, Material.FIREWORK_ROCKET);

    inv.setItem(4, createPageTitle("§b派对邀请", Material.FIREWORK_ROCKET));

    if (invites.isEmpty()) {
      inv.setItem(22, createEmptyStateItem("§7没有待处理的派对邀请", null));
    } else {
      int slot = 10;
      for (UUID inviterId : invites) {
        if (slot >= 44) break;
        inv.setItem(slot, createPartyInviteItem(inviterId));
        slot++;
      }
      inv.setItem(
          21, createInfoItem(Material.FIREWORK_ROCKET, "§7共 " + invites.size() + " 条邀请", null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createPartyInviteItem(UUID inviterId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(inviterId);
    String name = offlinePlayer.getName() != null ? offlinePlayer.getName() : inviterId.toString();
    boolean online = offlinePlayer.isOnline();

    ItemStack item = new ItemStack(Material.FIREWORK_ROCKET);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(name, online ? NamedTextColor.GREEN : NamedTextColor.GRAY));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("邀请者ID: " + inviterId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text(online ? "§a[在线]" : "§7[离线]"));
      lore.add(Component.text(""));
      lore.add(Component.text("§a[点击接受]  §c[Shift+点击拒绝]", NamedTextColor.YELLOW));

      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return item;
  }

  private void handlePartyInvitesClick(Player player, int slot) {
    if (isListEntrySlot(slot)) {
      ItemStack item = player.getOpenInventory().getTopInventory().getItem(slot);
      if (item == null) return;
      String inviterIdStr = extractValueFromLore(item, "邀请者ID: ");
      if (inviterIdStr != null) {
        try {
          UUID inviterId = UUID.fromString(inviterIdStr);
          if (player.isSneaking()) {
            partyService.rejectInvite(player.getUniqueId(), inviterId);
            player.sendMessage(Component.text("§7已拒绝 " + getPlayerName(inviterId) + " 的派对邀请"));
          } else {
            partyService.acceptInvite(player.getUniqueId(), inviterId);
            player.sendMessage(Component.text("§a已接受 " + getPlayerName(inviterId) + " 的派对邀请"));
          }
        } catch (Exception e) {
          player.sendMessage(Component.text("§c操作失败: " + e.getMessage()));
        }
        openPartyInvitesPage(player);
      }
    } else if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openBlockedPlayersPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_BLOCKED_PLAYERS);
    var blocked = messageService.getMutedPlayers(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§c屏蔽列表"));
    fillBorder(inv, Material.RED_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle("§c屏蔽列表", Material.BARRIER));

    if (blocked.isEmpty()) {
      inv.setItem(22, createEmptyStateItem("§7你没有屏蔽任何玩家", null));
    } else {
      int slot = 10;
      for (UUID blockedId : blocked) {
        if (slot >= 44) break;
        inv.setItem(slot, createBlockedPlayerItem(blockedId));
        slot++;
      }
      inv.setItem(21, createInfoItem(Material.BARRIER, "§7共 " + blocked.size() + " 位屏蔽玩家", null));
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private ItemStack createBlockedPlayerItem(UUID blockedId) {
    var offlinePlayer = Bukkit.getOfflinePlayer(blockedId);
    String name = offlinePlayer.getName() != null ? offlinePlayer.getName() : blockedId.toString();

    ItemStack item = new ItemStack(Material.BARRIER);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(name, NamedTextColor.RED));

      List<Component> lore = new ArrayList<>();
      lore.add(Component.text("ID: " + blockedId, NamedTextColor.DARK_GRAY));
      lore.add(Component.text(""));
      lore.add(Component.text("§7点击取消屏蔽", NamedTextColor.YELLOW));

      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return item;
  }

  private void handleBlockedPlayersClick(Player player, int slot) {
    if (isListEntrySlot(slot)) {
      ItemStack item = player.getOpenInventory().getTopInventory().getItem(slot);
      if (item == null) return;
      UUID blockedId = extractUUIDFromLore(item);
      if (blockedId != null) {
        try {
          messageService.unmutePlayer(player.getUniqueId(), blockedId);
          player.sendMessage(Component.text("§a已取消对 " + getPlayerName(blockedId) + " 的屏蔽"));
        } catch (Exception e) {
          player.sendMessage(Component.text("§c操作失败: " + e.getMessage()));
        }
        openBlockedPlayersPage(player);
      }
    } else if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private void openChatHistoryPage(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_CHAT_HISTORY);
    UUID targetId = playerChatTarget.get(player.getUniqueId());

    Inventory inv =
        Bukkit.createInventory(new SocialMenuHolder(), GUI_SIZE, Component.text("§a聊天记录"));
    fillBorder(inv, Material.LIME_STAINED_GLASS_PANE);

    inv.setItem(4, createPageTitle("§a聊天记录", Material.BOOK));

    if (targetId == null) {
      var lastPartner = messageService.getLastChatPartner(player.getUniqueId());
      if (lastPartner != null) {
        targetId = lastPartner;
        playerChatTarget.put(player.getUniqueId(), targetId);
      }
    }

    if (targetId == null) {
      inv.setItem(22, createEmptyStateItem("§7没有最近的私聊记录", null));
    } else {
      String partnerName = getPlayerName(targetId);
      inv.setItem(13, createInfoItem(Material.PLAYER_HEAD, "§a与 " + partnerName + " 的聊天", null));

      var messages = messageService.getConversation(player.getUniqueId(), targetId, 36);
      int slot = 10;
      int count = 0;
      for (var msg : messages) {
        if (slot >= 44) break;
        boolean isSender = msg.senderId().equals(player.getUniqueId());
        inv.setItem(slot, createChatMessageItem(msg, isSender));
        slot++;
        count++;
      }
      if (count == 0) {
        inv.setItem(22, createEmptyStateItem("§7没有聊天记录", null));
      }
    }

    inv.setItem(38, createBackButton());
    inv.setItem(44, createCloseButton());

    player.openInventory(inv);
  }

  private void handleChatHistoryClick(Player player, int slot) {
    if (slot == 38) {
      openMainSocialMenu(player);
    } else if (slot == 44) {
      playerMenuState.remove(player.getUniqueId());
      player.closeInventory();
    }
  }

  private static boolean isListEntrySlot(int slot) {
    return slot >= 10 && slot <= 43 && slot != 38;
  }

  private ItemStack createChatMessageItem(PrivateMessageService.ChatMessage msg, boolean isSender) {
    ItemStack item =
        new ItemStack(
            isSender ? Material.LIME_STAINED_GLASS_PANE : Material.CYAN_STAINED_GLASS_PANE);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(
          Component.text(
              isSender ? "我" : getPlayerName(msg.senderId()),
              isSender ? NamedTextColor.GREEN : NamedTextColor.AQUA));

      List<Component> lore = new ArrayList<>();
      String messageText = msg.message();
      if (messageText.length() > 40) {
        lore.add(Component.text(messageText.substring(0, 40) + "...", NamedTextColor.GRAY));
      } else {
        lore.add(Component.text(messageText, NamedTextColor.GRAY));
      }

      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return item;
  }

  private void openMainSocialMenu(Player player) {
    playerMenuState.put(player.getUniqueId(), STATE_MAIN);
    playerChatTarget.remove(player.getUniqueId());
    summaryKinds.remove(player.getUniqueId());
    SocialMenuGui menu =
        new SocialMenuGui(player, friendService, guildService, partyService, messageService);
    openMenus.put(player.getUniqueId(), menu);
    player.openInventory(menu.getInventory());
  }

  private void openActivityMenu(Player player) {
    if (activityListener == null || activityService == null) {
      openUnavailablePage(
          player,
          "Activity unavailable",
          Material.FIREWORK_STAR,
          "The activity service is not enabled on this server.");
      return;
    }
    if (activityListener != null && activityService != null) {
      activityListener.openMenu(player);
    } else {
      player.sendMessage(Component.text("§6=== 活动系统 ==="));
      player.sendMessage(Component.text("§7活动功能正在初始化..."));
      player.sendMessage(Component.text("§e使用 /activity 命令创建或查看活动"));
    }
  }

  private void openLeaderboardMenu(Player player) {
    if (leaderboardListener == null) {
      openUnavailablePage(
          player,
          "Leaderboard unavailable",
          Material.END_CRYSTAL,
          "The leaderboard service is not enabled on this server.");
      return;
    }
    if (leaderboardListener != null) {
      leaderboardListener.openMenu(player);
    } else {
      player.sendMessage(Component.text("§6=== 排行榜系统 ==="));
      player.sendMessage(Component.text("§7使用 /influence 查看影响力排行榜"));
    }
  }

  private void openUnavailablePage(Player player, String title, Material icon, String detail) {
    playerMenuState.put(player.getUniqueId(), STATE_SUMMARY);
    summaryKinds.put(player.getUniqueId(), "unavailable");
    Inventory inventory = Bukkit.createInventory(new SocialMenuHolder(), 27, Component.text(title));
    fillBorder(inventory, Material.GRAY_STAINED_GLASS_PANE);
    inventory.setItem(4, createPageTitle(title, icon));
    inventory.setItem(13, createEmptyStateItem(detail, "Return to the social menu to continue."));
    inventory.setItem(18, createBackButton());
    inventory.setItem(26, createCloseButton());
    player.openInventory(inventory);
  }

  private ItemStack createPageTitle(String name, Material material) {
    return ButtonFactory.createStyledButton(name, material, ButtonFactory.BUTTON_STYLE_PRIMARY);
  }

  private ItemStack createEmptyStateItem(String message, String hint) {
    return ButtonFactory.createEmptyState(
        PlainTextComponentSerializer.plainText().serialize(Component.text(message)),
        hint != null
            ? PlainTextComponentSerializer.plainText().serialize(Component.text(hint))
            : null);
  }

  private ItemStack createInfoItem(Material material, String name, String description) {
    return ButtonFactory.createStyledButton(
        PlainTextComponentSerializer.plainText().serialize(Component.text(name)),
        material,
        ButtonFactory.BUTTON_STYLE_INFO,
        description != null
            ? PlainTextComponentSerializer.plainText().serialize(Component.text(description))
            : "");
  }

  private ItemStack createBackButton() {
    return ButtonFactory.createBackButton();
  }

  private ItemStack createCloseButton() {
    return ButtonFactory.createCloseButton();
  }

  private void fillBorder(Inventory inv, Material material) {
    ItemStack border = ButtonFactory.createBorder(material);
    int size = inv.getSize();
    int rows = size / 9;

    for (int row = 0; row < rows; row++) {
      inv.setItem(row * 9, border);
      inv.setItem(row * 9 + 8, border);
    }
    for (int col = 1; col < 8; col++) {
      inv.setItem(col, border);
      inv.setItem(size - 9 + col, border);
    }
  }

  private UUID extractUUIDFromLore(ItemStack item) {
    if (item == null || !item.hasItemMeta()) return null;
    ItemMeta meta = item.getItemMeta();
    if (meta == null || meta.lore() == null) return null;

    for (Component loreLine : meta.lore()) {
      String plain = PlainTextComponentSerializer.plainText().serialize(loreLine);
      int uuidIndex = plain.indexOf("ID: ");
      if (uuidIndex >= 0) {
        String uuidStr = plain.substring(uuidIndex + 4).trim();
        try {
          return UUID.fromString(uuidStr);
        } catch (IllegalArgumentException ignored) {
        }
      }
    }
    return null;
  }

  private String extractValueFromLore(ItemStack item, String prefix) {
    if (item == null || !item.hasItemMeta()) return null;
    ItemMeta meta = item.getItemMeta();
    if (meta == null || meta.lore() == null) return null;

    for (Component loreLine : meta.lore()) {
      String plain = PlainTextComponentSerializer.plainText().serialize(loreLine);
      if (plain.startsWith(prefix)) {
        return plain.substring(prefix.length()).trim();
      }
    }
    return null;
  }

  private String getPlayerName(UUID id) {
    var offlinePlayer = Bukkit.getOfflinePlayer(id);
    return offlinePlayer.getName() != null ? offlinePlayer.getName() : id.toString();
  }

  public void openMenu(Player player) {
    openMainSocialMenu(player);
  }

  public void setActivityListener(ActivityRecommendationListener activityListener) {
    this.activityListener = activityListener;
    if (activityListener != null) {
      activityListener.setSocialMenuOpener(this::openMainSocialMenu);
    }
  }

  /** Supplies the activity service when feature services are initialized after listeners. */
  public void setActivityService(SocialActivityService activityService) {
    this.activityService = activityService;
  }

  public void setLeaderboardListener(SocialLeaderboardListener leaderboardListener) {
    this.leaderboardListener = leaderboardListener;
  }
}
