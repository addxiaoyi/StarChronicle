package dev.starcore.starcore.social.simulation;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseSettings;
import dev.starcore.starcore.core.database.DatabaseUtils;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * 社交活动服务
 *
 * <p>管理玩家的社交活动: - 聚会 (Party) - 庆典 (Celebration) - 比赛 (Competition) - 集会 (Gathering) - 社交任务
 */
public class SocialActivityService {

  private final Map<String, SocialActivity> activities = new ConcurrentHashMap<>();
  private final Map<UUID, Set<String>> playerActivities = new ConcurrentHashMap<>();
  private final Map<UUID, ActivityReward> pendingRewards = new ConcurrentHashMap<>();
  private final Object activityMutationLock = new Object();
  private final Set<String> pendingActivityWrites = new HashSet<>();

  private JavaPlugin plugin;
  private DatabaseService databaseService;
  private boolean isSQLite = false;

  /** 设置插件和数据库引用（用于持久化） */
  public void initialize(JavaPlugin plugin, DatabaseService databaseService) {
    this.plugin = plugin;
    this.databaseService = databaseService;
    if (databaseService != null) {
      initializeTables();
      loadAllActivities();
    }
  }

  private void initializeTables() {
    if (databaseService == null) return;

    try {
      Optional<javax.sql.DataSource> ds = databaseService.dataSource();
      if (ds.isPresent()) {
        isSQLite = DatabaseUtils.detectDatabaseType(ds.get()) == DatabaseUtils.DatabaseType.SQLITE;
      }
    } catch (Exception e) {
      isSQLite = false;
      if (plugin != null) {
        plugin
            .getLogger()
            .warning("Failed to detect database type, defaulting to MySQL: " + e.getMessage());
      }
    }

    String sql;
    if (isSQLite) {
      sql =
          """
          CREATE TABLE IF NOT EXISTS social_activities (
              id TEXT PRIMARY KEY,
              name TEXT NOT NULL,
              description TEXT,
              type TEXT NOT NULL,
              host TEXT NOT NULL,
              start_time INTEGER NOT NULL,
              duration INTEGER NOT NULL,
              status TEXT NOT NULL,
              max_participants INTEGER NOT NULL,
              metadata TEXT
          )
          """;
    } else {
      sql =
          """
          CREATE TABLE IF NOT EXISTS social_activities (
              id VARCHAR(100) PRIMARY KEY,
              name VARCHAR(100) NOT NULL,
              description TEXT,
              type VARCHAR(50) NOT NULL,
              host VARCHAR(36) NOT NULL,
              start_time BIGINT NOT NULL,
              duration BIGINT NOT NULL,
              status VARCHAR(20) NOT NULL,
              max_participants INT NOT NULL,
              metadata TEXT
          )
          """;
    }
    databaseService.execute(sql);

    // 活动参与者表
    String memberSql;
    if (isSQLite) {
      memberSql =
          """
          CREATE TABLE IF NOT EXISTS social_activity_participants (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              activity_id TEXT NOT NULL,
              player_uuid TEXT NOT NULL,
              joined_at INTEGER NOT NULL,
              UNIQUE(activity_id, player_uuid)
          )
          """;
    } else {
      memberSql =
          """
          CREATE TABLE IF NOT EXISTS social_activity_participants (
              id BIGINT AUTO_INCREMENT PRIMARY KEY,
              activity_id VARCHAR(100) NOT NULL,
              player_uuid VARCHAR(36) NOT NULL,
              joined_at BIGINT NOT NULL,
              UNIQUE KEY unique_participant (activity_id, player_uuid)
          )
          """;
    }
    databaseService.execute(memberSql);
  }

  private void loadAllActivities() {
    if (databaseService == null) return;

    String sql =
        "SELECT * FROM social_activities WHERE status != 'ENDED' AND status != 'CANCELLED'";
    databaseService.query(
        sql,
        rs -> {
          try {
            while (rs.next()) {
              String id = rs.getString("id");
              String name = rs.getString("name");
              String description = rs.getString("description");
              String typeStr = rs.getString("type");
              UUID host = UUID.fromString(rs.getString("host"));
              long startTime = rs.getLong("start_time");
              long duration = rs.getLong("duration");
              String statusStr = rs.getString("status");
              int maxParticipants = rs.getInt("max_participants");

              SocialActivityType type;
              try {
                type = SocialActivityType.valueOf(typeStr);
              } catch (Exception e) {
                type = SocialActivityType.PARTY;
              }

              ActivityStatus status;
              try {
                status = ActivityStatus.valueOf(statusStr);
              } catch (Exception e) {
                status = ActivityStatus.PREPARING;
              }

              // 加载参与者
              Set<UUID> participants = loadParticipants(id);
              Set<UUID> invited = new HashSet<>();

              SocialActivity activity =
                  new SocialActivity(
                      id,
                      name,
                      description,
                      type,
                      host,
                      startTime,
                      duration,
                      participants,
                      new HashSet<>(),
                      invited,
                      status,
                      maxParticipants,
                      new HashMap<>());
              activities.put(id, activity);

              // 更新玩家活动映射
              for (UUID p : participants) {
                playerActivities.computeIfAbsent(p, k -> new HashSet<>()).add(id);
              }
            }
          } catch (Exception e) {
            if (plugin != null) {
              plugin.getLogger().warning("Failed to load social activities: " + e.getMessage());
            }
          }
          return null;
        });
  }

  private Set<UUID> loadParticipants(String activityId) {
    Set<UUID> participants = new HashSet<>();
    String sql = "SELECT player_uuid FROM social_activity_participants WHERE activity_id = ?";
    databaseService.query(
        sql,
        rs -> {
          try {
            while (rs.next()) {
              participants.add(UUID.fromString(rs.getString("player_uuid")));
            }
          } catch (Exception e) {
            if (plugin != null) {
              plugin
                  .getLogger()
                  .warning(
                      "Failed to parse participant UUID for activity "
                          + activityId
                          + ": "
                          + e.getMessage());
            }
          }
          return null;
        },
        activityId);
    return participants;
  }

  private boolean saveActivityToDb(SocialActivity activity) {
    return executeTransaction(
        "save activity " + activity.id(),
        connection -> {
          String sql;
          if (isSQLite) {
            sql =
                "INSERT OR REPLACE INTO social_activities (id, name, description, type, host,"
                    + " start_time, duration, status, max_participants) VALUES (?, ?, ?, ?, ?, ?,"
                    + " ?, ?, ?)";
          } else {
            sql =
                """
INSERT INTO social_activities (id, name, description, type, host, start_time, duration, status, max_participants)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
ON DUPLICATE KEY UPDATE name = VALUES(name), description = VALUES(description), type = VALUES(type), host = VALUES(host), start_time = VALUES(start_time), duration = VALUES(duration), status = VALUES(status), max_participants = VALUES(max_participants)
""";
          }
          try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, activity.id());
            statement.setString(2, activity.name());
            statement.setString(3, activity.description());
            statement.setString(4, activity.type().name());
            statement.setString(5, activity.host().toString());
            statement.setLong(6, activity.startTime());
            statement.setLong(7, activity.duration());
            statement.setString(8, activity.status().name());
            statement.setInt(9, activity.maxParticipants());
            statement.executeUpdate();
          }

          try (PreparedStatement delete =
              connection.prepareStatement(
                  "DELETE FROM social_activity_participants WHERE activity_id = ?")) {
            delete.setString(1, activity.id());
            delete.executeUpdate();
          }

          if (!activity.participants().isEmpty()) {
            String insertSql =
                "INSERT INTO social_activity_participants (activity_id, player_uuid, joined_at)"
                    + " VALUES (?, ?, ?)";
            try (PreparedStatement insert = connection.prepareStatement(insertSql)) {
              long joinedAt = System.currentTimeMillis();
              for (UUID participant : activity.participants()) {
                insert.setString(1, activity.id());
                insert.setString(2, participant.toString());
                insert.setLong(3, joinedAt);
                insert.addBatch();
              }
              insert.executeBatch();
            }
          }
        });
  }

  private boolean deleteActivityFromDb(String activityId) {
    return executeTransaction(
        "delete activity " + activityId,
        connection -> {
          try (PreparedStatement deleteParticipants =
              connection.prepareStatement(
                  "DELETE FROM social_activity_participants WHERE activity_id = ?")) {
            deleteParticipants.setString(1, activityId);
            deleteParticipants.executeUpdate();
          }
          try (PreparedStatement deleteActivity =
              connection.prepareStatement("DELETE FROM social_activities WHERE id = ?")) {
            deleteActivity.setString(1, activityId);
            deleteActivity.executeUpdate();
          }
        });
  }

  private boolean executeTransaction(String operation, SqlTransaction transaction) {
    if (databaseService == null) return true;
    if (!databaseService.isRunning()) {
      DatabaseSettings settings = databaseService.settings();
      if (settings == null || !settings.enabled()) return true;
      logPersistenceFailure(operation, new IllegalStateException("Database is not running"));
      return false;
    }

    Connection connection = null;
    boolean previousAutoCommit = true;
    try {
      connection = databaseService.getConnection();
      previousAutoCommit = connection.getAutoCommit();
      connection.setAutoCommit(false);
      transaction.execute(connection);
      connection.commit();
      return true;
    } catch (Exception failure) {
      if (connection != null) {
        try {
          connection.rollback();
        } catch (SQLException rollbackFailure) {
          failure.addSuppressed(rollbackFailure);
        }
      }
      logPersistenceFailure(operation, failure);
      return false;
    } finally {
      if (connection != null) {
        try {
          connection.setAutoCommit(previousAutoCommit);
        } catch (SQLException resetFailure) {
          logPersistenceFailure(operation + " connection reset", resetFailure);
        }
        try {
          connection.close();
        } catch (SQLException closeFailure) {
          logPersistenceFailure(operation + " connection close", closeFailure);
        }
      }
    }
  }

  private void logPersistenceFailure(String operation, Exception failure) {
    java.util.logging.Logger logger =
        plugin != null
            ? plugin.getLogger()
            : java.util.logging.Logger.getLogger(getClass().getName());
    logger.log(
        java.util.logging.Level.WARNING,
        "SOCIAL_ACTIVITY_PERSISTENCE_FAILED " + operation,
        failure);
  }

  @FunctionalInterface
  private interface SqlTransaction {
    void execute(Connection connection) throws SQLException;
  }

  private void registerActivity(SocialActivity activity) {
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activity.id())) {
        throw new IllegalStateException("Social activity has a pending write: " + activity.id());
      }
      if (!saveActivityToDb(activity)) {
        throw new IllegalStateException("Failed to persist social activity " + activity.id());
      }
      publishActivity(activity);
    }
  }

  private void publishActivity(SocialActivity activity) {
    activities.put(activity.id(), activity);
    playerActivities.computeIfAbsent(activity.host(), key -> new HashSet<>()).add(activity.id());
  }

  private SocialActivity createPartyRecord(UUID host, String name, String description) {
    String id = "party_" + UUID.randomUUID();
    return new SocialActivity(
        id,
        name,
        description,
        SocialActivityType.PARTY,
        host,
        System.currentTimeMillis(),
        2 * 60 * 60 * 1000L,
        new HashSet<>(Set.of(host)),
        new HashSet<>(),
        new HashSet<>(),
        ActivityStatus.PREPARING,
        20,
        new HashMap<>());
  }

  private SocialActivity createCelebrationRecord(
      UUID host, String name, String description, int duration) {
    String id = "celebration_" + UUID.randomUUID();
    return new SocialActivity(
        id,
        name,
        description,
        SocialActivityType.CELEBRATION,
        host,
        System.currentTimeMillis(),
        duration * 60 * 60 * 1000L,
        new HashSet<>(Set.of(host)),
        new HashSet<>(),
        new HashSet<>(),
        ActivityStatus.PREPARING,
        100,
        new HashMap<>());
  }

  private SocialActivity createCompetitionRecord(
      UUID host, String name, String description, CompetitionType type) {
    String id = "comp_" + UUID.randomUUID();
    return new SocialActivity(
        id,
        name,
        description,
        SocialActivityType.COMPETITION,
        host,
        System.currentTimeMillis(),
        4 * 60 * 60 * 1000L,
        new HashSet<>(Set.of(host)),
        new HashSet<>(),
        new HashSet<>(),
        ActivityStatus.PREPARING,
        type.maxParticipants,
        Map.of("type", type.name()));
  }

  /** 创建聚会 */
  public String createParty(UUID host, String name, String description) {
    SocialActivity activity = createPartyRecord(host, name, description);
    registerActivity(activity);
    return activity.id();
  }

  /** 异步创建聚会，持久化成功后在主线程发布活动。 */
  public CompletableFuture<String> createPartyAsync(UUID host, String name, String description) {
    return createActivityAsync(createPartyRecord(host, name, description));
  }

  /** 创建庆典 */
  public String createCelebration(UUID host, String name, String description, int duration) {
    SocialActivity activity = createCelebrationRecord(host, name, description, duration);
    registerActivity(activity);
    return activity.id();
  }

  /** 异步创建庆典，持久化成功后在主线程发布活动。 */
  public CompletableFuture<String> createCelebrationAsync(
      UUID host, String name, String description, int duration) {
    return createActivityAsync(createCelebrationRecord(host, name, description, duration));
  }

  /** 创建比赛 */
  public String createCompetition(
      UUID host, String name, String description, CompetitionType type) {
    SocialActivity activity = createCompetitionRecord(host, name, description, type);
    registerActivity(activity);
    return activity.id();
  }

  /** 异步创建比赛，持久化成功后在主线程发布活动。 */
  public CompletableFuture<String> createCompetitionAsync(
      UUID host, String name, String description, CompetitionType type) {
    return createActivityAsync(createCompetitionRecord(host, name, description, type));
  }

  private CompletableFuture<String> createActivityAsync(SocialActivity activity) {
    synchronized (activityMutationLock) {
      if (activities.containsKey(activity.id()) || !pendingActivityWrites.add(activity.id())) {
        return CompletableFuture.failedFuture(
            new IllegalStateException("Social activity already exists: " + activity.id()));
      }
    }

    CompletableFuture<String> operation =
        persistActivityAsync(activity)
            .handle((saved, failure) -> new PersistenceOutcome(saved, failure))
            .thenCompose(
                outcome ->
                    runOnMainThread(
                        () -> {
                          try {
                            requirePersisted(outcome, "create activity " + activity.id());
                            synchronized (activityMutationLock) {
                              publishActivity(activity);
                            }
                            return activity.id();
                          } finally {
                            releasePendingWrite(activity.id());
                          }
                        }))
            .whenComplete((activityId, failure) -> releasePendingWrite(activity.id()));
    return operation.thenApply(activityId -> activityId);
  }

  private CompletableFuture<Boolean> persistActivityAsync(SocialActivity activity) {
    if (databaseService == null) return CompletableFuture.completedFuture(true);
    try {
      return databaseService.executeQueryAsync(() -> saveActivityToDb(activity));
    } catch (RuntimeException failure) {
      return CompletableFuture.failedFuture(failure);
    }
  }

  private void requirePersisted(PersistenceOutcome outcome, String operation) {
    if (outcome.failure() != null) {
      throw new CompletionException(outcome.failure());
    }
    if (!Boolean.TRUE.equals(outcome.saved())) {
      throw new CompletionException(new IllegalStateException("Failed to persist " + operation));
    }
  }

  private <T> CompletableFuture<T> runOnMainThread(Supplier<T> action) {
    if (plugin == null) {
      try {
        return CompletableFuture.completedFuture(action.get());
      } catch (RuntimeException failure) {
        return CompletableFuture.failedFuture(failure);
      }
    }

    CompletableFuture<T> result = new CompletableFuture<>();
    try {
      plugin
          .getServer()
          .getScheduler()
          .runTask(
              plugin,
              () -> {
                try {
                  result.complete(action.get());
                } catch (Throwable failure) {
                  result.completeExceptionally(failure);
                }
              });
    } catch (RuntimeException failure) {
      result.completeExceptionally(failure);
    }
    return result;
  }

  private void releasePendingWrite(String activityId) {
    synchronized (activityMutationLock) {
      pendingActivityWrites.remove(activityId);
    }
  }

  private record PersistenceOutcome(Boolean saved, Throwable failure) {}

  private SocialActivity copyActivity(SocialActivity activity) {
    return new SocialActivity(
        activity.id(),
        activity.name(),
        activity.description(),
        activity.type(),
        activity.host(),
        activity.startTime(),
        activity.duration(),
        new HashSet<>(activity.participants()),
        new HashSet<>(activity.applicants()),
        new HashSet<>(activity.invited()),
        activity.status(),
        activity.maxParticipants(),
        new HashMap<>(activity.metadata()));
  }

  /** 参加活动 */
  public boolean joinActivity(UUID playerId, String activityId) {
    SocialActivity updated;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return false;
      SocialActivity activity = activities.get(activityId);
      if (activity == null || activity.participants().contains(playerId)) return false;
      if (activity.participants().size() >= activity.maxParticipants()) return false;

      updated = copyActivity(activity);
      updated.participants().add(playerId);
      updated.applicants().remove(playerId);
      if (!saveActivityToDb(updated)) return false;
      activities.put(activityId, updated);
      playerActivities.computeIfAbsent(playerId, key -> new HashSet<>()).add(activityId);
    }

    broadcastActivity(updated, playerId + " 加入了活动！");

    return true;
  }

  /** 异步参加活动，数据库提交后再更新缓存和广播。 */
  public CompletableFuture<Boolean> joinActivityAsync(UUID playerId, String activityId) {
    SocialActivity original;
    SocialActivity updated;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId))
        return CompletableFuture.completedFuture(false);
      original = activities.get(activityId);
      if (original == null
          || original.participants().contains(playerId)
          || original.participants().size() >= original.maxParticipants()) {
        return CompletableFuture.completedFuture(false);
      }

      pendingActivityWrites.add(activityId);
      updated = copyActivity(original);
      updated.participants().add(playerId);
      updated.applicants().remove(playerId);
    }

    SocialActivity activitySnapshot = updated;
    SocialActivity originalSnapshot = original;
    CompletableFuture<Boolean> operation =
        persistActivityAsync(activitySnapshot)
            .handle((saved, failure) -> new PersistenceOutcome(saved, failure))
            .thenCompose(
                outcome ->
                    runOnMainThread(
                        () -> {
                          try {
                            requirePersisted(outcome, "join activity " + activityId);
                            synchronized (activityMutationLock) {
                              if (activities.get(activityId) != originalSnapshot) {
                                throw new IllegalStateException(
                                    "Social activity changed during pending write: " + activityId);
                              }
                              activities.put(activityId, activitySnapshot);
                              playerActivities
                                  .computeIfAbsent(playerId, key -> new HashSet<>())
                                  .add(activityId);
                            }
                            broadcastActivitySafely(activitySnapshot, playerId + " 加入了活动！");
                            return true;
                          } finally {
                            releasePendingWrite(activityId);
                          }
                        }))
            .whenComplete((joined, failure) -> releasePendingWrite(activityId));
    return operation.thenApply(joined -> joined);
  }

  /** 离开活动 */
  public boolean leaveActivity(UUID playerId, String activityId) {
    SocialActivity updated;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return false;
      SocialActivity activity = activities.get(activityId);
      if (activity == null || !activity.participants().contains(playerId)) return false;

      updated = copyActivity(activity);
      updated.participants().remove(playerId);
      if (!saveActivityToDb(updated)) return false;
      activities.put(activityId, updated);
      playerActivities.computeIfPresent(
          playerId,
          (id, activityIds) -> {
            activityIds.remove(activityId);
            return activityIds.isEmpty() ? null : activityIds;
          });
    }

    broadcastActivity(updated, playerId + " 离开了活动");

    return true;
  }

  /** 开始活动 */
  public boolean startActivity(String activityId) {
    SocialActivity started;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return false;
      SocialActivity activity = activities.get(activityId);
      if (activity == null || activity.participants().size() < 2) return false;

      started = withStatus(copyActivity(activity), ActivityStatus.ACTIVE);
      if (!saveActivityToDb(started)) return false;
      activities.put(activityId, started);
    }

    broadcastActivity(started, "活动开始了！");

    return true;
  }

  /** 结束活动 */
  public void endActivity(String activityId) {
    SocialActivity activity;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return;
      activity = activities.get(activityId);
      if (activity == null || !saveActivityToDb(withStatus(activity, ActivityStatus.ENDED))) return;
      if (!activities.remove(activityId, activity)) return;

      for (UUID participant : activity.participants()) {
        removePlayerActivity(participant, activityId);
      }
    }

    calculateAndDistributeRewards(activity);

    // 广播结束
    for (UUID participant : activity.participants()) {
      Player player = Bukkit.getPlayer(participant);
      if (player != null) {
        player.sendMessage("§6【活动结束】§e" + activity.name() + " §7已结束！");
      }
    }
  }

  /** 取消活动 */
  public void cancelActivity(String activityId) {
    SocialActivity activity;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return;
      activity = activities.get(activityId);
      if (activity == null || !deleteActivityFromDb(activityId)) return;
      if (!activities.remove(activityId, activity)) return;

      for (UUID participant : activity.participants()) {
        removePlayerActivity(participant, activityId);
      }
    }

    // 广播取消
    for (UUID participant : activity.participants()) {
      Player player = Bukkit.getPlayer(participant);
      if (player != null) {
        player.sendMessage("§c【活动取消】§e" + activity.name() + " §c已被取消！");
      }
    }
  }

  private SocialActivity withStatus(SocialActivity activity, ActivityStatus status) {
    return new SocialActivity(
        activity.id(),
        activity.name(),
        activity.description(),
        activity.type(),
        activity.host(),
        activity.startTime(),
        activity.duration(),
        activity.participants(),
        activity.applicants(),
        activity.invited(),
        status,
        activity.maxParticipants(),
        activity.metadata());
  }

  private void removePlayerActivity(UUID playerId, String activityId) {
    playerActivities.computeIfPresent(
        playerId,
        (id, activityIds) -> {
          activityIds.remove(activityId);
          return activityIds.isEmpty() ? null : activityIds;
        });
  }

  /** 计算并发放活动奖励 */
  private void calculateAndDistributeRewards(SocialActivity activity) {
    int participantCount = activity.participants().size();
    if (participantCount == 0) return;

    // 根据活动类型计算奖励
    int baseReputation =
        switch (activity.type()) {
          case PARTY -> 5;
          case CELEBRATION -> 10;
          case COMPETITION -> 15;
          case GATHERING -> 8;
          case SOCIAL_MISSION -> 12;
          case NETWORKING -> 10;
        };

    // 根据参与人数调整奖励
    int bonus = Math.min(10, participantCount / 5);

    for (UUID participant : activity.participants()) {
      ActivityReward reward =
          new ActivityReward(
              activity.id(),
              activity.type().getName(),
              baseReputation + bonus,
              activity.type().emoji(),
              System.currentTimeMillis());
      pendingRewards.put(participant, reward);

      // 通知玩家
      Player player = Bukkit.getPlayer(participant);
      if (player != null) {
        player.sendMessage("§6【活动奖励】§e你获得了 §a" + (baseReputation + bonus) + " §e点声誉值！");
      }
    }
  }

  /** 领取活动奖励 */
  public boolean claimReward(UUID playerId) {
    ActivityReward reward = pendingRewards.remove(playerId);
    if (reward == null) return false;

    // 奖励已经通过事件系统发放，这里只是标记已领取
    return true;
  }

  /** 获取待领取的奖励 */
  public ActivityReward getPendingReward(UUID playerId) {
    return pendingRewards.get(playerId);
  }

  /** 邀请玩家 */
  public void inviteToActivity(UUID inviterId, UUID targetId, String activityId) {
    SocialActivity activity;
    synchronized (activityMutationLock) {
      if (pendingActivityWrites.contains(activityId)) return;
      SocialActivity current = activities.get(activityId);
      if (current == null) return;

      activity = copyActivity(current);
      activity.invited().add(targetId);
      if (!saveActivityToDb(activity)) return;
      activities.put(activityId, activity);
    }

    Player target = Bukkit.getPlayer(targetId);
    if (target != null) {
      String inviterName =
          Bukkit.getPlayer(inviterId) != null ? Bukkit.getPlayer(inviterId).getName() : "一位玩家";
      target.sendMessage("§6§l【活动邀请】§e" + inviterName + " 邀请你参加: " + activity.name());
      target.sendMessage("§a使用 /activity accept " + activityId + " 接受邀请");
    }
  }

  /** 获取活动 */
  public Optional<SocialActivity> getActivity(String activityId) {
    return Optional.ofNullable(activities.get(activityId));
  }

  /** 获取玩家的活动 */
  public Set<String> getPlayerActivities(UUID playerId) {
    return playerActivities.getOrDefault(playerId, Set.of());
  }

  /** 获取所有活动 */
  public List<SocialActivity> getAllActivities() {
    return List.copyOf(activities.values());
  }

  /** 获取公开活动 */
  public List<SocialActivity> getPublicActivities() {
    return activities.values().stream()
        .filter(a -> a.status() == ActivityStatus.PREPARING || a.status() == ActivityStatus.ACTIVE)
        .sorted(Comparator.comparingLong(SocialActivity::startTime).reversed())
        .toList();
  }

  /** 广播活动消息 */
  private void broadcastActivity(SocialActivity activity, String message) {
    for (UUID participant : activity.participants()) {
      Player player = Bukkit.getPlayer(participant);
      if (player != null) {
        player.sendMessage("§6[§e" + activity.name() + "§6]§f " + message);
      }
    }
  }

  private void broadcastActivitySafely(SocialActivity activity, String message) {
    try {
      broadcastActivity(activity, message);
    } catch (RuntimeException failure) {
      java.util.logging.Logger logger =
          plugin != null
              ? plugin.getLogger()
              : java.util.logging.Logger.getLogger(getClass().getName());
      logger.log(
          java.util.logging.Level.WARNING,
          "SOCIAL_ACTIVITY_NOTIFICATION_FAILED " + activity.id(),
          failure);
    }
  }

  // ==================== 数据类 ====================

  public record SocialActivity(
      String id,
      String name,
      String description,
      SocialActivityType type,
      UUID host,
      long startTime,
      long duration,
      Set<UUID> participants,
      Set<UUID> applicants,
      Set<UUID> invited,
      ActivityStatus status,
      int maxParticipants,
      Map<String, Object> metadata) {
    public int participantCount() {
      return participants.size();
    }

    public boolean isActive() {
      return status == ActivityStatus.ACTIVE;
    }
  }

  public enum SocialActivityType {
    PARTY("聚会", "§b✦"),
    CELEBRATION("庆典", "§6✦"),
    COMPETITION("比赛", "§c⚔"),
    GATHERING("集会", "§a☺"),
    SOCIAL_MISSION("社交任务", "§d☰"),
    NETWORKING("社交联谊", "§e⚑");

    private final String name;
    private final String emoji;

    SocialActivityType(String name, String emoji) {
      this.name = name;
      this.emoji = emoji;
    }

    public String getName() {
      return name;
    }

    public String emoji() {
      return emoji;
    }
  }

  public enum ActivityStatus {
    PREPARING("准备中", "§e"),
    ACTIVE("进行中", "§a"),
    ENDED("已结束", "§7"),
    CANCELLED("已取消", "§c");

    private final String name;
    private final String color;

    ActivityStatus(String name, String color) {
      this.name = name;
      this.color = color;
    }

    public String getName() {
      return name;
    }

    public String color() {
      return color;
    }
  }

  public enum CompetitionType {
    DUEL(2, "决斗", "§c"),
    TOURNAMENT(16, "锦标赛", "§6"),
    BATTLE_ROYALE(32, "大乱斗", "§4"),
    SPORTS(20, "运动会", "§b"),
    QUIZ(50, "知识竞赛", "§e");

    private final int maxParticipants;
    private final String name;
    private final String color;

    CompetitionType(int max, String name, String color) {
      this.maxParticipants = max;
      this.name = name;
      this.color = color;
    }

    public int maxParticipants() {
      return maxParticipants;
    }

    public String getName() {
      return name;
    }

    public String color() {
      return color;
    }
  }

  /** 活动奖励记录 */
  public record ActivityReward(
      String activityId, String activityType, int reputationAmount, String emoji, long timestamp) {
    public String getDisplayText() {
      return emoji + " " + activityType + ": +" + reputationAmount + " 声誉";
    }
  }
}
