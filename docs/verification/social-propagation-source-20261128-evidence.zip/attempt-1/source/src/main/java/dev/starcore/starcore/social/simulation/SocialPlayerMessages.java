package dev.starcore.starcore.social.simulation;

import dev.starcore.starcore.foundation.gui.PlayerMenuTasks;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Captures the original session before asynchronous work and dispatches only to its owner. */
final class SocialPlayerMessages {
  private final JavaPlugin plugin;
  private final PlayerMenuTasks tasks;
  private volatile boolean closed;

  SocialPlayerMessages(JavaPlugin plugin) {
    this.plugin = plugin;
    tasks = new PlayerMenuTasks(plugin);
  }

  Player capture(UUID id) {
    return closed || id == null || !plugin.isEnabled() ? null : plugin.getServer().getPlayer(id);
  }

  CompletableFuture<String> name(Player original, UUID id) {
    String fallback = id == null ? "系统" : id.toString().substring(0, 8);
    if (original == null) return CompletableFuture.completedFuture(fallback);
    return tasks
        .call(original, null, original::getName)
        .handle((name, error) -> error != null || name == null || name.isBlank() ? fallback : name);
  }

  CompletableFuture<Void> send(Player original, String... lines) {
    if (closed || original == null)
      return CompletableFuture.failedFuture(
          new IllegalStateException("Original social recipient unavailable"));
    String[] snapshot = lines.clone();
    return tasks.execute(
        original,
        null,
        () -> {
          if (!closed) for (String line : snapshot) original.sendMessage(line);
        });
  }

  void close() {
    closed = true;
    tasks.shutdown();
  }
}
