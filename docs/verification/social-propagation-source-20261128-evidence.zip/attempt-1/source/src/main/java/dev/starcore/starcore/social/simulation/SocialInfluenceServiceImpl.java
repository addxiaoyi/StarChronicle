package dev.starcore.starcore.social.simulation;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseUtils;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/** 社会影响力服务实现 */
public class SocialInfluenceServiceImpl implements SocialInfluenceService {

  private final JavaPlugin plugin;
  private final ReputationService reputationService;
  private final RelationshipNetwork relationshipNetwork;
  private final DatabaseService databaseService;

  private final Map<UUID, Integer> influenceCache = new ConcurrentHashMap<>();
  private final Map<UUID, List<InfluenceSource>> influenceSources = new ConcurrentHashMap<>();
  private final Set<UUID> uncertainInfluence = ConcurrentHashMap.newKeySet();
  private final Object persistenceLock = new Object();
  private volatile boolean influenceLoaded;
  private BukkitTask decayTask;

  // 衰减配置
  private static final int DECAY_INTERVAL_TICKS = 1200 * 60; // 每小时衰减一次
  private static final double DECAY_RATE = 0.01; // 每次衰减1%

  public SocialInfluenceServiceImpl(
      JavaPlugin plugin,
      ReputationService reputationService,
      RelationshipNetwork relationshipNetwork,
      DatabaseService databaseService) {
    this.plugin = plugin;
    this.reputationService = reputationService;
    this.relationshipNetwork = relationshipNetwork;
    this.databaseService = databaseService;
    if (databaseService != null) {
      initializeTables();
      try {
        loadAllInfluence();
      } catch (Exception e) {
        plugin
            .getLogger()
            .log(java.util.logging.Level.SEVERE, "SOCIAL_INFLUENCE_READ_FAILED during startup", e);
      }
    }
  }

  private void initializeTables() {
    if (databaseService == null) return;
    // 检测数据库类型
    boolean isSQLite = false;
    try {
      Optional<javax.sql.DataSource> ds = databaseService.dataSource();
      if (ds.isPresent()) {
        isSQLite = DatabaseUtils.detectDatabaseType(ds.get()) == DatabaseUtils.DatabaseType.SQLITE;
      }
    } catch (Exception e) {
      plugin.getLogger().warning("检测数据库类型失败，使用 MySQL 语法: " + e.getMessage());
    }

    if (isSQLite) {
      String sql =
          """
          CREATE TABLE IF NOT EXISTS player_influence (
              player_id TEXT PRIMARY KEY,
              influence INTEGER DEFAULT 0,
              last_decay INTEGER
          )
          """;
      databaseService.execute(sql);
    } else {
      String sql =
          """
          CREATE TABLE IF NOT EXISTS player_influence (
              player_id VARCHAR(36) PRIMARY KEY,
              influence INT DEFAULT 0,
              last_decay BIGINT,
              UNIQUE KEY unique_player (player_id)
          )
          """;
      databaseService.execute(sql);
    }

    // 影响力来源表
    if (isSQLite) {
      String sourceSql =
          """
          CREATE TABLE IF NOT EXISTS influence_sources (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              player_id TEXT,
              source TEXT,
              amount INTEGER,
              timestamp INTEGER
          )
          """;
      databaseService.execute(sourceSql);
    } else {
      String sourceSql =
          """
          CREATE TABLE IF NOT EXISTS influence_sources (
              id BIGINT AUTO_INCREMENT PRIMARY KEY,
              player_id VARCHAR(36),
              source VARCHAR(100),
              amount INT,
              timestamp BIGINT
          )
          """;
      databaseService.execute(sourceSql);
    }
  }

  private void loadAllInfluence() {
    String sql = "SELECT * FROM player_influence";
    Map<UUID, Integer> loaded =
        databaseService.query(
            sql,
            rs -> {
              Map<UUID, Integer> values = new HashMap<>();
              try {
                while (rs.next()) {
                  UUID playerId = UUID.fromString(rs.getString("player_id"));
                  int influence = rs.getInt("influence");
                  if (rs.wasNull()) throw new SQLException("Null influence for " + playerId);
                  values.put(playerId, influence);
                }
              } catch (SQLException | IllegalArgumentException e) {
                throw new IllegalStateException("SOCIAL_INFLUENCE_READ_FAILED", e);
              }
              return values;
            });
    influenceCache.putAll(Objects.requireNonNull(loaded, "influence query returned null"));
    influenceLoaded = true;
  }

  @Override
  public int getInfluence(UUID playerId) {
    if (!influenceLoaded) {
      throw new IllegalStateException("SOCIAL_INFLUENCE_READ_FAILED");
    }
    if (uncertainInfluence.contains(playerId)) {
      throw new IllegalStateException("SOCIAL_INFLUENCE_RELOAD_REQUIRED");
    }
    return influenceCache.computeIfAbsent(playerId, this::loadInfluence);
  }

  private int loadInfluence(UUID playerId) {
    String sql = "SELECT influence FROM player_influence WHERE player_id = ?";
    try {
      List<Integer> results =
          databaseService.query(
              sql,
              rs -> {
                List<Integer> list = new ArrayList<>();
                try {
                  if (rs.next()) {
                    int influence = rs.getInt("influence");
                    if (rs.wasNull()) throw new SQLException("Null influence for " + playerId);
                    list.add(influence);
                  }
                } catch (SQLException e) {
                  throw new IllegalStateException("SOCIAL_INFLUENCE_READ_FAILED", e);
                }
                return list;
              },
              playerId.toString());

      return results.isEmpty() ? 0 : results.get(0);
    } catch (RuntimeException failure) {
      throw new IllegalStateException("SOCIAL_INFLUENCE_READ_FAILED", failure);
    }
  }

  @Override
  public SocialStatus getStatus(UUID playerId) {
    return SocialStatus.fromInfluence(getInfluence(playerId));
  }

  @Override
  public void addInfluence(UUID playerId, int amount, String source) {
    // SQLite serializes writers; keep the read/compute/influence-source writes atomic for
    // bursty join and gameplay events instead of allowing concurrent connections to contend.
    synchronized (persistenceLock) {
      int current = getInfluence(playerId);
      int newInfluence = Math.max(0, current + amount);
      Map<UUID, Integer> updates = new LinkedHashMap<>();
      updates.put(playerId, newInfluence);
      if (amount > 0) {
        collectPropagation(playerId, amount, new HashSet<>(), updates);
      }

      // 保存到数据库 - 使用 SQLite 兼容语法
      String sql;
      if (databaseService != null
          && "SQLITE".equalsIgnoreCase(databaseService.settings().type().name())) {
        // SQLite 使用 INSERT OR REPLACE
        sql =
            """
            INSERT INTO player_influence (player_id, influence, last_decay)
            VALUES (?, ?, ?)
            ON CONFLICT(player_id) DO UPDATE SET influence = excluded.influence
            """;
      } else {
        // MySQL 使用 ON DUPLICATE KEY UPDATE
        sql =
            """
            INSERT INTO player_influence (player_id, influence, last_decay)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE influence = VALUES(influence)
            """;
      }
      long timestamp = System.currentTimeMillis();
      persistInfluenceAndSource(playerId, updates, source, amount, timestamp, sql);
      influenceCache.putAll(updates);

      influenceSources
          .computeIfAbsent(playerId, k -> new ArrayList<>())
          .add(new InfluenceSource(source, amount, timestamp));
    }
  }

  private void persistInfluenceAndSource(
      UUID playerId,
      Map<UUID, Integer> updates,
      String source,
      int amount,
      long timestamp,
      String sql) {
    try {
      var dataSource =
          databaseService
              .dataSource()
              .orElseThrow(() -> new SQLException("Database not initialized"));
      try (Connection connection = dataSource.getConnection()) {
        connection.setAutoCommit(false);
        try {
          try (PreparedStatement statement = connection.prepareStatement(sql)) {
            for (var entry : updates.entrySet()) {
              statement.setString(1, entry.getKey().toString());
              statement.setInt(2, entry.getValue());
              statement.setLong(3, timestamp);
              statement.executeUpdate();
            }
          }
          try (PreparedStatement statement =
              connection.prepareStatement(
                  "INSERT INTO influence_sources (player_id, source, amount, timestamp) VALUES (?,"
                      + " ?, ?, ?)")) {
            statement.setString(1, playerId.toString());
            statement.setString(2, source);
            statement.setInt(3, amount);
            statement.setLong(4, timestamp);
            statement.executeUpdate();
          }
          connection.commit();
        } catch (SQLException | RuntimeException failure) {
          try {
            connection.rollback();
          } catch (SQLException rollbackFailure) {
            failure.addSuppressed(rollbackFailure);
          }
          throw failure;
        }
      }
    } catch (SQLException | RuntimeException failure) {
      uncertainInfluence.addAll(updates.keySet());
      throw new IllegalStateException("SOCIAL_INFLUENCE_WRITE_FAILED", failure);
    }
  }

  private void collectPropagation(
      UUID source, int amount, Set<UUID> visited, Map<UUID, Integer> updates) {
    if (visited.contains(source)) return;
    visited.add(source);

    // 获取源玩家的社交圈
    Set<UUID> friends = relationshipNetwork.getFriends(source);
    int influencePerFriend = amount / Math.max(1, friends.size());

    for (UUID friendId : friends) {
      if (visited.contains(friendId)) continue;

      // 给予朋友一定影响力
      int friendGain = influencePerFriend / 2; // 递减传播
      if (friendGain > 0) {
        int current =
            updates.containsKey(friendId) ? updates.get(friendId) : getInfluence(friendId);
        int newInfluence = Math.max(0, current + friendGain);
        updates.put(friendId, newInfluence);
      }

      // 继续传播 (最多2度)
      if (visited.size() < 10) {
        collectPropagation(friendId, influencePerFriend / 2, visited, updates);
      }
    }
  }

  @Override
  public void broadcastToInfluenceSphere(UUID source, String message, int maxReach) {
    Set<UUID> sphere = getInfluenceSphere(source, 3);
    SocialStatus sourceStatus = getStatus(source);

    for (UUID targetId : sphere) {
      Player target = Bukkit.getPlayer(targetId);
      if (target != null && target.isOnline()) {
        SocialStatus targetStatus = getStatus(targetId);
        // 高地位玩家更容易收到消息
        if (targetStatus.ordinal() >= SocialStatus.REGIONAL.ordinal()) {
          target.sendMessage(sourceStatus.getColor() + "【社会新闻】" + message);
        }
      }
    }
  }

  @Override
  public Set<UUID> getInfluenceSphere(UUID playerId, int levels) {
    Set<UUID> sphere = new HashSet<>();
    Set<UUID> visited = new HashSet<>();
    Queue<UUID> queue = new LinkedList<>();

    queue.offer(playerId);
    visited.add(playerId);
    sphere.add(playerId);

    int currentLevel = 0;
    while (!queue.isEmpty() && currentLevel < levels) {
      int size = queue.size();
      for (int i = 0; i < size; i++) {
        UUID current = queue.poll();
        Set<UUID> friends = relationshipNetwork.getFriends(current);
        for (UUID friend : friends) {
          if (!visited.contains(friend)) {
            visited.add(friend);
            queue.offer(friend);
            sphere.add(friend);
          }
        }
      }
      currentLevel++;
    }

    return sphere;
  }

  @Override
  public synchronized void startDecayTask() {
    if (decayTask != null) {
      return;
    }
    decayTask =
        plugin
            .getServer()
            .getScheduler()
            .runTaskTimerAsynchronously(
                plugin, this::applyDecay, DECAY_INTERVAL_TICKS, DECAY_INTERVAL_TICKS);
  }

  @Override
  public synchronized void startDecayTask(Function<Runnable, CompletableFuture<Void>> ioSubmitter) {
    Objects.requireNonNull(ioSubmitter, "ioSubmitter");
    if (decayTask != null) {
      return;
    }
    decayTask =
        plugin
            .getServer()
            .getScheduler()
            .runTaskTimer(
                plugin,
                () -> {
                  try {
                    Objects.requireNonNull(
                        ioSubmitter.apply(this::applyDecay), "I/O submission returned null");
                  } catch (RuntimeException failure) {
                    plugin
                        .getLogger()
                        .log(
                            java.util.logging.Level.SEVERE,
                            "SOCIAL_INFLUENCE_DECAY_SUBMISSION_FAILED",
                            failure);
                  }
                },
                DECAY_INTERVAL_TICKS,
                DECAY_INTERVAL_TICKS);
  }

  @Override
  public synchronized void stopDecayTask() {
    if (decayTask != null) {
      decayTask.cancel();
      decayTask = null;
    }
  }

  private void applyDecay() {
    synchronized (persistenceLock) {
      if (!influenceLoaded) return;
      for (UUID playerId : new ArrayList<>(influenceCache.keySet())) {
        if (uncertainInfluence.contains(playerId)) continue;
        int current = influenceCache.get(playerId);
        if (current > 0) {
          int decay = Math.max(1, (int) (current * DECAY_RATE));
          int newInfluence = Math.max(0, current - decay);
          String sql =
              "UPDATE player_influence SET influence = ?, last_decay = ? WHERE player_id = ?";
          try {
            databaseService.update(
                sql, newInfluence, System.currentTimeMillis(), playerId.toString());
          } catch (RuntimeException failure) {
            uncertainInfluence.add(playerId);
            throw failure;
          }
          influenceCache.put(playerId, newInfluence);
        }
      }
    }
  }

  record InfluenceSource(String source, int amount, long timestamp) {}
}
