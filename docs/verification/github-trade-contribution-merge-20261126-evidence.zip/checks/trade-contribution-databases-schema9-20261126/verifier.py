from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,zipfile,sys
root=Path(__file__).resolve().parents[1]
out=root/('run/trade-contribution-databases-'+sys.argv[1]+'-20261126');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
archive=root/'docs/verification/trade-contribution-linux-20261126-evidence.zip'
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('evidence-manifest.json'))
 assert set(z.namelist())==set(manifest)|{'evidence-manifest.json'}
 for name,digest in manifest.items():assert sha(z.read(name))==digest,name
 prefix='paper-trade-contribution-0e0fc515-20261126-3/evidence/boot3.data/'
 for folder,filename in [('StarChronicle','chronicle.db'),('StarCore','starcore.db')]:
  dest=out/'raw'/folder;dest.mkdir(parents=True)
  for suffix in ('','-wal','-shm'):
   name=prefix+folder+'/'+filename+suffix
   (dest/(filename+suffix)).write_bytes(z.read(name))
def backup(source,destination):
 with sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True) as db,sqlite3.connect(destination) as copy:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',);db.backup(copy)
def snapshot(path,previous=None):
 with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
  result={}
  for (table,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
   quoted='"'+table.replace('"','""')+'"'
   cols=previous[table]['columns'] if previous and table in previous else [r[1] for r in db.execute('PRAGMA table_info('+quoted+')')]
   selected=','.join('"'+c.replace('"','""')+'"' for c in cols)
   rows=sorted(json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in db.execute('SELECT '+selected+' FROM '+quoted))
   result[table]={'columns':cols,'count':len(rows),'sha256':sha(json.dumps(rows,ensure_ascii=False).encode())}
  return result
for name in ('legacy','upstream','fresh'):(out/name).mkdir()
backup(root/'run/native-trade-artifacts-final-20261126/chronicle.db',out/'legacy/chronicle.db')
backup(root/'run/native-trade-databases-20261126/upstream.db',out/'legacy/starcore.db')
backup(out/'raw/StarChronicle/chronicle.db',out/'upstream/chronicle.db')
backup(out/'raw/StarCore/starcore.db',out/'upstream/starcore.db')
backup(out/'raw/StarCore/starcore.db',out/'fresh/starcore.db')
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
chronicle=root/'target/starchronicle-0.1.0-SNAPSHOT.jar';native=root.parent/'StarChronicle-audit/starcore-all-stages/target/starcore-1.0.0.jar'
cp=';'.join(str(p) for p in [chronicle,native,*sorted((root/'run/paper-epic-1faf2ba2-dungeon-phases-2/libraries').rglob('*.jar'))])
probe=root/'run/MergedTradeContributionProbe.java';shutil.copy2(probe,out/probe.name)
argfile=out/'compile.args';argfile.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp,'-d',out,probe])+'\n',encoding='utf-8')
p=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(argfile)],capture_output=True);(out/'compile.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
results={}
for name in ('legacy','upstream','fresh'):
 dest=out/name;before={filename:snapshot(dest/filename) for filename in ('starcore.db','chronicle.db') if (dest/filename).exists()}
 (dest/'before.json').write_text(json.dumps(before,indent=2),encoding='utf-8');runs=[]
 for step in ('upgrade','reopen'):
  args=dest/(step+'.args');args.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-Dfile.encoding=UTF-8','-classpath',cp+';'+str(out),'io.github.addxiaoyi.starchronicle.integration.MergedTradeContributionProbe',dest/'starcore.db',dest/'chronicle.db','legacy' if name=='legacy' else 'journal'])+'\n',encoding='utf-8')
  p=subprocess.run([str(java/'java.exe'),'@'+str(args)],capture_output=True);(dest/(step+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,(name,step)
  runs.append(json.loads(next(line for line in p.stdout.decode().splitlines() if line.startswith('{'))))
 after={filename:snapshot(dest/filename,before.get(filename)) for filename in ('starcore.db','chronicle.db')}
 for filename,tables in before.items():
  for table,rows in tables.items():assert after[filename][table]==rows,(name,filename,table)
 assert runs[1]['accepted']==0 and runs[1]['pending']==0
 for field in ('cursor','contributions','events','contribution_revisions','trade_history_receipts','net'):assert runs[0][field]==runs[1][field],(name,field)
 expected=(134,534,0) if name=='legacy' else (141 if name=='upstream' else 139,534,554)
 assert (runs[0]['events'],runs[0]['contributions'],runs[0]['contribution_revisions'])==expected,(name,runs)
 assert runs[0]['accepted']==(139 if name=='fresh' else 0)
 (dest/'after.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
 backup(dest/'chronicle.db',dest/'downgrade-attempt.db')
 old=root/'run/trade-contribution-merge-baseline-20261126/starchronicle-0.1.0-SNAPSHOT.jar'
 oldcp=str(old)+cp[len(str(chronicle)):]+ ';'+str(root/'run/trade-contribution-downgrade-control-20261126')
 p=subprocess.run([str(java/'java.exe'),'-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-cp',oldcp,'TradeContributionDowngradeProbe',str(dest/'downgrade-attempt.db'),'refuse'],capture_output=True)
 (dest/'downgrade-refused.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(name,'old writer refusal')
 assert snapshot(dest/'downgrade-attempt.db')==after['chronicle.db']
 with sqlite3.connect(dest/'downgrade-attempt.db') as db:assert db.execute('PRAGMA user_version').fetchone()==(9,)
 results[name]={'runs':runs,'schema_version':9,'old_schema8_jar':'REFUSED_NEWER_SCHEMA_WITH_ROWS_UNCHANGED','unchanged_original_tables':{file:len(tables) for file,tables in before.items()},'added_tables':{file:sorted(set(after[file])-set(before.get(file,{}))) for file in after}}
summary={'status':'VERIFIED','chronicle_sha256':sha(chronicle.read_bytes()),'starcore_sha256':sha(native.read_bytes()),'archive_sha256':sha(archive.read_bytes()),'verified_upstream_manifest_files':len(manifest),'results':results,'limits':'Disposable database copies; paired actual services in six independent JVM runs, no Minecraft, assets or live audience. Upstream DB/WAL/SHM copied together and backed up consistently.'}
(out/'result.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
