package io.github.addxiaoyi.starchronicle.integration;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.resource.SimpleTradeHistoryService;
import io.github.addxiaoyi.starchronicle.api.contribution.*;
import io.github.addxiaoyi.starchronicle.core.RuleEngine;
import io.github.addxiaoyi.starchronicle.history.CommittedHistoryJournal;
import io.github.addxiaoyi.starchronicle.persistence.SqliteStore;
import java.sql.*;
import java.nio.file.Path;
import java.time.Clock;
import java.util.*;

/** Actual paired services over disposable database copies, with no Minecraft or asset calls. */
public class MergedTradeContributionProbe {
    public static void main(String[] args)throws Exception {
        DatabaseService database=new DatabaseService(null,null){
            @Override public Connection getConnection(){try{return DriverManager.getConnection("jdbc:sqlite:"+args[0]);}catch(SQLException e){throw new IllegalStateException(e);}}
        };
        var nativeHistory=new SimpleTradeHistoryService(database,null);
        try(var store=new SqliteStore(Path.of(args[1]))){
            var engine=new RuleEngine(store,List.of(),Clock.systemUTC());var journal=new CommittedHistoryJournal(store);
            var coordinator=new TradeHistoryCoordinator(engine,key->nativeHistory,journal);int accepted=0;
            for(int i=0;i<20;i++){int count=coordinator.poll(List.of());accepted+=count;if(count==0)break;if(i==19)throw new AssertionError("Unbounded recovery");}
            var legacy=engine.committedSourceCursor("starcore.trade");var modern=journal.cursor("starcore.trade");
            if(legacy.isPresent()==modern.isPresent())throw new AssertionError("Require exactly one trade cursor");
            if(!args[2].equals(legacy.isPresent()?"legacy":"journal"))throw new AssertionError("Wrong ledger selected");
            Map<String,Object> counts=store.transaction(c->{
                Map<String,Object> result=new TreeMap<>();
                for(String table:List.of("events","contributions","contribution_revisions","trade_history_receipts"))
                    try(var s=c.createStatement();var r=s.executeQuery("SELECT count(*) FROM "+table)){r.next();result.put(table,r.getLong(1));}
                return result;
            });
            Map<String,String> net=new TreeMap<>();
            var subjects=store.transaction(c->{List<String> result=new ArrayList<>();try(var s=c.createStatement();var r=s.executeQuery("SELECT DISTINCT subject_id FROM contributions ORDER BY subject_id")){while(r.next())result.add(r.getString(1));}return result;});
            for(String subject:subjects){
                Map<String,java.math.BigDecimal> sums=new TreeMap<>();
                for(int page=0;;page++){
                    var balances=engine.contributionBalances(subject,ContributionType.TRADE,page,100);
                    for(var balance:balances)sums.merge(balance.entry().request().unit(),balance.netAmount(),java.math.BigDecimal::add);
                    if(balances.size()<100)break;if(page>=100)throw new AssertionError("Unexpected fixture size");
                }
                for(var entry:sums.entrySet()){
                    var total=engine.contributionTotal(subject,ContributionType.TRADE,entry.getKey());
                    if(total.compareTo(entry.getValue())!=0)throw new AssertionError("Public total and balances differ");
                    net.put(subject+"/"+entry.getKey(),total.toPlainString());
                }
            }
            counts.put("accepted",accepted);counts.put("mode",args[2]);counts.put("cursor",legacy.isPresent()?legacy.get().sequence():modern.orElseThrow().sequence());
            counts.put("pending",journal.pending("starcore.trade",128).size());counts.put("net",net);
            System.out.println(SqliteStore.json(counts));
        }
    }
}
