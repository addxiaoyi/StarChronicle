package dev.starcore.starcore.core.scheduler;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;
import org.mockito.stubbing.Answer;

/** Models callbacks retained past cancellation without launching Paper/Folia. */
class FoliaCompatSchedulerLifecycleTest {
  private final Plugin plugin = mock(Plugin.class);
  private final BukkitScheduler paper = mock(BukkitScheduler.class);
  private final GlobalRegionScheduler global = mock(GlobalRegionScheduler.class);
  private final RegionScheduler region = mock(RegionScheduler.class);
  private final AsyncScheduler async = mock(AsyncScheduler.class);
  private final EntityScheduler owner = mock(EntityScheduler.class);
  private final Entity entity = mock(Entity.class);
  private final Location location = mock(Location.class);
  private final List<Registration> registrations = new ArrayList<>();
  private final List<Runnable> retired = new ArrayList<>();
  private MockedStatic<Bukkit> bukkit;

  private record Registration(Object task, Runnable tick) {
    void verifyCancelled() {
      if (task instanceof ScheduledTask t) verify(t).cancel();
      else verify((BukkitTask) task).cancel();
    }

    void verifyNotCancelled() {
      if (task instanceof ScheduledTask t) verify(t, never()).cancel();
      else verify((BukkitTask) task, never()).cancel();
    }

    void throwWhenCancelled(RuntimeException failure) {
      if (task instanceof ScheduledTask t) when(t.cancel()).thenThrow(failure);
      else doThrow(failure).when((BukkitTask) task).cancel();
    }
  }

  private Answer<Object> folia(int callback) {
    return i -> {
      ScheduledTask raw = mock(ScheduledTask.class);
      Consumer<ScheduledTask> operation = i.getArgument(callback);
      registrations.add(new Registration(raw, () -> operation.accept(raw)));
      return raw;
    };
  }

  @BeforeEach
  void setup() {
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(entity.getScheduler()).thenReturn(owner);
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(Bukkit::getScheduler).thenReturn(paper);
    bukkit.when(Bukkit::getGlobalRegionScheduler).thenReturn(global);
    bukkit.when(Bukkit::getRegionScheduler).thenReturn(region);
    bukkit.when(Bukkit::getAsyncScheduler).thenReturn(async);
    Answer<BukkitTask> paperAnswer =
        i -> {
          BukkitTask raw = mock(BukkitTask.class);
          registrations.add(new Registration(raw, i.getArgument(1)));
          return raw;
        };
    when(paper.runTask(eq(plugin), any(Runnable.class))).thenAnswer(paperAnswer);
    when(paper.runTaskLater(eq(plugin), any(Runnable.class), anyLong())).thenAnswer(paperAnswer);
    when(paper.runTaskTimer(eq(plugin), any(Runnable.class), anyLong(), anyLong()))
        .thenAnswer(paperAnswer);
    when(paper.runTaskAsynchronously(eq(plugin), any(Runnable.class))).thenAnswer(paperAnswer);
    when(paper.runTaskLaterAsynchronously(eq(plugin), any(Runnable.class), anyLong()))
        .thenAnswer(paperAnswer);
    when(paper.runTaskTimerAsynchronously(eq(plugin), any(Runnable.class), anyLong(), anyLong()))
        .thenAnswer(paperAnswer);
    when(global.run(eq(plugin), any())).thenAnswer(folia(1));
    when(global.runDelayed(eq(plugin), any(), anyLong())).thenAnswer(folia(1));
    when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong())).thenAnswer(folia(1));
    when(region.run(eq(plugin), eq(location), any())).thenAnswer(folia(2));
    when(region.runDelayed(eq(plugin), eq(location), any(), anyLong())).thenAnswer(folia(2));
    when(async.runNow(eq(plugin), any())).thenAnswer(folia(1));
    when(async.runDelayed(eq(plugin), any(), anyLong(), any())).thenAnswer(folia(1));
    when(async.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong(), any())).thenAnswer(folia(1));
    when(owner.run(eq(plugin), any(), nullable(Runnable.class)))
        .thenAnswer(
            i -> {
              retired.add(i.getArgument(2));
              return folia(1).answer(i);
            });
    when(owner.runDelayed(eq(plugin), any(), nullable(Runnable.class), anyLong()))
        .thenAnswer(
            i -> {
              retired.add(i.getArgument(2));
              return folia(1).answer(i);
            });
  }

  @AfterEach
  void closeBukkit() {
    bukkit.close();
  }

  private void cancelFromAnotherThread(FoliaCompatScheduler scheduler) throws Exception {
    CompletableFuture.runAsync(
            () -> {
              // Mockito static mocks are thread-local; the old Paper implementation uses Bukkit
              // here.
              try (MockedStatic<Bukkit> workerBukkit = mockStatic(Bukkit.class)) {
                workerBukkit.when(Bukkit::getScheduler).thenReturn(paper);
                scheduler.cancelAll();
              }
            })
        .get(3, TimeUnit.SECONDS);
  }

  private void scheduleAll(FoliaCompatScheduler scheduler, Runnable operation) {
    scheduler.runAtEntity(entity, ignored -> operation.run());
    scheduler.runAtLocation(location, ignored -> operation.run());
    scheduler.runAtLocationDelayed(location, ignored -> operation.run(), 2);
    scheduler.runAsync(operation);
    scheduler.runAsyncDelayed(operation, 1, TimeUnit.SECONDS);
    scheduler.runAsyncRepeating(operation, 1, 1, TimeUnit.SECONDS);
    scheduler.runGlobal(operation);
    scheduler.runEntityDelayed(entity, operation, 2);
    scheduler.runDelayed(operation, 2);
    scheduler.runGlobalDelayed(operation, 2);
    scheduler.runGlobalRepeating(operation, 1, 2);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void cancelsEveryBackendWithoutCancellingOtherPluginTasks(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    scheduleAll(scheduler, () -> {});
    scheduler.cancelAll();
    scheduler.cancelAll();
    assertEquals(11, registrations.size());
    registrations.forEach(Registration::verifyCancelled);
    verify(paper, never()).cancelTasks(any());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void cancelledCallbacksCannotExecuteEvenWhenThePlatformDeliversThemLate(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger calls = new AtomicInteger();
    scheduleAll(scheduler, calls::incrementAndGet);
    scheduler.cancelAll();
    registrations.forEach(r -> r.tick.run());
    assertEquals(0, calls.get());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void cancellingOneInstanceDoesNotCancelAnotherAndAllowsNewWork(boolean folia) {
    var first = new FoliaCompatScheduler(plugin, folia);
    var second = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger calls = new AtomicInteger();
    first.runGlobalRepeating(calls::incrementAndGet, 1, 1);
    second.runGlobalRepeating(calls::incrementAndGet, 1, 1);
    first.cancelAll();
    registrations.getFirst().tick.run();
    registrations.getLast().tick.run();
    assertEquals(1, calls.get());
    registrations.getLast().verifyNotCancelled();
    first.runGlobal(calls::incrementAndGet);
    registrations.getLast().tick.run();
    assertEquals(2, calls.get());
    second.cancelAll();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void completedOneShotCannotRunTwiceAndDoesNotRemainTracked(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger calls = new AtomicInteger();
    scheduler.runGlobal(calls::incrementAndGet);
    registrations.getFirst().tick.run();
    registrations.getFirst().tick.run();
    scheduler.cancelAll();
    assertEquals(1, calls.get());
    registrations.getFirst().verifyNotCancelled();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void failedRepeatingBodyStopsAndPreservesTheOriginalFailure(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    RuntimeException failure = new IllegalStateException("body");
    scheduler.runGlobalRepeating(
        () -> {
          throw failure;
        },
        1,
        1);
    assertSame(failure, assertThrows(RuntimeException.class, registrations.getFirst().tick::run));
    assertDoesNotThrow(registrations.getFirst().tick::run);
    registrations.getFirst().verifyCancelled();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void cancellationFailureDoesNotStopOtherTasksOrReviveItsCallback(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger calls = new AtomicInteger();
    scheduler.runGlobalRepeating(calls::incrementAndGet, 1, 1);
    scheduler.runGlobalRepeating(calls::incrementAndGet, 1, 1);
    registrations.getFirst().throwWhenCancelled(new IllegalStateException("cancel"));
    assertDoesNotThrow(scheduler::cancelAll);
    registrations.getLast().verifyCancelled();
    registrations.forEach(r -> r.tick.run());
    assertEquals(0, calls.get());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void cancellationFromAnotherThreadBeforePublicationCancelsTheLateTask(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    AtomicInteger calls = new AtomicInteger();
    if (folia) {
      when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                Object raw = folia(1).answer(i);
                cancelFromAnotherThread(scheduler);
                return raw;
              });
    } else {
      when(paper.runTaskTimer(eq(plugin), any(Runnable.class), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                BukkitTask raw = mock(BukkitTask.class);
                registrations.add(new Registration(raw, i.getArgument(1)));
                cancelFromAnotherThread(scheduler);
                return raw;
              });
    }
    scheduler.runGlobalRepeating(calls::incrementAndGet, 1, 1);
    registrations.getFirst().verifyCancelled();
    registrations.getFirst().tick.run();
    assertEquals(0, calls.get());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void bodyFailureIsNotReplacedByBackendCancellationFailure(boolean folia) {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    RuntimeException body = new IllegalStateException("body"),
        cleanup = new IllegalStateException("cancel");
    scheduler.runGlobalRepeating(
        () -> {
          throw body;
        },
        1,
        1);
    registrations.getFirst().throwWhenCancelled(cleanup);
    assertSame(body, assertThrows(RuntimeException.class, registrations.getFirst().tick::run));
    assertArrayEquals(new Throwable[] {cleanup}, body.getSuppressed());
  }

  @Test
  void entityRetirementSuppressesBothImmediateAndDelayedCallbacks() {
    var scheduler = new FoliaCompatScheduler(plugin, true);
    AtomicInteger calls = new AtomicInteger();
    scheduler.runAtEntity(entity, t -> calls.incrementAndGet());
    scheduler.runEntityDelayed(entity, calls::incrementAndGet, 2);
    retired.forEach(r -> assertNotNull(r, "Entity retirement must release tracking"));
    retired.forEach(Runnable::run);
    registrations.forEach(r -> r.tick.run());
    assertEquals(0, calls.get());
    registrations.forEach(Registration::verifyCancelled);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void registrationFailureSuppressesCapturedCallbacksAndReleasesTracking(boolean folia)
      throws Exception {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    RuntimeException rejected = new IllegalStateException("registration");
    if (folia) {
      when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                folia(1).answer(i);
                throw rejected;
              });
    } else {
      when(paper.runTaskTimer(eq(plugin), any(Runnable.class), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                registrations.add(new Registration(mock(BukkitTask.class), i.getArgument(1)));
                throw rejected;
              });
    }
    AtomicInteger calls = new AtomicInteger();
    assertSame(
        rejected,
        assertThrows(
            RuntimeException.class,
            () -> scheduler.runGlobalRepeating(calls::incrementAndGet, 1, 1)));
    registrations.getFirst().tick.run();
    assertEquals(0, calls.get());
    assertEquals(0, tracked(scheduler));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void nullRegistrationReleasesTracking(boolean folia) throws Exception {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    if (folia) when(global.run(eq(plugin), any())).thenReturn(null);
    else when(paper.runTask(eq(plugin), any(Runnable.class))).thenReturn(null);
    scheduler.runGlobal(() -> fail("not registered"));
    assertEquals(0, tracked(scheduler));
  }

  private int tracked(FoliaCompatScheduler scheduler) throws Exception {
    var field = FoliaCompatScheduler.class.getDeclaredField("tasks");
    field.setAccessible(true);
    return ((Set<?>) field.get(scheduler)).size();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void earlyCallbackCanCancelBeforeItsBackendHandleReturns(boolean folia) throws Exception {
    var scheduler = new FoliaCompatScheduler(plugin, folia);
    if (folia) {
      when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                Object raw = folia(1).answer(i);
                registrations.getFirst().tick.run();
                return raw;
              });
    } else {
      when(paper.runTaskTimer(eq(plugin), any(Runnable.class), anyLong(), anyLong()))
          .thenAnswer(
              i -> {
                BukkitTask raw = mock(BukkitTask.class);
                registrations.add(new Registration(raw, i.getArgument(1)));
                registrations.getFirst().tick.run();
                return raw;
              });
    }
    scheduler.runGlobalRepeating(scheduler::cancelAll, 1, 1);
    registrations.getFirst().verifyCancelled();
    assertEquals(0, tracked(scheduler));
  }
}
