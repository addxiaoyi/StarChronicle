package dev.starcore.starcore.essentials;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.data.EssentialsDataManager;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.message.MessageService;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.MockedConstruction;

class EssentialsModuleLifecycleTest {
  private final Plugin plugin = mock(Plugin.class, RETURNS_DEEP_STUBS);
  private final StarCoreContext context = mock(StarCoreContext.class, RETURNS_DEEP_STUBS);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final EconomyService economy = mock(EconomyService.class);
  private final List<Runnable> callbacks = new ArrayList<>();
  private EssentialsModule module;
  private MockedConstruction<EssentialsDataManager> managers;

  @BeforeEach
  void setup() {
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(context.configuration().getConfig()).thenReturn(new YamlConfiguration());
    when(economy.getAllBalances()).thenReturn(Map.of());
    doAnswer(
            i -> {
              callbacks.add(i.getArgument(0));
              return null;
            })
        .when(scheduler)
        .runGlobalRepeating(any(), anyLong(), anyLong());
    managers = mockConstruction(EssentialsDataManager.class);
    module = new EssentialsModule(plugin, scheduler, mock(MessageService.class), economy);
  }

  @AfterEach
  void cleanup() {
    managers.close();
  }

  @Test
  void disableCancelsScheduledWorkBeforeTheFinalSaveAndIsIdempotent() {
    module.enable(context);
    EssentialsDataManager manager = managers.constructed().getFirst();
    module.disable(context);
    module.disable(context);
    var order = inOrder(scheduler, manager);
    order.verify(scheduler).cancelAll();
    order.verify(manager).shutdownAndSave();
    verify(scheduler, times(1)).cancelAll();
    verify(manager, times(1)).shutdownAndSave();
  }

  @Test
  void disabledCapturedTimersCannotSaveOrReadEconomy() {
    module.enable(context);
    module.disable(context);
    callbacks.forEach(Runnable::run);
    verify(managers.constructed().getFirst(), never()).saveAllAsync();
    verify(economy, never()).getAllBalances();
  }

  @Test
  void previousEnableTimersCannotUseTheNewManagers() {
    module.enable(context);
    List<Runnable> old = List.copyOf(callbacks);
    module.disable(context);
    module.enable(context);
    old.forEach(Runnable::run);
    managers.constructed().forEach(m -> verify(m, never()).saveAllAsync());
    verify(economy, never()).getAllBalances();
    callbacks.get(2).run();
    callbacks.get(3).run();
    verify(managers.constructed().getLast()).saveAllAsync();
    verify(economy).getAllBalances();
    module.disable(context);
  }

  @Test
  void duplicateEnableDoesNotCreateWritersOrTimers() {
    module.enable(context);
    module.enable(context);
    assertEquals(1, managers.constructed().size());
    assertEquals(2, callbacks.size());
    module.disable(context);
  }

  @Test
  void partialTimerRegistrationFailureCancelsAndDrainsTheWriter() {
    RuntimeException rejected = new IllegalStateException("second timer");
    doAnswer(
            i -> {
              callbacks.add(i.getArgument(0));
              if (callbacks.size() == 2) throw rejected;
              return null;
            })
        .when(scheduler)
        .runGlobalRepeating(any(), anyLong(), anyLong());
    assertSame(rejected, assertThrows(RuntimeException.class, () -> module.enable(context)));
    verify(scheduler).cancelAll();
    verify(managers.constructed().getFirst()).shutdownAndSave();
    callbacks.forEach(Runnable::run);
    verify(economy, never()).getAllBalances();
  }
}
