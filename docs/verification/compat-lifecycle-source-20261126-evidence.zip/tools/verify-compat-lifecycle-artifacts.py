from pathlib import Path
import hashlib, json, subprocess, zipfile

root = Path(__file__).resolve().parents[1]
native = root.parent/'StarChronicle-audit/starcore-all-stages'
out = root/'run/compat-lifecycle-artifacts-20261126'
out.mkdir(exist_ok=False)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
old = root/'run/compat-lifecycle-baseline-20261126/starcore.jar'
jar = native/'target/starcore-1.0.0.jar'
classes = native/'target/classes'
checked = {}
paths = [('dev/starcore/starcore/core/scheduler','FoliaCompatScheduler'),('dev/starcore/starcore/essentials','EssentialsModule')]
with zipfile.ZipFile(jar) as archive:
    for directory, stem in paths:
        for path in sorted((classes/directory).glob(stem+'*.class')):
            name = path.relative_to(classes).as_posix()
            raw = path.read_bytes()
            assert archive.read(name) == raw, name
            assert int.from_bytes(raw[6:8],'big') == 65, name
            checked[name] = sha(raw)
    assert len(checked) == 3

source_hashes = {}
for directory, stem in paths:
    for source_type, file_name in [('main',stem+'.java'),('test',stem+'LifecycleTest.java')]:
        path = native/'src'/source_type/'java'/directory/file_name
        raw = path.read_bytes()
        assert raw == (root/'run/compat-lifecycle-compile-20261126'/file_name).read_bytes(), file_name
        source_hashes[path.relative_to(native).as_posix()] = sha(raw)

javap = Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin\javap.exe')
apis = {}
for directory, stem in paths:
    outputs = []
    for label, artifact in (('old',old),('current',jar)):
        result = subprocess.run([str(javap),'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),directory.replace('/','.')+'.'+stem],capture_output=True,check=True)
        (out/(label+'-'+stem+'.txt')).write_bytes(result.stdout)
        outputs.append(result.stdout.replace(b'synchronized ',b''))
    assert outputs[0] == outputs[1], stem
    apis[stem] = sha(outputs[1])
summary = {'status':'VERIFIED','starcore_sha256':sha(jar.read_bytes()),'baseline_sha256':sha(old.read_bytes()),
    'class_hashes':checked,'compiled_source_hashes':source_hashes,'public_api_hashes':apis,
    'api_comparison':'Public descriptors and declarations match; synchronized modifier added to Essentials lifecycle is normalized for comparison.',
    'sbom_components':len(json.loads((native/'target/starcore-1.0.0-sbom.json').read_text())['components']),
    'limits':['No live platform compatibility claim.','Previous shared-periodic regression and multi-JVM contracts retain their original artifact identities.']}
assert summary['sbom_components'] == 36
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
