import hashlib, json, runpy, shutil, sqlite3, subprocess, sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
helpers=runpy.run_path(str(root/'tools/run-capacity-contract.py'))
tables,sha=helpers['original_tables'],helpers['sha']
output=root/'run/capacity-backup-20261126'
output.mkdir(exist_ok=False)
source=output/'live-source.db'
backup=output/'consistent-backup.db'
shutil.copy2(root/'run/capacity-contract-20261126-2/schema7.db',source)
writer=sqlite3.connect(source)
try:
    writer.execute('PRAGMA journal_mode=WAL')
    writer.execute("INSERT INTO facts VALUES('WORLD','capacity.backup-test','committed-only-in-wal')")
    writer.commit()
    wal=Path(str(source)+'-wal')
    assert wal.is_file() and wal.stat().st_size>0
    immutable=sqlite3.connect(source.as_uri()+'?mode=ro&immutable=1',uri=True)
    try:
        assert immutable.execute("SELECT COUNT(*) FROM facts WHERE key='capacity.backup-test'").fetchone()[0]==0
    finally:
        immutable.close()
    original=tables(source)
    bytes_before={'main':sha(source),'wal':sha(wal)}
    args=[sys.executable,str(root/'tools/inspect-capacity.py'),str(source),'--backup',str(backup)]
    result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',timeout=150)
    (output/'backup.log').write_text(result.stdout+result.stderr,encoding='utf-8')
    assert result.returncode==0,result.stderr
    report=json.loads(result.stdout)
    assert report['backup']['integrity_check']=='ok'
    assert tables(backup)==original==tables(source)
    assert bytes_before=={'main':sha(source),'wal':sha(wal)},'Read-only backup changed source bytes'
    fingerprint=sha(backup)
    for label,destination in [('existing-backup',backup),('source-as-backup',source)]:
        refused=subprocess.run([sys.executable,str(root/'tools/inspect-capacity.py'),str(source),'--backup',str(destination)],capture_output=True,text=True,encoding='utf-8',timeout=150)
        (output/(label+'.log')).write_text(refused.stdout+refused.stderr,encoding='utf-8')
        assert refused.returncode!=0 and 'FileExistsError' in refused.stderr
        assert fingerprint==sha(backup)
        assert bytes_before=={'main':sha(source),'wal':sha(wal)}
    summary={'status':'PASS','source_wal_bytes_preserved':True,'wal_only_fact_in_backup':True,'all_tables_preserved':len(original),
             'overwrite_refusals':['existing-backup','source-as-backup'],'backup_sha256':fingerprint,'source_bytes_before':bytes_before,
             'database_report':report,'table_fingerprints':original}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k not in ('table_fingerprints','database_report')},ensure_ascii=False))
finally:
    writer.close()
