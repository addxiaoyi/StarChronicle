package dev.starcore.starcore.integration.typewriter;

import java.util.Optional;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Typewriter 集成 支持任务系统、对话系统、剧情系统
 *
 * <p>Typewriter 是一个强大的任务和对话插件 官网: https://github.com/gabber235/Typewriter
 */
public final class TypewriterIntegration {
  private final Plugin plugin;
  private boolean enabled = false;

  // Typewriter API 引用
  private Object typewriterPlugin;

  public TypewriterIntegration(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 初始化集成 */
  public boolean init() {
    enabled = false;
    typewriterPlugin = null;
    try {
      // 检测 Typewriter 插件
      Plugin typewriter = plugin.getServer().getPluginManager().getPlugin("Typewriter");
      if (typewriter == null) {
        plugin.getLogger().info("⚠ Typewriter 未安装");
        return false;
      }

      if (!plugin.getServer().getPluginManager().isPluginEnabled("Typewriter")) {
        plugin.getLogger().warning("⚠ Typewriter 已安装但未启用");
        return false;
      }

      // 检查 API 类是否存在
      try {
        Class.forName("me.gabber235.typewriter.Typewriter");
        Class.forName("me.gabber235.typewriter.entry.Entry");
        Class.forName("me.gabber235.typewriter.entry.Quest");
      } catch (ClassNotFoundException e) {
        plugin.getLogger().warning("⚠ Typewriter API 未找到（可能版本不兼容）");
        return false;
      }

      this.typewriterPlugin = typewriter;
      this.enabled = true;
      plugin.getLogger().info("✅ Typewriter 集成已启用");
      return true;

    } catch (Exception e) {
      plugin.getLogger().warning("⚠ Typewriter 集成初始化失败: " + e.getMessage());
      return false;
    }
  }

  /** 触发对话 */
  public boolean triggerDialogue(Player player, String dialogueId) {
    Optional<String> id = validPlayerCommandId(player, dialogueId);
    if (id.isEmpty()) {
      return false;
    }

    return dispatch("触发对话", "tw trigger " + player.getUniqueId() + " " + id.get());
  }

  /** 开始任务 */
  public boolean startQuest(Player player, String questId) {
    Optional<String> id = validPlayerCommandId(player, questId);
    if (id.isEmpty()) {
      return false;
    }

    return dispatch("开始任务", "tw quest start " + player.getUniqueId() + " " + id.get());
  }

  /** 完成任务 */
  public boolean completeQuest(Player player, String questId) {
    Optional<String> id = validPlayerCommandId(player, questId);
    if (id.isEmpty()) {
      return false;
    }

    return dispatch("完成任务", "tw quest complete " + player.getUniqueId() + " " + id.get());
  }

  /** 检查任务状态 */
  public boolean hasCompletedQuest(Player player, String questId) {
    Optional<String> id = validPlayerCommandId(player, questId);
    if (id.isEmpty()) {
      return false;
    }

    try {
      return player.hasPermission("typewriter.quest." + id.get() + ".completed");
    } catch (RuntimeException exception) {
      plugin.getLogger().warning("检查任务完成状态失败: " + exception.getMessage());
      return false;
    }
  }

  /** 检查任务是否进行中 */
  public boolean isQuestActive(Player player, String questId) {
    Optional<String> id = validPlayerCommandId(player, questId);
    if (id.isEmpty()) {
      return false;
    }

    try {
      return player.hasPermission("typewriter.quest." + id.get() + ".active");
    } catch (RuntimeException exception) {
      plugin.getLogger().warning("检查任务进行状态失败: " + exception.getMessage());
      return false;
    }
  }

  /** 触发事件 */
  public boolean triggerEvent(Player player, String eventId) {
    Optional<String> id = validPlayerCommandId(player, eventId);
    if (id.isEmpty()) {
      return false;
    }

    return dispatch("触发事件", "tw event " + player.getUniqueId() + " " + id.get());
  }

  /** 设置任务目标进度 */
  public boolean setQuestProgress(Player player, String questId, String objectiveId, int progress) {
    Optional<String> quest = validPlayerCommandId(player, questId);
    Optional<String> objective = normalizeIdentifier(objectiveId);
    if (quest.isEmpty() || objective.isEmpty() || progress < 0) {
      return false;
    }

    return dispatch(
        "设置任务进度",
        String.format(
            "tw quest progress %s %s %s %d",
            player.getUniqueId(), quest.get(), objective.get(), progress));
  }

  /** 播放剧情 */
  public boolean playCinematic(Player player, String cinematicId) {
    Optional<String> id = validPlayerCommandId(player, cinematicId);
    if (id.isEmpty()) {
      return false;
    }

    return dispatch("播放剧情", "tw cinematic " + player.getUniqueId() + " " + id.get());
  }

  /** 显示标题消息（Typewriter 样式） */
  public boolean showTitle(Player player, String title, String subtitle) {
    if (!enabled || player == null) {
      return false;
    }

    try {
      player.sendTitle(title, subtitle, 10, 70, 20);
      return true;
    } catch (RuntimeException exception) {
      plugin.getLogger().warning("显示标题失败: " + exception.getMessage());
      return false;
    }
  }

  /** 添加任务标记 */
  public boolean addQuestMarker(Player player, String questId, org.bukkit.Location location) {
    // The available Typewriter API surface has no marker operation; do not report a fake success.
    return false;
  }

  /** 移除任务标记 */
  public boolean removeQuestMarker(Player player, String questId) {
    // The available Typewriter API surface has no marker operation; do not report a fake success.
    return false;
  }

  /** 重载 Typewriter */
  public boolean reload() {
    if (!enabled) {
      return false;
    }

    return dispatch("重载 Typewriter", "tw reload");
  }

  /** 是否已启用 */
  public boolean isEnabled() {
    return enabled;
  }

  /** 获取 Typewriter 插件实例 */
  public Optional<Plugin> getTypewriterPlugin() {
    return Optional.ofNullable((Plugin) typewriterPlugin);
  }

  private Optional<String> validPlayerCommandId(Player player, String value) {
    if (!enabled || player == null || player.getUniqueId() == null) {
      return Optional.empty();
    }
    return normalizeIdentifier(value);
  }

  private Optional<String> normalizeIdentifier(String value) {
    if (value == null) {
      return Optional.empty();
    }

    String normalized = value.trim();
    if (normalized.isEmpty()) {
      return Optional.empty();
    }
    for (int offset = 0; offset < normalized.length(); ) {
      int codePoint = normalized.codePointAt(offset);
      if (Character.isWhitespace(codePoint)
          || Character.isISOControl(codePoint)
          || codePoint == '"'
          || codePoint == '\''
          || codePoint == '`'
          || codePoint == ';'
          || codePoint == '|'
          || codePoint == '&') {
        return Optional.empty();
      }
      offset += Character.charCount(codePoint);
    }
    return Optional.of(normalized);
  }

  private boolean dispatch(String action, String command) {
    try {
      return plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), command);
    } catch (RuntimeException exception) {
      plugin.getLogger().warning(action + "失败: " + exception.getMessage());
      return false;
    }
  }
}
