package dev.starcore.starcore;

import dev.starcore.starcore.achievement.AchievementModule;
import dev.starcore.starcore.api.StarCoreApi;
import dev.starcore.starcore.api.StarCoreApiProvider;
import dev.starcore.starcore.audit.AuditLogService;
import dev.starcore.starcore.clan.ClanManager;
import dev.starcore.starcore.command.StarCoreCommand;
import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.cache.CacheManager;
import dev.starcore.starcore.core.config.ConfigurationService;
import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.event.redis.RedisCrossServerService;
import dev.starcore.starcore.core.extension.ExtensionRegistry;
import dev.starcore.starcore.core.metrics.PerformanceMetricsService;
import dev.starcore.starcore.core.module.ModuleManager;
import dev.starcore.starcore.core.monitoring.PrometheusHttpMetricsReceiver;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.platform.PlatformAdapter;
import dev.starcore.starcore.core.platform.PlatformAdapterFactory;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.death.DeathMessageService;
import dev.starcore.starcore.death.DeathMessagesCommand;
import dev.starcore.starcore.death.DeathMessagesListener;
import dev.starcore.starcore.essentials.EssentialsModule;
import dev.starcore.starcore.foundation.animation.ScreenShake;
import dev.starcore.starcore.foundation.animation.ScreenShakeManager;
import dev.starcore.starcore.foundation.animation.SoundFeedbackManager;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.PlayerVaultEconomyService;
import dev.starcore.starcore.foundation.economy.extension.EconomyTransactionExtensionPoint;
import dev.starcore.starcore.foundation.epoch.EpochService;
import dev.starcore.starcore.foundation.feedback.ParticleFeedbackCommand;
import dev.starcore.starcore.foundation.feedback.ParticleFeedbackListener;
import dev.starcore.starcore.foundation.feedback.ParticleFeedbackService;
import dev.starcore.starcore.foundation.gui.BaseGuiListener;
import dev.starcore.starcore.foundation.gui.NavigationHubMenu;
import dev.starcore.starcore.foundation.hud.HudCommand;
import dev.starcore.starcore.foundation.hud.ModernHudListener;
import dev.starcore.starcore.foundation.i18n.I18nManager;
import dev.starcore.starcore.foundation.message.MessageService;
import dev.starcore.starcore.foundation.message.SimpleMessageService;
import dev.starcore.starcore.foundation.permission.InternalPermissionService;
import dev.starcore.starcore.foundation.player.BukkitOnlinePlayerDirectory;
import dev.starcore.starcore.foundation.player.InMemoryPlayerProfileService;
import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.foundation.player.PlayerProfileService;
import dev.starcore.starcore.foundation.protection.ExternalProtectionService;
import dev.starcore.starcore.foundation.protection.ExternalProtectionServices;
import dev.starcore.starcore.foundation.sound.SceneSoundCommand;
import dev.starcore.starcore.foundation.sound.SceneSoundConfig;
import dev.starcore.starcore.foundation.sound.SceneSoundService;
import dev.starcore.starcore.foundation.territory.DatabaseAwareTerritoryService;
import dev.starcore.starcore.foundation.territory.TerritoryService;
import dev.starcore.starcore.foundation.timesync.TimeSyncService;
import dev.starcore.starcore.foundation.tooltip.SmartTooltipService;
import dev.starcore.starcore.foundation.tooltip.TooltipModule;
import dev.starcore.starcore.mechanics.ReligionService;
import dev.starcore.starcore.mechanics.SeasonService;
import dev.starcore.starcore.module.anniversary.AnniversaryModule;
import dev.starcore.starcore.module.army.ArmyModule;
import dev.starcore.starcore.module.army.doctrine.DoctrineModule;
import dev.starcore.starcore.module.army.exercise.ExerciseModule;
import dev.starcore.starcore.module.army.mercenary.MercenaryModule;
import dev.starcore.starcore.module.army.navy.NavyModule;
import dev.starcore.starcore.module.banner.BannerModule;
import dev.starcore.starcore.module.blueprint.BlueprintModule;
import dev.starcore.starcore.module.city.CityModule;
import dev.starcore.starcore.module.city.gui.CityMenuGui;
import dev.starcore.starcore.module.combat.CombatModule;
import dev.starcore.starcore.module.diplomacy.DiplomacyModule;
import dev.starcore.starcore.module.diplomacy.alliance.AllianceModule;
import dev.starcore.starcore.module.event.EventModule;
import dev.starcore.starcore.module.gameplay.GameplayModule;
import dev.starcore.starcore.module.government.GovernmentModule;
import dev.starcore.starcore.module.map.MapModule;
import dev.starcore.starcore.module.narrative.NarrativeModule;
import dev.starcore.starcore.module.nation.NationModule;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.officer.OfficerModule;
import dev.starcore.starcore.module.officer.gui.OfficerMenu;
import dev.starcore.starcore.module.policy.PolicyModule;
import dev.starcore.starcore.module.resolution.ResolutionGuiListener;
import dev.starcore.starcore.module.resolution.ResolutionModule;
import dev.starcore.starcore.module.resource.ResourceModule;
import dev.starcore.starcore.module.season.SeasonalWorldContracts;
import dev.starcore.starcore.module.split.SplitModule;
import dev.starcore.starcore.module.technology.TechnologyModule;
import dev.starcore.starcore.module.tournament.gui.TournamentGui;
import dev.starcore.starcore.module.treasury.BankruptcyServiceImpl;
import dev.starcore.starcore.module.treasury.BudgetServiceImpl;
import dev.starcore.starcore.module.treasury.LoanServiceImpl;
import dev.starcore.starcore.module.treasury.TreasuryModule;
import dev.starcore.starcore.module.treasury.gui.TreasuryMenu;
import dev.starcore.starcore.module.war.WarModule;
import dev.starcore.starcore.module.weather.WeatherModule;
import dev.starcore.starcore.module.weather.gui.WeatherMenu;
import dev.starcore.starcore.nation.command.NationRankCommand;
import dev.starcore.starcore.nation.permission.NationPermissionChecker;
import dev.starcore.starcore.nation.rank.NationRankManager;
import dev.starcore.starcore.performance.OptimizedMoveListener;
import dev.starcore.starcore.pvp.PvPModule;
import dev.starcore.starcore.region.RegionModule;
import dev.starcore.starcore.stats.StatsService;
import dev.starcore.starcore.storage.StorageModule;
import dev.starcore.starcore.territory.PermissionChecker;
import dev.starcore.starcore.territory.PermissionTemplateService;
import dev.starcore.starcore.territory.SubRegionService;
import dev.starcore.starcore.territory.TemporaryPermissionService;
import dev.starcore.starcore.territory.TerritoryLeaseService;
import dev.starcore.starcore.territory.TerritoryStorage;
import dev.starcore.starcore.territory.TerritoryStorageFactory;
import dev.starcore.starcore.territory.visualization.TerritoryVisualizer;
import dev.starcore.starcore.title.TitleModule;
import dev.starcore.starcore.util.MessageUtil;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class StarCorePlugin extends JavaPlugin {
  private StarCoreContext context;
  private StarCoreApi api;
  private RegionModule regionModule;
  private TitleModule titleModule;
  private dev.starcore.starcore.title.StarCorePlaceholderExpansion placeholderExpansion;
  private dev.starcore.starcore.social.SocialModule socialModule;
  private dev.starcore.starcore.social.SocialSimulationModule socialSimulationModule;
  private dev.starcore.starcore.quest.QuestModule questModule;
  private dev.starcore.starcore.event.random.RandomEventService randomEventService;
  private ClanManager clanManager;
  private ScreenShakeManager screenShakeManager;
  private SceneSoundService sceneSoundService;
  private SceneSoundConfig sceneSoundConfig;
  private TooltipModule tooltipModule;
  private StatsService statsReportService;
  private dev.starcore.starcore.ranking.gui.RankingGUI rankingGui;
  private OptimizedMoveListener moveDispatcher;
  private SeasonService seasonService;
  private SeasonalWorldContracts seasonalWorldContracts;
  private ReligionService religionService;
  private DeathMessageService deathMessageService;
  private DeathMessagesListener deathMessagesListener;
  private ParticleFeedbackService particleFeedbackService;
  private dev.starcore.starcore.monitoring.StressTestCommand stressTestExecutor;
  private ParticleFeedbackListener particleFeedbackListener;
  private BukkitTask externalMetricsTask;
  private AutoCloseable redisMetricsSourceRegistration;
  private AutoCloseable stressMetricsSourceRegistration;

  /** 封装 ServiceRegistry 中 isInstance/map(cast) 模式，避免在业务代码中硬编码类类型转换。 */
  private static <S, M extends S> Optional<M> findModule(
      dev.starcore.starcore.core.service.ServiceRegistry registry,
      Class<S> serviceClass,
      Class<M> moduleClass) {
    return registry.find(serviceClass).filter(moduleClass::isInstance).map(moduleClass::cast);
  }

  @Override
  public void onEnable() {
    saveDefaultConfig();

    ConfigurationService configurationService = new ConfigurationService(this);

    // 校验配置文件版本
    configurationService.validateConfigVersion();

    // 安全检查：MySQL空密码验证
    validateDatabaseSecurity(configurationService);

    if (configurationService.ensureMapWebAccessSecretConfigured()) {
      getLogger().info("Generated map.web.access-secret for STARCORE map personal links.");
    }
    StarCoreScheduler scheduler = new StarCoreScheduler(this, configurationService.asyncThreads());
    StarCoreEventBus eventBus = new StarCoreEventBus(getLogger());
    PersistenceService persistenceService = new PersistenceService(this, scheduler);
    DatabaseService databaseService = new DatabaseService(this, configurationService);
    InternalPermissionService permissionService = new InternalPermissionService();
    InternalEconomyService economyService =
        new InternalEconomyService(
            databaseService, persistenceService, getLogger(), scheduler.getIoExecutor());
    PlatformAdapter platformAdapter = PlatformAdapterFactory.detect(this);
    ServiceRegistry serviceRegistry = new ServiceRegistry();
    ModuleManager moduleManager = new ModuleManager(getLogger(), serviceRegistry);

    this.context =
        new StarCoreContext(
            this,
            platformAdapter,
            configurationService,
            scheduler,
            eventBus,
            persistenceService,
            databaseService,
            permissionService,
            economyService,
            moduleManager,
            serviceRegistry);

    context.persistenceService().start();
    context.databaseService().start();
    context.economyService().start();
    initializePrometheusMetrics(configurationService);

    ExtensionRegistry.init(getLogger());
    registerEconomySmokeExtension();
    registerFoundationServices();
    initializeRedisCrossServerService(configurationService);
    initializeParticleFeedbackService();
    context.serviceRegistry().require(TimeSyncService.class).start();

    // 初始化屏幕震动管理器
    this.screenShakeManager = new ScreenShakeManager(this);
    context.serviceRegistry().register(ScreenShakeManager.class, screenShakeManager);
    ScreenShake.init(screenShakeManager);
    getServer().getPluginManager().registerEvents(screenShakeManager, this);
    getLogger().info("Screen shake manager initialized.");

    // 初始化场景化音效系统
    this.sceneSoundConfig = new SceneSoundConfig(this);
    this.sceneSoundService = new SceneSoundService(this);
    context.serviceRegistry().register(SceneSoundService.class, sceneSoundService);

    // 注册音效命令
    SceneSoundCommand soundCommand =
        new SceneSoundCommand(this, sceneSoundService, sceneSoundConfig);
    soundCommand.register();
    getLogger().info("Scene sound system initialized.");

    // 初始化四季系统
    this.seasonService = new SeasonService(this, configurationService, eventBus, scheduler);
    context.serviceRegistry().register(SeasonService.class, seasonService);
    var seasonInitialization = seasonService.initializeAsync();
    this.seasonalWorldContracts =
        new SeasonalWorldContracts(
            getDataFolder().toPath().resolve("season/contracts.properties"),
            eventBus,
            context
                .serviceRegistry()
                .require(
                    dev.starcore.starcore.foundation.economy.transaction.TransactionFabric.class),
            getLogger());
    context.serviceRegistry().register(SeasonalWorldContracts.class, seasonalWorldContracts);
    seasonalWorldContracts.registerBukkitListeners(this);
    var activeSeasonService = seasonService;
    var activeSeasonalContracts = seasonalWorldContracts;
    seasonInitialization.thenCompose(
        ignored ->
            scheduler.callGlobal(
                () -> {
                  if (!activeSeasonService.isRunning()) return null;
                  getServer().getWorlds().stream()
                      .findFirst()
                      .ifPresent(
                          world ->
                              activeSeasonalContracts.activate(
                                  world.getName(),
                                  activeSeasonService.getSeason(world),
                                  activeSeasonService.getSeasonCycle(world)));
                  return null;
                }));
    getLogger().info("Season system initialized.");

    // 初始化宗教系统
    this.religionService = new ReligionService(this, scheduler);
    context.serviceRegistry().register(ReligionService.class, religionService);
    religionService.initialize();
    getLogger().info("Religion system initialized.");

    // 初始化死亡消息系统
    this.deathMessageService = new DeathMessageService(this);
    this.deathMessagesListener = new DeathMessagesListener(deathMessageService);
    getServer().getPluginManager().registerEvents(deathMessagesListener, this);
    PluginCommand deathMessagesCmd = getCommand("deathmessages");
    if (deathMessagesCmd != null) {
      deathMessagesCmd.setExecutor(new DeathMessagesCommand(deathMessageService));
    } else {
      getLogger().warning("deathmessages 命令未在 plugin.yml 中声明");
    }
    getLogger().info("Death message system initialized.");

    // 初始化 GUI 动画系统 (在模块启用前初始化)
    dev.starcore.starcore.foundation.animation.GuiAnimationRegistry.initialize(this);
    getServer()
        .getPluginManager()
        .registerEvents(
            new dev.starcore.starcore.foundation.gui.GuiHubNavigationListener(this), this);
    getLogger().info("GUI animation system initialized.");

    // 关键优化：必须在模块 enable() 之前注册 OptimizedMoveListener 服务
    // 否则 navy/tunnel/region 等模块在 enable() 中 subscribe() 时找不到服务
    // （原代码把注册放在 moduleManager.enableAll 之后，导致 IllegalStateException）
    OptimizedMoveListener moveDispatcher = new OptimizedMoveListener();
    getServer().getPluginManager().registerEvents(moveDispatcher, this);
    context.serviceRegistry().register(OptimizedMoveListener.class, moveDispatcher);
    this.moveDispatcher = moveDispatcher;
    getLogger()
        .info(
            "Optimized move dispatcher registered; modules should subscribe via ServiceRegistry.");

    registerModules();
    registerCommands();

    // 初始化权限工具类（必须在模块注册之后）
    // 初始化通知服务（在模块启用前注册，供各模块使用）
    var notificationService =
        new dev.starcore.starcore.notification.NotificationService(
            this,
            playerId -> {
              var ns =
                  context
                      .serviceRegistry()
                      .find(dev.starcore.starcore.module.nation.NationService.class);
              if (ns.isEmpty()) return java.util.List.<java.util.UUID>of();
              var nation = ns.get().getNationByMember(playerId);
              return nation
                  .<java.util.Collection<java.util.UUID>>map(
                      n ->
                          n.members().stream()
                              .map(m -> m.playerId())
                              .collect(
                                  java.util.stream.Collectors.toCollection(
                                      java.util.LinkedHashSet::new)))
                  .orElse(java.util.List.of());
            });
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.notification.NotificationService.class, notificationService);

    context.moduleManager().enableAll(context);
    // PermissionUtil resolves module-owned services, so initialize it after modules are enabled.
    dev.starcore.starcore.util.PermissionUtil.init(this);
    findModule(
            context.serviceRegistry(),
            dev.starcore.starcore.module.nation.NationService.class,
            dev.starcore.starcore.module.nation.NationModule.class)
        .ifPresent(dev.starcore.starcore.module.nation.NationModule::recoverPendingDisband);

    if (context.configuration().moduleEnabled("tooltip", true)) {
      this.tooltipModule = new TooltipModule(this);
      this.tooltipModule.enable();
      context
          .serviceRegistry()
          .register(SmartTooltipService.class, tooltipModule.getTooltipService());
    }

    // 初始化 HUD 菜单系统
    ModernHudListener.initialize(this);
    ModernHudListener.getInstance().subscribe(moveDispatcher);
    getLogger().info("Modern HUD system initialized.");

    // 随机事件与 EventModule（审计日志）是两个独立系统。
    // 默认不构造随机事件服务，旧配置缺少该键时同样保持关闭。
    if (context.configuration().moduleEnabled("random-event", false)) {
      initializeRandomEventService();
    } else {
      getLogger().info("Random event subsystem disabled (modules.random-event=false).");
    }

    // 称号模块（非 StarCoreModule，手动装配）
    if (context.configuration().moduleEnabled("title", true)) {
      this.titleModule =
          new TitleModule(this, context.databaseService(), context.serviceRegistry());
      this.titleModule.enable();
      if (socialSimulationModule != null) {
        socialSimulationModule.initializeActivityRewards(context);
      }
    }

    // 注册需要模块支持的辅助命令（必须在模块启用后）
    registerModuleDependentCommands();

    // 注册导航中枢 GUI handlers（消除 performCommand 依赖）
    registerNavigationGuiHandlers();

    // 注意：任务模块（任务/每日任务/委托）现在由 QuestModule 管理
    // 参见 registerModules() 中的 QuestModule 注册

    // 初始化 ClanManager 并注册命令
    this.clanManager = new ClanManager();
    this.clanManager.setPlugin(this);
    this.clanManager.loadData(); // 加载保存的数据
    this.clanManager.startSaveTask();
    bindCommand("clan", new dev.starcore.starcore.clan.command.ClanCommand(clanManager));

    // 注册 Clan PvP 监听器
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.clan.listener.ClanPvPListener(clanManager), this);

    // 注册 Clan 聊天监听器
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.clan.chat.ClanChatChannel(clanManager), this);

    // 注册中心化移动事件分发器（消除 25+ 个独立 PlayerMoveEvent 监听器
    // 重复的 chunk 比较）。其它模块通过 ServiceRegistry 获取该服务后注册回调。
    // 关键：此 dispatcher 已在 registerModules() 之前注册——重复注册会触发
    // "service already registered" 异常。
    getLogger().info("Optimized move dispatcher already registered pre-modules.");

    // 注册 BaseGui 统一点击监听器，确保所有 BaseGui 菜单都能处理按钮事件
    BaseGuiListener baseGuiListener = new BaseGuiListener(this);
    getServer().getPluginManager().registerEvents(baseGuiListener, this);

    // 注册通用二次确认菜单监听器（供所有破坏性操作复用）
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.foundation.gui.ConfirmationMenuListener(), this);

    // 注册统一导航中枢监听器（/menu 总入口，模块间跳转）
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.foundation.gui.NavigationHubListener(), this);

    // 注册玩法指南监听器（/guide 命令 GUI 交互）
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.core.guide.GameplayGuideListener(this), this);

    // 注册指南书物品监听器（粘液科技风格指南书，右键打开 GUI）
    getServer()
        .getPluginManager()
        .registerEvents(new dev.starcore.starcore.core.guide.GuideBookListener(), this);

    // 初始化 MessageUtil（获取 NationService）
    dev.starcore.starcore.module.nation.NationModule nationModule =
        (dev.starcore.starcore.module.nation.NationModule)
            context
                .serviceRegistry()
                .find(dev.starcore.starcore.module.nation.NationService.class)
                .orElse(null);
    MessageUtil.init(nationModule, clanManager);

    // 注册 PlaceholderAPI 扩展
    registerPlaceholderAPI();

    java.util.List<String> unavailableNavigation = NavigationHubMenu.unavailableRoutes();
    if (unavailableNavigation.isEmpty()) {
      getLogger().info("Navigation coverage: all hub entries are connected.");
    } else {
      getLogger().warning("Navigation entries without handlers: " + unavailableNavigation);
    }

    registerApi();

    // 向 GUI 静态菜单注入共享服务，使统计/社交菜单显示真实数据
    // Nukkit GUI system removed - commented out
    /*
    dev.starcore.starcore.gui.GuiServices.init(
        context.economyService(),
        context.serviceRegistry().find(dev.starcore.starcore.pvp.stats.PvPStatsService.class).orElse(null),
        socialModule != null ? socialModule.friendService() : null,
        socialModule != null ? socialModule.guildService() : null,
        socialModule != null ? socialModule.partyService() : null
    );
    */

    getLogger()
        .info(
            "Platform adapter: "
                + platformAdapter.platformName()
                + " | "
                + platformAdapter.supportSummary());
    getLogger().info("STARCORE " + getPluginMeta().getVersion() + " enabled.");
  }

  @Override
  public void onDisable() {
    dev.starcore.starcore.foundation.animation.GuiAnimationRegistry.shutdown(this);
    if (externalMetricsTask != null) {
      externalMetricsTask.cancel();
      externalMetricsTask = null;
    }
    unregisterRedisMetricsSource();
    unregisterStressMetricsSource();
    if (stressTestExecutor != null) {
      stressTestExecutor.shutdown();
      stressTestExecutor = null;
    }
    if (context == null) {
      return;
    }
    context.databaseService().monitoringService().clearExternalMetricsReceiver();
    if (particleFeedbackService != null) {
      int activeFeedbacks = particleFeedbackService.activeContinuousFeedbackCount();
      particleFeedbackService.shutdown();
      getLogger().info("Particle feedback tasks cleared on disable: " + activeFeedbacks);
    }
    if (particleFeedbackListener != null) {
      HandlerList.unregisterAll(particleFeedbackListener);
      particleFeedbackListener = null;
    }
    if (particleFeedbackService != null) {
      context.serviceRegistry().unregister(ParticleFeedbackService.class, particleFeedbackService);
      particleFeedbackService = null;
    }
    NavigationHubMenu.clearHandlers();
    unregisterApi();
    if (rankingGui != null) {
      rankingGui.shutdown();
      rankingGui = null;
    }

    if (screenShakeManager != null) {
      ScreenShake.shutdown();
      context.serviceRegistry().unregister(ScreenShakeManager.class, screenShakeManager);
      screenShakeManager = null;
    }
    if (sceneSoundService != null) {
      sceneSoundService.shutdown();
      context.serviceRegistry().unregister(SceneSoundService.class, sceneSoundService);
      sceneSoundService = null;
      sceneSoundConfig = null;
    }

    // 保存领土数据到存储
    try {
      ModernHudListener.getInstance().shutdown();
    } catch (IllegalStateException ignored) {
      // HUD 未初始化，忽略
    }

    context
        .serviceRegistry()
        .find(dev.starcore.starcore.territory.TerritoryService.class)
        .ifPresent(dev.starcore.starcore.territory.TerritoryService::save);
    context.serviceRegistry().find(SubRegionService.class).ifPresent(SubRegionService::save);
    context
        .serviceRegistry()
        .find(TemporaryPermissionService.class)
        .ifPresent(TemporaryPermissionService::stop);
    context
        .serviceRegistry()
        .find(TerritoryLeaseService.class)
        .ifPresent(TerritoryLeaseService::stop);

    // 关闭区域模块
    context
        .serviceRegistry()
        .find(TerritoryVisualizer.class)
        .ifPresent(TerritoryVisualizer::shutdown);
    if (regionModule != null) {
      regionModule.shutdown();
      regionModule = null;
    }

    if (placeholderExpansion != null) {
      placeholderExpansion.unregister();
      placeholderExpansion = null;
    }

    // 关闭称号模块
    if (titleModule != null) {
      titleModule.disable();
      titleModule = null;
    }

    if (tooltipModule != null) {
      tooltipModule.disable();
      context.serviceRegistry().unregister(SmartTooltipService.class);
      tooltipModule = null;
    }

    // 关闭随机事件服务
    if (randomEventService != null) {
      randomEventService.shutdown();
      context
          .serviceRegistry()
          .unregister(
              dev.starcore.starcore.event.random.RandomEventService.class, randomEventService);
      randomEventService = null;
      getLogger().info("RandomEventService shut down.");
    }

    if (seasonService != null) {
      seasonService.shutdown();
      HandlerList.unregisterAll(seasonService);
      context.serviceRegistry().unregister(SeasonService.class, seasonService);
      seasonService = null;
    }
    if (religionService != null) {
      religionService.shutdown();
      context.serviceRegistry().unregister(ReligionService.class, religionService);
      religionService = null;
    }
    if (deathMessagesListener != null) {
      HandlerList.unregisterAll(deathMessagesListener);
      deathMessagesListener = null;
    }
    if (deathMessageService != null) {
      context.serviceRegistry().unregister(DeathMessageService.class, deathMessageService);
      deathMessageService = null;
    }
    if (moveDispatcher != null) {
      HandlerList.unregisterAll(moveDispatcher);
      context.serviceRegistry().unregister(OptimizedMoveListener.class, moveDispatcher);
      moveDispatcher = null;
    }

    // 清理 MessageUtil 静态引用
    MessageUtil.shutdown();

    context.serviceRegistry().find(TimeSyncService.class).ifPresent(TimeSyncService::stop);
    shutdownStatsReportService();
    saveNationRanks();
    if (seasonalWorldContracts != null) {
      seasonalWorldContracts.close();
      context.serviceRegistry().unregister(SeasonalWorldContracts.class, seasonalWorldContracts);
      seasonalWorldContracts = null;
    }
    context.moduleManager().disableAll(context);
    AbstractModuleStateStorage.shutdownAll();
    context
        .serviceRegistry()
        .find(RedisCrossServerService.class)
        .ifPresent(
            service -> {
              try {
                service.close();
              } finally {
                context.serviceRegistry().unregister(RedisCrossServerService.class, service);
              }
            });
    // 关闭事件桥（停止其异步线程池）
    context
        .serviceRegistry()
        .find(dev.starcore.starcore.core.event.EventBridge.class)
        .ifPresent(
            bridge -> {
              try {
                bridge.shutdown();
              } finally {
                context
                    .serviceRegistry()
                    .unregister(dev.starcore.starcore.core.event.EventBridge.class);
              }
            });
    context
        .serviceRegistry()
        .find(TerritoryService.class)
        .ifPresent(
            territoryService -> {
              try {
                territoryService.shutdown();
              } finally {
                context.serviceRegistry().unregister(TerritoryService.class, territoryService);
              }
            });
    context.economyService().stop();
    // 保存 ClanManager 数据
    if (clanManager != null) {
      clanManager.saveDirtyClans();
      clanManager.stopSaveTask();
    }
    // 注意：任务模块（QuestModule）禁用时会自动保存数据

    shutdownCacheManager();
    context
        .serviceRegistry()
        .find(TerritoryStorage.class)
        .ifPresent(
            storage -> {
              try {
                storage.shutdown();
              } finally {
                context.serviceRegistry().unregister(TerritoryStorage.class, storage);
              }
            });
    context.serviceRegistry().find(AuditLogService.class).ifPresent(AuditLogService::close);
    context.persistenceService().stop();
    context.scheduler().shutdown();
    context.databaseService().shutdown();
    context.databaseService().stop();
    getLogger().info("STARCORE disabled.");
  }

  private void shutdownStatsReportService() {
    StatsService service = statsReportService;
    if (service == null) {
      return;
    }
    try {
      service.shutdown();
    } finally {
      context.serviceRegistry().unregister(StatsService.class, service);
      if (statsReportService == service) {
        statsReportService = null;
      }
    }
  }

  private void shutdownCacheManager() {
    context
        .serviceRegistry()
        .find(CacheManager.class)
        .ifPresent(
            cacheManager -> {
              try {
                cacheManager.shutdown();
              } finally {
                context.serviceRegistry().unregister(CacheManager.class, cacheManager);
              }
            });
  }

  private void initializePrometheusMetrics(ConfigurationService configuration) {
    String endpoint = configuration.prometheusMetricsEndpoint();
    if (endpoint.isBlank()) {
      return;
    }
    try {
      var monitoring = context.databaseService().monitoringService();
      monitoring.setExternalMetricsReceiver(
          new PrometheusHttpMetricsReceiver(
              URI.create(endpoint),
              Duration.ofMillis(configuration.prometheusMetricsRequestTimeoutMs()),
              configuration.prometheusMetricsBearerToken()));
      AtomicBoolean publishing = new AtomicBoolean();
      long intervalTicks = configuration.prometheusMetricsIntervalSeconds() * 20L;
      externalMetricsTask =
          context
              .scheduler()
              .runSyncTimer(
                  () -> {
                    if (!publishing.compareAndSet(false, true)) {
                      return;
                    }
                    monitoring
                        .publishPrometheusMetricsAsync(context.scheduler().getIoExecutor())
                        .whenComplete(
                            (result, failure) -> {
                              publishing.set(false);
                              if (failure != null) {
                                getLogger()
                                    .log(
                                        Level.WARNING,
                                        "METRICS_DELIVERY_FAILED code=METRICS_PUBLISH_UNEXPECTED",
                                        failure);
                              }
                            });
                  },
                  intervalTicks,
                  intervalTicks);
      getLogger().info("External Prometheus metrics delivery enabled.");
    } catch (IllegalArgumentException invalidEndpoint) {
      getLogger()
          .log(
              Level.SEVERE,
              "Invalid monitoring.prometheus.endpoint; external delivery is disabled.",
              invalidEndpoint);
    }
  }

  public StarCoreContext context() {
    return context;
  }

  private void registerEconomySmokeExtension() {
    String armedPlayer = System.getProperty("starcore.smoke.fail-deposit-once");
    String rewardPlayerName = System.getProperty("starcore.smoke.fail-dungeon-reward-once");
    if ((armedPlayer == null || armedPlayer.isBlank())
        && (rewardPlayerName == null || rewardPlayerName.isBlank())) {
      return;
    }
    EconomyTransactionExtensionPoint point = new EconomyTransactionExtensionPoint();
    context.serviceRegistry().register(EconomyTransactionExtensionPoint.class, point);

    if (armedPlayer != null && !armedPlayer.isBlank()) {
      try {
        java.util.UUID playerId = java.util.UUID.fromString(armedPlayer.trim());
        AtomicBoolean armed = new AtomicBoolean(true);
        context
            .serviceRegistry()
            .register(
                StarcoreSmokeDepositFailure.class,
                new StarcoreSmokeDepositFailure(playerId, armed));
        ExtensionRegistry.getInstance()
            .registerContributor(
                "economy_transaction",
                new dev.starcore.starcore.core.extension.ExtensionContributor<
                    EconomyTransactionExtensionPoint.TransactionResult,
                    EconomyTransactionExtensionPoint.TransactionContext>() {
                  @Override
                  public String getId() {
                    return "starcore-smoke-fail-deposit-once";
                  }

                  @Override
                  public String getName() {
                    return "STARCORE Paper smoke deposit failure";
                  }

                  @Override
                  public boolean isApplicable(
                      EconomyTransactionExtensionPoint.TransactionContext request) {
                    return request.type()
                            == EconomyTransactionExtensionPoint.TransactionType.DEPOSIT
                        && request.playerId().equals(playerId)
                        && armed.get();
                  }

                  @Override
                  public EconomyTransactionExtensionPoint.TransactionResult contribute(
                      EconomyTransactionExtensionPoint.TransactionContext request) {
                    if (armed.compareAndSet(true, false)) {
                      getLogger()
                          .warning(
                              "STARCORE smoke: injected one-shot deposit rejection for "
                                  + playerId);
                      return new EconomyTransactionExtensionPoint.TransactionResult(
                          false, request.amount(), "smoke_fail_once", java.util.Map.of());
                    }
                    return null;
                  }
                });
      } catch (IllegalArgumentException invalid) {
        getLogger().warning("Ignoring invalid starcore.smoke.fail-deposit-once UUID.");
      }
    }

    if (rewardPlayerName != null && !rewardPlayerName.isBlank()) {
      registerDungeonRewardSmokeExtension(rewardPlayerName.trim());
    }
  }

  private void registerDungeonRewardSmokeExtension(String playerName) {
    java.util.UUID playerId = getServer().getOfflinePlayer(playerName).getUniqueId();
    String configuredReport = System.getProperty("starcore.smoke.dungeon-reward-provider-report");
    Path reportPath =
        configuredReport == null || configuredReport.isBlank() ? null : Path.of(configuredReport);
    Properties previousReport = readDungeonRewardSmokeReport(reportPath);
    boolean alreadyInjected = Boolean.parseBoolean(previousReport.getProperty("injected", "false"));
    int previousCalls = parseDungeonRewardSmokeCalls(previousReport.getProperty("rewardCalls"));
    AtomicBoolean armed = new AtomicBoolean(!alreadyInjected);
    AtomicBoolean injected = new AtomicBoolean(alreadyInjected);
    AtomicInteger calls = new AtomicInteger(previousCalls);
    writeDungeonRewardSmokeReport(reportPath, playerId, calls.get(), injected.get());
    ExtensionRegistry.getInstance()
        .registerContributor(
            "economy_transaction",
            new dev.starcore.starcore.core.extension.ExtensionContributor<
                EconomyTransactionExtensionPoint.TransactionResult,
                EconomyTransactionExtensionPoint.TransactionContext>() {
              @Override
              public String getId() {
                return "starcore-smoke-fail-dungeon-reward-once";
              }

              @Override
              public String getName() {
                return "STARCORE Paper smoke dungeon reward provider failure";
              }

              @Override
              public boolean isApplicable(
                  EconomyTransactionExtensionPoint.TransactionContext request) {
                return request.type() == EconomyTransactionExtensionPoint.TransactionType.DEPOSIT
                    && request.playerId().equals(playerId)
                    && "dungeon_reward".equals(request.source());
              }

              @Override
              public EconomyTransactionExtensionPoint.TransactionResult contribute(
                  EconomyTransactionExtensionPoint.TransactionContext request) {
                int call = calls.incrementAndGet();
                if (armed.compareAndSet(true, false)) {
                  injected.set(true);
                  writeDungeonRewardSmokeReport(reportPath, playerId, call, true);
                  getLogger()
                      .warning(
                          "STARCORE smoke: injected one-shot dungeon reward provider rejection for "
                              + playerId);
                  return new EconomyTransactionExtensionPoint.TransactionResult(
                      false,
                      request.amount(),
                      "smoke_dungeon_reward_provider_rejected",
                      java.util.Map.of());
                }
                writeDungeonRewardSmokeReport(reportPath, playerId, call, injected.get());
                return null;
              }
            });
  }

  private void writeDungeonRewardSmokeReport(
      Path reportPath, java.util.UUID playerId, int calls, boolean injected) {
    if (reportPath == null) return;
    try {
      Path parent = reportPath.toAbsolutePath().getParent();
      if (parent != null) Files.createDirectories(parent);
      Files.writeString(
          reportPath,
          "installed=true\n"
              + "playerId="
              + playerId
              + "\n"
              + "injected="
              + injected
              + "\n"
              + "rewardCalls="
              + calls
              + "\n",
          StandardCharsets.UTF_8);
    } catch (IOException failure) {
      getLogger().warning("Could not write dungeon reward smoke report: " + failure);
    }
  }

  private Properties readDungeonRewardSmokeReport(Path reportPath) {
    Properties properties = new Properties();
    if (reportPath == null || !Files.isRegularFile(reportPath)) return properties;
    try (var reader = Files.newBufferedReader(reportPath, StandardCharsets.UTF_8)) {
      properties.load(reader);
    } catch (IOException failure) {
      getLogger().warning("Could not read dungeon reward smoke report: " + failure);
    }
    return properties;
  }

  private int parseDungeonRewardSmokeCalls(String value) {
    if (value == null || value.isBlank()) return 0;
    try {
      return Math.max(0, Integer.parseInt(value));
    } catch (NumberFormatException invalid) {
      getLogger().warning("Ignoring invalid dungeon reward smoke call count: " + value);
      return 0;
    }
  }

  private record StarcoreSmokeDepositFailure(java.util.UUID playerId, AtomicBoolean armed) {}

  private void registerFoundationServices() {
    dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService refundLedgerService =
        new dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService(this);
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService.class,
            refundLedgerService);
    dev.starcore.starcore.foundation.economy.transaction.TransactionFabric transactionFabric =
        new dev.starcore.starcore.foundation.economy.transaction.TransactionFabric(
            getDataFolder().toPath().resolve("economy/transaction-fabric.properties"), getLogger());
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.economy.transaction.TransactionFabric.class,
            transactionFabric);
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.economy.transaction.EvidenceReplayService.class,
            new dev.starcore.starcore.foundation.economy.transaction.EvidenceReplayService(
                transactionFabric, refundLedgerService.ledger()));
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService.class,
            new dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService(
                getDataFolder().toPath().resolve("economy/insurance.properties"),
                getLogger(),
                context.economyService(),
                transactionFabric,
                refundLedgerService.ledger()));
    context
        .serviceRegistry()
        .register(PerformanceMetricsService.class, new PerformanceMetricsService());
    context.serviceRegistry().register(CacheManager.class, new CacheManager());
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.core.health.ModuleHealthCenter.class,
            new dev.starcore.starcore.core.health.ModuleHealthCenter(
                context.moduleManager(), context.serviceRegistry()));
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.economy.transaction.IncidentBundleService.class,
            new dev.starcore.starcore.foundation.economy.transaction.IncidentBundleService(
                getDataFolder().toPath().resolve("operations/incidents"),
                transactionFabric,
                refundLedgerService.ledger(),
                context
                    .serviceRegistry()
                    .require(
                        dev.starcore.starcore.foundation.economy.transaction.EvidenceReplayService
                            .class),
                context
                    .serviceRegistry()
                    .require(dev.starcore.starcore.core.health.ModuleHealthCenter.class),
                context
                    .serviceRegistry()
                    .require(
                        dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService
                            .class),
                getLogger()));
    context
        .serviceRegistry()
        .register(PlayerProfileService.class, new InMemoryPlayerProfileService());
    context
        .serviceRegistry()
        .register(OnlinePlayerDirectory.class, new BukkitOnlinePlayerDirectory());
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.core.event.EventBridge.class,
            new dev.starcore.starcore.core.event.EventBridge());

    NationRankManager rankManager = new NationRankManager();
    rankManager.initDefaultRanks();
    File rankFile = new File(getDataFolder(), "ranks.yml");
    rankManager.loadRanksFromConfig(YamlConfiguration.loadConfiguration(rankFile));
    context.serviceRegistry().register(NationRankManager.class, rankManager);

    // 注册国际化管理器
    I18nManager i18nManager = new I18nManager(this, context.platformAdapter());
    i18nManager.setDatabaseService(context.databaseService());
    i18nManager.setDefaultLocale(context.configuration().locale());
    dev.starcore.starcore.foundation.gui.GuiText.configure(i18nManager);
    context.serviceRegistry().register(I18nManager.class, i18nManager);

    // 注册消息服务（使用国际化管理器作为实现）
    context.serviceRegistry().register(MessageService.class, i18nManager);

    MessageService messageService = new SimpleMessageService(this, context.configuration());
    context
        .serviceRegistry()
        .register(EpochService.class, new EpochService(context.configuration(), messageService));
    context
        .serviceRegistry()
        .register(
            TimeSyncService.class,
            new TimeSyncService(this, context.configuration(), messageService));

    // 注册Foundation的TerritoryService（基于chunk的）
    dev.starcore.starcore.foundation.territory.TerritoryService foundationTerritoryService =
        new DatabaseAwareTerritoryService(
            context.databaseService(), context.persistenceService(), getLogger());
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.foundation.territory.TerritoryService.class,
            foundationTerritoryService);

    // 创建领土存储（支持 SQL/Properties 双模式持久化）
    TerritoryStorage territoryStorage =
        TerritoryStorageFactory.create(
            this, context.databaseService(), context.persistenceService());
    context.serviceRegistry().register(TerritoryStorage.class, territoryStorage);

    // 注册Territory包的TerritoryService（基于坐标的）
    dev.starcore.starcore.territory.TerritoryService territoryService =
        new dev.starcore.starcore.territory.TerritoryService(this, territoryStorage);
    context
        .serviceRegistry()
        .register(dev.starcore.starcore.territory.TerritoryService.class, territoryService);
    territoryService.load(); // 从存储加载

    // 注册子区域服务
    SubRegionService subRegionService =
        new SubRegionService(this, territoryService, territoryStorage);
    context.serviceRegistry().register(SubRegionService.class, subRegionService);
    subRegionService.load(); // 从存储加载

    // 领土权限模板 / 临时权限 / 租赁 / 权限检查 / 边界可视化（坐标级领土体系）
    PermissionTemplateService permissionTemplateService = new PermissionTemplateService(this);
    context.serviceRegistry().register(PermissionTemplateService.class, permissionTemplateService);

    TemporaryPermissionService temporaryPermissionService =
        new TemporaryPermissionService(this, territoryService);
    temporaryPermissionService.start();
    context
        .serviceRegistry()
        .register(TemporaryPermissionService.class, temporaryPermissionService);

    TerritoryLeaseService territoryLeaseService = new TerritoryLeaseService(this, territoryService);
    territoryLeaseService.start();
    context.serviceRegistry().register(TerritoryLeaseService.class, territoryLeaseService);

    PermissionChecker territoryPermissionChecker =
        new PermissionChecker(
            territoryService, subRegionService, temporaryPermissionService, territoryLeaseService);
    context.serviceRegistry().register(PermissionChecker.class, territoryPermissionChecker);

    TerritoryVisualizer territoryVisualizer = new TerritoryVisualizer(this);
    context.serviceRegistry().register(TerritoryVisualizer.class, territoryVisualizer);

    // 注册区域模块（同时传递两个服务）
    // - foundationTerritoryService: Chunk 级别，用于王国/国家检测
    // - territoryService: 坐标级别，用于子区域检测
    this.regionModule =
        new RegionModule(
            this,
            foundationTerritoryService,
            territoryService,
            subRegionService,
            context.serviceRegistry());

    context
        .serviceRegistry()
        .register(ExternalProtectionService.class, createExternalProtectionService());
    context.serviceRegistry().register(DatabaseService.class, context.databaseService());
    context.serviceRegistry().register(PersistenceService.class, context.persistenceService());
    context
        .serviceRegistry()
        .register(InternalPermissionService.class, context.permissionService());
    context.serviceRegistry().register(InternalEconomyService.class, context.economyService());

    PerformanceMetricsService performanceMetrics =
        context.serviceRegistry().find(PerformanceMetricsService.class).orElse(null);
    long providerTimeoutMillis = getConfig().getLong("economy.provider-timeout-ms", 0L);
    PlayerVaultEconomyService playerVaultEconomyService =
        new PlayerVaultEconomyService(getLogger(), performanceMetrics, providerTimeoutMillis);
    context.serviceRegistry().register(PlayerVaultEconomyService.class, playerVaultEconomyService);
    EconomyService selectedEconomy = selectEconomyService(playerVaultEconomyService);
    context.serviceRegistry().register(EconomyService.class, selectedEconomy);

    AuditLogService auditLogService = new AuditLogService(this, context.databaseService());
    auditLogService.start();
    context.serviceRegistry().register(AuditLogService.class, auditLogService);
    context
        .serviceRegistry()
        .require(dev.starcore.starcore.foundation.economy.transaction.TransactionFabric.class)
        .setAuditSink(auditLogService::logTransactionEvent);
    context
        .serviceRegistry()
        .require(dev.starcore.starcore.foundation.economy.transaction.EvidenceReplayService.class)
        .registerProvider(
            (transactionId, transaction) -> auditLogService.replayTransaction(transactionId));
  }

  private void initializeRedisCrossServerService(ConfigurationService configuration) {
    var redisService =
        new RedisCrossServerService(
            new RedisCrossServerService.Settings(
                configuration.redisEnabled(),
                configuration.redisHost(),
                configuration.redisPort(),
                configuration.redisPassword(),
                configuration.redisDatabase(),
                configuration.redisChannel(),
                configuration.redisTls()),
            getLogger(),
            task -> getServer().getScheduler().runTask(this, task));
    context.serviceRegistry().register(RedisCrossServerService.class, redisService);
    unregisterRedisMetricsSource();
    redisMetricsSourceRegistration =
        context
            .databaseService()
            .monitoringService()
            .registerPrometheusSource("redis", redisService::exportPrometheusMetrics);
    redisService.start();
  }

  private void unregisterRedisMetricsSource() {
    AutoCloseable registration = redisMetricsSourceRegistration;
    redisMetricsSourceRegistration = null;
    if (registration == null) {
      return;
    }
    try {
      registration.close();
    } catch (Exception exception) {
      getLogger()
          .log(Level.WARNING, "Failed to unregister Redis Prometheus metrics source", exception);
    }
  }

  private void unregisterStressMetricsSource() {
    AutoCloseable registration = stressMetricsSourceRegistration;
    stressMetricsSourceRegistration = null;
    if (registration == null) return;
    try {
      registration.close();
    } catch (Exception exception) {
      getLogger().log(Level.WARNING, "Failed to unregister stress metrics source", exception);
    }
  }

  private EconomyService selectEconomyService(PlayerVaultEconomyService vaultEconomy) {
    String configured = getConfig().getString("economy.provider", "internal");
    String mode =
        configured == null ? "internal" : configured.trim().toLowerCase(java.util.Locale.ROOT);
    boolean vaultPluginEnabled = getServer().getPluginManager().isPluginEnabled("Vault");

    EconomyProviderSelector.Selection selection =
        EconomyProviderSelector.select(
            configured, vaultPluginEnabled, context.economyService(), vaultEconomy);
    if (selection.unavailableDependency()) {
      getLogger()
          .warning(
              "economy.provider=vault but Vault is not enabled; economy operations will fail"
                  + " closed.");
    } else if (!mode.equals("internal") && !mode.equals("auto") && !mode.equals("vault")) {
      getLogger()
          .warning(
              "Unknown economy.provider '" + configured + "'; falling back to internal economy.");
    }
    getLogger()
        .info(
            "Business economy provider selected: "
                + selection.resolvedMode()
                + " (configured="
                + mode
                + ")");
    return selection.service();
  }

  private void saveNationRanks() {
    context
        .serviceRegistry()
        .find(NationRankManager.class)
        .ifPresent(
            rankManager -> {
              YamlConfiguration rankConfig = new YamlConfiguration();
              rankManager.saveRanksToConfig(rankConfig);
              try {
                rankConfig.save(new File(getDataFolder(), "ranks.yml"));
              } catch (IOException e) {
                getLogger().log(Level.SEVERE, "Failed to save nation ranks", e);
              }
            });
  }

  private ExternalProtectionService createExternalProtectionService() {
    return ExternalProtectionServices.create(this, context.configuration(), getLogger());
  }

  private void registerModules() {
    ModuleManager modules = context.moduleManager();
    if (context.configuration().moduleEnabled("nation")) modules.register(new NationModule());
    if (context.configuration().moduleEnabled("city", true)) modules.register(new CityModule());
    if (context.configuration().moduleEnabled("government"))
      modules.register(new GovernmentModule());
    if (context.configuration().moduleEnabled("resolution"))
      modules.register(new ResolutionModule());
    if (context.configuration().moduleEnabled("treasury")) modules.register(new TreasuryModule());
    if (context.configuration().moduleEnabled("treasury")) {
      // 注册财政子系统模块
      modules.register(new LoanServiceImpl());
      modules.register(new BudgetServiceImpl());
      modules.register(new BankruptcyServiceImpl());
    }
    // 经济业务聚合模块（统一查询入口，只委托已有经济/财政服务）
    if (context.configuration().moduleEnabled("economy", true)) {
      modules.register(new dev.starcore.starcore.economy.EconomyModule());
    }
    if (context.configuration().moduleEnabled("diplomacy")) modules.register(new DiplomacyModule());
    // 联盟外交系统模块
    if (context.configuration().moduleEnabled("alliance", true))
      modules.register(new AllianceModule());
    if (context.configuration().moduleEnabled("federation", true)) {
      modules.register(new dev.starcore.starcore.module.alliance.AllianceModule());
    }
    if (context.configuration().moduleEnabled("policy")) modules.register(new PolicyModule());
    if (context.configuration().moduleEnabled("resource")) modules.register(new ResourceModule());
    if (context.configuration().moduleEnabled("technology"))
      modules.register(new TechnologyModule());
    if (context.configuration().moduleEnabled("gameplay", true))
      modules.register(new GameplayModule());
    if (context.configuration().moduleEnabled("war")) modules.register(new WarModule());
    if (context.configuration().moduleEnabled("officer")) modules.register(new OfficerModule());
    if (context.configuration().moduleEnabled("event")) modules.register(new EventModule());
    if (context.configuration().moduleEnabled("map")) modules.register(new MapModule());
    if (context.configuration().restApiEnabled()) {
      modules.register(new dev.starcore.starcore.api.v1.module.RestApiModule());
    }
    // 功能模块（配置缺失时默认开启，兼容已部署服务器的旧 config.yml）
    if (context.configuration().moduleEnabled("essentials", true)) {
      modules.register(
          new EssentialsModule(
              this,
              new FoliaCompatScheduler(this),
              context.serviceRegistry().require(MessageService.class),
              context.economyService()));
    }
    if (context.configuration().moduleEnabled("pvp", true)) modules.register(new PvPModule());
    if (context.configuration().moduleEnabled("army", true)) modules.register(new ArmyModule());
    if (context.configuration().moduleEnabled("exercise", true))
      modules.register(new ExerciseModule());
    if (context.configuration().moduleEnabled("wounded", true))
      modules.register(new dev.starcore.starcore.module.army.wounded.WoundedModule());
    if (context.configuration().moduleEnabled("navy", true)) modules.register(new NavyModule());
    if (context.configuration().moduleEnabled("mercenary", true))
      modules.register(new MercenaryModule());
    // 军事学说系统模块
    if (context.configuration().moduleEnabled("doctrine", true))
      modules.register(new DoctrineModule());
    if (context.configuration().moduleEnabled("faith", true))
      modules.register(new dev.starcore.starcore.module.faith.FaithModule());
    if (context.configuration().moduleEnabled("banner", true)) modules.register(new BannerModule());
    if (context.configuration().moduleEnabled("split", true)) modules.register(new SplitModule());
    if (context.configuration().moduleEnabled("storage", true))
      modules.register(new StorageModule());
    if (context.configuration().moduleEnabled("social", true)) {
      this.socialModule = new dev.starcore.starcore.social.SocialModule();
      modules.register(this.socialModule);
    }
    // 任务模块（任务/每日任务/委托系统）
    if (context.configuration().moduleEnabled("quest", true)) {
      this.questModule = new dev.starcore.starcore.quest.QuestModule();
      modules.register(this.questModule);
    }
    // 邮件模块
    if (context.configuration().moduleEnabled("mail", true)) {
      modules.register(new dev.starcore.starcore.social.mail.MailModule());
    }
    if (context.configuration().moduleEnabled("mail-attachment", true)) {
      modules.register(new dev.starcore.starcore.module.mail.MailModule());
    }
    // 成就模块
    if (context.configuration().moduleEnabled("achievement", true)) {
      modules.register(new dev.starcore.starcore.achievement.AchievementModule(this));
    }
    // 宠物/坐骑模块
    if (context.configuration().moduleEnabled("pet", true)) {
      modules.register(new dev.starcore.starcore.pet.PetModule());
    }
    // 经济区模块
    if (context.configuration().moduleEnabled("zone", true)) {
      modules.register(new dev.starcore.starcore.zone.ZoneModule());
    }
    // 锦标赛模块
    if (context.configuration().moduleEnabled("tournament", true)) {
      modules.register(new dev.starcore.starcore.module.tournament.TournamentModule());
    }
    // 天气控制模块
    if (context.configuration().moduleEnabled("weather", true)) {
      modules.register(new WeatherModule());
    }
    // 战斗系统模块
    if (context.configuration().moduleEnabled("combat", true)) {
      modules.register(new CombatModule());
    }
    // 商店系统模块
    if (context.configuration().moduleEnabled("shop", true)) {
      modules.register(new dev.starcore.starcore.module.shop.ShopModule());
    }
    // 领地升级模块
    if (context.configuration().moduleEnabled("territory_upgrade", true)) {
      modules.register(new dev.starcore.starcore.module.territory.upgrade.TerritoryUpgradeModule());
    }
    // 副本系统模块
    if (context.configuration().moduleEnabled("dungeon", true)) {
      modules.register(new dev.starcore.starcore.module.dungeon.DungeonModule());
    }
    // 蓝图系统模块
    if (context.configuration().moduleEnabled("blueprint", true)) {
      modules.register(new BlueprintModule());
    }
    // 用户生成内容模块
    if (context.configuration().moduleEnabled("ugc", true)) {
      modules.register(new dev.starcore.starcore.ugc.UGCModule());
    }
    // 商业系统模块
    if (context.configuration().moduleEnabled("business", true)) {
      modules.register(new dev.starcore.starcore.module.business.service.BusinessServiceImpl());
    }
    // 社会模拟模块（声望/关系/影响力/文化/新闻/事件/阶层/联盟/八卦/活动）
    if (context.configuration().moduleEnabled("social-simulation", true)) {
      this.socialSimulationModule = new dev.starcore.starcore.social.SocialSimulationModule();
      modules.register(socialSimulationModule);
    }
    // 纪念日系统模块
    if (context.configuration().moduleEnabled("anniversary", true)) {
      modules.register(new AnniversaryModule());
    }
    // 紧急状态系统模块
    if (context.configuration().moduleEnabled("emergency", true)) {
      modules.register(new dev.starcore.starcore.module.emergency.EmergencyModule());
    }
    // 契约制度/租约系统模块
    if (context.configuration().moduleEnabled("lease", true)) {
      modules.register(new dev.starcore.starcore.module.lease.LeaseModule());
    }
    // 领土租借系统模块
    if (context.configuration().moduleEnabled("territory_rent", true)) {
      modules.register(new dev.starcore.starcore.module.territory.rent.TerritoryRentModule());
    }
    // 领土仲裁系统模块
    if (context.configuration().moduleEnabled("arbitration", true)) {
      modules.register(new dev.starcore.starcore.module.arbitration.ArbitrationModule());
    }
    // 繁荣度系统模块
    if (context.configuration().moduleEnabled("prosperity", true)) {
      modules.register(new dev.starcore.starcore.module.prosperity.ProsperityModule());
    }
    // 合并公投系统模块
    if (context.configuration().moduleEnabled("merge", true)) {
      modules.register(new dev.starcore.starcore.module.merge.MergeModule());
    }
    // Narrative dialogue system
    if (context.configuration().moduleEnabled("narrative", true)) {
      modules.register(new NarrativeModule());
    }
    // 王位继承系统模块
    if (context.configuration().moduleEnabled("dynasty", true)) {
      modules.register(new dev.starcore.starcore.module.dynasty.DynastyModule());
    }
    // 军事指挥中心模块（战况预览）
    if (context.configuration().moduleEnabled("military", true)) {
      modules.register(new dev.starcore.starcore.module.military.MilitaryModule());
    }
    if (context.configuration().moduleEnabled("fatigue", true)) {
      modules.register(new dev.starcore.starcore.module.army.fatigue.FatigueModule());
    }
    if (context.configuration().moduleEnabled("commander", true)) {
      modules.register(new dev.starcore.starcore.module.army.commander.CommanderModule());
    }
    if (context.configuration().moduleEnabled("donation", true)) {
      modules.register(new dev.starcore.starcore.module.donation.DonationModule());
    }
    if (context.configuration().moduleEnabled("espionage", true)) {
      modules.register(new dev.starcore.starcore.module.army.espionage.EspionageModule());
    }
    if (context.configuration().moduleEnabled("interaction_visualizer", true)) {
      modules.register(new dev.starcore.starcore.module.visualizer.InteractionVisualizerModule());
    }
    if (context.configuration().moduleEnabled("military-alliance", true)) {
      modules.register(
          new dev.starcore.starcore.module.diplomacy.military.MilitaryAllianceModule());
    }
    if (context.configuration().moduleEnabled("prisoner", true)) {
      modules.register(new dev.starcore.starcore.module.army.prisoner.PrisonerModule());
    }
    if (context.configuration().moduleEnabled("raid", true)) {
      modules.register(new dev.starcore.starcore.module.army.raid.RaidModule());
    }
    if (context.configuration().moduleEnabled("reparations", true)) {
      modules.register(new dev.starcore.starcore.module.war.reparations.ReparationsModule());
    }
    if (context.configuration().moduleEnabled("satellite", true)) {
      modules.register(new dev.starcore.starcore.module.satellite.SatelliteModule());
    }
    if (context.configuration().moduleEnabled("siege", true)) {
      modules.register(new dev.starcore.starcore.module.army.siege.SiegeModule());
    }
    if (context.configuration().moduleEnabled("sovereignty", true)) {
      modules.register(new dev.starcore.starcore.module.sovereignty.SovereigntyModule());
    }
    if (context.configuration().moduleEnabled("taxation", true)) {
      modules.register(new dev.starcore.starcore.module.treasury.TaxationServiceImpl());
    }
    if (context.configuration().moduleEnabled("tunnel", true)) {
      modules.register(new dev.starcore.starcore.module.army.tunnel.TunnelModule());
    }
    if (context.configuration().moduleEnabled("army-weather-tactics", true)) {
      modules.register(new dev.starcore.starcore.module.army.weather.WeatherTacticsModule());
    }
    // 领土升级模块 (已在第449行注册)
    // 领土租借模块 (已在第481行注册)
    // 攻城器械模块（已在第517行注册）
  }

  private void registerCommands() {
    dev.starcore.starcore.module.dungeon.DungeonModule.registerUnavailableCommand(this);
    PluginCommand command = getCommand("starcore");
    if (command == null) {
      throw new IllegalStateException("Command 'starcore' is missing from plugin.yml");
    }
    StarCoreCommand executor = new StarCoreCommand(context);
    command.setExecutor(executor);
    command.setTabCompleter(executor);

    registerAuxiliaryCommands();
    bindCommand("operations", new dev.starcore.starcore.command.OperationsCommandHandler(context));
    bindCommand(
        "insurance",
        new dev.starcore.starcore.command.InsuranceCommand(
            context
                .serviceRegistry()
                .require(
                    dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService
                        .class)));
  }

  private void initializeParticleFeedbackService() {
    particleFeedbackService = new ParticleFeedbackService(this);
    particleFeedbackListener = new ParticleFeedbackListener(particleFeedbackService);
    getServer().getPluginManager().registerEvents(particleFeedbackListener, this);
    context.serviceRegistry().register(ParticleFeedbackService.class, particleFeedbackService);
    getLogger().info("Particle feedback service initialized.");
  }

  /** 注册不属于 ModuleManager 的辅助命令（管理、经济、社交） 注意：菜单命令需要在模块启用后注册，见 registerModuleDependentCommands() */
  private void registerAuxiliaryCommands() {
    // 管理命令（mute/unmute/kick/ban/unban/jail/unjail/vanish 共用一个执行器，按命令名分发）
    var moderationExecutor =
        new dev.starcore.starcore.moderation.command.ModerationCommand(
            new dev.starcore.starcore.moderation.ModerationService(),
            new dev.starcore.starcore.moderation.VanishService());
    for (String name :
        new String[] {"mute", "unmute", "kick", "ban", "unban", "jail", "unjail", "vanish"}) {
      bindCommand(name, moderationExecutor);
    }

    bindCommand("feedback", new ParticleFeedbackCommand(particleFeedbackService));

    // 经济命令（pay/balance）
    var economyExecutor =
        new dev.starcore.starcore.essentials.command.EconomyCommand(
            this,
            context.economyService(),
            new dev.starcore.starcore.essentials.baltop.BalTopService(),
            context
                .serviceRegistry()
                .find(dev.starcore.starcore.foundation.economy.transaction.TransactionFabric.class)
                .orElse(null),
            new dev.starcore.starcore.core.scheduler.FoliaCompatScheduler(this));
    bindCommand("pay", economyExecutor);
    bindCommand("balance", economyExecutor);

    // 语言切换命令
    I18nManager i18nManager = context.serviceRegistry().find(I18nManager.class).orElse(null);
    if (i18nManager != null) {
      bindCommand(
          "language",
          new dev.starcore.starcore.foundation.i18n.command.LanguageCommand(i18nManager));
    }

    // 压力测试命令
    stressTestExecutor =
        new dev.starcore.starcore.monitoring.StressTestCommand(
            this,
            context.economyService(),
            context
                .serviceRegistry()
                .find(dev.starcore.starcore.module.war.WarService.class)
                .orElse(null));
    bindCommand("stresstest", stressTestExecutor);
    unregisterStressMetricsSource();
    var monitoring = context.databaseService().monitoringService();
    var stressMetrics = stressTestExecutor;
    stressMetricsSourceRegistration =
        monitoring.registerPrometheusSource(
            "stress",
            () -> stressMetrics.exportPrometheusMetrics(monitoring.getMonitoringInstanceId()));

    // 玩法指南命令
    bindCommand("guide", new dev.starcore.starcore.core.guide.GuideCommand(this));

    // 目标系统命令
    bindCommand("goal", new dev.starcore.starcore.core.goal.GoalCommand(this));

    // 季节系统命令
    dev.starcore.starcore.mechanics.SeasonCommand seasonCmd =
        new dev.starcore.starcore.mechanics.SeasonCommand(this);
    seasonCmd.setSeasonService(seasonService);
    seasonCmd.setContracts(seasonalWorldContracts);
    bindCommand("season", seasonCmd);

    // 宗教系统命令
    dev.starcore.starcore.mechanics.ReligionCommand religionCmd =
        new dev.starcore.starcore.mechanics.ReligionCommand(this);
    religionCmd.setReligionService(religionService);
    bindCommand("religion", religionCmd);

    // 领土命令（坐标级领土体系）
    var coordinateTerritoryService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.territory.TerritoryService.class)
            .orElse(null);
    var territorySubRegionService =
        context.serviceRegistry().find(SubRegionService.class).orElse(null);
    var territoryTempPermService =
        context.serviceRegistry().find(TemporaryPermissionService.class).orElse(null);
    var territoryTemplateService =
        context.serviceRegistry().find(PermissionTemplateService.class).orElse(null);
    var territoryLeaseSvc =
        context.serviceRegistry().find(TerritoryLeaseService.class).orElse(null);
    var territoryPermChecker = context.serviceRegistry().find(PermissionChecker.class).orElse(null);
    var territoryViz = context.serviceRegistry().find(TerritoryVisualizer.class).orElse(null);
    if (coordinateTerritoryService != null
        && territorySubRegionService != null
        && territoryTempPermService != null
        && territoryTemplateService != null
        && territoryLeaseSvc != null
        && territoryPermChecker != null) {
      bindCommand(
          "territory",
          new dev.starcore.starcore.territory.TerritoryCommand(
              this,
              coordinateTerritoryService,
              territorySubRegionService,
              territoryTempPermService,
              territoryTemplateService,
              territoryLeaseSvc,
              territoryPermChecker,
              territoryViz,
              createTerritorySelectionService()));
    }

    // 好友/公会/派对命令由 SocialModule 用共享+持久化的服务实例注册
  }

  /** Creates and registers the two-point sub-region selection listener. */
  private dev.starcore.starcore.territory.TerritorySelectionService
      createTerritorySelectionService() {
    dev.starcore.starcore.territory.TerritorySelectionService selectionService =
        new dev.starcore.starcore.territory.TerritorySelectionService(this);
    getServer()
        .getPluginManager()
        .registerEvents(
            new dev.starcore.starcore.territory.TerritorySelectionListener(selectionService), this);
    return selectionService;
  }

  /** 绑定命令执行器（同时设置 TabCompleter，若执行器支持） */
  private void bindCommand(String name, org.bukkit.command.CommandExecutor executor) {
    PluginCommand cmd = getCommand(name);
    if (cmd == null) {
      getLogger().warning("命令 '" + name + "' 未在 plugin.yml 声明，跳过注册");
      return;
    }
    cmd.setExecutor(executor);
    getLogger().info("命令 '" + name + "' 执行器已注册: " + executor.getClass().getSimpleName());
    if (executor instanceof org.bukkit.command.TabCompleter completer) {
      cmd.setTabCompleter(completer);
    }
  }

  private void registerApi() {
    this.api = new StarCoreApiProvider(context);
    getServer().getServicesManager().register(StarCoreApi.class, api, this, ServicePriority.Normal);
    getLogger().info("Registered STARCORE public API.");
  }

  private void unregisterApi() {
    if (api == null) {
      return;
    }
    getServer().getServicesManager().unregister(StarCoreApi.class, api);
    api = null;
  }

  /** 验证数据库配置安全性 - 防止空密码和弱配置 */
  private void validateDatabaseSecurity(ConfigurationService configService) {
    // Reuse the normalized type so the mariadb alias cannot bypass the MySQL
    // credential checks applied by the connection factory.
    String dbType = configService.databaseType();

    if ("mysql".equalsIgnoreCase(dbType)) {
      // Use the same resolved credential as the connection factory. This keeps the
      // security gate compatible with STARCORE_DB_PASSWORD and prevents an empty
      // legacy config value from rejecting a valid environment-injected secret.
      String password = configService.databaseMysqlPassword();

      // 检查空密码
      if (password.isEmpty()) {
        getLogger().severe("========================================");
        getLogger().severe("  ⚠  SECURITY ALERT - 安全警告");
        getLogger().severe("========================================");
        getLogger().severe("检测到 MySQL 数据库配置使用空密码！");
        getLogger().severe("这是严重的安全漏洞，可能导致：");
        getLogger().severe("  - 数据库完全暴露");
        getLogger().severe("  - 玩家数据被窃取或篡改");
        getLogger().severe("  - 服务器被完全控制");
        getLogger().severe("");
        getLogger().severe("解决方案：");
        getLogger().severe("1. 为 MySQL 设置强密码（至少16字符）");
        getLogger().severe("2. 在 config.yml 中更新 database.mysql.password");
        getLogger().severe("   或设置 STARCORE_DB_PASSWORD 环境变量");
        getLogger().severe("3. 或切换到 SQLite: database.type: sqlite");
        getLogger().severe("========================================");
        getLogger().severe("插件拒绝启动以保护服务器安全！");
        getLogger().severe("========================================");

        // 抛出异常阻止插件启动
        throw new SecurityException("MySQL password cannot be empty! 数据库密码不能为空！");
      }

      // 检查弱密码
      if (password.length() < 8) {
        getLogger().warning("========================================");
        getLogger().warning("  ⚠  SECURITY WARNING - 安全警告");
        getLogger().warning("========================================");
        getLogger().warning("MySQL 密码过短（少于8字符）！");
        getLogger().warning("建议使用至少16字符的强密码。");
        getLogger().warning("========================================");
      }

      // 检查默认密码
      if ("starcore".equalsIgnoreCase(password)
          || "password".equalsIgnoreCase(password)
          || "123456".equals(password)
          || "admin".equalsIgnoreCase(password)) {
        getLogger().severe("========================================");
        getLogger().severe("  ⚠  SECURITY ALERT - 安全警告");
        getLogger().severe("========================================");
        getLogger().severe("检测到使用默认或弱密码（长度：" + password.length() + " 字符）");
        getLogger().severe("这是严重的安全风险！");
        getLogger().severe("请立即更换为强随机密码！");
        getLogger().severe("========================================");
        throw new SecurityException("Default or weak MySQL password detected! 检测到默认或弱密码！");
      }

      getLogger().info("✅ 数据库安全验证通过");
    }
  }

  /** 注册依赖模块的命令（必须在模块启用后调用） */
  private void registerModuleDependentCommands() {
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    NationRankManager rankManager =
        context.serviceRegistry().find(NationRankManager.class).orElse(null);
    if (nationService != null && rankManager != null) {
      bindCommand(
          "nrank",
          new NationRankCommand(nationService, rankManager, new NationPermissionChecker()));
    } else {
      getLogger().warning("Nation rank dependencies unavailable, /nrank command not registered.");
    }
    // 主菜单统一进入导航中枢；国家管理仍通过 /sc nation gui 进入。
    var nationModule =
        findModule(
                context.serviceRegistry(),
                dev.starcore.starcore.module.nation.NationService.class,
                dev.starcore.starcore.module.nation.NationModule.class)
            .orElse(null);

    if (nationModule != null && nationModule.getMenuProvider() != null) {
      bindCommand(
          "menu",
          (sender, command, label, args) -> {
            if (!(sender instanceof org.bukkit.entity.Player player)) {
              sender.sendMessage("§c只有玩家可以使用此命令");
              return true;
            }
            dev.starcore.starcore.foundation.gui.NavigationHubMenu.openHub(this, player);
            return true;
          });
      getLogger().info("STARCORE menu command registered.");

      // 注册新的 HUD 菜单命令
      bindCommand(
          "hud",
          new HudCommand(
              this, nationModule, context.serviceRegistry().require(MessageService.class)));
      getLogger().info("HUD menu command registered (/hud).");
    } else {
      getLogger()
          .warning("Nation module or menu provider not available, /menu command not registered.");
    }

    // 成就命令
    if (context.configuration().moduleEnabled("achievement", true)) {
      bindCommand(
          "achievements",
          new dev.starcore.starcore.achievement.command.AchievementCommand(
              this, context.serviceRegistry()));
      getLogger().info("Achievement command registered.");
    }
  }

  /** 注册导航中枢 GUI handlers，将导航按钮直接路由到 GUI 方法，消除 performCommand 依赖 */
  private void registerNavigationGuiHandlers() {
    var registry = context.serviceRegistry();

    // 国家 GUI
    findModule(
            registry,
            dev.starcore.starcore.module.nation.NationService.class,
            dev.starcore.starcore.module.nation.NationModule.class)
        .ifPresent(
            nationModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "sc nation gui",
                  player -> {
                    if (nationModule.getMenuProvider() == null) {
                      player.sendMessage("§c国家菜单尚未就绪，请稍后再试。");
                      return;
                    }
                    nationModule.getMenuProvider().openMainMenu(player);
                  });
              getLogger().info("Navigation handler registered: sc nation gui");
            });

    // 政体 GUI (GovernmentModule implements GovernmentService)
    findModule(
            registry,
            dev.starcore.starcore.module.government.GovernmentService.class,
            dev.starcore.starcore.module.government.GovernmentModule.class)
        .ifPresent(
            govModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "sc government gui",
                  player -> {
                    new dev.starcore.starcore.module.government.gui.GovernmentMenu(
                            govModule,
                            registry
                                .find(dev.starcore.starcore.module.nation.NationService.class)
                                .orElse(null),
                            player.getUniqueId())
                        .open(player);
                  });
              getLogger().info("Navigation handler registered: sc government gui");
            });

    // 外交 GUI
    registry
        .find(dev.starcore.starcore.module.diplomacy.DiplomacyRelationService.class)
        .ifPresent(
            diplomacyService -> {
              var diplomacyMenu =
                  registry
                      .find(dev.starcore.starcore.module.diplomacy.gui.DiplomacyMenu.class)
                      .orElse(null);
              if (diplomacyMenu == null) {
                getLogger()
                    .warning("Navigation route diplomacy skipped: DiplomacyMenu is unavailable.");
                return;
              }
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "diplomacy",
                  player -> {
                    diplomacyMenu.open(player);
                  });
              getLogger().info("Navigation handler registered: diplomacy");
            });

    // 科技 GUI
    registry
        .find(dev.starcore.starcore.module.technology.TechnologyService.class)
        .ifPresent(
            techService -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "tech gui",
                  player -> {
                    new dev.starcore.starcore.module.technology.gui.TechnologyMenu(
                            registry
                                .find(
                                    dev.starcore.starcore.module.technology.TechnologyModule.class)
                                .orElse(null),
                            techService,
                            registry
                                .find(dev.starcore.starcore.module.nation.NationService.class)
                                .orElse(null))
                        .open(player);
                  });
              getLogger().info("Navigation handler registered: tech gui");
            });

    // 战争 GUI：复用 WarModule 已完成服务接线的菜单实例。
    findModule(
            registry,
            dev.starcore.starcore.module.war.WarService.class,
            dev.starcore.starcore.module.war.WarModule.class)
        .ifPresent(
            warModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "war gui",
                  player -> {
                    dev.starcore.starcore.module.war.gui.WarMenu menu = warModule.getWarMenu();
                    if (menu == null) {
                      player.sendMessage("§c战争菜单尚未就绪，请稍后再试。");
                      return;
                    }
                    menu.openMainMenu(player);
                  });
              getLogger().info("Navigation handler registered: war gui");
            });

    // 资源 GUI
    registry
        .find(dev.starcore.starcore.module.resource.ResourceService.class)
        .ifPresent(
            resourceService -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "resourcegui",
                  player -> {
                    new dev.starcore.starcore.module.resource.gui.ResourceMenu(
                            resourceService,
                            registry
                                .find(
                                    dev.starcore.starcore.module.resource.ResourcePriceService
                                        .class)
                                .orElse(null),
                            registry
                                .find(
                                    dev.starcore.starcore.module.resource.ResourceReserveService
                                        .class)
                                .orElse(null),
                            registry
                                .find(
                                    dev.starcore.starcore.module.resource.MarketOrderBookService
                                        .class)
                                .orElse(null),
                            registry
                                .find(
                                    dev.starcore.starcore.module.resource.TradeHistoryService.class)
                                .orElse(null),
                            registry
                                .find(
                                    dev.starcore.starcore.module.resource.PlayerTradeService.class)
                                .orElse(null),
                            registry
                                .find(dev.starcore.starcore.module.nation.NationService.class)
                                .orElse(null),
                            dev.starcore.starcore.foundation.animation.GuiAnimationRegistry
                                .getInstance()
                                .getGuiAnimationManager(),
                            dev.starcore.starcore.foundation.animation.GuiAnimationRegistry
                                .getInstance()
                                .getSoundFeedbackManager(),
                            registry
                                .find(dev.starcore.starcore.foundation.message.MessageService.class)
                                .orElse(null))
                        .openMainMenu(player);
                  });
              getLogger().info("Navigation handler registered: resourcegui");
            });

    // 官员 GUI
    findModule(
            registry,
            dev.starcore.starcore.module.officer.OfficerService.class,
            OfficerModule.class)
        .ifPresent(
            officerModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "sc officer gui",
                  player -> {
                    var nationService =
                        registry
                            .find(dev.starcore.starcore.module.nation.NationService.class)
                            .orElse(null);
                    if (nationService == null) {
                      player.sendMessage("§c国家服务暂不可用。");
                      return;
                    }
                    var nation = nationService.nationOf(player.getUniqueId()).orElse(null);
                    if (nation == null) {
                      player.sendMessage("§e你需要先加入一个国家才能管理官职。");
                      return;
                    }
                    player.openInventory(
                        OfficerMenu.create(player, nation, officerModule).getInventory());
                  });
              getLogger().info("Navigation handler registered: sc officer gui");
            });

    // 军队 GUI
    context.moduleManager().modules().stream()
        .filter(ArmyModule.class::isInstance)
        .map(ArmyModule.class::cast)
        .findFirst()
        .ifPresent(
            armyModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "army", player -> armyModule.getMenuListener().openMenu(player));
              getLogger().info("Navigation handler registered: army");
            });

    // 国库 GUI
    findModule(
            registry,
            dev.starcore.starcore.module.treasury.TreasuryService.class,
            TreasuryModule.class)
        .ifPresent(
            treasuryModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "sc treasury gui",
                  player -> {
                    var nationService =
                        registry
                            .find(dev.starcore.starcore.module.nation.NationService.class)
                            .orElse(null);
                    var animationManager =
                        registry
                            .find(
                                dev.starcore.starcore.foundation.animation.GuiAnimationManager
                                    .class)
                            .orElse(null);
                    var soundManager = registry.find(SoundFeedbackManager.class).orElse(null);
                    if (nationService == null) {
                      player.sendMessage("§c国家服务暂不可用。");
                      return;
                    }
                    if (nationService.nationOf(player.getUniqueId()).isEmpty()) {
                      player.sendMessage("§e你需要先加入一个国家才能查看国库。");
                      return;
                    }
                    new TreasuryMenu(
                            treasuryModule,
                            treasuryModule,
                            nationService,
                            animationManager,
                            soundManager)
                        .openMainMenu(player);
                  });
              getLogger().info("Navigation handler registered: sc treasury gui");
            });

    // 城市 GUI
    registry
        .find(dev.starcore.starcore.module.city.CityService.class)
        .ifPresent(
            cityService -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "sc city gui",
                  player -> {
                    var nationService =
                        registry
                            .find(dev.starcore.starcore.module.nation.NationService.class)
                            .orElse(null);
                    var economyService = registry.find(EconomyService.class).orElse(null);
                    if (nationService == null || economyService == null) return;
                    player.openInventory(
                        new CityMenuGui(player, cityService, nationService, economyService)
                            .getInventory());
                  });
              getLogger().info("Navigation handler registered: sc city gui");
            });

    // 社交 GUI
    registry
        .find(dev.starcore.starcore.social.friend.FriendService.class)
        .ifPresent(
            friendService -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "socialgui",
                  player -> {
                    var guildService =
                        registry
                            .find(dev.starcore.starcore.social.guild.GuildService.class)
                            .orElse(null);
                    var partyService =
                        registry
                            .find(dev.starcore.starcore.social.party.PartyService.class)
                            .orElse(null);
                    var messageService =
                        registry
                            .find(dev.starcore.starcore.social.chat.PrivateMessageService.class)
                            .orElse(null);
                    if (guildService == null || partyService == null || messageService == null)
                      return;
                    if (socialModule != null) socialModule.openMenu(player);
                  });
              getLogger().info("Navigation handler registered: socialgui");
            });

    // 称号 GUI
    registry
        .find(dev.starcore.starcore.title.TitleService.class)
        .ifPresent(
            titleService -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
                  "title list",
                  player -> {
                    if (titleModule == null) {
                      player.sendMessage("§c称号模块当前不可用。");
                      return;
                    }
                    titleModule.openMenu(player);
                  });
              getLogger().info("Navigation handler registered: title list");
            });

    // 排行榜 GUI（通过 RankingService 条件注册，避免重复）
    // 任务 GUI - 由 QuestModule 自行注册 questgui 处理器

    // 玩法指南 GUI - 注册 guide 处理器
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerHandler(
        "guide",
        player -> {
          dev.starcore.starcore.core.guide.GameplayGuideGui.openMainMenu(player);
        });
    getLogger().info("Navigation handler registered: guide");

    // 决议 GUI
    registry
        .find(dev.starcore.starcore.module.resolution.ResolutionModule.class)
        .ifPresent(
            resolutionModule -> {
              ResolutionGuiListener guiListener = resolutionModule.getGuiListener();
              if (guiListener != null) {
                dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
                    "resolution",
                    player -> {
                      guiListener.openMainMenu(player);
                      return true;
                    });
                getLogger().info("Navigation handler registered: resolution");
              }
            });

    // 天气 GUI
    registry
        .find(dev.starcore.starcore.module.weather.WeatherModule.class)
        .ifPresent(
            weatherModule -> {
              WeatherMenu menu = weatherModule.getWeatherMenu();
              if (menu != null) {
                dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
                    "weathermenu",
                    player -> {
                      menu.openMainMenu(player);
                      return true;
                    });
                getLogger().info("Navigation handler registered: weathermenu");
              }
            });

    // 锦标赛 GUI
    registry
        .find(dev.starcore.starcore.module.tournament.TournamentModule.class)
        .ifPresent(
            tournamentModule -> {
              TournamentGui gui = tournamentModule.tournamentGui();
              if (gui != null) {
                dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
                    "tournament",
                    player -> {
                      gui.openMainGui(player);
                      return true;
                    });
                getLogger().info("Navigation handler registered: tournament");
              }
            });

    // 成就 GUI
    registry
        .find(AchievementModule.class)
        .ifPresent(
            achievementModule -> {
              dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
                  "achievements",
                  player -> {
                    achievementModule.openGui(player);
                    return true;
                  });
              getLogger().info("Navigation handler registered: achievements");
            });

    var nationAccess =
        registry.find(dev.starcore.starcore.module.nation.NationService.class).orElse(null);
    if (nationAccess != null) {
      java.util.function.Predicate<org.bukkit.entity.Player> isNationMember =
          player -> nationAccess.nationOf(player.getUniqueId()).isPresent();
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc officer gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc government gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "diplomacy", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "tech gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "war gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "resourcegui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "army", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc treasury gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc treasury gui",
          player ->
              nationAccess
                  .nationOf(player.getUniqueId())
                  .map(nation -> nation.hasPermission(player.getUniqueId(), "treasury.manage"))
                  .orElse(false),
          "需要国库管理权限");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc city gui", isNationMember, "需要先加入国家");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "army", player -> registry.find(MessageService.class).isPresent(), "军队信息服务暂未就绪");
      dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
          "sc city gui", player -> registry.find(EconomyService.class).isPresent(), "城市经济服务暂未就绪");
    }
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
        "resolution",
        player -> nationAccess != null && nationAccess.nationOf(player.getUniqueId()).isPresent(),
        "需要先加入国家");
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
        "weathermenu",
        player -> nationAccess != null && nationAccess.nationOf(player.getUniqueId()).isPresent(),
        "需要先加入国家");
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
        "socialgui",
        player ->
            registry.find(dev.starcore.starcore.social.guild.GuildService.class).isPresent()
                && registry.find(dev.starcore.starcore.social.party.PartyService.class).isPresent()
                && registry
                    .find(dev.starcore.starcore.social.chat.PrivateMessageService.class)
                    .isPresent(),
        "好友服务已连接，但公会、队伍或私信服务未就绪");
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerGate(
        "title list", player -> titleModule != null, "称号系统未启用");

    getLogger().info("Navigation GUI handlers registered successfully.");
  }

  /** 初始化随机事件服务 必须在所有业务模块启用后调用，以确保服务引用可用 */
  private void initializeRandomEventService() {
    // 从 ServiceRegistry 获取所需服务
    dev.starcore.starcore.module.nation.NationService nationService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.module.nation.NationService.class)
            .orElse(null);
    dev.starcore.starcore.module.resource.ResourceService resourceService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.module.resource.ResourceService.class)
            .orElse(null);
    dev.starcore.starcore.module.treasury.TreasuryService treasuryService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.module.treasury.TreasuryService.class)
            .orElse(null);
    dev.starcore.starcore.module.technology.TechnologyService technologyService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.module.technology.TechnologyService.class)
            .orElse(null);
    dev.starcore.starcore.module.diplomacy.DiplomacyRelationService diplomacyService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.module.diplomacy.DiplomacyRelationService.class)
            .orElse(null);

    // 创建并初始化 RandomEventService
    this.randomEventService =
        new dev.starcore.starcore.event.random.RandomEventService(
            this,
            context.economyService(),
            nationService,
            resourceService,
            treasuryService,
            technologyService,
            diplomacyService);

    // 设置服务注册表（用于延迟解析）
    this.randomEventService.setServiceRegistry(context.serviceRegistry());

    // 执行初始化（注入所有静态服务引用）
    this.randomEventService.initialize();

    // 注册到 ServiceRegistry（供其他组件使用）
    context
        .serviceRegistry()
        .register(
            dev.starcore.starcore.event.random.RandomEventService.class, this.randomEventService);

    getLogger().info("RandomEventService initialized successfully.");
  }

  /** 注册 PlaceholderAPI 扩展 */
  private void registerPlaceholderAPI() {
    if (!getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
      registerRankingFeatures();
    }
    if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
      try {
        dev.starcore.starcore.pvp.stats.PvPStatsService statsService =
            context
                .serviceRegistry()
                .find(dev.starcore.starcore.pvp.stats.PvPStatsService.class)
                .orElse(null);

        if (statsService != null) {
          // 注册 RankingService（如果尚未注册）
          if (context
              .serviceRegistry()
              .find(dev.starcore.starcore.ranking.RankingService.class)
              .isEmpty()) {
            dev.starcore.starcore.ranking.RankingService rankingService =
                new dev.starcore.starcore.ranking.RankingServiceImpl(this, statsService);
            context
                .serviceRegistry()
                .register(dev.starcore.starcore.ranking.RankingService.class, rankingService);
            getLogger().info("RankingService registered.");
          }

          // 注册排行榜命令
          dev.starcore.starcore.ranking.RankingService rankingService =
              context.serviceRegistry().require(dev.starcore.starcore.ranking.RankingService.class);
          dev.starcore.starcore.ranking.command.RankingCommand rankCommand =
              new dev.starcore.starcore.ranking.command.RankingCommand(
                  this, rankingService, statsService);

          bindCommand("rank", rankCommand);
          bindCommand("leaderboard", rankCommand);
          bindCommand("top", rankCommand);
          getLogger().info("Ranking commands registered.");

          // 注册排行榜 GUI
          this.rankingGui =
              new dev.starcore.starcore.ranking.gui.RankingGUI(this, rankingService, statsService);
          dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
              "rank",
              player -> {
                if (rankingGui == null) {
                  player.sendMessage("§c排行榜当前不可用，请稍后再试。");
                  return false;
                }
                rankingGui.openMainMenu(player);
                return true;
              });
          getLogger().info("RankingGUI registered.");

        } else {
          getLogger().warning("PvP stats service not available, ranking features not registered.");
        }

      } catch (Exception e) {
        getLogger().warning("Failed to register ranking features: " + e.getMessage());
      }
      try {
        dev.starcore.starcore.title.StarCorePlaceholderExpansion expansion =
            new dev.starcore.starcore.title.StarCorePlaceholderExpansion(
                context
                    .serviceRegistry()
                    .find(dev.starcore.starcore.title.TitleService.class)
                    .orElse(null),
                context.serviceRegistry());
        if (expansion.register()) {
          placeholderExpansion = expansion;
          getLogger().info("STARCORE PlaceholderAPI expansion registered.");
        } else {
          getLogger().warning("Failed to register STARCORE PlaceholderAPI expansion.");
        }
      } catch (Exception e) {
        getLogger().warning("Failed to register PlaceholderAPI expansion: " + e.getMessage());
      }
    }

    // 数据库迁移命令
    bindCommand("dbmigrate", new dev.starcore.starcore.core.database.MigrationCommand(context));
    getLogger().info("Database migration command registered.");

    // 注册统计报告系统命令
    registerStatsCommands();
  }

  /** 注册统计报告命令 */
  private void registerRankingFeatures() {
    dev.starcore.starcore.pvp.stats.PvPStatsService statsService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.pvp.stats.PvPStatsService.class)
            .orElse(null);
    if (statsService == null) {
      getLogger().warning("PvP stats service unavailable; ranking GUI was not registered.");
      return;
    }

    dev.starcore.starcore.ranking.RankingService rankingService =
        context
            .serviceRegistry()
            .find(dev.starcore.starcore.ranking.RankingService.class)
            .orElseGet(
                () -> {
                  dev.starcore.starcore.ranking.RankingService created =
                      new dev.starcore.starcore.ranking.RankingServiceImpl(this, statsService);
                  context
                      .serviceRegistry()
                      .register(dev.starcore.starcore.ranking.RankingService.class, created);
                  return created;
                });

    dev.starcore.starcore.ranking.command.RankingCommand command =
        new dev.starcore.starcore.ranking.command.RankingCommand(
            this, rankingService, statsService);
    bindCommand("rank", command);
    bindCommand("leaderboard", command);
    bindCommand("top", command);

    this.rankingGui =
        new dev.starcore.starcore.ranking.gui.RankingGUI(this, rankingService, statsService);
    dev.starcore.starcore.foundation.gui.NavigationHubMenu.registerResultHandler(
        "rank",
        player -> {
          if (rankingGui == null) {
            player.sendMessage("排行榜当前不可用，请稍后再试。");
            return false;
          }
          rankingGui.openMainMenu(player);
          return true;
        });
    getLogger().info("Ranking commands and navigation GUI registered without PlaceholderAPI.");
  }

  private void registerStatsCommands() {
    try {
      dev.starcore.starcore.pvp.stats.PvPStatsService statsService =
          context
              .serviceRegistry()
              .find(dev.starcore.starcore.pvp.stats.PvPStatsService.class)
              .orElse(null);
      dev.starcore.starcore.ranking.RankingService rankingService =
          context
              .serviceRegistry()
              .find(dev.starcore.starcore.ranking.RankingService.class)
              .orElse(null);

      if (statsService != null && rankingService != null) {
        StatsService createdService = new StatsService(this, rankingService, statsService);
        try {
          createdService.initialize();
          this.statsReportService = createdService;
          context.serviceRegistry().register(StatsService.class, createdService);

          dev.starcore.starcore.stats.command.StatsCommand statsCommand =
              new dev.starcore.starcore.stats.command.StatsCommand(
                  this, createdService, rankingService);
          bindCommand("stats", statsCommand);
          getLogger().info("Stats command system registered.");
        } catch (RuntimeException exception) {
          createdService.shutdown();
          context.serviceRegistry().unregister(StatsService.class, createdService);
          if (statsReportService == createdService) {
            statsReportService = null;
          }
          throw exception;
        }
      }
    } catch (Exception e) {
      getLogger().warning("Failed to register stats command: " + e.getMessage());
    }
  }
}
