from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
build=json.loads((root/'run/base-merge-full-combination-20261126/result.json').read_text())
artifacts=json.loads((root/'run/combination-merge-artifacts-final-20261126/result.json').read_text())
databases=json.loads((root/'run/base-merge-databases-combination-final-20261126/result.json').read_text())
baseline=json.loads((root/'run/github-combination-merge-20261126/baseline.json').read_text())
upstream=json.loads((root/'run/github-combination-merge-20261126/upstream-archive.json').read_text())
assert build['totals']==dict(tests=1050,failures=0,errors=0,skipped=0)
assert databases['current_jar_sha256']==artifacts['jar_sha256']
summary={'status':'VERIFIED','parents':{'local':baseline['head'],'upstream':baseline['upstream']},
 'tests':build['totals'],'upstream_tests_added':5,'build':build,
 'artifacts':{'chronicle':artifacts['jar_sha256'],'sources':artifacts['sources_jar_sha256'],'starcore':'e321d2d7cc3c05ef5b30395b58b98f613824fdefdcdc113772159f91e092b5e0'},
 'api':artifacts['api'],'databases':databases,'upstream_archive':upstream,
 'limits':['No Minecraft server started. Prior third-party live evidence belongs to 5758e54b/44f450ec, not current artifacts.',
 'Chronicle tests run serially in a 256 MiB JVM with forkCount=0 and jacoco.skip=true. No local coverage result.',
 'StarCore unchanged: its separate 484-test checkpoint remains valid only for that tested scope.',
 'EpicCampaignPaperFixture compiled against current artifacts. ProductionCombinationFixture was not compiled locally because the pinned third-party jars are absent.',
 'Only syntax checks performed for new combination preparation/inspection tools. Their upstream 48 evidence regression results were preserved, not rerun.',
 'Database checks use isolated copies and standalone JVMs, not a Minecraft upgrade or live acceptance.']}
files={}
for folder in ['base-merge-full-combination-20261126','combination-merge-artifacts-final-20261126','base-merge-databases-combination-final-20261126','github-combination-merge-20261126']:
 for p in sorted((root/'run'/folder).rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.zip','.class'):
   files[folder+'/'+p.relative_to(root/'run'/folder).as_posix()]=p.read_bytes()
for name in ['run/resolve-combination-merge.py','run/run-base-merge.py','run/verify-combination-merge-artifacts.py','run/verify-base-merge-databases.py','run/MergedContributionProbe.java','run/finalize-combination-merge.py','tools/ProductionCombinationFixture.java','tools/epic-paper-clients.cjs','tools/prepare-production-combination.py','tools/inspect-production-combination.py','tools/test_production_combination.py']:
 files['tools/'+Path(name).name]=(root/name).read_bytes()
files['merged.patch']=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=root)
files['manifest.json']=(json.dumps({'summary':summary,'files':{n:sha(b) for n,b in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/github-combination-merge-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(output) as z:
 m=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(m['files'])|{'manifest.json'}
 for name,digest in m['files'].items():assert sha(z.read(name))==digest,name
summary['evidence_files']=len(files);summary['evidence_sha256']=sha(output.read_bytes())
(root/'docs/verification/github-combination-merge-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# GitHub 组合保护增量合并：2026-11-26

将上游 `9a0c103`／`3f79820` 合入 `89c361f`，接通 WorldGuard 纪念点创建保护，并保留原有 NPC 会话／生命周期修复和成员界面测试入口。解决 6 个文件冲突，没有启动 Minecraft。

| 构件 | SHA-256 |
| --- | --- |
| Chronicle | `{summary['artifacts']['chronicle']}` |
| Sources | `{summary['artifacts']['sources']}` |
| StarCore（本轮未改） | `{summary['artifacts']['starcore']}` |
| 本轮证据 ZIP | `{summary['evidence_sha256']}` |

完整 `clean verify` **1,050 项通过，0 failures／errors／skipped**，包括上游新增的 5 项保护边界测试。单个 256 MiB JVM，forkCount=0、jacoco.skip=true；不提供本机覆盖率。250 个源码／资源／测试文件与冻结副本一致，选定类与未重定位 JAR 字节一致；最终 shade 保留正常重定位。8 类旧公开声明及描述符保持。双插件史诗夹具针对当前构件编译通过，JavaScript 与 8 个 Python 工具语法通过。

创建检查使用玩家真实 WorldGuard 身份，覆盖纪念点相邻及上方共 36 个位置，不加载区块。管理员权限不替代领地权限；服务存在但停用、接口或查询失败时拒绝创建。只检查创建时授权，不自动清除后续规则变更下的既有点位。新增组合工具显式使用 UTF-8，兼容 Windows 中文日志和配置。

最终 JAR 对两份真实旧数据库副本以 1、2、1、0 批次恢复，再分别启动独立 JVM 重开，恢复量均为 0、贡献仍为 8；各 38 张原表原列完全保持。此检查不是 Minecraft 整服升级。原备份与失败历史均保留。

[证据包](verification/github-combination-merge-20261126-evidence.zip) 含 {len(files)} 个文件，[机器摘要](verification/github-combination-merge-20261126-summary.json) 保存原始构建、API 与数据库结果。

上游[组合验收](PRODUCTION-COMBINATION-TEST-REPORT.md)的 603 个清单文件逐个哈希通过，原 ZIP SHA-256 为 `2c7d1081e8d8ca6b2cabaa61426de260ba1e48cca57cb97f22e0e7d68574fba1`。其 887 项与 Paper 双路线各三次启动、48 项证据回归属于 Chronicle `5758e54b…96daa`／StarCore `44f450ec…8518d`，没有移用于当前构件。本机缺少固定哈希的第三方 JAR，未编译新 ProductionCombinationFixture，也未重跑组合证据回归。在线热卸载仍保留其真实失败边界。

StarCore 沿用独立 484 项经济检查点。继续推进社交／GUI 所有权、外部经济不确定结果、全栈 Folia 与长期容量；当前构件实服验收保持待办，十阶段尚未全部完成。
'''
(root/'docs/GITHUB-COMBINATION-MERGE-20261126.md').write_text(report,encoding='utf-8')
note=f'2026-11-26 当前源码检查点：[同步 WorldGuard 保护增量](GITHUB-COMBINATION-MERGE-20261126.md)。已合入上游 `3f79820`；Chronicle **1,050 项完整回归通过**，JAR `{artifacts["jar_sha256"][:8]}…{artifacts["jar_sha256"][-6:]}`，两份数据库副本恢复／重开及公开 API 核验通过。StarCore 保持 484 项检查点。只做源码与单元测试，未启动 Minecraft；所选组合旧构件的实服记录单独保留。'
for name in ['README.md','docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md']:
 p=root/name;t=p.read_text(encoding='utf-8');pos=t.index('\n\n')+2
 inserted=note.replace('(GITHUB-COMBINATION-MERGE-20261126.md)','(docs/GITHUB-COMBINATION-MERGE-20261126.md)') if name=='README.md' else note
 p.write_text(t[:pos]+inserted+'\n\n'+t[pos:],encoding='utf-8')
p=root/'docs/HANDOFF-2026-11-26.md';t=p.read_text(encoding='utf-8')
t=t.replace('前一合并构件、1,045 项回归与源码范围见 [合并报告](GITHUB-BASE-MERGE-20261126.md)','当前合并构件、1,050 项回归与源码范围见 [合并报告](GITHUB-COMBINATION-MERGE-20261126.md)',1)
t=t.replace('## 十阶段状态','## 上游历史检查点的十阶段状态',1)
pos=t.index('## 获取代码')
current='''## 当前分支的十阶段续接

下表更新到当前源码；后文保留上游冻结构件的验收记录。

| 阶段 | 当前源码／验证 | 继续工作 |
| --- | --- | --- |
| 1. 国家史诗 | 完整战略链、任务回执、唯一结算与两种成员／贡献格式兼容 | 当前构件实服、战场胜利及拒绝操作重试 |
| 2. 国库 | 持久编号、未知隔离、SQL 完整凭据归档；多 JVM 契约 | 外部经济未知结果、规模与生产核验 |
| 3. 任务恢复 | UNKNOWN 对账、失败／放弃新轮次、旧回包隔离；源码及多 JVM 契约通过 | 当前构件玩家恢复实服 |
| 4. 贡献 | 援助、贸易／退款、即时加工／定时工厂来源，恢复去重与分页 | 第三方生产来源、长期负载与实服 |
| 5. 成员复核 | 原生锁内授权、公开复核／退出／重入、两种旧退出证明兼容 | 国家消失等当前构件实服流程 |
| 6. 精确历史 | 五类原生提交来源、游标、恢复锚点、旧证据保持 | 旧来源完整核对、更多权威来源和实服 |
| 7. Folia | 调度、周期、传送、命令、经济所有权已分批修复 | 社交／GUI 等调用链、完整生命周期与全栈实服 |
| 8. 第三方组合 | 合入 WorldGuard 创建授权；旧冻结组合证据保留 | 当前构件所选组合、在线热卸载及其他组合不在通过范围 |
| 9. 容量与运维 | schema 8 分批、历史游标、版本目录、SQL 工厂／贸易／国库归档 | 首次迁移峰值、文件模式全量、长期压力与维护 |
| 10. 内容编辑 | YAML／JSON、严格校验与示例已具备 | 拖拽编辑器仍是可选增强 |

'''
p.write_text(t[:pos]+current+t[pos:],encoding='utf-8')
print(json.dumps({'evidence_files':len(files),'evidence_sha256':summary['evidence_sha256'],'artifacts':summary['artifacts']}))
