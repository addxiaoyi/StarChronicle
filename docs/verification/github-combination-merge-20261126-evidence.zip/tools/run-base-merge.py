from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
phase=sys.argv[1];out=root/'run'/('base-merge-'+phase+'-20261126');out.mkdir(exist_ok=False)
env=os.environ.copy();env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']=r'-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8 -javaagent:C:\Users\Administrator\.m2\repository\org\mockito\mockito-core\5.15.2\mockito-core-5.15.2.jar'
args=['cmd.exe','/d','/c',str(root/'mvnw.cmd'),'-o','-B','-ntp','-DforkCount=0','-Djacoco.skip=true']
if phase.startswith('full'):args+=['clean','verify']
elif phase.startswith('package'):args+=['-DskipTests','verify']
elif phase.startswith('compile'):args+=['-DskipTests','test-compile']
else:args+=['-Dtest='+sys.argv[2],'test']
for directory in ('src/main','src/test'):
 shutil.copytree(root/directory,out/directory)
(out/'command.json').write_text(json.dumps({'args':args,'maven_opts':env['MAVEN_OPTS']},indent=2))
start=time.monotonic()
with (out/'maven.log').open('wb') as log: result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
totals={k:0 for k in ('tests','failures','errors','skipped')}
log=(out/'maven.log').read_text(encoding='utf-8',errors='replace')
for suite in re.findall(r'\[INFO\] Running ([\w.$]+)',log):
 path=root/'target/surefire-reports'/('TEST-'+suite+'.xml')
 if path.exists():
  (out/'surefire').mkdir(exist_ok=True);shutil.copy2(path,out/'surefire'/path.name)
  data=ET.parse(path).getroot()
  for key in totals:totals[key]+=int(data.attrib.get(key,0))
summary={'exit_code':result.returncode,'seconds':time.monotonic()-start,'totals':totals,'args':args}
if phase.startswith('full') and result.returncode==0:summary['artifacts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'target').glob('*.jar')}
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary));raise SystemExit(result.returncode)
