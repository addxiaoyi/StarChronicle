from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
pattern=re.compile(r'<<<<<<<[^\n]*\n([\s\S]*?)\n=======\n([\s\S]*?)\n>>>>>>>[^\n]*(?:\n|$)')
names=['README.md','docs/HANDOFF-2026-11-25.md','docs/HANDOFF-2026-11-26.md','docs/NPC-INTEGRATIONS.md','docs/REMAINING-WORK.md','tools/epic-paper-clients.cjs']
for name in names:
    path=root/name;original=path.read_text(encoding='utf-8')
    backup=root/'run/github-combination-merge-20261126/conflicts'/name
    backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(original,encoding='utf-8')
    def resolve(match):
        ours,theirs=match[1],match[2]
        if name=='tools/epic-paper-clients.cjs':return ours+'\n  }\n'+theirs+'\n'
        if name=='docs/HANDOFF-2026-11-26.md':
            return ours.split('\n\n')[0].replace('`9de34ec`','`3f79820`').replace('最新合并构件','前一合并构件')+'\n\n'+theirs+'\n'
        if name=='docs/NPC-INTEGRATIONS.md':return ours+'\n'
        if ours.startswith('2026-11-26 当前合并检查点'):
            link=('docs/' if name=='README.md' else '')+'PRODUCTION-COMBINATION-TEST-REPORT.md'
            note=f'同步合入上游 `3f79820` 的 [WorldGuard 创建保护与第三方组合记录]({link})：887 项及 Paper 双路线各三次启动属于 Chronicle `5758e54b…96daa`／StarCore `44f450ec…8518d`，保留原始失败和离线维护边界。当前分支继续源码与单元测试；旧构件实服证明不转用于当前构件。'
            return note+'\n\n'+ours.replace('当前合并检查点','前一合并检查点',1)+'\n'
        if ours.startswith('| 隔离 Paper'):
            ours=ours.replace('| 隔离 Paper 已验收，待生产组合 |','| 旧构件所选隔离组合已验收 |',1).replace('当前同一构件双路线三次启动','报告内冻结构件双路线三次启动',1)
        return ours+'\n'
    changed,count=pattern.subn(resolve,original)
    assert count>0,name
    assert '<<<<<<<' not in changed and '>>>>>>>' not in changed,name
    path.write_text(changed,encoding='utf-8')
    print(name,count)
