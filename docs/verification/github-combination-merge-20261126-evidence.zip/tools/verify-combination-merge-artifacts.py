from pathlib import Path
import hashlib,json,re,subprocess,zipfile,sys
root=Path(__file__).resolve().parents[1];out=root/'run'/('combination-merge-artifacts-'+sys.argv[1]+'-20261126');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
jar=root/'target/starchronicle-0.1.0-SNAPSHOT.jar';original=root/'target/original-starchronicle-0.1.0-SNAPSHOT.jar';old=root/'run/github-combination-merge-20261126/starchronicle-0.1.0-SNAPSHOT.jar'
classes=root/'target/classes';types=['api/ChronicleService','core/RuleEngine','core/ContributionLedger','core/EpicCampaignLedger','core/QuestGateLedger','core/MemberReviewLedger','paper/StarChroniclePlugin','integration/StarCoreNationalVoteAuthority','api/MemberAuthority','core/EpicContributionProjection','integration/StarCoreMemberAuthority','paper/MemoryProtection']
prefix='io/github/addxiaoyi/starchronicle/'
compiled={};packaged={}
with zipfile.ZipFile(jar) as final,zipfile.ZipFile(original) as before_shade:
 for kind in types:
  relative=prefix+kind;directory,stem=relative.rsplit('/',1)
  for path in sorted((classes/directory).glob(stem+'*.class')):
   name=path.relative_to(classes).as_posix();raw=path.read_bytes()
   assert before_shade.read(name)==raw and int.from_bytes(final.read(name)[6:8],'big')==65
   compiled[name]=sha(raw);packaged[name]=sha(final.read(name))
sources={}
for name in ('src/main','src/test'):
 for path in (root/name).rglob('*'):
  if path.is_file():
   relative=path.relative_to(root).as_posix();assert path.read_bytes()==(root/'run/base-merge-full-combination-20261126'/relative).read_bytes(),relative
   sources[relative]=sha(path.read_bytes())
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin');apis={}
for kind in types[:8]:
 methods=[]
 for label,artifact in [('old',old),('current',jar)]:
  result=subprocess.run([str(java/'javap.exe'),'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),(prefix+kind).replace('/','.')],capture_output=True,check=True)
  (out/(label+'-'+kind.rsplit('/',1)[-1]+'.txt')).write_bytes(result.stdout)
  methods.append(set(re.findall(r'  (public [^\n]+;)\r?\n    descriptor: ([^\r\n]+)',result.stdout.decode())))
 assert methods[0]<=methods[1],(kind,methods[0]-methods[1]);apis[kind]={'preserved':len(methods[0]),'added':len(methods[1]-methods[0])}
runtime=root/'run/paper-epic-1faf2ba2-dungeon-phases-2'
dependencies=[jar,root.parent/'StarChronicle-audit/starcore-all-stages/target/starcore-1.0.0.jar']+sorted((runtime/'libraries').rglob('*.jar'))
assert len(dependencies)>5
fixture=root/'tools/EpicCampaignPaperFixture.java';argfile=out/'fixture.args'
argfile.write_text('-encoding\nUTF-8\n-proc:none\n--release\n21\n-classpath\n"'+';'.join(p.as_posix() for p in dependencies)+'"\n-d\n"'+out.as_posix()+'"\n"'+fixture.as_posix()+'"\n',encoding='utf-8')
result=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(argfile)],capture_output=True)
(out/'fixture.log').write_bytes(result.stdout+result.stderr);assert result.returncode==0
summary={'status':'VERIFIED','jar_sha256':sha(jar.read_bytes()),'sources_jar_sha256':sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes()),'compiled_classes':compiled,'packaged_classes':packaged,'source_files':len(sources),'source_hashes':sources,'api':apis,'fixture_compiled':True,'limits':'All selected classes equal tested pre-shade bytes; production shade relocates Jackson/YAML references. Final Java 21 descriptors verified. No live server.'}
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['compiled_classes','packaged_classes','source_hashes']}))
