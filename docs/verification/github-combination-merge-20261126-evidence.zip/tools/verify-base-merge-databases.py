from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];out=root/'run'/('base-merge-databases-'+sys.argv[1]+'-20261126');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
archive=root/'docs/verification/national-epic-ledgers-linux-20261126-evidence.zip'
metadata=json.loads((root/'docs/verification/national-epic-ledgers-linux-20261126-summary.json').read_text(encoding='utf-8'))
assert sha(archive.read_bytes())==metadata['evidence_archive']['sha256']
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('evidence-manifest.json'));assert len(manifest)==284
 assert set(z.namelist())==set(manifest)|{'evidence-manifest.json'}
 for name,digest in manifest.items():assert sha(z.read(name))==digest,name
 for route,folder in [('dungeon','paper-epic-a85e1f50-dungeon-ledgers-20261126-2'),('war','paper-epic-a85e1f50-war-ledgers-20261126-1')]:
  raw=z.read(folder+'/plugins/StarChronicle/chronicle.db');(out/(route+'-original.db')).write_bytes(raw)
def snapshot(path, original=None):
 with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
  tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
  result={}
  for table in tables:
   columns=[r[1] for r in db.execute('PRAGMA table_info("'+table.replace('"','""')+'")')]
   if original and table in original:columns=original[table]['columns']
   select=','.join('"'+c.replace('"','""')+'"' for c in columns)
   rows=sorted([json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in db.execute('SELECT '+select+' FROM "'+table.replace('"','""')+'"')])
   result[table]={'columns':columns,'rows':rows}
  return result
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
jar=root/'target/starchronicle-0.1.0-SNAPSHOT.jar'
source=root/'run/MergedContributionProbe.java';shutil.copy2(source,out/source.name)
compile=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','-encoding','UTF-8','-cp',str(jar),'-d',str(out),str(source)],capture_output=True)
(out/'compile.log').write_bytes(compile.stdout+compile.stderr);assert compile.returncode==0
summary={'status':'VERIFIED','archive_sha256':sha(archive.read_bytes()),'upstream_evidence_files':284,'current_jar_sha256':sha(jar.read_bytes()),'routes':{}}
for route in ('dungeon','war'):
 original=out/(route+'-original.db');copy=out/(route+'-merged.db');shutil.copy2(original,copy);before=snapshot(original)
 outcomes=[]
 for mode in ('first','reopen'):
  process=subprocess.run([str(java/'java.exe'),'-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-cp',str(jar)+';'+str(out),'MergedContributionProbe',str(copy),mode],capture_output=True)
  (out/(route+'-'+mode+'.log')).write_bytes(process.stdout+process.stderr);assert process.returncode==0,(route,mode)
  outcomes.append(json.loads(process.stdout))
 after=snapshot(copy,before)
 for table,rows in before.items():
  # The migrator adds bookkeeping to schema versions; all business rows must remain exact.
  assert after[table]==rows,(route,table)
 assert len(after['epic_contribution_projections']['rows'])==4
 assert len(after['contribution_receipts']['rows'])==8
 with sqlite3.connect(copy.resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert set(r[0] for r in db.execute('SELECT attempt FROM quest_gates'))=={1}
 summary['routes'][route]={'source_sha256':sha(original.read_bytes()),'result_sha256':sha(copy.read_bytes()),'unchanged_original_tables':len(before),'table_hashes':{table:sha(json.dumps(rows,ensure_ascii=False).encode()) for table,rows in before.items()},'results':outcomes}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({**summary,'routes':{k:{kk:vv for kk,vv in v.items() if kk!='table_hashes'} for k,v in summary['routes'].items()}}))
