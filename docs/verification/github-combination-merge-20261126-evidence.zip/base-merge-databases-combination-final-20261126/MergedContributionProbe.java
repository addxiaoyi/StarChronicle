import io.github.addxiaoyi.starchronicle.core.RuleEngine;
import io.github.addxiaoyi.starchronicle.persistence.SqliteStore;
import java.nio.file.Path;
import java.time.Clock;
import java.util.*;

public final class MergedContributionProbe {
    public static void main(String[] args) {
        if(args.length!=2)throw new IllegalArgumentException("copy.db first|reopen");
        try(var store=new SqliteStore(Path.of(args[0]))) {
            var engine=new RuleEngine(store,List.of(),Clock.systemUTC());
            var batches=new ArrayList<Integer>();
            if(args[1].equals("first")) {
                for(int size:List.of(1,2,2,2))batches.add(engine.recoverEpicContributions(size));
                if(!batches.equals(List.of(1,2,1,0)))throw new IllegalStateException("Unexpected recovery batches: "+batches);
            } else {
                batches.add(engine.recoverEpicContributions(100));
                if(batches.getFirst()!=0)throw new IllegalStateException("Recovery repeated after process restart");
            }
            var entries=engine.contributions(null,null,0,100);
            if(entries.size()!=8)throw new IllegalStateException("Contributions were lost or duplicated");
            System.out.println(SqliteStore.json(Map.of("status","PASS","mode",args[1],"batches",batches,"contributions",entries.size(),"nativeCalls",0)));
        }
    }
}
