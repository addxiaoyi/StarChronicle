package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.ResourceQuota;
import dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceQuotaRenewalTest {
  @TempDir Path directory;
  private static final NationId EXPORTER = TradeSnapshotValidationTest.EXPORTER;
  private static final NationId IMPORTER = TradeSnapshotValidationTest.IMPORTER;

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void expiredQuotaRenewsOnceAndEnforcesTheNewPeriodLimit(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var old = expired(EXPORTER, type);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertTrue(service.useQuota(old.quotaId(), 5));
    assertFalse(service.useQuota(old.quotaId(), 1));
    var current = service.getQuota(old.quotaId()).orElseThrow();
    assertEquals(old.resetTime(), current.startTime());
    assertEquals(old.resetTime().plusSeconds(3600), current.resetTime());
    assertEquals(5, current.currentAmount());
    assertEquals(5, old.currentAmount());
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void repeatedSchedulerTicksCannotEraseUsageInTheNewPeriod(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var old = expired(EXPORTER, type);
    var events = mock(StarCoreEventBus.class);
    service.setEventBus(events);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    service.resetExpiredQuotas();
    assertTrue(service.useQuota(old.quotaId(), 3));
    service.resetExpiredQuotas();
    assertEquals(3, service.getQuota(old.quotaId()).orElseThrow().currentAmount());
    verify(events, times(1)).publish(isA(SimpleResourceTradeService.QuotaResetEvent.class));
    verify(events, times(1)).publish(isA(SimpleResourceTradeService.QuotaRefreshEvent.class));
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void anUnexpiredQuotaRetainsItsOriginalWindowAndUsage(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var start = Instant.now().minusSeconds(10);
    var quota =
        new ResourceQuota(
            UUID.randomUUID(), EXPORTER, "iron", 5, 4, start, start.plusSeconds(3600), type);
    service.restoreQuotas(Map.of(quota.quotaId(), quota));
    service.resetExpiredQuotas();
    assertTrue(service.useQuota(quota.quotaId(), 1));
    assertFalse(service.useQuota(quota.quotaId(), 1));
    var current = service.getQuota(quota.quotaId()).orElseThrow();
    assertEquals(quota.startTime(), current.startTime());
    assertEquals(quota.resetTime(), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void tradeReservationsAndReleaseUseTheRenewedQuotas(boolean firstDelivered) {
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(EXPORTER, "iron")).thenReturn(5L);
    when(resources.consume(EXPORTER, "iron", 5)).thenReturn(true);
    when(resources.grant(IMPORTER, "iron", 5)).thenReturn(firstDelivered);
    when(resources.grant(EXPORTER, "iron", 5)).thenReturn(true);
    var service = new SimpleResourceTradeService(resources);
    var exported = expired(EXPORTER, QuotaType.EXPORT);
    var imported = expired(IMPORTER, QuotaType.IMPORT);
    service.restoreQuotas(Map.of(exported.quotaId(), exported, imported.quotaId(), imported));
    var agreement = service.createTradeAgreement(EXPORTER, IMPORTER, "iron", 5, 2, 300);
    assertEquals(firstDelivered, service.executeTradeAgreement(agreement.agreementId()));
    long expected = firstDelivered ? 5 : 0;
    assertEquals(expected, service.getQuota(exported.quotaId()).orElseThrow().currentAmount());
    assertEquals(expected, service.getQuota(imported.quotaId()).orElseThrow().currentAmount());
    if (!firstDelivered) {
      when(resources.grant(IMPORTER, "iron", 5)).thenReturn(true);
      assertTrue(service.executeTradeAgreement(agreement.agreementId()));
    }
    assertFalse(service.executeTradeAgreement(agreement.agreementId()));
    assertEquals(
        exported.resetTime(), service.getQuota(exported.quotaId()).orElseThrow().startTime());
    assertEquals(
        imported.resetTime(), service.getQuota(imported.quotaId()).orElseThrow().startTime());
    verify(resources, times(firstDelivered ? 1 : 2)).consume(EXPORTER, "iron", 5);
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void savedRenewalAndUsageSurviveRestartWithoutAnotherReset(String engine) throws Exception {
    var helper = new TradeSnapshotValidationTest();
    helper.directory = directory;
    var storage = helper.seeded(engine);
    var state = storage.load();
    var old = expired(IMPORTER, QuotaType.IMPORT);
    state.setProperty("quota.0.max", "5");
    state.setProperty("quota.0.current", "5");
    state.setProperty("quota.0.start", Long.toString(old.startTime().toEpochMilli()));
    state.setProperty("quota.0.reset", Long.toString(old.resetTime().toEpochMilli()));
    storage.save(state);
    var module = TradeSnapshotValidationTest.module(storage);
    var service = module.getTradeService();
    UUID id = TradeSnapshotValidationTest.QUOTA;
    assertTrue(service.useQuota(id, 5));
    assertTrue(module.grant(EXPORTER, "luxury", 1));
    var saved = storage.load();
    assertEquals(Long.toString(old.resetTime().toEpochMilli()), saved.getProperty("quota.0.start"));
    assertEquals(
        Long.toString(old.resetTime().plusSeconds(3600).toEpochMilli()),
        saved.getProperty("quota.0.reset"));
    var restarted = TradeSnapshotValidationTest.module(storage);
    assertFalse(restarted.getTradeService().useQuota(id, 1));
    restarted.getTradeService().resetExpiredQuotas();
    assertEquals(5, restarted.getTradeService().getQuota(id).orElseThrow().currentAmount());
    assertEquals(saved, storage.load());
    assertEquals(module.authorityDomainId(), restarted.authorityDomainId());
    assertEquals(1, restarted.amount(EXPORTER, "luxury"));
  }

  @ParameterizedTest
  @ValueSource(longs = {-1, 0, 1, 20000000001L})
  void exactDeadlineAndMissedPeriodsStayAlignedToTheOriginalWindow(long offsetNanos) {
    Instant end = Instant.parse("2026-11-26T00:00:10Z");
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class),
            null,
            Clock.fixed(end.plusNanos(offsetNanos), ZoneOffset.UTC));
    var old = quota(end.minusSeconds(10), end);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertEquals(offsetNanos >= 0, service.useQuota(old.quotaId(), 5));
    assertFalse(service.useQuota(old.quotaId(), 1));
    var current = service.getQuota(old.quotaId()).orElseThrow();
    Instant expectedStart =
        offsetNanos < 0 ? old.startTime() : end.plusSeconds(offsetNanos >= 20000000000L ? 20 : 0);
    assertEquals(expectedStart, current.startTime());
    assertEquals(expectedStart.plusSeconds(10), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @Test
  void wallClockRollbackCannotEraseAlreadyUsedQuota() {
    Instant end = Instant.parse("2026-11-26T00:00:10Z");
    var time = new AtomicReference<>(end);
    Clock clock = mock(Clock.class);
    when(clock.instant()).thenAnswer(ignored -> time.get());
    var service = new SimpleResourceTradeService(mock(ResourceService.class), null, clock);
    var old = quota(end.minusSeconds(10), end);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertTrue(service.useQuota(old.quotaId(), 5));
    time.set(end.minusSeconds(100));
    assertFalse(service.useQuota(old.quotaId(), 1));
    assertEquals(end, service.getQuota(old.quotaId()).orElseThrow().startTime());
    time.set(end.plusSeconds(10));
    assertTrue(service.useQuota(old.quotaId(), 5));
    assertFalse(service.useQuota(old.quotaId(), 1));
    assertEquals(end.plusSeconds(10), service.getQuota(old.quotaId()).orElseThrow().startTime());
  }

  @Test
  void veryOldMillisecondPeriodAdvancesWithoutAWindowCounterOrLoop() {
    Instant now = Instant.parse("2026-11-26T00:00:00.123456789Z");
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class), null, Clock.fixed(now, ZoneOffset.UTC));
    var old = quota(Instant.ofEpochMilli(Long.MIN_VALUE), Instant.ofEpochMilli(Long.MIN_VALUE + 1));
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertTimeout(Duration.ofSeconds(1), () -> assertTrue(service.useQuota(old.quotaId(), 5)));
    assertFalse(service.useQuota(old.quotaId(), 1));
    var current = service.getQuota(old.quotaId()).orElseThrow();
    assertEquals(Instant.ofEpochMilli(now.toEpochMilli()), current.startTime());
    assertEquals(Instant.ofEpochMilli(now.toEpochMilli() + 1), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @Test
  void anUnrepresentableNextWindowKeepsTheOriginalQuotaIntact() {
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class),
            null,
            Clock.fixed(Instant.ofEpochMilli(1000), ZoneOffset.UTC));
    var old = quota(Instant.ofEpochMilli(Long.MIN_VALUE), Instant.EPOCH);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertThrows(IllegalStateException.class, () -> service.useQuota(old.quotaId(), 1));
    var current = service.getQuota(old.quotaId()).orElseThrow();
    assertEquals(old.startTime(), current.startTime());
    assertEquals(old.resetTime(), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @Test
  void subMillisecondWindowCannotTurnIntoAnInvalidStoredPeriod() {
    var old = quota(Instant.EPOCH, Instant.EPOCH.plusNanos(1));
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class), null, Clock.fixed(old.resetTime(), ZoneOffset.UTC));
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertThrows(IllegalStateException.class, service::resetExpiredQuotas);
    var current = service.getQuota(old.quotaId()).orElseThrow();
    assertEquals(old.startTime(), current.startTime());
    assertEquals(old.resetTime(), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @Test
  void creationUsesTheSameClockAsRenewal() {
    Instant now = Instant.parse("2026-11-26T00:00:00Z");
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class), null, Clock.fixed(now, ZoneOffset.UTC));
    var quota = service.createQuota(EXPORTER, "iron", 5, 3600, QuotaType.EXPORT);
    assertEquals(now, quota.startTime());
    assertEquals(now.plusSeconds(3600), quota.resetTime());
    assertTrue(service.useQuota(quota.quotaId(), 5));
    assertFalse(service.useQuota(quota.quotaId(), 1));
  }

  @Test
  void concurrentFirstUsesShareOneRenewalAndOneLimit() throws Exception {
    Instant end = Instant.parse("2026-11-26T00:00:10Z");
    var service =
        new SimpleResourceTradeService(
            mock(ResourceService.class), null, Clock.fixed(end, ZoneOffset.UTC));
    var old = quota(end.minusSeconds(10), end);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    try (var workers = Executors.newFixedThreadPool(4)) {
      var results = new ArrayList<Future<Boolean>>();
      for (int i = 0; i < 8; i++)
        results.add(workers.submit(() -> service.useQuota(old.quotaId(), 1)));
      int accepted = 0;
      for (var result : results) if (result.get(5, TimeUnit.SECONDS)) accepted++;
      assertEquals(5, accepted);
      assertFalse(service.useQuota(old.quotaId(), 1));
      assertEquals(5, service.getQuota(old.quotaId()).orElseThrow().currentAmount());
    }
  }

  private static ResourceQuota quota(Instant start, Instant end) {
    return new ResourceQuota(
        UUID.randomUUID(), EXPORTER, "iron", 5, 5, start, end, QuotaType.EXPORT);
  }

  private static ResourceQuota expired(NationId nation, QuotaType type) {
    var end = Instant.now().minusSeconds(10);
    return new ResourceQuota(
        UUID.randomUUID(), nation, "iron", 5, 5, end.minusSeconds(3600), end, type);
  }
}
