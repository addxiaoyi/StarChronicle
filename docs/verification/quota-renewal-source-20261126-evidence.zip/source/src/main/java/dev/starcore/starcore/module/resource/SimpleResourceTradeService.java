package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.*;
import dev.starcore.starcore.module.treasury.NationTransferService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

/** 资源贸易服务实现 */
public class SimpleResourceTradeService implements ResourceTradeService {
  private final ResourceService resourceService;
  // Native inventory saves call back into this service; one monitor prevents lock inversion.
  private final Object stateLock;
  private final TreasuryService treasuryService;
  private final Clock quotaClock;
  private final Map<UUID, TradeRoute> tradeRoutes;
  private final Map<UUID, TradeAgreement> tradeAgreements;
  private final Map<UUID, ResourceEmbargo> embargoes;
  private final Map<UUID, ResourceQuota> quotas;
  private volatile boolean routesDirty;
  private volatile boolean embargoesDirty;
  private volatile boolean quotasDirty;
  private StarCoreEventBus eventBus;
  private StarCoreScheduler scheduler;

  public SimpleResourceTradeService(ResourceService resourceService) {
    this(resourceService, null);
  }

  public SimpleResourceTradeService(
      ResourceService resourceService, TreasuryService treasuryService) {
    this(resourceService, treasuryService, Clock.systemUTC());
  }

  SimpleResourceTradeService(
      ResourceService resourceService, TreasuryService treasuryService, Clock quotaClock) {
    this.resourceService = Objects.requireNonNull(resourceService, "resourceService");
    this.stateLock = resourceService instanceof ResourceModule ? resourceService : this;
    this.treasuryService = treasuryService;
    this.quotaClock = Objects.requireNonNull(quotaClock, "quotaClock");
    this.tradeRoutes = new ConcurrentHashMap<>();
    this.tradeAgreements = new ConcurrentHashMap<>();
    this.embargoes = new ConcurrentHashMap<>();
    this.quotas = new ConcurrentHashMap<>();
  }

  /** 设置事件总线用于发布贸易事件 */
  public void setEventBus(StarCoreEventBus eventBus) {
    this.eventBus = eventBus;
  }

  /** 设置调度器用于定时刷新配额 */
  public void setScheduler(StarCoreScheduler scheduler) {
    this.scheduler = scheduler;
    if (scheduler != null) {
      // 每小时检查并重置过期的配额
      scheduler.runSyncTimer(() -> resetExpiredQuotas(), 60 * 60 * 20L, 60 * 60 * 20L);
    }
  }

  /** 发布贸易事件 */
  private void publishTradeEvent(Object event) {
    if (eventBus != null) {
      eventBus.publish(event);
    }
  }

  @Override
  public TradeRoute createTradeRoute(
      NationId originNationId, NationId destinationNationId, String routeName) {
    synchronized (stateLock) {
      requireAvailable();
      requireNationId(originNationId, "originNationId");
      requireNationId(destinationNationId, "destinationNationId");
      if (originNationId.equals(destinationNationId)) {
        throw new IllegalArgumentException("Trade route nations must differ");
      }
      String normalizedRouteName = requireRouteName(routeName);
      UUID routeId = UUID.randomUUID();
      TradeRoute route =
          new TradeRoute(
              routeId, originNationId, destinationNationId, normalizedRouteName, Instant.now());
      tradeRoutes.put(routeId, route);
      routesDirty = true;
      return copy(route);
    }
  }

  @Override
  public Optional<TradeRoute> getTradeRoute(UUID routeId) {
    synchronized (stateLock) {
      requireAvailable();
      if (routeId == null) {
        return Optional.empty();
      }
      return Optional.ofNullable(tradeRoutes.get(routeId)).map(SimpleResourceTradeService::copy);
    }
  }

  @Override
  public Collection<TradeRoute> getTradeRoutes(NationId nationId) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null) {
        return List.of();
      }
      return tradeRoutes.values().stream()
          .filter(route -> route.connects(nationId))
          .map(SimpleResourceTradeService::copy)
          .collect(Collectors.toList());
    }
  }

  @Override
  public Optional<TradeRoute> getTradeRouteBetween(NationId nation1, NationId nation2) {
    synchronized (stateLock) {
      requireAvailable();
      return findRouteBetween(nation1, nation2).map(SimpleResourceTradeService::copy);
    }
  }

  // These lookups retain service ownership and must run under stateLock.
  private Optional<TradeRoute> findRouteBetween(NationId nation1, NationId nation2) {
    if (nation1 == null || nation2 == null) return Optional.empty();
    return tradeRoutes.values().stream()
        .filter(route -> route.connectsBoth(nation1, nation2))
        .findFirst();
  }

  @Override
  public TradeAgreement createTradeAgreement(
      NationId exporterNationId,
      NationId importerNationId,
      String resourceId,
      long amount,
      double pricePerUnit,
      long duration) {
    synchronized (stateLock) {
      requireAvailable();
      requireNationId(exporterNationId, "exporterNationId");
      requireNationId(importerNationId, "importerNationId");
      if (exporterNationId.equals(importerNationId)) {
        throw new IllegalArgumentException("Trade agreement nations must differ");
      }

      ResourceTradeTerms.Validation validation =
          ResourceTradeTerms.validateAgreement(resourceId, amount, pricePerUnit, duration);
      if (!validation.isValid()) {
        throw new IllegalArgumentException(
            "Invalid trade agreement terms: " + validation.violation());
      }
      ResourceTradeTerms terms = validation.terms();

      UUID agreementId = UUID.randomUUID();
      Instant startTime = Instant.now();
      Instant expiryTime = startTime.plusSeconds(terms.durationSeconds());
      TradeAgreement agreement =
          new TradeAgreement(
              agreementId,
              exporterNationId,
              importerNationId,
              terms.resourceId(),
              terms.amount(),
              terms.pricePerUnitAsDouble(),
              startTime,
              expiryTime);
      tradeAgreements.put(agreementId, agreement);
      markAgreementsDirty();
      return copy(agreement);
    }
  }

  // ResourceModule includes agreements, routes, embargoes, and quotas in its state snapshot.
  private volatile boolean agreementsDirty = false;

  private void markAgreementsDirty() {
    this.agreementsDirty = true;
  }

  /** Returns detached agreements for persistence; later mutations cannot change this snapshot. */
  public java.util.Map<UUID, TradeAgreement> snapshotAgreements() {
    synchronized (stateLock) {
      var result =
          copyState(tradeAgreements, TradeAgreement::agreementId, SimpleResourceTradeService::copy);
      this.agreementsDirty = false;
      return result;
    }
  }

  /**
   * Restores trusted recovery input. The caller must keep the input stable during this call;
   * subsequent changes to its map or models do not affect the service.
   */
  public void restoreAgreements(java.util.Map<UUID, TradeAgreement> snapshot) {
    synchronized (stateLock) {
      var replacement =
          copyState(snapshot, TradeAgreement::agreementId, SimpleResourceTradeService::copy);
      tradeAgreements.clear();
      tradeAgreements.putAll(replacement);
      this.agreementsDirty = false;
    }
  }

  /**
   * @return 自上次快照后是否有变更，上层可据此决定是否落盘。
   */
  public boolean isAgreementsDirty() {
    return agreementsDirty;
  }

  public Map<UUID, TradeRoute> snapshotRoutes() {
    synchronized (stateLock) {
      var result = copyState(tradeRoutes, TradeRoute::routeId, SimpleResourceTradeService::copy);
      routesDirty = false;
      return result;
    }
  }

  public Map<UUID, ResourceEmbargo> snapshotEmbargoes() {
    synchronized (stateLock) {
      var result =
          copyState(embargoes, ResourceEmbargo::embargoId, SimpleResourceTradeService::copy);
      embargoesDirty = false;
      return result;
    }
  }

  public Map<UUID, ResourceQuota> snapshotQuotas() {
    synchronized (stateLock) {
      var result = copyState(quotas, ResourceQuota::quotaId, SimpleResourceTradeService::copy);
      quotasDirty = false;
      return result;
    }
  }

  public void restoreRoutes(Map<UUID, TradeRoute> snapshot) {
    synchronized (stateLock) {
      var replacement = copyState(snapshot, TradeRoute::routeId, SimpleResourceTradeService::copy);
      tradeRoutes.clear();
      tradeRoutes.putAll(replacement);
      routesDirty = false;
    }
  }

  public void restoreEmbargoes(Map<UUID, ResourceEmbargo> snapshot) {
    synchronized (stateLock) {
      var replacement =
          copyState(snapshot, ResourceEmbargo::embargoId, SimpleResourceTradeService::copy);
      embargoes.clear();
      embargoes.putAll(replacement);
      embargoesDirty = false;
    }
  }

  public void restoreQuotas(Map<UUID, ResourceQuota> snapshot) {
    synchronized (stateLock) {
      var replacement =
          copyState(snapshot, ResourceQuota::quotaId, SimpleResourceTradeService::copy);
      quotas.clear();
      quotas.putAll(replacement);
      quotasDirty = false;
    }
  }

  /** Keeps the dirty marker set when an enclosing state snapshot write fails. */
  public void markAgreementsDirtyForRetry() {
    this.agreementsDirty = true;
  }

  public void markRoutesDirtyForRetry() {
    this.routesDirty = true;
  }

  public void markEmbargoesDirtyForRetry() {
    this.embargoesDirty = true;
  }

  public void markQuotasDirtyForRetry() {
    this.quotasDirty = true;
  }

  @Override
  public Optional<TradeAgreement> getTradeAgreement(UUID agreementId) {
    synchronized (stateLock) {
      requireAvailable();
      if (agreementId == null) {
        return Optional.empty();
      }
      return Optional.ofNullable(tradeAgreements.get(agreementId))
          .map(SimpleResourceTradeService::copy);
    }
  }

  @Override
  public Collection<TradeAgreement> getTradeAgreements(NationId nationId) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null) {
        return List.of();
      }
      return tradeAgreements.values().stream()
          .filter(
              agreement ->
                  agreement.exporterNationId().equals(nationId)
                      || agreement.importerNationId().equals(nationId))
          .map(SimpleResourceTradeService::copy)
          .collect(Collectors.toList());
    }
  }

  @Override
  public boolean executeTradeAgreement(UUID agreementId) {
    synchronized (stateLock) {
      requireAvailable();
      Optional<TradeAgreement> agreementOpt =
          Optional.ofNullable(agreementId == null ? null : tradeAgreements.get(agreementId));
      if (agreementOpt.isEmpty()) {
        return false;
      }

      TradeAgreement agreement = agreementOpt.get();
      if (!agreement.isActive()) {
        return false;
      }

      // 检查出口国是否有足够资源
      long exporterAmount =
          resourceService.amount(agreement.exporterNationId(), agreement.resourceId());
      if (exporterAmount < agreement.amount()) {
        return false;
      }

      // 检查是否被禁运
      if (isEmbargoed(
          agreement.exporterNationId(), agreement.importerNationId(), agreement.resourceId())) {
        return false;
      }

      Instant quotaTime = quotaClock.instant();
      ResourceQuota exportQuota =
          renewQuota(
              findQuota(
                      agreement.exporterNationId(),
                      agreement.resourceId(),
                      ResourceQuota.QuotaType.EXPORT)
                  .orElse(null),
              quotaTime);
      ResourceQuota importQuota =
          renewQuota(
              findQuota(
                      agreement.importerNationId(),
                      agreement.resourceId(),
                      ResourceQuota.QuotaType.IMPORT)
                  .orElse(null),
              quotaTime);
      boolean exportReserved = reserveQuota(exportQuota, agreement.amount());
      if (!exportReserved) {
        return false;
      }
      boolean importReserved = reserveQuota(importQuota, agreement.amount());
      if (!importReserved) {
        releaseQuota(exportQuota, agreement.amount());
        return false;
      }

      long tradedAmount = agreement.amount();
      BigDecimal tradeValue =
          BigDecimal.valueOf(agreement.pricePerUnit())
              .multiply(BigDecimal.valueOf(tradedAmount))
              .setScale(2, RoundingMode.HALF_UP);
      UUID executionId = UUID.randomUUID();
      boolean treasuryTransferred = false;
      if (treasuryService != null) {
        try {
          if (!transferTreasury(
              agreement,
              agreement.importerNationId(),
              agreement.exporterNationId(),
              tradeValue,
              executionId,
              "debit")) {
            releaseQuota(exportQuota, tradedAmount);
            releaseQuota(importQuota, tradedAmount);
            return false;
          }
          treasuryTransferred = true;
        } catch (RuntimeException failure) {
          releaseQuota(exportQuota, tradedAmount);
          releaseQuota(importQuota, tradedAmount);
          throw new IllegalStateException(
              "Trade agreement treasury transfer failed for " + agreement.agreementId(), failure);
        }
      }

      // 执行资源转移
      boolean consumed;
      try {
        consumed =
            resourceService.consume(
                agreement.exporterNationId(), agreement.resourceId(), agreement.amount());
      } catch (RuntimeException failure) {
        releaseQuota(exportQuota, tradedAmount);
        releaseQuota(importQuota, tradedAmount);
        reverseTreasuryTransfer(agreement, tradeValue, treasuryTransferred, executionId, failure);
        throw failure;
      }
      if (!consumed) {
        releaseQuota(exportQuota, tradedAmount);
        releaseQuota(importQuota, tradedAmount);
        reverseTreasuryTransfer(agreement, tradeValue, treasuryTransferred, executionId, null);
        return false;
      }

      // audit B-074: 之前 consume 成功后 grant 返回值未检查，若 grant 失败（资源不足或同步问题），
      // 资源凭空消失。改为校验 grant 返回值；失败时把已消耗的 grant 回出口国。
      boolean granted;
      RuntimeException deliveryFailure = null;
      try {
        granted =
            resourceService.grant(
                agreement.importerNationId(), agreement.resourceId(), tradedAmount);
      } catch (RuntimeException e) {
        granted = false;
        deliveryFailure = e;
      }
      if (!granted) {
        boolean restored;
        RuntimeException restoreFailure = null;
        try {
          restored =
              resourceService.grant(
                  agreement.exporterNationId(), agreement.resourceId(), tradedAmount);
        } catch (RuntimeException rollbackEx) {
          restored = false;
          restoreFailure = rollbackEx;
        }
        if (!restored) {
          IllegalStateException criticalFailure =
              new IllegalStateException(
                  "Trade agreement resource rollback failed for " + agreement.agreementId());
          if (deliveryFailure != null) {
            criticalFailure.addSuppressed(deliveryFailure);
          }
          if (restoreFailure != null) {
            criticalFailure.addSuppressed(restoreFailure);
          }
          releaseQuota(exportQuota, tradedAmount);
          releaseQuota(importQuota, tradedAmount);
          reverseTreasuryTransfer(
              agreement, tradeValue, treasuryTransferred, executionId, criticalFailure);
          throw criticalFailure;
        }
        releaseQuota(exportQuota, tradedAmount);
        releaseQuota(importQuota, tradedAmount);
        reverseTreasuryTransfer(
            agreement, tradeValue, treasuryTransferred, executionId, deliveryFailure);
        publishTradeEvent(
            new ResourceTradedEvent(
                agreement.exporterNationId(),
                agreement.importerNationId(),
                agreement.resourceId(),
                0L,
                agreement.pricePerUnit(),
                Instant.now()));
        return false;
      }

      // 更新贸易路线统计
      findRouteBetween(agreement.exporterNationId(), agreement.importerNationId())
          .ifPresent(
              route -> {
                route.addTradeVolume(tradedAmount);
                routesDirty = true;
              });

      // 发布贸易成功事件
      publishTradeEvent(
          new ResourceTradedEvent(
              agreement.exporterNationId(),
              agreement.importerNationId(),
              agreement.resourceId(),
              tradedAmount,
              agreement.pricePerUnit(),
              Instant.now()));

      return true;
    }
  }

  private boolean reserveQuota(ResourceQuota quota, long amount) {
    if (quota == null) return true;
    return quota.use(amount);
  }

  /** Advances to the current fixed period without replaying every missed interval. */
  private ResourceQuota renewQuota(ResourceQuota quota, Instant now) {
    if (quota == null || now.isBefore(quota.resetTime())) return quota;
    ResourceQuota renewed;
    try {
      Duration period = Duration.between(quota.startTime(), quota.resetTime());
      BigInteger remainder =
          durationNanos(Duration.between(quota.resetTime(), now)).remainder(durationNanos(period));
      BigInteger[] parts = remainder.divideAndRemainder(BigInteger.valueOf(1_000_000_000L));
      Instant start =
          now.minusSeconds(parts[0].longValueExact()).minusNanos(parts[1].longValueExact());
      Instant reset = start.plus(period);
      // Resource snapshots store epoch milliseconds. Reject an unrepresentable next window
      // before replacing the old quota or clearing any usage.
      if (reset.toEpochMilli() <= start.toEpochMilli())
        throw new ArithmeticException("Quota period is below persistent timestamp precision");
      renewed =
          new ResourceQuota(
              quota.quotaId(),
              quota.nationId(),
              quota.resourceId(),
              quota.maxAmount(),
              0,
              start,
              reset,
              quota.type());
    } catch (ArithmeticException | java.time.DateTimeException error) {
      throw new IllegalStateException(
          "Quota period cannot be represented in resource storage", error);
    }
    quotas.put(renewed.quotaId(), renewed);
    quotasDirty = true;
    return renewed;
  }

  private static BigInteger durationNanos(Duration duration) {
    return BigInteger.valueOf(duration.getSeconds())
        .multiply(BigInteger.valueOf(1_000_000_000L))
        .add(BigInteger.valueOf(duration.getNano()));
  }

  private void releaseQuota(ResourceQuota quota, long amount) {
    if (quota != null) quota.release(amount);
  }

  private void reverseTreasuryTransfer(
      TradeAgreement agreement,
      BigDecimal amount,
      boolean transferred,
      UUID executionId,
      RuntimeException originalFailure) {
    if (!transferred || treasuryService == null) return;
    try {
      if (!transferTreasury(
          agreement,
          agreement.exporterNationId(),
          agreement.importerNationId(),
          amount,
          executionId,
          "rollback")) {
        IllegalStateException failure =
            new IllegalStateException(
                "Trade agreement treasury rollback was rejected for " + agreement.agreementId());
        if (originalFailure != null) failure.addSuppressed(originalFailure);
        throw failure;
      }
    } catch (RuntimeException rollbackFailure) {
      if (originalFailure != null && rollbackFailure != originalFailure) {
        rollbackFailure.addSuppressed(originalFailure);
      }
      throw new IllegalStateException(
          "Trade agreement treasury rollback failed for " + agreement.agreementId(),
          rollbackFailure);
    }
  }

  private boolean transferTreasury(
      TradeAgreement agreement,
      NationId from,
      NationId to,
      BigDecimal amount,
      UUID executionId,
      String phase) {
    if (treasuryService instanceof NationTransferService transfers) {
      String transactionId =
          "resource-trade:" + agreement.agreementId() + ":" + executionId + ":" + phase;
      NationTransferService.TransferResult result;
      try {
        result =
            transfers.transfer(
                new NationTransferService.TransferRequest(
                    transactionId,
                    from,
                    to,
                    amount,
                    NationTransferService.TransferCategory.OTHER,
                    "Resource trade " + agreement.agreementId() + " " + phase));
      } catch (RuntimeException failure) {
        throw new IllegalStateException(
            "Trade agreement treasury transfer failed for " + agreement.agreementId(), failure);
      }
      return result != null
          && result.status() != null
          && transactionId.equals(result.transactionId())
          && result.applied();
    }
    return treasuryService.transfer(from, to, amount);
  }

  /** 资源交易事件 */
  public record ResourceTradedEvent(
      NationId exporterNationId,
      NationId importerNationId,
      String resourceId,
      long amount,
      double pricePerUnit,
      Instant timestamp) {}

  @Override
  public boolean cancelTradeAgreement(NationId actorNationId, UUID agreementId) {
    synchronized (stateLock) {
      requireAvailable();
      if (actorNationId == null || agreementId == null) {
        return false;
      }
      TradeAgreement agreement = tradeAgreements.get(agreementId);
      if (agreement == null
          || (!actorNationId.equals(agreement.exporterNationId())
              && !actorNationId.equals(agreement.importerNationId()))) {
        return false;
      }

      boolean removed = tradeAgreements.remove(agreementId, agreement);
      if (removed) {
        markAgreementsDirty();
        publishTradeEvent(
            new TradeAgreementCancelledEvent(
                agreement.exporterNationId(),
                agreement.importerNationId(),
                agreement.resourceId(),
                agreement.amount(),
                Instant.now()));
      }
      return removed;
    }
  }

  /** 贸易协定取消事件 */
  public record TradeAgreementCancelledEvent(
      NationId exporterNationId,
      NationId importerNationId,
      String resourceId,
      long cancelledAmount,
      Instant timestamp) {}

  @Override
  public ResourceEmbargo createEmbargo(
      NationId initiatorNationId,
      Set<NationId> targetNationIds,
      String resourceId,
      Long duration,
      String reason) {
    synchronized (stateLock) {
      requireAvailable();
      requireNationId(initiatorNationId, "initiatorNationId");
      if (targetNationIds == null || targetNationIds.isEmpty()) {
        throw new IllegalArgumentException("Embargo requires at least one target nation");
      }
      if (targetNationIds.stream().anyMatch(Objects::isNull)) {
        throw new IllegalArgumentException("Embargo target nation is required");
      }
      Set<NationId> targets = Set.copyOf(targetNationIds);
      if (targets.contains(initiatorNationId)) {
        throw new IllegalArgumentException("Embargo target must be a different nation");
      }
      String normalizedResource = ResourceTradeTerms.normalizeResourceId(resourceId);
      if (normalizedResource == null) {
        throw new IllegalArgumentException("Invalid embargo resource ID");
      }
      if (duration != null
          && (duration < 1 || duration > ResourceTradeTerms.MAX_DURATION_SECONDS)) {
        throw new IllegalArgumentException("Embargo duration is outside the supported range");
      }

      UUID embargoId = UUID.randomUUID();
      Instant startTime = Instant.now();
      Instant expiryTime = duration == null ? null : startTime.plusSeconds(duration);
      ResourceEmbargo embargo =
          new ResourceEmbargo(
              embargoId,
              initiatorNationId,
              targets,
              normalizedResource,
              startTime,
              expiryTime,
              reason);
      embargoes.put(embargoId, embargo);
      embargoesDirty = true;
      return copy(embargo);
    }
  }

  @Override
  public Optional<ResourceEmbargo> getEmbargo(UUID embargoId) {
    synchronized (stateLock) {
      requireAvailable();
      if (embargoId == null) {
        return Optional.empty();
      }
      return Optional.ofNullable(embargoes.get(embargoId)).map(SimpleResourceTradeService::copy);
    }
  }

  @Override
  public Collection<ResourceEmbargo> getEmbargoesBy(NationId nationId) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null) {
        return List.of();
      }
      return embargoes.values().stream()
          .filter(embargo -> embargo.initiatorNationId().equals(nationId))
          .map(SimpleResourceTradeService::copy)
          .collect(Collectors.toList());
    }
  }

  @Override
  public Collection<ResourceEmbargo> getEmbargoesAgainst(NationId nationId) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null) {
        return List.of();
      }
      return embargoes.values().stream()
          .filter(embargo -> embargo.isEmbargoed(nationId))
          .map(SimpleResourceTradeService::copy)
          .collect(Collectors.toList());
    }
  }

  @Override
  public boolean isEmbargoed(NationId fromNation, NationId toNation, String resourceId) {
    synchronized (stateLock) {
      requireAvailable();
      String normalizedResource = ResourceTradeTerms.normalizeResourceId(resourceId);
      if (fromNation == null || toNation == null || normalizedResource == null) {
        return false;
      }
      return embargoes.values().stream()
          .anyMatch(
              embargo ->
                  embargo.initiatorNationId().equals(fromNation)
                      && embargo.isEmbargoed(toNation)
                      && embargo.resourceId().equals(normalizedResource)
                      && embargo.isEffective());
    }
  }

  @Override
  public boolean liftEmbargo(NationId actorNationId, UUID embargoId) {
    synchronized (stateLock) {
      requireAvailable();
      if (actorNationId == null || embargoId == null) {
        return false;
      }
      ResourceEmbargo embargo = embargoes.get(embargoId);
      if (embargo == null
          || !actorNationId.equals(embargo.initiatorNationId())
          || !embargo.isActive()) {
        return false;
      }
      embargo.setActive(false);
      embargoesDirty = true;
      return true;
    }
  }

  @Override
  public ResourceQuota createQuota(
      NationId nationId,
      String resourceId,
      long maxAmount,
      long duration,
      ResourceQuota.QuotaType type) {
    synchronized (stateLock) {
      requireAvailable();
      requireNationId(nationId, "nationId");
      String normalizedResource = ResourceTradeTerms.normalizeResourceId(resourceId);
      if (normalizedResource == null) {
        throw new IllegalArgumentException("Invalid quota resource ID");
      }
      if (maxAmount <= 0) {
        throw new IllegalArgumentException("Quota maxAmount must be positive");
      }
      if (duration < 1 || duration > ResourceTradeTerms.MAX_DURATION_SECONDS) {
        throw new IllegalArgumentException("Quota duration is outside the supported range");
      }
      if (type == null) {
        throw new IllegalArgumentException("Quota type is required");
      }
      UUID quotaId = UUID.randomUUID();
      Instant startTime = quotaClock.instant();
      Instant resetTime = startTime.plusSeconds(duration);

      ResourceQuota quota =
          new ResourceQuota(
              quotaId, nationId, normalizedResource, maxAmount, startTime, resetTime, type);
      quotas.put(quotaId, quota);
      quotasDirty = true;
      return copy(quota);
    }
  }

  @Override
  public Optional<ResourceQuota> getQuota(UUID quotaId) {
    synchronized (stateLock) {
      requireAvailable();
      if (quotaId == null) {
        return Optional.empty();
      }
      return Optional.ofNullable(quotas.get(quotaId)).map(SimpleResourceTradeService::copy);
    }
  }

  @Override
  public Collection<ResourceQuota> getQuotas(NationId nationId) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null) {
        return List.of();
      }
      return quotas.values().stream()
          .filter(quota -> quota.nationId().equals(nationId))
          .map(SimpleResourceTradeService::copy)
          .collect(Collectors.toList());
    }
  }

  @Override
  public Optional<ResourceQuota> getQuota(
      NationId nationId, String resourceId, ResourceQuota.QuotaType type) {
    synchronized (stateLock) {
      requireAvailable();
      return findQuota(nationId, resourceId, type).map(SimpleResourceTradeService::copy);
    }
  }

  private Optional<ResourceQuota> findQuota(
      NationId nationId, String resourceId, ResourceQuota.QuotaType type) {
    String normalizedResource = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (nationId == null || normalizedResource == null || type == null) return Optional.empty();
    return quotas.values().stream()
        .filter(
            quota ->
                quota.nationId().equals(nationId)
                    && quota.resourceId().equals(normalizedResource)
                    && quota.type() == type)
        .findFirst();
  }

  @Override
  public boolean useQuota(UUID quotaId, long amount) {
    synchronized (stateLock) {
      requireAvailable();
      ResourceQuota quota = quotaId == null ? null : quotas.get(quotaId);
      if (quota == null) {
        return false;
      }

      quota = renewQuota(quota, quotaClock.instant());

      boolean used = quota.use(amount);
      if (used) quotasDirty = true;
      return used;
    }
  }

  @Override
  public void resetExpiredQuotas() {
    synchronized (stateLock) {
      requireAvailable();
      int resetCount = 0;
      Instant now = quotaClock.instant();
      for (ResourceQuota quota : quotas.values()) {
        if (!now.isBefore(quota.resetTime())) {
          NationId nationId = quota.nationId();
          String resourceId = quota.resourceId();
          renewQuota(quota, now);
          resetCount++;

          // 发布配额重置事件
          publishTradeEvent(new QuotaResetEvent(nationId, resourceId, quota.maxAmount(), now));
        }
      }
      if (resetCount > 0) {
        // 发布总体配额刷新事件
        publishTradeEvent(new QuotaRefreshEvent(resetCount, now));
      }
    }
  }

  /** 配额重置事件 */
  public record QuotaResetEvent(
      NationId nationId, String resourceId, long maxAmount, Instant timestamp) {}

  /** 配额刷新事件（汇总事件） */
  public record QuotaRefreshEvent(int resetCount, Instant timestamp) {}

  // ==================== 税收集成方法实现 ====================

  @Override
  public java.math.BigDecimal calculateTradeVolume(NationId nationId, java.time.Duration duration) {
    synchronized (stateLock) {
      requireAvailable();
      if (nationId == null || duration == null || duration.isNegative()) {
        return java.math.BigDecimal.ZERO.setScale(2, java.math.RoundingMode.HALF_UP);
      }
      Instant cutoff = Instant.now().minus(duration);

      // 计算作为出口国的贸易额
      double exportValue =
          tradeAgreements.values().stream()
              .filter(agreement -> agreement.exporterNationId().equals(nationId))
              .filter(agreement -> agreement.startTime().isAfter(cutoff))
              .mapToDouble(agreement -> agreement.amount() * agreement.pricePerUnit())
              .sum();

      // 计算作为进口国的贸易额（反向计算）
      double importValue =
          tradeAgreements.values().stream()
              .filter(agreement -> agreement.importerNationId().equals(nationId))
              .filter(agreement -> agreement.startTime().isAfter(cutoff))
              .mapToDouble(agreement -> agreement.amount() * agreement.pricePerUnit())
              .sum();

      return java.math.BigDecimal.valueOf(exportValue + importValue)
          .setScale(2, java.math.RoundingMode.HALF_UP);
    }
  }

  private static <T> Map<UUID, T> copyState(
      Map<UUID, T> source, Function<T, UUID> identity, Function<T, T> copier) {
    Map<UUID, T> result = new HashMap<>();
    if (source == null) return result;
    source.forEach(
        (key, value) -> {
          if (key == null || value == null || !key.equals(identity.apply(value)))
            throw new IllegalArgumentException("Trade snapshot key must match a non-null model ID");
          result.put(key, copier.apply(value));
        });
    return result;
  }

  private static TradeAgreement copy(TradeAgreement value) {
    var result =
        new TradeAgreement(
            value.agreementId(),
            value.exporterNationId(),
            value.importerNationId(),
            value.resourceId(),
            value.amount(),
            value.pricePerUnit(),
            value.startTime(),
            value.expiryTime());
    result.setAutoRenew(value.isAutoRenew());
    return result;
  }

  private static TradeRoute copy(TradeRoute value) {
    return new TradeRoute(
        value.routeId(),
        value.originNationId(),
        value.destinationNationId(),
        value.routeName(),
        value.establishedTime(),
        value.efficiency(),
        value.isActive(),
        value.totalTradeVolume());
  }

  private static ResourceEmbargo copy(ResourceEmbargo value) {
    return new ResourceEmbargo(
        value.embargoId(),
        value.initiatorNationId(),
        value.targetNationIds(),
        value.resourceId(),
        value.startTime(),
        value.expiryTime(),
        value.reason(),
        value.isActive());
  }

  private static ResourceQuota copy(ResourceQuota value) {
    return new ResourceQuota(
        value.quotaId(),
        value.nationId(),
        value.resourceId(),
        value.maxAmount(),
        value.currentAmount(),
        value.startTime(),
        value.resetTime(),
        value.type());
  }

  private void requireNationId(NationId nationId, String name) {
    if (nationId == null) {
      throw new IllegalArgumentException(name + " is required");
    }
  }

  private void requireAvailable() {
    if (resourceService instanceof ResourceModule module) module.requireTradeStateAvailable();
  }

  private String requireRouteName(String routeName) {
    if (routeName == null || routeName.isBlank()) {
      throw new IllegalArgumentException("routeName must not be blank");
    }
    return routeName.trim();
  }
}
