package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.ResourceQuota;
import dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceQuotaRenewalTest {
  @TempDir Path directory;
  private static final NationId EXPORTER = TradeSnapshotValidationTest.EXPORTER;
  private static final NationId IMPORTER = TradeSnapshotValidationTest.IMPORTER;

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void expiredQuotaRenewsOnceAndEnforcesTheNewPeriodLimit(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var old = expired(EXPORTER, type);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    assertTrue(service.useQuota(old.quotaId(), 5));
    assertFalse(service.useQuota(old.quotaId(), 1));
    var current = service.getQuota(old.quotaId()).orElseThrow();
    assertEquals(old.resetTime(), current.startTime());
    assertEquals(old.resetTime().plusSeconds(3600), current.resetTime());
    assertEquals(5, current.currentAmount());
    assertEquals(5, old.currentAmount());
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void repeatedSchedulerTicksCannotEraseUsageInTheNewPeriod(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var old = expired(EXPORTER, type);
    var events = mock(StarCoreEventBus.class);
    service.setEventBus(events);
    service.restoreQuotas(Map.of(old.quotaId(), old));
    service.resetExpiredQuotas();
    assertTrue(service.useQuota(old.quotaId(), 3));
    service.resetExpiredQuotas();
    assertEquals(3, service.getQuota(old.quotaId()).orElseThrow().currentAmount());
    verify(events, times(1)).publish(isA(SimpleResourceTradeService.QuotaResetEvent.class));
    verify(events, times(1)).publish(isA(SimpleResourceTradeService.QuotaRefreshEvent.class));
  }

  @ParameterizedTest
  @EnumSource(QuotaType.class)
  void anUnexpiredQuotaRetainsItsOriginalWindowAndUsage(QuotaType type) {
    var service = new SimpleResourceTradeService(mock(ResourceService.class));
    var start = Instant.now().minusSeconds(10);
    var quota =
        new ResourceQuota(
            UUID.randomUUID(), EXPORTER, "iron", 5, 4, start, start.plusSeconds(3600), type);
    service.restoreQuotas(Map.of(quota.quotaId(), quota));
    service.resetExpiredQuotas();
    assertTrue(service.useQuota(quota.quotaId(), 1));
    assertFalse(service.useQuota(quota.quotaId(), 1));
    var current = service.getQuota(quota.quotaId()).orElseThrow();
    assertEquals(quota.startTime(), current.startTime());
    assertEquals(quota.resetTime(), current.resetTime());
    assertEquals(5, current.currentAmount());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void tradeReservationsAndReleaseUseTheRenewedQuotas(boolean firstDelivered) {
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(EXPORTER, "iron")).thenReturn(5L);
    when(resources.consume(EXPORTER, "iron", 5)).thenReturn(true);
    when(resources.grant(IMPORTER, "iron", 5)).thenReturn(firstDelivered);
    when(resources.grant(EXPORTER, "iron", 5)).thenReturn(true);
    var service = new SimpleResourceTradeService(resources);
    var exported = expired(EXPORTER, QuotaType.EXPORT);
    var imported = expired(IMPORTER, QuotaType.IMPORT);
    service.restoreQuotas(Map.of(exported.quotaId(), exported, imported.quotaId(), imported));
    var agreement = service.createTradeAgreement(EXPORTER, IMPORTER, "iron", 5, 2, 300);
    assertEquals(firstDelivered, service.executeTradeAgreement(agreement.agreementId()));
    long expected = firstDelivered ? 5 : 0;
    assertEquals(expected, service.getQuota(exported.quotaId()).orElseThrow().currentAmount());
    assertEquals(expected, service.getQuota(imported.quotaId()).orElseThrow().currentAmount());
    if (!firstDelivered) {
      when(resources.grant(IMPORTER, "iron", 5)).thenReturn(true);
      assertTrue(service.executeTradeAgreement(agreement.agreementId()));
    }
    assertFalse(service.executeTradeAgreement(agreement.agreementId()));
    assertEquals(
        exported.resetTime(), service.getQuota(exported.quotaId()).orElseThrow().startTime());
    assertEquals(
        imported.resetTime(), service.getQuota(imported.quotaId()).orElseThrow().startTime());
    verify(resources, times(firstDelivered ? 1 : 2)).consume(EXPORTER, "iron", 5);
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void savedRenewalAndUsageSurviveRestartWithoutAnotherReset(String engine) throws Exception {
    var helper = new TradeSnapshotValidationTest();
    helper.directory = directory;
    var storage = helper.seeded(engine);
    var state = storage.load();
    var old = expired(IMPORTER, QuotaType.IMPORT);
    state.setProperty("quota.0.max", "5");
    state.setProperty("quota.0.current", "5");
    state.setProperty("quota.0.start", Long.toString(old.startTime().toEpochMilli()));
    state.setProperty("quota.0.reset", Long.toString(old.resetTime().toEpochMilli()));
    storage.save(state);
    var module = TradeSnapshotValidationTest.module(storage);
    var service = module.getTradeService();
    UUID id = TradeSnapshotValidationTest.QUOTA;
    assertTrue(service.useQuota(id, 5));
    assertTrue(module.grant(EXPORTER, "luxury", 1));
    var saved = storage.load();
    assertEquals(Long.toString(old.resetTime().toEpochMilli()), saved.getProperty("quota.0.start"));
    assertEquals(
        Long.toString(old.resetTime().plusSeconds(3600).toEpochMilli()),
        saved.getProperty("quota.0.reset"));
    var restarted = TradeSnapshotValidationTest.module(storage);
    assertFalse(restarted.getTradeService().useQuota(id, 1));
    restarted.getTradeService().resetExpiredQuotas();
    assertEquals(5, restarted.getTradeService().getQuota(id).orElseThrow().currentAmount());
    assertEquals(saved, storage.load());
    assertEquals(module.authorityDomainId(), restarted.authorityDomainId());
    assertEquals(1, restarted.amount(EXPORTER, "luxury"));
  }

  private static ResourceQuota expired(NationId nation, QuotaType type) {
    var end = Instant.now().minusSeconds(10);
    return new ResourceQuota(
        UUID.randomUUID(), nation, "iron", 5, 5, end.minusSeconds(3600), end, type);
  }
}
