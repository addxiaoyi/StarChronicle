package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.sqlite.SQLiteDataSource;

class SqlTreasuryWriterContentionTest {
  @TempDir Path directory;

  @ParameterizedTest
  @CsvSource({"false,false", "false,true", "true,false", "true,true"})
  void unrelatedWriterIsWaitedForBeforeReadingTreasuryRevision(
      boolean existingRevision, boolean coordinated) throws Exception {
    var sqlite = database(5000);
    var attempted = new AtomicReference<CountDownLatch>();
    var storage = storage(sqlite, attempted);
    storage.load();
    if (existingRevision) storage.save(snapshot("75.00"));
    try (var executor = Executors.newSingleThreadExecutor();
        var otherModule = sqlite.getConnection()) {
      holdWriter(otherModule);
      var entered = new CountDownLatch(1);
      attempted.set(entered);
      var saving =
          executor.submit(
              () -> {
                if (coordinated) {
                  storage.saveCoordinated(
                      snapshot("100.00"),
                      (source, commit) ->
                          commit.commit(
                              connection -> {
                                try (var statement = connection.createStatement()) {
                                  statement.executeUpdate(
                                      "INSERT INTO joint_receipts VALUES ('paid')");
                                }
                              }));
                } else {
                  storage.save(snapshot("100.00"));
                }
                return null;
              });
      try {
        assertThat(entered.await(5, TimeUnit.SECONDS)).isTrue();
        assertThatThrownBy(() -> saving.get(250, TimeUnit.MILLISECONDS))
            .isInstanceOf(TimeoutException.class);
      } finally {
        otherModule.commit();
      }
      saving.get(5, TimeUnit.SECONDS);
      assertThat(storage.load()).containsExactlyEntriesOf(snapshot("100.00"));
      assertThat(value(sqlite, "SELECT COUNT(*) FROM joint_receipts"))
          .isEqualTo(coordinated ? "1" : "0");
      assertThat(
              value(
                  sqlite,
                  "SELECT property_value FROM starcore_treasury_state WHERE"
                      + " property_key='__starcore_revision__'"))
          .isEqualTo(existingRevision ? "2" : "1");
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void revisionChangedWhileWaitingStillRejectsStalePayment() throws Exception {
    var sqlite = database(5000);
    var attempted = new AtomicReference<CountDownLatch>();
    var storage = storage(sqlite, attempted);
    storage.load();
    storage.save(snapshot("75.00"));
    try (var executor = Executors.newSingleThreadExecutor();
        var winner = sqlite.getConnection()) {
      winner.setAutoCommit(false);
      try (var statement = winner.createStatement()) {
        statement.executeUpdate(
            "UPDATE starcore_treasury_state SET property_value='2' WHERE"
                + " property_key='__starcore_revision__'");
        statement.executeUpdate(
            "UPDATE starcore_treasury_state SET property_value='120.00' WHERE"
                + " property_key='balance.example'");
      }
      var entered = new CountDownLatch(1);
      attempted.set(entered);
      var saving = executor.submit(() -> storage.save(snapshot("100.00")));
      try {
        assertThat(entered.await(5, TimeUnit.SECONDS)).isTrue();
        assertThatThrownBy(() -> saving.get(250, TimeUnit.MILLISECONDS))
            .isInstanceOf(TimeoutException.class);
      } finally {
        winner.commit();
      }
      assertThatThrownBy(() -> saving.get(5, TimeUnit.SECONDS))
          .hasCauseInstanceOf(TreasuryStateConflictException.class);
      assertThat(storage.load()).containsExactlyEntriesOf(snapshot("120.00"));
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void participantFailureAfterWaitingRollsBackBothStoresAndRevision() throws Exception {
    var sqlite = database(5000);
    var attempted = new AtomicReference<CountDownLatch>();
    var storage = storage(sqlite, attempted);
    storage.load();
    storage.save(snapshot("75.00"));
    try (var executor = Executors.newSingleThreadExecutor();
        var otherModule = sqlite.getConnection()) {
      holdWriter(otherModule);
      var entered = new CountDownLatch(1);
      attempted.set(entered);
      var saving =
          executor.submit(
              () ->
                  storage.saveCoordinated(
                      snapshot("100.00"),
                      (source, commit) ->
                          commit.commit(
                              connection -> {
                                try (var statement = connection.createStatement()) {
                                  statement.executeUpdate(
                                      "INSERT INTO joint_receipts VALUES ('rolled-back')");
                                }
                                throw new SQLException("participant write failed");
                              })));
      try {
        assertThat(entered.await(5, TimeUnit.SECONDS)).isTrue();
        assertThatThrownBy(() -> saving.get(250, TimeUnit.MILLISECONDS))
            .isInstanceOf(TimeoutException.class);
      } finally {
        otherModule.commit();
      }
      assertThatThrownBy(() -> saving.get(5, TimeUnit.SECONDS))
          .hasCauseInstanceOf(TreasuryStateReconciliationException.class);
      assertThat(storage.load()).containsExactlyEntriesOf(snapshot("75.00"));
      assertThat(value(sqlite, "SELECT COUNT(*) FROM joint_receipts")).isEqualTo("0");
      assertThat(
              value(
                  sqlite,
                  "SELECT property_value FROM starcore_treasury_state WHERE"
                      + " property_key='__starcore_revision__'"))
          .isEqualTo("1");
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void busyTimeoutFailsWithoutChangingBalanceAndLaterExplicitSaveWritesOnce() throws Exception {
    var sqlite = database(100);
    var storage = storage(sqlite, new AtomicReference<>());
    storage.load();
    storage.save(snapshot("75.00"));
    try (var otherModule = sqlite.getConnection()) {
      holdWriter(otherModule);
      assertThatThrownBy(() -> storage.save(snapshot("100.00")))
          .isInstanceOf(TreasuryStateConflictException.class);
      assertThat(
              value(
                  sqlite,
                  "SELECT property_value FROM starcore_treasury_state WHERE"
                      + " property_key='balance.example'"))
          .isEqualTo("75.00");
      otherModule.commit();
      storage.save(snapshot("100.00"));
      assertThat(storage.load()).containsExactlyEntriesOf(snapshot("100.00"));
      assertThat(
              value(
                  sqlite,
                  "SELECT property_value FROM starcore_treasury_state WHERE"
                      + " property_key='__starcore_revision__'"))
          .isEqualTo("2");
    } finally {
      storage.shutdown();
    }
  }

  private SQLiteDataSource database(int timeout) throws SQLException {
    var sqlite = new SQLiteDataSource();
    sqlite.setUrl("jdbc:sqlite:" + directory.resolve("treasury-contention.db"));
    sqlite.setBusyTimeout(timeout);
    try (var connection = sqlite.getConnection();
        var statement = connection.createStatement()) {
      statement.execute("PRAGMA journal_mode=WAL");
      statement.execute("CREATE TABLE unrelated_flush (value INTEGER)");
      statement.execute("CREATE TABLE joint_receipts (id TEXT PRIMARY KEY)");
    }
    return sqlite;
  }

  private SqlTreasuryStateStorage storage(
      SQLiteDataSource sqlite, AtomicReference<CountDownLatch> attempted) {
    DataSource monitored =
        (DataSource)
            Proxy.newProxyInstance(
                getClass().getClassLoader(),
                new Class<?>[] {DataSource.class},
                (proxy, method, arguments) -> {
                  try {
                    Object result = method.invoke(sqlite, arguments);
                    if (!(result instanceof Connection physical)) return result;
                    return Proxy.newProxyInstance(
                        getClass().getClassLoader(),
                        new Class<?>[] {Connection.class},
                        (connection, operation, values) -> {
                          if (operation.getName().equals("prepareStatement")
                              && !physical.getAutoCommit()
                              && attempted.get() != null) attempted.get().countDown();
                          try {
                            return operation.invoke(physical, values);
                          } catch (InvocationTargetException exception) {
                            throw exception.getCause();
                          }
                        });
                  } catch (InvocationTargetException exception) {
                    throw exception.getCause();
                  }
                });
    return new SqlTreasuryStateStorage(monitored, new Properties(), Logger.getAnonymousLogger());
  }

  private static Properties snapshot(String balance) {
    var properties = new Properties();
    properties.setProperty("balance.example", balance);
    return properties;
  }

  private static void holdWriter(Connection connection) throws SQLException {
    connection.setAutoCommit(false);
    try (var statement = connection.createStatement()) {
      statement.executeUpdate("INSERT INTO unrelated_flush VALUES (1)");
    }
  }

  private static String value(SQLiteDataSource sqlite, String query) throws SQLException {
    try (var connection = sqlite.getConnection();
        var statement = connection.createStatement();
        var rows = statement.executeQuery(query)) {
      assertThat(rows.next()).isTrue();
      return rows.getString(1);
    }
  }
}
