package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import javax.sql.DataSource;

final class SqlTreasuryStateStorage extends AbstractModuleStateStorage
    implements TreasuryStateStorage {

  private static final String FILE_NAME = "treasury.properties";
  private static final String TABLE_NAME = "starcore_treasury_state";
  private static final String REVISION_KEY = "__starcore_revision__";
  private long expectedRevision;
  private boolean revisionRowExists;

  SqlTreasuryStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    super(namespace, databaseService, persistenceService, logger);
  }

  // Test constructor.
  SqlTreasuryStateStorage(DataSource dataSource, Properties legacyProperties, Logger logger) {
    this("test", mockDatabaseService(dataSource), mockPersistenceService(legacyProperties), logger);
  }

  private static DatabaseService mockDatabaseService(DataSource dataSource) {
    return new DatabaseService(null, null) {
      @Override
      public synchronized Optional<DataSource> dataSource() {
        return Optional.of(dataSource);
      }

      @Override
      public synchronized boolean isRunning() {
        return true;
      }
    };
  }

  private static PersistenceService mockPersistenceService(Properties properties) {
    return new PersistenceService(null, null) {
      @Override
      public Properties loadProperties(String namespace, String fileName) {
        return properties;
      }

      @Override
      public void saveProperties(String namespace, String fileName, Properties properties) {
        // Test environment: do not persist a fallback file.
      }

      @Override
      public CompletableFuture<Void> savePropertiesAsync(
          String namespace, String fileName, Properties properties) {
        return CompletableFuture.completedFuture(null);
      }
    };
  }

  @Override
  protected String getTableName() {
    return TABLE_NAME;
  }

  @Override
  protected String getFileName() {
    return FILE_NAME;
  }

  @Override
  public synchronized Properties load() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      Properties properties = loadFromDatabase(connection);
      if (!properties.isEmpty() || revisionRowExists) {
        return properties;
      }

      // Only import the legacy file before the SQL snapshot has ever been initialized.
      Properties legacy = copy(loadFromProperties());
      if (legacy.isEmpty()) {
        return legacy;
      }

      writeSnapshot(connection, legacy);
      logger.info("[" + namespace + "] 已从 Properties 迁移数据到 SQL");
      return legacy;
    } catch (Exception exception) {
      return handleSqlLoadFailure(exception);
    }
  }

  @Override
  protected Properties handleSqlLoadFailure(Exception exception) {
    throw new IllegalStateException("Treasury SQL state load failed", exception);
  }

  @Override
  protected void handleSqlWriteFailure(Properties properties, Exception exception) {
    if (exception instanceof TreasuryStateReconciliationException reconciliationException) {
      throw reconciliationException;
    }
    if (exception instanceof SQLException sqlException && isConcurrentWriteConflict(sqlException)) {
      throw new TreasuryStateConflictException(exception);
    }
    throw new IllegalStateException("Treasury SQL state write failed", exception);
  }

  @Override
  protected void ensureTable(Connection connection) throws SQLException {
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE IF NOT EXISTS starcore_treasury_state ("
              + "property_key VARCHAR(191) PRIMARY KEY, "
              + "property_value TEXT NOT NULL)");
    }
  }

  @Override
  protected Properties loadFromDatabase(Connection connection) throws SQLException {
    DatabaseSnapshot snapshot = readDatabaseSnapshot(connection);
    expectedRevision = snapshot.revision();
    revisionRowExists = snapshot.revisionRowExists();
    return snapshot.properties();
  }

  private DatabaseSnapshot readDatabaseSnapshot(Connection connection) throws SQLException {
    Properties properties = new Properties();
    long revision = 0L;
    boolean hasRevisionRow = false;
    try (PreparedStatement statement =
            connection.prepareStatement(
                "SELECT property_key, property_value FROM "
                    + TABLE_NAME
                    + " ORDER BY property_key");
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        String key = rows.getString("property_key");
        String value = rows.getString("property_value");
        if (REVISION_KEY.equals(key)) {
          revision = parseRevision(value);
          hasRevisionRow = true;
        } else {
          properties.setProperty(key, value);
        }
      }
    }
    return new DatabaseSnapshot(properties, revision, hasRevisionRow);
  }

  @Override
  public synchronized Optional<TreasuryStateRefresh> refreshIfChanged() {
    try (Connection connection = openConnection()) {
      if (readRevision(connection) == expectedRevision) {
        return Optional.empty();
      }
      DatabaseSnapshot snapshot = readDatabaseSnapshot(connection);
      if (snapshot.revision() == expectedRevision) {
        return Optional.empty();
      }
      return Optional.of(new TreasuryStateRefresh(snapshot.properties(), snapshot.revision()));
    } catch (Exception exception) {
      throw new IllegalStateException("Treasury SQL state refresh failed", exception);
    }
  }

  @Override
  public synchronized boolean acceptRefresh(TreasuryStateRefresh refresh) {
    if (refresh.revision() >= 0L) {
      expectedRevision = refresh.revision();
      revisionRowExists = true;
    }
    return true;
  }

  @Override
  protected synchronized void writeSnapshot(Connection connection, Properties properties)
      throws SQLException {
    writeSnapshot(connection, properties, ignored -> {});
  }

  @Override
  public boolean supportsCoordinatedWrite() {
    return databaseService.dataSource().isPresent();
  }

  @Override
  public boolean usesDataSource(javax.sql.DataSource source) {
    return source != null && databaseService.dataSource().orElse(null) == source;
  }

  @Override
  public void saveCoordinated(
      Properties properties, dev.starcore.starcore.core.storage.SqlCoordinatedWrite coordinator) {
    var source = databaseService.dataSource().orElseThrow();
    var called = new java.util.concurrent.atomic.AtomicBoolean();
    var completed = new java.util.concurrent.atomic.AtomicBoolean();
    coordinator.execute(
        source,
        participant -> {
          if (!called.compareAndSet(false, true))
            throw new IllegalStateException("Joint SQL commit invoked more than once");
          saveWith(
              properties,
              snapshot -> {
                try (Connection connection = source.getConnection()) {
                  writeSnapshot(
                      connection, snapshot, java.util.Objects.requireNonNull(participant));
                } catch (Exception error) {
                  // Includes an ambiguous commit or connection-close result. The owner must reload.
                  throw new TreasuryStateReconciliationException(error);
                }
              });
          completed.set(true);
        });
    if (!called.get() || !completed.get())
      throw new IllegalStateException("Joint SQL commit was not completed");
  }

  private synchronized void writeSnapshot(
      Connection connection,
      Properties properties,
      dev.starcore.starcore.core.storage.SqlCoordinatedWrite.Participant participant)
      throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    boolean commitAttempted = false;
    boolean committed = false;
    connection.setAutoCommit(false);
    try {
      if ("SQLite".equalsIgnoreCase(connection.getMetaData().getDatabaseProductName())) {
        // Reserve the writer before reading a snapshot. A deferred read-to-write upgrade can
        // fail immediately with SQLITE_BUSY while another module writes, bypassing busy_timeout.
        // This also reserves the database when the revision row has not been created yet.
        try (PreparedStatement reserve =
            connection.prepareStatement(
                "UPDATE "
                    + TABLE_NAME
                    + " SET property_value = property_value WHERE property_key = ?")) {
          reserve.setString(1, REVISION_KEY);
          reserve.executeUpdate();
        }
      }
      long currentRevision = readRevision(connection);
      if (currentRevision != expectedRevision) {
        throw new SQLException(
            "Stale treasury state snapshot: expected revision "
                + expectedRevision
                + " but database is at "
                + currentRevision);
      }
      long nextRevision = Math.addExact(currentRevision, 1L);
      if (revisionExists(connection)) {
        try (PreparedStatement update =
            connection.prepareStatement(
                "UPDATE "
                    + TABLE_NAME
                    + " SET property_value = ? WHERE property_key = ? AND property_value = ?")) {
          update.setString(1, Long.toString(nextRevision));
          update.setString(2, REVISION_KEY);
          update.setString(3, Long.toString(currentRevision));
          if (update.executeUpdate() != 1) {
            throw new SQLException("Treasury state revision changed during save");
          }
        }
      } else {
        try (PreparedStatement insertRevision =
            connection.prepareStatement(
                "INSERT INTO " + TABLE_NAME + " (property_key, property_value) VALUES (?, ?)")) {
          insertRevision.setString(1, REVISION_KEY);
          insertRevision.setString(2, Long.toString(nextRevision));
          try {
            insertRevision.executeUpdate();
          } catch (SQLException exception) {
            if (isDuplicateKeyViolation(exception)) {
              throw new SQLException(
                  "Treasury state revision changed during save",
                  "40001",
                  exception.getErrorCode(),
                  exception);
            }
            throw exception;
          }
        }
      }
      try (PreparedStatement delete =
          connection.prepareStatement("DELETE FROM " + TABLE_NAME + " WHERE property_key <> ?")) {
        delete.setString(1, REVISION_KEY);
        delete.executeUpdate();
      }
      try (PreparedStatement insert =
          connection.prepareStatement(
              "INSERT INTO " + TABLE_NAME + " (property_key, property_value) VALUES (?, ?)")) {
        for (String key : properties.stringPropertyNames()) {
          if (REVISION_KEY.equals(key)) {
            continue;
          }
          insert.setString(1, key);
          insert.setString(2, properties.getProperty(key));
          insert.addBatch();
        }
        insert.executeBatch();
      }
      participant.write(connection);
      commitAttempted = true;
      connection.commit();
      committed = true;
      expectedRevision = nextRevision;
      revisionRowExists = true;
    } catch (Exception exception) {
      try {
        connection.rollback();
      } catch (SQLException rollbackFailure) {
        exception.addSuppressed(rollbackFailure);
      }
      if (commitAttempted) {
        throw new TreasuryStateReconciliationException(exception);
      }
      throw exception;
    } finally {
      try {
        connection.setAutoCommit(previousAutoCommit);
      } catch (SQLException resetFailure) {
        if (committed) {
          throw new TreasuryStateReconciliationException(resetFailure);
        }
        throw resetFailure;
      }
    }
  }

  static boolean isConcurrentWriteConflict(SQLException exception) {
    for (SQLException current = exception; current != null; current = current.getNextException()) {
      String message = current.getMessage();
      if (message != null
          && (message.startsWith("Stale treasury state snapshot")
              || message.equals("Treasury state revision changed during save"))) {
        return true;
      }

      String sqlState = current.getSQLState();
      if (sqlState != null && (sqlState.startsWith("40") || sqlState.equals("41000"))) {
        return true;
      }

      int errorCode = current.getErrorCode();
      int sqlitePrimaryCode = errorCode & 0xff;
      if (sqlitePrimaryCode == 5
          || sqlitePrimaryCode == 6
          || errorCode == 1205
          || errorCode == 1213) {
        return true;
      }

      if (message != null) {
        String normalized = message.toLowerCase(Locale.ROOT);
        if (normalized.contains("database is locked")
            || normalized.contains("database table is locked")
            || normalized.contains("deadlock")
            || normalized.contains("lock wait timeout")
            || normalized.contains("serialization failure")) {
          return true;
        }
      }
    }
    return false;
  }

  private boolean revisionExists(Connection connection) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement("SELECT 1 FROM " + TABLE_NAME + " WHERE property_key = ?")) {
      query.setString(1, REVISION_KEY);
      try (ResultSet result = query.executeQuery()) {
        return result.next();
      }
    }
  }

  private long readRevision(Connection connection) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement(
            "SELECT property_value FROM " + TABLE_NAME + " WHERE property_key = ?")) {
      query.setString(1, REVISION_KEY);
      try (ResultSet result = query.executeQuery()) {
        return result.next() ? parseRevision(result.getString(1)) : 0L;
      }
    }
  }

  private static long parseRevision(String value) throws SQLException {
    try {
      long revision = Long.parseLong(value);
      if (revision < 0) {
        throw new NumberFormatException("negative revision");
      }
      return revision;
    } catch (NumberFormatException exception) {
      throw new SQLException("Invalid treasury state revision", exception);
    }
  }

  private static boolean isDuplicateKeyViolation(SQLException exception) {
    for (SQLException current = exception; current != null; current = current.getNextException()) {
      int errorCode = current.getErrorCode();
      String sqlState = current.getSQLState();
      if (errorCode == 1062 || errorCode == 2601 || errorCode == 2627 || "23505".equals(sqlState)) {
        return true;
      }
    }
    return false;
  }

  private record DatabaseSnapshot(Properties properties, long revision, boolean revisionRowExists) {
    private DatabaseSnapshot {
      properties = copy(properties);
    }

    @Override
    public Properties properties() {
      return copy(properties);
    }
  }
}
