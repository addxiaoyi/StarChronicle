package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;

import com.mysql.cj.jdbc.MysqlDataSource;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.NationTransferService.TransferCategory;
import dev.starcore.starcore.module.treasury.NationTransferService.TransferRequest;
import dev.starcore.starcore.module.treasury.NationTransferService.TransferStatus;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

/** Runs only against a dedicated, empty loopback test database. */
@EnabledIfSystemProperty(named = "starcore.mysql.it", matches = "true")
class MySqlTreasuryStateIntegrationTest {
  private static final String CATALOG = "starcore_treasury_it";
  private static final String TABLE = "starcore_treasury_state";
  private MysqlDataSource mysql;

  @BeforeEach
  void requireEmptyFixture() throws Exception {
    var candidate = new MysqlDataSource();
    String url = setting("url", "STARCORE_MYSQL_URL");
    assertThat(url).matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/" + CATALOG + "(?:\\?.*)?");
    candidate.setURL(url);
    candidate.setUser(setting("user", "STARCORE_MYSQL_USER"));
    candidate.setPassword(setting("password", "STARCORE_MYSQL_PASSWORD"));
    try (var connection = candidate.getConnection();
        var statement = connection.createStatement()) {
      assertThat(connection.getCatalog()).isEqualTo(CATALOG);
      statement.execute(
          "CREATE TABLE IF NOT EXISTS "
              + TABLE
              + " (property_key VARCHAR(191) PRIMARY KEY, property_value TEXT NOT NULL)"
              + " ENGINE=InnoDB");
      try (var rows = statement.executeQuery("SELECT 1 FROM " + TABLE + " LIMIT 1")) {
        assertThat(rows.next()).as("treasury fixture must be empty before a test").isFalse();
      }
    }
    mysql = candidate;
  }

  @AfterEach
  void clearFixture() throws Exception {
    if (mysql != null) {
      try (var connection = mysql.getConnection();
          var statement = connection.createStatement()) {
        statement.executeUpdate("DELETE FROM " + TABLE);
      }
    }
  }

  @Test
  void concurrentFirstSnapshotsHaveOneWinnerAndLoserCanReload() throws Exception {
    var reads = new AtomicInteger();
    var dataSource = synchronizeRevisionReads(mysql, reads);
    var first = storage(dataSource);
    var second = storage(dataSource);
    var workers = Executors.newFixedThreadPool(2);
    try {
      assertThat(first.load()).isEmpty();
      assertThat(second.load()).isEmpty();
      var left = workers.submit(() -> attemptFirstSave(first, "left"));
      var right = workers.submit(() -> attemptFirstSave(second, "right"));
      boolean leftWon = left.get(20, TimeUnit.SECONDS);
      assertThat(right.get(20, TimeUnit.SECONDS)).isEqualTo(!leftWon);
      assertThat(reads.get()).isEqualTo(2);
      assertThat((leftWon ? second : first).load())
          .hasSize(1)
          .containsEntry("winner", leftWon ? "left" : "right");
    } finally {
      workers.shutdownNow();
      first.shutdown();
      second.shutdown();
    }
  }

  @Test
  void simultaneousReplayCommitsOneTransferAndIdleInstanceCanRefreshAndWrite() throws Exception {
    var observerStorage = storage(mysql);
    var reads = new AtomicInteger();
    var synchronizedDataSource = synchronizeRevisionReads(mysql, reads);
    var firstStorage = storage(synchronizedDataSource);
    var secondStorage = storage(synchronizedDataSource);
    var workers = Executors.newFixedThreadPool(2);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    var request =
        new TransferRequest(
            "shared-mysql-transfer",
            payer,
            receiver,
            new BigDecimal("25.00"),
            TransferCategory.OTHER,
            "integration test");

    try {
      TreasuryModule observer = loadModule(observerStorage);
      assertThat(observer.tryDeposit(payer, new BigDecimal("100.00"))).isTrue();
      assertThat(observer.tryDeposit(receiver, new BigDecimal("10.00"))).isTrue();
      TreasuryModule first = loadModule(firstStorage);
      TreasuryModule second = loadModule(secondStorage);
      var left = workers.submit(() -> first.transfer(request));
      var right = workers.submit(() -> second.transfer(request));
      var leftResult = left.get(20, TimeUnit.SECONDS);
      var rightResult = right.get(20, TimeUnit.SECONDS);
      assertThat(reads.get()).isEqualTo(2);
      assertThat(java.util.List.of(leftResult.status(), rightResult.status()))
          .containsExactlyInAnyOrder(TransferStatus.APPLIED, TransferStatus.REJECTED);

      TreasuryModule loser = leftResult.status() == TransferStatus.REJECTED ? first : second;
      assertThat(loser.transfer(request).status()).isEqualTo(TransferStatus.ALREADY_APPLIED);
      assertThat(observer.balance(payer)).isEqualByComparingTo("100.00");
      assertThat(observer.transferReceipt(request.transactionId())).isEmpty();
      assertThat(observer.refreshStateIfChanged()).isTrue();
      assertThat(observer.balance(payer)).isEqualByComparingTo("75.00");
      assertThat(observer.balance(receiver)).isEqualByComparingTo("35.00");
      assertThat(observer.transfer(request).status()).isEqualTo(TransferStatus.ALREADY_APPLIED);

      assertThat(observer.tryDeposit(payer, new BigDecimal("5.00"))).isTrue();
      Properties persisted = firstStorage.load();
      var snapshot = TreasuryStateCodec.stateFromProperties(persisted);
      assertThat(snapshot.balances().get(payer)).isEqualByComparingTo("80.00");
      assertThat(snapshot.balances().get(receiver)).isEqualByComparingTo("35.00");
      assertThat(snapshot.transferReceipts()).containsOnlyKeys(request.transactionId());
    } finally {
      workers.shutdownNow();
      firstStorage.shutdown();
      secondStorage.shutdown();
      observerStorage.shutdown();
    }
  }

  private static String setting(String property, String environment) {
    return System.getProperty("starcore.mysql." + property, System.getenv(environment));
  }

  private static SqlTreasuryStateStorage storage(DataSource dataSource) {
    return new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
  }

  private static TreasuryModule loadModule(TreasuryStateStorage storage) throws Exception {
    var module = new TreasuryModule();
    var field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    var load = TreasuryModule.class.getDeclaredMethod("loadState");
    load.setAccessible(true);
    load.invoke(module);
    return module;
  }

  private static boolean attemptFirstSave(SqlTreasuryStateStorage storage, String marker) {
    var properties = new Properties();
    properties.setProperty("winner", marker);
    try {
      storage.save(properties);
      return true;
    } catch (TreasuryStateConflictException conflict) {
      assertThat(conflict).hasMessageContaining("code=TREASURY_STATE_CONFLICT");
      return false;
    }
  }

  private static DataSource synchronizeRevisionReads(DataSource delegate, AtomicInteger reads) {
    var barrier = new CyclicBarrier(2);
    return intercept(
        DataSource.class,
        delegate,
        (method, args, result) -> {
          if (!(result instanceof Connection connection)) {
            return result;
          }
          return intercept(
              Connection.class,
              connection,
              (operation, parameters, prepared) -> {
                if (!(prepared instanceof PreparedStatement statement)
                    || !operation.getName().equals("prepareStatement")
                    || !(parameters[0] instanceof String sql)
                    || !sql.startsWith(
                        "SELECT property_value FROM " + TABLE + " WHERE property_key = ?")) {
                  return prepared;
                }
                return intercept(
                    PreparedStatement.class,
                    statement,
                    (query, ignored, rows) -> {
                      if (query.getName().equals("executeQuery") && reads.getAndIncrement() < 2) {
                        barrier.await(10, TimeUnit.SECONDS);
                      }
                      return rows;
                    });
              });
        });
  }

  @FunctionalInterface
  private interface Interceptor {
    Object after(Method method, Object[] arguments, Object result) throws Throwable;
  }

  private static <T> T intercept(Class<T> type, T delegate, Interceptor interceptor) {
    return type.cast(
        Proxy.newProxyInstance(
            type.getClassLoader(),
            new Class<?>[] {type},
            (proxy, method, args) -> {
              Object result;
              try {
                result = method.invoke(delegate, args);
              } catch (InvocationTargetException failure) {
                throw failure.getCause();
              }
              return interceptor.after(method, args, result);
            }));
  }
}
