#!/usr/bin/env python3
"""Offline independent verifier for the retained native MySQL interruption evidence."""
from pathlib import Path
from decimal import Decimal
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET

PHASES = ('start', 'complete', 'cancel', 'trade')
MODES = ('mysql_before', 'jvm_before', 'jvm_after')
TABLES = frozenset(('starcore_resource_state', 'starcore_resource_transfer_receipts',
    'starcore_resource_state_migrations', 'starcore_resource_transfer_history',
    'starcore_resource_revision', 'starcore_nation_trade_offers', 'starcore_nation_trade_head',
    'starcore_nation_trade_settlements', 'starcore_nation_production_head',
    'starcore_nation_production_events', 'starcore_treasury_state'))


def check(value, message):
    if not value:
        raise AssertionError(message)


def read(path):
    return json.loads(path.read_text())


def verify_files(directory, manifest, excluded):
    paths = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
    check(paths - set(excluded) == set(manifest), 'Unhashed or missing evidence')
    for name, digest in manifest.items():
        path = directory / name
        check(not path.is_symlink() and path.resolve().is_relative_to(directory.resolve()), 'Unsafe evidence member')
        check(hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'Evidence hash mismatch: ' + name)


def rows(tables, table):
    value = tables[table]
    return [dict(zip(value['columns'], row, strict=True)) for row in value['rows']]


def properties(tables, table):
    return {r['property_key']: r['property_value'] for r in rows(tables, table)}


def business(tables, identities, phase):
    check(set(tables) == TABLES, 'Incomplete table snapshot')
    resource = properties(tables, 'starcore_resource_state')
    stock = {}
    for i in range(int(resource['count'])):
        prefix = f'stockpile.{i}.'
        key = (resource[prefix + 'nationId'], resource[prefix + 'type'])
        check(key not in stock, 'Duplicate inventory cell')
        stock[key] = int(resource[prefix + 'amount'])
    seller, buyer = identities['selling'], identities['buying']
    expected = {(seller, 'mineral'): 280 if phase == 'trade' else 300 if phase == 'cancel' else 294,
                (seller, 'energy'): 100 if phase in ('trade', 'cancel') else 98}
    if phase == 'trade':
        expected[(buyer, 'mineral')] = 20
    if phase == 'complete':
        expected[(seller, 'industrial')] = 4
    check(stock == expected, 'Wrong inventory or duplicate delivery/refund')
    treasury = properties(tables, 'starcore_treasury_state')
    balances = {treasury[k]: Decimal(treasury[k.removesuffix('nationId') + 'balance'])
                for k in treasury if k.startswith('treasury.') and k.endswith('.nationId')}
    check(balances == {seller: Decimal(100 if phase == 'trade' else 50), buyer: Decimal(950 if phase == 'trade' else 1000)}, 'Wrong treasury balances')
    events = rows(tables, 'starcore_nation_production_events')
    trades = rows(tables, 'starcore_nation_trade_settlements')
    if phase == 'trade':
        check(not events and len(trades) == 1 and trades[0]['offer_id'] == identities['operation'], 'Wrong trade receipt')
        check(trades[0]['sequence_id'] == '1' and trades[0]['resource_sequence'] == '1', 'Wrong trade sequence')
        offers = rows(tables, 'starcore_nation_trade_offers')
        check(len(offers) == 1 and offers[0]['status'] == 'SETTLED' and offers[0]['offer_id'] == identities['operation'], 'Wrong consent')
        check(offers[0]['offer_json'] == trades[0]['offer_json'], 'Consent/receipt mismatch')
        offer = json.loads(trades[0]['offer_json'])
        check(offer['sellerId'] == identities['seller'] and offer['buyerId'] == identities['buyer']
              and offer['sellerNationId'] == seller and offer['buyerNationId'] == buyer,
              'Wrong original trade actors')
        check(offer['resourceId'] == 'mineral' and offer['amount'] == 20 and offer['unitPriceMinor'] == 250,
              'Wrong agreed trade terms')
        resources = rows(tables, 'starcore_resource_transfer_receipts')
        check(len(resources) == 1 and treasury['transfer.count'] == '1', 'Missing or duplicate asset receipt')
        check(resources[0]['transaction_id'] == treasury['transfer.0.transactionId'], 'Asset receipt identity mismatch')
        check(treasury['transfer.0.payerId'] == buyer and treasury['transfer.0.receiverId'] == seller and Decimal(treasury['transfer.0.amount']) == Decimal(50), 'Wrong payment receipt')
    else:
        check(not trades, 'Production unexpectedly created a trade')
        events.sort(key=lambda r: int(r['event_sequence']))
        expected_states = ['RUNNING'] + ([] if phase == 'start' else ['COMPLETED' if phase == 'complete' else 'CANCELLED'])
        check([e['state'] for e in events] == expected_states, 'Missing/duplicate production transition')
        check([int(e['event_sequence']) for e in events] == list(range(1, len(events) + 1)), 'Noncontiguous production history')
        check(all(e['run_id'] == identities['operation'] for e in events), 'Wrong production identity')
        check(len({e['run_json'] for e in events}) == 1, 'Production run changed')
        run = json.loads(events[0]['run_json'])
        check(run['actorId'] == identities['seller'] and run['nationId'] == seller
              and run['runId'] == identities['operation'], 'Wrong original production actor')
        check(run['recipeId'] == 'industrial_refining' and run['batches'] == 2
              and run['inputs'] == {'mineral': 6, 'energy': 2} and run['outputs'] == {'industrial': 4},
              'Wrong original production contract')
        check([e['completion_sequence'] for e in events] == ([None, '1'] if phase == 'complete' else [None] * len(events)), 'Wrong completion receipts')
        head = rows(tables, 'starcore_nation_production_head')
        check(len(head) == 1 and head[0]['event_sequence'] == str(len(events)) and head[0]['completed_sequence'] == str(int(phase == 'complete')), 'Wrong production head')


def inspect_case(directory, phase, mode, hashes=True):
    result = read(directory / 'result.json')
    check(result['status'] == 'PASSED' and result['phase'] == phase and result['mode'] == mode, 'Wrong case identity')
    if hashes:
        verify_files(directory, result['files'], {'result.json'})
    gate = read(directory / 'gate.json')
    check(gate == result['commit_boundary'], 'Gate marker changed')
    check(gate['pid'] == read(directory / 'operate-process.json')['pid'], 'Wrong interrupted PID')
    for stage in ('setup', 'verify', 'reload'):
        check(read(directory / (stage + '-exit.json'))['code'] == 0, 'Unsuccessful normal JVM')
    exit_record = read(directory / 'operate-exit.json')
    check(exit_record['pid'] == gate['pid'] and exit_record['code'] == (-9 if mode.startswith('jvm_') else 0), 'Wrong fault injection exit')
    lifecycle = read(directory / 'database-restarted.json')
    killed = lifecycle['killed']
    check(lifecycle['before']['Running'] and not killed['Running'] and killed['ExitCode'] == 137 and not killed['OOMKilled'], 'Missing database SIGKILL')
    check(lifecycle['after']['Running'] and not lifecycle['after']['OOMKilled'] and lifecycle['after']['StartedAt'] != lifecycle['before']['StartedAt'], 'Missing database restart')
    check(lifecycle['meta']['innodb_flush_log_at_trx_commit'] == lifecycle['meta']['sync_binlog'] == 1, 'Unsafe durability configuration')
    original = read(directory / 'independent-baseline.json')
    observed = read(directory / 'independent-gate.json')
    recovered = read(directory / 'independent-recovered.json')
    final = read(directory / 'independent-final.json')
    baseline = read(directory / 'baseline.json')
    desired = read(directory / 'transaction-view.json')
    check(baseline == original['tables'] and baseline != desired, 'No real pending mutations')
    for snapshot in (original, observed, recovered, final):
        check(snapshot['server_uuid'] == lifecycle['meta']['server_uuid'], 'Server authority changed')
        check(snapshot['database'] == f'starcore_inflight_it_{phase}_{mode}', 'Wrong database')
        check(snapshot['ddl'] == original['ddl'] and set(snapshot['tables']) == TABLES, 'Schema drift')
        check(all('ENGINE=InnoDB' in ddl for ddl in snapshot['ddl'].values()), 'Nontransactional table')
        check(snapshot['isolation'] == 'REPEATABLE-READ' and snapshot['ssl_cipher'], 'Missing transport/isolation evidence')
    committed = mode == 'jvm_after'
    check(gate['commit_returned_to_wrapper'] == committed, 'Wrong commit window')
    check(observed['tables'] == (desired if committed else baseline), 'Partial visibility at commit gate')
    check(recovered['tables'] == (desired if committed else baseline), 'Partial commit after process crash')
    transactions = observed['transactions']
    check(not transactions if committed else len(transactions) == 1 and transactions[0][2] == gate['connection_id'] and int(transactions[0][3]) > 0, 'No real transaction witness')
    if mode == 'mysql_before':
        check(read(directory / 'outage-outcome.json')['status'] == 'UNKNOWN', 'Interrupted operation reported success')
        stale = read(directory / 'stale-writers.json')
        check(stale['inventory_blocked'] and stale['treasury_blocked'] == (phase == 'trade'), 'Uncertain writers were not blocked')
    check(read(directory / 'verify-before.json') == recovered['tables'], 'Reload rewrote recovered state')
    for stage in ('verify', 'reload'):
        replay = read(directory / (stage + '-result.json'))
        expected = 'ALREADY_APPLIED' if stage == 'reload' or committed else 'STARTED' if phase == 'start' else 'APPLIED'
        check(replay['status'] == 'PASSED' and replay['first'] == expected and replay['replay'] == 'ALREADY_APPLIED', 'Wrong replay outcome')
        check(read(directory / (stage + '-after.json')) == final['tables'], 'Replay changed assets or receipts')
    check(read(directory / 'reload-before.json') == final['tables'], 'Fresh JVM altered final state')
    if committed:
        check(final['tables'] == desired, 'Committed replay was not read-only')
    identities = read(directory / 'identities.json')
    business(desired, identities, phase)
    business(final['tables'], identities, phase)
    return dict(phase=phase, mode=mode, status='PASSED')


def inspect(directory):
    manifest = read(directory / 'manifest.json')
    check(manifest['status'] == 'PASSED', 'Failed run is not accepted')
    verify_files(directory, manifest['files'], {'manifest.json'})
    results = [inspect_case(directory / f'{p}-{m}', p, m) for p in PHASES for m in MODES]
    check(manifest['results'] == results and manifest['cases'] == 12 and manifest['database_kills'] == 12
          and manifest['jvm_kills'] == 8 and manifest['normal_worker_exits'] == 40, 'Incomplete fault matrix')
    xml = next((directory / 'corrected-settlement').glob('TEST-*.xml'))
    suite = ET.parse(xml).getroot()
    counts = {k: int(suite.attrib[k]) for k in ('tests', 'failures', 'errors', 'skipped')}
    check(counts == dict(tests=31, failures=0, errors=0, skipped=0), 'Corrected SQL matrix failed')
    source = (directory / 'corrected-settlement/MySqlNationSettlementIntegrationTest.java').read_text()
    check('+ operation' in source and '+ table' in source, 'Old identical trigger sites were retained')
    shutdown = read(directory / 'shutdown.json')
    check(not shutdown['Running'] and shutdown['ExitCode'] == 0 and not shutdown['OOMKilled'], 'Database was not normally retained')
    return dict(status='PASSED', cases=12, database_kills=12, jvm_kills=8, normal_worker_exits=40, corrected_sql_tests=31)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(inspect(args.directory.resolve()), indent=2))
