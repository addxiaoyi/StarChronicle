#!/usr/bin/env python3
"""Verify real interruption evidence and reject plausible but invalid crash records.

Usage: python3 tools/test_nation_inflight_mysql.py PATH_TO_ACCEPTED_EVIDENCE
No database access; every mutation uses a fresh temporary copy of the evidence.
"""
from pathlib import Path
import copy
import json
import shutil
import sys
import tempfile
import unittest
import inspect_nation_inflight_mysql as I

EVIDENCE = None


class InFlightEvidenceTest(unittest.TestCase):
    def test_full_archive(self):
        self.assertEqual(I.inspect(EVIDENCE)['cases'], 12)

    def mutant(self, phase, mode, changes, *, hashes=False):
        with tempfile.TemporaryDirectory(prefix='inflight-evidence-negative-') as temporary:
            directory = Path(temporary) / 'case'
            shutil.copytree(EVIDENCE / f'{phase}-{mode}', directory)
            for filename, change in changes:
                path = directory / filename
                value = I.read(path)
                change(value)
                path.write_text(json.dumps(value))
            with self.assertRaises(AssertionError):
                I.inspect_case(directory, phase, mode, hashes=hashes)

    def test_rejects_corrupt_hash(self):
        self.mutant('start', 'jvm_before', [('gate.json', lambda v: v.update(pid=0))], hashes=True)

    def test_rejects_normal_jvm_exit_in_place_of_kill(self):
        self.mutant('start', 'jvm_before', [('operate-exit.json', lambda v: v.update(code=0))])

    def test_rejects_wrong_interrupted_pid(self):
        self.mutant('cancel', 'jvm_before', [('operate-exit.json', lambda v: v.update(pid=0))])

    def test_rejects_missing_active_transaction(self):
        self.mutant('complete', 'mysql_before', [('independent-gate.json', lambda v: v.update(transactions=[]))])

    def test_rejects_read_only_transaction_witness(self):
        self.mutant('start', 'mysql_before', [('independent-gate.json', lambda v: v['transactions'][0].__setitem__(3, 0))])

    def test_rejects_foreign_transaction_witness(self):
        self.mutant('cancel', 'jvm_before', [('independent-gate.json', lambda v: v['transactions'][0].__setitem__(2, 0))])

    def test_rejects_oom_in_place_of_deliberate_database_kill(self):
        self.mutant('trade', 'jvm_after', [('database-restarted.json', lambda v: v['killed'].update(OOMKilled=True))])

    def test_rejects_no_database_restart(self):
        self.mutant('trade', 'jvm_after', [('database-restarted.json', lambda v: v['after'].update(StartedAt=v['before']['StartedAt']))])

    def test_rejects_missing_durable_commit_configuration(self):
        self.mutant('complete', 'jvm_after', [('database-restarted.json', lambda v: v['meta'].update(innodb_flush_log_at_trx_commit=2))])

    def test_rejects_database_identity_change(self):
        self.mutant('complete', 'jvm_after', [('independent-recovered.json', lambda v: v.update(server_uuid='different'))])

    def test_rejects_success_on_interrupted_unknown(self):
        self.mutant('trade', 'mysql_before', [('outage-outcome.json', lambda v: v.update(status='APPLIED'))])

    def test_rejects_writable_uncertain_treasury(self):
        self.mutant('trade', 'mysql_before', [('stale-writers.json', lambda v: v.update(treasury_blocked=False))])

    def test_rejects_failed_reload_worker(self):
        self.mutant('start', 'jvm_after', [('reload-exit.json', lambda v: v.update(code=1))])

    def test_rejects_replay_that_claims_new_delivery(self):
        self.mutant('complete', 'jvm_after', [('reload-result.json', lambda v: v.update(first='APPLIED'))])

    def test_rejects_partial_rollback(self):
        desired = I.read(EVIDENCE / 'trade-mysql_before/transaction-view.json')
        self.mutant('trade', 'mysql_before', [('independent-recovered.json', lambda v: v['tables'].__setitem__('starcore_treasury_state', desired['starcore_treasury_state']))])

    def business_mutant(self, phase, change):
        directory = EVIDENCE / f'{phase}-jvm_after'
        tables = copy.deepcopy(I.read(directory / 'independent-final.json')['tables'])
        change(tables)
        with self.assertRaises(AssertionError):
            I.business(tables, I.read(directory / 'identities.json'), phase)

    def test_rejects_duplicate_trade_receipt(self):
        self.business_mutant('trade', lambda v: v['starcore_nation_trade_settlements']['rows'].append(v['starcore_nation_trade_settlements']['rows'][0]))

    def test_rejects_duplicate_production_completion(self):
        self.business_mutant('complete', lambda v: v['starcore_nation_production_events']['rows'].append(v['starcore_nation_production_events']['rows'][-1]))

    def test_rejects_refund_twice(self):
        def double(tables):
            table = tables['starcore_resource_state']
            for row in table['rows']:
                if row[0].startswith('stockpile.') and row[0].endswith('.amount') and row[1] == '300':
                    row[1] = '306'
        self.business_mutant('cancel', double)

    def test_rejects_wrong_treasury_value(self):
        def wrong(tables):
            for row in tables['starcore_treasury_state']['rows']:
                if row[0].endswith('.balance'):
                    row[1] = '999.00'
        self.business_mutant('trade', wrong)


for phase in I.PHASES:
    for mode in I.MODES:
        def verify(self, p=phase, m=mode):
            self.assertEqual(I.inspect_case(EVIDENCE / f'{p}-{m}', p, m)['status'], 'PASSED')
        setattr(InFlightEvidenceTest, f'test_real_{phase}_{mode}', verify)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    EVIDENCE = Path(sys.argv.pop()).resolve()
    unittest.main(verbosity=2)
