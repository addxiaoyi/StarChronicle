package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.mysql.cj.jdbc.MysqlDataSource;
import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TreasuryModule;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * Real MySQL/InnoDB transactions. Refuses shared catalogs, the normal port and nonempty fixtures.
 */
@EnabledIfSystemProperty(named = "starcore.mysql.settlement.it", matches = "true")
class MySqlNationSettlementIntegrationTest {
  private static final String CATALOG = "starcore_settlement_it";
  private static final Set<String> TABLES =
      Set.of(
          "starcore_resource_state",
          "starcore_resource_transfer_receipts",
          "starcore_resource_state_migrations",
          "starcore_resource_transfer_history",
          "starcore_resource_revision",
          "starcore_nation_trade_offers",
          "starcore_nation_trade_head",
          "starcore_nation_trade_settlements",
          "starcore_nation_production_head",
          "starcore_nation_production_events",
          "starcore_treasury_state");
  private final List<AbstractModuleStateStorage> stores = new ArrayList<>();
  private final UUID seller = UUID.randomUUID(), buyer = UUID.randomUUID();
  private final Nation selling = new Nation(NationId.random(), "Selling", seller, "seller");
  private final Nation buying = new Nation(NationId.random(), "Buying", buyer, "buyer");
  private final NationService nations = mock(NationService.class);
  private final AtomicBoolean loseAck = new AtomicBoolean(), failReads = new AtomicBoolean();
  private MysqlDataSource mysql;
  private DataSource source;
  private boolean owned, loseReload;
  private String writePrefix = "INSERT INTO starcore_nation_production_events";
  private volatile CountDownLatch beforeCommit, continueCommit;
  // The SQL settlement layer also checks wall-clock expiry at the actual commit boundary.
  private Instant time = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS);
  private Bundle initial;
  private NationProductionCatalog catalog = NationProductionCatalog.defaults();

  private record Bundle(
      ResourceModule resources,
      SqlResourceStateStorage storage,
      TreasuryModule treasury,
      SimpleNationTradeService trades,
      SimpleNationProductionService production) {}

  @BeforeEach
  void requireDedicatedEmptyMySql() throws Exception {
    String url = System.getenv("STARCORE_SETTLEMENT_MYSQL_URL");
    assertThat(url).matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/" + CATALOG + "(?:\\?.*)?");
    assertThat(url).doesNotContain("127.0.0.1:3306/");
    mysql = new MysqlDataSource();
    mysql.setURL(url);
    mysql.setUser(System.getenv("STARCORE_SETTLEMENT_MYSQL_USER"));
    mysql.setPassword(System.getenv("STARCORE_SETTLEMENT_MYSQL_PASSWORD"));
    try (var c = mysql.getConnection()) {
      assertThat(c.getCatalog()).isEqualTo(CATALOG);
      assertThat(c.getMetaData().getDatabaseProductName()).isEqualTo("MySQL");
      try (var s = c.createStatement();
          var r =
              s.executeQuery(
                  "SELECT @@default_storage_engine,@@transaction_isolation,@@sql_mode")) {
        assertThat(r.next()).isTrue();
        assertThat(r.getString(1)).isEqualToIgnoringCase("InnoDB");
        assertThat(r.getString(2)).isEqualTo("REPEATABLE-READ");
        assertThat(r.getString(3)).contains("STRICT_TRANS_TABLES");
      }
      for (String table : existingTables(c)) {
        assertThat(TABLES).as("Unexpected table in dedicated fixture").contains(table);
        try (var s = c.createStatement();
            var r = s.executeQuery("SELECT 1 FROM " + table + " LIMIT 1")) {
          assertThat(r.next()).as("Fixture must be empty: " + table).isFalse();
        }
      }
      try (var s = c.createStatement();
          var r = s.executeQuery("SHOW TRIGGERS")) {
        assertThat(r.next()).as("Fixture must not contain pre-existing triggers").isFalse();
      }
    }
    owned = true;
    source = interceptedSource();
    when(nations.nationOf(seller)).thenReturn(Optional.of(selling));
    when(nations.nationOf(buyer)).thenReturn(Optional.of(buying));
    initial = bundle();
    assertThat(initial.resources.grant(selling.id(), "mineral", 300)).isTrue();
    assertThat(initial.resources.grant(selling.id(), "energy", 100)).isTrue();
    assertThat(initial.treasury.tryDeposit(selling.id(), new BigDecimal("50.00"))).isTrue();
    assertThat(initial.treasury.tryDeposit(buying.id(), new BigDecimal("1000.00"))).isTrue();
  }

  @AfterEach
  void closeOnlyOwnedFixture() throws Exception {
    if (continueCommit != null) continueCommit.countDown();
    stores.forEach(AbstractModuleStateStorage::shutdown);
    if (!owned) return;
    try (var c = mysql.getConnection();
        var s = c.createStatement()) {
      s.execute("DROP TRIGGER IF EXISTS settlement_test_failure");
      c.setAutoCommit(false);
      for (String table : existingTables(c)) {
        if (!TABLES.contains(table)) throw new IllegalStateException("Unexpected fixture table");
        s.executeUpdate("DELETE FROM " + table);
      }
      c.commit();
    }
  }

  private Bundle bundle() throws Exception {
    String namespace = "mysql-settlement-it-" + UUID.randomUUID();
    var database = mock(DatabaseService.class);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.isRunning()).thenReturn(true);
    var persistence = mock(PersistenceService.class);
    when(persistence.loadProperties(eq(namespace), anyString())).thenReturn(new Properties());
    var logger = Logger.getLogger(namespace);
    var storage = new SqlResourceStateStorage(namespace, database, persistence, logger);
    stores.add(storage);
    var resources = new ResourceModule(storage);
    var type = Class.forName("dev.starcore.starcore.module.treasury.SqlTreasuryStateStorage");
    var constructor =
        type.getDeclaredConstructor(
            String.class, DatabaseService.class, PersistenceService.class, Logger.class);
    constructor.setAccessible(true);
    var treasuryStorage =
        (AbstractModuleStateStorage)
            constructor.newInstance(namespace, database, persistence, logger);
    stores.add(treasuryStorage);
    var treasury = new TreasuryModule();
    var field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(treasury, treasuryStorage);
    var load = TreasuryModule.class.getDeclaredMethod("loadState");
    load.setAccessible(true);
    load.invoke(treasury);
    Clock clock =
        new Clock() {
          public ZoneId getZone() {
            return ZoneOffset.UTC;
          }

          public Clock withZone(ZoneId zone) {
            return this;
          }

          public Instant instant() {
            return time;
          }
        };
    return new Bundle(
        resources,
        storage,
        treasury,
        new SimpleNationTradeService(resources, storage, nations, treasury, clock, () -> true),
        new SimpleNationProductionService(
            resources, storage, nations, clock, () -> true, () -> catalog));
  }

  private DataSource interceptedSource() {
    return (DataSource)
        Proxy.newProxyInstance(
            getClass().getClassLoader(),
            new Class<?>[] {DataSource.class},
            (proxy, method, args) -> {
              if (failReads.get() && method.getName().equals("getConnection"))
                throw new SQLException("injected unavailable store after commit");
              Object result = invoke(method, mysql, args);
              if (!(result instanceof Connection connection)) return result;
              var writing = new AtomicBoolean();
              return Proxy.newProxyInstance(
                  getClass().getClassLoader(),
                  new Class<?>[] {Connection.class},
                  (unused, call, parameters) -> {
                    if (call.getName().equals("prepareStatement")
                        && parameters[0].toString().startsWith(writePrefix)) writing.set(true);
                    if (call.getName().equals("commit") && writing.get()) {
                      if (beforeCommit != null) {
                        beforeCommit.countDown();
                        if (!continueCommit.await(15, TimeUnit.SECONDS))
                          throw new SQLException("fixture commit gate timeout");
                      }
                      Object committed = invoke(call, connection, parameters);
                      if (loseAck.compareAndSet(true, false)) {
                        if (loseReload) failReads.set(true);
                        throw new SQLException("injected lost commit acknowledgement");
                      }
                      return committed;
                    }
                    return invoke(call, connection, parameters);
                  });
            });
  }

  private static Object invoke(Method method, Object target, Object[] args) throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException error) {
      throw error.getCause();
    }
  }

  private static Set<String> existingTables(Connection c) throws Exception {
    var tables = new TreeSet<String>();
    try (var s = c.createStatement();
        var r = s.executeQuery("SHOW TABLES")) {
      while (r.next()) tables.add(r.getString(1));
    }
    return tables;
  }

  private Map<String, List<String>> snapshot() throws Exception {
    var result = new TreeMap<String, List<String>>();
    try (var c = mysql.getConnection()) {
      c.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
      c.setAutoCommit(false);
      for (String table : existingTables(c)) {
        var rows = new ArrayList<String>();
        try (var s = c.createStatement();
            var r = s.executeQuery("SELECT * FROM " + table)) {
          while (r.next()) {
            var values = new ArrayList<String>();
            for (int i = 1; i <= r.getMetaData().getColumnCount(); i++) values.add(r.getString(i));
            rows.add(values.toString());
          }
        }
        Collections.sort(rows);
        result.put(table, rows);
      }
      c.commit();
    }
    return result;
  }

  private void sql(String command) throws Exception {
    try (var c = mysql.getConnection();
        var s = c.createStatement()) {
      s.execute(command);
    }
  }

  private UUID start(Bundle b) {
    var id = UUID.randomUUID();
    assertThat(b.production.start(id, seller, "industrial_refining", 2).status())
        .isEqualTo(NationProductionService.Status.STARTED);
    return id;
  }

  private UUID offer(Bundle b) {
    var id = UUID.randomUUID();
    assertThat(b.trades.createOffer(id, seller, buyer, "mineral", 20, 250, 600).status())
        .isEqualTo(NationTradeService.Status.CREATED);
    return id;
  }

  private void stock(Bundle b, long mineral, long energy, long industrial) {
    assertThat(b.resources.amount(selling.id(), "mineral")).isEqualTo(mineral);
    assertThat(b.resources.amount(selling.id(), "energy")).isEqualTo(energy);
    assertThat(b.resources.amount(selling.id(), "industrial")).isEqualTo(industrial);
  }

  private void money(Bundle b, String sell, String buy) {
    assertThat(b.treasury.balance(selling.id())).isEqualByComparingTo(sell);
    assertThat(b.treasury.balance(buying.id())).isEqualByComparingTo(buy);
  }

  @Test
  void allAuthorityAndAssetTablesUseTransactionalEngine() throws Exception {
    try (var c = mysql.getConnection();
        var s = c.createStatement();
        var r =
            s.executeQuery(
                "SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE"
                    + " TABLE_SCHEMA=DATABASE()")) {
      var names = new HashSet<String>();
      while (r.next()) {
        names.add(r.getString(1));
        assertThat(r.getString(2)).isEqualToIgnoringCase("InnoDB");
      }
      assertThat(names).containsExactlyInAnyOrderElementsOf(TABLES);
    }
  }

  @Test
  void productionAndTradeShareInventoryWithoutLosingReceiptsAfterReload() throws Exception {
    UUID run = start(initial), sale = offer(initial);
    assertThat(initial.production.complete(run, seller).status())
        .isEqualTo(NationProductionService.Status.NOT_READY);
    var reloaded = bundle();
    assertThat(reloaded.trades.acceptOffer(sale, buyer).status())
        .isEqualTo(NationTradeService.Status.APPLIED);
    time = time.plusSeconds(60);
    assertThat(reloaded.production.complete(run, seller).status())
        .isEqualTo(NationProductionService.Status.APPLIED);
    var finalState = bundle();
    stock(finalState, 274, 98, 4);
    assertThat(finalState.resources.amount(buying.id(), "mineral")).isEqualTo(20);
    money(finalState, "100", "950");
    var receipt = finalState.trades.settlement(sale).orElseThrow();
    assertThat(finalState.storage.transferReceipt(receipt.offer().transactionId())).isPresent();
    assertThat(finalState.treasury.transferReceipt(receipt.offer().transactionId())).isPresent();
    assertThat(finalState.trades.settlementsAfter(receipt.authorityDomain(), 0, 100))
        .containsExactly(receipt);
    var completions =
        finalState.production.completionsAfter(
            finalState.production.completionAuthorityDomain().orElseThrow(), 0, 100);
    assertThat(completions).hasSize(1);
    assertThat(completions.getFirst().run().actorId()).isEqualTo(seller);
    var before = snapshot();
    assertThat(finalState.production.complete(run, seller).status())
        .isEqualTo(NationProductionService.Status.ALREADY_APPLIED);
    assertThat(finalState.trades.acceptOffer(sale, buyer).status())
        .isEqualTo(NationTradeService.Status.ALREADY_APPLIED);
    assertThat(snapshot()).isEqualTo(before);
  }

  @Test
  void configuredCapacityIsReservedAcrossIndependentMySqlInstances() throws Exception {
    catalog =
        NationProductionCatalog.parse(
            NationProductionCatalogTest.valid()
                .replace("\"max-running-runs\":2", "\"max-running-runs\":1"));
    var other = bundle();
    var barrier = new CyclicBarrier(2);
    try (var pool = Executors.newFixedThreadPool(2)) {
      var a =
          pool.submit(
              () -> {
                barrier.await();
                return initial.production.start(UUID.randomUUID(), seller, "custom", 1).status();
              });
      var b =
          pool.submit(
              () -> {
                barrier.await();
                return other.production.start(UUID.randomUUID(), seller, "custom", 1).status();
              });
      var values = List.of(a.get(20, TimeUnit.SECONDS), b.get(20, TimeUnit.SECONDS));
      assertThat(values.stream().filter(v -> v == NationProductionService.Status.STARTED).count())
          .isEqualTo(1);
      assertThat(values)
          .allMatch(
              v ->
                  Set.of(
                          NationProductionService.Status.STARTED,
                          NationProductionService.Status.CAPACITY_REACHED,
                          NationProductionService.Status.UNKNOWN)
                      .contains(v));
    }
    var reloaded = bundle();
    stock(reloaded, 298, 100, 0);
    assertThat(reloaded.production.capacity(seller).orElseThrow().runningRuns()).isEqualTo(1);
    var before = snapshot();
    assertThat(reloaded.production.start(UUID.randomUUID(), seller, "custom", 1).status())
        .isEqualTo(NationProductionService.Status.CAPACITY_REACHED);
    assertThat(snapshot()).isEqualTo(before);
  }

  @Test
  void mySqlStorageEnforcesCapacityEvenWithoutServicePrecheck() throws Exception {
    UUID first = start(initial);
    var run =
        new NationProductionService.Run(
            UUID.randomUUID(),
            seller,
            selling.id(),
            UUID.fromString(initial.resources.authorityDomainId()),
            "industrial_refining",
            1,
            Map.of("mineral", 3L, "energy", 1L),
            Map.of("industrial", 2L),
            time,
            time.plusSeconds(30));
    var before = snapshot();
    var staged = initial.resources.prepareProductionSnapshot(selling.id(), run.inputs(), Map.of());
    assertThatThrownBy(
            () ->
                initial.storage.saveProduction(
                    staged,
                    run,
                    NationProductionService.State.RUNNING,
                    time,
                    new NationProductionCatalog.Limits(1, 1000)))
        .isInstanceOf(IllegalStateException.class);
    assertThat(snapshot()).isEqualTo(before);
    assertThat(bundle().production.run(first, seller)).isPresent();
  }

  @Test
  void mysqlReloadRetainsFrozenRunWhenCurrentCatalogIsDisabled() throws Exception {
    UUID first = start(initial);
    var frozen = initial.production.run(first, seller).orElseThrow().run();
    catalog = NationProductionCatalog.unavailable();
    var reloaded = bundle();
    assertThat(
            reloaded.production.start(UUID.randomUUID(), seller, "industrial_refining", 1).status())
        .isEqualTo(NationProductionService.Status.STARTS_DISABLED);
    time = time.plusSeconds(60);
    assertThat(reloaded.production.complete(first, seller).status())
        .isEqualTo(NationProductionService.Status.APPLIED);
    stock(reloaded, 294, 98, 4);
    assertThat(reloaded.production.run(first, seller).orElseThrow().run()).isEqualTo(frozen);
    var before = snapshot();
    assertThat(bundle().production.complete(first, seller).status())
        .isEqualTo(NationProductionService.Status.ALREADY_APPLIED);
    assertThat(snapshot()).isEqualTo(before);
  }

  private static java.util.stream.Stream<Arguments> productionFailurePoints() {
    return java.util.stream.Stream.of("start", "complete", "cancel")
        .flatMap(
            phase ->
                java.util.stream.Stream.of(
                    Arguments.of(phase, "INSERT", "starcore_nation_production_events"),
                    Arguments.of(phase, "UPDATE", "starcore_nation_production_head"),
                    Arguments.of(phase, "UPDATE", "starcore_resource_revision"),
                    Arguments.of(phase, "INSERT", "starcore_resource_state")));
  }

  @ParameterizedTest
  @MethodSource("productionFailurePoints")
  void productionTransitionsRollbackEntireDatabaseOnNativeFailure(
      String phase, String operation, String table) throws Exception {
    UUID id = phase.equals("start") ? UUID.randomUUID() : start(initial);
    time = time.plusSeconds(60);
    var before = snapshot();
    sql(
        "CREATE TRIGGER settlement_test_failure BEFORE "
            + operation
            + " ON "
            + table
            + " FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='injected production"
            + " failure'");
    var outcome =
        switch (phase) {
          case "start" -> initial.production.start(id, seller, "industrial_refining", 2);
          case "complete" -> initial.production.complete(id, seller);
          default -> initial.production.cancel(id, seller);
        };
    assertThat(outcome.status()).isEqualTo(NationProductionService.Status.UNKNOWN);
    assertThat(snapshot()).isEqualTo(before);
    sql("DROP TRIGGER settlement_test_failure");
    var reloaded = bundle();
    stock(reloaded, phase.equals("start") ? 300 : 294, phase.equals("start") ? 100 : 98, 0);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "starcore_resource_state",
        "starcore_resource_transfer_receipts",
        "starcore_nation_trade_settlements",
        "starcore_treasury_state"
      })
  void tradeFailureRollsBackBothAssetsAndEveryReceipt(String table) throws Exception {
    var id = offer(initial);
    writePrefix = "INSERT INTO starcore_nation_trade_settlements";
    var before = snapshot();
    sql(
        "CREATE TRIGGER settlement_test_failure BEFORE INSERT ON "
            + table
            + " FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='injected trade failure'");
    assertThat(initial.trades.acceptOffer(id, buyer).status())
        .isIn(NationTradeService.Status.UNKNOWN, NationTradeService.Status.REJECTED);
    assertThat(snapshot()).isEqualTo(before);
    sql("DROP TRIGGER settlement_test_failure");
    var reloaded = bundle();
    assertThat(reloaded.trades.acceptOffer(id, buyer).status())
        .isEqualTo(NationTradeService.Status.APPLIED);
    stock(reloaded, 280, 100, 0);
    money(reloaded, "100", "950");
  }

  @ParameterizedTest
  @ValueSource(strings = {"start", "complete", "cancel"})
  void lostAcknowledgementReloadsCommittedProductionWithoutSecondDelivery(String phase)
      throws Exception {
    UUID id = phase.equals("start") ? UUID.randomUUID() : start(initial);
    time = time.plusSeconds(60);
    loseAck.set(true);
    var outcome =
        switch (phase) {
          case "start" -> initial.production.start(id, seller, "industrial_refining", 2);
          case "complete" -> initial.production.complete(id, seller);
          default -> initial.production.cancel(id, seller);
        };
    assertThat(outcome.status()).isEqualTo(NationProductionService.Status.UNKNOWN);
    stock(
        initial,
        phase.equals("cancel") ? 300 : 294,
        phase.equals("cancel") ? 100 : 98,
        phase.equals("complete") ? 4 : 0);
    var before = snapshot();
    var reloaded = bundle();
    var replay =
        switch (phase) {
          case "start" -> reloaded.production.start(id, seller, "industrial_refining", 2);
          case "complete" -> reloaded.production.complete(id, seller);
          default -> reloaded.production.cancel(id, seller);
        };
    assertThat(replay.status()).isEqualTo(NationProductionService.Status.ALREADY_APPLIED);
    assertThat(snapshot()).isEqualTo(before);
  }

  @Test
  void cancelledProductionRefundsOnceAndNeverCreatesCompletion() throws Exception {
    var id = start(initial);
    assertThat(initial.production.cancel(id, seller).status())
        .isEqualTo(NationProductionService.Status.APPLIED);
    var reloaded = bundle();
    stock(reloaded, 300, 100, 0);
    assertThat(reloaded.production.cancel(id, seller).status())
        .isEqualTo(NationProductionService.Status.ALREADY_APPLIED);
    assertThat(
            reloaded.production.completionsAfter(
                reloaded.production.completionAuthorityDomain().orElseThrow(), 0, 100))
        .isEmpty();
  }

  @Test
  void lostTradeAcknowledgementReconcilesBothAssetsAndAllReceipts() throws Exception {
    var id = offer(initial);
    writePrefix = "INSERT INTO starcore_nation_trade_settlements";
    loseAck.set(true);
    assertThat(initial.trades.acceptOffer(id, buyer).status())
        .isEqualTo(NationTradeService.Status.UNKNOWN);
    var reloaded = bundle();
    stock(reloaded, 280, 100, 0);
    money(reloaded, "100", "950");
    var before = snapshot();
    assertThat(reloaded.trades.acceptOffer(id, buyer).status())
        .isEqualTo(NationTradeService.Status.ALREADY_APPLIED);
    assertThat(snapshot()).isEqualTo(before);
  }

  @Test
  void failedReconciliationCannotOverwriteACommittedProduction() throws Exception {
    var id = start(initial);
    time = time.plusSeconds(60);
    loseReload = true;
    loseAck.set(true);
    assertThat(initial.production.complete(id, seller).status())
        .isEqualTo(NationProductionService.Status.UNKNOWN);
    failReads.set(false);
    var before = snapshot();
    assertThat(initial.resources.grant(selling.id(), "mineral", 1)).isFalse();
    assertThat(snapshot()).isEqualTo(before);
    var reloaded = bundle();
    stock(reloaded, 294, 98, 4);
    assertThat(reloaded.production.complete(id, seller).status())
        .isEqualTo(NationProductionService.Status.ALREADY_APPLIED);
  }

  @Test
  void staleInstanceCannotOverwriteProductionOrSpendOldInventoryInTrade() throws Exception {
    var sale = offer(initial);
    var stale = bundle();
    var id = start(initial);
    var committed = snapshot();
    assertThat(stale.resources.grant(selling.id(), "mineral", 1)).isFalse();
    assertThat(snapshot()).isEqualTo(committed);
    assertThat(stale.trades.acceptOffer(sale, buyer).status())
        .isIn(NationTradeService.Status.UNKNOWN, NationTradeService.Status.REJECTED);
    assertThat(snapshot()).isEqualTo(committed);
    var reloaded = bundle();
    assertThat(reloaded.trades.acceptOffer(sale, buyer).status())
        .isEqualTo(NationTradeService.Status.APPLIED);
    assertThat(reloaded.production.cancel(id, seller).status())
        .isEqualTo(NationProductionService.Status.APPLIED);
    stock(reloaded, 280, 100, 0);
  }

  @Test
  void separateConnectionsDoNotExposeUncommittedProduction() throws Exception {
    var id = start(initial);
    time = time.plusSeconds(60);
    var before = snapshot();
    beforeCommit = new CountDownLatch(1);
    continueCommit = new CountDownLatch(1);
    var workers = Executors.newSingleThreadExecutor();
    try {
      var pending = workers.submit(() -> initial.production.complete(id, seller));
      assertThat(beforeCommit.await(10, TimeUnit.SECONDS)).isTrue();
      assertThat(snapshot()).isEqualTo(before);
      continueCommit.countDown();
      assertThat(pending.get(10, TimeUnit.SECONDS).status())
          .isEqualTo(NationProductionService.Status.APPLIED);
    } finally {
      continueCommit.countDown();
      workers.shutdownNow();
    }
    stock(bundle(), 294, 98, 4);
  }

  @Test
  void separateConnectionsDoNotExposeEitherSideOfUncommittedTrade() throws Exception {
    var id = offer(initial);
    writePrefix = "INSERT INTO starcore_nation_trade_settlements";
    var before = snapshot();
    beforeCommit = new CountDownLatch(1);
    continueCommit = new CountDownLatch(1);
    var workers = Executors.newSingleThreadExecutor();
    try {
      var pending = workers.submit(() -> initial.trades.acceptOffer(id, buyer));
      assertThat(beforeCommit.await(10, TimeUnit.SECONDS)).isTrue();
      assertThat(snapshot()).isEqualTo(before);
      continueCommit.countDown();
      assertThat(pending.get(10, TimeUnit.SECONDS).status())
          .isEqualTo(NationTradeService.Status.APPLIED);
    } finally {
      continueCommit.countDown();
      workers.shutdownNow();
    }
    var reloaded = bundle();
    stock(reloaded, 280, 100, 0);
    money(reloaded, "100", "950");
  }

  @Test
  void unreadableTradeOutcomeBlocksBothAssetWritersUntilReload() throws Exception {
    var id = offer(initial);
    writePrefix = "INSERT INTO starcore_nation_trade_settlements";
    loseReload = true;
    loseAck.set(true);
    assertThat(initial.trades.acceptOffer(id, buyer).status())
        .isEqualTo(NationTradeService.Status.UNKNOWN);
    failReads.set(false);
    var committed = snapshot();
    assertThat(initial.resources.grant(selling.id(), "mineral", 1)).isFalse();
    assertThat(initial.treasury.tryDeposit(buying.id(), BigDecimal.ONE)).isFalse();
    assertThat(snapshot()).isEqualTo(committed);
    var reloaded = bundle();
    stock(reloaded, 280, 100, 0);
    money(reloaded, "100", "950");
    assertThat(reloaded.trades.acceptOffer(id, buyer).status())
        .isEqualTo(NationTradeService.Status.ALREADY_APPLIED);
  }

  @Test
  void independentInstancesCollectSameProductionAtMostOnce() throws Exception {
    var id = start(initial);
    time = time.plusSeconds(60);
    var other = bundle();
    var barrier = new CyclicBarrier(2);
    var workers = Executors.newFixedThreadPool(2);
    try {
      var first =
          workers.submit(
              () -> {
                barrier.await(10, TimeUnit.SECONDS);
                return initial.production.complete(id, seller).status();
              });
      var second =
          workers.submit(
              () -> {
                barrier.await(10, TimeUnit.SECONDS);
                return other.production.complete(id, seller).status();
              });
      var statuses = List.of(first.get(20, TimeUnit.SECONDS), second.get(20, TimeUnit.SECONDS));
      assertThat(statuses.stream().filter(s -> s == NationProductionService.Status.APPLIED).count())
          .isEqualTo(1);
      assertThat(statuses)
          .allMatch(
              s ->
                  Set.of(
                          NationProductionService.Status.APPLIED,
                          NationProductionService.Status.UNKNOWN,
                          NationProductionService.Status.ALREADY_APPLIED)
                      .contains(s));
    } finally {
      workers.shutdownNow();
    }
    var reloaded = bundle();
    stock(reloaded, 294, 98, 4);
    assertThat(
            reloaded.production.completionsAfter(
                reloaded.production.completionAuthorityDomain().orElseThrow(), 0, 100))
        .hasSize(1);
  }

  @Test
  void independentInstancesAcceptSameOfferAtMostOnce() throws Exception {
    var id = offer(initial);
    var other = bundle();
    var barrier = new CyclicBarrier(2);
    var workers = Executors.newFixedThreadPool(2);
    try {
      var first =
          workers.submit(
              () -> {
                barrier.await(10, TimeUnit.SECONDS);
                return initial.trades.acceptOffer(id, buyer).status();
              });
      var second =
          workers.submit(
              () -> {
                barrier.await(10, TimeUnit.SECONDS);
                return other.trades.acceptOffer(id, buyer).status();
              });
      var statuses = List.of(first.get(20, TimeUnit.SECONDS), second.get(20, TimeUnit.SECONDS));
      assertThat(statuses.stream().filter(s -> s == NationTradeService.Status.APPLIED).count())
          .isEqualTo(1);
      assertThat(statuses)
          .allMatch(
              s ->
                  Set.of(
                          NationTradeService.Status.APPLIED,
                          NationTradeService.Status.UNKNOWN,
                          NationTradeService.Status.ALREADY_APPLIED,
                          NationTradeService.Status.REJECTED)
                      .contains(s));
    } finally {
      workers.shutdownNow();
    }
    var reloaded = bundle();
    stock(reloaded, 280, 100, 0);
    money(reloaded, "100", "950");
    var receipt = reloaded.trades.settlement(id).orElseThrow();
    assertThat(reloaded.trades.settlementsAfter(receipt.authorityDomain(), 0, 100))
        .containsExactly(receipt);
  }

  @Test
  void removingWholeProductionTailBlocksReloadAndOrdinaryAssets() throws Exception {
    var id = start(initial);
    time = time.plusSeconds(60);
    assertThat(initial.production.complete(id, seller).status())
        .isEqualTo(NationProductionService.Status.APPLIED);
    sql("DELETE FROM starcore_nation_production_events WHERE event_sequence=2");
    var damaged = snapshot();
    assertThat(initial.resources.grant(selling.id(), "mineral", 1)).isFalse();
    assertThat(snapshot()).isEqualTo(damaged);
    assertThatThrownBy(this::bundle).isInstanceOf(IllegalStateException.class);
  }
}
