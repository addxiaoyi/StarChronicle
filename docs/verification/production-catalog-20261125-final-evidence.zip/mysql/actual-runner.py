from pathlib import Path
from types import SimpleNamespace
import importlib.util,os,subprocess,json,sys
root=Path('/home/add/starcore-production-catalog')
spec=importlib.util.spec_from_file_location('inflight',root/'tools/run_nation_inflight_mysql.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=root/'target/catalog-mysql-20261125';out.mkdir(exist_ok=False)
a=SimpleNamespace(private_directory=Path('/tmp/starcore-catalog-mysql-20261125'),container='starcore-inflight-mysql-catalog-20261125',port=33324)
i=m.prepare(a);m.write(out/'instance.json',i)
code=1
try:
 env=dict(os.environ,JAVA_HOME='/usr/lib/jvm/java-21-openjdk-amd64',STARCORE_SETTLEMENT_MYSQL_USER='starcore_inflight',STARCORE_SETTLEMENT_MYSQL_PASSWORD=os.environ['STARCORE_INFLIGHT_MYSQL_PASSWORD'],STARCORE_SETTLEMENT_MYSQL_URL='jdbc:mysql://127.0.0.1:33324/starcore_settlement_it?sslMode=REQUIRED&connectTimeout=2000&socketTimeout=5000&serverTimezone=UTC')
 with (out/'runner.log').open('xb') as log:
  code=subprocess.run(['python3','tools/run_nation_settlement_mysql.py','--output',str(out/'settlement')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 m.write(out/'after-tests.json',m.capture(i,'starcore_settlement_it'))
finally:
 if m.inspect(i)['Running']:m.docker('stop','--time','30',i['container'])
 m.write(out/'shutdown.json',m.inspect(i))
 logs=subprocess.run(['docker','--host=unix:///var/run/docker.sock','logs',i['container']],env={k:v for k,v in os.environ.items() if not k.startswith('DOCKER_')},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 (out/'database.log').write_bytes(logs.stdout)
 print('MySQL suite exit:',code,flush=True)
sys.exit(code)
