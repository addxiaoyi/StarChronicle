from pathlib import Path
import hashlib,subprocess,json,zipfile,sys,os,time
root=Path('/home/add/starchronicle-production-catalog');out=root/'target/catalog-pair-regression-2';out.mkdir(exist_ok=False)
java='/usr/lib/jvm/java-21-openjdk-amd64';native='/home/add/starcore-production-catalog/target/starcore-1.0.0.jar'
sha=hashlib.sha256((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes()).hexdigest()
result=[]
def execute(name,cmd,env=None):
 with (out/(name+'.log')).open('xb') as log:code=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 if code:raise RuntimeError(name+' failed; evidence retained')
for index,kind in enumerate(('production','offline','trade','dungeon','war')):
 attempt='catalog-regression-'+kind+'-2';port=29777+index
 tool={'production':'prepare-nation-production-paper.py','offline':'prepare-nation-production-paper.py','trade':'prepare-nation-trade-paper.py','dungeon':'prepare-production-paper.py','war':'prepare-battlefield-paper.py'}[kind]
 args=['python3','tools/'+tool,'--attempt',attempt,'--port',str(port),'--starcore',native,'--runtime','/tmp/starcore-mobile-paper-acceptance-20261122d','--java-home',java,'--artifacts-dir','/tmp/star-acceptance-stack-20261125']
 if kind=='offline':args+=['--offline']
 if kind=='dungeon':args+=['--campaign']
 execute(kind+'-prepare',args)
 run=root/'run'/f'paper-epic-{sha[:8]}-{"war" if kind=="war" else "dungeon"}-{attempt}'
 with zipfile.ZipFile(run/'plugins/EssentialsX-2.22.0.jar') as z:config=z.read('config.yml').decode()
 assert config.count('update-check: true')==1
 (run/'plugins/Essentials').mkdir(exist_ok=True);(run/'plugins/Essentials/config.yml').write_text(config.replace('update-check: true','update-check: false'))
 manifest=json.loads((run/'preparation.json').read_text());manifest['optional_essentials_update_check']=False;(run/'preparation.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 phases={'production':['production-first','production-second','production-third'],'offline':['production-offline-first','production-offline-second'],'trade':['sale-first','sale-second','sale-third'],'dungeon':['first','second','third'],'war':['first','second','third']}[kind]
 for boot,phase in enumerate(phases,1):
  if boot==2 and kind=='offline':execute(kind+'-resume',['python3','tools/prepare-nation-production-resume.py','--run',str(run)])
  args=['python3','tools/epic-paper-session.py','--run',str(run),'--java-home',java,'--node','/usr/bin/node','--boot',str(boot),'--scenario',phase]
  if kind in ('dungeon','war'):args+=['--contributions']
  execute(f'{kind}-boot{boot}',args)
  print(kind,boot,'completed',flush=True)
 inspector={'production':'inspect-nation-production-paper.py','offline':'inspect-nation-production-paper.py','trade':'inspect-nation-trade-paper.py','dungeon':'inspect-epic-production-paper.py','war':'inspect-battlefield-paper.py'}[kind]
 execute(kind+'-inspect',['python3','tools/'+inspector,str(run)])
 test={'production':('STARCHRONICLE_NATION_PRODUCTION_RUN','test_nation_production_acceptance.py'),'offline':('STARCHRONICLE_NATION_PRODUCTION_RUN','test_nation_production_acceptance.py'),'trade':('STARCHRONICLE_NATION_TRADE_RUN','test_nation_trade_acceptance.py'),'dungeon':('STARCHRONICLE_EPIC_RUN','test_epic_production_acceptance.py'),'war':('STARCHRONICLE_EPIC_RUN','test_battlefield_acceptance.py')}[kind]
 execute(kind+'-evidence-tests',['python3','-m','unittest','discover','-s','tools','-p',test[1],'-v'],dict(os.environ,**{test[0]:str(run)}))
 result.append(dict(kind=kind,run=str(run),boots=len(phases)))
 (out/'progress.json').write_text(json.dumps(result,indent=2)+'\n')
print('All frozen-pair regressions passed',flush=True)
