package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.NationProductionService.Status.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.sqlite.SQLiteDataSource;

class NationProductionSettlementTest {
  @TempDir Path directory;
  SQLiteDataSource sqlite;
  DataSource source;
  ResourceModule resources;
  SqlResourceStateStorage storage;
  SimpleNationProductionService production;
  final UUID actor = UUID.randomUUID(), successor = UUID.randomUUID();
  final Nation nation = new Nation(NationId.random(), "Production", actor, "original");
  final NationService nations = mock(NationService.class);
  final AtomicBoolean loseAck = new AtomicBoolean(),
      loseReads = new AtomicBoolean(),
      failReads = new AtomicBoolean();
  Instant time = Instant.parse("2026-11-25T20:00:00Z");

  @BeforeEach
  void setup() throws Exception {
    sqlite = new SQLiteDataSource();
    sqlite.setUrl("jdbc:sqlite:" + directory.resolve("production.db"));
    sqlite.setBusyTimeout(5000);
    source =
        (DataSource)
            Proxy.newProxyInstance(
                getClass().getClassLoader(),
                new Class<?>[] {DataSource.class},
                (unused, method, args) -> {
                  if (failReads.get() && method.getName().equals("getConnection"))
                    throw new SQLException("injected unavailable store");
                  Object value = invoke(method, sqlite, args);
                  if (!(value instanceof Connection connection)) return value;
                  AtomicBoolean productionWrite = new AtomicBoolean();
                  return Proxy.newProxyInstance(
                      getClass().getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (proxy, call, parameters) -> {
                        if (call.getName().equals("prepareStatement")
                            && parameters[0]
                                .toString()
                                .startsWith("INSERT INTO starcore_nation_production_events"))
                          productionWrite.set(true);
                        Object result = invoke(call, connection, parameters);
                        if (call.getName().equals("commit")
                            && productionWrite.get()
                            && loseAck.compareAndSet(true, false)) {
                          if (loseReads.get()) failReads.set(true);
                          throw new SQLException("injected lost production commit acknowledgement");
                        }
                        return result;
                      });
                });
    when(nations.nationOf(actor)).thenReturn(Optional.of(nation));
    restart();
    assertThat(resources.grant(nation.id(), "mineral", 300)).isTrue();
    assertThat(resources.grant(nation.id(), "energy", 100)).isTrue();
  }

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  void restart() {
    storage = new SqlResourceStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    resources = new ResourceModule(storage);
    production = service(() -> true);
  }

  SimpleNationProductionService service(java.util.function.BooleanSupplier thread) {
    Clock clock =
        new Clock() {
          public ZoneId getZone() {
            return ZoneOffset.UTC;
          }

          public Clock withZone(ZoneId zone) {
            return this;
          }

          public Instant instant() {
            return time;
          }
        };
    return new SimpleNationProductionService(resources, storage, nations, clock, thread);
  }

  UUID start() {
    UUID id = UUID.randomUUID();
    assertThat(production.start(id, actor, "industrial_refining", 2).status()).isEqualTo(STARTED);
    return id;
  }

  void due() {
    time = time.plusSeconds(60);
  }

  void assets(long mineral, long energy, long industrial) {
    assertThat(resources.amount(nation.id(), "mineral")).isEqualTo(mineral);
    assertThat(resources.amount(nation.id(), "energy")).isEqualTo(energy);
    assertThat(resources.amount(nation.id(), "industrial")).isEqualTo(industrial);
  }

  List<NationProductionService.CompletionReceipt> receipts() {
    return production.completionsAfter(
        production.completionAuthorityDomain().orElseThrow(), 0, 100);
  }

  void sql(String text) throws Exception {
    try (var c = sqlite.getConnection();
        var s = c.createStatement()) {
      s.execute(text);
    }
  }

  @Test
  void paidRunSurvivesRestartAndOnlyDeliversOnceAfterItsFrozenDeadline() {
    UUID id = start();
    assets(294, 98, 0);
    var original = production.run(id, actor).orElseThrow().run();
    assertThat(original.inputs()).containsEntry("mineral", 6L).containsEntry("energy", 2L);
    assertThat(original.outputs()).containsExactlyEntriesOf(Map.of("industrial", 4L));
    assertThat(production.complete(id, actor).status()).isEqualTo(NOT_READY);
    restart();
    assertThat(production.run(id, actor).orElseThrow().run()).isEqualTo(original);
    due();
    assertThat(production.complete(id, actor).status()).isEqualTo(APPLIED);
    assets(294, 98, 4);
    restart();
    assertThat(production.complete(id, actor).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(production.cancel(id, actor).status()).isEqualTo(REJECTED);
    assertThat(receipts()).hasSize(1);
    assertThat(receipts().getFirst().run()).isEqualTo(original);
    assets(294, 98, 4);
  }

  @Test
  void cancellationReturnsExactInputsAndNeverCreatesProductionCredit() {
    UUID id = start();
    assertThat(production.cancel(id, actor).status()).isEqualTo(APPLIED);
    assets(300, 100, 0);
    restart();
    assertThat(production.cancel(id, actor).status()).isEqualTo(ALREADY_APPLIED);
    due();
    assertThat(production.complete(id, actor).status()).isEqualTo(REJECTED);
    assertThat(receipts()).isEmpty();
    assets(300, 100, 0);
  }

  @Test
  void policyGrantBonusesCannotMultiplyRefundsOrFrozenOutputs() throws Exception {
    var policy = mock(dev.starcore.starcore.module.policy.PolicyService.class);
    when(policy.activePolicyModifier(eq(nation.id()), eq("production_bonus"), any()))
        .thenReturn(3.0);
    var field = ResourceModule.class.getDeclaredField("policyService");
    field.setAccessible(true);
    field.set(resources, policy);
    UUID cancel = start();
    assertThat(production.cancel(cancel, actor).status()).isEqualTo(APPLIED);
    assets(300, 100, 0);
    UUID finish = start();
    due();
    assertThat(production.complete(finish, actor).status()).isEqualTo(APPLIED);
    assets(294, 98, 4);
    verifyNoInteractions(policy);
  }

  @Test
  void legacyActorlessFactoryCallsCannotMutateAssetsOrInferPaidRuns() {
    var legacy = new SimpleProcessingService(resources, mock(ResourcePriceService.class));
    var factory =
        legacy.buildFactory(
            nation.id(),
            "legacy",
            dev.starcore.starcore.module.resource.model.Factory.FactoryType.values()[0]);
    legacy.registerRecipe(
        new dev.starcore.starcore.module.resource.model.ProcessingRecipe(
            "legacy", "legacy", Map.of("mineral", 3L), Map.of("industrial", 2L), 1, 0, 1));
    assertThat(legacy.startProcessing(factory.factoryId(), "legacy", 1)).isFalse();
    assertThat(legacy.autoProcess(nation.id(), "legacy", 1)).isFalse();
    factory.startProcessing("legacy", 1);
    assertThat(legacy.completeProcessing(factory.factoryId())).isEmpty();
    assertThat(factory.isProcessing()).isTrue();
    assertThat(production.completionAuthorityDomain()).isEmpty();
    assets(300, 100, 0);
  }

  @Test
  void idIsBoundToInitiatorRecipeAndBatchCountIncludingTerminalReplays() {
    UUID id = start();
    assertThat(production.start(id, actor, "industrial_refining", 2).status())
        .isEqualTo(ALREADY_APPLIED);
    assertThat(production.start(id, actor, "industrial_refining", 3).status()).isEqualTo(REJECTED);
    assertThat(production.start(id, actor, "chemical_synthesis", 2).status()).isEqualTo(REJECTED);
    assertThat(production.start(id, successor, "industrial_refining", 2).status())
        .isEqualTo(REJECTED);
    assertThat(production.cancel(id, actor).status()).isEqualTo(APPLIED);
    assertThat(production.start(id, actor, "industrial_refining", 2).status())
        .isEqualTo(ALREADY_APPLIED);
    assets(300, 100, 0);
  }

  @Test
  void missingInputsDoNotPartiallyConsumeOtherResources() {
    assertThat(resources.consume(nation.id(), "energy", 100)).isTrue();
    UUID id = UUID.randomUUID();
    assertThat(production.start(id, actor, "industrial_refining", 2).status())
        .isEqualTo(INSUFFICIENT_ASSETS);
    assertThat(production.run(id, actor)).isEmpty();
    assets(300, 0, 0);
    assertThat(production.completionAuthorityDomain()).isEmpty();
  }

  @Test
  void successorMaySettlePaidNationalRunButCannotRewriteOriginalAttribution() {
    UUID id = start();
    due();
    var replacement = new Nation(nation.id(), "Production", successor, "successor");
    when(nations.nationOf(actor)).thenReturn(Optional.empty());
    when(nations.nationOf(successor)).thenReturn(Optional.of(replacement));
    assertThat(production.complete(id, actor).status()).isEqualTo(REJECTED);
    assertThat(production.complete(id, UUID.randomUUID()).status()).isEqualTo(REJECTED);
    assertThat(production.complete(id, successor).status()).isEqualTo(APPLIED);
    assertThat(receipts().getFirst().run().actorId()).isEqualTo(actor);
    assertThat(production.complete(id, actor).status()).isEqualTo(ALREADY_APPLIED);
    assets(294, 98, 4);
  }

  @Test
  void unrelatedFounderCannotSeeOrMutateAnotherNationsRun() {
    var foreign = new Nation(NationId.random(), "Foreign", successor, "foreign");
    when(nations.nationOf(successor)).thenReturn(Optional.of(foreign));
    UUID id = start();
    due();
    assertThat(production.run(id, successor)).isEmpty();
    assertThat(production.runs(successor, 20)).isEmpty();
    assertThat(production.complete(id, successor).status()).isEqualTo(REJECTED);
    assertThat(production.cancel(id, successor).status()).isEqualTo(REJECTED);
    assets(294, 98, 0);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "start-inventory",
        "start-journal",
        "start-head",
        "complete-inventory",
        "complete-journal",
        "complete-head",
        "cancel-inventory",
        "cancel-journal",
        "cancel-head"
      })
  void anyFailedSqlParticipantRollsBackTheWholeStateTransition(String point) throws Exception {
    String stage = point.split("-")[0];
    UUID id = stage.equals("start") ? UUID.randomUUID() : start();
    due();
    String target =
        point.endsWith("inventory")
            ? "INSERT ON starcore_resource_state"
            : point.endsWith("journal")
                ? "INSERT ON starcore_nation_production_events"
                : stage.equals("start")
                    ? "INSERT ON starcore_nation_production_head"
                    : "UPDATE ON starcore_nation_production_head";
    sql(
        "CREATE TRIGGER fail_production BEFORE "
            + target
            + " BEGIN SELECT RAISE(ABORT,'injected production failure'); END");
    var result =
        stage.equals("start")
            ? production.start(id, actor, "industrial_refining", 2)
            : stage.equals("complete")
                ? production.complete(id, actor)
                : production.cancel(id, actor);
    assertThat(result.status()).isEqualTo(UNKNOWN);
    assets(stage.equals("start") ? 300 : 294, stage.equals("start") ? 100 : 98, 0);
    assertThat(production.run(id, actor).map(NationProductionService.RunView::state))
        .isEqualTo(
            stage.equals("start")
                ? Optional.empty()
                : Optional.of(NationProductionService.State.RUNNING));
    sql("DROP TRIGGER fail_production");
    restart();
    result =
        stage.equals("start")
            ? production.start(id, actor, "industrial_refining", 2)
            : stage.equals("complete")
                ? production.complete(id, actor)
                : production.cancel(id, actor);
    assertThat(result.status()).isEqualTo(stage.equals("start") ? STARTED : APPLIED);
  }

  @ParameterizedTest
  @ValueSource(strings = {"start", "complete", "cancel"})
  void lostAcknowledgementReconcilesTheCommittedTransitionWithoutDuplicateAssets(String stage) {
    UUID id = stage.equals("start") ? UUID.randomUUID() : start();
    due();
    loseAck.set(true);
    var result =
        stage.equals("start")
            ? production.start(id, actor, "industrial_refining", 2)
            : stage.equals("complete")
                ? production.complete(id, actor)
                : production.cancel(id, actor);
    assertThat(result.status()).isEqualTo(UNKNOWN);
    assets(
        stage.equals("cancel") ? 300 : 294,
        stage.equals("cancel") ? 100 : 98,
        stage.equals("complete") ? 4 : 0);
    restart();
    result =
        stage.equals("start")
            ? production.start(id, actor, "industrial_refining", 2)
            : stage.equals("complete")
                ? production.complete(id, actor)
                : production.cancel(id, actor);
    assertThat(result.status()).isEqualTo(ALREADY_APPLIED);
    assertThat(receipts()).hasSize(stage.equals("complete") ? 1 : 0);
  }

  @Test
  void unavailableReconciliationBlocksOrdinaryWritesUntilRestart() {
    UUID id = start();
    due();
    loseAck.set(true);
    loseReads.set(true);
    assertThat(production.complete(id, actor).status()).isEqualTo(UNKNOWN);
    assertThat(resources.grant(nation.id(), "industrial", 1)).isFalse();
    assertThat(production.complete(id, actor).status()).isEqualTo(UNAVAILABLE);
    failReads.set(false);
    restart();
    assertThat(production.complete(id, actor).status()).isEqualTo(ALREADY_APPLIED);
    assets(294, 98, 4);
  }

  @Test
  void staleServerAndOrdinarySnapshotCannotOverwritePaidInputsOrOutputs() {
    var staleStore =
        new SqlResourceStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    var stale = new ResourceModule(staleStore);
    UUID id = start();
    assertThat(stale.grant(nation.id(), "mineral", 1)).isFalse();
    var competing =
        new SimpleNationProductionService(
            stale,
            staleStore,
            nations,
            Clock.fixed(time.plusSeconds(60), ZoneOffset.UTC),
            () -> true);
    assertThat(competing.complete(id, actor).status()).isEqualTo(UNKNOWN);
    assertThat(competing.complete(id, actor).status()).isEqualTo(APPLIED);
    restart();
    assets(294, 98, 4);
  }

  @Test
  void concurrentCompletionsProduceOneReceipt() throws Exception {
    UUID id = start();
    due();
    try (var pool = Executors.newFixedThreadPool(2)) {
      var a = pool.submit(() -> production.complete(id, actor));
      var b = pool.submit(() -> production.complete(id, actor));
      assertThat(List.of(a.get(5, TimeUnit.SECONDS).status(), b.get(5, TimeUnit.SECONDS).status()))
          .containsExactlyInAnyOrder(APPLIED, ALREADY_APPLIED);
    }
    assertThat(receipts()).hasSize(1);
    assets(294, 98, 4);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"tail", "start", "head", "terms", "state", "digest", "sequence", "authority"})
  void missingOrChangedProductionEvidenceFailsClosedIncludingOrdinarySaves(String damage)
      throws Exception {
    UUID id = start();
    due();
    assertThat(production.complete(id, actor).status()).isEqualTo(APPLIED);
    sql(
        switch (damage) {
          case "tail" -> "DELETE FROM starcore_nation_production_events WHERE event_sequence=2";
          case "start" -> "DELETE FROM starcore_nation_production_events WHERE event_sequence=1";
          case "head" -> "DELETE FROM starcore_nation_production_head";
          case "terms" ->
              "UPDATE starcore_nation_production_events SET"
                  + " run_json=REPLACE(run_json,'industrial_refining','different')";
          case "state" ->
              "UPDATE starcore_nation_production_events SET state='CANCELLED' WHERE"
                  + " event_sequence=2";
          case "digest" ->
              "UPDATE starcore_nation_production_events SET entry_hash='bad' WHERE"
                  + " event_sequence=1";
          case "sequence" ->
              "UPDATE starcore_nation_production_events SET completion_sequence=2 WHERE"
                  + " event_sequence=2";
          default ->
              "UPDATE starcore_nation_production_head SET resource_domain='"
                  + UUID.randomUUID()
                  + "'";
        });
    assertThatThrownBy(() -> production.completionAuthorityDomain())
        .isInstanceOf(IllegalStateException.class);
    assertThat(resources.grant(nation.id(), "mineral", 1)).isFalse();
    assertThatThrownBy(this::restart).isInstanceOf(IllegalStateException.class);
  }

  @Test
  void cursorDomainThreadAndInvalidCountsFailBeforeMutation() {
    assertThat(
            production
                .start(UUID.randomUUID(), actor, "industrial_refining", Long.MAX_VALUE)
                .status())
        .isEqualTo(REJECTED);
    assertThat(production.start(UUID.randomUUID(), actor, "industrial_refining", 0).status())
        .isEqualTo(REJECTED);
    UUID id = start();
    due();
    assertThat(service(() -> false).complete(id, actor).status()).isEqualTo(UNAVAILABLE);
    assertThatThrownBy(() -> production.completionsAfter(UUID.randomUUID(), 0, 100))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(
            () ->
                production.completionsAfter(
                    production.completionAuthorityDomain().orElseThrow(), 1, 100))
        .isInstanceOf(IllegalStateException.class);
    assets(294, 98, 0);
  }

  private SimpleNationProductionService configured(
      java.util.function.Supplier<NationProductionCatalog> config) {
    Clock clock =
        new Clock() {
          public ZoneId getZone() {
            return ZoneOffset.UTC;
          }

          public Clock withZone(ZoneId zone) {
            return this;
          }

          public Instant instant() {
            return time;
          }
        };
    return new SimpleNationProductionService(
        resources, storage, nations, clock, () -> true, config);
  }

  @Test
  void hotCatalogChangesNeverRewriteExistingRunAndRemovedRecipeCanFinish() {
    var current =
        new java.util.concurrent.atomic.AtomicReference<>(
            NationProductionCatalog.parse(NationProductionCatalogTest.valid()));
    production = configured(current::get);
    UUID first = UUID.randomUUID(), second = UUID.randomUUID();
    assertThat(production.start(first, actor, "custom", 2).status()).isEqualTo(STARTED);
    var frozen = production.run(first, actor).orElseThrow().run();
    current.set(
        NationProductionCatalog.parse(
            NationProductionCatalogTest.valid()
                .replace("\"industrial\":1", "\"industrial\":3")
                .replace("\"seconds-per-batch\":1", "\"seconds-per-batch\":9")));
    assertThat(production.start(second, actor, "custom", 1).status()).isEqualTo(STARTED);
    assertThat(production.run(second, actor).orElseThrow().run().outputs())
        .containsEntry("industrial", 3L);
    assertThat(production.run(first, actor).orElseThrow().run()).isEqualTo(frozen);
    current.set(NationProductionCatalog.unavailable());
    assertThat(production.start(first, actor, "custom", 2).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 1).status())
        .isEqualTo(STARTS_DISABLED);
    time = time.plusSeconds(2);
    assertThat(production.complete(first, actor).status()).isEqualTo(APPLIED);
    assertThat(production.complete(second, actor).status()).isEqualTo(NOT_READY);
    assertThat(production.cancel(second, actor).status()).isEqualTo(APPLIED);
    assets(296, 100, 2);
    restart();
    assertThat(production.complete(first, actor).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(production.cancel(second, actor).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(receipts()).hasSize(1);
    assets(296, 100, 2);
  }

  @Test
  void batchAndRunCapacityCountsPendingOldRecipesAndReleasesOnlyOnTerminalState() {
    UUID old = start();
    var catalog = NationProductionCatalog.parse(NationProductionCatalogTest.valid());
    production = configured(() -> catalog);
    assertThat(production.capacity(actor).orElseThrow().runningBatches()).isEqualTo(2);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 2).status())
        .isEqualTo(CAPACITY_REACHED);
    UUID next = UUID.randomUUID();
    assertThat(production.start(next, actor, "custom", 1).status()).isEqualTo(STARTED);
    time = time.plusSeconds(120); // Ready-but-uncollected runs still occupy capacity.
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 1).status())
        .isEqualTo(CAPACITY_REACHED);
    assertThat(production.cancel(old, actor).status()).isEqualTo(APPLIED);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 2).status()).isEqualTo(STARTED);
    assertThat(production.capacity(actor).orElseThrow().runningBatches()).isEqualTo(3);
    assertThat(production.capacity(successor)).isEmpty();
  }

  @Test
  void perRecipeLimitRejectsBeforeAssetsChange() {
    production =
        configured(() -> NationProductionCatalog.parse(NationProductionCatalogTest.valid()));
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 4).status())
        .isEqualTo(REJECTED);
    assertThat(production.completionAuthorityDomain()).isEmpty();
    assets(300, 100, 0);
  }

  @Test
  void storageIndependentlyEnforcesCapacityInsideInventoryTransaction() {
    var current =
        NationProductionCatalog.parse(
            NationProductionCatalogTest.valid()
                .replace("\"max-running-runs\":2", "\"max-running-runs\":1"));
    production = configured(() -> current);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 1).status()).isEqualTo(STARTED);
    var before = storage.load();
    var history = storage.productionState();
    var run =
        new NationProductionService.Run(
            UUID.randomUUID(),
            actor,
            nation.id(),
            UUID.fromString(resources.authorityDomainId()),
            "custom",
            1,
            Map.of("mineral", 2L),
            Map.of("industrial", 1L),
            time,
            time.plusSeconds(1));
    var staged = resources.prepareProductionSnapshot(nation.id(), run.inputs(), Map.of());
    assertThatThrownBy(
            () ->
                storage.saveProduction(
                    staged, run, NationProductionService.State.RUNNING, time, current.limits()))
        .isInstanceOf(IllegalStateException.class);
    assertThat(storage.load()).isEqualTo(before);
    assertThat(storage.productionState()).isEqualTo(history);
    assets(298, 100, 0);
  }

  @Test
  void independentInstancesCannotBothReserveLastProductionSlot() throws Exception {
    var catalog =
        NationProductionCatalog.parse(
            NationProductionCatalogTest.valid()
                .replace("\"max-running-runs\":2", "\"max-running-runs\":1"));
    production = configured(() -> catalog);
    var otherStore =
        new SqlResourceStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    var otherResources = new ResourceModule(otherStore);
    var other =
        new SimpleNationProductionService(
            otherResources,
            otherStore,
            nations,
            Clock.fixed(time, ZoneOffset.UTC),
            () -> true,
            () -> catalog);
    var barrier = new CyclicBarrier(2);
    try (var pool = Executors.newFixedThreadPool(2)) {
      var a =
          pool.submit(
              () -> {
                barrier.await();
                return production.start(UUID.randomUUID(), actor, "custom", 1).status();
              });
      var b =
          pool.submit(
              () -> {
                barrier.await();
                return other.start(UUID.randomUUID(), actor, "custom", 1).status();
              });
      var outcomes = List.of(a.get(10, TimeUnit.SECONDS), b.get(10, TimeUnit.SECONDS));
      assertThat(outcomes.stream().filter(STARTED::equals).count()).isEqualTo(1);
      assertThat(outcomes).allMatch(v -> Set.of(STARTED, CAPACITY_REACHED, UNKNOWN).contains(v));
    }
    restart();
    production = configured(() -> catalog);
    assets(298, 100, 0);
    assertThat(production.capacity(actor).orElseThrow().runningRuns()).isEqualTo(1);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 1).status())
        .isEqualTo(CAPACITY_REACHED);
  }

  @Test
  void failedStartConsumesNoCapacityAndLostAcknowledgementKeepsTheSlot() throws Exception {
    var catalog =
        NationProductionCatalog.parse(
            NationProductionCatalogTest.valid()
                .replace("\"max-running-runs\":2", "\"max-running-runs\":1"));
    production = configured(() -> catalog);
    sql(
        "CREATE TRIGGER reject_catalog BEFORE INSERT ON starcore_nation_production_events BEGIN"
            + " SELECT RAISE(ABORT,'injected'); END");
    UUID id = UUID.randomUUID();
    assertThat(production.start(id, actor, "custom", 1).status()).isEqualTo(UNKNOWN);
    assertThat(production.capacity(actor).orElseThrow().runningRuns()).isZero();
    assets(300, 100, 0);
    sql("DROP TRIGGER reject_catalog");
    loseAck.set(true);
    assertThat(production.start(id, actor, "custom", 1).status()).isEqualTo(UNKNOWN);
    assertThat(production.start(id, actor, "custom", 1).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(production.start(UUID.randomUUID(), actor, "custom", 1).status())
        .isEqualTo(CAPACITY_REACHED);
    restart();
    production = configured(() -> catalog);
    assertThat(production.capacity(actor).orElseThrow().runningRuns()).isEqualTo(1);
    assets(298, 100, 0);
  }

  private static Object invoke(java.lang.reflect.Method method, Object target, Object[] args)
      throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException failure) {
      throw failure.getCause();
    }
  }
}
