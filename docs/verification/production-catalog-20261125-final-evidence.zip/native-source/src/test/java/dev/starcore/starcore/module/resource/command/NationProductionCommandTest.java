package dev.starcore.starcore.module.resource.command;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.module.resource.NationProductionService;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class NationProductionCommandTest {
  private final NationProductionService service = mock(NationProductionService.class);
  private final NationProductionCommand executor = new NationProductionCommand(service);
  private final Player player = mock(Player.class);
  private final UUID actor = UUID.randomUUID();

  private void authorized() {
    when(player.hasPermission("starcore.nationproduction.use")).thenReturn(true);
    when(player.getUniqueId()).thenReturn(actor);
  }

  private void run(CommandSender sender, String... args) {
    executor.onCommand(sender, mock(Command.class), "nationproduction", args);
  }

  @Test
  void consoleAndMissingPermissionNeverReachProduction() {
    run(mock(CommandSender.class), "list");
    run(player, "start", "industrial_refining", "2");
    verifyNoInteractions(service);
  }

  @Test
  void retryUsesTheSameRunIdAndExecutingPlayer() {
    authorized();
    UUID id = UUID.randomUUID();
    when(service.start(id, actor, "industrial_refining", 2))
        .thenReturn(new NationProductionService.Result(NationProductionService.Status.STARTED, id));
    when(service.run(id, actor)).thenReturn(Optional.empty());
    run(player, "start", "industrial_refining", "2", id.toString());
    verify(service).start(id, actor, "industrial_refining", 2);
  }

  @Test
  void collectionAndCancellationUseTheExecutingPlayer() {
    authorized();
    UUID id = UUID.randomUUID();
    when(service.complete(id, actor))
        .thenReturn(
            new NationProductionService.Result(NationProductionService.Status.NOT_READY, id));
    when(service.cancel(id, actor))
        .thenReturn(new NationProductionService.Result(NationProductionService.Status.APPLIED, id));
    run(player, "complete", id.toString());
    run(player, "cancel", id.toString());
    verify(service).complete(id, actor);
    verify(service).cancel(id, actor);
  }

  @ParameterizedTest
  @ValueSource(strings = {"0", "-1", "1001", "1.5", "1e9", "999999999999999999999"})
  void invalidBatchCountsDoNotReachMutation(String count) {
    authorized();
    run(player, "start", "industrial_refining", count);
    verifyNoInteractions(service);
  }

  @Test
  void adminReloadChecksPermissionAndValidationDoesNotPublish(
      @org.junit.jupiter.api.io.TempDir java.nio.file.Path directory) throws Exception {
    var file = directory.resolve("catalog.json");
    try (var input = getClass().getResourceAsStream("/nation-production.json")) {
      java.nio.file.Files.copy(input, file);
    }
    var config =
        new dev.starcore.starcore.module.resource.NationProductionConfiguration(file, () -> true);
    config.initialize(java.util.logging.Logger.getAnonymousLogger());
    var command = new NationProductionCommand(service, config);
    CommandSender console = mock(CommandSender.class);
    command.onCommand(console, mock(Command.class), "nationproduction", new String[] {"reload"});
    verify(console).sendMessage(contains("没有生产配置管理权限"));
    var before = config.get();
    when(console.hasPermission("starcore.nationproduction.admin")).thenReturn(true);
    java.nio.file.Files.writeString(
        file,
        java.nio.file.Files.readString(file).replace("\"enabled\": true", "\"enabled\": false"));
    command.onCommand(console, mock(Command.class), "nationproduction", new String[] {"validate"});
    org.assertj.core.api.Assertions.assertThat(config.get()).isSameAs(before);
    command.onCommand(console, mock(Command.class), "nationproduction", new String[] {"reload"});
    org.assertj.core.api.Assertions.assertThat(config.get().enabled()).isFalse();
    verifyNoInteractions(service);
  }

  @Test
  void capacityUsesExecutingPlayerAndDoesNotMutate() {
    authorized();
    when(service.capacity(actor))
        .thenReturn(Optional.of(new NationProductionService.Capacity(true, 2, 3, 4, 5)));
    run(player, "capacity");
    verify(service).capacity(actor);
    verify(player).sendMessage(contains("运行 2/4 个生产，占用 3/5 批"));
    verifyNoMoreInteractions(service);
  }
}
