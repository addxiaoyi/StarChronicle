package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;

import java.nio.file.*;
import java.util.*;
import java.util.logging.Logger;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class NationProductionCatalogTest {
  @TempDir Path directory;

  static String valid() {
    return
    """
    {"format":1,"enabled":true,"limits":{"max-running-runs":2,"max-running-batches":3},
     "recipes":[{"id":"custom","name":"自定义","inputs":{"mineral":2},"outputs":{"industrial":1},
     "seconds-per-batch":1,"max-batches":3}]}
    """;
  }

  @Test
  void bundledDefaultsPreserveExistingProductionTerms() {
    var defaults = NationProductionCatalog.defaults();
    assertThat(defaults.entries()).hasSize(3);
    var recipe = defaults.entry("industrial_refining").orElseThrow().recipe();
    assertThat(recipe.inputs())
        .containsExactlyInAnyOrderEntriesOf(Map.of("mineral", 3L, "energy", 1L));
    assertThat(recipe.outputs()).containsExactlyEntriesOf(Map.of("industrial", 2L));
    assertThat(recipe.secondsPerBatch()).isEqualTo(30);
    assertThatThrownBy(() -> defaults.entries().clear())
        .isInstanceOf(UnsupportedOperationException.class);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"0", "-1", "1.5", "1e2", "\"2\"", "true", "null", "9999999999999999999", "01"})
  void rejectsNonExactResourceQuantities(String number) {
    assertThatThrownBy(
            () ->
                NationProductionCatalog.parse(
                    valid().replace("\"mineral\":2", "\"mineral\":" + number)))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "{\"format\":1,\"format\":1}",
        "{\"format\":1,}",
        "// comment\n{}",
        "{}{}",
        "null",
        "[]"
      })
  void rejectsInvalidOrDuplicateJson(String json) {
    assertThatThrownBy(() -> NationProductionCatalog.parse(json))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void rejectsNestedDuplicatesUnknownFieldsAndResources() {
    for (String json :
        List.of(
            valid().replace("\"mineral\":2", "\"mineral\":2,\"mineral\":3"),
            valid().replace("\"format\":1", "\"format\":1,\"typo\":1"),
            valid().replace("mineral", "unknown"),
            valid().replace("\"max-batches\":3", "\"max-batches\":1001"),
            valid().replace("\"mineral\":2", "\"mineral\":100000000"),
            valid().replace("\"seconds-per-batch\":1", "\"seconds-per-batch\":86401"),
            valid().replace("自定义", "§cInjected"),
            valid().replace("\"enabled\":true", "\"enabled\":\"true\"")))
      assertThatThrownBy(() -> NationProductionCatalog.parse(json))
          .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void rejectsDuplicateRecipeIdsAndEmptyEnabledCatalog() {
    var json = com.google.gson.JsonParser.parseString(valid()).getAsJsonObject();
    json.getAsJsonArray("recipes").add(json.getAsJsonArray("recipes").get(0).deepCopy());
    assertThatThrownBy(() -> NationProductionCatalog.parse(json.toString()))
        .isInstanceOf(IllegalArgumentException.class);
    json.add("recipes", new com.google.gson.JsonArray());
    assertThatThrownBy(() -> NationProductionCatalog.parse(json.toString()))
        .isInstanceOf(IllegalArgumentException.class);
    json.addProperty("enabled", false);
    assertThat(NationProductionCatalog.parse(json.toString()).enabled()).isFalse();
  }

  @Test
  void validateDoesNotPublishAndInvalidReloadRetainsExactPriorCatalog() throws Exception {
    var path = directory.resolve("catalog.json");
    Files.writeString(path, valid());
    var config = new NationProductionConfiguration(path, () -> true);
    config.initialize(Logger.getAnonymousLogger());
    var original = config.get();
    String changed = valid().replace("\"industrial\":1", "\"industrial\":2");
    Files.writeString(path, changed);
    assertThat(config.validate().entry("custom").orElseThrow().recipe().outputs())
        .containsEntry("industrial", 2L);
    assertThat(config.get()).isSameAs(original);
    assertThat(Files.readString(path)).isEqualTo(changed);
    config.reload();
    var updated = config.get();
    assertThat(updated.digest()).isNotEqualTo(original.digest());
    Files.writeString(path, "{\"format\":1,\"format\":2}");
    assertThatThrownBy(config::reload).isInstanceOf(IllegalArgumentException.class);
    assertThat(config.get()).isSameAs(updated);
  }

  @Test
  void absentFileInstallsDefaultsButInvalidFileNeverFallsBackToEnabledDefaults() throws Exception {
    var path = directory.resolve("catalog.json");
    var config = new NationProductionConfiguration(path, () -> true);
    config.initialize(Logger.getAnonymousLogger());
    assertThat(path).exists();
    assertThat(config.get().enabled()).isTrue();
    Files.writeString(path, "{}");
    config = new NationProductionConfiguration(path, () -> true);
    config.initialize(Logger.getAnonymousLogger());
    assertThat(config.get().enabled()).isFalse();
    assertThat(config.get().entries()).isEmpty();
    assertThat(Files.readString(path)).isEqualTo("{}");
  }

  @Test
  void refusesWrongThreadOversizedMalformedUtf8AndSymlink() throws Exception {
    var path = directory.resolve("catalog.json");
    Files.writeString(path, valid());
    var config = new NationProductionConfiguration(path, () -> false);
    config.initialize(Logger.getAnonymousLogger());
    var initial = config.get();
    assertThatThrownBy(config::reload).isInstanceOf(IllegalStateException.class);
    assertThat(config.get()).isSameAs(initial);
    Files.writeString(path, " ".repeat(65537));
    assertThatThrownBy(config::validate).isInstanceOf(java.io.IOException.class);
    Files.write(path, new byte[] {(byte) 0xc3, (byte) 0x28});
    assertThatThrownBy(config::validate).isInstanceOf(java.io.IOException.class);
    var target = directory.resolve("target.json");
    Files.writeString(target, valid());
    Files.delete(path);
    Files.createSymbolicLink(path, target);
    assertThatThrownBy(config::validate).isInstanceOf(java.io.IOException.class);
  }
}
