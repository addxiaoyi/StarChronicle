package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.BooleanSupplier;

/** All asset writes hold the resource lock; SQL revisions exclude stale writers. */
public final class SimpleNationProductionService implements NationProductionService {
  private final ResourceModule resources;
  private final ResourceStateStorage storage;
  private final NationService nations;
  private final Clock clock;
  private final BooleanSupplier ownerThread;
  private static final NationProductionCatalog DEFAULT_CATALOG = NationProductionCatalog.defaults();
  private final java.util.function.Supplier<NationProductionCatalog> catalog;

  SimpleNationProductionService(
      ResourceModule resources,
      ResourceStateStorage storage,
      NationService nations,
      Clock clock,
      BooleanSupplier ownerThread) {
    this(resources, storage, nations, clock, ownerThread, () -> DEFAULT_CATALOG);
  }

  SimpleNationProductionService(
      ResourceModule resources,
      ResourceStateStorage storage,
      NationService nations,
      Clock clock,
      BooleanSupplier ownerThread,
      java.util.function.Supplier<NationProductionCatalog> catalog) {
    this.catalog = Objects.requireNonNull(catalog);
    this.resources = resources;
    this.storage = storage;
    this.nations = nations;
    this.clock = clock;
    this.ownerThread = ownerThread;
  }

  @Override
  public List<Recipe> recipes() {
    return catalog.get().entries().stream().map(NationProductionCatalog.Entry::recipe).toList();
  }

  @Override
  public int maxBatches(String recipeId) {
    return catalog.get().entry(recipeId).map(NationProductionCatalog.Entry::maxBatches).orElse(0);
  }

  @Override
  public Optional<Capacity> capacity(UUID actor) {
    synchronized (resources) {
      Nation nation = founder(actor);
      if (nation == null) return Optional.empty();
      long running = 0, batches = 0;
      for (var view : state().map(h -> h.runs().values()).orElse(List.of())) {
        if (view.state() == State.RUNNING && view.run().nationId().equals(nation.id())) {
          running++;
          batches = Math.addExact(batches, view.run().batches());
        }
      }
      var current = catalog.get();
      return Optional.of(
          new Capacity(
              current.enabled(),
              running,
              batches,
              current.limits().maxRunningRuns(),
              current.limits().maxRunningBatches()));
    }
  }

  @Override
  public Result start(UUID id, UUID actor, String recipeId, long batches) {
    Objects.requireNonNull(id);
    synchronized (resources) {
      if (!available()) return result(Status.UNAVAILABLE, id);
      try {
        var prior = state().map(h -> h.runs().get(id)).orElse(null);
        if (prior != null) {
          Run old = prior.run();
          return result(
              old.actorId().equals(actor)
                      && old.recipeId().equals(recipeId)
                      && old.batches() == batches
                  ? Status.ALREADY_APPLIED
                  : Status.REJECTED,
              id);
        }
        Nation nation = founder(actor);
        var current = catalog.get();
        if (!current.enabled()) return result(Status.STARTS_DISABLED, id);
        var entry = current.entry(recipeId).orElse(null);
        if (nation == null || entry == null || batches < 1 || batches > entry.maxBatches())
          return result(Status.REJECTED, id);
        if (!current
            .limits()
            .permits(state().map(h -> h.runs().values()).orElse(List.of()), nation.id(), batches))
          return result(Status.CAPACITY_REACHED, id);
        var recipe = entry.recipe();
        Instant now = now();
        Run run =
            new Run(
                id,
                actor,
                nation.id(),
                UUID.fromString(resources.authorityDomainId()),
                recipeId,
                batches,
                scaled(recipe.inputs(), batches),
                scaled(recipe.outputs(), batches),
                now,
                now.plusSeconds(Math.multiplyExact(recipe.secondsPerBatch(), batches)));
        return save(
            run, State.RUNNING, run.inputs(), Map.of(), now, Status.STARTED, current.limits());
      } catch (IllegalArgumentException | ArithmeticException invalid) {
        return result(Status.REJECTED, id);
      } catch (RuntimeException uncertain) {
        resources.reconcileTradeState();
        return result(Status.UNKNOWN, id);
      }
    }
  }

  @Override
  public Result complete(UUID id, UUID actor) {
    return finish(id, actor, State.COMPLETED);
  }

  @Override
  public Result cancel(UUID id, UUID actor) {
    return finish(id, actor, State.CANCELLED);
  }

  private Result finish(UUID id, UUID actor, State target) {
    Objects.requireNonNull(id);
    synchronized (resources) {
      if (!available()) return result(Status.UNAVAILABLE, id);
      try {
        var view = state().map(h -> h.runs().get(id)).orElse(null);
        if (view == null) return result(Status.REJECTED, id);
        Run run = view.run();
        Nation nation = founder(actor);
        boolean authorized = nation != null && nation.id().equals(run.nationId());
        // Read-only replay can be reconciled by the original initiator after a succession.
        if (view.state() == target && (authorized || run.actorId().equals(actor)))
          return result(Status.ALREADY_APPLIED, id);
        if (!authorized
            || view.state() != State.RUNNING
            || !run.resourceDomain().toString().equals(resources.authorityDomainId()))
          return result(Status.REJECTED, id);
        Instant now = now();
        if (now.isBefore(run.startedAt())) return result(Status.UNAVAILABLE, id);
        if (target == State.COMPLETED && now.isBefore(run.readyAt()))
          return result(Status.NOT_READY, id);
        return save(
            run,
            target,
            Map.of(),
            target == State.COMPLETED ? run.outputs() : run.inputs(),
            now,
            Status.APPLIED,
            null);
      } catch (RuntimeException uncertain) {
        resources.reconcileTradeState();
        return result(Status.UNKNOWN, id);
      }
    }
  }

  private Result save(
      Run run,
      State target,
      Map<String, Long> debits,
      Map<String, Long> credits,
      Instant changed,
      Status success,
      NationProductionCatalog.Limits limits) {
    var snapshot = resources.prepareProductionSnapshot(run.nationId(), debits, credits);
    if (snapshot == null) return result(Status.INSUFFICIENT_ASSETS, run.runId());
    storage.saveProduction(snapshot, run, target, changed, limits);
    resources.publishTradeSnapshot(snapshot);
    return result(success, run.runId());
  }

  private boolean available() {
    return ownerThread.getAsBoolean()
        && storage != null
        && storage.supportsNationProduction()
        && !resources.authorityDomainId().isBlank();
  }

  private Optional<SqlNationProductionJournal.Head> state() {
    return storage.productionState();
  }

  private Nation founder(UUID actor) {
    if (actor == null || nations == null) return null;
    Nation nation = nations.nationOf(actor).orElse(null);
    return nation != null && nation.hasMember(actor) && nation.isFounder(actor) ? nation : null;
  }

  private boolean visible(Run run, UUID actor) {
    Nation nation = founder(actor);
    return run.actorId().equals(actor) || nation != null && nation.id().equals(run.nationId());
  }

  private Instant now() {
    return clock.instant().truncatedTo(ChronoUnit.MILLIS);
  }

  private static Result result(Status status, UUID id) {
    return new Result(status, id);
  }

  private static Map<String, Long> scaled(Map<String, Long> source, long batches) {
    var result = new TreeMap<String, Long>();
    source.forEach((key, value) -> result.put(key, Math.multiplyExact(value, batches)));
    return result;
  }

  @Override
  public Optional<RunView> run(UUID id, UUID viewer) {
    synchronized (resources) {
      return state().map(h -> h.runs().get(id)).filter(v -> visible(v.run(), viewer));
    }
  }

  @Override
  public List<RunView> runs(UUID viewer, int limit) {
    if (limit < 1 || limit > 100)
      throw new IllegalArgumentException("Production limit must be 1..100");
    synchronized (resources) {
      return state()
          .map(
              h ->
                  h.runs().values().stream()
                      .filter(v -> visible(v.run(), viewer))
                      .sorted(
                          Comparator.comparing((RunView v) -> v.run().startedAt())
                              .reversed()
                              .thenComparing(v -> v.run().runId()))
                      .limit(limit)
                      .toList())
          .orElse(List.of());
    }
  }

  @Override
  public Optional<UUID> completionAuthorityDomain() {
    synchronized (resources) {
      return state().map(SqlNationProductionJournal.Head::domain);
    }
  }

  @Override
  public List<CompletionReceipt> completionsAfter(UUID domain, long after, int limit) {
    Objects.requireNonNull(domain);
    if (after < 0 || limit < 1 || limit > 100)
      throw new IllegalArgumentException("Invalid production page");
    synchronized (resources) {
      var head = state().orElseThrow();
      if (!head.domain().equals(domain) || after > head.completed())
        throw new IllegalStateException("Production authority/cursor changed");
      return head.receipts().stream().filter(r -> r.sequence() > after).limit(limit).toList();
    }
  }
}
