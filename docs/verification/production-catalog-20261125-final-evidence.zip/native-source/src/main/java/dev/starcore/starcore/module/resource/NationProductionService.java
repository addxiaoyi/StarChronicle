package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.time.Instant;
import java.util.*;

/** Durable national inventory production. Each run freezes its initiator and exact recipe. */
public interface NationProductionService {
  enum State {
    RUNNING,
    COMPLETED,
    CANCELLED
  }

  enum Status {
    STARTED,
    APPLIED,
    ALREADY_APPLIED,
    NOT_READY,
    STARTS_DISABLED,
    CAPACITY_REACHED,
    REJECTED,
    INSUFFICIENT_ASSETS,
    UNAVAILABLE,
    UNKNOWN
  }

  record Result(Status status, UUID runId) {}

  record Recipe(
      String recipeId,
      String name,
      Map<String, Long> inputs,
      Map<String, Long> outputs,
      long secondsPerBatch) {
    public Recipe {
      if (recipeId == null
          || !recipeId.matches("[a-z0-9_.:-]{1,64}")
          || name == null
          || name.isBlank()
          || name.length() > 80
          || secondsPerBatch < 1
          || secondsPerBatch > 86400)
        throw new IllegalArgumentException("Invalid production recipe");
      inputs = quantities(inputs);
      outputs = quantities(outputs);
    }
  }

  record Run(
      UUID runId,
      UUID actorId,
      NationId nationId,
      UUID resourceDomain,
      String recipeId,
      long batches,
      Map<String, Long> inputs,
      Map<String, Long> outputs,
      Instant startedAt,
      Instant readyAt) {
    public Run {
      Objects.requireNonNull(runId);
      Objects.requireNonNull(actorId);
      Objects.requireNonNull(nationId);
      Objects.requireNonNull(resourceDomain);
      if (recipeId == null
          || !recipeId.matches("[a-z0-9_.:-]{1,64}")
          || batches < 1
          || batches > 1000) throw new IllegalArgumentException("Invalid production run");
      inputs = quantities(inputs);
      outputs = quantities(outputs);
      timestamp(startedAt);
      timestamp(readyAt);
      if (!readyAt.isAfter(startedAt) || readyAt.isAfter(startedAt.plusSeconds(86_400_000L)))
        throw new IllegalArgumentException("Invalid production duration");
    }
  }

  record RunView(Run run, State state, Instant changedAt) {
    public RunView {
      Objects.requireNonNull(run);
      Objects.requireNonNull(state);
      timestamp(changedAt);
      if (changedAt.isBefore(run.startedAt())
          || (state == State.RUNNING && !changedAt.equals(run.startedAt()))
          || (state == State.COMPLETED && changedAt.isBefore(run.readyAt())))
        throw new IllegalArgumentException("Invalid production transition time");
    }
  }

  record CompletionReceipt(UUID authorityDomain, long sequence, Run run, Instant committedAt) {
    public CompletionReceipt {
      Objects.requireNonNull(authorityDomain);
      if (sequence < 1)
        throw new IllegalArgumentException("Invalid production completion sequence");
      new RunView(run, State.COMPLETED, committedAt);
    }
  }

  record Capacity(
      boolean startsEnabled,
      long runningRuns,
      long runningBatches,
      int maxRunningRuns,
      long maxRunningBatches) {}

  List<Recipe> recipes();

  default int maxBatches(String recipeId) {
    return 1000;
  }

  default Optional<Capacity> capacity(UUID actorId) {
    return Optional.empty();
  }

  Result start(UUID runId, UUID actorId, String recipeId, long batches);

  Result complete(UUID runId, UUID actorId);

  Result cancel(UUID runId, UUID actorId);

  Optional<RunView> run(UUID runId, UUID viewer);

  List<RunView> runs(UUID viewer, int limit);

  Optional<UUID> completionAuthorityDomain();

  List<CompletionReceipt> completionsAfter(UUID domain, long after, int limit);

  static Map<String, Long> quantities(Map<String, Long> values) {
    Objects.requireNonNull(values);
    if (values.isEmpty() || values.size() > 7)
      throw new IllegalArgumentException("Invalid resource map");
    var result = new TreeMap<String, Long>();
    values.forEach(
        (key, amount) -> {
          if (key == null
              || !Set.of(
                      "mineral",
                      "agricultural",
                      "energy",
                      "luxury",
                      "industrial",
                      "chemical",
                      "strategic")
                  .contains(key)
              || amount == null
              || amount < 1
              || amount > 100_000_000L)
            throw new IllegalArgumentException("Invalid production quantity");
          result.put(key, amount);
        });
    return Collections.unmodifiableMap(result);
  }

  static void timestamp(Instant time) {
    Objects.requireNonNull(time);
    if (time.toEpochMilli() < 0 || !Instant.ofEpochMilli(time.toEpochMilli()).equals(time))
      throw new IllegalArgumentException("Production time must use persisted milliseconds");
  }
}
