package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.logging.Logger;

final class DatabaseAwareResourceStateStorage implements ResourceStateStorage {
  private final ResourceStateStorage fileStorage;
  private final ResourceStateStorage sqlStorage;
  private final boolean sqlPreferred;
  private final java.nio.file.Path sqlMarker;

  DatabaseAwareResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    Objects.requireNonNull(databaseService, "databaseService");
    this.fileStorage = new PersistenceResourceStateStorage(namespace, persistenceService);
    try {
      this.sqlMarker =
          persistenceService.namespacePath(namespace).resolve("resource-sql-authority");
    } catch (java.io.IOException error) {
      throw new IllegalStateException("Cannot locate resource SQL authority marker", error);
    }
    boolean alreadyPinned = java.nio.file.Files.exists(sqlMarker);
    this.sqlStorage =
        new SqlResourceStateStorage(
            namespace, databaseService, persistenceService, logger, !alreadyPinned);
    this.sqlPreferred = databaseService.isRunning() || alreadyPinned;
  }

  @Override
  public Properties load() {
    return activeStorage().load();
  }

  @Override
  public void save(Properties properties) {
    activeStorage().save(properties);
  }

  @Override
  public boolean supportsNationProduction() {
    return activeStorage().supportsNationProduction();
  }

  @Override
  public Optional<SqlNationProductionJournal.Head> productionState() {
    return activeStorage().productionState();
  }

  @Override
  public void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt) {
    activeStorage().saveProduction(properties, run, state, changedAt);
  }

  @Override
  public void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt,
      NationProductionCatalog.Limits limits) {
    activeStorage().saveProduction(properties, run, state, changedAt, limits);
  }

  @Override
  public boolean supportsNationTrade() {
    return activeStorage().supportsNationTrade();
  }

  @Override
  public Optional<javax.sql.DataSource> tradeDataSource() {
    return activeStorage().tradeDataSource();
  }

  @Override
  public void saveTradeOffer(NationTradeService.Offer offer) {
    activeStorage().saveTradeOffer(offer);
  }

  @Override
  public void cancelTradeOffer(NationTradeService.Offer offer) {
    activeStorage().cancelTradeOffer(offer);
  }

  @Override
  public Optional<NationTradeService.OfferView> tradeOffer(java.util.UUID id) {
    return activeStorage().tradeOffer(id);
  }

  @Override
  public List<NationTradeService.OfferView> tradeOffers(java.util.UUID player, int limit) {
    return activeStorage().tradeOffers(player, limit);
  }

  @Override
  public Optional<SqlNationTradeJournal.Head> tradeHead() {
    return activeStorage().tradeHead();
  }

  @Override
  public Optional<NationTradeService.SettlementReceipt> tradeSettlement(java.util.UUID id) {
    return activeStorage().tradeSettlement(id);
  }

  @Override
  public List<NationTradeService.SettlementReceipt> tradeSettlementsAfter(
      java.util.UUID domain, long after, int limit) {
    return activeStorage().tradeSettlementsAfter(domain, after, limit);
  }

  @Override
  public void saveTrade(
      Properties properties,
      NationResourceTransactionService.TransferReceipt resourceReceipt,
      NationTradeService.SettlementReceipt settlement,
      javax.sql.DataSource fundingSource,
      dev.starcore.starcore.core.storage.SqlCoordinatedWrite.Commit fundingCommit) {
    activeStorage()
        .saveTrade(properties, resourceReceipt, settlement, fundingSource, fundingCommit);
  }

  @Override
  public void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    activeStorage().saveTransfer(properties, receipt);
  }

  @Override
  public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    return activeStorage().transferReceipt(id);
  }

  @Override
  public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    return activeStorage().transferReceiptsAfter(sequence, limit);
  }

  @Override
  public long latestTransferSequence() {
    return activeStorage().latestTransferSequence();
  }

  @Override
  public Optional<java.util.UUID> transferHistoryAuthorityDomainId() {
    return activeStorage().transferHistoryAuthorityDomainId();
  }

  @Override
  public int transferReceiptCount() {
    return activeStorage().transferReceiptCount();
  }

  @Override
  public void saveAsync(Properties properties) {
    activeStorage().saveAsync(properties);
  }

  private ResourceStateStorage activeStorage() {
    if (sqlPreferred) {
      try {
        if (!java.nio.file.Files.exists(sqlMarker)) {
          dev.starcore.starcore.core.persistence.AtomicFilePersistence.replace(
              sqlMarker, temp -> java.nio.file.Files.writeString(temp, "SQL"));
        } else if (!java.nio.file.Files.readString(sqlMarker).equals("SQL")) {
          throw new IllegalStateException("Invalid resource SQL authority marker");
        }
      } catch (java.io.IOException error) {
        throw new IllegalStateException("Cannot pin resource SQL authority", error);
      }
      return sqlStorage;
    }
    return fileStorage;
  }
}
