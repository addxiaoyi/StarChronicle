package dev.starcore.starcore.module.resource;

import java.util.List;
import java.util.Optional;
import java.util.Properties;

interface ResourceStateStorage {
  Properties load();

  void save(Properties properties);

  default boolean supportsNationProduction() {
    return false;
  }

  default Optional<SqlNationProductionJournal.Head> productionState() {
    return Optional.empty();
  }

  default void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt) {
    throw new UnsupportedOperationException();
  }

  default void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt,
      NationProductionCatalog.Limits limits) {
    throw new UnsupportedOperationException(
        "Storage must enforce production admission in its transaction");
  }

  default boolean supportsNationTrade() {
    return false;
  }

  default Optional<javax.sql.DataSource> tradeDataSource() {
    return Optional.empty();
  }

  default void saveTradeOffer(NationTradeService.Offer offer) {
    throw new UnsupportedOperationException();
  }

  default void cancelTradeOffer(NationTradeService.Offer offer) {
    throw new UnsupportedOperationException();
  }

  default Optional<NationTradeService.OfferView> tradeOffer(java.util.UUID id) {
    return Optional.empty();
  }

  default List<NationTradeService.OfferView> tradeOffers(java.util.UUID player, int limit) {
    return List.of();
  }

  default Optional<SqlNationTradeJournal.Head> tradeHead() {
    return Optional.empty();
  }

  default Optional<NationTradeService.SettlementReceipt> tradeSettlement(java.util.UUID id) {
    return Optional.empty();
  }

  default List<NationTradeService.SettlementReceipt> tradeSettlementsAfter(
      java.util.UUID domain, long after, int limit) {
    throw new UnsupportedOperationException();
  }

  default void saveTrade(
      Properties properties,
      NationResourceTransactionService.TransferReceipt resourceReceipt,
      NationTradeService.SettlementReceipt settlement,
      javax.sql.DataSource fundingSource,
      dev.starcore.starcore.core.storage.SqlCoordinatedWrite.Commit fundingCommit) {
    throw new UnsupportedOperationException();
  }

  default void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    save(ResourceTransferReceiptStore.transferSnapshot(properties, load(), receipt));
  }

  default Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    Properties properties = load();
    ResourceTransferReceiptStore.latestSequence(properties);
    return ResourceTransferReceiptStore.find(properties, id);
  }

  default List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    return ResourceTransferReceiptStore.after(load(), sequence, limit);
  }

  default long latestTransferSequence() {
    return ResourceTransferReceiptStore.latestSequence(load());
  }

  default Optional<java.util.UUID> transferHistoryAuthorityDomainId() {
    Properties properties = load();
    ResourceTransferReceiptStore.latestSequence(properties);
    String domain = properties.getProperty("resource.authority-domain");
    if (domain == null) return Optional.empty();
    java.util.UUID parsed = java.util.UUID.fromString(domain);
    if (!parsed.toString().equals(domain))
      throw new IllegalStateException("Invalid resource history domain");
    return Optional.of(parsed);
  }

  default int transferReceiptCount() {
    return ResourceTransferReceiptStore.count(load());
  }

  default void saveAsync(Properties properties) {
    save(properties);
  }
}
