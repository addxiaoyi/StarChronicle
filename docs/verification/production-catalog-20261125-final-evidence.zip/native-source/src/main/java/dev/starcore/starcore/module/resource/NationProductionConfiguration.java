package dev.starcore.starcore.module.resource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import java.util.logging.Logger;

/** File validation is read-only; reload publishes a completely validated snapshot in one step. */
public final class NationProductionConfiguration implements Supplier<NationProductionCatalog> {
  private final Path file;
  private final BooleanSupplier ownerThread;
  private volatile NationProductionCatalog current = NationProductionCatalog.unavailable();

  public NationProductionConfiguration(Path file, BooleanSupplier ownerThread) {
    this.file = Objects.requireNonNull(file);
    this.ownerThread = Objects.requireNonNull(ownerThread);
  }

  public void initialize(Logger logger) {
    try {
      if (!Files.exists(file, LinkOption.NOFOLLOW_LINKS)) {
        Files.createDirectories(file.toAbsolutePath().getParent());
        try (var stream = getClass().getResourceAsStream("/nation-production.json")) {
          if (stream == null) throw new IOException("Missing default catalog");
          Files.copy(stream, file);
        }
      }
      // Initialization can occur before the plugin's scheduler is running.
      current = validate();
    } catch (IOException | RuntimeException error) {
      current = NationProductionCatalog.unavailable();
      logger.severe(
          "Nation production catalog invalid; new starts disabled; existing runs remain"
              + " recoverable: "
              + error.getMessage());
    }
  }

  public NationProductionCatalog validate() throws IOException {
    if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) || Files.size(file) > 65536)
      throw new IOException("Require a regular production catalog of at most 64 KiB");
    byte[] raw;
    try (var input = Files.newInputStream(file)) {
      raw = input.readNBytes(65537);
    }
    if (raw.length > 65536) throw new IOException("Production catalog grew beyond 64 KiB");
    String text =
        StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(raw)).toString();
    return NationProductionCatalog.parse(text);
  }

  public NationProductionCatalog reload() throws IOException {
    if (!ownerThread.getAsBoolean())
      throw new IllegalStateException("Production reload requires the Paper owner thread");
    NationProductionCatalog next = validate();
    current = next;
    return next;
  }

  @Override
  public NationProductionCatalog get() {
    return current;
  }
}
