package dev.starcore.starcore.module.resource.command;

import dev.starcore.starcore.module.resource.NationProductionService;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/** National founders explicitly start, collect or cancel exact production batches. */
public final class NationProductionCommand implements CommandExecutor, TabCompleter {
  private final NationProductionService service;
  private final dev.starcore.starcore.module.resource.NationProductionConfiguration configuration;

  public NationProductionCommand(NationProductionService service) {
    this(service, null);
  }

  public NationProductionCommand(
      NationProductionService service,
      dev.starcore.starcore.module.resource.NationProductionConfiguration configuration) {
    this.service = service;
    this.configuration = configuration;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (args.length > 0
        && (args[0].equalsIgnoreCase("validate") || args[0].equalsIgnoreCase("reload"))) {
      if (!sender.hasPermission("starcore.nationproduction.admin")) {
        sender.sendMessage("§c你没有生产配置管理权限。");
        return true;
      }
      if (args.length != 1 || configuration == null) {
        sender.sendMessage("§c生产配置管理不可用或参数无效。");
        return true;
      }
      try {
        boolean reload = args[0].equalsIgnoreCase("reload");
        var catalog = reload ? configuration.reload() : configuration.validate();
        sender.sendMessage(
            (reload ? "§a生产配置已生效" : "§a生产配置校验通过，尚未改变运行配置")
                + "；配方数 "
                + catalog.entries().size()
                + "；允许开工 "
                + catalog.enabled()
                + "；每国同时运行 "
                + catalog.limits().maxRunningRuns()
                + " 个生产、共 "
                + catalog.limits().maxRunningBatches()
                + " 批。");
      } catch (java.io.IOException | RuntimeException invalid) {
        sender.sendMessage("§c生产配置校验失败，当前运行配置保持不变：" + invalid.getMessage());
      }
      return true;
    }
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用国家生产。");
      return true;
    }
    if (!player.hasPermission("starcore.nationproduction.use")) {
      player.sendMessage("§c你没有国家生产命令权限。");
      return true;
    }
    if (args.length == 0) {
      help(player);
      return true;
    }
    UUID id = null;
    try {
      switch (args[0].toLowerCase(Locale.ROOT)) {
        case "recipes" -> {
          if (args.length != 1) {
            help(player);
            return true;
          }
          for (var recipe : service.recipes()) {
            player.sendMessage("§6" + recipe.recipeId() + " · " + recipe.name());
            player.sendMessage(
                "§7每批消耗: "
                    + recipe.inputs()
                    + " → 产出: "
                    + recipe.outputs()
                    + "；用时"
                    + recipe.secondsPerBatch()
                    + "秒；单次最多"
                    + service.maxBatches(recipe.recipeId())
                    + "批");
          }
        }
        case "start" -> {
          if (args.length != 3 && args.length != 4) {
            help(player);
            return true;
          }
          long batches = Long.parseLong(args[2]);
          if (batches < 1 || batches > 1000) throw new IllegalArgumentException();
          id = args.length == 4 ? uuid(args[3]) : UUID.randomUUID();
          player.sendMessage("§7国家生产ID: " + id);
          result(player, service.start(id, player.getUniqueId(), args[1], batches));
          service.run(id, player.getUniqueId()).ifPresent(view -> show(player, view));
        }
        case "capacity" -> {
          if (args.length != 1) {
            help(player);
            return true;
          }
          var capacity = service.capacity(player.getUniqueId());
          if (capacity.isEmpty()) player.sendMessage("§c需要当前国家创始人身份查看产能。");
          else {
            var c = capacity.orElseThrow();
            player.sendMessage(
                "§6国家产能：运行 "
                    + c.runningRuns()
                    + "/"
                    + c.maxRunningRuns()
                    + " 个生产，占用 "
                    + c.runningBatches()
                    + "/"
                    + c.maxRunningBatches()
                    + " 批；允许新开工 "
                    + c.startsEnabled());
          }
        }
        case "list" -> {
          if (args.length != 1) {
            help(player);
            return true;
          }
          var runs = service.runs(player.getUniqueId(), 20);
          if (runs.isEmpty()) player.sendMessage("§7没有可查看的国家生产批次。");
          runs.forEach(view -> show(player, view));
        }
        case "show", "complete", "cancel" -> {
          if (args.length != 2) {
            help(player);
            return true;
          }
          id = uuid(args[1]);
          switch (args[0].toLowerCase(Locale.ROOT)) {
            case "complete" -> result(player, service.complete(id, player.getUniqueId()));
            case "cancel" -> result(player, service.cancel(id, player.getUniqueId()));
            default -> {
              var view = service.run(id, player.getUniqueId());
              if (view.isPresent()) show(player, view.orElseThrow());
              else player.sendMessage("§c没有可查看的这个批次。");
            }
          }
        }
        default -> help(player);
      }
    } catch (IllegalArgumentException | ArithmeticException invalid) {
      player.sendMessage("§c生产参数无效；批次须为1至1000的整数，请核对配方和批次ID。");
    } catch (RuntimeException unavailable) {
      player.sendMessage("§c暂时无法核对国家生产，请保留原批次ID后查询。" + (id == null ? "" : " ID: " + id));
    }
    return true;
  }

  private static UUID uuid(String value) {
    UUID id = UUID.fromString(value);
    if (!id.toString().equals(value)) throw new IllegalArgumentException();
    return id;
  }

  private static void show(Player player, NationProductionService.RunView view) {
    var run = view.run();
    String state =
        switch (view.state()) {
          case RUNNING -> "待领取";
          case COMPLETED -> "已完成";
          case CANCELLED -> "已取消";
        };
    player.sendMessage(
        "§6国家生产 " + run.runId() + " §7[" + state + "] " + run.recipeId() + " × " + run.batches());
    player.sendMessage(
        "§7已投入: " + run.inputs() + "；成品: " + run.outputs() + "；可领取时间: " + run.readyAt());
    if (view.state() == NationProductionService.State.RUNNING)
      player.sendMessage("§e到期领取: /nationproduction complete " + run.runId() + "；取消将退回已投入原料。");
  }

  private static void result(Player player, NationProductionService.Result result) {
    player.sendMessage(
        switch (result.status()) {
          case STARTED -> "§a生产已开工，原料已从国家库存扣除。";
          case APPLIED -> "§a生产批次已处理，请用 show 查看结果。";
          case ALREADY_APPLIED -> "§7这个请求已处理，没有重复扣除或发放。";
          case NOT_READY -> "§e尚未到领取时间。";
          case STARTS_DISABLED -> "§e当前已暂停新开工，已有批次仍可领取或取消。";
          case CAPACITY_REACHED -> "§e国家同时运行的生产已达上限，请先领取或取消已有批次。";
          case REJECTED -> "§c请求被拒绝，请核对批次状态和当前国家创始人身份。";
          case INSUFFICIENT_ASSETS -> "§c国家库存不足或数量超出上限，批次未改变。";
          case UNAVAILABLE -> "§c国家生产暂不可用。";
          case UNKNOWN -> "§e本次结果尚待核对，请用原批次ID查询或重试同一请求。";
        });
  }

  private static void help(Player p) {
    p.sendMessage("§6国家生产：原料与成品均使用国家库存，由当前创始人操作。");
    p.sendMessage("§e/nationproduction recipes | capacity | list | show <批次ID>");
    p.sendMessage("§e/nationproduction start <配方> <批数> [原批次ID]");
    p.sendMessage("§e/nationproduction complete|cancel <批次ID>");
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    boolean admin = sender.hasPermission("starcore.nationproduction.admin");
    if (!sender.hasPermission("starcore.nationproduction.use") && !admin) return List.of();
    var options =
        args.length == 1
            ? (admin
                ? List.of(
                    "recipes",
                    "capacity",
                    "start",
                    "list",
                    "show",
                    "complete",
                    "cancel",
                    "validate",
                    "reload")
                : List.of("recipes", "capacity", "start", "list", "show", "complete", "cancel"))
            : args.length == 2 && args[0].equalsIgnoreCase("start")
                ? service.recipes().stream().map(NationProductionService.Recipe::recipeId).toList()
                : List.<String>of();
    return args.length == 0
        ? List.of()
        : options.stream()
            .filter(value -> value.startsWith(args[args.length - 1].toLowerCase(Locale.ROOT)))
            .toList();
  }
}
