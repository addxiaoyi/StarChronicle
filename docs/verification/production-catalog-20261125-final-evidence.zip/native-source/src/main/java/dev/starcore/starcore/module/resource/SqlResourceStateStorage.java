package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import javax.sql.DataSource;

final class SqlResourceStateStorage extends AbstractModuleStateStorage
    implements ResourceStateStorage {

  private static final String FILE_NAME = "resources.properties";
  private static final String TABLE_NAME = "starcore_resource_state";
  private static final String TRANSFER_TABLE = "starcore_resource_transfer_receipts";
  private static final String MIGRATION_TABLE = "starcore_resource_state_migrations";
  private static final String RECEIPT_MIGRATION = "resource-transfer-receipts-v1";
  private final boolean allowLegacyImport;
  private volatile long expectedRevision;

  SqlResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    this(namespace, databaseService, persistenceService, logger, true);
  }

  SqlResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger,
      boolean allowLegacyImport) {
    super(namespace, databaseService, persistenceService, logger);
    this.allowLegacyImport = allowLegacyImport;
  }

  // 测试构造函数
  SqlResourceStateStorage(DataSource dataSource, Properties legacyProperties, Logger logger) {
    this("test", mockDatabaseService(dataSource), mockPersistenceService(legacyProperties), logger);
  }

  private static DatabaseService mockDatabaseService(DataSource ds) {
    return new DatabaseService(null, null) {
      @Override
      public synchronized Optional<DataSource> dataSource() {
        return Optional.of(ds);
      }

      @Override
      public synchronized boolean isRunning() {
        return true;
      }
    };
  }

  private static PersistenceService mockPersistenceService(Properties props) {
    return new PersistenceService(null, null) {
      @Override
      public Properties loadProperties(String namespace, String fileName) {
        return props;
      }

      @Override
      public void saveProperties(String namespace, String fileName, Properties properties) {
        // 测试环境：不做实际保存
      }

      @Override
      public CompletableFuture<Void> savePropertiesAsync(
          String namespace, String fileName, Properties properties) {
        return CompletableFuture.completedFuture(null);
      }
    };
  }

  @Override
  public Properties load() {
    var result = new java.util.concurrent.atomic.AtomicReference<Properties>();
    saveWith(new Properties(), ignored -> result.set(loadInitialized()));
    return result.get();
  }

  private Properties loadInitialized() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      if (!allowLegacyImport && loadFromDatabase(connection).isEmpty())
        throw new IllegalStateException("Pinned resource SQL state is missing; restore its backup");
      migrateLegacyTransferReceipts(connection, loadFromProperties());
    } catch (Exception error) {
      throw new IllegalStateException("Unable to migrate legacy resource transfer receipts", error);
    }
    super.load();
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      connection.setAutoCommit(false);
      try {
        SqlResourceTransferJournal.reserveWriter(connection);
        Properties properties = loadFromDatabase(connection);
        SqlResourceTransferJournal.initialize(connection, properties);
        long revision = SqlResourceStateRevision.initialize(connection);
        SqlNationTradeJournal.head(connection);
        SqlNationProductionJournal.read(connection);
        connection.commit();
        expectedRevision = revision;
        return properties;
      } catch (Exception error) {
        connection.rollback();
        throw error;
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to initialize resource transfer history", error);
    }
  }

  @Override
  protected Properties loadFromProperties() {
    return allowLegacyImport ? super.loadFromProperties() : new Properties();
  }

  @Override
  protected void handleSqlWriteFailure(Properties properties, Exception error) {
    throw new IllegalStateException(
        "Resource SQL authority cannot fall back to a file save", error);
  }

  @Override
  protected Properties handleSqlLoadFailure(Exception error) {
    throw new IllegalStateException(
        "Resource SQL authority cannot fall back to a file read", error);
  }

  @Override
  protected String getTableName() {
    return TABLE_NAME;
  }

  @Override
  protected String getFileName() {
    return FILE_NAME;
  }

  @Override
  protected void ensureTable(Connection connection) throws SQLException {
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_state (
              property_key VARCHAR(191) PRIMARY KEY,
              property_value TEXT NOT NULL
          )
          """);
    }
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_transfer_receipts (
              transaction_id VARCHAR(191) PRIMARY KEY,
              authority_domain_id VARCHAR(36) NOT NULL,
              sequence BIGINT NOT NULL UNIQUE,
              payer_nation_id VARCHAR(36) NOT NULL,
              receiver_nation_id VARCHAR(36) NOT NULL,
              resources TEXT NOT NULL,
              category VARCHAR(32) NOT NULL,
              description VARCHAR(200) NOT NULL,
              applied_at BIGINT NOT NULL
          )
          """);
    }
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_state_migrations (
              migration_key VARCHAR(100) PRIMARY KEY,
              completed_at BIGINT NOT NULL
          )
          """);
    }
    SqlResourceTransferJournal.ensureTable(connection);
    SqlResourceStateRevision.ensureTable(connection);
    SqlNationTradeJournal.ensureTables(connection);
    SqlNationProductionJournal.ensureTables(connection);
  }

  private void migrateLegacyTransferReceipts(Connection connection, Properties legacy)
      throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    connection.setAutoCommit(false);
    try {
      SqlResourceTransferJournal.reserveWriter(connection);
      try (PreparedStatement marker =
          connection.prepareStatement(
              "SELECT 1 FROM " + MIGRATION_TABLE + " WHERE migration_key=?")) {
        marker.setString(1, RECEIPT_MIGRATION);
        try (ResultSet result = marker.executeQuery()) {
          if (result.next()) {
            connection.commit();
            return;
          }
        }
      }

      Properties database = loadFromDatabase(connection);
      long latest = ResourceTransferReceiptStore.latestSequence(legacy);
      if (database.isEmpty() && !legacy.isEmpty()) {
        // Import stockpiles and domain before the receipt batch, under this same transaction.
        writeProperties(connection, legacy);
        database = loadFromDatabase(connection);
      }
      String legacyDomain = legacy.getProperty("resource.authority-domain");
      String databaseDomain = database.getProperty("resource.authority-domain");
      if (latest > 0L
          && legacyDomain != null
          && databaseDomain != null
          && !legacyDomain.equals(databaseDomain)) {
        throw new IllegalStateException(
            "Legacy transfer receipts use a different resource authority domain");
      }
      if (latest > 0L && databaseDomain == null && legacyDomain != null) {
        try (PreparedStatement insert =
            connection.prepareStatement(
                "INSERT INTO " + TABLE_NAME + "(property_key,property_value) VALUES(?,?)")) {
          insert.setString(1, "resource.authority-domain");
          insert.setString(2, legacyDomain);
          insert.executeUpdate();
        }
      }

      long cursor = 0L;
      while (cursor < latest) {
        List<NationResourceTransactionService.TransferReceipt> batch =
            ResourceTransferReceiptStore.after(legacy, cursor, 1000);
        if (batch.isEmpty())
          throw new IllegalStateException("Legacy transfer receipt sequence has a gap");
        for (var receipt : batch) migrateReceipt(connection, receipt);
        cursor = batch.getLast().sequence();
      }
      try (PreparedStatement insert =
          connection.prepareStatement(
              "INSERT INTO " + MIGRATION_TABLE + "(migration_key,completed_at) VALUES(?,?)")) {
        insert.setString(1, RECEIPT_MIGRATION);
        insert.setLong(2, System.currentTimeMillis());
        insert.executeUpdate();
      }
      connection.commit();
    } catch (Exception error) {
      connection.rollback();
      if (error instanceof SQLException sqlError) throw sqlError;
      throw new IllegalStateException("Legacy resource transfer receipt migration failed", error);
    } finally {
      connection.setAutoCommit(previousAutoCommit);
    }
  }

  private static void migrateReceipt(
      Connection connection, NationResourceTransactionService.TransferReceipt receipt)
      throws SQLException {
    try (PreparedStatement select =
        connection.prepareStatement(
            "SELECT * FROM " + TRANSFER_TABLE + " WHERE transaction_id=?")) {
      select.setString(1, receipt.transactionId());
      try (ResultSet result = select.executeQuery()) {
        if (result.next()) {
          if (!receipt.equals(readTransferReceipt(result)))
            throw new IllegalStateException(
                "Legacy transfer receipt conflicts with SQL history: " + receipt.transactionId());
          return;
        }
      }
    }
    try (PreparedStatement insert =
        connection.prepareStatement(
            """
            INSERT INTO starcore_resource_transfer_receipts
              (transaction_id,authority_domain_id,sequence,payer_nation_id,receiver_nation_id,
               resources,category,description,applied_at)
            VALUES (?,?,?,?,?,?,?,?,?)
            """)) {
      insert.setString(1, receipt.transactionId());
      insert.setString(2, receipt.authorityDomainId());
      insert.setLong(3, receipt.sequence());
      insert.setString(4, receipt.payerNationId().toString());
      insert.setString(5, receipt.receiverNationId().toString());
      insert.setString(6, ResourceTransferReceiptStore.encodeResources(receipt.resources()));
      insert.setString(7, receipt.category().name());
      insert.setString(8, receipt.description());
      insert.setLong(9, receipt.appliedAt().toEpochMilli());
      if (insert.executeUpdate() != 1)
        throw new SQLException("Legacy transfer receipt was not migrated");
    }
  }

  @Override
  protected Properties loadFromDatabase(Connection connection) throws SQLException {
    Properties properties = new Properties();
    try (PreparedStatement statement =
            connection.prepareStatement(
                """
                SELECT property_key, property_value
                FROM starcore_resource_state
                ORDER BY property_key
                """);
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        properties.setProperty(rows.getString("property_key"), rows.getString("property_value"));
      }
    }
    return properties;
  }

  @Override
  protected void writeSnapshot(Connection connection, Properties properties) throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    connection.setAutoCommit(false);
    try {
      SqlResourceTransferJournal.reserveWriter(connection);
      SqlResourceTransferJournal.beforeSnapshot(connection, properties);
      SqlNationTradeJournal.head(connection);
      SqlNationProductionJournal.read(connection);
      long nextRevision = SqlResourceStateRevision.advance(connection, expectedRevision);
      writeProperties(connection, properties);
      connection.commit();
      expectedRevision = nextRevision;
    } catch (Exception exception) {
      connection.rollback();
      throw exception;
    } finally {
      connection.setAutoCommit(previousAutoCommit);
    }
  }

  @Override
  public void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    java.util.Objects.requireNonNull(receipt, "receipt");
    saveWith(properties, snapshot -> writeTransfer(snapshot, receipt));
  }

  private void writeTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      boolean previousAutoCommit = connection.getAutoCommit();
      connection.setAutoCommit(false);
      try {
        SqlResourceTransferJournal.reserveWriter(connection);
        var head =
            SqlResourceTransferJournal.beforeSnapshot(connection, properties)
                .orElseThrow(
                    () -> new SQLException("Resource transfer authority is not initialized"));
        SqlNationProductionJournal.read(connection);
        SqlResourceTransferJournal.advance(connection, head, receipt);
        long nextRevision = SqlResourceStateRevision.advance(connection, expectedRevision);
        writeProperties(connection, properties);
        try (PreparedStatement insert =
            connection.prepareStatement(
                """
                INSERT INTO starcore_resource_transfer_receipts
                  (transaction_id,authority_domain_id,sequence,payer_nation_id,
                   receiver_nation_id,resources,category,description,applied_at)
                VALUES (?,?,?,?,?,?,?,?,?)
                """)) {
          insert.setString(1, receipt.transactionId());
          insert.setString(2, receipt.authorityDomainId());
          insert.setLong(3, receipt.sequence());
          insert.setString(4, receipt.payerNationId().toString());
          insert.setString(5, receipt.receiverNationId().toString());
          insert.setString(6, encodeResources(receipt.resources()));
          insert.setString(7, receipt.category().name());
          insert.setString(8, receipt.description());
          insert.setLong(9, receipt.appliedAt().toEpochMilli());
          if (insert.executeUpdate() != 1) {
            throw new SQLException("Transfer receipt was not inserted");
          }
        }
        connection.commit();
        expectedRevision = nextRevision;
      } catch (Exception error) {
        connection.rollback();
        throw error;
      } finally {
        connection.setAutoCommit(previousAutoCommit);
      }
    } catch (Exception error) {
      throw new IllegalStateException("Atomic resource transfer persistence failed", error);
    }
  }

  @Override
  public boolean supportsNationProduction() {
    return databaseService.dataSource().isPresent();
  }

  @Override
  public Optional<SqlNationProductionJournal.Head> productionState() {
    try (Connection c = openConnection()) {
      SqlResourceTransferJournal.beginRead(c);
      SqlResourceTransferJournal.read(c);
      var result = SqlNationProductionJournal.read(c);
      c.commit();
      return result;
    } catch (Exception error) {
      throw new IllegalStateException("Cannot read production authority", error);
    }
  }

  @Override
  public void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt) {
    saveProduction(properties, run, state, changedAt, NationProductionCatalog.defaults().limits());
  }

  @Override
  public void saveProduction(
      Properties properties,
      NationProductionService.Run run,
      NationProductionService.State state,
      java.time.Instant changedAt,
      NationProductionCatalog.Limits limits) {
    if (state == NationProductionService.State.RUNNING) java.util.Objects.requireNonNull(limits);
    saveWith(
        properties,
        snapshot -> {
          try (Connection c = openConnection()) {
            c.setAutoCommit(false);
            try {
              SqlResourceTransferJournal.reserveWriter(c);
              SqlResourceTransferJournal.beforeSnapshot(c, snapshot);
              SqlNationTradeJournal.head(c);
              if (!run.resourceDomain()
                  .toString()
                  .equals(snapshot.getProperty("resource.authority-domain")))
                throw new SQLException("Production snapshot authority changed");
              if (state == NationProductionService.State.RUNNING) {
                var runs =
                    SqlNationProductionJournal.read(c)
                        .map(h -> h.runs().values())
                        .orElse(List.of());
                if (!limits.permits(runs, run.nationId(), run.batches()))
                  throw new SQLException("Nation production capacity reached before commit");
              }
              long revision = SqlResourceStateRevision.advance(c, expectedRevision);
              SqlNationProductionJournal.append(c, run, state, changedAt);
              writeProperties(c, snapshot);
              c.commit();
              expectedRevision = revision;
            } catch (Exception error) {
              c.rollback();
              throw error;
            }
          } catch (Exception error) {
            throw new IllegalStateException("Atomic production outcome is uncertain", error);
          }
        });
  }

  @Override
  public boolean supportsNationTrade() {
    return databaseService.dataSource().isPresent();
  }

  @Override
  public Optional<javax.sql.DataSource> tradeDataSource() {
    return databaseService.dataSource();
  }

  @Override
  public void saveTradeOffer(NationTradeService.Offer offer) {
    writeTradeMetadata(connection -> SqlNationTradeJournal.insertOffer(connection, offer));
  }

  @Override
  public void cancelTradeOffer(NationTradeService.Offer offer) {
    writeTradeMetadata(
        connection ->
            SqlNationTradeJournal.closeOffer(
                connection, offer, NationTradeService.OfferStatus.CANCELLED));
  }

  private void writeTradeMetadata(
      dev.starcore.starcore.core.storage.SqlCoordinatedWrite.Participant mutation) {
    saveWith(
        new Properties(),
        ignored -> {
          try (Connection connection = openConnection()) {
            connection.setAutoCommit(false);
            try {
              SqlResourceTransferJournal.reserveWriter(connection);
              SqlResourceTransferJournal.read(connection);
              SqlNationTradeJournal.head(connection);
              SqlNationProductionJournal.read(connection);
              mutation.write(connection);
              connection.commit();
            } catch (Exception error) {
              connection.rollback();
              throw error;
            }
          } catch (Exception error) {
            throw new IllegalStateException("National trade metadata outcome is uncertain", error);
          }
        });
  }

  @FunctionalInterface
  private interface TradeRead<T> {
    T read(Connection connection) throws SQLException;
  }

  private <T> T readTrade(TradeRead<T> reader) {
    try (Connection connection = openConnection()) {
      SqlResourceTransferJournal.beginRead(connection);
      SqlResourceTransferJournal.read(connection);
      SqlNationTradeJournal.head(connection);
      SqlNationProductionJournal.read(connection);
      T value = reader.read(connection);
      connection.commit();
      return value;
    } catch (Exception error) {
      throw new IllegalStateException("Cannot read national trade authority", error);
    }
  }

  @Override
  public Optional<NationTradeService.OfferView> tradeOffer(java.util.UUID id) {
    return readTrade(c -> SqlNationTradeJournal.offer(c, id));
  }

  @Override
  public List<NationTradeService.OfferView> tradeOffers(java.util.UUID player, int limit) {
    if (limit < 1 || limit > 100) throw new IllegalArgumentException("Offer limit must be 1..100");
    return readTrade(c -> SqlNationTradeJournal.offers(c, player, limit));
  }

  @Override
  public Optional<SqlNationTradeJournal.Head> tradeHead() {
    return readTrade(SqlNationTradeJournal::head);
  }

  @Override
  public Optional<NationTradeService.SettlementReceipt> tradeSettlement(java.util.UUID id) {
    return readTrade(
        c -> {
          var head = SqlNationTradeJournal.head(c);
          if (head.isEmpty()) return Optional.empty();
          try (var s =
              c.prepareStatement(
                  "SELECT * FROM starcore_nation_trade_settlements WHERE offer_id=?")) {
            s.setString(1, id.toString());
            try (var r = s.executeQuery()) {
              return r.next()
                  ? Optional.of(SqlNationTradeJournal.readReceipt(r, head.orElseThrow()))
                  : Optional.empty();
            }
          }
        });
  }

  @Override
  public List<NationTradeService.SettlementReceipt> tradeSettlementsAfter(
      java.util.UUID domain, long after, int limit) {
    java.util.Objects.requireNonNull(domain);
    if (after < 0 || limit < 1 || limit > 100)
      throw new IllegalArgumentException("Invalid trade cursor/page");
    return readTrade(
        c -> {
          var head = SqlNationTradeJournal.head(c).orElseThrow();
          if (!head.domain().equals(domain) || after > head.sequence())
            throw new SQLException("Trade authority/cursor changed");
          List<NationTradeService.SettlementReceipt> result = new ArrayList<>();
          try (var s =
              c.prepareStatement(
                  "SELECT * FROM starcore_nation_trade_settlements WHERE sequence_id>? AND"
                      + " sequence_id<=? ORDER BY sequence_id LIMIT ?")) {
            s.setLong(1, after);
            s.setLong(2, head.sequence());
            s.setInt(3, limit);
            try (var r = s.executeQuery()) {
              while (r.next()) {
                var receipt = SqlNationTradeJournal.readReceipt(r, head);
                if (receipt.sequence() != after + result.size() + 1L)
                  throw new SQLException("Trade page is not contiguous");
                result.add(receipt);
              }
            }
          }
          if (result.size() != Math.min((long) limit, head.sequence() - after))
            throw new SQLException("Trade page lost committed receipts");
          return List.copyOf(result);
        });
  }

  @Override
  public void saveTrade(
      Properties properties,
      NationResourceTransactionService.TransferReceipt resourceReceipt,
      NationTradeService.SettlementReceipt settlement,
      javax.sql.DataSource fundingSource,
      dev.starcore.starcore.core.storage.SqlCoordinatedWrite.Commit fundingCommit) {
    if (fundingSource != databaseService.dataSource().orElseThrow())
      throw new IllegalStateException(
          "Trade funding and inventory must use the same SQL data source");
    saveWith(
        properties,
        snapshot -> {
          var nextRevision = new java.util.concurrent.atomic.AtomicLong(-1);
          fundingCommit.commit(
              c -> {
                SqlResourceTransferJournal.reserveWriter(c);
                var head = SqlResourceTransferJournal.beforeSnapshot(c, snapshot).orElseThrow();
                SqlNationProductionJournal.read(c);
                nextRevision.set(SqlResourceStateRevision.advance(c, expectedRevision));
                SqlResourceTransferJournal.advance(c, head, resourceReceipt);
                writeProperties(c, snapshot);
                migrateReceipt(c, resourceReceipt);
                SqlNationTradeJournal.append(c, settlement);
              });
          if (nextRevision.get() < 0)
            throw new IllegalStateException("Trade inventory was not written");
          expectedRevision = nextRevision.get();
        });
  }

  @Override
  public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      SqlResourceTransferJournal.beginRead(connection);
      SqlResourceTransferJournal.read(connection);
      try (PreparedStatement statement =
          connection.prepareStatement(
              "SELECT * FROM " + TRANSFER_TABLE + " WHERE transaction_id=?")) {
        statement.setString(1, id);
        try (ResultSet result = statement.executeQuery()) {
          var receipt =
              result.next()
                  ? Optional.of(readTransferReceipt(result))
                  : Optional.<NationResourceTransactionService.TransferReceipt>empty();
          connection.commit();
          return receipt;
        }
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer receipt", error);
    }
  }

  @Override
  public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    if (sequence < 0L || limit < 1 || limit > 1000)
      throw new IllegalArgumentException("sequence must be non-negative and limit must be 1..1000");
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      SqlResourceTransferJournal.beginRead(connection);
      var head = SqlResourceTransferJournal.read(connection);
      long committed = head.map(SqlResourceTransferJournal.Head::sequence).orElse(0L);
      if (sequence > committed) throw new SQLException("Resource cursor is ahead of its journal");
      try (PreparedStatement statement =
          connection.prepareStatement(
              "SELECT * FROM "
                  + TRANSFER_TABLE
                  + " WHERE sequence>? AND sequence<=? ORDER BY sequence LIMIT ?")) {
        statement.setLong(1, sequence);
        statement.setLong(2, committed);
        statement.setInt(3, limit);
        try (ResultSet result = statement.executeQuery()) {
          List<NationResourceTransactionService.TransferReceipt> receipts = new ArrayList<>();
          while (result.next()) {
            var receipt = readTransferReceipt(result);
            if (receipt.sequence() != sequence + receipts.size() + 1L
                || !receipt.authorityDomainId().equals(head.orElseThrow().domain()))
              throw new SQLException("Resource transfer page is not contiguous in its domain");
            receipts.add(receipt);
          }
          if (receipts.size() != Math.min((long) limit, committed - sequence))
            throw new SQLException("Resource transfer page has missing committed receipts");
          connection.commit();
          return List.copyOf(receipts);
        }
      }
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer journal", error);
    }
  }

  private Optional<SqlResourceTransferJournal.Head> readHistoryHead() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      SqlResourceTransferJournal.beginRead(connection);
      var head = SqlResourceTransferJournal.read(connection);
      connection.commit();
      return head;
    } catch (Exception error) {
      throw new IllegalStateException("Unable to read resource transfer journal head", error);
    }
  }

  @Override
  public Optional<java.util.UUID> transferHistoryAuthorityDomainId() {
    return readHistoryHead().map(head -> java.util.UUID.fromString(head.domain()));
  }

  @Override
  public long latestTransferSequence() {
    return readHistoryHead().map(SqlResourceTransferJournal.Head::sequence).orElse(0L);
  }

  @Override
  public int transferReceiptCount() {
    return Math.toIntExact(latestTransferSequence());
  }

  private static void writeProperties(Connection connection, Properties properties)
      throws SQLException {
    try (Statement delete = connection.createStatement()) {
      delete.execute("DELETE FROM " + TABLE_NAME);
    }
    try (PreparedStatement insert =
        connection.prepareStatement(
            """
            INSERT INTO starcore_resource_state (property_key, property_value)
            VALUES (?, ?)
            """)) {
      for (String key : properties.stringPropertyNames()) {
        if (key.startsWith("resource.transfer.")) continue;
        insert.setString(1, key);
        insert.setString(2, properties.getProperty(key));
        insert.addBatch();
      }
      insert.executeBatch();
    }
  }

  private static NationResourceTransactionService.TransferReceipt readTransferReceipt(ResultSet row)
      throws SQLException {
    return new NationResourceTransactionService.TransferReceipt(
        row.getString("transaction_id"),
        row.getString("authority_domain_id"),
        row.getLong("sequence"),
        new dev.starcore.starcore.module.nation.model.NationId(
            java.util.UUID.fromString(row.getString("payer_nation_id"))),
        new dev.starcore.starcore.module.nation.model.NationId(
            java.util.UUID.fromString(row.getString("receiver_nation_id"))),
        ResourceTransferReceiptStore.decodeResources(row.getString("resources")),
        NationResourceTransactionService.Category.valueOf(row.getString("category")),
        row.getString("description"),
        java.time.Instant.ofEpochMilli(row.getLong("applied_at")));
  }

  private static String encodeResources(Map<String, Long> resources) {
    return resources.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .map(entry -> entry.getKey() + '=' + entry.getValue())
        .collect(java.util.stream.Collectors.joining(";"));
  }
}
