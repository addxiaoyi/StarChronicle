package dev.starcore.starcore.module.resource;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Strict, immutable operator-authored terms for new runs. Existing runs retain their own terms. */
public record NationProductionCatalog(
    boolean enabled, Limits limits, List<Entry> entries, String digest) {
  public record Limits(int maxRunningRuns, long maxRunningBatches) {
    public Limits {
      if (maxRunningRuns < 1
          || maxRunningRuns > 1000
          || maxRunningBatches < 1
          || maxRunningBatches > 1_000_000)
        throw new IllegalArgumentException("Invalid nation production capacity");
    }

    boolean permits(
        Collection<NationProductionService.RunView> runs,
        dev.starcore.starcore.module.nation.model.NationId nation,
        long batches) {
      long count = 0, used = 0;
      for (var view : runs) {
        if (view.state() == NationProductionService.State.RUNNING
            && view.run().nationId().equals(nation)) {
          count++;
          used = Math.addExact(used, view.run().batches());
        }
      }
      return count < maxRunningRuns && Math.addExact(used, batches) <= maxRunningBatches;
    }
  }

  public record Entry(NationProductionService.Recipe recipe, int maxBatches) {
    public Entry {
      Objects.requireNonNull(recipe);
      if (maxBatches < 1 || maxBatches > 1000)
        throw new IllegalArgumentException("Invalid recipe max-batches");
      for (var values : List.of(recipe.inputs(), recipe.outputs()))
        for (long value : values.values())
          if (Math.multiplyExact(value, maxBatches) > 100_000_000L)
            throw new IllegalArgumentException("Recipe scaled quantities exceed persisted limits");
    }
  }

  public NationProductionCatalog {
    Objects.requireNonNull(limits);
    entries = List.copyOf(entries);
    if (entries.size() > 100 || (enabled && entries.isEmpty()))
      throw new IllegalArgumentException("Require 1..100 enabled recipes");
    var ids = new HashSet<String>();
    for (var entry : entries)
      if (!ids.add(entry.recipe().recipeId()))
        throw new IllegalArgumentException("Duplicate recipe id");
    Objects.requireNonNull(digest);
  }

  public Optional<Entry> entry(String id) {
    return entries.stream().filter(e -> e.recipe().recipeId().equals(id)).findFirst();
  }

  public static NationProductionCatalog defaults() {
    try (var stream =
        NationProductionCatalog.class.getResourceAsStream("/nation-production.json")) {
      if (stream == null)
        throw new IllegalStateException("Missing packaged nation production catalog");
      return parse(new String(stream.readAllBytes(), StandardCharsets.UTF_8));
    } catch (IOException error) {
      throw new IllegalStateException("Cannot read packaged catalog", error);
    }
  }

  public static NationProductionCatalog unavailable() {
    return new NationProductionCatalog(false, new Limits(16, 1000), List.of(), "unavailable");
  }

  public static NationProductionCatalog parse(String text) {
    if (text.getBytes(StandardCharsets.UTF_8).length > 65536)
      throw new IllegalArgumentException("Production catalog exceeds 64 KiB");
    try (var reader = new JsonReader(new StringReader(text))) {
      reader.setLenient(false);
      JsonElement document = read(reader, 0);
      if (reader.peek() != JsonToken.END_DOCUMENT)
        throw new IllegalArgumentException("Trailing catalog content");
      JsonObject root = object(document, Set.of("format", "enabled", "limits", "recipes"));
      if (integer(root.get("format")) != 1)
        throw new IllegalArgumentException("Unsupported catalog format");
      JsonElement enabled = root.get("enabled");
      if (!enabled.isJsonPrimitive() || !enabled.getAsJsonPrimitive().isBoolean())
        throw new IllegalArgumentException("enabled must be boolean");
      var caps = object(root.get("limits"), Set.of("max-running-runs", "max-running-batches"));
      var limits =
          new Limits(
              Math.toIntExact(integer(caps.get("max-running-runs"))),
              integer(caps.get("max-running-batches")));
      if (!root.get("recipes").isJsonArray())
        throw new IllegalArgumentException("recipes must be an array");
      var entries = new ArrayList<Entry>();
      for (var value : root.getAsJsonArray("recipes")) {
        var recipe =
            object(
                value,
                Set.of("id", "name", "inputs", "outputs", "seconds-per-batch", "max-batches"));
        entries.add(
            new Entry(
                new NationProductionService.Recipe(
                    string(recipe.get("id")),
                    string(recipe.get("name")),
                    quantities(recipe.get("inputs")),
                    quantities(recipe.get("outputs")),
                    integer(recipe.get("seconds-per-batch"))),
                Math.toIntExact(integer(recipe.get("max-batches")))));
      }
      String digest =
          HexFormat.of()
              .formatHex(
                  MessageDigest.getInstance("SHA-256")
                      .digest(text.getBytes(StandardCharsets.UTF_8)));
      return new NationProductionCatalog(enabled.getAsBoolean(), limits, entries, digest);
    } catch (IOException | java.security.NoSuchAlgorithmException | ArithmeticException error) {
      throw new IllegalArgumentException("Invalid production catalog", error);
    }
  }

  private static JsonElement read(JsonReader r, int depth) throws IOException {
    if (depth > 8) throw new IllegalArgumentException("Catalog nesting limit exceeded");
    return switch (r.peek()) {
      case BEGIN_OBJECT -> {
        var result = new JsonObject();
        r.beginObject();
        while (r.hasNext()) {
          String key = r.nextName();
          if (result.has(key)) throw new IllegalArgumentException("Duplicate JSON key: " + key);
          result.add(key, read(r, depth + 1));
        }
        r.endObject();
        yield result;
      }
      case BEGIN_ARRAY -> {
        var result = new JsonArray();
        r.beginArray();
        while (r.hasNext()) {
          if (result.size() >= 100)
            throw new IllegalArgumentException("Catalog array limit exceeded");
          result.add(read(r, depth + 1));
        }
        r.endArray();
        yield result;
      }
      case STRING -> new JsonPrimitive(r.nextString());
      case NUMBER -> {
        String number = r.nextString();
        if (!number.matches("0|[1-9][0-9]{0,18}"))
          throw new IllegalArgumentException(
              "Catalog numbers must be nonnegative integer literals");
        yield new JsonPrimitive(Long.parseLong(number));
      }
      case BOOLEAN -> new JsonPrimitive(r.nextBoolean());
      default -> throw new IllegalArgumentException("Invalid/null catalog value");
    };
  }

  private static JsonObject object(JsonElement value, Set<String> keys) {
    if (!value.isJsonObject() || !value.getAsJsonObject().keySet().equals(keys))
      throw new IllegalArgumentException("Unexpected or missing catalog fields; expected " + keys);
    return value.getAsJsonObject();
  }

  private static String string(JsonElement value) {
    if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString())
      throw new IllegalArgumentException("Expected catalog text");
    String text = value.getAsString();
    if (text.codePoints().anyMatch(c -> Character.isISOControl(c) || c == 0x00a7))
      throw new IllegalArgumentException("Control/formatting characters are not allowed");
    return text;
  }

  private static long integer(JsonElement value) {
    if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber())
      throw new IllegalArgumentException("Expected catalog integer");
    return value.getAsLong();
  }

  private static Map<String, Long> quantities(JsonElement value) {
    if (!value.isJsonObject())
      throw new IllegalArgumentException("Expected resource quantity object");
    var result = new TreeMap<String, Long>();
    value.getAsJsonObject().entrySet().forEach(e -> result.put(e.getKey(), integer(e.getValue())));
    return result;
  }
}
