from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
attempt=sys.argv[2] if len(sys.argv)>2 else 'native-social-data-command-focused-1-20261128'
tests=json.loads((root/'run'/attempt/'result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][k]==0 for k in ('failures','errors','skipped'))
frozen=root/'run/social-data-command-frozen-pair-1-20261128'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
if sys.argv[1]=='freeze':
    frozen.mkdir();manifest={}
    for name,source,key in [
        ('chronicle.jar',root/'run/friend-service-complete-frozen-pair-1-20261128/chronicle.jar',None),
        ('native.jar',native/'target/starcore-1.0.0.jar','starcore-1.0.0.jar'),
        ('original-native.jar',native/'target/original-starcore-1.0.0.jar','original-starcore-1.0.0.jar')]:
        original=digest(source)
        if key:assert original==tests['artifacts'][key]
        if key:shutil.copy2(source,frozen/name)
        else:os.link(source,frozen/name)
        assert digest(frozen/name)==original
        manifest[name]={'sha256':original,'bytes':source.stat().st_size,'source':str(source)}
    (frozen/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));sys.exit()
pair=json.loads((root/'run/social-data-command-pair-artifacts-1-20261128/result.json').read_text());assert pair['status']=='VERIFIED'
replicas=json.loads((root/'run/social-data-command-replicas-1-20261128/result.json').read_text());assert replicas['status']=='VERIFIED'
files={}
folders=[('validation',attempt),('replicas','social-data-command-replicas-1-20261128'),('pair','social-data-command-pair-artifacts-1-20261128'),('frozen',frozen.name)]
for previous in sorted((root/'run').glob('native-social-data-command-focused-*-20261128')):
    if previous.name!=attempt:folders.append(('prior-'+previous.name,previous.name))
for label,name in folders:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class','.mdmp'):files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','tools/verify-social-import-recovery.py','tools/SocialImportOfflineProbe.java','tools/SocialImportLegacyProbe.java','tools/test_snapshot_maven_validation.py','run/snapshot-reuse-tests-20261128.json',
             'run/validate-social-data-command-20261128.py','run/finalize-social-data-command-20261128.py','run/social-data-command-format-20261128.log','run/all-historical-jar-deduplication-20261128-summary.json','run/all-historical-jar-deduplication-20261128.jsonl','run/deduplicate-all-historical-jars-executed-20261128.py','run/jar-deduplication-relaunch-20261128.json','run/social-import-recovery-sync-20261128.json','run/frozen-source-deduplication-4-20261128-summary.json','run/party-evidence-compression-4-native-friend-complete-sql-focused-1-20261128.json']:
    files['tools/'+Path(name).name]=root/name
manifest={name:digest(path) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],'artifacts':json.loads((frozen/'manifest.json').read_text()),'fixtures_compiled':pair['fixtures']['count'],'replica_jvms':len(replicas['runs']),
    'limits':['Related tests only, not full StarCore regression. SQLite and mixed SQL/file modes only; MySQL not run.',
      'Version 2 exports logical states and all modeled invitation evidence. Native SQL row IDs/member join times, original friend request timestamps/expiry, handled/expired rows and extension columns still require the original database backup.',
      'Version 1 cannot reconstruct omitted requests, blacklist, legacy contacts or invitations. Exact original export bytes remain retained.',
      'The importer validates all participants then durably journals expected/candidate states and opaque authority identities. Local participant monitors hide in-process partial imports; external SQL/file writers are not globally fenced.',
      'Startup forward recovery requires each participant to match its recorded before/after state and the original storage identity. Third states, changed authority, expired SQL request projections or damaged/pending publication evidence fail closed for manual inspection.',
      'Prepared plans, independent immutable anchors and matching completion receipts are retained. Removal of the journal directory or both a plan and its receipt is detected by the independent anchor; removal of all independent evidence cannot be inferred. Journal document size/node limits remain; all retained plans are scanned on startup and before another import, with no long-term archival benchmark.',
      'File publication uses forced immutable documents and cooperation locks. Windows directory fsync is best effort; no hardware power-loss test.',
      'Social data commands use captured player/global owners, bounded I/O, cached completion, explicit outcomes and 20-entry pages. Periodic owners, emote/chat, activity/alliance/culture and other phases remain source work.',
      'No Minecraft/Paper/Folia, deployment, live multiplayer acceptance or sustained mixed-writer load.']}
out=root/'docs/verification/social-data-command-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=digest(out),files=manifest)
(root/'docs/verification/social-data-command-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
