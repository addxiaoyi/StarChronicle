from pathlib import Path
import hashlib,json,os,uuid
run=Path(__file__).resolve().parent
paths=sorted(run.rglob('*.jar'))
index={};files=[];saved=0
log=run/'all-historical-jar-deduplication-20261128.jsonl'
def sha(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
with log.open('x') as output:
 for p in paths:
  assert not p.is_symlink() and p.resolve().is_relative_to(run)
  before=p.stat();digest=sha(p);key=(before.st_size,digest)
  canonical=index.setdefault(key,p)
  linked=False
  if not os.path.samefile(canonical,p):
   assert sha(canonical)==digest and p.stat().st_mtime_ns==before.st_mtime_ns
   temp=p.with_name('.dedup-'+uuid.uuid4().hex)
   os.link(canonical,temp);os.replace(temp,p)
   assert sha(p)==digest
   saved+=before.st_size;linked=True
  record={'path':p.relative_to(run).as_posix(),'bytes':before.st_size,'sha256':digest,'canonical':canonical.relative_to(run).as_posix(),'linked':linked}
  output.write(json.dumps(record)+'\n');output.flush();files.append(record)
  if len(files)%50==0:print(json.dumps({'files':len(files),'duplicate_bytes':saved}),flush=True)
report={'status':'VERIFIED','files':len(files),'duplicate_bytes':saved,'manifest_sha256':sha(log),'scope':'Identical completed JAR artifacts under this task run directory only; every original path and byte retained. No current product source or other project changed.'}
(run/'all-historical-jar-deduplication-20261128-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
