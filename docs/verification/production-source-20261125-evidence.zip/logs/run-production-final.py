import os, sys, subprocess, shutil
from pathlib import Path
chronicle=Path(r'C:\Users\Administrator\Documents\StarChronicle')
native=Path(r'C:\Users\Administrator\Documents\StarChronicle-audit\starcore-all-stages')
logs=chronicle/'run'
shutil.copytree(native/'target/surefire-reports', logs/'production-native-first-reports')
env=os.environ.copy()
env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
base='-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8'
for root,name,args in [(native,'production-native-format-final.log',['-DspotlessFiles=.*Production.*.java,.*ProcessingService.java,.*ResourceModule.java,.*ResourceStateStorage.java,.*ResourceCommand.java','spotless:apply']),
 (native,'production-native-final.log',['-DforkCount=0','-Dtest=ProductionPersistenceTest,SqlProductionPersistenceTest,ResourceProductionCommandTest,ResourceTransactionPersistenceTest,ResourceTransferReceiptStoreTest,SqlResourceTransferMigrationTest,ResourceCommandSafetyTest,ResourceCommandRoleMatrixTest,ResourceStateCodecTest,ProcessingRecipeTest,FactoryTest,PublicApiCompatibilityTest','verify']),
 (chronicle,'production-chronicle-final.log',['-DforkCount=0','verify'])]:
    env['MAVEN_OPTS']=base+(' -javaagent:C:\\Users\\Administrator\\.m2\\repository\\org\\mockito\\mockito-core\\5.23.0\\mockito-core-5.23.0.jar' if root==native else '')
    with (logs/name).open('wb') as out:
        r=subprocess.run([str(root/'mvnw.cmd'),'-B','-ntp',*args],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    print(name,r.returncode,flush=True)
    if r.returncode: sys.exit(r.returncode)
