import os, sys, subprocess
from pathlib import Path
root=Path(r'C:\Users\Administrator\Documents\StarChronicle-audit\starcore-all-stages')
logs=Path(r'C:\Users\Administrator\Documents\StarChronicle\run')
env=os.environ.copy()
env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']='-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8 -javaagent:C:\\Users\\Administrator\\.m2\\repository\\org\\mockito\\mockito-core\\5.23.0\\mockito-core-5.23.0.jar'
commands=[('production-native-format-1.log',['-DspotlessFiles=.*Production.*.java,.*ProcessingService.java,.*ResourceModule.java,.*ResourceStateStorage.java,.*ResourceCommand.java','spotless:apply']),
          ('production-native-first.log',['-DforkCount=0','-Dtest=ProductionPersistenceTest,SqlProductionPersistenceTest,ResourceProductionCommandTest,ResourceTransactionPersistenceTest,ResourceTransferReceiptStoreTest,SqlResourceTransferMigrationTest,ResourceCommandSafetyTest,ResourceCommandRoleMatrixTest,PublicApiCompatibilityTest','verify'])]
for name,args in commands:
    with (logs/name).open('wb') as out:
        r=subprocess.run([str(root/'mvnw.cmd'),'-B','-ntp',*args],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    print(name,r.returncode,flush=True)
    if r.returncode: sys.exit(r.returncode)
