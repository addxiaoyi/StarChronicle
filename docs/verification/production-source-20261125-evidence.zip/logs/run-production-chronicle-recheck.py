import os, sys, subprocess, shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
shutil.copytree(root/'target/surefire-reports',root/'run/production-chronicle-first-reports')
env=os.environ.copy()
env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']='-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8'
for name,args in [('production-sqlite-recheck.log',['-Dtest=SqliteStoreTest,CrossStoryEngineTest','test']),('production-chronicle-recheck.log',['verify'])]:
    with (root/'run'/name).open('wb') as out:
        result=subprocess.run([str(root/'mvnw.cmd'),'-B','-ntp','-DforkCount=0',*args],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    print(name,result.returncode,flush=True)
    if result.returncode: sys.exit(result.returncode)
