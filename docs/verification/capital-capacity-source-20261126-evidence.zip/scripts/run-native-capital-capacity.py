from pathlib import Path
import json,os,re,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
phase=sys.argv[1];out=root/'run'/('native-capital-capacity-'+phase+'-20261126');out.mkdir(exist_ok=False)
env=os.environ.copy();env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']='-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8'
if phase.startswith('test'):env['MAVEN_OPTS']+=r' -javaagent:C:\Users\Administrator\.m2\repository\org\mockito\mockito-core\5.23.0\mockito-core-5.23.0.jar'
base=['cmd.exe','/d','/c',str(native/'mvnw.cmd'),'-o','-B','-ntp','-Djacoco.skip=true']
if phase.startswith('compile'):args=['spotless:apply','-Dmaven.compiler.useIncrementalCompilation=false','-DskipTests','test-compile']
elif phase.startswith('test'):args=['-DforkCount=0','-Dtest='+sys.argv[2],'surefire:test']
elif phase.startswith('package'):args=['-Dmaven.main.skip=true','-Dmaven.test.skip=true','verify']
elif phase=='sbom':
 base.remove('-o');args=['cyclonedx:makeAggregateBom@generate-sbom']
else:raise ValueError(phase)
start=time.monotonic()
with (out/'maven.log').open('wb') as log:result=subprocess.run(base+args,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT)
logtext=(out/'maven.log').read_text(encoding='utf-8',errors='replace')
totals={k:0 for k in ('tests','failures','errors','skipped')}
for suite in re.findall(r'Tests run: \d+, Failures: \d+, Errors: \d+, Skipped: \d+, Time elapsed: [^\r\n]+ -- in ([\w.$]+)',logtext):
 path=native/'target/surefire-reports'/('TEST-'+suite+'.xml')
 if path.exists():
  (out/'surefire').mkdir(exist_ok=True);shutil.copy2(path,out/'surefire'/path.name)
  data=ET.parse(path).getroot()
  for key in totals:totals[key]+=int(data.attrib.get(key,0))
summary={'exit_code':result.returncode,'totals':totals,'seconds':time.monotonic()-start,'args':base+args}
(out/'result.json').write_text(json.dumps(summary,indent=2))
names=set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=native).decode().splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=native).decode().splitlines())
for name in names:
 p=native/name
 if p.is_file():
  dest=out/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
print(json.dumps(summary));raise SystemExit(result.returncode)
