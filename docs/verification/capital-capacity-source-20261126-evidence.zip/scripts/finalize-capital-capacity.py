from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda name:json.loads((root/'run'/name/'result.json').read_text())
summary={'status':'VERIFIED','native_tests':read('native-capital-capacity-test-nation-20261126'),'capacity':read('capital-capacity-first-20261126'),
 'artifacts':read('native-capital-capacity-artifacts-20261126'),'compatibility':read('capital-databases-capacity-20261126'),
 'chronicle':'271 tested source/resource/test files and JAR unchanged from b30743d; prior 1123 clean verify and CI #210 remain applicable to Chronicle product.',
 'limits':['No Minecraft or full native-suite run; 281 selected tests, existing exclusions unchanged.',
 '400000 synthetic canonical records, 200000 nations and 1 MiB incomplete tail at fixed 32 MiB Java heap. Disk space and elapsed time still grow; not long-running concurrency or production upgrade.',
 'Legacy complete lines exceeding 512 bytes are now rejected before publishing migration files; canonical old writer max is 225 bytes. Arbitrarily long incomplete tail remains evidence only.',
 'The expected old-JAR OOM is a preserved comparison failure; original log SHA unchanged and no migration files were created.',
 'Large synthetic files remain local; archive includes deterministic generator, exact hashes, original logs and row fingerprint. Smaller real-JAR and upstream copies are archived.']}
files={}
for folder in ('native-capital-capacity-compile-20261126','native-capital-capacity-compile-final-20261126','native-capital-capacity-test-nation-20261126',
 'native-capital-capacity-package-20261126','native-capital-capacity-sbom-20261126','native-capital-capacity-artifacts-20261126','capital-databases-capacity-20261126'):
 for path in (root/'run'/folder).rglob('*'):
  if path.is_file() and path.suffix not in ('.class','.jar'):files['run/'+path.relative_to(root/'run').as_posix()]=path
large=root/'run/capital-capacity-first-20261126'
omitted={}
for path in large.rglob('*'):
 if not path.is_file() or path.suffix=='.class':continue
 if path.stat().st_size>1024*1024:
  with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
  omitted[path.relative_to(large).as_posix()]={'bytes':path.stat().st_size,'sha256':digest}
 else:files['capacity/'+path.relative_to(large).as_posix()]=path
summary['large_fixture_files']=omitted
for name in ('CapitalCapacityProbe.java','verify-capital-capacity.py','verify-native-capital-capacity-artifacts.py','run-native-capital-capacity.py','CapitalMergeProbe.java','verify-capital-databases.py','finalize-capital-capacity.py'):
 files['scripts/'+name]=root/'run'/name
files['native-sbom.json']=native/'target/starcore-1.0.0-sbom.json'
files['previous-ci.log']=root/'run/capital-merge-ci-success-20261126.log'
files['previous-ci.json']=root/'run/capital-merge-ci-20261126.json'
archive=root/'docs/verification/capital-capacity-source-20261126-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
 z.writestr('large-fixture-manifest.json',json.dumps(omitted,indent=2))
 inventory={name:sha(z.read(name)) for name in z.namelist()}
 z.writestr('evidence-manifest.json',json.dumps(inventory,indent=2))
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(inventory)|{'evidence-manifest.json'}
 for name,digest in inventory.items():assert sha(z.read(name))==digest
summary['evidence']={'members':len(inventory)+1,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
(root/'docs/verification/capital-capacity-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
core=summary['artifacts']['starcore_sha256'];evidence=summary['evidence']['sha256']
report=f'''# 首都迁移与启动校验容量

在首都合并 StarCore `cf5016d`／Chronicle `b30743d` 后继续第9阶段源码工作。首都旧日志迁移不再整文件读入，也不在Java堆内保留全部操作ID和国家首都。**281项StarCore相关测试通过**，当前JAR在**32 MiB堆**下迁移并重开**40万条记录／20万个国家**。按用户要求未启动Minecraft，十阶段尚未全部完成。

## 行为与兼容

迁移前用SQLite私有临时磁盘库及唯一操作索引校验完整旧记录；查重和每国前城市状态不随历史增长占用Java集合。原文件流式读取／哈希／复制，先完成校验才写legacy与迁移标记，归档冲突或校验失败保持原文件。导入在原SQLite事务内逐条写入，提交前再次核对完整SHA；原操作、城市、主体、毫秒精度和未提交尾部保留。

启动仍逐条验证全部历史与连续序号，通过国家／序号索引查询每条前城市，不累积国家Map。SQLite页缓存明确有界，临时数据落盘；原SQLite结构、独立域、迁移标记和公开API不变。正常追加仍FULL同步、原操作幂等，页查询仍有界。

旧writer的规范ASCII行最大225字节，读取器以512字节为完整行上限；异常超长完整行在改变原日志前拒绝。任意长度未换行尾部仅保留原字节，不导入或截断。实际坏文件／手改超长数字不被视为旧writer兼容输入。

## 测试与低堆对照

281项国家／公开API相关测试零失败、错误、跳过，含20项首都存储与1项授权。新增六项覆盖多国交错、长尾保留、超长完整行、远距离重复operation、原legacy冲突和MIGRATING缺库恢复。test-compile、Spotless、skip-tests verify、36组件SBOM、六类旧公开API与关键编译字节码通过。没有声称本轮原生全库回归。

同一确定性样本为400,000条、200,000个不同国家的交错历史，每国两次指定，另有1 MiB未完成尾部，总76,337,471字节。三个独立串行JVM都限制 `-Xmx32m`，真实打包的存储执行迁移／打开：

| 构件与操作 | 结果 | 本次耗时 |
| --- | --- | --- |
| 原JAR `c4b80053…88121f` 迁移 | `Files.readAllBytes` 真实OutOfMemoryError，退出1；原日志SHA保持，未生成legacy／SQLite | 0.594秒 |
| 当前JAR迁移 | 成功，退出0，400,000条完整记录、200,000国、操作唯一、原毫秒时间和尾部完整保持 | 44.844秒 |
| 当前JAR独立重开 | 成功，退出0，深页／当前首都／超前游标拒绝通过，所有来源文件与完整记录指纹保持 | 6.875秒 |

探针同时确认空SQLite文件名对应临时磁盘数据库的DELETE日志模式。SHA与行指纹由独立Python SQLite只读检查核验。耗时只代表本机样本，不是服务延迟保证；磁盘空间、I/O和启动全扫描时间仍随历史增长。

当前两JAR再次执行旧JAR生成260条→迁移→续接261条、新装261条及上游139条副本重开。47张旧Chronicle原表原列、43张上游原表原列与2张首都表保持；两种旧writer尝试仍拒绝且文件不变。该对照仍为测试国家域门面加真实打包存储／Chronicle，不替代整服授权。

Chronicle产品未修改，271份已测源码／资源／测试及JAR与 `b30743d` 一致，沿用1,123项完整clean verify及成功[CI #210](https://github.com/addxiaoyi/StarChronicle/actions/runs/45781843782)的精确范围；不把它计作本轮再次执行。当前配套Chronicle SHA `53844b0d1c78b014325fd483001ee0406cb9053204786144acfe8aa0d325f5a9`，StarCore SHA `{core}`。

## 证据与剩余边界

[摘要](verification/capital-capacity-source-20261126-summary.json)和[证据ZIP](verification/capital-capacity-source-20261126-evidence.zip)含{summary['evidence']['members']}成员，SHA `{evidence}`。包含最终源码、真实XML、全部构建／OOM／成功日志、探针和确定性样本生成脚本、小型真实副本、API及字节码指纹。76MB样本文本及126MB合成SQLite留在本机 `run/capital-capacity-first-20261126`，其完整文件清单／SHA和行指纹归档；未把大样本伪称已经放入ZIP。

本轮限制迁移与启动的Java堆增长，仍需要足够临时和永久磁盘，仍全量扫描检查历史。长期并发、超大磁盘存档、其他集合／文件容量、未撮合订单托管／核对、其余所有权与生命周期、外部经济以及当前构件真实Paper／Folia组合仍待继续。未合并主分支或部署生产。
'''
(root/'docs/CAPITAL-CAPACITY-SOURCE-20261126.md').write_text(report,encoding='utf-8')
intro='2026-11-26 当前源码检查点：[首都迁移与启动容量]({link})。**281项原生相关测试通过**；相同32 MiB堆下，旧JAR读取76MB日志发生OOM，新JAR完成40万条／20万国迁移和独立重开，原字节与指纹保持。StarCore `2e802d62…08bf09`；Chronicle产品保持1,123项检查点。本轮仅源码与副本验证，十阶段继续进行。'
for name in ('README.md','docs/HANDOFF-2026-11-26.md','docs/REMAINING-WORK.md'):
 path=root/name;content=path.read_text(encoding='utf-8');head,rest=content.split('\n',1)
 link=('docs/' if name=='README.md' else '')+'CAPITAL-CAPACITY-SOURCE-20261126.md'
 content=head+'\n\n'+intro.format(link=link)+'\n'+rest
 if name.endswith('HANDOFF-2026-11-26.md'):
  content=content.replace('先同步 GitHub 并阅读 GITHUB-CAPITAL-MERGE-20261126.md','先同步 GitHub 并阅读 CAPITAL-CAPACITY-SOURCE-20261126.md、GITHUB-CAPITAL-MERGE-20261126.md')
  content=content.replace('当前首都合并已有1,123项Chronicle全量、275项StarCore相关测试及真实JAR迁移／副本恢复；','当前Chronicle产品保持1,123项全量；StarCore容量改进281项相关测试和32MiB堆40万条／20万国迁移重开通过，真实JAR兼容副本再次通过；')
 path.write_text(content,encoding='utf-8')
(native/'docs/CAPITAL-CAPACITY-SOURCE-2026-11-26.md').write_text(f'''# 首都迁移与启动容量

从 `cf5016d` 继续，流式读取／哈希／复制原日志，以临时磁盘SQLite及唯一索引验证重复操作、原国家城市链；启动改为逐条解码及索引前城市查询，不驻留全历史集合。原SQLite结构、域、公开API、提交和备份协议不变。完整旧规范行最大225字节，512字节上限拒绝异常完整行，任意未完成尾部完整保留。

281项相关测试零失败／错误／跳过；包含新增6项及20项首都存储／1项授权。Spotless、编译、skip-tests verify、36组件SBOM、六类旧公开API和字节码通过。最终JAR `{core}`。

32MiB堆下，原JAR读取76,337,471字节样本在readAllBytes发生真实OOM且原文件保持；当前JAR迁移400,000记录／200,000国家并独立重开通过，保留1MiB尾部、原毫秒和完整行指纹。44.844秒迁移、6.875秒重开仅为本机结果。当前JAR另通过260旧记录迁移／261续接与139上游副本重开，旧writer拒绝不变。未启动Minecraft或原生全库测试，未合并部署。

完整[源码报告](https://github.com/addxiaoyi/StarChronicle/blob/codex/plugin-all-stages-20261125/docs/CAPITAL-CAPACITY-SOURCE-20261126.md)、实际XML、源快照、OOM及成功日志和探针在配套仓库。证据ZIP SHA `{evidence}`。合成大文件只归档哈希与生成器，小型真实副本已归档。磁盘和时间仍随历史增长，长期并发与生产升级待验收。
''',encoding='utf-8')
print(json.dumps({'evidence':summary['evidence'],'starcore':core}))
