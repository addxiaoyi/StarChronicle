from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,time,sys
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/('run/capital-capacity-'+sys.argv[1]+'-20261126');out.mkdir(exist_ok=False)
sha=lambda path:hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
old=root/'run/capital-capacity-baseline-20261126/starcore-1.0.0.jar';current=native/'target/starcore-1.0.0.jar'
cp=lambda jar:';'.join(str(p) for p in [jar,out])
probe=root/'run/CapitalCapacityProbe.java';shutil.copy2(probe,out/probe.name)
args=out/'compile.args';args.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp(old),'-d',out,probe])+'\n')
p=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(args)],capture_output=True);(out/'compile.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
nations=200_000;total=nations*2
def uid(high,low):return f'{high>>32:08x}-{high>>16&65535:04x}-{high&65535:04x}-{low>>48:04x}-{low&((1<<48)-1):012x}'
seed=out/'seed.log'
with seed.open('w',encoding='ascii',newline='\n',buffering=1024*1024) as f:
 for seq in range(1,total+1):
  nation=(seq-1)%nations+1;first=seq<=nations
  f.write(f'{seq}|{uid(2,seq)}|{uid(3,nation)}|{"-" if first else uid(1,1)}|{uid(1,1 if first else 2)}|{uid(4,1 if first else 2)}|1795651200123\n')
 f.write('x'*(1024*1024))
seed_hash=sha(seed);seed_bytes=seed.stat().st_size
for name in ('old','current'):
 (out/name).mkdir();shutil.copy2(seed,out/name/'capital.log')
def run(label,jar,folder,success):
 argfile=out/(label+'.args');argfile.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-Xmx32m','-Xss512k','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-XX:TieredStopAtLevel=1','-XX:ReservedCodeCacheSize=24m','-XX:CompressedClassSpaceSize=16m','-Dfile.encoding=UTF-8','-cp',cp(jar),'dev.starcore.starcore.module.nation.CapitalCapacityProbe',out/folder/'capital.log',nations])+'\n')
 start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:p=subprocess.run([str(java/'java.exe'),'@'+str(argfile)],stdout=log,stderr=subprocess.STDOUT)
 text=(out/(label+'.log')).read_text(encoding='utf-8',errors='replace');result={'exit_code':p.returncode,'seconds':time.monotonic()-start,'command_file':argfile.name}
 (out/(label+'.json')).write_text(json.dumps(result,indent=2))
 if success:assert p.returncode==0 and 'CAPITAL_CAPACITY_OK' in text,(label,result)
 else:assert p.returncode!=0 and 'OutOfMemoryError' in text,(label,result)
 return result
control=run('old-control',old,'old',False);assert sha(out/'old/capital.log')==seed_hash
assert not (out/'old/capital.log.sqlite').exists() and not (out/'old/capital.log.legacy').exists()
upgrade=run('current-migrate',current,'current',True)
assert sha(out/'current/capital.log.legacy')==seed_hash
database=out/'current/capital.log.sqlite'
def database_facts():
 with sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
  authority=db.execute('SELECT * FROM authority').fetchall();assert authority[0][3]==total
  assert authority[0][4]==seed_hash
  assert db.execute('SELECT count(*),count(DISTINCT operation),count(DISTINCT nation) FROM designations').fetchone()==(total,total,nations)
  assert db.execute("SELECT count(*) FROM designations WHERE committed_at<>'2026-11-26T00:00:00.123Z'").fetchone()[0]==0
  fingerprint=hashlib.sha256()
  for row in db.execute('SELECT * FROM designations ORDER BY sequence'):fingerprint.update(json.dumps(row,separators=(',',':')).encode())
  return {'authority':authority,'records_sha256':fingerprint.hexdigest()}
before=database_facts();files={p.name:sha(p) for p in (out/'current').glob('capital.log*')}
reopen=run('current-reopen',current,'current',True)
assert database_facts()==before and files=={p.name:sha(p) for p in (out/'current').glob('capital.log*')}
summary={'status':'VERIFIED','records':total,'nations':nations,'heap_mib':32,'legacy_bytes':seed_bytes,'legacy_sha256':seed_hash,'partial_tail_bytes':1024*1024,'old_jar_sha256':sha(old),'new_jar_sha256':sha(current),'old_control':control,'migration':upgrade,'reopen':reopen,'database':before,'limits':'Synthetic canonical legacy rows over packaged real SQLite store, fixed heap and serialized processes. Disk space and elapsed time grow with history; no server or long-duration concurrency acceptance.'}
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
