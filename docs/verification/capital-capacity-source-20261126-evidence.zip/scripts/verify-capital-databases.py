from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,zipfile,sys
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/('run/capital-databases-'+sys.argv[1]+'-20261126');out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
archive=root/'docs/verification/capital-history-linux-20261126-evidence.zip'
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('evidence-manifest.json'))
 assert set(z.namelist())==set(manifest)|{'evidence-manifest.json'}
 for name,digest in manifest.items():assert sha(z.read(name))==digest,name
 prefix='paper-capital-00922cb5-20261126-1/evidence/boot3.data/'
 for name in z.namelist():
  if name.startswith(prefix) and ('chronicle.db' in name or 'capital-designations.log' in name):
   dest=out/'raw'/name[len(prefix):];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
def backup(source,destination):
 with sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True) as db,sqlite3.connect(destination) as copy:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',);db.backup(copy)
def snapshot(path,previous=None):
 with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
  result={}
  for (table,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
   q='"'+table.replace('"','""')+'"'
   cols=previous[table]['columns'] if previous and table in previous else [r[1] for r in db.execute('PRAGMA table_info('+q+')')]
   rows=sorted(json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in db.execute('SELECT '+','.join('"'+c.replace('"','""')+'"' for c in cols)+' FROM '+q))
   result[table]={'columns':cols,'count':len(rows),'sha256':sha(json.dumps(rows,ensure_ascii=False).encode())}
  return result
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
product=root/'target/starchronicle-0.1.0-SNAPSHOT.jar';core=native/'target/starcore-1.0.0.jar'
baseline=root/'run/github-capital-merge-baseline-20261126'
libraries=sorted((root/'run/paper-epic-1faf2ba2-dungeon-phases-2/libraries').rglob('*.jar'))
def cp(old=False):return ';'.join(str(p) for p in ([baseline/product.name,baseline/core.name] if old else [product,core])+libraries+[out])
probe=root/'run/CapitalMergeProbe.java';shutil.copy2(probe,out/probe.name)
argfile=out/'compile.args';argfile.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp(True),'-d',out,probe])+'\n',encoding='utf-8')
p=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(argfile)],capture_output=True);(out/'compile.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,'compile'
def run(name,mode,step,old=False):
 dest=out/name;dest.mkdir(exist_ok=True)
 args=dest/(step+'.args');args.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-Dfile.encoding=UTF-8','-cp',cp(old),'io.github.addxiaoyi.starchronicle.integration.CapitalMergeProbe',dest,mode,step])+'\n',encoding='utf-8')
 p=subprocess.run([str(java/'java.exe'),'@'+str(args)],capture_output=True);(dest/(step+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,(name,step)
 return None if step=='refuse' else json.loads(next(line for line in p.stdout.decode().splitlines() if line.startswith('{')))
def check_reopen(before,after):
 assert after['accepted']==0 and after['pending']==0
 for key in ('records','events','cursor','domain','mode'):assert before[key]==after[key],key
seed=run('legacy','legacy','seed',True)
assert seed['accepted']==seed['cursor']==seed['events']==260
original=(out/'legacy/capital-designations.log').read_bytes();assert original.endswith(b'uncommitted-tail')
old_chronicle=snapshot(out/'legacy/chronicle.db');(out/'legacy/before.json').write_text(json.dumps(old_chronicle,indent=2))
upgraded=run('legacy','legacy','upgrade');check_reopen(seed,upgraded)
assert (out/'legacy/capital-designations.log.legacy').read_bytes()==original
assert snapshot(out/'legacy/chronicle.db',old_chronicle)==old_chronicle
assert all(r['committedAt'].endswith('.123Z') for r in upgraded['records'])
reopened=run('legacy','legacy','reopen');check_reopen(upgraded,reopened)
appended=run('legacy','legacy','append');assert appended['accepted']==1 and appended['cursor']==appended['events']==261
assert appended['records'][:-1]==seed['records'] and appended['records'][-1]['committedAt'].endswith('.123456789Z')
check_reopen(appended,run('legacy','legacy','reopen-after-append'))
# A fresh Chronicle follows the independent journal over the same migrated native copy.
(out/'fresh').mkdir()
for p in (out/'legacy').glob('capital-designations.log*'):shutil.copy2(p,out/'fresh'/p.name)
fresh=run('fresh','journal','import');assert fresh['accepted']==fresh['cursor']==fresh['events']==261
assert fresh['records']==appended['records'] and fresh['domain']!=seed['domain']
check_reopen(fresh,run('fresh','journal','reopen'))
# Original upstream three-boot database/fence copies: preserve every original row/column.
(out/'upstream').mkdir()
backup(out/'raw/StarChronicle/chronicle.db',out/'upstream/chronicle.db')
for p in (out/'raw/StarCore/nation').glob('capital-designations.log*'):shutil.copy2(p,out/'upstream'/p.name)
before={name:snapshot(out/'upstream'/name) for name in ('chronicle.db','capital-designations.log.sqlite')}
(out/'upstream/before.json').write_text(json.dumps(before,indent=2))
upstream=run('upstream','journal','upgrade');assert upstream['accepted']==0 and upstream['cursor']==139 and len(upstream['records'])==139
check_reopen(upstream,run('upstream','journal','reopen'))
after={name:snapshot(out/'upstream'/name,previous) for name,previous in before.items()}
for name,tables in before.items():
 for table,rows in tables.items():assert after[name][table]==rows,(name,table)
(out/'upstream/after.json').write_text(json.dumps(after,indent=2))
for case in ('legacy','upstream'):
 before_files={p.name:sha(p.read_bytes()) for p in (out/case).glob('capital-designations.log*')}
 run(case,'legacy','refuse',True)
 assert before_files=={p.name:sha(p.read_bytes()) for p in (out/case).glob('capital-designations.log*')},case
def compact(value):return {k:v for k,v in value.items() if k!='records'}|{'record_count':len(value['records']),'records_sha256':sha(json.dumps(value['records'],sort_keys=True).encode())}
summary={'status':'VERIFIED','chronicle_sha256':sha(product.read_bytes()),'starcore_sha256':sha(core.read_bytes()),'upstream_archive_sha256':sha(archive.read_bytes()),'upstream_manifest_files':len(manifest),
 'legacy':{'seed':compact(seed),'upgrade':compact(upgraded),'append':compact(appended),'original_tables_unchanged_before_append':len(old_chronicle),'legacy_bytes_preserved':len(original)},
 'fresh':compact(fresh),'upstream':compact(upstream)|{'unchanged_original_tables':{k:len(v) for k,v in before.items()}},
 'old_writer_refusal':['legacy','upstream'],'limits':'Disposable copies and serialized JVMs only. Real packaged capital stores with a fixture nation-domain facade, and real packaged Chronicle collectors/coordinator; not a server, NationModule authorization or production upgrade.'}
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
