package dev.starcore.starcore.module.nation;

import dev.starcore.starcore.module.nation.model.NationId;
import java.nio.file.Path;
import java.time.Instant;
import java.util.UUID;

/** Disk migration/startup at a fixed heap; never starts a server or loads Bukkit state. */
public final class CapitalCapacityProbe {
    public static void main(String[] args)throws Exception {
        try(var temp=java.sql.DriverManager.getConnection("jdbc:sqlite:");var s=temp.createStatement();var rows=s.executeQuery("PRAGMA main.journal_mode")) {
            if(!rows.next()||!rows.getString(1).equals("delete"))throw new AssertionError("Scratch SQLite is not a temporary disk database");
        }
        Path path=Path.of(args[0]);int nations=Integer.parseInt(args[1]);long total=2L*nations;
        long started=System.nanoTime();var store=new NationCapitalDesignationStore(path);
        UUID domain=store.authorityDomainId();
        var page=store.after(total-3,100);
        if(page.size()!=3||page.getFirst().sequence()!=total-2||page.getLast().sequence()!=total)throw new AssertionError("Deep page changed");
        NationId selected=NationId.of(new UUID(3,nations/2));
        var current=store.current(selected).orElseThrow();
        if(!current.cityId().equals(new UUID(1,2))||!current.previousCityId().equals(new UUID(1,1)))throw new AssertionError("Current nation chain changed");
        if(!current.committedAt().equals(Instant.ofEpochMilli(1_795_651_200_123L)))throw new AssertionError("Legacy precision changed");
        if(!store.after(total,100).isEmpty())throw new AssertionError("Extra receipt");
        boolean rejected=false;try{store.after(total+1,100);}catch(IllegalStateException expected){rejected=true;}
        if(!rejected)throw new AssertionError("Ahead cursor accepted");
        System.out.printf("CAPITAL_CAPACITY_OK records=%d nations=%d domain=%s maxHeap=%d seconds=%.3f%n",total,nations,domain,Runtime.getRuntime().maxMemory(),(System.nanoTime()-started)/1e9);
    }
}
