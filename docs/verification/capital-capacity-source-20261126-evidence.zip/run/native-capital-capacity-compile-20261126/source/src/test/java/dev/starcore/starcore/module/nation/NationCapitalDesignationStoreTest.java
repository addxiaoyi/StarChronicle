package dev.starcore.starcore.module.nation;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.starcore.starcore.module.nation.model.NationId;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class NationCapitalDesignationStoreTest {
  private static final NationId NATION = NationId.of(uuid(1));
  private static final UUID ACTOR = uuid(2);
  private static final UUID CITY_ONE = uuid(3);
  private static final UUID CITY_TWO = uuid(4);
  private static final Instant COMMITTED_AT = Instant.parse("2026-11-22T02:00:00.123456Z");

  @TempDir Path directory;

  @Test
  void appendIsIdempotentAndRestoresTheCurrentDesignation() throws Exception {
    Path journal = directory.resolve("capital-designations.log");
    NationCapitalDesignationStore first = new NationCapitalDesignationStore(journal);

    var initial = first.append(uuid(10), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    assertEquals(initial, first.append(uuid(10), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT));
    var moved =
        first.append(uuid(11), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT.plusSeconds(1));

    NationCapitalDesignationStore restarted = new NationCapitalDesignationStore(journal);
    assertEquals(first.authorityDomainId(), restarted.authorityDomainId());
    assertEquals(COMMITTED_AT, initial.committedAt());
    assertEquals(initial, restarted.after(0, 1).getFirst());
    assertEquals(moved, restarted.current(NATION).orElseThrow());
    assertEquals(2L, restarted.after(0L, 10).getLast().sequence());
    assertEquals(moved, restarted.after(1L, 10).getFirst());
  }

  @Test
  void operationIdsAndPreviousCapitalAreBoundToCommittedRequests() throws Exception {
    NationCapitalDesignationStore store =
        new NationCapitalDesignationStore(directory.resolve("capital.log"));
    store.append(uuid(20), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);

    assertThrows(
        IllegalStateException.class,
        () -> store.append(uuid(20), NATION, null, CITY_TWO, ACTOR, COMMITTED_AT));
    assertThrows(
        IllegalStateException.class,
        () -> store.append(uuid(21), NATION, null, CITY_TWO, ACTOR, COMMITTED_AT));
  }

  @Test
  void migrationImportsOnlyCompleteLegacyRecordsAndPreservesOriginalBytes() throws Exception {
    Path journal = directory.resolve("capital.log");
    byte[] original =
        (legacyLine(1, uuid(30), null, CITY_ONE) + "2|partial").getBytes(StandardCharsets.US_ASCII);
    Files.write(journal, original);
    NationCapitalDesignationStore store = new NationCapitalDesignationStore(journal);
    assertArrayEquals(original, Files.readAllBytes(directory.resolve("capital.log.legacy")));
    assertTrue(Files.readString(journal).startsWith("STARCORE_CAPITAL_SQLITE_V1|READY|"));
    assertEquals(
        Instant.ofEpochMilli(COMMITTED_AT.toEpochMilli()),
        store.current(NATION).orElseThrow().committedAt());
    NationCapitalDesignationStore restarted = new NationCapitalDesignationStore(journal);
    assertEquals(CITY_ONE, restarted.current(NATION).orElseThrow().cityId());
    assertEquals(
        2L, restarted.append(uuid(31), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT).sequence());
    assertArrayEquals(original, Files.readAllBytes(directory.resolve("capital.log.legacy")));
  }

  @Test
  void longHistoryReadsOnlyTheRequestedPage() throws Exception {
    Path journal = directory.resolve("large-capital.log");
    try (var writer = Files.newBufferedWriter(journal, StandardCharsets.US_ASCII)) {
      UUID previous = null;
      for (int sequence = 1; sequence <= 30_000; sequence++) {
        UUID city = uuid(sequence + 100L);
        writer.write(
            sequence
                + "|"
                + uuid(sequence + 1_000_000L)
                + "|"
                + NATION
                + "|"
                + (previous == null ? "-" : previous)
                + "|"
                + city
                + "|"
                + ACTOR
                + "|"
                + COMMITTED_AT.toEpochMilli()
                + "\n");
        previous = city;
      }
    }

    NationCapitalDesignationStore store = new NationCapitalDesignationStore(journal);
    // Corrupt a distant old row after startup: paging must not scan the lifetime journal.
    sql(journal, "UPDATE designations SET actor='broken' WHERE sequence=1");
    var page = store.after(29_997L, 10);

    assertEquals(3, page.size());
    assertEquals(29_998L, page.getFirst().sequence());
    assertEquals(30_000L, page.getLast().sequence());
  }

  @Test
  void cursorAheadAndMissingCommittedHeadFailClosed() throws Exception {
    Path path = directory.resolve("capital.log");
    var store = new NationCapitalDesignationStore(path);
    assertThrows(IllegalStateException.class, () -> store.after(1, 10));
    store.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    sql(path, "DELETE FROM designations");
    assertThrows(IllegalStateException.class, () -> store.after(0, 10));
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(path));
  }

  @Test
  void missingDatabaseNeverCreatesANewAuthorityOrUsesLegacyAsFallback() throws Exception {
    Path path = directory.resolve("capital.log");
    var store = new NationCapitalDesignationStore(path);
    store.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    Files.delete(database(path));
    assertThrows(IllegalStateException.class, store::authorityDomainId);
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(path));
    assertTrue(Files.notExists(database(path)));
  }

  @Test
  void missingOrReplacedFenceAndChangedDatabaseDomainAreRejected() throws Exception {
    Path path = directory.resolve("capital.log");
    var store = new NationCapitalDesignationStore(path);
    String fence = Files.readString(path);
    Files.delete(path);
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(path));
    Files.writeString(path, fence.replace(storeDomain(fence), UUID.randomUUID().toString()));
    assertThrows(IllegalStateException.class, () -> store.after(0, 10));
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(path));
    Files.writeString(path, fence);
    sql(path, "UPDATE authority SET domain='" + UUID.randomUUID() + "'");
    assertThrows(IllegalStateException.class, store::authorityDomainId);
  }

  @Test
  void failedCommitRollsBackHistoryAndCurrentCityAndRetriedOperationCommitsOnce() throws Exception {
    Path path = directory.resolve("capital.log");
    var store = new NationCapitalDesignationStore(path);
    store.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    sql(
        path,
        "CREATE TRIGGER fail_head BEFORE UPDATE ON authority BEGIN SELECT RAISE(ABORT,'injected"
            + " commit failure'); END");
    assertThrows(
        IllegalStateException.class,
        () -> store.append(uuid(2), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT));
    assertEquals(CITY_ONE, store.current(NATION).orElseThrow().cityId());
    assertEquals(1, store.after(0, 10).size());
    sql(path, "DROP TRIGGER fail_head");
    var next = store.append(uuid(2), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT);
    assertEquals(2, next.sequence());
    assertEquals(next, store.append(uuid(2), NATION, CITY_TWO, CITY_TWO, ACTOR, Instant.now()));
  }

  @Test
  void separateStoresSerializeWritesAndNeverUseStaleCachedCapitals() throws Exception {
    Path path = directory.resolve("capital.log");
    var first = new NationCapitalDesignationStore(path);
    var second = new NationCapitalDesignationStore(path);
    var initial = first.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    assertEquals(initial, second.current(NATION).orElseThrow());
    assertThrows(
        IllegalStateException.class,
        () -> second.append(uuid(2), NATION, null, CITY_TWO, ACTOR, COMMITTED_AT));
    var moved =
        second.append(uuid(2), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT.minusSeconds(1));
    assertEquals(moved, first.current(NATION).orElseThrow());
    assertEquals(
        first.authorityDomainId(), first.changesAfter(1, 1).getFirst().authorityDomainId());
    assertEquals(moved, first.changesAfter(1, 1).getFirst().designation());
  }

  @Test
  void concurrentDuplicateRequestReturnsOneCommittedOperation() throws Exception {
    Path path = directory.resolve("capital.log");
    var first = new NationCapitalDesignationStore(path);
    var second = new NationCapitalDesignationStore(path);
    try (var pool = java.util.concurrent.Executors.newFixedThreadPool(2)) {
      var gate = new java.util.concurrent.CountDownLatch(1);
      var a =
          pool.submit(
              () -> {
                gate.await();
                return first.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
              });
      var b =
          pool.submit(
              () -> {
                gate.await();
                return second.append(
                    uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT.plusSeconds(1));
              });
      gate.countDown();
      assertEquals(
          a.get(10, java.util.concurrent.TimeUnit.SECONDS),
          b.get(10, java.util.concurrent.TimeUnit.SECONDS));
    }
    assertEquals(1, first.after(0, 10).size());
  }

  @Test
  void completedMigrationResumesAfterFencePublicationInterruptionWithoutReimport()
      throws Exception {
    Path path = directory.resolve("capital.log");
    Files.writeString(path, legacyLine(1, uuid(1), null, CITY_ONE));
    var first = new NationCapitalDesignationStore(path);
    Files.writeString(path, Files.readString(path).replace("|READY|", "|MIGRATING|"));
    var restarted = new NationCapitalDesignationStore(path);
    assertEquals(first.authorityDomainId(), restarted.authorityDomainId());
    assertEquals(1, restarted.after(0, 10).size());
  }

  @Test
  void migrationRejectsBrokenChainAndDuplicateOperationWithoutChangingLegacy() throws Exception {
    Path path = directory.resolve("capital.log");
    for (String invalid :
        java.util.List.of(
            legacyLine(2, uuid(1), null, CITY_ONE),
            legacyLine(1, uuid(1), null, CITY_ONE) + legacyLine(2, uuid(1), CITY_ONE, CITY_TWO),
            legacyLine(1, uuid(1), null, CITY_ONE) + legacyLine(2, uuid(2), null, CITY_TWO))) {
      Files.writeString(path, invalid);
      assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(path));
      assertEquals(invalid, Files.readString(path));
      assertTrue(Files.notExists(database(path)));
    }
  }

  @Test
  void validOlderDatabaseCannotMoveAnAlreadyObservedSourceBackwards() throws Exception {
    Path path = directory.resolve("capital.log");
    var store = new NationCapitalDesignationStore(path);
    store.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    Path backup = directory.resolve("backup.sqlite");
    Files.copy(database(path), backup);
    store.append(uuid(2), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT);
    assertEquals(2, store.after(0, 10).size());
    Files.copy(backup, database(path), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    assertThrows(IllegalStateException.class, store::authorityDomainId);
    var restarted = new NationCapitalDesignationStore(path);
    assertThrows(IllegalStateException.class, () -> restarted.after(2, 10));
  }

  private static String legacyLine(long sequence, UUID operation, UUID previous, UUID city) {
    return sequence
        + "|"
        + operation
        + "|"
        + NATION
        + "|"
        + (previous == null ? "-" : previous)
        + "|"
        + city
        + "|"
        + ACTOR
        + "|"
        + COMMITTED_AT.toEpochMilli()
        + "\n";
  }

  private static String storeDomain(String fence) {
    return fence.split("\\|")[2];
  }

  private static Path database(Path journal) {
    return journal.resolveSibling(journal.getFileName() + ".sqlite");
  }

  private static void sql(Path path, String sql) throws Exception {
    try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database(path));
        var statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  private static UUID uuid(long value) {
    return new UUID(0L, value);
  }

  @Test
  void restoredJournalCannotSilentlyAcceptAnAheadCursorOrTruncatedCommittedTail() throws Exception {
    Path journal = directory.resolve("restored.log");
    var store = new NationCapitalDesignationStore(journal);
    store.append(uuid(1), NATION, null, CITY_ONE, ACTOR, COMMITTED_AT);
    assertThrows(IllegalStateException.class, () -> store.after(2, 10));
    try (var channel = FileChannel.open(journal, StandardOpenOption.WRITE)) {
      channel.truncate(0);
    }
    assertThrows(IllegalStateException.class, () -> store.after(0, 10));
  }

  @Test
  void interleavedNationsKeepTheirOwnPreviousCityAcrossMigrationAndRestart() throws Exception {
    Path journal = directory.resolve("interleaved.log");
    NationId other = NationId.of(uuid(90));
    String history =
        legacyLine(1, uuid(101), null, CITY_ONE)
            + legacyLine(2, uuid(102), null, CITY_TWO).replace(NATION.toString(), other.toString())
            + legacyLine(3, uuid(103), CITY_ONE, CITY_TWO)
            + legacyLine(4, uuid(104), CITY_TWO, CITY_ONE)
                .replace(NATION.toString(), other.toString());
    Files.writeString(journal, history);
    var migrated = new NationCapitalDesignationStore(journal);
    var restarted = new NationCapitalDesignationStore(journal);
    assertEquals(migrated.after(0, 10), restarted.after(0, 10));
    assertEquals(CITY_TWO, restarted.current(NATION).orElseThrow().cityId());
    assertEquals(CITY_ONE, restarted.current(other).orElseThrow().cityId());
    assertEquals(history, Files.readString(directory.resolve("interleaved.log.legacy")));
    sql(journal, "UPDATE designations SET previous_city='" + CITY_TWO + "' WHERE sequence=3");
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(journal));
  }

  @Test
  void arbitrarilyLongIncompleteTailIsArchivedWithoutBecomingARecord() throws Exception {
    Path journal = directory.resolve("large-tail.log");
    Files.writeString(journal, legacyLine(1, uuid(101), null, CITY_ONE));
    try (var output = Files.newOutputStream(journal, StandardOpenOption.APPEND)) {
      byte[] chunk = "x".repeat(8192).getBytes(StandardCharsets.US_ASCII);
      for (int i = 0; i < 64; i++) output.write(chunk);
    }
    Path original = directory.resolve("original.log");
    Files.copy(journal, original);
    var migrated = new NationCapitalDesignationStore(journal);
    assertEquals(1, migrated.after(0, 10).size());
    assertEquals(-1, Files.mismatch(original, directory.resolve("large-tail.log.legacy")));
    assertEquals(
        2, migrated.append(uuid(102), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT).sequence());
  }

  @Test
  void overlongCompleteRecordIsRejectedBeforePublishingAnyMigrationFiles() throws Exception {
    Path journal = directory.resolve("invalid-long.log");
    // Numerically parseable but never produced by the canonical old writer.
    String original = "0".repeat(1024) + legacyLine(1, uuid(101), null, CITY_ONE);
    Files.writeString(journal, original);
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(journal));
    assertEquals(original, Files.readString(journal));
    assertTrue(Files.notExists(database(journal)));
    assertTrue(Files.notExists(directory.resolve("invalid-long.log.legacy")));
  }

  @Test
  void distantRepeatedOperationIsRejectedBeforeChangingTheOriginalLog() throws Exception {
    Path journal = directory.resolve("distant-duplicate.log");
    try (var writer = Files.newBufferedWriter(journal)) {
      UUID previous = null;
      for (int i = 1; i <= 4097; i++) {
        UUID next = i % 2 == 1 ? CITY_ONE : CITY_TWO;
        writer.write(legacyLine(i, uuid(i == 4097 ? 1 : i), previous, next));
        previous = next;
      }
    }
    Path original = directory.resolve("duplicate-original.log");
    Files.copy(journal, original);
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(journal));
    assertEquals(-1, Files.mismatch(journal, original));
    assertTrue(Files.notExists(database(journal)));
    assertTrue(Files.notExists(directory.resolve("distant-duplicate.log.legacy")));
  }

  @Test
  void conflictingLegacyArchiveIsNotOverwrittenDuringStreamingMigration() throws Exception {
    Path journal = directory.resolve("archive-conflict.log");
    String original = legacyLine(1, uuid(101), null, CITY_ONE);
    Files.writeString(journal, original);
    Path archive = directory.resolve("archive-conflict.log.legacy");
    Files.writeString(archive, original + "unexpected-tail");
    assertThrows(IllegalStateException.class, () -> new NationCapitalDesignationStore(journal));
    assertEquals(original, Files.readString(journal));
    assertEquals(original + "unexpected-tail", Files.readString(archive));
    assertTrue(Files.notExists(database(journal)));
  }

  @Test
  void interruptedMigrationWithoutDatabaseReimportsTheSameDomainAndExactBytes() throws Exception {
    Path journal = directory.resolve("retry.log");
    String original = legacyLine(1, uuid(101), null, CITY_ONE) + "partial";
    Files.writeString(journal, original);
    var first = new NationCapitalDesignationStore(journal);
    UUID domain = first.authorityDomainId();
    Files.writeString(journal, Files.readString(journal).replace("|READY|", "|MIGRATING|"));
    Files.delete(database(journal));
    var resumed = new NationCapitalDesignationStore(journal);
    assertEquals(domain, resumed.authorityDomainId());
    assertEquals(1, resumed.after(0, 10).size());
    assertEquals(original, Files.readString(directory.resolve("retry.log.legacy")));
    assertEquals(
        2, resumed.append(uuid(102), NATION, CITY_ONE, CITY_TWO, ACTOR, COMMITTED_AT).sequence());
  }
}
