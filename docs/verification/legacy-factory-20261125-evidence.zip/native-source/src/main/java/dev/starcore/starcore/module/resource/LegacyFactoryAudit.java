package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

/** Read-only audit of raw legacy fields. A valid shape never certifies a past payment or actor. */
public final class LegacyFactoryAudit {
  private static final Pattern KEY = Pattern.compile("factory\\.(0|[1-9][0-9]*)\\.(.+)");
  private static final Set<String> REQUIRED =
      Set.of("id", "nationId", "name", "type", "buildTime", "level", "efficiency", "operational");
  private static final Set<String> PROCESSING =
      Set.of("recipe", "processingStart", "processingBatches");

  private LegacyFactoryAudit() {}

  public record Metadata(
      UUID factoryId,
      NationId nationId,
      String name,
      NationFactoryService.Type type,
      int level,
      Instant builtAt,
      BigDecimal efficiency,
      boolean operational) {}

  public record Entry(
      String key, Map<String, String> fields, List<String> issues, Metadata metadata) {
    public Entry {
      fields = immutable(fields);
      issues = List.copyOf(issues);
    }
  }

  public record Report(
      String resourceDomain,
      String fingerprint,
      Map<String, String> raw,
      List<String> issues,
      List<Entry> entries) {
    public Report {
      raw = immutable(raw);
      issues = List.copyOf(issues);
      entries = List.copyOf(entries);
    }

    public Optional<Entry> eligible(UUID factory) {
      if (!issues.isEmpty()) return Optional.empty();
      return entries.stream()
          .filter(
              e ->
                  e.issues().isEmpty()
                      && e.metadata() != null
                      && e.metadata().factoryId().equals(factory))
          .findFirst();
    }
  }

  /** Frozen original fields plus the digest of the whole source snapshot and resource domain. */
  public record Evidence(String snapshotHash, String key, Map<String, String> fields) {
    public Evidence {
      if (snapshotHash == null || !snapshotHash.matches("[0-9a-f]{64}"))
        throw new IllegalArgumentException("Invalid legacy snapshot digest");
      index(key);
      fields = immutable(fields);
      if (!parse(key, fields).issues().isEmpty())
        throw new IllegalArgumentException("Legacy record is not eligible for paid registration");
    }

    public Metadata metadata() {
      return parse(key, fields).metadata();
    }
  }

  public static Report inspect(Properties properties) {
    var raw = new TreeMap<String, String>();
    for (String k : properties.stringPropertyNames())
      if (k.startsWith("factory.")) raw.put(k, properties.getProperty(k));
    String domain = properties.getProperty("resource.authority-domain", "");
    var issues = new TreeSet<String>();
    try {
      uuid(domain);
    } catch (RuntimeException e) {
      issues.add("INVALID_RESOURCE_DOMAIN");
    }
    int count = 0;
    if (!raw.isEmpty()) {
      try {
        count = index(raw.get("factory.count"));
      } catch (RuntimeException e) {
        issues.add("INVALID_FACTORY_COUNT");
      }
    }
    var groups = new TreeMap<Integer, Map<String, String>>();
    for (var pair : raw.entrySet()) {
      if (pair.getKey().equals("factory.count")) continue;
      var m = KEY.matcher(pair.getKey());
      try {
        if (!m.matches()) throw new IllegalArgumentException();
        int slot = index(m.group(1));
        groups.computeIfAbsent(slot, ignored -> new TreeMap<>()).put(m.group(2), pair.getValue());
        if (slot >= count) issues.add("ORPHAN_FACTORY_INDEX");
      } catch (RuntimeException e) {
        issues.add("UNKNOWN_FACTORY_KEY");
      }
    }
    // Never allocate or iterate using an untrusted declared count.
    if (groups.size() != count) issues.add("FACTORY_COUNT_MISMATCH");
    var ids = new HashMap<UUID, Integer>();
    for (var fields : groups.values()) {
      try {
        ids.merge(UUID.fromString(fields.get("id")), 1, Integer::sum);
      } catch (RuntimeException ignored) {
        /* Invalid IDs remain in the raw report. */
      }
    }
    var entries = new ArrayList<Entry>();
    groups.forEach(
        (slot, fields) -> {
          var entry = parse(slot.toString(), fields);
          var errors = new TreeSet<>(entry.issues());
          try {
            if (ids.getOrDefault(UUID.fromString(fields.get("id")), 0) > 1)
              errors.add("DUPLICATE_FACTORY_ID");
          } catch (RuntimeException ignored) {
            /* parse already reported it. */
          }
          entries.add(new Entry(entry.key(), fields, List.copyOf(errors), entry.metadata()));
        });
    return new Report(domain, fingerprint(domain, raw), raw, List.copyOf(issues), entries);
  }

  private static Entry parse(String key, Map<String, String> fields) {
    var issues = new TreeSet<String>();
    for (String required : REQUIRED)
      if (!fields.containsKey(required)) issues.add("MISSING_" + required);
    for (String field : fields.keySet())
      if (!REQUIRED.contains(field) && !PROCESSING.contains(field)) issues.add("UNKNOWN_FIELD");
    if (fields.keySet().stream().anyMatch(PROCESSING::contains))
      issues.add("UNRESOLVED_PROCESSING");
    Metadata metadata = null;
    try {
      UUID id = uuid(fields.get("id")), nation = uuid(fields.get("nationId"));
      NationFactoryService.validName(fields.get("name"));
      var type = NationFactoryService.Type.valueOf(fields.get("type"));
      int level = index(fields.get("level"));
      if (level < 1 || level > 10) throw new IllegalArgumentException();
      String time = fields.get("buildTime");
      long millis = Long.parseLong(time);
      if (millis < 0 || !Long.toString(millis).equals(time)) throw new IllegalArgumentException();
      String efficiency = fields.get("efficiency");
      if (efficiency == null || !efficiency.matches("(?:0|1|2)(?:\\.[0-9]+)?"))
        throw new IllegalArgumentException();
      var rate = new BigDecimal(efficiency);
      if (rate.compareTo(new BigDecimal("0.5")) < 0 || rate.compareTo(new BigDecimal("2.0")) > 0)
        throw new IllegalArgumentException();
      String operational = fields.get("operational");
      if (!"true".equals(operational) && !"false".equals(operational))
        throw new IllegalArgumentException();
      metadata =
          new Metadata(
              id,
              NationId.of(nation),
              fields.get("name"),
              type,
              level,
              Instant.ofEpochMilli(millis),
              rate,
              Boolean.parseBoolean(operational));
    } catch (RuntimeException e) {
      issues.add("INVALID_METADATA");
    }
    return new Entry(key, fields, List.copyOf(issues), metadata);
  }

  static UUID uuid(String value) {
    UUID id = UUID.fromString(value);
    if (!id.toString().equals(value)) throw new IllegalArgumentException("Noncanonical UUID");
    return id;
  }

  private static int index(String value) {
    int result = Integer.parseInt(value);
    if (result < 0 || !Integer.toString(result).equals(value))
      throw new IllegalArgumentException("Invalid index");
    return result;
  }

  private static Map<String, String> immutable(Map<String, String> fields) {
    var sorted = new TreeMap<String, String>();
    fields.forEach((k, v) -> sorted.put(Objects.requireNonNull(k), Objects.requireNonNull(v)));
    return Collections.unmodifiableMap(sorted);
  }

  private static String fingerprint(String domain, Map<String, String> raw) {
    try {
      var bytes = new ByteArrayOutputStream();
      var out = new DataOutputStream(bytes);
      text(out, "legacy-factory-audit-v1");
      text(out, domain);
      out.writeInt(raw.size());
      for (var e : raw.entrySet()) {
        text(out, e.getKey());
        text(out, e.getValue());
      }
      return HexFormat.of()
          .formatHex(MessageDigest.getInstance("SHA-256").digest(bytes.toByteArray()));
    } catch (java.io.IOException | java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  // Length-prefixed UTF-16 code units preserve even malformed Unicode without lossy UTF-8
  // replacement.
  private static void text(DataOutputStream out, String value) throws java.io.IOException {
    out.writeInt(value.length());
    for (int i = 0; i < value.length(); i++) out.writeChar(value.charAt(i));
  }
}
