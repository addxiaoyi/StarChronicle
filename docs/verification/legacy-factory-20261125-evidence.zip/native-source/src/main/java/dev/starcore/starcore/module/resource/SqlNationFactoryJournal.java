package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.NationFactoryService.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/** Inventory and infrastructure share the resource writer lock, revision and SQL commit. */
final class SqlNationFactoryJournal {
  private static final String MARKER = "nation-factory-journal-v1";
  private static final String EMPTY_HASH = "0".repeat(64);

  record Version(UUID factoryId, long version) {}

  record Head(
      UUID domain,
      UUID resourceDomain,
      long sequence,
      String hash,
      Map<UUID, Building> buildings,
      Map<UUID, Receipt> operations,
      Map<Version, Change> history) {}

  private SqlNationFactoryJournal() {}

  static void ensureTables(Connection c) throws SQLException {
    try (var s = c.createStatement()) {
      s.execute(
          "CREATE TABLE IF NOT EXISTS starcore_nation_factory_head (singleton INTEGER PRIMARY KEY,"
              + " authority_domain VARCHAR(36) NOT NULL, resource_domain VARCHAR(36) NOT NULL,"
              + " event_sequence BIGINT NOT NULL, prefix_hash VARCHAR(64) NOT NULL)");
      s.execute(
          "CREATE TABLE IF NOT EXISTS starcore_nation_factory_events (event_sequence BIGINT PRIMARY"
              + " KEY, operation_id VARCHAR(36) NOT NULL UNIQUE, factory_id VARCHAR(36) NOT NULL,"
              + " change_json TEXT NOT NULL, entry_hash VARCHAR(64) NOT NULL)");
    }
  }

  static Optional<Head> read(Connection c) throws SQLException {
    boolean marked;
    try (var s =
        c.prepareStatement(
            "SELECT 1 FROM starcore_resource_state_migrations WHERE migration_key=?")) {
      s.setString(1, MARKER);
      try (var r = s.executeQuery()) {
        marked = r.next();
      }
    }
    UUID domain = null, resourceDomain = null;
    long sequence = 0;
    String finalHash = EMPTY_HASH;
    try (var s = c.createStatement();
        var r = s.executeQuery("SELECT * FROM starcore_nation_factory_head")) {
      if (r.next()) {
        if (r.getInt("singleton") != 1) throw new SQLException("Invalid factory head");
        domain = uuid(r.getString("authority_domain"));
        resourceDomain = uuid(r.getString("resource_domain"));
        sequence = r.getLong("event_sequence");
        finalHash = r.getString("prefix_hash");
        if (sequence < 1 || r.next()) throw new SQLException("Invalid factory head sequence");
      }
    }
    if (marked != (domain != null)) throw new SQLException("Factory marker/head mismatch");
    if (domain != null) {
      try (var s =
              c.prepareStatement(
                  "SELECT property_value FROM starcore_resource_state WHERE"
                      + " property_key='resource.authority-domain'");
          var r = s.executeQuery()) {
        if (!r.next() || !resourceDomain.toString().equals(r.getString(1)))
          throw new SQLException("Factory inventory authority changed");
      }
    }
    long seen = 0;
    String prefix = EMPTY_HASH;
    var buildings = new LinkedHashMap<UUID, Building>();
    var operations = new LinkedHashMap<UUID, Receipt>();
    var history = new HashMap<Version, Change>();
    try (var s = c.createStatement();
        var r =
            s.executeQuery(
                "SELECT * FROM starcore_nation_factory_events ORDER BY event_sequence")) {
      while (r.next()) {
        if (domain == null || r.getLong("event_sequence") != ++seen || seen > sequence)
          throw new SQLException("Missing or noncontiguous factory events");
        var change = NationFactoryCodec.decode(r.getString("change_json"));
        var b = change.building();
        if (!b.resourceDomain().equals(resourceDomain)
            || !b.factoryId().toString().equals(r.getString("factory_id"))
            || !change.operationId().toString().equals(r.getString("operation_id")))
          throw new SQLException("Foreign factory identity");
        validate(change, buildings, operations, history);
        prefix = hash(domain, resourceDomain, seen, prefix, change);
        if (!prefix.equals(r.getString("entry_hash")))
          throw new SQLException("Factory event digest mismatch");
        buildings.put(b.factoryId(), b);
        operations.put(change.operationId(), new Receipt(domain, seen, change));
        history.put(new Version(b.factoryId(), b.version()), change);
      }
    }
    if (seen != sequence || !prefix.equals(finalHash))
      throw new SQLException("Factory committed prefix is incomplete");
    return domain == null
        ? Optional.empty()
        : Optional.of(
            new Head(
                domain,
                resourceDomain,
                sequence,
                prefix,
                Collections.unmodifiableMap(buildings),
                Collections.unmodifiableMap(operations),
                Map.copyOf(history)));
  }

  private static void validate(
      Change change,
      Map<UUID, Building> buildings,
      Map<UUID, Receipt> operations,
      Map<Version, Change> history)
      throws SQLException {
    var b = change.building();
    var before = buildings.get(b.factoryId());
    if (operations.containsKey(change.operationId()))
      throw new SQLException("Duplicate factory operation");
    if (before == null) {
      boolean registration = change.action() == Action.REGISTER_LEGACY;
      if ((!registration && change.action() != Action.BUILD)
          || (!registration && !change.operationId().equals(b.factoryId()))
          || !change.actorId().equals(b.builderId())
          || (!registration && b.level() != 1)
          || b.version() != 1
          || b.operational() == registration
          || !b.builtAt().equals(change.committedAt())
          || buildings.values().stream().filter(f -> f.nationId().equals(b.nationId())).count()
              >= MAX_FACTORIES_PER_NATION) throw new SQLException("Invalid factory construction");
      return;
    }
    var previousChange = history.get(new Version(before.factoryId(), before.version()));
    if (change.committedAt().isBefore(previousChange.committedAt())
        || !before.nationId().equals(b.nationId())
        || !before.resourceDomain().equals(b.resourceDomain())
        || !before.builderId().equals(b.builderId())
        || before.origin() != b.origin()
        || before.type() != b.type()
        || !before.name().equals(b.name())
        || !before.builtAt().equals(b.builtAt())
        || b.version() != Math.addExact(before.version(), 1))
      throw new SQLException("Factory identity/version changed");
    boolean valid =
        switch (change.action()) {
          case BUILD, REGISTER_LEGACY -> false;
          case UPGRADE ->
              b.level() == before.level() + 1 && b.operational() == before.operational();
          case SET_OPERATIONAL ->
              b.level() == before.level() && b.operational() != before.operational();
        };
    if (!valid) throw new SQLException("Illegal factory transition");
  }

  static void append(Connection c, Change change) throws SQLException {
    Head head =
        read(c)
            .orElse(
                new Head(
                    UUID.randomUUID(),
                    change.building().resourceDomain(),
                    0,
                    EMPTY_HASH,
                    Map.of(),
                    Map.of(),
                    Map.of()));
    if (!head.resourceDomain().equals(change.building().resourceDomain()))
      throw new SQLException("Factory authority changed");
    validate(change, head.buildings(), head.operations(), head.history());
    long sequence = Math.addExact(head.sequence(), 1);
    String digest = hash(head.domain(), head.resourceDomain(), sequence, head.hash(), change);
    if (head.sequence() == 0) {
      try (var s =
          c.prepareStatement(
              "INSERT INTO"
                  + " starcore_nation_factory_head(singleton,authority_domain,resource_domain,event_sequence,prefix_hash)"
                  + " VALUES(1,?,?,?,?)")) {
        s.setString(1, head.domain().toString());
        s.setString(2, head.resourceDomain().toString());
        s.setLong(3, sequence);
        s.setString(4, digest);
        if (s.executeUpdate() != 1) throw new SQLException("Factory head not inserted");
      }
      try (var s =
          c.prepareStatement(
              "INSERT INTO starcore_resource_state_migrations(migration_key,completed_at)"
                  + " VALUES(?,?)")) {
        s.setString(1, MARKER);
        s.setLong(2, change.committedAt().toEpochMilli());
        s.executeUpdate();
      }
    } else {
      try (var s =
          c.prepareStatement(
              "UPDATE starcore_nation_factory_head SET event_sequence=?,prefix_hash=? WHERE"
                  + " singleton=1 AND event_sequence=? AND prefix_hash=?")) {
        s.setLong(1, sequence);
        s.setString(2, digest);
        s.setLong(3, head.sequence());
        s.setString(4, head.hash());
        if (s.executeUpdate() != 1) throw new SQLException("Factory head changed");
      }
    }
    try (var s =
        c.prepareStatement(
            "INSERT INTO"
                + " starcore_nation_factory_events(event_sequence,operation_id,factory_id,change_json,entry_hash)"
                + " VALUES(?,?,?,?,?)")) {
      s.setLong(1, sequence);
      s.setString(2, change.operationId().toString());
      s.setString(3, change.building().factoryId().toString());
      s.setString(4, NationFactoryCodec.encode(change));
      s.setString(5, digest);
      if (s.executeUpdate() != 1) throw new SQLException("Factory change not inserted");
    }
  }

  static void validateHistoricalBinding(Head head, NationProductionService.Run run)
      throws SQLException {
    var binding = run.factory();
    if (binding == null) return;
    var change =
        head == null
            ? null
            : head.history().get(new Version(binding.factoryId(), binding.version()));
    if (change == null || !head.domain().equals(binding.authorityDomain()))
      throw new SQLException("Missing factory admission history");
    var b = change.building();
    if (!b.nationId().equals(run.nationId())
        || !b.resourceDomain().equals(run.resourceDomain())
        || b.type() != binding.type()
        || b.level() != binding.level()
        || b.origin() != binding.origin()
        || !b.operational()
        || change.committedAt().isAfter(run.startedAt()))
      throw new SQLException("Foreign factory admission history");
  }

  static boolean permits(
      Head head, NationProductionService.Run run, Collection<NationProductionService.RunView> runs)
      throws SQLException {
    if (run.factory() == null) return true;
    validateHistoricalBinding(head, run);
    var binding = run.factory();
    var b = head.buildings().get(binding.factoryId());
    if (b.version() != binding.version() || !b.operational()) return false;
    long count = 0, batches = 0;
    for (var view : runs) {
      var other = view.run().factory();
      if (view.state() == NationProductionService.State.RUNNING
          && other != null
          && other.factoryId().equals(b.factoryId())
          && other.authorityDomain().equals(head.domain())) {
        count++;
        batches = Math.addExact(batches, view.run().batches());
      }
    }
    return count < b.runSlots() && Math.addExact(batches, run.batches()) <= b.batchCapacity();
  }

  private static UUID uuid(String text) throws SQLException {
    UUID id = UUID.fromString(text);
    if (!id.toString().equals(text)) throw new SQLException("Noncanonical factory authority");
    return id;
  }

  private static String hash(
      UUID domain, UUID resourceDomain, long sequence, String previous, Change change) {
    String value =
        domain
            + "\n"
            + resourceDomain
            + "\n"
            + sequence
            + "\n"
            + previous
            + "\n"
            + NationFactoryCodec.encode(change);
    try {
      return HexFormat.of()
          .formatHex(
              MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }
}
