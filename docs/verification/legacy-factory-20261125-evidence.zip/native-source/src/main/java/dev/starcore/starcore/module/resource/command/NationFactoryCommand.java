package dev.starcore.starcore.module.resource.command;

import dev.starcore.starcore.module.resource.NationFactoryService;
import java.util.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/** All mutations are current-founder requests with stable operation IDs and expected versions. */
public final class NationFactoryCommand implements CommandExecutor, TabCompleter {
  private final NationFactoryService service;

  public NationFactoryCommand(NationFactoryService service) {
    this.service = service;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (args.length == 1 && args[0].equalsIgnoreCase("audit")) {
      if (!sender.hasPermission("starcore.nationfactory.audit")) {
        sender.sendMessage("§c你没有全服旧工厂审计权限。");
        return true;
      }
      try {
        var report = service.legacyAudit();
        sender.sendMessage("§6旧工厂原始记录 " + report.entries().size() + "；全局问题 " + report.issues());
        sender.sendMessage("§7审计摘要: " + report.fingerprint());
        var issues = new TreeMap<String, Long>();
        report.entries().forEach(e -> e.issues().forEach(i -> issues.merge(i, 1L, Long::sum)));
        sender.sendMessage("§7记录问题统计: " + issues + "；所有旧付款与原建造人均未证明。");
      } catch (RuntimeException unavailable) {
        sender.sendMessage("§c旧工厂审计暂不可用。");
      }
      return true;
    }
    if (!(sender instanceof Player p)) {
      sender.sendMessage("§c只有玩家可以管理国家工厂。");
      return true;
    }
    if (!p.hasPermission("starcore.nationfactory.use")) {
      p.sendMessage("§c你没有国家工厂命令权限。");
      return true;
    }
    if (args.length == 0) {
      help(p);
      return true;
    }
    UUID operation = null;
    try {
      switch (args[0].toLowerCase(Locale.ROOT)) {
        case "legacy" -> {
          if (args.length > 2) {
            help(p);
            return true;
          }
          int page = args.length == 2 ? Integer.parseInt(args[1]) : 1;
          if (page < 1) throw new IllegalArgumentException();
          var quotes = service.legacyQuotes(p.getUniqueId(), Math.multiplyExact(page - 1, 8), 8);
          if (quotes.isEmpty()) p.sendMessage("§7本页没有可查看的旧工厂，需要当前创始人身份。");
          for (var q : quotes) {
            var e = q.entry();
            var m = e.metadata();
            p.sendMessage(
                "§6旧记录 "
                    + e.key()
                    + (m == null
                        ? "（字段异常）"
                        : " · " + m.name() + " · " + m.factoryId() + " · 等级 " + m.level()));
            p.sendMessage("§7阻止登记原因: " + q.blockers() + "；登记新付款材料: " + q.cost());
            p.sendMessage("§7审计摘要: " + q.snapshotHash());
          }
          p.sendMessage("§e旧付款与原建造人未证明；登记会新收取1至当前等级累计材料，初始停用。");
          p.sendMessage("§7旧效率只保留作审计，新生产使用配方规则；不会自动退款、发货或补贡献。");
        }
        case "registerlegacy" -> {
          if (args.length != 3 && args.length != 4) {
            help(p);
            return true;
          }
          UUID factory = uuid(args[1]);
          if (!args[2].matches("[0-9a-f]{64}")) throw new IllegalArgumentException();
          operation = args.length == 4 ? uuid(args[3]) : UUID.randomUUID();
          p.sendMessage("§7旧工厂付费登记请求ID: " + operation);
          result(p, service.registerLegacy(operation, p.getUniqueId(), factory, args[2]));
        }
        case "plans" -> {
          if (args.length != 1 && args.length != 3) {
            help(p);
            return true;
          }
          int level = args.length == 3 ? Integer.parseInt(args[2]) : 1;
          var types =
              args.length == 3
                  ? List.of(type(args[1]))
                  : List.of(NationFactoryService.Type.values());
          for (var t : types)
            p.sendMessage(
                "§6"
                    + t
                    + " 达到 "
                    + level
                    + " 级材料: "
                    + t.cost(level)
                    + "；容量 "
                    + level
                    + " 个生产、"
                    + (25L * level)
                    + " 批。");
          p.sendMessage("§7每国最多32座工厂，最高10级。建造与升级使用国家库存；国家总产能上限同时生效。");
        }
        case "build" -> {
          if (args.length != 3 && args.length != 4) {
            help(p);
            return true;
          }
          var t = type(args[1]);
          NationFactoryService.validName(args[2]);
          operation = args.length == 4 ? uuid(args[3]) : UUID.randomUUID();
          p.sendMessage("§7工厂ID／建造请求ID: " + operation + "；建造材料 " + t.cost(1));
          result(p, service.build(operation, p.getUniqueId(), t, args[2]));
        }
        case "upgrade", "enable", "disable" -> {
          if (args.length != 3 && args.length != 4) {
            help(p);
            return true;
          }
          UUID factory = uuid(args[1]);
          long version = Long.parseLong(args[2]);
          if (version < 1) throw new IllegalArgumentException();
          operation = args.length == 4 ? uuid(args[3]) : UUID.randomUUID();
          p.sendMessage("§7工厂请求ID: " + operation);
          result(
              p,
              args[0].equalsIgnoreCase("upgrade")
                  ? service.upgrade(operation, p.getUniqueId(), factory, version)
                  : service.setOperational(
                      operation,
                      p.getUniqueId(),
                      factory,
                      version,
                      args[0].equalsIgnoreCase("enable")));
        }
        case "list" -> {
          if (args.length != 1) {
            help(p);
            return true;
          }
          var values = service.buildings(p.getUniqueId(), 32);
          if (values.isEmpty()) p.sendMessage("§7没有可查看的国家工厂，需要当前创始人身份。");
          values.forEach(b -> show(p, b));
        }
        case "show" -> {
          if (args.length != 2) {
            help(p);
            return true;
          }
          var value = service.capacity(uuid(args[1]), p.getUniqueId());
          if (value.isEmpty()) p.sendMessage("§c没有可查看的这个工厂。");
          else {
            var c = value.orElseThrow();
            show(p, c.building());
            p.sendMessage(
                "§7已占用 "
                    + c.runningRuns()
                    + "/"
                    + c.building().runSlots()
                    + " 个生产、"
                    + c.runningBatches()
                    + "/"
                    + c.building().batchCapacity()
                    + " 批。到期未领取的批次仍占用容量。");
          }
        }
        case "operation" -> {
          if (args.length != 2) {
            help(p);
            return true;
          }
          var value = service.operation(uuid(args[1]), p.getUniqueId());
          if (value.isEmpty()) p.sendMessage("§c没有可查看的这个工厂请求。");
          else {
            var c = value.orElseThrow().change();
            p.sendMessage(
                "§6已提交请求 "
                    + c.operationId()
                    + " · "
                    + c.action()
                    + "；实际消耗 "
                    + c.cost()
                    + "；原操作者 "
                    + c.actorId());
            show(p, c.building());
            if (c.legacy() != null)
              p.sendMessage(
                  "§7旧记录索引 "
                      + c.legacy().key()
                      + "；原始快照摘要 "
                      + c.legacy().snapshotHash()
                      + "；本回执只证明本次登记付款，旧建造人未证明。");
          }
        }
        default -> help(p);
      }
    } catch (IllegalArgumentException invalid) {
      p.sendMessage("§c参数无效，请核对类型、等级、版本号和完整UUID。");
    } catch (RuntimeException uncertain) {
      p.sendMessage(
          "§e工厂状态暂不可核对。"
              + (operation == null ? "请稍后重试查询。" : "请保留请求ID " + operation + "，恢复后查询或重试同一请求。"));
    }
    return true;
  }

  private static void show(Player p, NationFactoryService.Building b) {
    p.sendMessage(
        "§6"
            + b.name()
            + " · "
            + b.type()
            + " · 等级 "
            + b.level()
            + " · "
            + (b.operational() ? "启用" : "停用"));
    p.sendMessage("§7工厂ID: " + b.factoryId() + "；版本号 " + b.version());
    if (b.origin() == NationFactoryService.Origin.LEGACY_REGISTERED)
      p.sendMessage("§7来源：旧工厂付费登记；登记人 " + b.builderId() + "；登记时间 " + b.builtAt());
    if (b.level() < 10)
      p.sendMessage("§7升至 " + (b.level() + 1) + " 级材料: " + b.type().cost(b.level() + 1));
  }

  private static void result(Player p, NationFactoryService.Result r) {
    p.sendMessage(
        switch (r.status()) {
          case APPLIED -> "§a工厂请求已提交，材料和工厂状态已共同保存。";
          case ALREADY_APPLIED -> "§7此请求已经完成，没有重复扣除材料。";
          case REJECTED -> "§c请求被拒绝，请核对当前国家创始人身份与请求内容。";
          case CONFLICT -> "§e工厂版本已变化，或旧记录摘要／ID占用已变化，请重新查询后发起操作。";
          case MAX_LEVEL -> "§e工厂已达到最高等级10。";
          case CAPACITY_REACHED -> "§e本国工厂数量已达32座上限。";
          case INSUFFICIENT_ASSETS -> "§c国家库存材料不足，工厂状态未改变。";
          case UNAVAILABLE -> "§c国家工厂暂不可用。";
          case UNKNOWN -> "§e请求结果尚待核对，请用原请求ID查询或重试同一请求。";
        });
  }

  private static NationFactoryService.Type type(String s) {
    return NationFactoryService.Type.valueOf(s.toUpperCase(Locale.ROOT));
  }

  private static UUID uuid(String s) {
    UUID id = UUID.fromString(s);
    if (!id.toString().equals(s)) throw new IllegalArgumentException();
    return id;
  }

  private static void help(Player p) {
    p.sendMessage("§6国家工厂：由当前创始人操作；基础设施记录不会自动放置地图建筑。");
    p.sendMessage("§e/nationfactory plans [类型 目标等级] | list | show <工厂ID> | operation <请求ID>");
    p.sendMessage("§e/nationfactory build <类型> <名称> [原请求ID]");
    p.sendMessage("§e/nationfactory upgrade|enable|disable <工厂ID> <当前版本号> [原请求ID]");
    p.sendMessage("§e/nationfactory legacy [页码] | registerlegacy <旧工厂ID> <审计摘要> [原请求ID]");
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    if (!sender.hasPermission("starcore.nationfactory.use") || args.length == 0) return List.of();
    var choices =
        args.length == 1
            ? List.of(
                "plans",
                "build",
                "upgrade",
                "enable",
                "disable",
                "list",
                "show",
                "operation",
                "legacy",
                "registerlegacy")
            : args.length == 2
                    && (args[0].equalsIgnoreCase("build") || args[0].equalsIgnoreCase("plans"))
                ? Arrays.stream(NationFactoryService.Type.values()).map(Enum::name).toList()
                : List.<String>of();
    return choices.stream()
        .filter(
            v ->
                v.toLowerCase(Locale.ROOT)
                    .startsWith(args[args.length - 1].toLowerCase(Locale.ROOT)))
        .toList();
  }
}
