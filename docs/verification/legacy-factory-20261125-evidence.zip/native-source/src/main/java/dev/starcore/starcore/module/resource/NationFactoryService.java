package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.time.Instant;
import java.util.*;

/** Paid national infrastructure. These records do not place or claim world blocks. */
public interface NationFactoryService {
  enum Type {
    SMELTER(20, 5, 4),
    PROCESSING_PLANT(16, 4, 3),
    CHEMICAL_PLANT(30, 8, 6),
    ASSEMBLY_PLANT(40, 10, 8),
    REFINERY(50, 12, 10),
    INTEGRATED_FACTORY(100, 25, 20);

    private final Map<String, Long> baseCost;

    Type(long mineral, long industrial, long energy) {
      baseCost = Map.of("mineral", mineral, "industrial", industrial, "energy", energy);
    }

    /** Version 1 prices: building level 1, or upgrading to target level, paid exactly once. */
    public Map<String, Long> cost(int targetLevel) {
      level(targetLevel);
      var result = new TreeMap<String, Long>();
      baseCost.forEach((key, amount) -> result.put(key, amount * targetLevel * targetLevel));
      return Collections.unmodifiableMap(result);
    }

    /** Explicit new payment for all levels; legacy metadata supplies no payment credit. */
    public Map<String, Long> registrationCost(int targetLevel) {
      level(targetLevel);
      var total = new TreeMap<String, Long>();
      for (int l = 1; l <= targetLevel; l++)
        cost(l).forEach((k, v) -> total.merge(k, v, Math::addExact));
      return Collections.unmodifiableMap(total);
    }
  }

  enum Action {
    BUILD,
    UPGRADE,
    SET_OPERATIONAL,
    REGISTER_LEGACY
  }

  enum Status {
    APPLIED,
    ALREADY_APPLIED,
    REJECTED,
    CONFLICT,
    MAX_LEVEL,
    CAPACITY_REACHED,
    INSUFFICIENT_ASSETS,
    UNAVAILABLE,
    UNKNOWN
  }

  record Result(Status status, UUID operationId, UUID factoryId) {}

  enum Origin {
    BUILT,
    LEGACY_REGISTERED
  }

  record Building(
      UUID factoryId,
      NationId nationId,
      UUID resourceDomain,
      UUID builderId,
      Type type,
      String name,
      int level,
      boolean operational,
      long version,
      Instant builtAt,
      Origin origin) {
    public Building(
        UUID factoryId,
        NationId nationId,
        UUID resourceDomain,
        UUID builderId,
        Type type,
        String name,
        int level,
        boolean operational,
        long version,
        Instant builtAt) {
      this(
          factoryId,
          nationId,
          resourceDomain,
          builderId,
          type,
          name,
          level,
          operational,
          version,
          builtAt,
          Origin.BUILT);
    }

    public Building {
      Objects.requireNonNull(factoryId);
      Objects.requireNonNull(nationId);
      Objects.requireNonNull(resourceDomain);
      Objects.requireNonNull(builderId);
      Objects.requireNonNull(type);
      Objects.requireNonNull(origin);
      validName(name);
      NationFactoryService.level(level);
      if (version < 1) throw new IllegalArgumentException("Invalid factory version");
      if (origin == Origin.BUILT && version < level)
        throw new IllegalArgumentException("Invalid built factory version");
      NationProductionService.timestamp(builtAt);
    }

    public int runSlots() {
      return level;
    }

    public long batchCapacity() {
      return 25L * level;
    }
  }

  /** Exact post-operation state, price and original caller; no mutable legacy model is trusted. */
  record Change(
      UUID operationId,
      UUID actorId,
      Action action,
      Building building,
      Map<String, Long> cost,
      Instant committedAt,
      LegacyFactoryAudit.Evidence legacy) {
    public Change(
        UUID operationId,
        UUID actorId,
        Action action,
        Building building,
        Map<String, Long> cost,
        Instant committedAt) {
      this(operationId, actorId, action, building, cost, committedAt, null);
    }

    public Change {
      Objects.requireNonNull(operationId);
      Objects.requireNonNull(actorId);
      Objects.requireNonNull(action);
      Objects.requireNonNull(building);
      cost = cost.isEmpty() ? Map.of() : NationProductionService.quantities(cost);
      NationProductionService.timestamp(committedAt);
      if (committedAt.isBefore(building.builtAt()))
        throw new IllegalArgumentException("Factory operation predates construction");
      if ((action == Action.REGISTER_LEGACY) != (legacy != null))
        throw new IllegalArgumentException("Legacy provenance must accompany registration only");
      if (legacy != null) {
        var original = legacy.metadata();
        if (!original.factoryId().equals(building.factoryId())
            || !original.nationId().equals(building.nationId())
            || !original.name().equals(building.name())
            || original.type() != building.type()
            || original.level() != building.level()
            || building.operational()
            || building.origin() != Origin.LEGACY_REGISTERED
            || original.builtAt().isAfter(committedAt))
          throw new IllegalArgumentException("Legacy registration changed source metadata");
      }
      if (action == Action.BUILD && building.origin() != Origin.BUILT)
        throw new IllegalArgumentException("New construction cannot claim legacy origin");
      var expected =
          switch (action) {
            case SET_OPERATIONAL -> Map.<String, Long>of();
            case REGISTER_LEGACY -> building.type().registrationCost(building.level());
            default -> building.type().cost(building.level());
          };
      if (!cost.equals(expected))
        throw new IllegalArgumentException("Invalid version 1 factory price");
    }
  }

  record Receipt(UUID authorityDomain, long sequence, Change change) {
    public Receipt {
      Objects.requireNonNull(authorityDomain);
      Objects.requireNonNull(change);
      if (sequence < 1) throw new IllegalArgumentException("Invalid factory sequence");
    }
  }

  record Requirement(Type type, int minimumLevel) {
    public Requirement {
      Objects.requireNonNull(type);
      level(minimumLevel);
    }
  }

  /** Frozen provenance of a factory admission, retained after upgrades, closure or succession. */
  record Binding(
      UUID authorityDomain,
      UUID factoryId,
      long version,
      Type type,
      int level,
      int minimumLevel,
      Origin origin) {
    public Binding(
        UUID authorityDomain,
        UUID factoryId,
        long version,
        Type type,
        int level,
        int minimumLevel) {
      this(authorityDomain, factoryId, version, type, level, minimumLevel, Origin.BUILT);
    }

    public Binding {
      Objects.requireNonNull(authorityDomain);
      Objects.requireNonNull(factoryId);
      Objects.requireNonNull(type);
      Objects.requireNonNull(origin);
      NationFactoryService.level(level);
      NationFactoryService.level(minimumLevel);
      if (level < minimumLevel || version < 1 || (origin == Origin.BUILT && version < level))
        throw new IllegalArgumentException("Invalid factory admission");
    }
  }

  record Capacity(Building building, long runningRuns, long runningBatches) {}

  record LegacyQuote(
      String snapshotHash,
      LegacyFactoryAudit.Entry entry,
      List<String> blockers,
      Map<String, Long> cost) {
    public LegacyQuote {
      blockers = List.copyOf(blockers);
      cost = Map.copyOf(cost);
    }
  }

  int MAX_FACTORIES_PER_NATION = 32;

  Result build(UUID operationId, UUID actorId, Type type, String name);

  /**
   * Register idle legacy metadata with a new cumulative material payment; starts disabled at v1.
   */
  Result registerLegacy(UUID operationId, UUID actorId, UUID factoryId, String snapshotHash);

  List<LegacyQuote> legacyQuotes(UUID viewer, int offset, int limit);

  /** Trusted operator audit, including malformed records that cannot be assigned to a player. */
  LegacyFactoryAudit.Report legacyAudit();

  Result upgrade(UUID operationId, UUID actorId, UUID factoryId, long expectedVersion);

  Result setOperational(
      UUID operationId, UUID actorId, UUID factoryId, long expectedVersion, boolean enabled);

  Optional<Building> building(UUID factoryId, UUID viewer);

  List<Building> buildings(UUID viewer, int limit);

  Optional<Receipt> operation(UUID operationId, UUID viewer);

  Optional<Capacity> capacity(UUID factoryId, UUID viewer);

  Optional<UUID> authorityDomain();

  List<Receipt> changesAfter(UUID domain, long after, int limit);

  private static void level(int level) {
    if (level < 1 || level > 10) throw new IllegalArgumentException("Factory level must be 1..10");
  }

  static void validName(String name) {
    if (name == null
        || name.isBlank()
        || !name.equals(name.strip())
        || name.length() > 80
        || name.codePoints()
            .anyMatch(
                c -> Character.isISOControl(c) || c == 0x00a7 || (c >= 0xd800 && c <= 0xdfff)))
      throw new IllegalArgumentException("Invalid factory name");
  }
}
