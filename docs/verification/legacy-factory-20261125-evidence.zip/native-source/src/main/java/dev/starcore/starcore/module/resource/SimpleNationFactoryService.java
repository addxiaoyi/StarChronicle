package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.BooleanSupplier;

public final class SimpleNationFactoryService implements NationFactoryService {
  private final ResourceModule resources;
  private final ResourceStateStorage storage;
  private final NationService nations;
  private final Clock clock;
  private final BooleanSupplier ownerThread;

  SimpleNationFactoryService(
      ResourceModule resources,
      ResourceStateStorage storage,
      NationService nations,
      Clock clock,
      BooleanSupplier ownerThread) {
    this.resources = resources;
    this.storage = storage;
    this.nations = nations;
    this.clock = clock;
    this.ownerThread = ownerThread;
  }

  @Override
  public LegacyFactoryAudit.Report legacyAudit() {
    synchronized (resources) {
      if (!available()) throw new IllegalStateException("Legacy audit unavailable");
      var raw = storage.legacyFactoryAudit();
      var entries =
          raw.entries().stream()
              .map(
                  e -> {
                    if (e.metadata() == null
                        || (nations != null
                            && nations.nationById(e.metadata().nationId()).isPresent())) return e;
                    var issues = new ArrayList<>(e.issues());
                    issues.add("UNKNOWN_NATION");
                    return new LegacyFactoryAudit.Entry(e.key(), e.fields(), issues, e.metadata());
                  })
              .toList();
      return new LegacyFactoryAudit.Report(
          raw.resourceDomain(), raw.fingerprint(), raw.raw(), raw.issues(), entries);
    }
  }

  @Override
  public List<LegacyQuote> legacyQuotes(UUID viewer, int offset, int limit) {
    page(offset, limit);
    synchronized (resources) {
      if (!available()) return List.of();
      Nation nation = founder(viewer);
      if (nation == null) return List.of();
      var report = storage.legacyFactoryAudit();
      var head = storage.factoryState().orElse(null);
      return report.entries().stream()
          .filter(e -> nation.id().toString().equals(e.fields().get("nationId")))
          .skip(offset)
          .limit(limit)
          .map(e -> quote(report, e, head))
          .toList();
    }
  }

  private LegacyQuote quote(
      LegacyFactoryAudit.Report report,
      LegacyFactoryAudit.Entry entry,
      SqlNationFactoryJournal.Head head) {
    var blockers = new ArrayList<>(report.issues());
    blockers.addAll(entry.issues());
    var m = entry.metadata();
    if (m != null) {
      if (m.builtAt().isAfter(now())) blockers.add("FUTURE_BUILD_TIME");
      if (head != null && head.buildings().containsKey(m.factoryId()))
        blockers.add("ALREADY_REGISTERED_OR_ID_COLLISION");
      if (head != null
          && head.buildings().values().stream()
                  .filter(b -> b.nationId().equals(m.nationId()))
                  .count()
              >= MAX_FACTORIES_PER_NATION) blockers.add("CAPACITY_REACHED");
    }
    return new LegacyQuote(
        report.fingerprint(),
        entry,
        blockers,
        m == null ? Map.of() : m.type().registrationCost(m.level()));
  }

  @Override
  public Result registerLegacy(UUID id, UUID actor, UUID factory, String fingerprint) {
    Objects.requireNonNull(id);
    synchronized (resources) {
      if (!available()) return result(Status.UNAVAILABLE, id, factory);
      try {
        var head = storage.factoryState().orElse(null);
        var prior = head == null ? null : head.operations().get(id);
        if (prior != null) {
          var c = prior.change();
          return result(
              c.action() == Action.REGISTER_LEGACY
                      && c.actorId().equals(actor)
                      && c.building().factoryId().equals(factory)
                      && c.legacy().snapshotHash().equals(fingerprint)
                  ? Status.ALREADY_APPLIED
                  : Status.REJECTED,
              id,
              factory);
        }
        Nation nation = founder(actor);
        if (nation == null || factory == null) return result(Status.REJECTED, id, factory);
        if (head != null && head.buildings().containsKey(factory))
          return result(Status.CONFLICT, id, factory);
        if (head != null
            && head.buildings().values().stream()
                    .filter(b -> b.nationId().equals(nation.id()))
                    .count()
                >= MAX_FACTORIES_PER_NATION) return result(Status.CAPACITY_REACHED, id, factory);
        var audit = storage.legacyFactoryAudit();
        if (!audit.resourceDomain().equals(resources.authorityDomainId())
            || !audit.fingerprint().equals(fingerprint))
          return result(Status.CONFLICT, id, factory);
        var entry = audit.eligible(factory).orElse(null);
        if (entry == null || !entry.metadata().nationId().equals(nation.id()))
          return result(Status.REJECTED, id, factory);
        var m = entry.metadata();
        Instant now = now();
        var b =
            new Building(
                factory,
                nation.id(),
                UUID.fromString(audit.resourceDomain()),
                actor,
                m.type(),
                m.name(),
                m.level(),
                false,
                1,
                now,
                Origin.LEGACY_REGISTERED);
        return save(
            new Change(
                id,
                actor,
                Action.REGISTER_LEGACY,
                b,
                m.type().registrationCost(m.level()),
                now,
                new LegacyFactoryAudit.Evidence(audit.fingerprint(), entry.key(), entry.fields())));
      } catch (IllegalArgumentException | ArithmeticException invalid) {
        return result(Status.REJECTED, id, factory);
      } catch (RuntimeException uncertain) {
        resources.reconcileTradeState();
        return result(Status.UNKNOWN, id, factory);
      }
    }
  }

  @Override
  public Result build(UUID id, UUID actor, Type type, String name) {
    Objects.requireNonNull(id);
    synchronized (resources) {
      if (!available()) return result(Status.UNAVAILABLE, id, id);
      try {
        var head = storage.factoryState().orElse(null);
        var prior = head == null ? null : head.operations().get(id);
        if (prior != null) {
          var c = prior.change();
          return result(
              c.actorId().equals(actor)
                      && c.action() == Action.BUILD
                      && c.building().type() == type
                      && c.building().name().equals(name)
                  ? Status.ALREADY_APPLIED
                  : Status.REJECTED,
              id,
              id);
        }
        Nation nation = founder(actor);
        if (nation == null || type == null) return result(Status.REJECTED, id, id);
        if (head != null
            && head.buildings().values().stream()
                    .filter(b -> b.nationId().equals(nation.id()))
                    .count()
                >= MAX_FACTORIES_PER_NATION) return result(Status.CAPACITY_REACHED, id, id);
        Instant now = now();
        var b =
            new Building(
                id,
                nation.id(),
                UUID.fromString(resources.authorityDomainId()),
                actor,
                type,
                name,
                1,
                true,
                1,
                now);
        return save(new Change(id, actor, Action.BUILD, b, type.cost(1), now));
      } catch (IllegalArgumentException | ArithmeticException invalid) {
        return result(Status.REJECTED, id, id);
      } catch (RuntimeException uncertain) {
        resources.reconcileTradeState();
        return result(Status.UNKNOWN, id, id);
      }
    }
  }

  @Override
  public Result upgrade(UUID id, UUID actor, UUID factoryId, long expectedVersion) {
    return change(id, actor, factoryId, expectedVersion, Action.UPGRADE, false);
  }

  @Override
  public Result setOperational(
      UUID id, UUID actor, UUID factoryId, long expectedVersion, boolean enabled) {
    return change(id, actor, factoryId, expectedVersion, Action.SET_OPERATIONAL, enabled);
  }

  private Result change(
      UUID id, UUID actor, UUID factoryId, long version, Action action, boolean enabled) {
    Objects.requireNonNull(id);
    synchronized (resources) {
      if (!available()) return result(Status.UNAVAILABLE, id, factoryId);
      try {
        var head = storage.factoryState().orElse(null);
        var prior = head == null ? null : head.operations().get(id);
        if (prior != null) {
          var c = prior.change();
          var b = c.building();
          return result(
              c.actorId().equals(actor)
                      && c.action() == action
                      && b.factoryId().equals(factoryId)
                      && b.version() - 1 == version
                      && (action != Action.SET_OPERATIONAL || b.operational() == enabled)
                  ? Status.ALREADY_APPLIED
                  : Status.REJECTED,
              id,
              factoryId);
        }
        var before = head == null ? null : head.buildings().get(factoryId);
        Nation nation = founder(actor);
        if (before == null
            || nation == null
            || !nation.id().equals(before.nationId())
            || !before.resourceDomain().toString().equals(resources.authorityDomainId()))
          return result(Status.REJECTED, id, factoryId);
        if (version != before.version()) return result(Status.CONFLICT, id, factoryId);
        if (action == Action.UPGRADE && before.level() == 10)
          return result(Status.MAX_LEVEL, id, factoryId);
        if (action == Action.SET_OPERATIONAL && before.operational() == enabled)
          return result(Status.REJECTED, id, factoryId);
        Instant now = now();
        if (now.isBefore(
            head.history()
                .get(new SqlNationFactoryJournal.Version(factoryId, version))
                .committedAt())) return result(Status.UNAVAILABLE, id, factoryId);
        var b =
            new Building(
                factoryId,
                before.nationId(),
                before.resourceDomain(),
                before.builderId(),
                before.type(),
                before.name(),
                action == Action.UPGRADE ? before.level() + 1 : before.level(),
                action == Action.SET_OPERATIONAL ? enabled : before.operational(),
                Math.addExact(version, 1),
                before.builtAt(),
                before.origin());
        return save(
            new Change(
                id,
                actor,
                action,
                b,
                action == Action.UPGRADE ? b.type().cost(b.level()) : Map.of(),
                now));
      } catch (IllegalArgumentException | ArithmeticException invalid) {
        return result(Status.REJECTED, id, factoryId);
      } catch (RuntimeException uncertain) {
        resources.reconcileTradeState();
        return result(Status.UNKNOWN, id, factoryId);
      }
    }
  }

  private Result save(Change change) {
    var b = change.building();
    var snapshot = resources.prepareProductionSnapshot(b.nationId(), change.cost(), Map.of());
    if (snapshot == null)
      return result(Status.INSUFFICIENT_ASSETS, change.operationId(), b.factoryId());
    storage.saveFactory(snapshot, change);
    resources.publishTradeSnapshot(snapshot);
    return result(Status.APPLIED, change.operationId(), b.factoryId());
  }

  private boolean available() {
    return ownerThread.getAsBoolean()
        && storage != null
        && storage.supportsNationFactories()
        && !resources.authorityDomainId().isBlank();
  }

  private Nation founder(UUID actor) {
    if (actor == null || nations == null) return null;
    Nation nation = nations.nationOf(actor).orElse(null);
    return nation != null && nation.hasMember(actor) && nation.isFounder(actor) ? nation : null;
  }

  private boolean visible(Building b, UUID viewer) {
    Nation nation = founder(viewer);
    return nation != null && nation.id().equals(b.nationId());
  }

  @Override
  public Optional<Building> building(UUID id, UUID viewer) {
    synchronized (resources) {
      return storage.factoryState().map(h -> h.buildings().get(id)).filter(b -> visible(b, viewer));
    }
  }

  @Override
  public List<Building> buildings(UUID viewer, int limit) {
    page(0, limit);
    synchronized (resources) {
      return storage
          .factoryState()
          .map(
              h ->
                  h.buildings().values().stream()
                      .filter(b -> visible(b, viewer))
                      .sorted(
                          Comparator.comparing(Building::builtAt)
                              .thenComparing(Building::factoryId))
                      .limit(limit)
                      .toList())
          .orElse(List.of());
    }
  }

  @Override
  public Optional<Receipt> operation(UUID id, UUID viewer) {
    synchronized (resources) {
      return storage
          .factoryState()
          .map(h -> h.operations().get(id))
          .filter(
              r -> r.change().actorId().equals(viewer) || visible(r.change().building(), viewer));
    }
  }

  @Override
  public Optional<Capacity> capacity(UUID id, UUID viewer) {
    synchronized (resources) {
      var head = storage.factoryState().orElse(null);
      var b = head == null ? null : head.buildings().get(id);
      if (b == null || !visible(b, viewer)) return Optional.empty();
      long count = 0, batches = 0;
      for (var v : storage.productionState().map(h -> h.runs().values()).orElse(List.of())) {
        var binding = v.run().factory();
        if (v.state() == NationProductionService.State.RUNNING
            && binding != null
            && binding.factoryId().equals(id)
            && binding.authorityDomain().equals(head.domain())) {
          count++;
          batches = Math.addExact(batches, v.run().batches());
        }
      }
      return Optional.of(new Capacity(b, count, batches));
    }
  }

  @Override
  public Optional<UUID> authorityDomain() {
    synchronized (resources) {
      return storage.factoryState().map(SqlNationFactoryJournal.Head::domain);
    }
  }

  @Override
  public List<Receipt> changesAfter(UUID domain, long after, int limit) {
    Objects.requireNonNull(domain);
    page(after, limit);
    synchronized (resources) {
      var head = storage.factoryState().orElseThrow();
      if (!head.domain().equals(domain) || after > head.sequence())
        throw new IllegalStateException("Factory authority/cursor changed");
      return head.operations().values().stream()
          .filter(r -> r.sequence() > after)
          .limit(limit)
          .toList();
    }
  }

  private static void page(long after, int limit) {
    if (after < 0 || limit < 1 || limit > 100)
      throw new IllegalArgumentException("Invalid factory page");
  }

  private Instant now() {
    return clock.instant().truncatedTo(ChronoUnit.MILLIS);
  }

  private static Result result(Status status, UUID id, UUID factory) {
    return new Result(status, id, factory);
  }
}
