package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.NationFactoryService.*;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.starcore.starcore.module.nation.model.NationId;
import java.time.Instant;
import java.util.*;

final class NationFactoryCodec {
  private NationFactoryCodec() {}

  static String encode(Change change) {
    var j = new JsonObject();
    j.addProperty("format", change.building().origin() == Origin.BUILT ? 1 : 2);
    j.addProperty("operationId", change.operationId().toString());
    j.addProperty("actorId", change.actorId().toString());
    j.addProperty("action", change.action().name());
    Building b = change.building();
    var f = new JsonObject();
    f.addProperty("factoryId", b.factoryId().toString());
    f.addProperty("nationId", b.nationId().toString());
    f.addProperty("resourceDomain", b.resourceDomain().toString());
    f.addProperty("builderId", b.builderId().toString());
    f.addProperty("type", b.type().name());
    f.addProperty("name", b.name());
    f.addProperty("level", b.level());
    f.addProperty("operational", b.operational());
    f.addProperty("version", b.version());
    f.addProperty("builtAt", b.builtAt().toString());
    if (b.origin() != Origin.BUILT) f.addProperty("origin", b.origin().name());
    j.add("building", f);
    var cost = new JsonObject();
    new TreeMap<>(change.cost()).forEach(cost::addProperty);
    j.add("cost", cost);
    j.addProperty("committedAt", change.committedAt().toString());
    if (change.legacy() != null) {
      var legacy = new JsonObject();
      legacy.addProperty("snapshotHash", change.legacy().snapshotHash());
      legacy.addProperty("key", change.legacy().key());
      var fields = new JsonObject();
      new TreeMap<>(change.legacy().fields()).forEach(fields::addProperty);
      legacy.add("fields", fields);
      j.add("legacy", legacy);
    }
    return j.toString();
  }

  static Change decode(String text) {
    var j = JsonParser.parseString(text).getAsJsonObject();
    int format = j.get("format").getAsInt();
    if (format != 1 && format != 2) throw new IllegalStateException("Unknown factory format");
    LegacyFactoryAudit.Evidence legacy = null;
    if (format == 2 && j.has("legacy")) {
      var value = j.getAsJsonObject("legacy");
      var fields = new TreeMap<String, String>();
      value
          .getAsJsonObject("fields")
          .entrySet()
          .forEach(e -> fields.put(e.getKey(), e.getValue().getAsString()));
      legacy =
          new LegacyFactoryAudit.Evidence(
              value.get("snapshotHash").getAsString(), value.get("key").getAsString(), fields);
    }
    var f = j.getAsJsonObject("building");
    var cost = new TreeMap<String, Long>();
    j.getAsJsonObject("cost")
        .entrySet()
        .forEach(e -> cost.put(e.getKey(), e.getValue().getAsBigDecimal().longValueExact()));
    var b =
        new Building(
            UUID.fromString(f.get("factoryId").getAsString()),
            NationId.of(UUID.fromString(f.get("nationId").getAsString())),
            UUID.fromString(f.get("resourceDomain").getAsString()),
            UUID.fromString(f.get("builderId").getAsString()),
            Type.valueOf(f.get("type").getAsString()),
            f.get("name").getAsString(),
            f.get("level").getAsBigDecimal().intValueExact(),
            f.get("operational").getAsBoolean(),
            f.get("version").getAsBigDecimal().longValueExact(),
            Instant.parse(f.get("builtAt").getAsString()),
            format == 1 ? Origin.BUILT : Origin.valueOf(f.get("origin").getAsString()));
    var change =
        new Change(
            UUID.fromString(j.get("operationId").getAsString()),
            UUID.fromString(j.get("actorId").getAsString()),
            Action.valueOf(j.get("action").getAsString()),
            b,
            cost,
            Instant.parse(j.get("committedAt").getAsString()),
            legacy);
    if (!encode(change).equals(text))
      throw new IllegalStateException("Noncanonical factory change");
    return change;
  }

  static JsonObject encodeBinding(Binding b) {
    var j = new JsonObject();
    j.addProperty("authorityDomain", b.authorityDomain().toString());
    j.addProperty("factoryId", b.factoryId().toString());
    j.addProperty("version", b.version());
    j.addProperty("type", b.type().name());
    j.addProperty("level", b.level());
    j.addProperty("minimumLevel", b.minimumLevel());
    if (b.origin() != Origin.BUILT) j.addProperty("origin", b.origin().name());
    return j;
  }

  static Binding decodeBinding(JsonObject j) {
    return new Binding(
        UUID.fromString(j.get("authorityDomain").getAsString()),
        UUID.fromString(j.get("factoryId").getAsString()),
        j.get("version").getAsBigDecimal().longValueExact(),
        Type.valueOf(j.get("type").getAsString()),
        j.get("level").getAsBigDecimal().intValueExact(),
        j.get("minimumLevel").getAsBigDecimal().intValueExact(),
        j.has("origin") ? Origin.valueOf(j.get("origin").getAsString()) : Origin.BUILT);
  }
}
