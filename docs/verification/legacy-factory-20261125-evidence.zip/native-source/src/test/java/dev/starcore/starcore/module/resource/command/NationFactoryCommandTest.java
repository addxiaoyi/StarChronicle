package dev.starcore.starcore.module.resource.command;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.module.resource.NationFactoryService;
import java.util.UUID;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class NationFactoryCommandTest {
  final NationFactoryService service = mock(NationFactoryService.class);
  final NationFactoryCommand command = new NationFactoryCommand(service);
  final Player player = mock(Player.class);
  final UUID actor = UUID.randomUUID();

  void run(CommandSender sender, String... args) {
    command.onCommand(sender, mock(Command.class), "nationfactory", args);
  }

  void authorized() {
    when(player.hasPermission("starcore.nationfactory.use")).thenReturn(true);
    when(player.getUniqueId()).thenReturn(actor);
  }

  @Test
  void consoleAndMissingPermissionCannotCallService() {
    run(mock(CommandSender.class), "build", "SMELTER", "Forge");
    run(player, "build", "SMELTER", "Forge");
    verifyNoInteractions(service);
  }

  @Test
  void buildAndUpgradeUseExplicitIdVersionAndAuthenticatedPlayer() {
    authorized();
    UUID factory = UUID.randomUUID(), operation = UUID.randomUUID();
    when(service.build(factory, actor, NationFactoryService.Type.SMELTER, "Forge"))
        .thenReturn(
            new NationFactoryService.Result(NationFactoryService.Status.APPLIED, factory, factory));
    run(player, "build", "smelter", "Forge", factory.toString());
    verify(service).build(factory, actor, NationFactoryService.Type.SMELTER, "Forge");
    when(service.upgrade(operation, actor, factory, 2))
        .thenReturn(
            new NationFactoryService.Result(
                NationFactoryService.Status.CONFLICT, operation, factory));
    run(player, "upgrade", factory.toString(), "2", operation.toString());
    verify(service).upgrade(operation, actor, factory, 2);
    verify(player).sendMessage(contains("工厂版本已变化"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"0", "-1", "1.5", "1e2", "999999999999999999999"})
  void invalidVersionsNeverReachFactoryMutation(String version) {
    authorized();
    run(player, "disable", UUID.randomUUID().toString(), version);
    verifyNoInteractions(service);
  }

  @Test
  void disableAndReplayKeepSameOperationIdAndDoNotUseConsoleAuthority() {
    authorized();
    UUID factory = UUID.randomUUID(), operation = UUID.randomUUID();
    when(service.setOperational(operation, actor, factory, 2, false))
        .thenReturn(
            new NationFactoryService.Result(
                NationFactoryService.Status.UNKNOWN, operation, factory));
    run(player, "disable", factory.toString(), "2", operation.toString());
    verify(service).setOperational(operation, actor, factory, 2, false);
    verify(player).sendMessage(contains(operation.toString()));
    verify(player).sendMessage(contains("原请求ID"));
  }

  @Test
  void pricePreviewHasNoMutationAndShowsTargetLevelCapacity() {
    authorized();
    run(player, "plans", "SMELTER", "2");
    verifyNoInteractions(service);
    verify(player).sendMessage(contains("容量 2 个生产、50 批"));
  }

  @Test
  void legacyRegistrationBindsExplicitSourceDigestActorAndRequestId() {
    authorized();
    UUID factory = UUID.randomUUID(), request = UUID.randomUUID();
    String hash = "f".repeat(64);
    when(service.registerLegacy(request, actor, factory, hash))
        .thenReturn(
            new NationFactoryService.Result(NationFactoryService.Status.APPLIED, request, factory));
    run(player, "registerlegacy", factory.toString(), hash, request.toString());
    verify(service).registerLegacy(request, actor, factory, hash);
    verifyNoMoreInteractions(service);
  }

  @Test
  void legacyQuoteIsReadOnlyAndWarnsAboutNewCumulativePayment() {
    authorized();
    run(player, "legacy", "2");
    verify(service).legacyQuotes(actor, 8, 8);
    verifyNoMoreInteractions(service);
    verify(player).sendMessage(contains("登记会新收取1至当前等级累计材料"));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"abc", "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF", "-1"})
  void invalidLegacyFingerprintCannotReachMutation(String hash) {
    authorized();
    run(player, "registerlegacy", UUID.randomUUID().toString(), hash);
    verifyNoInteractions(service);
  }

  @Test
  void globalAuditRequiresSeparatePermissionAndNeverGrantsConsoleRegistration() {
    var console = mock(CommandSender.class);
    run(console, "audit");
    verifyNoInteractions(service);
    when(console.hasPermission("starcore.nationfactory.audit")).thenReturn(true);
    when(service.legacyAudit())
        .thenReturn(
            dev.starcore.starcore.module.resource.LegacyFactoryAudit.inspect(
                new java.util.Properties()));
    run(console, "audit");
    run(console, "registerlegacy", UUID.randomUUID().toString(), "a".repeat(64));
    verify(service).legacyAudit();
    verifyNoMoreInteractions(service);
  }
}
