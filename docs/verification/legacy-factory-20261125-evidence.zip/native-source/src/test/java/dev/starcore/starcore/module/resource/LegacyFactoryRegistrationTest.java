package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.NationFactoryService.Status.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.module.nation.model.Nation;
import java.nio.file.Path;
import java.util.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class LegacyFactoryRegistrationTest {
  @TempDir Path directory;
  // Reuse the existing real-SQLite fixture and commit-acknowledgement fault injection.
  final NationFactorySettlementTest f = new NationFactorySettlementTest();
  final UUID factory = LegacyFactoryAuditTest.FACTORY;
  Properties legacy;

  @BeforeEach
  void setup() throws Exception {
    f.directory = directory;
    f.setup();
    legacy = LegacyFactoryAuditTest.legacy();
    legacy.remove("resource.authority-domain");
    legacy.setProperty("factory.0.nationId", f.nation.id().toString());
    for (String k : legacy.stringPropertyNames()) set(k, legacy.getProperty(k));
    f.current = f.bundle();
  }

  @AfterEach
  void close() {
    f.shutdown();
  }

  void set(String key, String value) throws Exception {
    try (var c = f.sqlite.getConnection();
        var s =
            c.prepareStatement(
                "INSERT INTO starcore_resource_state(property_key,property_value) VALUES(?,?) ON"
                    + " CONFLICT(property_key) DO UPDATE SET"
                    + " property_value=excluded.property_value")) {
      s.setString(1, key);
      s.setString(2, value);
      s.executeUpdate();
    }
  }

  String fingerprint() {
    return f.current.factories().legacyAudit().fingerprint();
  }

  NationFactoryService.Result register(UUID request, String hash) {
    return f.current.factories().registerLegacy(request, f.actor, factory, hash);
  }

  @Test
  void paidRegistrationRetainsRawProvenanceAndRestartsDisabledWithoutInventingPastBuilder()
      throws Exception {
    UUID request = UUID.randomUUID();
    String hash = fingerprint();
    var before = f.database();
    var quote = f.current.factories().legacyQuotes(f.actor, 0, 10).getFirst();
    assertThat(quote.blockers()).isEmpty();
    assertThat(quote.cost()).isEqualTo(Map.of("mineral", 280L, "energy", 56L, "industrial", 70L));
    assertThat(f.database()).isEqualTo(before);
    assertThat(register(request, hash).status()).isEqualTo(APPLIED);
    f.assets(9720, 9944, 9930);
    f.current = f.bundle();
    var b = f.current.factories().building(factory, f.actor).orElseThrow();
    assertThat(b.origin()).isEqualTo(NationFactoryService.Origin.LEGACY_REGISTERED);
    assertThat(b.level()).isEqualTo(3);
    assertThat(b.version()).isEqualTo(1);
    assertThat(b.operational()).isFalse();
    assertThat(b.builderId()).isEqualTo(f.actor);
    assertThat(b.builtAt()).isEqualTo(f.time);
    var change = f.current.factories().operation(request, f.actor).orElseThrow().change();
    assertThat(change.legacy().fields())
        .containsEntry("buildTime", "1700000000000")
        .containsEntry("efficiency", "1.1");
    assertThat(f.current.factories().legacyAudit().raw())
        .containsAllEntriesOf(
            legacy.entrySet().stream()
                .collect(
                    java.util.stream.Collectors.toMap(
                        e -> e.getKey().toString(), e -> e.getValue().toString())));
    var committed = f.database();
    assertThat(register(request, hash).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(register(UUID.randomUUID(), hash).status()).isEqualTo(CONFLICT);
    assertThat(f.database()).isEqualTo(committed);
    assertThat(f.current.factories().legacyQuotes(f.actor, 0, 10).getFirst().blockers())
        .contains("ALREADY_REGISTERED_OR_ID_COLLISION");
  }

  @Test
  void registeredFactoryEnablesUpgradesAndProducesWithNewActorAndFrozenHistory() {
    assertThat(register(UUID.randomUUID(), fingerprint()).status()).isEqualTo(APPLIED);
    UUID run = UUID.randomUUID();
    assertThat(f.current.production().start(run, f.actor, "factory_refining", 1, factory).status())
        .isEqualTo(NationProductionService.Status.FACTORY_UNAVAILABLE);
    assertThat(
            f.current
                .factories()
                .setOperational(UUID.randomUUID(), f.actor, factory, 1, true)
                .status())
        .isEqualTo(APPLIED);
    f.start(factory, 1);
    assertThat(f.current.factories().upgrade(UUID.randomUUID(), f.actor, factory, 2).status())
        .isEqualTo(APPLIED);
    f.current = f.bundle();
    var b = f.current.factories().building(factory, f.actor).orElseThrow();
    assertThat(b.level()).isEqualTo(4);
    assertThat(b.version()).isEqualTo(3);
    assertThat(b.origin()).isEqualTo(NationFactoryService.Origin.LEGACY_REGISTERED);
    f.assets(9397, 9879, 9850);
    assertThat(
            f.current
                .factories()
                .changesAfter(f.current.factories().authorityDomain().orElseThrow(), 0, 100))
        .hasSize(3);
  }

  @Test
  void changedArgumentsAndSuccessionCannotRebindRegistrationOrPastPayment() throws Exception {
    UUID request = UUID.randomUUID();
    String hash = fingerprint();
    assertThat(register(request, hash).status()).isEqualTo(APPLIED);
    var replacement = new Nation(f.nation.id(), "Factories", f.successor, "successor");
    when(f.nations.nationOf(f.actor)).thenReturn(Optional.empty());
    when(f.nations.nationOf(f.successor)).thenReturn(Optional.of(replacement));
    var before = f.database();
    assertThat(register(request, hash).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(register(request, "0".repeat(64)).status()).isEqualTo(REJECTED);
    assertThat(f.current.factories().registerLegacy(request, f.successor, factory, hash).status())
        .isEqualTo(REJECTED);
    assertThat(
            f.current
                .factories()
                .registerLegacy(request, f.actor, UUID.randomUUID(), hash)
                .status())
        .isEqualTo(REJECTED);
    assertThat(f.current.factories().legacyQuotes(f.actor, 0, 10)).isEmpty();
    assertThat(f.current.factories().building(factory, f.actor)).isEmpty();
    assertThat(f.current.factories().operation(request, f.actor)).isPresent();
    assertThat(f.current.factories().building(factory, f.successor).orElseThrow().builderId())
        .isEqualTo(f.actor);
    assertThat(f.database()).isEqualTo(before);
  }

  @Test
  void unauthorizedInsufficientAndStaleQuotesDoNotChangeAnything() throws Exception {
    String hash = fingerprint();
    var before = f.database();
    assertThat(
            f.current
                .factories()
                .registerLegacy(UUID.randomUUID(), f.successor, factory, hash)
                .status())
        .isEqualTo(REJECTED);
    assertThat(register(UUID.randomUUID(), "0".repeat(64)).status()).isEqualTo(CONFLICT);
    assertThat(f.database()).isEqualTo(before);
    assertThat(f.current.resources().consume(f.nation.id(), "mineral", 10000)).isTrue();
    before = f.database();
    assertThat(register(UUID.randomUUID(), hash).status()).isEqualTo(INSUFFICIENT_ASSETS);
    assertThat(f.database()).isEqualTo(before);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"processing", "duplicate", "unknown", "foreign", "future", "clamped", "orphan"})
  void quarantinedRecordsCannotCreateAssets(String defect) throws Exception {
    switch (defect) {
      case "processing" -> set("factory.0.recipe", "old");
      case "unknown" -> set("factory.0.extra", "unrecognized");
      case "foreign" -> set("factory.0.nationId", UUID.randomUUID().toString());
      case "future" ->
          set("factory.0.buildTime", Long.toString(f.time.plusSeconds(1).toEpochMilli()));
      case "clamped" -> set("factory.0.level", "99");
      case "orphan" -> set("factory.count", "0");
      case "duplicate" -> {
        set("factory.count", "2");
        for (String k : legacy.stringPropertyNames())
          if (k.startsWith("factory.0."))
            set(k.replace("factory.0.", "factory.1."), legacy.getProperty(k));
      }
    }
    f.current = f.bundle();
    var before = f.database();
    assertThat(register(UUID.randomUUID(), fingerprint()).status()).isEqualTo(REJECTED);
    assertThat(f.database()).isEqualTo(before);
    f.assets(10000, 10000, 10000);
    assertThat(f.current.factories().buildings(f.actor, 100)).isEmpty();
    assertThat(f.current.storage().productionState()).isEmpty();
  }

  @Test
  void sourceChangedAfterQuoteIsRejectedAndQuoteReadDoesNotRebaseStaleInventory() throws Exception {
    String hash = fingerprint();
    set("factory.0.name", "Changed");
    var before = f.database();
    assertThat(register(UUID.randomUUID(), hash).status()).isEqualTo(CONFLICT);
    assertThat(f.database()).isEqualTo(before);
    f.current = f.bundle();
    hash = fingerprint();
    var other = f.bundle();
    assertThat(other.resources().grant(f.nation.id(), "mineral", 7)).isTrue();
    before = f.database();
    assertThat(register(UUID.randomUUID(), hash).status()).isEqualTo(UNKNOWN);
    assertThat(f.database()).isEqualTo(before);
    f.assets(10007, 10000, 10000);
    assertThat(register(UUID.randomUUID(), hash).status()).isEqualTo(APPLIED);
    f.assets(9727, 9944, 9930);
  }

  @Test
  void sqlRechecksSourceAndRequiresExactNewPayment() throws Exception {
    var quote = f.current.factories().legacyQuotes(f.actor, 0, 10).getFirst();
    var m = quote.entry().metadata();
    var building =
        new NationFactoryService.Building(
            factory,
            f.nation.id(),
            UUID.fromString(f.current.resources().authorityDomainId()),
            f.actor,
            m.type(),
            m.name(),
            3,
            false,
            1,
            f.time,
            NationFactoryService.Origin.LEGACY_REGISTERED);
    var change =
        new NationFactoryService.Change(
            UUID.randomUUID(),
            f.actor,
            NationFactoryService.Action.REGISTER_LEGACY,
            building,
            quote.cost(),
            f.time,
            new LegacyFactoryAudit.Evidence(
                quote.snapshotHash(), quote.entry().key(), quote.entry().fields()));
    var paid =
        f.current.resources().prepareProductionSnapshot(f.nation.id(), quote.cost(), Map.of());
    var unpaid = f.current.resources().prepareProductionSnapshot(f.nation.id(), Map.of(), Map.of());
    var before = f.database();
    assertThatThrownBy(() -> f.current.storage().saveFactory(unpaid, change))
        .isInstanceOf(IllegalStateException.class);
    assertThat(f.database()).isEqualTo(before);
    set("factory.0.operational", "false");
    before = f.database();
    assertThatThrownBy(() -> f.current.storage().saveFactory(paid, change))
        .isInstanceOf(IllegalStateException.class);
    assertThat(f.database()).isEqualTo(before);
  }

  @Test
  void eventInsertFailureRollsBackMaterialAndRevision() throws Exception {
    f.sql(
        "CREATE TRIGGER reject_registration BEFORE INSERT ON starcore_nation_factory_events BEGIN"
            + " SELECT RAISE(ABORT,'injected registration failure'); END");
    var before = f.database();
    assertThat(register(UUID.randomUUID(), fingerprint()).status()).isEqualTo(UNKNOWN);
    assertThat(f.database()).isEqualTo(before);
    f.assets(10000, 10000, 10000);
  }

  @Test
  void lostCommitAcknowledgementReplaysExactlyOnceAfterRestart() throws Exception {
    UUID id = UUID.randomUUID();
    String hash = fingerprint();
    f.loseAck.set(true);
    assertThat(register(id, hash).status()).isEqualTo(UNKNOWN);
    f.assets(9720, 9944, 9930);
    f.current = f.bundle();
    var before = f.database();
    assertThat(register(id, hash).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(f.database()).isEqualTo(before);
  }

  @Test
  void lostAckAndFailedReconciliationBlockFurtherWritesUntilRecovery() throws Exception {
    UUID id = UUID.randomUUID();
    String hash = fingerprint();
    f.loseAck.set(true);
    f.loseReads.set(true);
    assertThat(register(id, hash).status()).isEqualTo(UNKNOWN);
    assertThat(f.current.resources().grant(f.nation.id(), "mineral", 1)).isFalse();
    f.failReads.set(false);
    f.current = f.bundle();
    var before = f.database();
    assertThat(register(id, hash).status()).isEqualTo(ALREADY_APPLIED);
    assertThat(f.database()).isEqualTo(before);
    f.assets(9720, 9944, 9930);
  }

  @Test
  void newConstructionCannotStealALegacyFactoryId() throws Exception {
    var before = f.database();
    assertThat(
            f.current
                .factories()
                .build(factory, f.actor, NationFactoryService.Type.SMELTER, "New")
                .status())
        .isEqualTo(UNKNOWN);
    assertThat(f.database()).isEqualTo(before);
    assertThat(register(UUID.randomUUID(), fingerprint()).status()).isEqualTo(APPLIED);
  }

  @Test
  void independentRegistrarsCannotChargeTwiceForOneLegacyAsset() throws Exception {
    String hash = fingerprint();
    var other = f.bundle();
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    var gate = new java.util.concurrent.CyclicBarrier(2);
    try (var pool = java.util.concurrent.Executors.newFixedThreadPool(2)) {
      var one =
          pool.submit(
              () -> {
                gate.await();
                return register(a, hash).status();
              });
      var two =
          pool.submit(
              () -> {
                gate.await();
                return other.factories().registerLegacy(b, f.actor, factory, hash).status();
              });
      var statuses =
          List.of(
              one.get(10, java.util.concurrent.TimeUnit.SECONDS),
              two.get(10, java.util.concurrent.TimeUnit.SECONDS));
      assertThat(statuses.stream().filter(APPLIED::equals).count()).isEqualTo(1);
      assertThat(statuses).allMatch(s -> Set.of(APPLIED, CONFLICT, UNKNOWN).contains(s));
    }
    f.current = f.bundle();
    f.assets(9720, 9944, 9930);
    assertThat(
            f.current
                .factories()
                .changesAfter(f.current.factories().authorityDomain().orElseThrow(), 0, 100))
        .hasSize(1);
  }

  @Test
  void wrongThreadCannotAuditOrRegisterAndCapacityIncludesRegisteredBuildings() throws Exception {
    var wrong =
        new SimpleNationFactoryService(
            f.current.resources(),
            f.current.storage(),
            f.nations,
            java.time.Clock.fixed(f.time, java.time.ZoneOffset.UTC),
            () -> false);
    assertThat(wrong.registerLegacy(UUID.randomUUID(), f.actor, factory, fingerprint()).status())
        .isEqualTo(UNAVAILABLE);
    assertThat(wrong.legacyQuotes(f.actor, 0, 10)).isEmpty();
    assertThatThrownBy(wrong::legacyAudit).isInstanceOf(IllegalStateException.class);
    for (int i = 0; i < 32; i++) f.build();
    var before = f.database();
    assertThat(register(UUID.randomUUID(), fingerprint()).status()).isEqualTo(CAPACITY_REACHED);
    assertThat(f.database()).isEqualTo(before);
  }

  @Test
  void deletedOrAlteredMigrationJournalBlocksRecoveryAndFurtherAssetWrites() throws Exception {
    UUID id = UUID.randomUUID();
    assertThat(register(id, fingerprint()).status()).isEqualTo(APPLIED);
    f.sql("DELETE FROM starcore_nation_factory_events");
    assertThatThrownBy(f::bundle).isInstanceOf(IllegalStateException.class);
    assertThat(f.current.resources().grant(f.nation.id(), "mineral", 1)).isFalse();
  }

  @Test
  void oldFactoryBytesStayUnchangedAndMigratedOriginsCannotBeRebound() {
    UUID id = f.build();
    var ordinary = f.current.factories().operation(id, f.actor).orElseThrow().change();
    String bytes = NationFactoryCodec.encode(ordinary);
    assertThat(bytes).startsWith("{\"format\":1,").doesNotContain("origin", "legacy");
    assertThat(NationFactoryCodec.encode(NationFactoryCodec.decode(bytes))).isEqualTo(bytes);
    UUID registration = UUID.randomUUID();
    assertThat(register(registration, fingerprint()).status()).isEqualTo(APPLIED);
    var c = f.current.factories().operation(registration, f.actor).orElseThrow().change();
    String migrated = NationFactoryCodec.encode(c);
    assertThat(migrated).startsWith("{\"format\":2,").contains("LEGACY_REGISTERED");
    assertThat(NationFactoryCodec.decode(migrated)).isEqualTo(c);
    assertThatThrownBy(
            () -> NationFactoryCodec.decode(migrated.replace("LEGACY_REGISTERED", "BUILT")))
        .isInstanceOf(RuntimeException.class);
    assertThatThrownBy(
            () -> NationFactoryCodec.decode(migrated.replace("\"level\":3", "\"level\":2")))
        .isInstanceOf(RuntimeException.class);
  }
}
