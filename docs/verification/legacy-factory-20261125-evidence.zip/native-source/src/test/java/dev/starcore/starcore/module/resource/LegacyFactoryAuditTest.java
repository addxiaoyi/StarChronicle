package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;

import java.time.Duration;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LegacyFactoryAuditTest {
  static final UUID FACTORY = UUID.fromString("21e94321-089a-4311-8fc1-19bfe7b176fd");
  static final UUID NATION = UUID.fromString("9da6bd62-fcec-4864-a93a-88904437d1bb");

  static Properties legacy() {
    var p = new Properties();
    p.setProperty("resource.authority-domain", "9a27064c-70f4-421c-aa79-742a9c9c84f0");
    p.setProperty("factory.count", "1");
    Map.of(
            "id",
            FACTORY.toString(),
            "nationId",
            NATION.toString(),
            "name",
            "OldForge",
            "type",
            "SMELTER",
            "buildTime",
            "1700000000000",
            "level",
            "3",
            "efficiency",
            "1.1",
            "operational",
            "true")
        .forEach((k, v) -> p.setProperty("factory.0." + k, v));
    return p;
  }

  @Test
  void reportPreservesExactStringsAndStableDigestWithoutTrustingTheLegacyModel() {
    var p = legacy();
    var r = LegacyFactoryAudit.inspect(p);
    assertThat(r.issues()).isEmpty();
    var e = r.eligible(FACTORY).orElseThrow();
    assertThat(e.metadata().level()).isEqualTo(3);
    assertThat(e.metadata().efficiency()).isEqualByComparingTo("1.1");
    var reordered = new Properties();
    p.stringPropertyNames().stream()
        .sorted(Comparator.reverseOrder())
        .forEach(k -> reordered.setProperty(k, p.getProperty(k)));
    reordered.setProperty("unrelated", "not in factory audit");
    assertThat(LegacyFactoryAudit.inspect(reordered)).isEqualTo(r);
    p.setProperty("factory.0.efficiency", "1.100");
    assertThat(LegacyFactoryAudit.inspect(p).fingerprint()).isNotEqualTo(r.fingerprint());
    assertThat(e.fields().get("efficiency")).isEqualTo("1.1");
    assertThatThrownBy(() -> r.raw().put("bad", "bad"))
        .isInstanceOf(UnsupportedOperationException.class);
    reordered.setProperty("resource.authority-domain", UUID.randomUUID().toString());
    assertThat(LegacyFactoryAudit.inspect(reordered).fingerprint()).isNotEqualTo(r.fingerprint());
  }

  @ParameterizedTest
  @CsvSource({
    "level,0",
    "level,11",
    "level,99",
    "level,03",
    "level,-1",
    "efficiency,NaN",
    "efficiency,Infinity",
    "efficiency,12.5",
    "efficiency,0.49",
    "efficiency,1e0",
    "operational,yes",
    "operational,TRUE",
    "buildTime,-1",
    "buildTime,01700000000000",
    "id,1-1-1-1-1",
    "id,21E94321-089A-4311-8FC1-19BFE7B176FD",
    "nationId,not-a-nation",
    "type,UNKNOWN"
  })
  void invalidRawFieldsCannotBecomeValidThroughClampingOrCoercion(String key, String value) {
    var p = legacy();
    p.setProperty("factory.0." + key, value);
    var r = LegacyFactoryAudit.inspect(p);
    assertThat(r.entries().getFirst().issues()).contains("INVALID_METADATA");
    assertThat(r.eligible(FACTORY)).isEmpty();
    assertThat(r.raw().get("factory.0." + key)).isEqualTo(value);
  }

  @Test
  void unknownMissingAndProcessingFieldsRemainQuarantined() {
    var p = legacy();
    p.setProperty("factory.0.recipe", "old");
    p.setProperty("factory.0.processingStart", "1700000000000");
    p.setProperty("factory.0.processingBatches", "37");
    p.setProperty("factory.0.unrecognized", "verbatim");
    p.remove("factory.0.name");
    var r = LegacyFactoryAudit.inspect(p);
    assertThat(r.entries().getFirst().issues())
        .contains("UNRESOLVED_PROCESSING", "MISSING_name", "UNKNOWN_FIELD");
    assertThat(r.eligible(FACTORY)).isEmpty();
    assertThat(r.raw()).containsEntry("factory.0.unrecognized", "verbatim");
  }

  @Test
  void duplicateIdsIncludingNoncanonicalAliasesBlockEveryCopy() {
    var p = legacy();
    p.setProperty("factory.count", "2");
    new HashSet<>(p.stringPropertyNames())
        .stream()
            .filter(k -> k.startsWith("factory.0."))
            .forEach(k -> p.setProperty(k.replace("factory.0.", "factory.1."), p.getProperty(k)));
    p.setProperty("factory.1.id", FACTORY.toString().toUpperCase(Locale.ROOT));
    var r = LegacyFactoryAudit.inspect(p);
    assertThat(r.entries())
        .allSatisfy(e -> assertThat(e.issues()).contains("DUPLICATE_FACTORY_ID"));
    assertThat(r.eligible(FACTORY)).isEmpty();
  }

  @Test
  void invalidCountsOrphansAndMalformedKeysBlockRegistrationWithoutExpandingDeclaredCount() {
    var p = legacy();
    p.setProperty("factory.count", "2147483647");
    org.junit.jupiter.api.Assertions.assertTimeout(
        Duration.ofSeconds(2),
        () -> {
          assertThat(LegacyFactoryAudit.inspect(p).issues()).contains("FACTORY_COUNT_MISMATCH");
          assertThat(ResourceStateCodec.snapshotFromProperties(p, Set.of()).factories()).hasSize(1);
        });
    p.setProperty("factory.count", "0");
    p.setProperty("factory.01.id", FACTORY.toString());
    p.setProperty("factory.2147483648.id", FACTORY.toString());
    var r = LegacyFactoryAudit.inspect(p);
    assertThat(r.issues())
        .contains("ORPHAN_FACTORY_INDEX", "UNKNOWN_FACTORY_KEY", "FACTORY_COUNT_MISMATCH");
    assertThat(r.eligible(FACTORY)).isEmpty();
    p.remove("factory.count");
    assertThat(LegacyFactoryAudit.inspect(p).issues()).contains("INVALID_FACTORY_COUNT");
  }

  @Test
  void digestDoesNotCollapseDelimitersOrMalformedUnicode() {
    var p = legacy();
    p.setProperty("factory.unknown", "a\nb");
    String first = LegacyFactoryAudit.inspect(p).fingerprint();
    p.setProperty("factory.unknown", "a");
    p.setProperty("factory.b", "");
    assertThat(LegacyFactoryAudit.inspect(p).fingerprint()).isNotEqualTo(first);
    p.setProperty("factory.unknown", "\ud800");
    first = LegacyFactoryAudit.inspect(p).fingerprint();
    p.setProperty("factory.unknown", "\ud801");
    assertThat(LegacyFactoryAudit.inspect(p).fingerprint()).isNotEqualTo(first);
  }
}
