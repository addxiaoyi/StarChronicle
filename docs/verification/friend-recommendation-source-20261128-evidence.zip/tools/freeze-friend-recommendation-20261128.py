from pathlib import Path
import hashlib,json,os,shutil
root=Path(__file__).resolve().parents[1]
native=root.parent/'StarChronicle-audit/starcore-all-stages'
result=json.loads((root/'run/native-friend-recommendation-focused-1-20261128/result.json').read_text())
assert result['validation_success'] and result['packaging_executed'] and not result['source_drift']
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
out=root/'run/friend-recommendation-frozen-pair-1-20261128';out.mkdir()
manifest={}
for name,source,key in [('chronicle.jar',root/'run/social-influence-frozen-pair-1-20261128/chronicle.jar',None),
                         ('native.jar',native/'target/starcore-1.0.0.jar','starcore-1.0.0.jar'),
                         ('original-native.jar',native/'target/original-starcore-1.0.0.jar','original-starcore-1.0.0.jar')]:
    original=digest(source)
    if key:assert original==result['artifacts'][key]
    if key:shutil.copy2(source,out/name)
    else:os.link(source,out/name)
    assert digest(out/name)==original
    manifest[name]={'sha256':original,'bytes':source.stat().st_size,'source':str(source)}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
