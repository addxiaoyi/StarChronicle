from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest();files={};runs={}
def add(path,name):files[name]=path.read_bytes()
for phase in ('baseline','compile','test-final','package','sbom','artifacts'):
 directory=root/'run'/('command-lifecycle-'+phase+'-20261126')
 runs[phase]=json.loads((directory/'result.json').read_text(encoding='utf-8'))
 for path in sorted(directory.rglob('*')):
  if path.is_file() and path.suffix in ('.json','.xml','.java','.log','.txt'):add(path,phase+'/'+path.relative_to(directory).as_posix())
 if phase!='baseline':assert runs[phase].get('exit_code',0)==0,phase
totals=dict(tests=0,failures=0,errors=0,skipped=0)
for path in (root/'run/command-lifecycle-test-final-20261126/surefire').glob('*.xml'):
 suite=ET.parse(path).getroot()
 for key in totals:totals[key]+=int(suite.get(key,0))
assert totals==runs['test-final']['totals']==dict(tests=356,failures=0,errors=0,skipped=0)
assert runs['baseline']['totals']==dict(tests=17,failures=17,errors=0,skipped=0)
names=['src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java',
 'src/test/java/dev/starcore/starcore/essentials/EssentialsCommandLifecycleTest.java',
 'src/test/java/dev/starcore/starcore/essentials/EssentialsModuleLifecycleTest.java',
 'docs/ESSENTIALS-COMMAND-LIFECYCLE.md','docs/COMPAT-SCHEDULER-LIFECYCLE.md']
for name in names+['pom.xml','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties']:add(native/name,'starcore/'+name)
for name in ('starcore-1.0.0-sbom.json','starcore-1.0.0-sbom.xml'):add(native/'target'/name,'sbom/'+name)
for name in ('run-command-lifecycle.py','verify-command-lifecycle-artifacts.py','finalize-command-lifecycle.py'):add(root/'run'/name,'tools/'+name)
for name in ('teleport-owner-ci-success-20261126.log','teleport-owner-final-ci-20261126.json','teleport-owner-delivery-git-20261126.json'):add(root/'run'/name,'previous-teleport-ci/'+name)
files['starcore/change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=native)
plugin=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
sources=sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes())
core=sha((native/'target/starcore-1.0.0.jar').read_bytes())
assert core==runs['artifacts']['starcore_sha256']
assert plugin=='1c7b8b010c9d330c15b0882753d54095fb906e42caedb926a81055d643cd78ce'
summary={'date':'2026-11-26','scope':'Essentials command ownership, handler restoration, inactive captured callbacks, partial enable and independent cleanup failures. No Minecraft.',
 'baseline_commits':{'starchronicle':'24c17a422e03f5a6ae7bb863ccacb8704556e3dc','starcore':'b2cb58f74064132b32509a4762c6c4a3e4719919'},
 'new_tests':17,'tests':totals,'baseline_tests':runs['baseline']['totals'],
 'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':sources,'starcore_sha256':core},'artifact_verification':runs['artifacts'],
 'source_hashes':{name:sha((native/name).read_bytes()) for name in names},
 'limits':['No real Minecraft, third-party binaries or live Paper/Folia reload.',
  'Command wrappers gate future entry, not already admitted effects or asynchronous continuations.',
  'Previous executor and completer slots are restored independently only while still owned.',
  'PluginCommand registration and aliases remain in the server command map.',
  'Command-map mutations require server lifecycle context; player invocations require the player owner.',
  'Cleanup failure is rethrown after other cleanup; it is not a successful-restoration receipt.',
  '356 selected tests, existing POM exclusions retained, not the complete native suite.',
  'Single 256 MiB JVM per operation; forkCount=0, jacoco.skip=true; no local coverage result.',
  'Chronicle main JAR and prior 1021-test local result unchanged. Earlier native contracts and regressions retain their own JAR identities.',
  'Remaining player-owner migrations, GUI state, full hot reload, other modules and production acceptance remain.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/command-lifecycle-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
 for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
 manifest=json.loads(archive.read('manifest.json'));assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
 for name,digest in manifest['files'].items():assert sha(archive.read(name))==digest
summary['evidence_files']=len(files);summary['evidence_zip_sha256']=sha(output.read_bytes())
(output.parent/'command-lifecycle-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# Essentials 命令生命周期：源码验证 2026-11-26

原实现停用模块后仍保留命令执行器及补全器，捕获的旧处理器仍能修改旧家园服务、读取旧补全数据；裸命令名冲突时还会覆盖其他插件的命令。本次增加原插件身份核验、每次启用的独立命令入口及按槽位恢复，并完整处理部分启用／清理失败。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{core}` |
| Chronicle，主构件保持 | `{plugin}` |
| Chronicle 源码 JAR | `{sources}` |
| 证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线 Chronicle `24c17a4`、StarCore `b2cb58f`。[证据 ZIP](verification/command-lifecycle-source-20261126-evidence.zip) **{len(files)} 文件**；[机器摘要](verification/command-lifecycle-source-20261126-summary.json)。包含源码、旧实现失败、最终 XML、构建／SBOM／API 与类字节核对、工具，以及上一传送检查点 CI #177 的成功日志和交付 Git 核对。没有启动 Minecraft。

## 行为与边界

- 优先使用插件命名空间查找，只有 PluginCommand 属于相同插件实例才注册；裸名仅作为相同所有者的兼容回退。别名指向同一对象时只绑定一次。
- 每次启用安装全新的执行／补全入口，所有服务、监听器、计时器完成初始化后才激活。停用首先关闭所有旧入口并释放其服务引用。重新启用不能复活旧回调；不可用时命令提示模块当前不可用，补全返回空列表。
- 记录原执行器和补全器，只在相应槽位仍是本次安装的确切对象时恢复；别的模块后来接管的槽位保留。命令自身及命名空间／别名继续注册，不删除服务器命令映射。
- 在设置处理器前登记清理记录，注册中途报错同样恢复。一个命令恢复失败不阻断其补全器、其余命令、调度器取消、监听移除或数据写入器关闭。第一异常保留，后续异常作为 suppressed；不能恢复的入口仍失效，不表示物理恢复已成功。

生命周期和命令映射修改仍要求服务器正常生命周期上下文；调用玩家命令仍要求玩家 owner。停用前已准入的命令允许完成，包括业务副作用与异步续办，本次没有等待全部在途工作或承诺回滚。GUI 状态、其他模块及完整热重载继续待办。

## 验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现命令生命周期基线 | 17 | 17 | 0 | 0 |
| 最终调度器与 Essentials 相关回归 | **356** | **0** | **0** | **0** |

新增 17 项使用真实 Paper API PluginCommand 对象及模拟服务，覆盖旧回调、旧补全、启用未完成、重启、共享别名、裸名冲突、命名空间回退、独立槽位接管、设置之后抛错、取消／恢复／最终保存失败与异常保留。旧实现 17 个失败均为行为断言，原始 XML 保留。已有生命周期测试仅补充插件名夹具，不改变其断言。

Spotless、2,266 主源／1,087 测试源编译、356 项相关测试、独立打包和在线 36 组件 SBOM 通过；最终 3 个模块类与已测 target/classes 字节一致，Java 21 和旧公开方法描述符保持。每次单个 256 MiB JVM、forkCount=0、jacoco.skip=true，无本机覆盖率。未新增 POM 排除；356 项不是全库测试。

```text
mvnw.cmd -o -B -ntp -Djacoco.skip=true spotless:apply -DskipTests test-compile
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=dev.starcore.starcore.core.scheduler.**,dev.starcore.starcore.essentials.** surefire:test
mvnw.cmd -o -B -ntp -Djacoco.skip=true -Dmaven.main.skip=true -Dmaven.test.skip=true verify
mvnw.cmd -B -ntp -Djacoco.skip=true cyclonedx:makeAggregateBom@generate-sbom
```

Chronicle 主构件沿用 NPC 检查点本地 1,021 项结果，本轮未本地重跑；新文档提交后独立跟踪 Linux CI。原 339／302／1,131 项和国库、贸易、工厂契约继续保持各自构件边界。StarCore 现有工作流不覆盖非 main 基线草稿 PR。

下一步继续玩家所有权与异步续办：经济转账、社交命令仍有远端玩家访问，其他 runSync／runNextTick 使用链及完整热重载继续审计。实际 NPC／保护组合、当前构件实服、全栈 Folia 和长期容量尚待验收；十阶段未全部完成。
'''
(root/'docs/COMMAND-LIFECYCLE-SOURCE-20261126.md').write_text(report,encoding='utf-8')
print(json.dumps({'evidence_files':len(files),'evidence_sha256':summary['evidence_zip_sha256'],'artifacts':summary['artifacts'],'tests':totals}))
