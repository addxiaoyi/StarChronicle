package dev.starcore.starcore.essentials;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.data.EssentialsDataManager;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.message.MessageService;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.MockedConstruction;

class EssentialsCommandLifecycleTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final StarCoreContext context = mock(StarCoreContext.class, RETURNS_DEEP_STUBS);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final Map<String, PluginCommand> commands = new HashMap<>();
  private final Player player = mock(Player.class);
  private final UUID playerId = UUID.randomUUID();
  private EssentialsModule module;
  private MockedConstruction<EssentialsDataManager> managers;

  @BeforeEach
  void setup() {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.getName()).thenReturn("StarCore");
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPluginManager()).thenReturn(mock(org.bukkit.plugin.PluginManager.class));
    when(server.getPluginCommand(anyString())).thenAnswer(i -> commands.get(i.getArgument(0)));
    when(context.configuration().getConfig()).thenReturn(new YamlConfiguration());
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.getLocation()).thenReturn(new Location(null, 4, 65, 8));
    managers = mockConstruction(EssentialsDataManager.class);
    module = new EssentialsModule(plugin, scheduler, mock(MessageService.class), mock(EconomyService.class));
  }

  @AfterEach
  void cleanup() {
    managers.close();
  }

  private PluginCommand command(String name, Plugin owner) throws Exception {
    var constructor = PluginCommand.class.getDeclaredConstructor(String.class, Plugin.class);
    constructor.setAccessible(true);
    return constructor.newInstance(name, owner);
  }

  private PluginCommand owned(String name) throws Exception {
    PluginCommand command = command(name, plugin);
    commands.put(name, command);
    commands.put("starcore:" + name, command);
    return command;
  }

  private void invoke(CommandExecutor executor, PluginCommand command, String name) {
    assertTrue(executor.onCommand(player, command, command.getName(), new String[] {name}));
  }

  @Test
  void restoresOriginalExecutorAndCompleterWhenDisabled() throws Exception {
    PluginCommand command = owned("sethome");
    CommandExecutor previous = mock(CommandExecutor.class);
    TabCompleter previousTabs = mock(TabCompleter.class);
    command.setExecutor(previous);
    command.setTabCompleter(previousTabs);
    module.enable(context);
    assertNotSame(previous, command.getExecutor());
    module.disable(context);
    assertSame(previous, command.getExecutor());
    assertSame(previousTabs, command.getTabCompleter());
  }

  @Test
  void aliasesSharingOneCommandRestoreOnlyTheOriginalBinding() throws Exception {
    PluginCommand command = owned("balance");
    for (String alias : List.of("bal", "money")) {
      commands.put(alias, command);
      commands.put("starcore:" + alias, command);
    }
    module.enable(context);
    module.disable(context);
    assertSame(plugin, command.getExecutor());
    assertNull(command.getTabCompleter());
  }

  @Test
  void capturedExecutorCannotMutateHomesAfterDisable() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    CommandExecutor captured = command.getExecutor();
    HomeService oldHomes = module.getHomeService();
    module.disable(context);
    invoke(captured, command, "late");
    assertTrue(oldHomes.getHome(playerId, "late").isEmpty());
  }

  @Test
  void capturedTabCompleterCannotReadOldHomesAfterDisable() throws Exception {
    PluginCommand command = owned("home");
    module.enable(context);
    assertTrue(module.getHomeService().setHome(player, "private"));
    TabCompleter captured = command.getTabCompleter();
    assertEquals(List.of("private"), captured.onTabComplete(player, command, "home", new String[] {""}));
    module.disable(context);
    assertEquals(List.of(), captured.onTabComplete(player, command, "home", new String[] {""}));
  }

  @Test
  void reenableUsesFreshServicesAndCannotReactivateCapturedHandlers() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    CommandExecutor captured = command.getExecutor();
    HomeService first = module.getHomeService();
    module.disable(context);
    module.enable(context);
    HomeService second = module.getHomeService();
    invoke(captured, command, "old");
    invoke(command.getExecutor(), command, "current");
    assertTrue(first.getHome(playerId, "old").isEmpty());
    assertTrue(second.getHome(playerId, "old").isEmpty());
    assertTrue(second.getHome(playerId, "current").isPresent());
    module.disable(context);
    assertSame(plugin, command.getExecutor());
  }

  @Test
  void doesNotOverwriteAnExecutorInstalledByAnotherModule() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    CommandExecutor replacement = mock(CommandExecutor.class);
    command.setExecutor(replacement);
    module.disable(context);
    assertSame(replacement, command.getExecutor());
    assertNull(command.getTabCompleter());
  }

  @Test
  void doesNotOverwriteACompleterInstalledByAnotherModule() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    TabCompleter replacement = mock(TabCompleter.class);
    command.setTabCompleter(replacement);
    module.disable(context);
    assertSame(replacement, command.getTabCompleter());
    assertSame(plugin, command.getExecutor());
  }

  @Test
  void foreignBareCommandIsNeverHijacked() throws Exception {
    Plugin foreign = mock(Plugin.class);
    PluginCommand command = command("sethome", foreign);
    commands.put("sethome", command);
    module.enable(context);
    assertSame(foreign, command.getExecutor());
    assertNull(command.getTabCompleter());
    module.disable(context);
  }

  @Test
  void usesOwnNamespacedCommandWhenTheBareNameBelongsToAnotherPlugin() throws Exception {
    Plugin foreign = mock(Plugin.class);
    PluginCommand own = owned("sethome");
    PluginCommand foreignCommand = command("sethome", foreign);
    commands.put("sethome", foreignCommand);
    module.enable(context);
    invoke(own.getExecutor(), own, "owned");
    assertTrue(module.getHomeService().getHome(playerId, "owned").isPresent());
    assertSame(foreign, foreignCommand.getExecutor());
    module.disable(context);
    assertSame(plugin, own.getExecutor());
  }

  @Test
  void ownBareCommandRemainsSupportedWhenNamespacedLookupIsAbsent() throws Exception {
    PluginCommand command = owned("sethome");
    commands.remove("starcore:sethome");
    module.enable(context);
    invoke(command.getExecutor(), command, "fallback");
    assertTrue(module.getHomeService().getHome(playerId, "fallback").isPresent());
    module.disable(context);
    assertSame(plugin, command.getExecutor());
  }

  @Test
  void duplicateEnableAndDisableDoNotStackBindings() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    CommandExecutor first = command.getExecutor();
    module.enable(context);
    assertSame(first, command.getExecutor());
    module.disable(context);
    module.disable(context);
    assertSame(plugin, command.getExecutor());
    verify(managers.constructed().getFirst()).shutdownAndSave();
  }

  @Test
  void commandsStayInactiveUntilEnableCompletes() throws Exception {
    PluginCommand command = owned("sethome");
    doAnswer(i -> { invoke(command.getExecutor(), command, "premature"); return null; })
        .when(scheduler).runGlobalRepeating(any(), anyLong(), anyLong());
    module.enable(context);
    assertTrue(module.getHomeService().getHome(playerId, "premature").isEmpty());
    invoke(command.getExecutor(), command, "ready");
    assertTrue(module.getHomeService().getHome(playerId, "ready").isPresent());
    module.disable(context);
  }

  @Test
  void failedEnableRestoresBindingsAndInvalidatesItsCapturedCommand() throws Exception {
    PluginCommand command = owned("sethome");
    List<CommandExecutor> captured = new ArrayList<>();
    RuntimeException failure = new IllegalStateException("timer rejected");
    doAnswer(i -> { captured.add(command.getExecutor()); throw failure; })
        .when(scheduler).runGlobalRepeating(any(), anyLong(), anyLong());
    assertSame(failure, assertThrows(RuntimeException.class, () -> module.enable(context)));
    invoke(captured.getFirst(), command, "failed");
    assertTrue(module.getHomeService().getHome(playerId, "failed").isEmpty());
    assertSame(plugin, command.getExecutor());
    verify(managers.constructed().getFirst()).shutdownAndSave();
  }

  @Test
  void schedulerCancellationFailureStillRestoresCommandsAndDrainsWriter() throws Exception {
    PluginCommand command = owned("sethome");
    module.enable(context);
    RuntimeException failure = new IllegalStateException("cancel rejected");
    doThrow(failure).when(scheduler).cancelAll();
    assertSame(failure, assertThrows(RuntimeException.class, () -> module.disable(context)));
    assertSame(plugin, command.getExecutor());
    assertNull(command.getTabCompleter());
    verify(managers.constructed().getFirst()).shutdownAndSave();
  }

  @Test
  void failedRestorationDoesNotPreventOtherCommandsOrWriterCleanup() throws Exception {
    PluginCommand broken = spy(owned("sethome"));
    commands.put("sethome", broken);
    commands.put("starcore:sethome", broken);
    PluginCommand other = owned("warp");
    module.enable(context);
    CommandExecutor captured = broken.getExecutor();
    RuntimeException failure = new IllegalStateException("restore rejected");
    doThrow(failure).when(broken).setExecutor(plugin);
    assertSame(failure, assertThrows(RuntimeException.class, () -> module.disable(context)));
    assertSame(plugin, other.getExecutor());
    assertNull(broken.getTabCompleter());
    invoke(captured, broken, "failedrestore");
    assertTrue(module.getHomeService().getHome(playerId, "failedrestore").isEmpty());
    verify(scheduler).cancelAll();
    verify(managers.constructed().getFirst()).shutdownAndSave();
  }

  @Test
  void registrationFailureAfterExecutorMutationRestoresThePreviousHandler() throws Exception {
    PluginCommand broken = spy(owned("sethome"));
    commands.put("sethome", broken);
    commands.put("starcore:sethome", broken);
    RuntimeException failure = new IllegalStateException("registration rejected");
    doAnswer(i -> { i.callRealMethod(); if (i.getArgument(0) != plugin) throw failure; return null; })
        .when(broken).setExecutor(any());
    assertSame(failure, assertThrows(RuntimeException.class, () -> module.enable(context)));
    assertSame(plugin, broken.getExecutor());
    assertNull(broken.getTabCompleter());
    verify(managers.constructed().getFirst()).shutdownAndSave();
  }

  @Test
  void cleanupFailuresAreRetainedWithoutSkippingLaterCleanup() throws Exception {
    owned("sethome");
    module.enable(context);
    RuntimeException cancelFailure = new IllegalStateException("cancel");
    RuntimeException saveFailure = new IllegalStateException("save");
    doThrow(cancelFailure).when(scheduler).cancelAll();
    doThrow(saveFailure).when(managers.constructed().getFirst()).shutdownAndSave();
    assertSame(cancelFailure, assertThrows(RuntimeException.class, () -> module.disable(context)));
    assertArrayEquals(new Throwable[] {saveFailure}, cancelFailure.getSuppressed());
  }
}
