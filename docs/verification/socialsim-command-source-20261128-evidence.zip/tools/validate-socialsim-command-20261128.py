import json
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
prior=json.loads((root/'run/native-social-relationships-focused-3-20261128/result.json').read_text());args=prior['args']
command=[sys.executable,str(root/'tools/snapshot-maven-validation.py'),'--repo',str(native),'--output',str(root/'run'/sys.argv[1]),
    '--java-home',str(Path(args[0]).parents[1]),'--maven-home',next(x.split('=',1)[1] for x in args if x.startswith('-Dmaven.home=')),
    '--heap','320m','--metaspace','192m','--java-agent',next(x.split(':',1)[1] for x in args if x.startswith('-javaagent:'))]
for suite in prior['required_suites']+['SocialSimCommandTest']:command+=['--require-suite',suite]
pattern=next(x for x in args if x.startswith('-Dtest='))+',SocialSimCommandTest'
command+=['--','-o','-DforkCount=0','-Djacoco.skip=true',pattern,'verify']
sys.exit(subprocess.call(command,cwd=root))
