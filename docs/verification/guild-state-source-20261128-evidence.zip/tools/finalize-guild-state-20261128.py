from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
attempt='native-guild-state-focused-1-20261128'
tests=json.loads((root/'run'/attempt/'result.json').read_text());assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][k]==0 for k in ('failures','errors','skipped'))
pair=json.loads((root/'run/guild-state-pair-artifacts-1-20261128/result.json').read_text());assert pair['status']=='VERIFIED'
replicas=json.loads((root/'run/guild-state-replicas-1-20261128/result.json').read_text());assert replicas['status']=='VERIFIED'
frozen=root/'run/guild-state-frozen-pair-1-20261128'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
files={}
for label,name in [('validation',attempt),('replicas','guild-state-replicas-1-20261128'),('pair','guild-state-pair-artifacts-1-20261128'),('frozen',frozen.name)]:
    for path in sorted((root/'run'/name).rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class','.mdmp'):files[label+'/'+path.relative_to(root/'run'/name).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','tools/verify-guild-state-recovery.py','tools/GuildStateRecoveryProbe.java',
             'run/validate-guild-state-20261128.py','run/finalize-guild-state-20261128.py','run/guild-state-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:digest(path) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],'artifacts':json.loads((frozen/'manifest.json').read_text()),'fixtures_compiled':pair['fixtures']['count'],'replica_jvms':len(replicas['runs']),
    'limits':['Related tests only; not full StarCore suite. SQLite and files only, no MySQL.',
      'GuildService commits a complete candidate before publication; SQL and unified file reject stale state, failed recovery and late admissions after close.',
      'Guild read methods return detached snapshots; modifying a returned Guild no longer changes service authority. Explicit service mutation/import methods are required.',
      'Old guilds.yml preserved with exact backup and source fingerprint; original creation time, roles and recorded balance restored. Old YAML did not record invites, old SQL did not record balance; neither can be recreated.',
      'Guild import preserves IDs/times/roles/balance and validates all guilds before one guild-state commit. Whole social import/export still has separate service transactions, path and other source work outstanding.',
      'Actual guild command owner/I-O, other social scheduling/activity/alliance/culture and remaining stages still require source changes.',
      'No Minecraft/Paper/Folia/server restart, MySQL, long cross-process load, hardware power loss or deployment.']}
out=root/'docs/verification/guild-state-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=digest(out),files=manifest)
(root/'docs/verification/guild-state-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
