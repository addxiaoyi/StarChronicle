# NPC 桥接生命周期与玩家会话：源码验证 2026-11-26

FancyNpcs、Citizens、Adyeshach 的旧监听器在禁用后可能继续回调；重载只按名字移除监听会误伤同名新实例。旧交互入口只保存 UUID，重新登录后可能把旧点击归到新会话上下文。本次修复这三类边界，并将纪念点老兵接入相同的观察入口。

## 当前构件与范围

| 构件 | SHA-256 |
| --- | --- |
| Chronicle 插件 | `e020c1ad8d26466c9e170a0af44beda82ef3674654656a5015aa23bf80964f23` |
| Chronicle 源码 | `aa59ea116635f97b91c71411df5fb8227fe1af2648fcbec5bd903fd38892b6dd` |
| 配套 StarCore，源码及构件未变 | `928637205bffa395a52781eade913650e767c551a04b5f1a78a6a3e86183e87b` |
| 本轮证据 ZIP | `d8f4546ed77dd56f28a940e1c4d9c101a1e4436b76585006ce7fc6861c050ee9` |

从 Chronicle `1c4acc0` 和 StarCore `b048071d` 续接同一分支 `codex/plugin-all-stages-20261125`，保持草稿 PR #2／#3。证据包 **152 个文件**：[ZIP](verification/npc-lifecycle-source-20261126-evidence.zip)、[机器摘要](verification/npc-lifecycle-source-20261126-summary.json)。本轮没有启动 Minecraft。

## 交互与关闭边界

- `start` 幂等、`close` 终止；按实际 Plugin 实例安装／失效监听。旧实例的迟到 disable 不移除新实例。禁用／重载后旧观察不能再次有效；单个注册失败清理残留，其他提供者继续安装。
- API 只从当前提供者的 ClassLoader 加载。MONITOR、ignoreCancelled 和回调内部取消复核保持，稳定身份限定为非空 String 或 UUID、最多 256 字符。null、任意对象和超长身份不进入历史；不操作第三方 NPC 实体。
- 桥接保留事件中的确切 Player 和观察时间。实体调度执行前发生离线或重连则拒绝，不读取替代实体；`starchronicle.use` 必需，只有 admin 权限也不能绕过。
- 在原玩家实体上取得的不可变上下文继续用于该事件，其他受众快照不再重取参与者。历史 `npc.id` 是逻辑档案，`npc.binding` 是来源稳定绑定，新增 `time_basis=OBSERVED`；旧历史不迁移或改写。
- 工作线程在调用规则引擎前再核对提供者失效和关服标志。此前已进入处理的观察可以完成，已提交历史不会因禁用回滚。单个事件被成功入库前仍无第三方持久 outbox，不能声称停用期间完整历史或端到端严格一次。
- 纪念点保留原事件 Player；配置刷新和关闭使旧观察失效，重新启用不会恢复旧观察。原 UUID 双参数回调构造器保留，使用它的外部调用者自行管理后续排队语义。

## 实际验证与保留失败

| 运行 | 测试 | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现初次夹具 | 33 | 10 | 13 | 0 |
| 补齐 Bukkit 测试线程环境，生产实现仍未修复 | 33 | 26 | 0 | 0 |
| 修复后的第一轮相关回归 | 102 | 0 | 0 | 0 |
| 最终完整 clean verify | 1,010 | 0 | 0 | 0 |

新增 **53 项**：NPC 桥接 37、生产观察入口 15、纪念点 1。三种第三方事件是明确标注的 API 形状测试替身，真实 Bukkit RegisteredListener／HandlerList 验证注册和取消；真实 RegionTasks 配合排队回调核对重连、关闭、权限、满队列、原时间与原上下文。缺少可选 API 的隔离 ClassLoader 不借用其他插件类。

初次夹具的 13 errors 来自 PluginEnable/DisableEvent 需要 Bukkit.isPrimaryThread 测试环境，不能算产品缺陷；补齐后得到 26 个真实断言失败。全部原始日志、XML 和旧源码保留在证据 ZIP。启动脚本最初有 Python Windows 路径转义语法错误，在启动 Java 前修正；该错误不计入测试结果。

最终使用单个 256 MiB 堆 JVM，命令为 `mvnw.cmd -o -B -ntp -DforkCount=0 -Djacoco.skip=true clean verify`，带 Mockito agent。插件入口 Java 21、全部主源码与源码 JAR、全部资源与插件 JAR 均通过逐项校验。发布 JAR 不包含 Bukkit、StarCore 或三种 NPC 夹具类；本机没有新增 JaCoCo 结果。完整报告见 [TEST-REPORT](TEST-REPORT.md)。

StarCore 本轮未改动；此前 1,558 项相关回归及国库／贸易／工厂契约按其原始 Chronicle 构件保存，不改称当前新 Chronicle 的再次实测。

## 剩余工作

第 8 阶段仍需要真实 NPC／领地保护版本组合的启停、事件顺序、客户端交互与区域线程验收。MONITOR 只证明当时观察到的取消状态，不替代实际保护插件行为。第 7 阶段 StarCore 全栈 Folia、其余当前构件实服流程、第三方持久来源、旧来源核对、长期压力与容量边界仍未完成。按用户选择继续源码与单元测试，不申请启动实服。
