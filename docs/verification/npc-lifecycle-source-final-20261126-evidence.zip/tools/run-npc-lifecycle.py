from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
phase = sys.argv[1]
destination = root / 'run' / ('npc-lifecycle-' + phase + '-20261126')
destination.mkdir(exist_ok=False)
env = os.environ.copy()
env['JAVA_HOME'] = r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS'] = r'-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8 -javaagent:C:\Users\Administrator\.m2\repository\org\mockito\mockito-core\5.15.2\mockito-core-5.15.2.jar'
args = ['cmd.exe', '/d', '/c', str(root / 'mvnw.cmd'), '-o', '-B', '-ntp', '-DforkCount=0', '-Djacoco.skip=true']
if phase.startswith('baseline'):
    for name in ('starchronicle-0.1.0-SNAPSHOT.jar', 'starchronicle-0.1.0-SNAPSHOT-sources.jar'):
        shutil.copy2(root / 'target' / name, destination / name)
    args += ['-Dtest=NpcHooksTest', 'test']
elif phase.startswith('full'):
    args += ['clean', 'verify']
else:
    args += ['-Dtest=NpcHooksTest,NpcInteractionLifecycleTest,NpcMenuLifecycleTest,StarCoreBridgeTest,PlayerOwnershipConsumersTest,RegionTasksTest,MemorySitesTest,NpcSystemTest,NpcEngineTransactionTest,NpcScopedHistoryTest', 'test']
start = time.monotonic()
(destination / 'command.json').write_text(json.dumps({'args':args,'maven_opts':env['MAVEN_OPTS']}, indent=2))
with (destination / 'maven.log').open('wb') as log:
    result = subprocess.run(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
reports = destination / 'surefire'
reports.mkdir()
totals = {key:0 for key in ('tests','failures','errors','skipped')}
suites = []
for path in sorted((root / 'target/surefire-reports').glob('TEST-*.xml')):
    if phase.startswith('baseline') and not path.name.endswith('.NpcHooksTest.xml'): continue
    if not phase.startswith(('baseline','full')) and path.stat().st_mtime < time.time() - (time.monotonic()-start) - 2: continue
    shutil.copy2(path, reports / path.name)
    suite = ET.parse(path).getroot()
    suites.append(suite.attrib['name'])
    for key in totals: totals[key] += int(suite.attrib.get(key,0))
for relative in ('src/main/java/io/github/addxiaoyi/starchronicle/paper/NpcHooks.java',
                 'src/main/java/io/github/addxiaoyi/starchronicle/paper/StarChroniclePlugin.java',
                 'src/test/java/io/github/addxiaoyi/starchronicle/paper/NpcHooksTest.java'):
    target = destination / 'source' / relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root / relative,target)
summary = {'exit_code':result.returncode, 'seconds':time.monotonic()-start, 'totals':totals,'suites':suites}
if phase.startswith('full') and result.returncode == 0:
    summary['jars'] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'target').glob('*.jar')}
(destination / 'result.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='suites'}))
raise SystemExit(result.returncode)
