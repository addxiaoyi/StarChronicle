from pathlib import Path
import hashlib, json, subprocess, zipfile

root=Path(__file__).resolve().parents[1]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={}
def add(path,name):files[name]=path.read_bytes()
previous=json.loads((root/'docs/verification/npc-lifecycle-source-20261126-summary.json').read_text(encoding='utf-8'))
add(root/'docs/verification/npc-lifecycle-source-20261126-evidence.zip','preliminary/evidence.zip')
add(root/'docs/verification/npc-lifecycle-source-20261126-summary.json','preliminary/summary.json')
add(root/'docs/NPC-LIFECYCLE-SOURCE-20261126.md','preliminary/report.md')
runs={}
for phase in ('full-final','full-release'):
    directory=root/'run'/f'npc-lifecycle-{phase}-20261126'
    result=json.loads((directory/'result.json').read_text());runs[phase]=result
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.xml','.java','.log'):
            add(path,phase+'/'+path.relative_to(directory).as_posix())
assert runs['full-release']['exit_code']==0
assert runs['full-release']['totals']==dict(tests=1021,failures=0,errors=0,skipped=0)
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=root).decode().split('\0')
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
sources={}
for name in sorted(set(changed+untracked)):
    if name.startswith('src/') and (root/name).is_file():
        add(root/name,'source/'+name);sources[name]=sha((root/name).read_bytes())
for name in ('pom.xml','mvnw.cmd','tools/verification_report.py','docs/NPC-INTEGRATIONS.md','docs/TEST-REPORT.md'):
    add(root/name,'project/'+name)
add(root/'run/run-npc-lifecycle.py','tools/run-npc-lifecycle.py')
add(Path(__file__),'tools/finalize-npc-lifecycle-final.py')
plugin=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
source=sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes())
assert plugin==runs['full-release']['jars']['starchronicle-0.1.0-SNAPSHOT.jar']
assert source==runs['full-release']['jars']['starchronicle-0.1.0-SNAPSHOT-sources.jar']
with zipfile.ZipFile(root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar') as jar:
    for path in (root/'src/main/java').rglob('*.java'):
        assert jar.read(path.relative_to(root/'src/main/java').as_posix())==path.read_bytes()
summary={'date':'2026-11-26','scope':'NPC provider-instance leases, observed timestamps, original player/direct context capture, guarded asynchronous menu presentation and owned memory-site observations. No Minecraft.',
    'baseline_commits':previous['baseline_commits'],'new_tests':64,'tests':runs['full-release']['totals'],
    'preserved_previous_runs':previous['tests'],
    'discarded_intermediate_build':{'phase':'full-final','totals':runs['full-final']['totals'],'reason':'Last ingress error-display callback edited after compile started; clean full-release is the final build. Intermediate JAR is not delivered.'},
    'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':source,'starcore_sha256':previous['artifacts']['starcore_sha256']},
    'source_hashes':sources,'limits':previous['limits']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/npc-lifecycle-source-final-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
    manifest=json.loads(archive.read('manifest.json'))
    assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
    for name,digest in manifest['files'].items():assert sha(archive.read(name))==digest
summary['evidence_files']=len(files);summary['evidence_zip_sha256']=sha(output.read_bytes())
(output.parent/'npc-lifecycle-source-final-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# NPC 桥接生命周期与玩家会话：源码验证 2026-11-26

旧 NPC 桥接缺少关闭状态守卫，按插件名移除监听会误伤重载后的新实例；只保存 UUID 的交互也可能读取重连后的玩家上下文。本次给 FancyNpcs／Citizens／Adyeshach 添加实例失效标记，保留原玩家、观察时间与本次直接采集的上下文，并把同样的检查贯穿纪念点老兵和异步菜单显示。

## 当前构件

| 构件 | SHA-256 |
| --- | --- |
| Chronicle 插件 | `{plugin}` |
| Chronicle 源码 JAR | `{source}` |
| StarCore，源码及构件未变 | `{summary['artifacts']['starcore_sha256']}` |
| 最终证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线：Chronicle `1c4acc0`、StarCore `b048071d`；继续 `codex/plugin-all-stages-20261125` 与草稿 PR #2／#3。最终 [证据 ZIP](verification/npc-lifecycle-source-final-20261126-evidence.zip) **{len(files)} 个文件**，其中嵌入第一次检查点的 152 文件原始证据 ZIP；[机器摘要](verification/npc-lifecycle-source-final-20261126-summary.json)。没有启动 Minecraft。

## 最终行为

- 启动幂等、关闭终止；按实际 Plugin 实例安装和失效。旧实例迟到 disable 不移除新实例；已经失效的旧回调／排队观察不会随重新启用恢复。注册部分失败时清理残留，其他提供者继续可用。
- 从提供者自己的 ClassLoader 加载 API。MONITOR、ignoreCancelled 和回调取消复核保持；稳定 ID 仅允许非空 String／UUID，最多 256 字符，不把 null 或任意对象转成历史绑定，不创建或修改第三方 NPC。
- 排队前保存原 Player 和观察时间。进入实体调度后检查确切对象；离线或重连拒绝该观察。必须有 `starchronicle.use`，只有 admin 权限也不能绕过。
- 原生桥接直接返回本次采集的不可变 PlayerContext，观察入口不再通过共享 UUID 缓存取回。受众刷新也不会重新获取原参与者。`npc.id` 为逻辑档案，`npc.binding` 为来源稳定身份，时间为原观察时间，新增 `time_basis=OBSERVED`。
- 工作线程在规则引擎入口前复核提供者和关服状态。已经进入处理的观察可完成，已提交历史不会因禁用回滚。此路径不是第三方持久 outbox，不能恢复入库前丢失或停用期间的点击。
- 纪念点老兵保留事件 Player；配置刷新／关闭使排队观察失效，再次启用不会恢复旧观察。NPC 档案、未绑定剧情菜单和查询失败提示将原玩家／提供者检查带到最终显示；等待查询后重连或禁用不会向新会话显示旧结果。
- 兼容 UUID 双参数回调构造器仍保留，外部使用者自行管理下游排队语义；现有命令菜单行为不变。

## 实际测试与失败保留

| 运行 | 测试 | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现初次夹具 | 33 | 10 | 13 | 0 |
| 修正测试环境，生产实现未修复 | 33 | 26 | 0 | 0 |
| 初步修复专项 | 102 | 0 | 0 | 0 |
| 初步完整构建 | 1,010 | 0 | 0 | 0 |
| 最终 clean verify | **1,021** | **0** | **0** | **0** |

新增 **64 项**：桥接 37、观察／显示入口 21、异步菜单结果 4、纪念点 1、直接上下文采集 1。三种事件是有明确标记的 API 形状测试替身；使用真实 Bukkit RegisteredListener／HandlerList 和真实 RegionTasks 配合排队回调。覆盖取消、实例替换、迟到通知、关服、无效身份、隔离类加载器、权限、满队列、原时间／上下文及显示前失效。

初次夹具的 13 errors 是 Bukkit.isPrimaryThread 环境未设置；补齐后得到 26 个真实断言失败。原始 XML／日志保留。首次 Python 启动器的 Windows 路径转义语法错误发生在 Java 前，不计入测试。后续一次 1,021 项中间构建测试成功，但编译开始后调整了最后的错误提示回调，因此没有作为最终交付；在源码稳定后重新 clean verify，以 `full-release` 的全部测试与 JAR 为准。

本机最终使用单个 256 MiB 堆 JVM：`mvnw.cmd -o -B -ntp -DforkCount=0 -Djacoco.skip=true clean verify`，带 Mockito agent。全部主源码／资源与产物逐项核对通过，Java 21 入口检查通过，JAR 不包含 Bukkit／StarCore／NPC 测试夹具类；没有本机 JaCoCo 结果。完整构建报告见 [TEST-REPORT](TEST-REPORT.md)。GitHub 当前提交的独立 Linux CI 在推送后检查。

StarCore 本轮未改动，此前 1,558 项相关回归及国库／贸易／工厂契约仍按原始 Chronicle 构件保留，不改称新 Chronicle 再次实测。

## 尚未完成

第 8 阶段仍需实际 NPC／保护版本组合的启停、事件顺序、跨区和客户端验收。MONITOR 只能证明当时所见取消状态，不能替代目标保护插件行为。全栈 Folia、当前其他实服流程、第三方持久来源、旧来源核对、长时并发和容量边界继续待办；十阶段没有全部完成。按用户选择继续源码与单元测试。
'''
(root/'docs/NPC-LIFECYCLE-SOURCE-20261126.md').write_text(report,encoding='utf-8')
checkpoint=f'2026-11-26 最新检查点：[NPC 生命周期与玩家会话](NPC-LIFECYCLE-SOURCE-20261126.md)。三种 NPC 桥接按插件实例失效，原玩家、观察时间与直接采集上下文保留，纪念点和异步菜单显示复核同一会话。新增 64 项、Chronicle 1,021 项完整回归通过，当前 JAR `{plugin[:8]}…{plugin[-6:]}`；StarCore 保持 `92863720…83e87b`。原始 26 项失败保留；实际 NPC／保护组合与全栈 Folia 继续待验，不启动 Minecraft。'
for name in ('README.md','docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md'):
    path=root/name;text=path.read_text(encoding='utf-8')
    text='\n'.join(line for line in text.split('\n') if not line.startswith('2026-11-26 最新检查点：[NPC 生命周期与玩家会话]'))
    heading,body=text.split('\n',1)
    note=checkpoint.replace('(NPC-LIFECYCLE-SOURCE-20261126.md)','(docs/NPC-LIFECYCLE-SOURCE-20261126.md)') if name=='README.md' else checkpoint
    text=heading+'\n\n'+note+'\n'+body.lstrip('\n')
    text=text.replace('原玩家会话与观察时间已加固，新增 53 项、Chronicle 1,010 项完整测试通过','原玩家会话、观察时间及异步显示已加固，新增 64 项、Chronicle 1,021 项完整测试通过')
    path.write_text(text,encoding='utf-8')
print(json.dumps({'tests':summary['tests'],'artifacts':summary['artifacts'],'files':len(files),'sha256':summary['evidence_zip_sha256']}))
