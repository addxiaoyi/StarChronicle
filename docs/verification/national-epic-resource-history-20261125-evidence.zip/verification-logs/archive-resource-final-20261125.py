from pathlib import Path
import json
import shutil
import subprocess
root=Path('/home/add/starchronicle-resource-history')
native=Path('/home/add/starcore-resource-history')
checks={'dungeon-resource-final-journal-1':'resource-check.json',
        'dungeon-resource-final-tech-1':'technology-check.json',
        'dungeon-resource-final-trade-1':'trade-check.json',
        'dungeon-resource-final-member-1':'member-check.json',
        'dungeon-resource-final-epic-1':'contribution-check.json',
        'war-resource-final-epic-1':'contribution-check.json'}
for suffix,check in checks.items():
    run=root/'run'/('paper-epic-222fbb40-'+suffix)
    assert (run/'evidence'/check).is_file(),(run,check)
    sessions=[json.loads(p.read_text()) for p in (run/'evidence').glob('boot*.session.json')]
    assert len(sessions)==3 and all(s['status']=='COMPLETE' and all(p['exit_code']==0 for p in s['processes']) for s in sessions)
for kind,total in [('resource',26),('tech',23),('trade',20),('members',15),('dungeon',17),('war',17)]:
    log=Path(f'/tmp/starchronicle-resource-accepted-{kind}-evidence-20261125.log').read_text()
    assert f'Ran {total} tests' in log and log.rstrip().endswith('OK') and 'skipped=' not in log
inputs=root/'target/resource-archive-inputs-20261125';inputs.mkdir(exist_ok=False)
failures=[('/home/add/starchronicle/run/paper-epic-57345b09-war-linux-2/evidence/boot1.server.log','original-policy-failure-20261125.log'),
('/home/add/starchronicle-technology-history/run/paper-epic-393141d0-war-technology-epic-regression-1/evidence/boot1.server.log','original-weather-failure-20261125.log'),
('/home/add/starchronicle-technology-history/run/paper-epic-393141d0-dungeon-technology-weather-epic-1/evidence/epic-fixture.jsonl','original-diplomacy-unknown-20261125.jsonl')]
for source,name in failures:shutil.copy2(source,inputs/name)
args=['python3','tools/archive-epic-evidence.py','--starcore',str(native),'--label','resource-history-20261125','--native-suite','resource',
      '--native-reports',str(native/'target/resource-history-focused-20261125/surefire-reports'),
      '--starcore-jar',str(native/'target/resource-history-accepted-starcore-1.0.0.jar'),'--native-artifact-commit','2c2ae268',
      '--full-regression-log','/tmp/starcore-resource-history-verify-20261125.log',
      '--chronicle-build-log','/tmp/starchronicle-resource-history-verify-20261125.log']
for run in sorted((root/'run').glob('paper-epic-222fbb40-*')):args+=['--run',str(run)]
for path in sorted(Path('/tmp').glob('starcore-resource-history-*.log')):
    if path.name!='starcore-resource-history-verify-20261125.log':args+=['--native-log',str(path)]
for path in sorted(Path('/tmp').glob('starchronicle-resource-*.log')):
    if path.name!='starchronicle-resource-history-verify-20261125.log':args+=['--verification-log',str(path)]
for path in sorted(inputs.iterdir()):args+=['--verification-log',str(path)]
for path in ['/tmp/resource-final-pair-20261125.py','/tmp/archive-resource-final-20261125.py',str(root/'docs/verification/production-stack-candidate-20261125.json')]:args+=['--verification-log',path]
for path in ('resource-history-before-20261125','resource-history-capacity-regression-20261125'):args+=['--prior-native-regression',str(native/'target'/path)]
subprocess.run(args,cwd=root,check=True)
