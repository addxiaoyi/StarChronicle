package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.*;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class TradeSnapshotValidationTest {
  @TempDir Path directory;
  static final NationId EXPORTER = FactorySnapshotVersionTest.NATION;
  static final NationId IMPORTER = new NationId(new UUID(0, 2));
  static final NationId THIRD = new NationId(new UUID(0, 3));
  static final UUID AGREEMENT = new UUID(0, 11);
  static final UUID ROUTE = new UUID(0, 12);
  static final UUID EMBARGO = new UUID(0, 13);
  static final UUID QUOTA = new UUID(0, 14);
  static final List<String> COLLECTIONS = List.of("agreement", "route", "embargo", "quota");
  static final Map<String, List<String>> REQUIRED =
      Map.of(
          "agreement",
              List.of(
                  "id", "exporter", "importer", "resource", "amount", "price", "start", "expiry"),
          "route", List.of("id", "origin", "destination", "name", "established", "efficiency"),
          "embargo", List.of("id", "initiator", "targets", "resource", "start"),
          "quota", List.of("id", "nation", "resource", "max", "start", "reset", "type"));

  record Damage(String name, Consumer<Properties> apply) {
    @Override
    public String toString() {
      return name;
    }
  }

  static Stream<Damage> corruptions() {
    List<Damage> values = new ArrayList<>();
    for (String collection : COLLECTIONS) {
      String count = collection + ".count";
      String prefix = collection + ".0.";
      values.add(new Damage(count + " missing", p -> p.remove(count)));
      for (String value : List.of("-1", "invalid", "0", "2", "01"))
        values.add(new Damage(count + "=" + value, p -> p.setProperty(count, value)));
      values.add(new Damage(prefix + "unknown", p -> p.setProperty(prefix + "unknown", "value")));
      values.add(
          new Damage(
              collection + " index alias",
              p -> p.setProperty(collection + ".00.id", p.getProperty(prefix + "id"))));
      values.add(
          new Damage(
              collection + " index gap",
              p -> {
                for (String key : new HashSet<>(p.stringPropertyNames()))
                  if (key.startsWith(prefix))
                    p.setProperty(
                        collection + ".1." + key.substring(prefix.length()),
                        (String) p.remove(key));
              }));
      values.add(
          new Damage(
              collection + " duplicate",
              p -> {
                for (String key : new HashSet<>(p.stringPropertyNames()))
                  if (key.startsWith(prefix))
                    p.setProperty(
                        collection + ".1." + key.substring(prefix.length()), p.getProperty(key));
                p.setProperty(count, "2");
              }));
      values.add(new Damage(prefix + "id short", p -> p.setProperty(prefix + "id", "0-0-0-0-1")));
      for (String field : REQUIRED.get(collection))
        values.add(new Damage(prefix + field + " missing", p -> p.remove(prefix + field)));
    }
    for (String[] row :
        new String[][] {
          {"agreement.0.exporter", "0-0-0-0-1"},
          {"agreement.0.importer", "invalid"},
          {"agreement.0.resource", ""},
          {"agreement.0.resource", " iron "},
          {"agreement.0.amount", "0"},
          {"agreement.0.amount", "-1"},
          {"agreement.0.amount", "9223372036854775808"},
          {"agreement.0.price", "NaN"},
          {"agreement.0.price", "Infinity"},
          {"agreement.0.price", "0.0"},
          {"agreement.0.price", "-1.0"},
          {"agreement.0.price", "0x1.0p0"},
          {"agreement.0.start", "text"},
          {"agreement.0.expiry", "0"},
          {"agreement.0.autoRenew", "TRUE"},
          {"route.0.origin", "invalid"},
          {"route.0.destination", "0-0-0-0-2"},
          {"route.0.name", " "},
          {"route.0.efficiency", "NaN"},
          {"route.0.efficiency", "Infinity"},
          {"route.0.efficiency", "-0.1"},
          {"route.0.efficiency", "2.1"},
          {"route.0.efficiency", "-0.0"},
          {"route.0.active", "yes"},
          {"route.0.volume", "-1"},
          {"route.0.volume", "01"},
          {"route.0.established", "text"},
          {"embargo.0.initiator", "invalid"},
          {"embargo.0.targets", ""},
          {"embargo.0.targets", IMPORTER.value() + ",invalid"},
          {"embargo.0.targets", IMPORTER.value() + ","},
          {"embargo.0.targets", IMPORTER.value() + "," + IMPORTER.value()},
          {"embargo.0.targets", EXPORTER.value().toString()},
          {"embargo.0.resource", " "},
          {"embargo.0.resource", "iron "},
          {"embargo.0.start", "+0"},
          {"embargo.0.expiry", "text"},
          {"embargo.0.expiry", "0"},
          {"embargo.0.active", "FALSE"},
          {"quota.0.nation", "0-0-0-0-2"},
          {"quota.0.resource", " iron"},
          {"quota.0.resource", ""},
          {"quota.0.max", "0"},
          {"quota.0.max", "-1"},
          {"quota.0.current", "-1"},
          {"quota.0.current", "11"},
          {"quota.0.current", "1.5"},
          {"quota.0.start", "text"},
          {"quota.0.reset", "0"},
          {"quota.0.type", "export"}
        }) values.add(new Damage(row[0] + "=" + row[1], p -> p.setProperty(row[0], row[1])));
    return values.stream();
  }

  static Stream<Arguments> storesAndCorruptions() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(engine -> corruptions().map(d -> Arguments.of(engine, d)));
  }

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @MethodSource("storesAndCorruptions")
  void malformedTradeStateCannotEstablishAuthorityOrOverwriteEvidence(String engine, Damage damage)
      throws Exception {
    var storage = seeded(engine);
    var damaged = storage.load();
    damage.apply.accept(damaged);
    storage.save(damaged);
    var before = storage.load();
    var module = module(storage);
    assertEquals("", module.authorityDomainId(), damage.name);
    assertFalse(module.grant(EXPORTER, "industrial", 1));
    assertFalse(module.consume(EXPORTER, "industrial", 1));
    assertEquals(
        NationResourceTransactionService.Status.REJECTED,
        module.grant(InventorySnapshotValidationTest.request("later")).status());
    assertThrows(IllegalStateException.class, () -> module.transactionReceipt("later"));
    assertThrows(
        IllegalStateException.class,
        () ->
            ((SimpleResourceTradeService) module.getTradeService())
                .isEmbargoed(EXPORTER, IMPORTER, "iron"));
    assertThrows(
        IllegalStateException.class,
        () ->
            ((SimpleResourceTradeService) module.getTradeService())
                .getQuota(IMPORTER, "iron", ResourceQuota.QuotaType.IMPORT));
    assertEquals(before, storage.load());
  }

  @ParameterizedTest
  @ValueSource(strings = {"agreement", "route", "embargo", "quota"})
  void damageDuringCommitRecoveryStopsTradeBeforeTreasuryOrQuotaEffects(String collection)
      throws Exception {
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          boolean damage;

          @Override
          public void save(Properties state) {
            super.save(state);
            if (damage) {
              damage = false;
              this.state.remove(collection + ".0.id");
              throw new IllegalStateException(
                  "commit acknowledgement lost with damaged trade state");
            }
          }
        };
    storage.state.putAll(validTrade());
    var module = module(storage);
    assertTrue(module.grant(EXPORTER, "industrial", 6));
    var treasury = mock(TreasuryService.class);
    var service = new SimpleResourceTradeService(module, treasury);
    set(module, "tradeService", service);
    load(module);
    storage.damage = true;
    assertFalse(module.grant(EXPORTER, "industrial", 1));
    assertEquals("", module.authorityDomainId());
    var before = storage.load();
    assertThrows(IllegalStateException.class, () -> service.executeTradeAgreement(AGREEMENT));
    assertThrows(IllegalStateException.class, () -> service.useQuota(QUOTA, 1));
    assertThrows(IllegalStateException.class, service::resetExpiredQuotas);
    assertThrows(IllegalStateException.class, () -> service.liftEmbargo(EXPORTER, EMBARGO));
    assertThrows(
        IllegalStateException.class, () -> service.cancelTradeAgreement(EXPORTER, AGREEMENT));
    assertThrows(
        IllegalStateException.class, () -> service.createTradeRoute(EXPORTER, THIRD, "new"));
    verifyNoInteractions(treasury);
    assertFalse(module.grant(EXPORTER, "luxury", 1));
    assertEquals(before, storage.load());
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void validFieldsSurviveRestartAndUnrelatedInventoryCommit(String engine) throws Exception {
    var storage = seeded(engine);
    var before = storage.load();
    var module = module(storage);
    assertFalse(module.authorityDomainId().isBlank());
    assertEquals(tradeFields(before), encodedTrade(module));
    assertEquals(before, storage.load());
    assertTrue(module.grant(EXPORTER, "luxury", 1));
    assertEquals(tradeFields(before), tradeFields(storage.load()));
    assertEquals(tradeFields(before), encodedTrade(module(storage)));
  }

  @Test
  void inheritedLegacyDefaultsAndHistoricalLimitsRemainReadable() throws Exception {
    var defaults = validTrade();
    for (String key :
        List.of(
            "agreement.0.autoRenew",
            "route.0.active",
            "route.0.volume",
            "embargo.0.expiry",
            "embargo.0.reason",
            "embargo.0.active",
            "quota.0.current")) defaults.remove(key);
    defaults.setProperty("agreement.0.amount", Long.toString(Long.MAX_VALUE));
    defaults.setProperty("agreement.0.price", Double.toString(Double.MAX_VALUE));
    defaults.setProperty("agreement.0.start", Long.toString(Long.MIN_VALUE));
    defaults.setProperty("agreement.0.expiry", Long.toString(Long.MAX_VALUE));
    defaults.setProperty("route.0.established", Long.toString(Long.MIN_VALUE));
    defaults.setProperty("quota.0.max", Long.toString(Long.MAX_VALUE));
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          @Override
          public Properties load() {
            return new Properties(state);
          }
        };
    storage.state.putAll(defaults);
    // Establish a domain before checking a read-only legacy load with inherited keys.
    storage.state.setProperty("resource.authority-domain", new UUID(0, 99).toString());
    var module = module(storage);
    assertFalse(module.authorityDomainId().isBlank());
    var expected = tradeFields(defaults);
    expected.setProperty("agreement.0.autoRenew", "false");
    expected.setProperty("route.0.active", "true");
    expected.setProperty("route.0.volume", "0");
    expected.setProperty("embargo.0.reason", "未说明");
    expected.setProperty("embargo.0.active", "true");
    expected.setProperty("quota.0.current", "0");
    assertEquals(expected, encodedTrade(module));
    assertEquals(tradeFields(defaults), tradeFields(storage.load()));
    assertTrue(module.grant(EXPORTER, "luxury", 1));
    assertEquals(expected, tradeFields(storage.load()));
  }

  ResourceStateStorage seeded(String engine) throws Exception {
    var helper = new InventoryCommitRecoveryTest();
    helper.directory = directory;
    var storage = helper.fixture(engine).storage();
    var state = storage.load();
    state.putAll(validTrade());
    storage.save(state);
    return storage;
  }

  static Properties validTrade() {
    var start = Instant.ofEpochMilli(0);
    var end = Instant.ofEpochMilli(Long.MAX_VALUE);
    var agreement = new TradeAgreement(AGREEMENT, EXPORTER, IMPORTER, "iron", 3, 2.5, start, end);
    agreement.setAutoRenew(true);
    return tradeFields(
        ResourceStateCodec.toProperties(
            Map.of(),
            Map.of(),
            Map.of(),
            Map.of(AGREEMENT, agreement),
            Map.of(
                ROUTE,
                new TradeRoute(
                    ROUTE, EXPORTER, IMPORTER, "旧港 route", start, 1.25, false, 9007199254740993L)),
            Map.of(
                EMBARGO,
                new ResourceEmbargo(
                    EMBARGO,
                    EXPORTER,
                    Set.of(IMPORTER, THIRD),
                    "custom:iron",
                    start,
                    end,
                    "original reason",
                    false)),
            Map.of(
                QUOTA,
                new ResourceQuota(
                    QUOTA, IMPORTER, "iron", 10, 7, start, end, ResourceQuota.QuotaType.IMPORT))));
  }

  static Properties encodedTrade(ResourceModule module) {
    var trade = ((SimpleResourceTradeService) module.getTradeService());
    return tradeFields(
        ResourceStateCodec.toProperties(
            Map.of(),
            Map.of(),
            Map.of(),
            trade.snapshotAgreements(),
            trade.snapshotRoutes(),
            trade.snapshotEmbargoes(),
            trade.snapshotQuotas()));
  }

  static Properties tradeFields(Properties state) {
    var result = new Properties();
    for (String key : state.stringPropertyNames())
      if (COLLECTIONS.stream().anyMatch(prefix -> key.startsWith(prefix + '.')))
        result.setProperty(key, state.getProperty(key));
    return result;
  }

  static ResourceModule module(ResourceStateStorage storage) throws Exception {
    var module = new ResourceModule();
    set(module, "stateStorage", storage);
    set(module, "factoryClock", FactorySnapshotVersionTest.CLOCK);
    set(module, "tradeService", new SimpleResourceTradeService(module));
    load(module);
    return module;
  }

  static void set(ResourceModule module, String name, Object value) throws Exception {
    var field = ResourceModule.class.getDeclaredField(name);
    field.setAccessible(true);
    field.set(module, value);
  }

  static void load(ResourceModule module) throws Exception {
    var method = ResourceModule.class.getDeclaredMethod("loadState");
    method.setAccessible(true);
    method.invoke(module);
  }
}
