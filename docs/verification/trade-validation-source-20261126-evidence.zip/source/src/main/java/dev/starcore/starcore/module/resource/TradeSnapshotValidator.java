package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.resource.model.ResourceQuota;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

/** Validate complete trade records before the permissive legacy decoder can discard any fields. */
final class TradeSnapshotValidator {
  private TradeSnapshotValidator() {}

  static void validate(Properties state) {
    Set<String> keys = state.stringPropertyNames();
    int agreements =
        count(
            state,
            keys,
            "agreement",
            8,
            Set.of(
                "id",
                "exporter",
                "importer",
                "resource",
                "amount",
                "price",
                "start",
                "expiry",
                "autoRenew"));
    int routes =
        count(
            state,
            keys,
            "route",
            6,
            Set.of(
                "id",
                "origin",
                "destination",
                "name",
                "established",
                "efficiency",
                "active",
                "volume"));
    int embargoes =
        count(
            state,
            keys,
            "embargo",
            5,
            Set.of(
                "id", "initiator", "targets", "resource", "start", "expiry", "reason", "active"));
    int quotas =
        count(
            state,
            keys,
            "quota",
            7,
            Set.of("id", "nation", "resource", "max", "current", "start", "reset", "type"));
    Set<String> identities = new HashSet<>();
    for (int index = 0; index < agreements; index++) {
      String prefix = "agreement." + index + '.';
      identity(state, prefix, identities);
      uuid(required(state, prefix + "exporter"), prefix + "exporter");
      uuid(required(state, prefix + "importer"), prefix + "importer");
      resource(state, prefix + "resource");
      require(number(state, prefix + "amount") > 0, prefix + "amount");
      require(decimal(state, prefix + "price") > 0, prefix + "price");
      require(
          number(state, prefix + "expiry") > number(state, prefix + "start"), prefix + "expiry");
      optionalBoolean(state, prefix + "autoRenew");
    }
    identities.clear();
    for (int index = 0; index < routes; index++) {
      String prefix = "route." + index + '.';
      identity(state, prefix, identities);
      uuid(required(state, prefix + "origin"), prefix + "origin");
      uuid(required(state, prefix + "destination"), prefix + "destination");
      require(!required(state, prefix + "name").isBlank(), prefix + "name");
      number(state, prefix + "established");
      double efficiency = decimal(state, prefix + "efficiency");
      // The model clamps out-of-range values and negative zero; recovery must not alter them.
      require(Double.compare(efficiency, 0.0) >= 0 && efficiency <= 2.0, prefix + "efficiency");
      optionalBoolean(state, prefix + "active");
      require(optionalNumber(state, prefix + "volume", 0) >= 0, prefix + "volume");
    }
    identities.clear();
    for (int index = 0; index < embargoes; index++) {
      String prefix = "embargo." + index + '.';
      identity(state, prefix, identities);
      String initiator = uuid(required(state, prefix + "initiator"), prefix + "initiator");
      Set<String> targets = new HashSet<>();
      for (String target : required(state, prefix + "targets").split(",", -1)) {
        uuid(target, prefix + "targets");
        require(!initiator.equals(target) && targets.add(target), prefix + "targets");
      }
      resource(state, prefix + "resource");
      long start = number(state, prefix + "start");
      if (state.getProperty(prefix + "expiry") != null)
        require(number(state, prefix + "expiry") > start, prefix + "expiry");
      optionalBoolean(state, prefix + "active");
    }
    identities.clear();
    for (int index = 0; index < quotas; index++) {
      String prefix = "quota." + index + '.';
      identity(state, prefix, identities);
      uuid(required(state, prefix + "nation"), prefix + "nation");
      resource(state, prefix + "resource");
      long max = number(state, prefix + "max");
      long current = optionalNumber(state, prefix + "current", 0);
      require(max > 0, prefix + "max");
      require(current >= 0 && current <= max, prefix + "current");
      require(number(state, prefix + "reset") > number(state, prefix + "start"), prefix + "reset");
      try {
        ResourceQuota.QuotaType.valueOf(required(state, prefix + "type"));
      } catch (IllegalArgumentException error) {
        throw invalid(prefix + "type");
      }
    }
  }

  private static int count(
      Properties state,
      Set<String> keys,
      String collection,
      int requiredFields,
      Set<String> allowed) {
    String countKey = collection + ".count";
    long count = optionalNumber(state, countKey, 0);
    require(count >= 0 && count <= Integer.MAX_VALUE, countKey);
    String prefix = collection + '.';
    long fields = 0;
    for (String key : keys) {
      if (!key.startsWith(prefix) || key.equals(countKey)) continue;
      int separator = key.indexOf('.', prefix.length());
      require(separator > prefix.length(), key);
      long index = integer(key.substring(prefix.length(), separator), key);
      require(index >= 0 && index < count && allowed.contains(key.substring(separator + 1)), key);
      fields++;
    }
    // Reject impossible counts before allocating per-row state or entering a count-sized loop.
    require(fields >= count * requiredFields && fields <= count * allowed.size(), countKey);
    return (int) count;
  }

  private static void identity(Properties state, String prefix, Set<String> identities) {
    String key = prefix + "id";
    require(identities.add(uuid(required(state, key), key)), key);
  }

  private static String required(Properties state, String key) {
    String value = state.getProperty(key);
    require(value != null, key);
    return value;
  }

  private static String uuid(String value, String key) {
    try {
      require(UUID.fromString(value).toString().equals(value), key);
    } catch (IllegalArgumentException error) {
      throw invalid(key);
    }
    return value;
  }

  private static void resource(Properties state, String key) {
    String value = required(state, key);
    // Preserve historical resource IDs and terms; current creation limits are not a migration rule.
    require(!value.isEmpty() && value.equals(value.trim()), key);
  }

  private static long optionalNumber(Properties state, String key, long fallback) {
    String value = state.getProperty(key);
    return value == null ? fallback : integer(value, key);
  }

  private static long number(Properties state, String key) {
    return integer(required(state, key), key);
  }

  private static long integer(String value, String key) {
    try {
      long number = Long.parseLong(value);
      require(Long.toString(number).equals(value), key);
      return number;
    } catch (NumberFormatException error) {
      throw invalid(key);
    }
  }

  private static double decimal(Properties state, String key) {
    String value = required(state, key);
    try {
      double number = Double.parseDouble(value);
      require(Double.isFinite(number) && Double.toString(number).equals(value), key);
      return number;
    } catch (NumberFormatException error) {
      throw invalid(key);
    }
  }

  private static void optionalBoolean(Properties state, String key) {
    String value = state.getProperty(key);
    require(value == null || value.equals("true") || value.equals("false"), key);
  }

  private static void require(boolean valid, String key) {
    if (!valid) throw invalid(key);
  }

  private static IllegalStateException invalid(String key) {
    return new IllegalStateException("Trade snapshot requires recovery at " + key);
  }
}
