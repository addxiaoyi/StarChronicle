package dev.starcore.starcore.essentials.command;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.player.PlayerNameDirectory;
import dev.starcore.starcore.essentials.social.SocialService;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Private messages and ignore changes retain the original player sessions. */
public final class SocialCommand implements CommandExecutor, TabCompleter {
  private final SocialService socialService;
  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final BooleanSupplier lifetime;
  private final PlayerNameDirectory names;

  /** Legacy synchronous entry: the caller must already own every accessed player. */
  public SocialCommand(SocialService socialService) {
    this.socialService = Objects.requireNonNull(socialService);
    this.plugin = null;
    this.scheduler = null;
    this.lifetime = () -> true;
    this.names = null;
  }

  public SocialCommand(
      SocialService socialService,
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      BooleanSupplier lifetime,
      PlayerNameDirectory names) {
    this.socialService = Objects.requireNonNull(socialService);
    this.plugin = Objects.requireNonNull(plugin);
    this.scheduler = Objects.requireNonNull(scheduler);
    this.lifetime = Objects.requireNonNull(lifetime);
    this.names = Objects.requireNonNull(names);
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (!active()) return true;
    if (!(sender instanceof Player player)) {
      sender.sendMessage(Component.text("只有玩家可以使用此命令", NamedTextColor.RED));
      return true;
    }
    if (plugin != null && (!sameSession(player) || !player.isOnline())) return true;
    String name = command.getName().toLowerCase(Locale.ROOT);
    switch (name) {
      case "msg", "tell", "whisper", "w" -> {
        if (args.length < 2) say(player, "用法: /msg <玩家> <消息>", NamedTextColor.YELLOW);
        else {
          Player target = find(args[0]);
          if (target == null) say(player, "玩家不在线: " + args[0], NamedTextColor.RED);
          else send(player, target, String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
        }
      }
      case "reply", "r" -> {
        if (args.length == 0) say(player, "用法: /reply <消息>", NamedTextColor.YELLOW);
        else {
          UUID targetId = socialService.getLastMessaged(player.getUniqueId()).orElse(null);
          if (targetId == null) say(player, "没有可回复的玩家", NamedTextColor.RED);
          else {
            Player target =
                plugin == null
                    ? Bukkit.getPlayer(targetId)
                    : plugin.getServer().getPlayer(targetId);
            if (target == null) say(player, "该玩家已离线", NamedTextColor.RED);
            else send(player, target, String.join(" ", args));
          }
        }
      }
      case "ignore", "unignore" -> ignore(player, args, name.equals("ignore"));
      default -> {}
    }
    return true;
  }

  private Player find(String name) {
    return plugin == null ? Bukkit.getPlayer(name) : plugin.getServer().getPlayer(name);
  }

  private void send(Player sender, Player target, String message) {
    UUID senderId = sender.getUniqueId(), targetId = target.getUniqueId();
    if (senderId.equals(targetId)) {
      say(sender, "你不能给自己发消息", NamedTextColor.RED);
      return;
    }
    String senderName = sender.getName(); // Caller is this exact sender's owner.
    owned(
        target,
        () -> {
          if (!sameSession(sender)) return;
          String targetName = target.getName();
          // The record is an admitted local message, not a network delivery receipt.
          if (!socialService.recordMessage(senderId, targetId, message)) {
            feedback(sender, "该玩家屏蔽了你");
            return;
          }
          try {
            target.sendMessage(
                Component.text("[" + senderName + " -> 我] ", NamedTextColor.GRAY)
                    .append(Component.text(message, NamedTextColor.WHITE)));
          } catch (RuntimeException failure) {
            log("Private message delivery unconfirmed", failure);
            feedback(sender, "私聊投递未确认，请核对后再重发");
            return;
          }
          owned(
              sender,
              () ->
                  sender.sendMessage(
                      Component.text("[我 -> " + targetName + "] ", NamedTextColor.GRAY)
                          .append(Component.text(message, NamedTextColor.WHITE))),
              () -> {});
        },
        () -> feedback(sender, "目标玩家当前不可用"));
  }

  private void ignore(Player player, String[] args, boolean ignore) {
    if (args.length == 0) {
      say(player, "用法: /" + (ignore ? "ignore" : "unignore") + " <玩家>", NamedTextColor.YELLOW);
      return;
    }
    Player target = find(args[0]);
    if (target == null) {
      say(player, "找不到玩家: " + args[0], NamedTextColor.RED);
      return;
    }
    UUID playerId = player.getUniqueId(), targetId = target.getUniqueId();
    if (playerId.equals(targetId)) {
      say(player, "你不能屏蔽自己", NamedTextColor.RED);
      return;
    }
    owned(
        target,
        () -> {
          String targetName = target.getName();
          owned(
              player,
              () -> {
                if (!sameSession(target)) {
                  say(player, "目标玩家当前不可用", NamedTextColor.RED);
                  return;
                }
                if (ignore) {
                  boolean added = socialService.ignorePlayer(playerId, targetId);
                  say(player, (added ? "已屏蔽玩家: " : "已屏蔽该玩家: ") + targetName, NamedTextColor.GREEN);
                } else if (socialService.unignorePlayer(playerId, targetId)) {
                  say(player, "已取消屏蔽玩家: " + targetName, NamedTextColor.GREEN);
                } else say(player, "该玩家未被屏蔽", NamedTextColor.YELLOW);
              },
              () -> {});
        },
        () -> feedback(player, "目标玩家当前不可用"));
  }

  private boolean active() {
    return lifetime.getAsBoolean() && (plugin == null || plugin.isEnabled());
  }

  private boolean sameSession(Player player) {
    return plugin == null || plugin.getServer().getPlayer(player.getUniqueId()) == player;
  }

  private void owned(Player player, Runnable action, Runnable unavailable) {
    if (!active()) return;
    if (scheduler == null) {
      action.run();
      return;
    }
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable retired =
        () -> {
          if (claimed.compareAndSet(false, true) && active()) unavailable.run();
        };
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (!claimed.compareAndSet(false, true) || !active()) return;
            try {
              if (sameSession(player) && player.isOnline()) action.run();
              else unavailable.run();
            } catch (RuntimeException failure) {
              log("Social owner callback unavailable", failure);
              if (active()) unavailable.run();
            }
          },
          retired);
    } catch (RuntimeException failure) {
      retired.run();
      log("Social owner registration unavailable", failure);
    }
  }

  private void feedback(Player player, String message) {
    owned(player, () -> say(player, message, NamedTextColor.RED), () -> {});
  }

  private static void say(Player player, String text, NamedTextColor color) {
    player.sendMessage(Component.text(text, color));
  }

  private void log(String message, RuntimeException failure) {
    if (plugin != null) plugin.getLogger().log(Level.FINE, message, failure);
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (!active()
        || args.length != 1
        || !Set.of("msg", "tell", "whisper", "w", "ignore", "unignore")
            .contains(command.getName().toLowerCase(Locale.ROOT))) return List.of();
    UUID exclude = sender instanceof Player p ? p.getUniqueId() : null;
    if (names != null) {
      if (sender instanceof Player player && !sameSession(player)) return List.of();
      names.refresh();
      return names.names(exclude, args[0]);
    }
    // Compatibility constructor: shared-owner synchronous contract only.
    String prefix = args[0].toLowerCase(Locale.ROOT);
    return Bukkit.getOnlinePlayers().stream()
        .filter(p -> !p.getUniqueId().equals(exclude))
        .map(Player::getName)
        .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix))
        .sorted(String.CASE_INSENSITIVE_ORDER)
        .toList();
  }
}
