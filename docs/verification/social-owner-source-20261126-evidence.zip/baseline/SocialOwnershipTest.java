package dev.starcore.starcore.essentials.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.player.PlayerNameDirectory;
import dev.starcore.starcore.essentials.social.SocialService;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.Answers;
import org.mockito.MockedStatic;

/** Each mutable Player access must occur in that exact player's owner queue. */
class SocialOwnershipTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final SocialService service = new SocialService();
  private final Map<UUID, Player> online = new HashMap<>();
  private final Map<Player, State> states = new IdentityHashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private Player sender, target, owner, rejectOwner;
  private boolean enabled = true, lifetime = true, throwAfterQueue;
  private PlayerNameDirectory names;
  private SocialCommand command;
  private MockedStatic<Bukkit> bukkit;

  private static final class State {
    UUID id;
    String name;
    boolean online = true, throwOnMessage;
    final List<String> messages = new ArrayList<>();
  }

  private record Job(Player player, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() throws Exception {
    when(plugin.isEnabled()).thenAnswer(i -> enabled);
    when(plugin.getServer()).thenReturn(server);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getPlayer(anyString())).thenAnswer(i -> byName(i.getArgument(0)));
    when(server.getOnlinePlayers()).thenAnswer(i -> List.copyOf(online.values()));
    doAnswer(i -> {
      Player p = i.getArgument(0);
      if (p == rejectOwner) throw new IllegalStateException("Owner unavailable");
      jobs.add(new Job(p, () -> i.<Consumer<Object>>getArgument(1).accept(null), i.getArgument(2)));
      if (throwAfterQueue) throw new IllegalStateException("Registration result lost");
      return null;
    }).when(scheduler).runAtEntity(any(), any(), any());
    sender = player("Sender", UUID.randomUUID());
    target = player("Target", UUID.randomUUID());
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(() -> Bukkit.getPlayer(anyString())).thenAnswer(i -> byName(i.getArgument(0)));
    bukkit.when(() -> Bukkit.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    bukkit.when(Bukkit::getOnlinePlayers).thenAnswer(i -> List.copyOf(online.values()));
    names = new PlayerNameDirectory(plugin, scheduler, () -> lifetime);
    owned(sender, () -> names.observe(sender));
    owned(target, () -> names.observe(target));
    // Also runs against the frozen predecessor to reproduce its foreign-owner accesses.
    try {
      command = SocialCommand.class.getConstructor(SocialService.class, Plugin.class,
          FoliaCompatScheduler.class, BooleanSupplier.class, PlayerNameDirectory.class)
          .newInstance(service, plugin, scheduler, (BooleanSupplier) () -> lifetime, names);
    } catch (NoSuchMethodException oldApi) {
      command = new SocialCommand(service);
    }
  }

  @AfterEach void cleanup() { bukkit.close(); }

  private Player byName(String name) {
    return online.values().stream().filter(p -> states.get(p).name.equalsIgnoreCase(name))
        .findFirst().orElse(null);
  }

  private Player player(String name, UUID id) {
    State state = new State(); state.id = id; state.name = name;
    Player p = mock(Player.class, i -> {
      String method = i.getMethod().getName();
      if (method.equals("getUniqueId")) return id;
      if (Set.of("getName", "isOnline", "sendMessage", "getServer").contains(method)) {
        assertSame(i.getMock(), owner, "Foreign owner: " + name + "." + method);
        return switch (method) {
          case "getName" -> state.name;
          case "isOnline" -> state.online;
          case "getServer" -> server;
          default -> {
            if (state.throwOnMessage) throw new IllegalStateException("Transport unavailable");
            Object message = i.getArgument(0);
            state.messages.add(message instanceof Component c
                ? PlainTextComponentSerializer.plainText().serialize(c) : String.valueOf(message));
            yield null;
          }
        };
      }
      return Answers.RETURNS_DEFAULTS.answer(i);
    });
    states.put(p, state); online.put(id, p); return p;
  }

  private void owned(Player p, Runnable action) {
    Player before = owner; owner = p;
    try { action.run(); } finally { owner = before; }
  }
  private void run(Job job) { owned(job.player(), job.body()); }
  private void drain() {
    int remaining = 40;
    while (!jobs.isEmpty()) { assertTrue(remaining-- > 0); run(jobs.remove()); }
  }
  private void invoke(Player p, String name, String... args) {
    Command cmd = mock(Command.class); when(cmd.getName()).thenReturn(name);
    owned(p, () -> command.onCommand(p, cmd, name, args));
  }
  private void send() { invoke(sender, "msg", "Target", "hello", "world"); }
  private List<String> messages(Player p) { return states.get(p).messages; }
  private UUID id(Player p) { return states.get(p).id; }
  private void noDelivery() {
    assertTrue(messages(target).isEmpty());
    assertTrue(service.getMessageHistory(id(target)).isEmpty());
    assertTrue(service.getLastMessaged(id(target)).isEmpty());
  }

  @Test void privateMessageUsesBothOwnersAndRecordsOnce() {
    send(); assertTrue(messages(target).isEmpty()); drain();
    assertEquals(1, messages(target).size()); assertEquals(1, messages(sender).size());
    assertTrue(messages(target).getFirst().contains("Sender"));
    assertTrue(messages(sender).getFirst().contains("Target"));
    assertEquals("hello world", service.getMessageHistory(id(target)).getFirst().content());
    assertEquals(id(sender), service.getLastMessaged(id(target)).orElseThrow());
  }
  @Test void replyUsesTheRecipientsOwner() {
    send(); drain(); invoke(target, "r", "answer"); drain();
    assertEquals("answer", service.getMessageHistory(id(sender)).getFirst().content());
    assertEquals(2, messages(sender).size()); assertEquals(2, messages(target).size());
  }
  @Test void senderReplacementBeforeDeliveryCannotSend() {
    send(); player("Sender", id(sender)); drain(); noDelivery();
    assertTrue(messages(sender).isEmpty());
  }
  @Test void recipientReplacementCannotReceiveOldMessage() {
    send(); Player replacement = player("Target", id(target)); drain(); noDelivery();
    assertTrue(messages(replacement).isEmpty()); assertEquals(1, messages(sender).size());
  }
  @Test void senderReplacementAfterDeliveryCannotReceiveEcho() {
    send(); run(jobs.remove()); Player replacement = player("Sender", id(sender)); drain();
    assertEquals(1, messages(target).size()); assertTrue(messages(replacement).isEmpty());
    assertTrue(messages(sender).isEmpty());
  }
  @Test void recipientOfflineBeforeOwnerAdmissionRejects() {
    send(); states.get(target).online = false; drain(); noDelivery();
    assertEquals(1, messages(sender).size());
  }
  @Test void ignoreAddedWhileQueuedRejectsWithoutHistory() {
    send(); service.ignorePlayer(id(target), id(sender)); drain(); noDelivery();
    assertTrue(messages(sender).getFirst().contains("屏蔽"));
  }
  @Test void moduleClosureBeforeDeliveryRejects() {
    send(); lifetime = false; drain(); noDelivery(); assertTrue(messages(sender).isEmpty());
  }
  @Test void pluginDisableBeforeDeliveryRejects() {
    send(); enabled = false; drain(); noDelivery(); assertTrue(messages(sender).isEmpty());
  }
  @Test void moduleClosureBeforeEchoSuppressesOldFeedback() {
    send(); run(jobs.remove()); lifetime = false; drain();
    assertEquals(1, messages(target).size()); assertTrue(messages(sender).isEmpty());
  }
  @Test void duplicateOwnerAndRetirementCallbacksDoNotRepeatMessage() {
    send(); Job job = jobs.remove(); run(job); run(job); job.retired().run(); drain();
    assertEquals(1, messages(target).size()); assertEquals(1, messages(sender).size());
    assertEquals(1, service.getMessageHistory(id(sender)).size());
  }
  @Test void retirementBeforeOwnerCallbackRejectsOnlyOnce() {
    send(); Job job = jobs.remove(); job.retired().run(); job.retired().run(); run(job); drain();
    noDelivery(); assertEquals(1, messages(sender).size());
  }
  @Test void registrationRejectionOnlyNotifiesOriginalSender() {
    rejectOwner = target; send(); drain(); noDelivery(); assertEquals(1, messages(sender).size());
  }
  @Test void callbackAfterRegistrationFailureCannotDeliver() {
    throwAfterQueue = true; send(); throwAfterQueue = false; drain(); noDelivery();
  }
  @Test void transportFailureIsNotReportedAsSuccessOrAutomaticallyRetried() {
    states.get(target).throwOnMessage = true; send(); drain();
    assertTrue(messages(target).isEmpty()); assertEquals(1, messages(sender).size());
    assertTrue(messages(sender).getFirst().contains("未确认"));
  }
  @Test void echoFailureDoesNotRepeatRecipientDelivery() {
    states.get(sender).throwOnMessage = true; send(); drain();
    assertEquals(1, messages(target).size()); assertEquals(1, service.getMessageHistory(id(target)).size());
  }
  @Test void ignoreCapturesTargetNameOnTargetThenMutatesOriginalSender() {
    invoke(sender, "ignore", "Target"); assertFalse(service.isIgnored(id(sender), id(target)));
    drain(); assertTrue(service.isIgnored(id(sender), id(target)));
    assertTrue(messages(sender).getFirst().contains("Target")); assertTrue(messages(target).isEmpty());
  }
  @Test void staleIgnoreCallbackCannotModifyReconnectedSender() {
    invoke(sender, "ignore", "Target"); run(jobs.remove()); player("Sender", id(sender)); drain();
    assertFalse(service.isIgnored(id(sender), id(target))); assertTrue(messages(sender).isEmpty());
  }
  @Test void staleIgnoreCallbackCannotTargetReconnectedRecipient() {
    invoke(sender, "ignore", "Target"); run(jobs.remove()); player("Target", id(target)); drain();
    assertFalse(service.isIgnored(id(sender), id(target)));
  }
  @Test void ignoreRemovedOnOwnersAllowsNextMessage() {
    service.ignorePlayer(id(sender), id(target)); invoke(sender, "unignore", "Target"); drain();
    assertFalse(service.isIgnored(id(sender), id(target)));
    invoke(target, "msg", "Sender", "allowed"); drain();
    assertEquals("allowed", service.getMessageHistory(id(sender)).getFirst().content());
  }
  @Test void duplicateIgnoreReportsAlreadyIgnoredInsteadOfSelf() {
    service.ignorePlayer(id(sender), id(target)); invoke(sender, "ignore", "Target"); drain();
    assertTrue(messages(sender).getFirst().contains("已屏蔽"));
    assertFalse(messages(sender).getFirst().contains("自己"));
  }
  @Test void completionUsesCachedNamesWithoutForeignPlayerReads() {
    Command cmd = mock(Command.class); when(cmd.getName()).thenReturn("msg");
    owned(sender, () -> assertEquals(List.of("Target"), command.onTabComplete(sender, cmd, "msg", new String[]{"ta"})));
  }
  @Test void replyAliasDoesNotCompletePlayerNames() {
    Command cmd = mock(Command.class); when(cmd.getName()).thenReturn("r");
    owned(sender, () -> assertEquals(List.of(), command.onTabComplete(sender, cmd, "r", new String[]{""})));
  }
  @Test void closedCommandDoesNotQueueOrSuggestNames() {
    lifetime = false; send(); assertTrue(jobs.isEmpty()); noDelivery();
    Command cmd = mock(Command.class); when(cmd.getName()).thenReturn("msg");
    owned(sender, () -> assertTrue(command.onTabComplete(sender, cmd, "msg", new String[]{""}).isEmpty()));
  }
}
