package dev.starcore.starcore.essentials;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.command.*;
import dev.starcore.starcore.essentials.data.EssentialsDataManager;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.listener.EssentialsGuiListener;
import dev.starcore.starcore.essentials.nickname.NicknameService;
import dev.starcore.starcore.essentials.player.PlayerNameDirectory;
import dev.starcore.starcore.essentials.social.SocialService;
import dev.starcore.starcore.essentials.teleport.TeleportConfig;
import dev.starcore.starcore.essentials.teleport.TeleportService;
import dev.starcore.starcore.essentials.warp.WarpService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.message.MessageService;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

/**
 * Essentials 模块 替代 EssentialsX 的核心功能
 *
 * <p>包含： - 传送系统（spawn/home/warp/tpa/back） - 社交系统（msg/reply/ignore） - 昵称系统（nick/realname） - Warp传送点
 * - 经济系统（bal/baltop/pay/eco）
 */
public final class EssentialsModule implements StarCoreModule, Listener {
  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final MessageService messages;
  private final EconomyService economyService;
  private EssentialsPermissions permissions;
  private TransactionFabric transactionFabric;

  // 服务
  private TeleportService teleportService;
  private HomeService homeService;
  private WarpService warpService;
  private SocialService socialService;
  private NicknameService nicknameService;
  private BalTopService balTopService;
  private EssentialsDataManager dataManager;
  private EssentialsGuiListener guiListener;
  private PlayerNameDirectory playerNames;
  private volatile Object lifecycle;
  private final List<CommandBinding> commandBindings = new ArrayList<>();

  public EssentialsModule(
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      MessageService messages,
      EconomyService economyService) {
    this.plugin = plugin;
    this.scheduler = scheduler;
    this.messages = messages;
    this.economyService = economyService;
  }

  @Override
  public ModuleMetadata metadata() {
    return new ModuleMetadata(
        "essentials",
        "Essentials Module",
        dev.starcore.starcore.core.module.ModuleLayer.FEATURE,
        List.of(),
        List.of(),
        "Essentials functionality module");
  }

  @Override
  public synchronized void enable(StarCoreContext context) {
    if (lifecycle != null) return;
    Object lifetime = new Object();
    lifecycle = lifetime;
    try {
      enableServices(context, lifetime);
      commandBindings.forEach(binding -> binding.handler.activate());
    } catch (RuntimeException | Error failure) {
      try {
        disable(context);
      } catch (RuntimeException | Error cleanupFailure) {
        if (cleanupFailure != failure) failure.addSuppressed(cleanupFailure);
      }
      throw failure;
    }
  }

  private void enableServices(StarCoreContext context, Object lifetime) {
    plugin.getLogger().info("正在启用 Essentials 模块...");
    this.transactionFabric = context.serviceRegistry().find(TransactionFabric.class).orElse(null);

    // 初始化配置
    TeleportConfig teleportConfig = TeleportConfig.from(context.configuration().getConfig());
    this.permissions = EssentialsPermissions.from(context.configuration().getConfig());

    // 初始化服务
    this.homeService = new HomeService(teleportConfig.maxHomes());
    this.warpService = new WarpService();
    this.socialService = new SocialService();
    this.nicknameService = new NicknameService();
    this.teleportService = new TeleportService(plugin, scheduler, teleportConfig, permissions);
    this.balTopService = new BalTopService();
    this.playerNames = new PlayerNameDirectory(plugin, scheduler, () -> lifecycle == lifetime);

    // 建立服务引用
    teleportService.setHomeService(homeService);
    teleportService.setWarpService(warpService);

    // 初始化数据管理器
    this.dataManager =
        new EssentialsDataManager(
            plugin, homeService, warpService, nicknameService, socialService, balTopService);

    // 加载数据
    dataManager.loadAll();

    // 注册命令
    this.guiListener =
        new EssentialsGuiListener(
            plugin, homeService, warpService, teleportService, balTopService, economyService);
    registerCommands(guiListener, lifetime);

    // ========== 注册 GUI 监听器 ==========
    plugin.getServer().getPluginManager().registerEvents(guiListener, plugin);

    // 注册主监听器
    plugin.getServer().getPluginManager().registerEvents(this, plugin);
    playerNames.refresh();

    // 定期保存数据（每5分钟）
    EssentialsDataManager enabledDataManager = dataManager;
    BalTopService enabledBalTopService = balTopService;
    scheduler.runGlobalRepeating(
        () -> {
          if (lifecycle == lifetime) enabledDataManager.saveAllAsync();
        },
        20L * 60 * 5,
        20L * 60 * 5);

    // 定期更新财富排行榜（每分钟）
    AtomicBoolean rankingQueued = new AtomicBoolean();
    AtomicBoolean providerWarning = new AtomicBoolean();
    scheduler.runGlobalRepeating(
        () -> {
          if (lifecycle != lifetime || !rankingQueued.compareAndSet(false, true)) return;
          AtomicBoolean refreshAdmitted = new AtomicBoolean();
          Runnable refresh =
              () -> {
                if (!refreshAdmitted.compareAndSet(false, true)) return;
                try {
                  if (lifecycle != lifetime) return;
                  var balances = economyService.getAllBalances();
                  if (lifecycle == lifetime) enabledBalTopService.updateRankings(balances);
                } catch (RuntimeException failure) {
                  plugin
                      .getLogger()
                      .log(
                          java.util.logging.Level.WARNING,
                          "Essentials ranking refresh unavailable",
                          failure);
                } finally {
                  rankingQueued.set(false);
                }
              };
          if (economyService instanceof InternalEconomyService) {
            try {
              scheduler.runAsync(refresh);
            } catch (RuntimeException rejected) {
              if (refreshAdmitted.compareAndSet(false, true)) rankingQueued.set(false);
              plugin
                  .getLogger()
                  .log(
                      java.util.logging.Level.WARNING,
                      "Essentials ranking refresh registration unavailable",
                      rejected);
            }
          } else if (!scheduler.isFolia()) {
            refresh.run(); // The timer is already on Paper's main thread.
          } else {
            rankingQueued.set(false);
            if (providerWarning.compareAndSet(false, true)) {
              plugin
                  .getLogger()
                  .warning("Essentials ranking refresh requires a verified Folia economy provider");
            }
          }
        },
        20L * 60,
        20L * 60);

    plugin.getLogger().info("✅ Essentials 模块已启用");
  }

  @Override
  public synchronized void disable(StarCoreContext context) {
    if (lifecycle == null) return;
    lifecycle = null;
    plugin.getLogger().info("正在禁用 Essentials 模块...");

    // Close every captured command before attempting fallible teardown. A command
    // already admitted may finish; this does not roll back its business effects.
    commandBindings.forEach(binding -> binding.handler.close());
    Throwable failure = null;
    if (playerNames != null) failure = cleanup(failure, playerNames::close);
    if (teleportService != null) failure = cleanup(failure, teleportService::shutdown);
    failure = cleanup(failure, this::unregisterCommands);
    failure = cleanup(failure, scheduler::cancelAll);
    failure = cleanup(failure, () -> HandlerList.unregisterAll(this));
    EssentialsGuiListener oldGuiListener = guiListener;
    guiListener = null;
    if (oldGuiListener != null) {
      failure = cleanup(failure, () -> HandlerList.unregisterAll(oldGuiListener));
    }
    if (dataManager != null) failure = cleanup(failure, dataManager::shutdownAndSave);
    rethrowCleanup(failure);

    plugin.getLogger().info("✅ Essentials 模块已禁用");
  }

  /** 注册命令 */
  private void registerCommands(EssentialsGuiListener guiListener, Object lifetime) {
    // ========== 社交命令 ==========
    SocialCommand socialCmd = new SocialCommand(socialService);
    registerCommand("msg", socialCmd);
    registerCommand("tell", socialCmd);
    registerCommand("whisper", socialCmd);
    registerCommand("reply", socialCmd);
    registerCommand("r", socialCmd);
    registerCommand("ignore", socialCmd);
    registerCommand("unignore", socialCmd);

    // ========== 昵称命令 ==========
    NicknameCommand nicknameCmd = new NicknameCommand(nicknameService, permissions);
    registerCommand("nick", nicknameCmd);
    registerCommand("realname", nicknameCmd);

    // ========== 家园命令 ==========
    HomeCommand homeCmd = new HomeCommand(homeService, teleportService);
    registerCommand("home", homeCmd);
    registerCommand("sethome", homeCmd);
    registerCommand("delhome", homeCmd);
    registerCommand("homes", homeCmd);

    // ========== Warp 命令 ==========
    WarpCommand warpCmd = new WarpCommand(warpService, teleportService, permissions);
    registerCommand("warp", warpCmd);
    registerCommand("setwarp", warpCmd);
    registerCommand("delwarp", warpCmd);
    registerCommand("warps", warpCmd);

    // ========== TPA 命令 ==========
    TpaCommand tpaCmd = new TpaCommand(teleportService);
    registerCommand("tpa", tpaCmd);
    registerCommand("tpaccept", tpaCmd);
    registerCommand("tpdeny", tpaCmd);
    registerCommand("back", tpaCmd);
    registerCommand("cooldown", tpaCmd);
    registerCommand("spawn", tpaCmd);
    registerCommand("setspawn", tpaCmd);

    // ========== 经济命令 ==========
    EconomyCommand economyCmd =
        new EconomyCommand(
            plugin,
            economyService,
            balTopService,
            transactionFabric,
            scheduler,
            permissions,
            () -> lifecycle == lifetime,
            playerNames);
    registerCommand("balance", economyCmd);
    registerCommand("bal", economyCmd);
    registerCommand("money", economyCmd);
    registerCommand("baltop", economyCmd);
    registerCommand("pay", economyCmd);
    registerCommand("eco", economyCmd);
    registerCommand("economy", economyCmd);

    // ========== GUI 命令 ==========
    EssentialsGuiCommand guiCmd =
        new EssentialsGuiCommand(
            homeService, warpService, teleportService, balTopService, economyService, guiListener);
    registerCommand("homegui", guiCmd);
    registerCommand("warpgui", guiCmd);
    registerCommand("baltopgui", guiCmd);
    registerCommand("teleporter", guiCmd);

    plugin
        .getLogger()
        .info(
            "已注册 Essentials 命令: home/sethome/delhome/homes, warp/setwarp/delwarp/warps,"
                + " tpa/tpaccept/tpdeny/back/cooldown/spawn/setspawn,"
                + " balance/baltop/pay/eco/economy,"
                + " homegui/warpgui/baltopgui/teleporter");
  }

  /** 注册单个命令 */
  private void registerCommand(String name, CommandExecutor executor) {
    String namespaced = plugin.getName().toLowerCase(Locale.ROOT) + ":" + name;
    PluginCommand command = plugin.getServer().getPluginCommand(namespaced);
    if (command == null || command.getPlugin() != plugin) {
      command = plugin.getServer().getPluginCommand(name);
    }
    if (command == null || command.getPlugin() != plugin) return;
    for (CommandBinding binding : commandBindings) {
      if (binding.command == command) return; // Aliases share the same PluginCommand.
    }
    LifecycleCommand handler = new LifecycleCommand(executor);
    CommandBinding binding =
        new CommandBinding(command, command.getExecutor(), command.getTabCompleter(), handler);
    commandBindings.add(binding); // Register before either setter can fail.
    command.setExecutor(handler);
    command.setTabCompleter(handler);
  }

  private void unregisterCommands() {
    List<CommandBinding> bindings = List.copyOf(commandBindings);
    commandBindings.clear();
    Throwable failure = null;
    for (CommandBinding binding : bindings) {
      failure =
          cleanup(
              failure,
              () -> {
                if (binding.command.getExecutor() == binding.handler) {
                  binding.command.setExecutor(binding.previousExecutor);
                }
              });
      failure =
          cleanup(
              failure,
              () -> {
                if (binding.command.getTabCompleter() == binding.handler) {
                  binding.command.setTabCompleter(binding.previousCompleter);
                }
              });
    }
    rethrowCleanup(failure);
  }

  private static Throwable cleanup(Throwable previous, Runnable action) {
    try {
      action.run();
    } catch (RuntimeException | Error failure) {
      if (previous == null) return failure;
      if (previous != failure) previous.addSuppressed(failure);
    }
    return previous;
  }

  private static void rethrowCleanup(Throwable failure) {
    if (failure instanceof RuntimeException runtime) throw runtime;
    if (failure instanceof Error error) throw error;
  }

  private record CommandBinding(
      PluginCommand command,
      CommandExecutor previousExecutor,
      TabCompleter previousCompleter,
      LifecycleCommand handler) {}

  /** A retained handler never becomes active again after disable/re-enable. */
  private static final class LifecycleCommand implements TabExecutor {
    private volatile CommandExecutor delegate;
    private volatile boolean active;

    private LifecycleCommand(CommandExecutor delegate) {
      this.delegate = delegate;
    }

    private void activate() {
      active = true;
    }

    private void close() {
      active = false;
      delegate = null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      CommandExecutor current = delegate;
      if (!active || current == null) {
        sender.sendMessage("§cEssentials 模块当前不可用");
        return true;
      }
      return current.onCommand(sender, command, label, args);
    }

    @Override
    public List<String> onTabComplete(
        CommandSender sender, Command command, String alias, String[] args) {
      CommandExecutor current = delegate;
      if (!active || !(current instanceof TabCompleter completer)) return List.of();
      return completer.onTabComplete(sender, command, alias, args);
    }
  }

  /** 玩家加入 */
  @EventHandler
  public void onPlayerJoin(PlayerJoinEvent event) {
    if (lifecycle == null) return;
    playerNames.observe(event.getPlayer());
  }

  @EventHandler(ignoreCancelled = true)
  public void onPlayerMove(PlayerMoveEvent event) {
    if (lifecycle == null) return;
    if (event.getTo() == null
        || (event.getFrom().getWorld() == event.getTo().getWorld()
            && event.getFrom().getBlockX() == event.getTo().getBlockX()
            && event.getFrom().getBlockY() == event.getTo().getBlockY()
            && event.getFrom().getBlockZ() == event.getTo().getBlockZ())) {
      return;
    }
    teleportService.cancelPendingTeleportOnMove(event.getPlayer(), event.getTo());
  }

  @EventHandler(ignoreCancelled = true)
  public void onPlayerDamage(EntityDamageEvent event) {
    if (lifecycle == null) return;
    if (event.getEntity() instanceof Player player) {
      teleportService.cancelPendingTeleportOnDamage(player);
    }
  }

  /** 玩家退出 */
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    if (lifecycle == null) return;
    playerNames.forget(event.getPlayer());
    // Snapshot before cleanup, then persist the detached values off-thread.
    dataManager.savePlayerDataAsync(event.getPlayer().getUniqueId());

    // 清理内存
    homeService.cleanup(event.getPlayer().getUniqueId());
    socialService.cleanup(event.getPlayer().getUniqueId());
    teleportService.cleanup(event.getPlayer().getUniqueId());
  }

  // Getter 方法
  public TeleportService getTeleportService() {
    return teleportService;
  }

  public HomeService getHomeService() {
    return homeService;
  }

  public WarpService getWarpService() {
    return warpService;
  }

  public SocialService getSocialService() {
    return socialService;
  }

  public NicknameService getNicknameService() {
    return nicknameService;
  }

  public BalTopService getBalTopService() {
    return balTopService;
  }

  public EssentialsDataManager getDataManager() {
    return dataManager;
  }
}
