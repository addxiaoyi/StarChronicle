package dev.starcore.starcore.essentials;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.data.EssentialsDataManager;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.message.MessageService;
import java.util.*;
import java.util.logging.Logger;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.MockedConstruction;

class EssentialsSocialSessionTest {
  private final Plugin plugin = mock(Plugin.class, RETURNS_DEEP_STUBS);
  private final StarCoreContext context = mock(StarCoreContext.class, RETURNS_DEEP_STUBS);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private EssentialsModule module;
  private MockedConstruction<EssentialsDataManager> managers;
  private final UUID actorId = UUID.randomUUID(), otherId = UUID.randomUUID();
  private final Player actor = mock(Player.class), other = mock(Player.class);

  @BeforeEach
  void setup() {
    when(plugin.getName()).thenReturn("StarCore");
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(context.configuration().getConfig()).thenReturn(new YamlConfiguration());
    when(actor.getUniqueId()).thenReturn(actorId);
    when(other.getUniqueId()).thenReturn(otherId);
    when(actor.getName()).thenReturn("Actor");
    when(other.getName()).thenReturn("Other");
    managers = mockConstruction(EssentialsDataManager.class);
    module =
        new EssentialsModule(
            plugin, scheduler, mock(MessageService.class), mock(EconomyService.class));
    module.enable(context);
    module.getSocialService().sendMessage(actor, other, "previous");
    module.getSocialService().ignorePlayer(actorId, otherId);
  }

  @AfterEach
  void close() {
    module.disable(context);
    managers.close();
  }

  private PlayerQuitEvent quit() {
    PlayerQuitEvent event = mock(PlayerQuitEvent.class);
    when(event.getPlayer()).thenReturn(actor);
    return event;
  }

  @Test
  void quitKeepsPersistentIgnoreWhileClearingSessionHistory() {
    when(plugin.getServer().getPlayer(actorId)).thenReturn(actor);
    module.onPlayerQuit(quit());
    assertTrue(module.getSocialService().isIgnored(actorId, otherId));
    assertTrue(module.getSocialService().getMessageHistory(actorId).isEmpty());
    assertTrue(module.getSocialService().getLastMessaged(actorId).isEmpty());
    assertTrue(module.getSocialService().getKnownPlayerIds().contains(actorId));
    verify(managers.constructed().getFirst()).savePlayerDataAsync(actorId);
  }

  @Test
  void oldQuitCannotSaveOrCleanReplacementSession() {
    when(plugin.getServer().getPlayer(actorId)).thenReturn(mock(Player.class));
    module.onPlayerQuit(quit());
    assertEquals(1, module.getSocialService().getMessageHistory(actorId).size());
    assertTrue(module.getSocialService().isIgnored(actorId, otherId));
    verify(managers.constructed().getFirst(), never()).savePlayerDataAsync(any());
  }

  @Test
  void alreadyRemovedPlayerStillGetsItsSessionCleaned() {
    when(plugin.getServer().getPlayer(actorId)).thenReturn(null);
    module.onPlayerQuit(quit());
    assertTrue(module.getSocialService().getMessageHistory(actorId).isEmpty());
    assertTrue(module.getSocialService().isIgnored(actorId, otherId));
    verify(managers.constructed().getFirst()).savePlayerDataAsync(actorId);
  }
}
