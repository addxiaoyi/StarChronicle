from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
phases=['baseline','compile','test-initial','compile-final','test-final','compile-final-compat','test-final-compat','package','sbom']
runs={p:json.loads((root/'run'/('social-owner-'+p+'-20261126/result.json')).read_text()) for p in phases}
assert runs['baseline']['totals']==dict(tests=24,failures=24,errors=0,skipped=0)
assert runs['test-final-compat']['totals']==dict(tests=517,failures=0,errors=0,skipped=0)
artifacts=json.loads((root/'run/social-owner-artifacts-20261126/result.json').read_text())
summary={'status':'VERIFIED','baseline':{'chronicle':'3fbe309e0ee9a3d46e82cc4900f6f69213522e92','starcore':'958f419d95db6bdf62b366590a87bd8b1ffa314c'},
 'tests':runs['test-final-compat']['totals'],'new_tests':33,'runs':runs,'artifacts':{'starcore':artifacts['starcore_sha256'],'chronicle':'10135139ddc6332ece286d16a5567da5e78fd527493789bc63cb1488ac851b77'},
 'api':artifacts['public_api'],'class_hashes':artifacts['class_hashes'],'sbom_components':artifacts['sbom_components'],
 'limits':['No Minecraft, live Paper/Folia, third-party combination or full hot-reload acceptance.',
 '517 related tests, not the whole StarCore suite; existing POM exclusions remain. One 256 MiB JVM, forkCount=0, jacoco.skip=true.',
 'Message history is local admission rather than a client acknowledgement or durable delivery receipt. Transport failure can retain an attempted row and never auto-retries.',
 'Legacy synchronous SocialCommand and SocialService APIs require the caller to own all accessed players. Runtime uses the scheduler-aware constructor.',
 'Ignore preferences retain the existing asynchronous persistence contract; other services and social/GUI modules are outside this change.',
 'After compiling all 2267 main and 1093 test sources, final session/compatibility edits were compiled by Maven stale-source compilation. Final source bytes and selected class bytes were checked.',
 'Chronicle is unchanged here; its 1050 local tests and successful Linux CI belong to 3fbe309. The new upstream technology-history commits remain to be reconciled.']}
files={}
for phase in phases:
 for p in sorted((root/'run'/('social-owner-'+phase+'-20261126')).rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.class'):files[phase+'/'+p.relative_to(root/'run'/('social-owner-'+phase+'-20261126')).as_posix()]=p.read_bytes()
for p in sorted((root/'run/social-owner-artifacts-20261126').rglob('*')):
 if p.is_file():files['artifacts/'+p.name]=p.read_bytes()
for name in ['run/run-social-owner.py','run/verify-social-owner-artifacts.py','run/finalize-social-owner.py','run/github-combination-merge-ci-success-20261126.log','run/github-combination-merge-ci-20261126.json','run/github-combination-merge-delivery-git-20261126.json']:
 files['tools/'+Path(name).name]=(root/name).read_bytes()
for name in ['pom.xml','docs/SOCIAL-COMMAND-OWNERSHIP.md','target/starcore-1.0.0-sbom.json']:
 files['native/'+name]=(native/name).read_bytes()
files['native/change.patch']=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=native)
files['manifest.json']=(json.dumps({'summary':summary,'files':{n:sha(b) for n,b in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
out=root/'docs/verification/social-owner-source-20261126-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(m['files'])|{'manifest.json'}
 for name,digest in m['files'].items():assert sha(z.read(name))==digest,name
summary['evidence_files']=len(files);summary['evidence_sha256']=sha(out.read_bytes())
(root/'docs/verification/social-owner-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# Essentials 私聊所有权与屏蔽会话：2026-11-26

私聊原先直接读取、通知另一玩家，历史队列在并发访问时没有保护，退出还会移除已加载的屏蔽偏好。本次将私聊／回复和屏蔽命令迁移到各自原玩家 owner，保留原会话和启用生命周期，补齐状态并发及退出清理。没有启动 Minecraft。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{summary['artifacts']['starcore']}` |
| Chronicle，本轮未改 | `{summary['artifacts']['chronicle']}` |
| 证据 ZIP | `{summary['evidence_sha256']}` |

[证据包](verification/social-owner-source-20261126-evidence.zip) **{len(files)} 文件**，[机器摘要](verification/social-owner-source-20261126-summary.json)。含失败／成功 XML、冻结源码、编译／打包／SBOM／API／类字节核验和 Chronicle `3fbe309` 的 Linux CI #189 成功日志。

## 行为与边界

- 私聊在发送者 owner 捕获名字，目标 owner 复核原会话、在线状态和最新屏蔽，再记录准入并投递；回显返回原发送者 owner。屏蔽／取消屏蔽先在目标 owner 采样名字，再回发起者核验后修改。补全使用已有名字目录，按前缀过滤，回复不再把玩家名当消息建议。
- 退休、注册拒绝、旧会话、模块停用和重复回调不会再投递到替换会话或执行两次。投递异常明确为未确认且不自动重试；回显失败不重发给收件人。已经准入的操作可能结束，不保证两名玩家在同一原子时刻都在线。
- 屏蔽检查、双方回复指针和最多十条历史在短锁内更新，快照不可变，Bukkit 调用在锁外。加载先构造完整独立集合，空列表替换旧偏好，坏输入保留旧状态。退出只清临时消息状态、保留屏蔽偏好；迟到的旧退出事件不会保存或清理新会话。
- 历史代表本地准入，不是客户端确认或持久投递凭据；传输异常可能保留尝试记录。屏蔽沿用异步文件保存，不承诺进程故障后的同步持久性；未修改其他服务的退出／加载策略。
- 原同步构造器和 `SocialService.sendMessage(Player,Player,String)` 保留，调用方必须已拥有两名玩家，不能用作跨区域 Folia 入口。生产模块使用新构造器；公开 API 签名保持，新增准入记录与会话结束接口。

## 验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 冻结旧实现的 owner 回归 | 24 | 24 | 0 | 0 |
| 初轮新增所有权／状态测试 | 29 | 0 | 0 | 0 |
| 补齐退出接线后的相关回归 | 516 | 0 | 0 | 0 |
| 保留旧构造器离线拒绝的最终回归 | **517** | **0** | **0** | **0** |

新增 **33 项**：25 命令所有权／会话、5 并发状态、3 实际模块退出接线。完整 2,267 主源和 1,093 测试源编译后，最终增量由 Maven 编译；最终共 1,094 测试源。Spotless、独立 verify 打包、36 组件 SBOM、6 个相关类字节与 3 类旧公开声明／描述符核验通过。517 项为 474 调度器／Essentials 加 43 自带经济／Vault／交易账本，并非全库回归；保留既有 POM 排除。每次一个 256 MiB JVM，forkCount=0、jacoco.skip=true，无本机覆盖率。

Chronicle 保持 1,050 项检查点，[Linux CI #189](https://github.com/addxiaoyi/StarChronicle/actions/runs/45759945895) 全部成功；交付包与 1,306 个 Git 项目文件核对通过。旧组合实服记录不转用于本次 StarCore。其他社交模块、GUI／昵称、完整生命周期、外部经济未知结果与当前构件实服仍待推进。
'''
(root/'docs/SOCIAL-OWNER-SOURCE-20261126.md').write_text(report,encoding='utf-8')
note=f'2026-11-26 StarCore 当前检查点：[私聊所有权与屏蔽会话](SOCIAL-OWNER-SOURCE-20261126.md)。私聊和回显回各自原 owner，屏蔽修改复核原会话；并发历史有界、加载原子替换，退出保留屏蔽偏好，旧退出不清理新会话。新增 33 项，**517 项相关回归全部通过**；StarCore `{artifacts["starcore_sha256"][:8]}…{artifacts["starcore_sha256"][-6:]}` 打包／36 组件 SBOM／API 与类字节核验通过。Chronicle 1,050 项与 Linux CI #189 通过。其他社交、GUI 和全栈实服继续待办，不启动 Minecraft。'
for name in ['README.md','docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md']:
 p=root/name;t=p.read_text(encoding='utf-8');pos=t.index('\n\n')+2
 inserted=note.replace('(SOCIAL-OWNER-SOURCE-20261126.md)','(docs/SOCIAL-OWNER-SOURCE-20261126.md)') if name=='README.md' else note
 p.write_text(t[:pos]+inserted+'\n\n'+t[pos:],encoding='utf-8')
p=root/'docs/HANDOFF-2026-11-26.md';t=p.read_text(encoding='utf-8')
t=t.replace('调度、周期、传送、命令、经济所有权已分批修复 | 社交／GUI 等调用链','调度、周期、传送、命令、经济及 Essentials 私聊／屏蔽所有权已分批修复 | 其他社交、GUI／昵称等调用链',1)
t=t.replace('下表更新到当前源码；后文保留上游冻结构件的验收记录。','下表更新到当前源码；最新 StarCore 517 项及社交修复见 [私聊报告](SOCIAL-OWNER-SOURCE-20261126.md)。后文保留上游冻结构件的验收记录。',1)
p.write_text(t,encoding='utf-8')
print(json.dumps({'artifacts':summary['artifacts'],'evidence_files':len(files),'evidence_sha256':summary['evidence_sha256']}))
