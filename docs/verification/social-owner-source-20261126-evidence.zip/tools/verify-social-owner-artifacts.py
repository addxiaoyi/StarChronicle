from pathlib import Path
import hashlib,json,re,subprocess,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/'run/social-owner-artifacts-20261126';out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
old=root/'run/social-owner-baseline-20261126/starcore.jar';jar=native/'target/starcore-1.0.0.jar'
classes=native/'target/classes'
types=['dev/starcore/starcore/essentials/EssentialsModule','dev/starcore/starcore/essentials/command/SocialCommand','dev/starcore/starcore/essentials/social/SocialService']
checked={};sources={};apis={}
with zipfile.ZipFile(jar) as archive:
 for name in types:
  directory,stem=name.rsplit('/',1)
  for path in sorted((classes/directory).glob(stem+'*.class')):
   raw=path.read_bytes();relative=path.relative_to(classes).as_posix()
   assert archive.read(relative)==raw and int.from_bytes(raw[6:8],'big')==65,relative
   checked[relative]=sha(raw)
assert len(checked)>=6
for name in ['src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java','src/main/java/dev/starcore/starcore/essentials/command/SocialCommand.java','src/main/java/dev/starcore/starcore/essentials/social/SocialService.java','src/test/java/dev/starcore/starcore/essentials/EssentialsSocialSessionTest.java','src/test/java/dev/starcore/starcore/essentials/command/SocialOwnershipTest.java','src/test/java/dev/starcore/starcore/essentials/social/SocialStateConcurrencyTest.java']:
 path=native/name;raw=path.read_bytes()
 assert raw==(root/'run/social-owner-compile-final-compat-20261126'/path.name).read_bytes(),name
 sources[name]=sha(raw)
javap=r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin\javap.exe'
for name in types:
 outputs=[]
 for label,artifact in [('old',old),('current',jar)]:
  result=subprocess.run([javap,'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),name.replace('/','.')],capture_output=True,check=True)
  (out/(label+'-'+name.rsplit('/',1)[1]+'.txt')).write_bytes(result.stdout)
  declaration=result.stdout.decode().replace('synchronized ','')
  outputs.append(set(re.findall(r'  (public [^\n]+;)\r?\n    descriptor: ([^\r\n]+)',declaration)))
 assert outputs[0] and outputs[0]<=outputs[1],name
 apis[name]={'preserved_methods':len(outputs[0]),'added_methods':[list(v) for v in sorted(outputs[1]-outputs[0])]}
summary={'status':'VERIFIED','starcore_sha256':sha(jar.read_bytes()),'baseline_sha256':sha(old.read_bytes()),'class_hashes':checked,
 'compiled_source_hashes':sources,'public_api':apis,'sbom_components':len(json.loads((native/'target/starcore-1.0.0-sbom.json').read_text())['components']),
 'limits':['Bytecode and API checks are not live Paper/Folia acceptance.','Existing public descriptors are preserved; scheduler-aware command constructor, recordMessage and endSession are additive. Legacy synchronous APIs require caller ownership.']}
assert summary['sbom_components']==36
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
