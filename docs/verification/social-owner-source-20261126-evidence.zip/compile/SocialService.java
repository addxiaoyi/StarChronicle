package dev.starcore.starcore.essentials.social;

import java.time.Instant;
import java.util.*;
import org.bukkit.entity.Player;

/** 社交系统服务 管理私聊、屏蔽、好友等社交功能 */
public final class SocialService {
  // 最近私聊对象 UUID -> UUID
  private final Map<UUID, UUID> lastMessaged = new HashMap<>();

  // 屏蔽列表 UUID -> Set<UUID>
  private final Map<UUID, Set<UUID>> ignoredPlayers = new HashMap<>();

  // 消息历史（最近10条）UUID -> List<Message>
  private final Map<UUID, ArrayDeque<Message>> messageHistory = new HashMap<>();

  private static final int MAX_HISTORY = 10;

  /**
   * Legacy synchronous delivery; the caller must own both players (normally Paper's main thread).
   */
  public boolean sendMessage(Player sender, Player recipient, String message) {
    if (!recordMessage(sender.getUniqueId(), recipient.getUniqueId(), message)) return false;

    // 发送消息
    sender.sendMessage("§7[§e我§7 -> §e" + recipient.getName() + "§7] §f" + message);
    recipient.sendMessage("§7[§e" + sender.getName() + "§7 -> §e我§7] §f" + message);

    return true;
  }

  /**
   * Atomically checks ignore state and records a locally admitted message. The runtime caller must
   * first verify both original sessions on the recipient owner. This is not a network delivery
   * receipt: a later transport failure remains an attempted message and must not be auto-retried.
   * No Bukkit call occurs while holding the state lock.
   */
  public synchronized boolean recordMessage(UUID senderId, UUID recipientId, String message) {
    Objects.requireNonNull(senderId);
    Objects.requireNonNull(recipientId);
    Objects.requireNonNull(message);
    if (isIgnored(recipientId, senderId)) return false;
    lastMessaged.put(senderId, recipientId);
    lastMessaged.put(recipientId, senderId);
    Message entry = new Message(senderId, recipientId, message, Instant.now());
    addToHistory(senderId, entry);
    addToHistory(recipientId, entry);
    return true;
  }

  /** 回复最近的私聊 */
  public synchronized Optional<UUID> getLastMessaged(UUID playerId) {
    return Optional.ofNullable(lastMessaged.get(playerId));
  }

  /** 屏蔽玩家 */
  public synchronized boolean ignorePlayer(UUID playerId, UUID targetId) {
    if (playerId.equals(targetId)) {
      return false;
    }

    Set<UUID> ignored = ignoredPlayers.computeIfAbsent(playerId, k -> new HashSet<>());

    return ignored.add(targetId);
  }

  /** 取消屏蔽 */
  public synchronized boolean unignorePlayer(UUID playerId, UUID targetId) {
    Set<UUID> ignored = ignoredPlayers.get(playerId);

    if (ignored == null) {
      return false;
    }

    return ignored.remove(targetId);
  }

  /** 检查是否被屏蔽 */
  public synchronized boolean isIgnored(UUID playerId, UUID potentialIgnorer) {
    Set<UUID> ignored = ignoredPlayers.get(playerId);

    if (ignored == null) {
      return false;
    }

    return ignored.contains(potentialIgnorer);
  }

  /** 获取屏蔽列表 */
  public synchronized Set<UUID> getIgnoredPlayers(UUID playerId) {
    Set<UUID> ignored = ignoredPlayers.get(playerId);

    if (ignored == null) {
      return Set.of();
    }

    return Set.copyOf(ignored);
  }

  /** 获取消息历史 */
  public synchronized List<Message> getMessageHistory(UUID playerId) {
    ArrayDeque<Message> history = messageHistory.get(playerId);

    if (history == null) {
      return List.of();
    }

    return List.copyOf(history);
  }

  /** 添加到历史记录 */
  private void addToHistory(UUID playerId, Message message) {
    ArrayDeque<Message> history = messageHistory.computeIfAbsent(playerId, k -> new ArrayDeque<>());

    history.addFirst(message);

    // 限制历史记录数量
    while (history.size() > MAX_HISTORY) {
      history.removeLast();
    }
  }

  /** 清理玩家数据 */
  public synchronized void cleanup(UUID playerId) {
    lastMessaged.remove(playerId);
    ignoredPlayers.remove(playerId);
    messageHistory.remove(playerId);
  }

  /** 加载玩家数据 */
  public void loadPlayerData(UUID playerId, Set<UUID> ignored) {
    Set<UUID> detached = ignored == null ? Set.of() : Set.copyOf(ignored);
    synchronized (this) {
      ignoredPlayers.put(playerId, new HashSet<>(detached));
    }
  }

  /** 保存玩家数据 */
  public Set<UUID> getPlayerData(UUID playerId) {
    return getIgnoredPlayers(playerId);
  }

  /** Returns every player whose persisted ignore state is currently loaded. */
  public synchronized Set<UUID> getKnownPlayerIds() {
    return Set.copyOf(ignoredPlayers.keySet());
  }

  /** 消息记录 */
  public record Message(UUID senderId, UUID recipientId, String content, Instant timestamp) {
    public String format() {
      return String.format("[%s] %s -> %s: %s", timestamp, senderId, recipientId, content);
    }
  }
}
