package dev.starcore.starcore.core.scheduler;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.module.narrative.engine.TypewriterController;
import io.papermc.paper.threadedregions.scheduler.EntityScheduler;
import io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.MockedStatic;

/** Captured callbacks model shutdown/retirement before publication without a live server. */
class RepeatingTaskLifecycleTest {
  private final JavaPlugin plugin = mock(JavaPlugin.class);
  private final Player entity = mock(Player.class);
  private final EntityScheduler owner = mock(EntityScheduler.class);
  private final GlobalRegionScheduler global = mock(GlobalRegionScheduler.class);
  private final List<Consumer<ScheduledTask>> entityTicks = new ArrayList<>(),
      globalTicks = new ArrayList<>();
  private final List<Runnable> retirements = new ArrayList<>();
  private final List<ScheduledTask> entityTasks = new ArrayList<>(),
      globalTasks = new ArrayList<>();
  private StarCoreScheduler scheduler;
  private MockedStatic<Bukkit> bukkit;

  @BeforeEach
  void setup() {
    when(plugin.getLogger()).thenReturn(Logger.getLogger("RepeatingTaskLifecycleTest"));
    when(entity.getScheduler()).thenReturn(owner);
    when(entity.getUniqueId()).thenReturn(UUID.randomUUID());
    scheduler = new StarCoreScheduler(plugin, 1, 1);
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(Bukkit::getGlobalRegionScheduler).thenReturn(global);
    bukkit.when(() -> Bukkit.isOwnedByCurrentRegion(entity)).thenReturn(true);
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              entityTicks.add(i.getArgument(1));
              retirements.add(i.getArgument(2));
              ScheduledTask task = mock(ScheduledTask.class);
              entityTasks.add(task);
              return task;
            });
    when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              globalTicks.add(i.getArgument(1));
              ScheduledTask task = mock(ScheduledTask.class);
              globalTasks.add(task);
              return task;
            });
  }

  @AfterEach
  void cleanup() {
    try {
      scheduler.shutdownNow();
    } finally {
      bukkit.close();
    }
  }

  private ScheduledTask repeat(AtomicInteger calls, AtomicInteger retired) {
    return scheduler.runAtEntityFixedRate(
        entity, t -> calls.incrementAndGet(), retired::incrementAndGet, 1, 1);
  }

  private int trackedGlobals() throws Exception {
    Field field = StarCoreScheduler.class.getDeclaredField("globalRepeatingTasks");
    field.setAccessible(true);
    return ((Set<?>) field.get(scheduler)).size();
  }

  private int trackedEntities() throws Exception {
    Field field = StarCoreScheduler.class.getDeclaredField("entityRepeatingTasks");
    field.setAccessible(true);
    return ((Set<?>) field.get(scheduler)).size();
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shutdownRetiresAndCancelsEntityTimersWithoutWaitingForAnotherTick(boolean immediate) {
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    repeat(calls, retired);
    if (immediate) scheduler.shutdownNow();
    else scheduler.shutdown();
    assertEquals(1, retired.get());
    verify(entityTasks.getFirst()).cancel();
    entityTicks.getFirst().accept(entityTasks.getFirst());
    retirements.getFirst().run();
    assertEquals(0, calls.get());
    assertEquals(1, retired.get());
  }

  @Test
  void shutdownBeforeHandlePublicationCancelsTheLateBackendTask() {
    ScheduledTask raw = mock(ScheduledTask.class);
    AtomicInteger retired = new AtomicInteger();
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              scheduler.shutdownNow();
              return raw;
            });
    scheduler.runAtEntityFixedRate(entity, t -> fail("late tick"), retired::incrementAndGet, 1, 1);
    verify(raw).cancel();
    assertEquals(1, retired.get());
  }

  @Test
  void retiredEntityCannotRunACapturedLateCallback() {
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    repeat(calls, retired);
    retirements.getFirst().run();
    entityTicks.getFirst().accept(entityTasks.getFirst());
    assertEquals(0, calls.get());
    assertEquals(1, retired.get());
  }

  @Test
  void explicitCancellationPreventsCapturedCallbacksAndDoesNotInvokeRetirement() {
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    var handle = repeat(calls, retired);
    handle.cancel();
    entityTicks.getFirst().accept(entityTasks.getFirst());
    scheduler.shutdownNow();
    assertEquals(0, calls.get());
    assertEquals(0, retired.get());
    verify(entityTasks.getFirst()).cancel();
  }

  @Test
  void registrationFailureRetiresCallerStateAndKeepsTheOriginalException() {
    RuntimeException failure = new IllegalStateException("registration rejected");
    AtomicInteger retired = new AtomicInteger();
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong())).thenThrow(failure);
    assertSame(
        failure,
        assertThrows(
            RuntimeException.class,
            () -> scheduler.runAtEntityFixedRate(entity, t -> {}, retired::incrementAndGet, 1, 1)));
    assertEquals(1, retired.get());
  }

  @Test
  void callbackFailureRetiresStateAndStopsFutureCallbacks() {
    RuntimeException failure = new IllegalStateException("body failed");
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    scheduler.runAtEntityFixedRate(
        entity,
        t -> {
          calls.incrementAndGet();
          throw failure;
        },
        retired::incrementAndGet,
        1,
        1);
    assertSame(
        failure,
        assertThrows(
            RuntimeException.class, () -> entityTicks.getFirst().accept(entityTasks.getFirst())));
    entityTicks.getFirst().accept(entityTasks.getFirst());
    assertEquals(1, calls.get());
    assertEquals(1, retired.get());
  }

  @Test
  void wrongOwnerCallbackCannotTouchEntityState() {
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    repeat(calls, retired);
    bukkit.when(() -> Bukkit.isOwnedByCurrentRegion(entity)).thenReturn(false);
    assertThrows(
        IllegalStateException.class, () -> entityTicks.getFirst().accept(entityTasks.getFirst()));
    assertEquals(0, calls.get());
    assertEquals(1, retired.get());
  }

  @Test
  void zeroEntityDelayNormalizesToTheNextTick() {
    scheduler.runAtEntityFixedRate(entity, t -> {}, () -> {}, 0, 1);
    verify(owner).runAtFixedRate(eq(plugin), any(), any(), eq(1L), eq(1L));
  }

  @Test
  void zeroGlobalDelayNormalizesToTheNextTick() {
    scheduler.runGlobalRepeatingTask(() -> {}, 0, 1);
    verify(global).runAtFixedRate(eq(plugin), any(), eq(1L), eq(1L));
  }

  @Test
  void failedGlobalRegistrationDoesNotLeaveTrackedTask() throws Exception {
    when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
        .thenThrow(new IllegalStateException("unavailable"));
    assertThrows(
        IllegalStateException.class, () -> scheduler.runGlobalRepeatingTask(() -> {}, 1, 1));
    assertEquals(0, trackedGlobals());
  }

  @Test
  void failedGlobalCallbackDoesNotRemainActiveOrRunAgain() throws Exception {
    AtomicInteger calls = new AtomicInteger();
    RuntimeException failure = new IllegalStateException("body failed");
    scheduler.runGlobalRepeatingTask(
        () -> {
          calls.incrementAndGet();
          throw failure;
        },
        1,
        1);
    assertSame(
        failure,
        assertThrows(
            RuntimeException.class, () -> globalTicks.getFirst().accept(globalTasks.getFirst())));
    globalTicks.getFirst().accept(globalTasks.getFirst());
    assertEquals(1, calls.get());
    assertEquals(0, trackedGlobals());
  }

  @Test
  void throwingBackendCancellationCannotPreventOtherTimersAndExecutorShutdown() {
    scheduler.runGlobalRepeatingTask(() -> {}, 1, 1);
    scheduler.runGlobalRepeatingTask(() -> {}, 1, 1);
    when(globalTasks.getFirst().cancel()).thenThrow(new IllegalStateException("cancel failed"));
    assertDoesNotThrow(scheduler::shutdownNow);
    verify(globalTasks.getLast()).cancel();
    assertTrue(scheduler.getAsyncExecutor().isShutdown());
    assertTrue(scheduler.getIoExecutor().isShutdown());
  }

  @Test
  void typewriterStateRetiresImmediatelyOnSchedulerShutdown() {
    TypewriterController controller = new TypewriterController(Logger.getLogger("test"), scheduler);
    controller.start(entity, "hello", 50, state -> fail("shutdown cannot complete dialogue"));
    scheduler.shutdownNow();
    assertFalse(controller.isTypewriterActive(entity.getUniqueId()));
  }

  @Test
  void typewriterRegistrationFailureDoesNotLeaveAnActiveRun() {
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenThrow(new IllegalStateException("unavailable"));
    TypewriterController controller = new TypewriterController(Logger.getLogger("test"), scheduler);
    assertThrows(IllegalStateException.class, () -> controller.start(entity, "hello", 50, null));
    assertFalse(controller.isTypewriterActive(entity.getUniqueId()));
  }

  @Test
  void nullEntityRegistrationRetiresAndDoesNotLeakTracking() throws Exception {
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong())).thenReturn(null);
    AtomicInteger retired = new AtomicInteger();
    assertNull(repeat(new AtomicInteger(), retired));
    assertEquals(1, retired.get());
    assertEquals(0, trackedEntities());
  }

  @Test
  void entityRetiredBeforePublicationCancelsTheLateTaskOnlyOnce() throws Exception {
    ScheduledTask raw = mock(ScheduledTask.class);
    AtomicInteger retired = new AtomicInteger();
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              i.getArgument(2, Runnable.class).run();
              return raw;
            });
    var handle = repeat(new AtomicInteger(), retired);
    handle.cancel();
    scheduler.shutdownNow();
    assertEquals(1, retired.get());
    verify(raw).cancel();
    assertTrue(handle.isCancelled());
    assertEquals(0, trackedEntities());
  }

  @Test
  void selfCancellationInsideCallbackBeforeRegistrationReturnsHasNoTrackingLeak() throws Exception {
    ScheduledTask raw = mock(ScheduledTask.class);
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              i.<Consumer<ScheduledTask>>getArgument(1).accept(raw);
              return raw;
            });
    var handle =
        scheduler.runAtEntityFixedRate(
            entity, ScheduledTask::cancel, () -> fail("explicit cancel is not retirement"), 1, 1);
    assertTrue(handle.isCancelled());
    verify(raw).cancel();
    assertEquals(0, trackedEntities());
  }

  @Test
  void externalThreadShutdownBeforePublicationCancelsLateTaskWithoutDeadlock() throws Exception {
    ScheduledTask raw = mock(ScheduledTask.class);
    AtomicInteger retired = new AtomicInteger();
    when(owner.runAtFixedRate(eq(plugin), any(), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              CompletableFuture.runAsync(scheduler::shutdownNow).get(3, TimeUnit.SECONDS);
              return raw;
            });
    var handle = repeat(new AtomicInteger(), retired);
    assertTrue(handle.isCancelled());
    verify(raw).cancel();
    assertEquals(1, retired.get());
    assertEquals(0, trackedEntities());
  }

  @Test
  void cleanupExceptionCannotReplaceTheCallbackFailure() {
    RuntimeException body = new IllegalStateException("body"),
        cleanup = new IllegalStateException("retirement");
    scheduler.runAtEntityFixedRate(
        entity,
        t -> {
          throw body;
        },
        () -> {
          throw cleanup;
        },
        1,
        1);
    assertSame(
        body,
        assertThrows(
            RuntimeException.class, () -> entityTicks.getFirst().accept(entityTasks.getFirst())));
    assertArrayEquals(new Throwable[] {cleanup}, body.getSuppressed());
  }

  @Test
  void retirementExceptionCannotBlockOtherTaskCleanupOrExecutors() throws Exception {
    scheduler.runAtEntityFixedRate(
        entity,
        t -> {},
        () -> {
          throw new IllegalStateException("retirement");
        },
        1,
        1);
    AtomicInteger retired = new AtomicInteger();
    repeat(new AtomicInteger(), retired);
    assertDoesNotThrow(scheduler::shutdownNow);
    assertEquals(1, retired.get());
    for (var raw : entityTasks) verify(raw).cancel();
    assertEquals(0, trackedEntities());
    assertTrue(scheduler.getAsyncExecutor().isShutdown());
    assertTrue(scheduler.getIoExecutor().isShutdown());
  }

  @Test
  void backendCancellationFailureStillRetiresAndRejectsLateEntityCallbacks() throws Exception {
    AtomicInteger calls = new AtomicInteger(), retired = new AtomicInteger();
    repeat(calls, retired);
    when(entityTasks.getFirst().cancel())
        .thenThrow(new IllegalStateException("backend unavailable"));
    assertDoesNotThrow(scheduler::shutdownNow);
    assertEquals(1, retired.get());
    entityTicks.getFirst().accept(entityTasks.getFirst());
    assertEquals(0, calls.get());
    assertEquals(0, trackedEntities());
  }

  @Test
  void cancellationStateTracksTheBackendAndPreventsRepeatedCancellation() {
    var handle = repeat(new AtomicInteger(), new AtomicInteger());
    var raw = entityTasks.getFirst();
    when(raw.getExecutionState()).thenReturn(ScheduledTask.ExecutionState.RUNNING);
    when(raw.cancel()).thenReturn(ScheduledTask.CancelledState.NEXT_RUNS_CANCELLED);
    assertEquals(ScheduledTask.CancelledState.NEXT_RUNS_CANCELLED, handle.cancel());
    assertEquals(ScheduledTask.ExecutionState.CANCELLED_RUNNING, handle.getExecutionState());
    assertEquals(ScheduledTask.CancelledState.CANCELLED_ALREADY, handle.cancel());
    verify(raw).cancel();
  }

  @Test
  void globalShutdownBeforePublicationCancelsLateTaskAndRemovesTracking() throws Exception {
    ScheduledTask raw = mock(ScheduledTask.class);
    when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong()))
        .thenAnswer(
            i -> {
              scheduler.shutdownNow();
              return raw;
            });
    var handle = scheduler.runGlobalRepeatingTask(() -> fail("stopped"), 1, 1);
    verify(raw).cancel();
    assertFalse(handle.cancel());
    assertEquals(0, trackedGlobals());
  }

  @Test
  void nullGlobalRegistrationLeavesNoTrackedTimer() throws Exception {
    when(global.runAtFixedRate(eq(plugin), any(), anyLong(), anyLong())).thenReturn(null);
    assertNull(scheduler.runGlobalRepeatingTask(() -> {}, 1, 1));
    assertEquals(0, trackedGlobals());
  }

  @Test
  void shutdownRejectsNewTimersBeforeCallingThePlatform() {
    scheduler.shutdownNow();
    AtomicInteger retired = new AtomicInteger();
    assertNull(repeat(new AtomicInteger(), retired));
    assertNull(scheduler.runGlobalRepeatingTask(() -> {}, 1, 1));
    verifyNoInteractions(owner, global);
    assertEquals(1, retired.get());
  }

  @Test
  void invalidIntervalsAreRejectedBeforePlatformRegistration() {
    for (long[] timing : List.of(new long[] {-1, 1}, new long[] {1, 0}, new long[] {1, -1})) {
      assertThrows(
          IllegalArgumentException.class,
          () -> scheduler.runAtEntityFixedRate(entity, t -> {}, () -> {}, timing[0], timing[1]));
      assertThrows(
          IllegalArgumentException.class,
          () -> scheduler.runGlobalRepeatingTask(() -> {}, timing[0], timing[1]));
    }
    verifyNoInteractions(owner, global);
  }
}
