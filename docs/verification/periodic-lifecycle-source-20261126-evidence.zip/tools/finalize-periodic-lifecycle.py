from pathlib import Path
import hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile

root = Path(__file__).resolve().parents[1]
native = root.parent/'StarChronicle-audit/starcore-all-stages'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
def add(path, name): files[name] = path.read_bytes()

runs = {}
for phase in ('baseline','compile','test-scheduler','test-war','test-finance','package','sbom','artifacts'):
    directory = root/'run'/('periodic-lifecycle-'+phase+'-20261126')
    runs[phase] = json.loads((directory/'result.json').read_text(encoding='utf-8'))
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.xml','.java','.log','.txt'):
            add(path, phase+'/'+path.relative_to(directory).as_posix())
    if phase != 'baseline': assert runs[phase].get('exit_code',0) == 0, phase

totals = dict(tests=0,failures=0,errors=0,skipped=0)
suite_names = set()
skips = []
for phase in ('test-scheduler','test-war','test-finance'):
    actual = dict.fromkeys(totals,0)
    for path in sorted((root/'run'/('periodic-lifecycle-'+phase+'-20261126')/'surefire').glob('*.xml')):
        suite = ET.parse(path).getroot()
        assert suite.attrib['name'] not in suite_names, suite.attrib['name']
        suite_names.add(suite.attrib['name'])
        for key in actual: actual[key] += int(suite.get(key,0))
        for case in suite.findall('testcase'):
            skipped = case.find('skipped')
            if skipped is not None: skips.append({'suite':suite.get('name'),'test':case.get('name'),'reason':skipped.get('message')})
    assert actual == runs[phase]['totals']
    for key in totals: totals[key] += actual[key]
assert totals == dict(tests=1131,failures=0,errors=0,skipped=9)
assert runs['baseline']['totals'] == dict(tests=15,failures=13,errors=2,skipped=0)

changed = [
    'src/main/java/dev/starcore/starcore/core/scheduler/StarCoreScheduler.java',
    'src/test/java/dev/starcore/starcore/core/scheduler/EntityTaskContractTest.java',
    'src/test/java/dev/starcore/starcore/core/scheduler/RepeatingTaskLifecycleTest.java',
    'docs/PERIODIC-TASK-LIFECYCLE.md']
for name in changed + ['src/main/java/dev/starcore/starcore/module/narrative/engine/TypewriterController.java','pom.xml','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties']:
    add(native/name,'starcore/'+name)
for name in ('starcore-1.0.0-sbom.json','starcore-1.0.0-sbom.xml'):
    add(native/'target'/name,'sbom/'+name)
for name in ('run-periodic-lifecycle.py','verify-periodic-lifecycle-artifacts.py','finalize-periodic-lifecycle.py'):
    add(root/'run'/name,'tools/'+name)
files['starcore/change.patch'] = subprocess.check_output(['git','diff','--binary'],cwd=native)
plugin = sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
sources = sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes())
core = sha((native/'target/starcore-1.0.0.jar').read_bytes())
assert core == runs['artifacts']['starcore_sha256']
assert plugin == '1c7b8b010c9d330c15b0882753d54095fb906e42caedb926a81055d643cd78ce'
summary = {'date':'2026-11-26','scope':'Shared entity/global periodic lifecycle; source, mocked platform callbacks and low-memory unit regressions only.',
    'baseline_commits':{'starchronicle':'d9e24fa2b022030bcea5b9901175652c244ccb59','starcore':'b048071df580a6919e37971d340b4abd681f46d1'},
    'new_tests':27,'tests':totals,'tests_by_group':{k:runs[k]['totals'] for k in ('test-scheduler','test-war','test-finance')},
    'baseline_tests':runs['baseline']['totals'],'skips':skips,'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':sources,'starcore_sha256':core},
    'source_hashes':{name:sha((native/name).read_bytes()) for name in changed},
    'artifact_verification':runs['artifacts'],
    'limits':['No Minecraft, real third-party binaries or full Folia validation.',
              '1131 selected native tests include 9 existing skips; this is not the full native suite.',
              'Existing POM exclusions and the explicit ConscriptionTest exclusion are retained.',
              'Local JVM heap 256 MiB; tests use forkCount=0 and jacoco.skip=true, no local coverage result.',
              'A callback already admitted can finish; cancellation is not rollback or proof of non-application.',
              'Retirement may run on shutdown/registration threads and must only touch detached state.',
              'Legacy runSync/runNextTick/FoliaCompatScheduler and Essentials timers need separate review.',
              'Chronicle main artifacts and their prior 1021-test result are unchanged, not rerun locally.',
              'Prior treasury/trade/factory multi-JVM contracts retain their earlier artifact identities.']}
files['manifest.json'] = (json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output = root/'docs/verification/periodic-lifecycle-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in sorted(files.items()): archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name,digest in manifest['files'].items(): assert sha(archive.read(name)) == digest
summary['evidence_files'] = len(files)
summary['evidence_zip_sha256'] = sha(output.read_bytes())
(output.parent/'periodic-lifecycle-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

report = f'''# 共享周期任务生命周期：源码验证 2026-11-26

StarCore 的实体周期任务原先不受关闭跟踪，关服后必须等下一次 tick 才能清理打字机状态；注册／回调异常和已退休的旧回调也可能留下或再次使用该状态。本次统一跟踪实体与全局周期任务，补齐注册、取消、退休、关闭及异常清理。

## 当前构件与证据

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{core}` |
| Chronicle，主源码与构件未变 | `{plugin}` |
| Chronicle 源码 JAR | `{sources}` |
| 证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线：Chronicle `d9e24fa`、StarCore `b048071d`。继续原配套分支与草稿 PR #2／#3。[证据 ZIP](verification/periodic-lifecycle-source-20261126-evidence.zip) 共 **{len(files)} 个文件**，含原始失败、三组最终 XML、编译／打包／SBOM 日志、冻结源码与检查工具；[机器摘要](verification/periodic-lifecycle-source-20261126-summary.json)。未启动 Minecraft。

## 行为与调用边界

- 实体周期 API 仍使用确切实体的调度器，每次回调先核验所有权。返回并传入回调的是同一个跟踪 `ScheduledTask`，调用者不能依赖它与平台原句柄的对象身份相同；公开方法签名保持。
- 显式取消立即移除跟踪、抑制迟到回调，不调用 retired。关闭、实体退休、空／失败注册或回调异常至多退休一次，不再等待下一次 tick 才清理打字机独立状态。
- 平台注册前先发布跟踪项；关服或退休先于平台返回时，迟到的句柄仍取消。注册期间提前进入的回调与自取消也受相同规则约束。
- retired 可在关闭或注册线程执行，只能清理独立状态，不可访问实体／世界。当前唯一实体周期消费者 TypewriterController 只删除 concurrent map 中捕获的状态并更新 volatile 标记。
- 注册／回调异常释放跟踪；清理异常作为 suppressed 保留原异常。一个任务取消或退休失败会记录日志，不中断其他周期任务和线程池关闭。
- 零初始延迟规范为下一 tick，负延迟或非正周期在平台注册前拒绝。已通过准入检查的回调可完成；取消不回滚业务，也不声明业务从未发生。单次 `callForEntity` 的未应用结果契约保持独立。

已沿当前使用链核对剧情、任务、国库、赔款、战争服务／态势、委托与和约的全局周期入口。没有将旧同步调用批量改为全局调度。

## 实际验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现红例 | 15 | 13 | 2 | 0 |
| 调度／剧情／任务 | 391 | 0 | 0 | 7 |
| 战争／赔款 | 475 | 0 | 0 | 2 |
| 国库／GUI／科研支付 | 265 | 0 | 0 | 0 |
| 当前相关回归合计 | **1,131** | **0** | **0** | **9** |

新增 **27 项**周期任务专项全部通过，包含真实另一线程关服与注册未返回的交错、旧回调、提前退休、自取消、无效 owner、失败注册／回调／清理、零延迟以及真实 TypewriterController 状态清理。平台调度器为 Mockito 替身，不是原生 Folia 调度执行。

旧实现的 2 errors 来自失败的业务回调再次执行，均保留原始 XML 和源码；其余 13 项为断言失败。最终专项在红例后扩展为 27 项。没有增加测试排除。7 项既有剧情跳过需要真实 Bukkit Player；2 项 WarModuleAuthorityTest 跳过因引用已移除接口，不能把测试注释中声称的集成覆盖视为本轮实服证据。`ConscriptionTest` 的既有排除及 POM 排除均保持，1,131 项不等于全库回归。

本机每次仅使用一个 256 MiB 堆 JVM，`forkCount=0`、`jacoco.skip=true` 和 Mockito agent；没有本机覆盖率结果。先完成 Spotless 和 2,266 个主源／1,082 个测试源的编译，再用三个独立 JVM 执行以上选择器，最后复用稳定的已测试类打包：

```text
mvnw.cmd -o -B -ntp -Djacoco.skip=true spotless:apply -DskipTests test-compile
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=dev.starcore.starcore.core.scheduler.**,dev.starcore.starcore.module.narrative.**,dev.starcore.starcore.quest.** surefire:test
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=dev.starcore.starcore.war.**,dev.starcore.starcore.module.war.**,!ConscriptionTest surefire:test
mvnw.cmd -o -B -ntp -Djacoco.skip=true -DforkCount=0 -Dtest=Treasury*Test,SqlTreasuryStateStorageTest,NationTransferEconomyStateTest,ResearchPaymentProcessorTest surefire:test
mvnw.cmd -o -B -ntp -Djacoco.skip=true -Dmaven.main.skip=true -Dmaven.test.skip=true verify
mvnw.cmd -B -ntp -Djacoco.skip=true cyclonedx:makeAggregateBom@generate-sbom
```

离线打包跳过 SBOM，随后在线命令成功生成并校验 36 组件清单，依赖元数据警告原样保留。最终 JAR 内 5 个调度器类与已测试 target/classes 字节相同，Java 21 字节码检查通过，旧／新 JAR 的公开调度器与 GlobalRepeatingTask 签名一致。源码亦与编译时冻结副本一致。这些检查不替代运行兼容验收。

Chronicle 主源码、JAR 和原 1,021 项完整测试结果沿用 NPC 检查点，本轮未本地重跑。此前国库／贸易／工厂契约和容量报告保留原构件边界，没有重新标记为此 StarCore 构件的实测。Chronicle 推送后另行跟踪 Linux CI；StarCore 草稿 PR 的基线不是 main，现有工作流触发条件不覆盖该 PR。

## 未完成范围

第 7 阶段仍需逐个审计 `runSync*`、`runNextTick`、FoliaCompatScheduler 及 Essentials 模块计时器，迁移其实体／区域／全局所有权并验证真实全栈。第 8 阶段实际 NPC／保护插件版本组合、第 9 阶段长时并发、首次迁移峰值、旧来源核对和其余容量问题也继续待办。当前只推进源码与单元测试，十阶段没有全部完成。
'''
(root/'docs/PERIODIC-LIFECYCLE-SOURCE-20261126.md').write_text(report,encoding='utf-8')
checkpoint = f'2026-11-26 最新检查点：[共享周期任务生命周期](PERIODIC-LIFECYCLE-SOURCE-20261126.md)。实体／全局周期任务补齐关闭、退休、迟到句柄与异常清理；新增 27 项，1,131 项相关回归零失败／错误、9 项既有跳过。最终 StarCore `{core[:8]}…{core[-6:]}` 已打包，公开签名与 5 个调度器类字节核对通过；Chronicle 主构件保持 `1c7b8b01…cd78ce`。旧同步调度、全栈 Folia 与真实插件组合继续待验，不启动 Minecraft。'
for name in ('README.md','docs/HANDOFF-2026-11-25.md','docs/REMAINING-WORK.md'):
    path = root/name
    text = path.read_text(encoding='utf-8')
    heading, body = text.split('\n',1)
    note = checkpoint.replace('(PERIODIC-LIFECYCLE-SOURCE-20261126.md)','(docs/PERIODIC-LIFECYCLE-SOURCE-20261126.md)') if name == 'README.md' else checkpoint
    text = heading+'\n\n'+note+'\n\n'+body.lstrip('\n')
    text = text.replace('2026-11-26 最新检查点：[NPC 生命周期与玩家会话]', '2026-11-26 上一 NPC 检查点：[NPC 生命周期与玩家会话]')
    text = text.replace('原生 owner 调度候选、Chronicle 独立模式历史证据 | StarCore 全栈验收；史诗原生适配器目前仅支持 Paper', '原生 owner 调度候选、Chronicle 独立模式历史证据；本轮实体／全局周期生命周期清理新增 27 项回归 | 旧 runSync／runNextTick 与 FoliaCompatScheduler、Essentials 计时器仍需逐个迁移；StarCore 全栈验收，史诗原生适配器目前仅支持 Paper')
    text = text.replace('1,558 项资源／国库／科研支付通过 |', '此前 1,558 项资源／国库／科研支付通过；本轮周期任务关闭与异常清理、1,131 项相关回归零失败／错误（9 项既有跳过） |')
    text = text.replace('GUI、计时、保存、Boss等还需全链路移植。', '共享实体／全局周期任务已补齐关闭与异常清理；旧 runSync／runNextTick、FoliaCompatScheduler、Essentials 计时器及 GUI、保存、Boss 等仍需逐个审计与全链路移植。')
    path.write_text(text,encoding='utf-8')
print(json.dumps({'tests':totals,'files':len(files),'artifacts':summary['artifacts'],'evidence_sha256':summary['evidence_zip_sha256']}))
