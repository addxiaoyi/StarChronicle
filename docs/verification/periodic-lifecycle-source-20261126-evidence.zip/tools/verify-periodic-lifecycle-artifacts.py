from pathlib import Path
import hashlib, json, os, subprocess, zipfile

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
out = root / 'run/periodic-lifecycle-artifacts-20261126'
out.mkdir(exist_ok=False)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
old = root / 'run/periodic-lifecycle-baseline-20261126/starcore.jar'
jar = native / 'target/starcore-1.0.0.jar'
classes = native / 'target/classes'
checked = {}
with zipfile.ZipFile(jar) as archive:
    for path in sorted((classes/'dev/starcore/starcore/core/scheduler').glob('StarCoreScheduler*.class')):
        name = path.relative_to(classes).as_posix()
        raw = path.read_bytes()
        assert archive.read(name) == raw, name
        assert int.from_bytes(raw[6:8], 'big') == 65, name
        checked[name] = sha(raw)
    assert any('EntityRepeatingTask' in name for name in checked)

source_hashes = {}
for name in ('StarCoreScheduler.java', 'RepeatingTaskLifecycleTest.java'):
    directory = 'src/main/java' if name == 'StarCoreScheduler.java' else 'src/test/java'
    source = native / directory / 'dev/starcore/starcore/core/scheduler' / name
    raw = source.read_bytes()
    assert raw == (root/'run/periodic-lifecycle-compile-20261126'/name).read_bytes(), name
    source_hashes[source.relative_to(native).as_posix()] = sha(raw)

javap = Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin\javap.exe')
apis = {}
for class_name in ('StarCoreScheduler', 'StarCoreScheduler$GlobalRepeatingTask'):
    full_name = 'dev.starcore.starcore.core.scheduler.' + class_name
    outputs = []
    for label, artifact in (('old', old), ('current', jar)):
        args = [str(javap), '-J-Xmx64m', '-J-XX:+UseSerialGC', '-public', '-classpath', str(artifact), full_name]
        result = subprocess.run(args, capture_output=True, check=True)
        (out/(label+'-'+class_name+'.txt')).write_bytes(result.stdout)
        outputs.append(result.stdout)
    assert outputs[0] == outputs[1], class_name
    apis[class_name] = sha(outputs[1])

bom = json.loads((native/'target/starcore-1.0.0-sbom.json').read_text(encoding='utf-8'))
assert len(bom['components']) == 36
summary = {'status':'VERIFIED', 'starcore_sha256':sha(jar.read_bytes()),
    'baseline_sha256':sha(old.read_bytes()), 'scheduler_class_hashes':checked,
    'compiled_source_hashes':source_hashes, 'public_api_hashes':apis,
    'sbom_components':len(bom['components']),
    'limits':['Bytecode/API comparison is not live Paper/Folia validation.',
              'Chronicle main artifacts are unchanged; prior integration results retain their original artifact boundaries.']}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
