package dev.starcore.starcore.module.narrative.engine;

import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Drives a per-player typewriter reveal animation.
 *
 * <p>Each typewriter run writes the source text one character at a time at a configurable speed
 * (milliseconds per character) into a {@link TypewriterState}. A callback is invoked on the main
 * thread once the text is fully revealed, the player clicks to skip, or the run is stopped.
 *
 * <p>Player-based reads require that player's entity owner. UUID-based reads are safe from any
 * thread because the controller stores immutable text and volatile progress by UUID.
 */
public final class TypewriterController {

  private final Logger logger;
  private final StarCoreScheduler scheduler;

  /** Live typewriter state keyed by player UUID. */
  private final Map<UUID, TypewriterState> activeStates = new ConcurrentHashMap<>();

  public TypewriterController(@NotNull Logger logger, @NotNull StarCoreScheduler scheduler) {
    this.logger = logger;
    this.scheduler = scheduler;
  }

  /**
   * Start a typewriter run for the given player.
   *
   * @param player the target player
   * @param text the text to reveal
   * @param speedMsPerChar milliseconds per character (clamped to >= 1)
   * @param onComplete callback invoked on the player's owning thread when finished
   */
  public void start(
      @NotNull Player player,
      @NotNull String text,
      int speedMsPerChar,
      @Nullable Consumer<TypewriterState> onComplete) {
    scheduler.requireEntityOwner(player);
    final UUID id = player.getUniqueId();
    // Stop any previous run
    stop(player);

    int safeSpeed = Math.max(1, speedMsPerChar);
    TypewriterState state = new TypewriterState(text, safeSpeed);
    activeStates.put(id, state);

    final long startTick = System.currentTimeMillis();
    state.startTimeMs = startTick;

    ScheduledTask task =
        scheduler.runAtEntityFixedRate(
            player,
            scheduledTask -> {
              if (!state.active || activeStates.get(id) != state) {
                state.active = false;
                activeStates.remove(id, state);
                scheduledTask.cancel();
                return;
              }
              state.currentIndex = Math.min(state.fullText.length(), state.currentIndex + 1);
              if (state.currentIndex >= state.fullText.length()) {
                boolean completed = activeStates.remove(id, state);
                state.active = false;
                scheduledTask.cancel();
                if (completed && onComplete != null) {
                  onComplete.accept(state);
                }
              }
            },
            () -> {
              activeStates.remove(id, state);
              state.active = false;
            },
            safeSpeed / 50L + 1L,
            Math.max(1L, safeSpeed / 50L));
    state.scheduledTask = task;
    if (task != null && (!state.active || activeStates.get(id) != state)) task.cancel();
    logger.log(
        Level.FINE,
        "Started typewriter for {0} ({1} chars @ {2}ms/char)",
        new Object[] {player.getName(), text.length(), safeSpeed});
  }

  /** Immediately complete the typewriter, invoking its callback. */
  public void completeImmediately(@NotNull Player player) {
    scheduler.requireEntityOwner(player);
    TypewriterState state = activeStates.get(player.getUniqueId());
    if (state == null) return;
    state.currentIndex = state.fullText.length();
    state.active = false;
    cancelInternal(player.getUniqueId());
  }

  /** True if a typewriter run is currently active for this player. */
  public boolean isTypewriterActive(@NotNull Player player) {
    scheduler.requireEntityOwner(player);
    return isTypewriterActive(player.getUniqueId());
  }

  /** True if a typewriter run is active for this player id. Safe from any thread. */
  public boolean isTypewriterActive(@NotNull UUID playerId) {
    TypewriterState state = activeStates.get(playerId);
    return state != null && state.active;
  }

  /** The text revealed so far. Requires the player's current entity owner thread. */
  @NotNull
  public String getCurrentText(@NotNull Player player) {
    scheduler.requireEntityOwner(player);
    return getCurrentText(player.getUniqueId());
  }

  /** The text revealed so far. Returns empty text when no run is active. Safe from any thread. */
  @NotNull
  public String getCurrentText(@NotNull UUID playerId) {
    TypewriterState state = activeStates.get(playerId);
    if (state == null) return "";
    int idx = Math.min(state.currentIndex, state.fullText.length());
    return state.fullText.substring(0, idx);
  }

  /** Cancel any active run for the player without invoking the completion callback. */
  public void stop(@NotNull Player player) {
    scheduler.requireEntityOwner(player);
    cancelInternal(player.getUniqueId());
  }

  /** Cancel any active run for this player id (no player object needed). */
  public void stopById(@NotNull UUID playerId) {
    cancelInternal(playerId);
  }

  /** Stop all typewriter runs. */
  public void stopAll() {
    for (UUID id : new ArrayList<>(activeStates.keySet())) {
      cancelInternal(id);
    }
  }

  private void cancelInternal(@NotNull UUID playerId) {
    TypewriterState state = activeStates.remove(playerId);
    if (state != null) {
      state.active = false;
      if (state.scheduledTask != null) {
        try {
          state.scheduledTask.cancel();
        } catch (IllegalStateException ignored) {
          // task already cancelled
        }
      }
    }
  }

  /** Mutable state for a single typewriter run. */
  public static final class TypewriterState {
    @NotNull public final String fullText;
    public final int speedMsPerChar;
    public volatile int currentIndex = 0;
    public volatile long startTimeMs = 0;
    public volatile boolean active = true;
    @Nullable public volatile ScheduledTask scheduledTask;

    public TypewriterState(@NotNull String fullText, int speedMsPerChar) {
      this.fullText = fullText;
      this.speedMsPerChar = speedMsPerChar;
    }
  }
}
