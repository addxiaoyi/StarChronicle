package dev.starcore.starcore.core.scheduler;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import io.papermc.paper.threadedregions.scheduler.EntityScheduler;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

class EntityTaskContractTest {
  private StarCoreScheduler scheduler;
  private JavaPlugin plugin;
  private Entity entity;
  private EntityScheduler owner;
  private MockedStatic<Bukkit> bukkit;
  private final AtomicReference<Runnable> body = new AtomicReference<>();
  private final AtomicReference<Runnable> retired = new AtomicReference<>();

  @BeforeEach
  void setup() {
    plugin = mock(JavaPlugin.class);
    entity = mock(Entity.class);
    owner = mock(EntityScheduler.class);
    scheduler = new StarCoreScheduler(plugin, 1, 1);
    bukkit = mockStatic(Bukkit.class);
    when(entity.getScheduler()).thenReturn(owner);
    when(owner.execute(eq(plugin), any(), any(), eq(1L)))
        .thenAnswer(
            call -> {
              body.set(call.getArgument(1));
              retired.set(call.getArgument(2));
              return true;
            });
  }

  @AfterEach
  void cleanup() {
    scheduler.shutdownNow();
    bukkit.close();
  }

  private void becomeOwner() {
    bukkit.when(() -> Bukkit.isOwnedByCurrentRegion(entity)).thenReturn(true);
  }

  @Test
  void ownerExecutesInlineAndReturnsActualValue() {
    becomeOwner();
    assertEquals("done", scheduler.callForEntity(entity, () -> "done").join());
    verifyNoInteractions(owner);
  }

  @Test
  void queuedIsNotAppliedUntilOwnedExecutionReturns() {
    AtomicInteger calls = new AtomicInteger();
    CompletableFuture<Integer> future = scheduler.callForEntity(entity, calls::incrementAndGet);
    assertFalse(future.isDone());
    assertEquals(0, calls.get());
    becomeOwner();
    body.get().run();
    assertEquals(1, future.join());
    assertEquals(1, calls.get());
  }

  @Test
  void retiredCompletesWithoutApplyingOrGlobalFallback() {
    AtomicInteger calls = new AtomicInteger();
    CompletableFuture<Integer> future = scheduler.callForEntity(entity, calls::incrementAndGet);
    retired.get().run();
    assertInstanceOf(
        StarCoreScheduler.EntityTaskNotAppliedException.class,
        assertThrows(CompletionException.class, future::join).getCause());
    becomeOwner();
    body.get().run();
    assertEquals(0, calls.get());
    bukkit.verify(() -> Bukkit.getScheduler(), never());
    bukkit.verify(() -> Bukkit.getGlobalRegionScheduler(), never());
  }

  @Test
  void schedulingFalseCompletesWithoutApplying() {
    when(owner.execute(eq(plugin), any(), any(), eq(1L))).thenReturn(false);
    CompletableFuture<String> future = scheduler.callForEntity(entity, () -> fail("must not run"));
    assertInstanceOf(
        StarCoreScheduler.EntityTaskNotAppliedException.class,
        assertThrows(CompletionException.class, future::join).getCause());
  }

  @Test
  void shutdownRejectsPendingAndPreventsLaterExecution() {
    AtomicInteger calls = new AtomicInteger();
    CompletableFuture<Integer> future = scheduler.callForEntity(entity, calls::incrementAndGet);
    scheduler.shutdownNow();
    becomeOwner();
    body.get().run();
    assertEquals(0, calls.get());
    assertInstanceOf(
        StarCoreScheduler.EntityTaskNotAppliedException.class,
        assertThrows(CompletionException.class, future::join).getCause());
  }

  @Test
  void cancelledPendingFuturePreventsApplication() {
    AtomicInteger calls = new AtomicInteger();
    CompletableFuture<Integer> future = scheduler.callForEntity(entity, calls::incrementAndGet);
    assertTrue(future.cancel(false));
    becomeOwner();
    body.get().run();
    assertEquals(0, calls.get());
  }

  @Test
  void bodyErrorPropagatesAndIsNotRelabelledNotApplied() {
    becomeOwner();
    IllegalStateException failure = new IllegalStateException("body failed after entry");
    CompletableFuture<String> future =
        scheduler.callForEntity(
            entity,
            () -> {
              throw failure;
            });
    assertSame(failure, assertThrows(CompletionException.class, future::join).getCause());
  }

  @Test
  void wrongOwnerCannotPassSynchronousGuard() {
    assertThrows(IllegalStateException.class, () -> scheduler.requireEntityOwner(entity));
  }

  @Test
  void misroutedSchedulerCallbackFailsBeforeApplication() {
    AtomicInteger calls = new AtomicInteger();
    CompletableFuture<Integer> future = scheduler.callForEntity(entity, calls::incrementAndGet);
    body.get().run();
    assertEquals(0, calls.get());
    assertInstanceOf(
        IllegalStateException.class,
        assertThrows(CompletionException.class, future::join).getCause());
  }

  @Test
  void repeatingWorkUsesTheEntitySchedulerAndRetiresWithoutGlobalFallback() {
    AtomicReference<Consumer<ScheduledTask>> action = new AtomicReference<>();
    AtomicReference<Runnable> retiredAction = new AtomicReference<>();
    ScheduledTask scheduled = mock(ScheduledTask.class);
    when(owner.runAtFixedRate(eq(plugin), any(), any(), eq(2L), eq(1L)))
        .thenAnswer(
            call -> {
              action.set(call.getArgument(1));
              retiredAction.set(call.getArgument(2));
              return scheduled;
            });
    AtomicInteger ticks = new AtomicInteger();
    AtomicInteger retired = new AtomicInteger();

    ScheduledTask result =
        scheduler.runAtEntityFixedRate(
            entity, ignored -> ticks.incrementAndGet(), retired::incrementAndGet, 2L, 1L);

    assertSame(plugin, result.getOwningPlugin());
    assertTrue(result.isRepeatingTask());
    becomeOwner();
    action.get().accept(scheduled);
    assertEquals(1, ticks.get());
    retiredAction.get().run();
    assertEquals(1, retired.get());
    verify(owner).runAtFixedRate(eq(plugin), any(), any(), eq(2L), eq(1L));
    bukkit.verify(() -> Bukkit.getScheduler(), never());
  }

  @Test
  void repeatingWorkRetiresImmediatelyWhenTheSchedulerHasStopped() {
    scheduler.shutdownNow();
    AtomicInteger retired = new AtomicInteger();

    assertNull(
        scheduler.runAtEntityFixedRate(
            entity, ignored -> fail("must not schedule"), retired::incrementAndGet, 1L, 1L));

    assertEquals(1, retired.get());
    verifyNoInteractions(owner);
  }
}
