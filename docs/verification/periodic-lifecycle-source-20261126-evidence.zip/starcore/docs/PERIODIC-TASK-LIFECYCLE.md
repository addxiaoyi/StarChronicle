# Shared periodic task lifecycle

`StarCoreScheduler.runAtEntityFixedRate` and `runGlobalRepeatingTask` keep their existing method signatures. A zero initial delay is normalized to the next tick; negative initial delays and nonpositive periods are rejected before platform registration.

Entity tasks use the exact supplied entity's scheduler and check ownership before each callback. They return a tracked `ScheduledTask`; callbacks receive that same handle. Callers must use the interface and must not depend on identity with a platform implementation. Explicit `cancel()` invalidates future callbacks and removes tracking, without invoking the retirement callback.

Scheduler shutdown, entity retirement, null/rejected registration, and callback failure invalidate the task and invoke retirement at most once. Retirement must only clean detached state: it can run on the shutdown or registration thread and must not access entities or worlds. The current typewriter consumer only removes its captured state from a concurrent map and marks it inactive. Shutdown cleans that state immediately even if the platform never delivers another tick or retirement notification.

Registration publishes a handle before calling the platform. Shutdown or retirement during registration is retained; a platform task returned later is cancelled. Callback failure stops subsequent calls, removes tracking, and propagates the original exception; a cleanup exception is suppressed onto that exception. Global registration and callback failures also release their tracked handles.

Cancellation failure during shutdown is logged, and remaining tasks and executors are still shut down. A callback that already passed its admission checks may finish; cancellation does not undo executed work or claim that it was never applied. The existing one-shot `callForEntity` no-application result remains separate.

This change covers the shared entity/global periodic APIs and their current consumers. It does not make `runSync*`, `runNextTick`, or `FoliaCompatScheduler` globally safe, migrate every legacy caller, or certify a full Folia server. Those call sites still require ownership-specific review and actual server verification. Source regression and artifact evidence are maintained in the companion Chronicle repository's `docs/PERIODIC-LIFECYCLE-SOURCE-20261126.md`.
