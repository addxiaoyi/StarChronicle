package dev.starcore.starcore.module.technology;

import dev.starcore.starcore.module.resource.NationResourceTransactionService;
import dev.starcore.starcore.module.treasury.NationCreditService;
import dev.starcore.starcore.module.treasury.NationSpendingService;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import java.util.function.Consumer;

final class ResearchPaymentProcessor {
  enum Outcome {
    COMMITTED,
    ALREADY_COMMITTED,
    INSUFFICIENT_FUNDS,
    INSUFFICIENT_RESOURCES,
    REFUNDED,
    RETRYABLE_FAILURE
  }

  record Result(Outcome outcome, ResearchPayment payment) {}

  private final NationSpendingService spendingService;
  private final NationCreditService creditService;
  private final NationResourceTransactionService resourceTransactions;
  private final ResearchPaymentStore store;
  private final Clock clock;

  ResearchPaymentProcessor(
      NationSpendingService spendingService,
      NationCreditService creditService,
      NationResourceTransactionService resourceTransactions,
      ResearchPaymentStore store) {
    this(spendingService, creditService, resourceTransactions, store, Clock.systemUTC());
  }

  ResearchPaymentProcessor(
      NationSpendingService spendingService,
      NationCreditService creditService,
      NationResourceTransactionService resourceTransactions,
      ResearchPaymentStore store,
      Clock clock) {
    this.spendingService = Objects.requireNonNull(spendingService, "spendingService");
    this.creditService = Objects.requireNonNull(creditService, "creditService");
    this.resourceTransactions =
        Objects.requireNonNull(resourceTransactions, "resourceTransactions");
    this.store = Objects.requireNonNull(store, "store");
    this.clock = Objects.requireNonNull(clock, "clock");
  }

  Result process(ResearchPayment candidate, Consumer<ResearchProgress> onProgress) {
    if (candidate == null) {
      throw new IllegalArgumentException("candidate must not be null");
    }
    try {
      return processAttempt(candidate, onProgress);
    } catch (ResourceReceiptUnavailable unavailable) {
      // Preserve this payment and its debit/refund IDs until the authority can be read again.
      return new Result(Outcome.RETRYABLE_FAILURE, candidate);
    }
  }

  private Result processAttempt(ResearchPayment candidate, Consumer<ResearchProgress> onProgress) {
    ResearchPayment current;
    try {
      current = store.prepare(candidate);
    } catch (RuntimeException persistenceFailure) {
      return new Result(Outcome.RETRYABLE_FAILURE, candidate);
    }

    if (current.state() == ResearchPaymentState.RESEARCH_COMMITTED) {
      return new Result(Outcome.ALREADY_COMMITTED, current);
    }
    if (current.state() == ResearchPaymentState.INSUFFICIENT_FUNDS) {
      return new Result(Outcome.INSUFFICIENT_FUNDS, current);
    }
    if (current.state() == ResearchPaymentState.INSUFFICIENT_RESOURCES) {
      return new Result(Outcome.INSUFFICIENT_RESOURCES, current);
    }
    if (current.state() == ResearchPaymentState.REFUNDED) {
      return new Result(Outcome.REFUNDED, current);
    }
    if (store.isResearching(current.nationId(), current.technologyKey())) {
      ResearchPayment committed =
          current.transition(ResearchPaymentState.RESEARCH_COMMITTED, now(), "");
      saveBestEffort(committed);
      return new Result(Outcome.ALREADY_COMMITTED, committed);
    }

    if (hasAnyRefundReceipt(current)) {
      return compensate(
          current, ResearchPaymentState.REFUNDED, "Recovered compensated research payment");
    }

    current = reconstructFromReceipts(current);
    Result treasuryResult = debitTreasury(current);
    if (treasuryResult != null) {
      if (treasuryResult.outcome() != Outcome.COMMITTED) {
        return treasuryResult;
      }
      current = treasuryResult.payment();
    }

    Result resourceResult = debitResources(current);
    if (resourceResult != null) {
      if (resourceResult.outcome() != Outcome.COMMITTED) {
        return resourceResult;
      }
      current = resourceResult.payment();
    }

    ResearchPayment committed =
        current.transition(ResearchPaymentState.RESEARCH_COMMITTED, now(), "");
    ResearchPaymentStore.CommitStatus commitStatus;
    try {
      commitStatus = store.commitResearch(committed, onProgress);
    } catch (RuntimeException persistenceFailure) {
      return compensate(
          current, ResearchPaymentState.REFUNDED, "Research state persistence failed");
    }
    if (commitStatus == ResearchPaymentStore.CommitStatus.REJECTED) {
      return compensate(
          current, ResearchPaymentState.REFUNDED, "Research state commit was rejected");
    }
    Outcome outcome =
        commitStatus == ResearchPaymentStore.CommitStatus.ALREADY_COMMITTED
            ? Outcome.ALREADY_COMMITTED
            : Outcome.COMMITTED;
    return new Result(outcome, committed);
  }

  private ResearchPayment reconstructFromReceipts(ResearchPayment payment) {
    ResearchPayment current = payment;
    if (payment.hasTreasuryCost()
        && spendingService.hasSpendingReceipt(payment.treasuryDebitId())) {
      current = current.transition(ResearchPaymentState.TREASURY_DEBITED, now(), "");
    }
    if (payment.hasResourceCosts() && hasResourceReceipt(payment.resourceDebitId())) {
      current = current.transition(ResearchPaymentState.RESOURCES_DEBITED, now(), "");
    }
    if (current.state() != payment.state()) {
      saveBestEffort(current);
    }
    return current;
  }

  private Result debitTreasury(ResearchPayment payment) {
    if (!payment.hasTreasuryCost()
        || spendingService.hasSpendingReceipt(payment.treasuryDebitId())) {
      return new Result(Outcome.COMMITTED, payment);
    }
    NationSpendingService.SpendResult spend =
        spendingService.spend(
            new NationSpendingService.SpendRequest(
                payment.treasuryDebitId(),
                payment.nationId(),
                payment.treasuryCost(),
                NationSpendingService.SpendingCategory.RESEARCH,
                "Technology research " + payment.technologyKey()));
    if (spend.status() == NationSpendingService.SpendingStatus.INSUFFICIENT_FUNDS) {
      ResearchPayment insufficient =
          payment.transition(
              ResearchPaymentState.INSUFFICIENT_FUNDS, now(), "Insufficient treasury balance");
      saveBestEffort(insufficient);
      return new Result(Outcome.INSUFFICIENT_FUNDS, insufficient);
    }
    if (!spend.applied()) {
      return new Result(Outcome.RETRYABLE_FAILURE, payment);
    }
    ResearchPayment debited = payment.transition(ResearchPaymentState.TREASURY_DEBITED, now(), "");
    try {
      store.save(debited);
      return new Result(Outcome.COMMITTED, debited);
    } catch (RuntimeException persistenceFailure) {
      return compensate(
          payment, ResearchPaymentState.REFUNDED, "Treasury debit state persistence failed");
    }
  }

  private Result debitResources(ResearchPayment payment) {
    if (!payment.hasResourceCosts() || hasResourceReceipt(payment.resourceDebitId())) {
      return new Result(Outcome.COMMITTED, payment);
    }
    NationResourceTransactionService.TransactionResult consumed =
        resourceTransactions.consume(
            new NationResourceTransactionService.TransactionRequest(
                payment.resourceDebitId(),
                payment.nationId(),
                payment.resourceCosts(),
                NationResourceTransactionService.Category.RESEARCH,
                "Technology research " + payment.technologyKey()));
    if (consumed.status() == NationResourceTransactionService.Status.INSUFFICIENT_RESOURCES) {
      return compensate(
          payment, ResearchPaymentState.INSUFFICIENT_RESOURCES, "Insufficient research resources");
    }
    if (!consumed.applied()) {
      return new Result(Outcome.RETRYABLE_FAILURE, payment);
    }
    ResearchPayment debited = payment.transition(ResearchPaymentState.RESOURCES_DEBITED, now(), "");
    try {
      store.save(debited);
      return new Result(Outcome.COMMITTED, debited);
    } catch (RuntimeException persistenceFailure) {
      return compensate(
          payment, ResearchPaymentState.REFUNDED, "Resource debit state persistence failed");
    }
  }

  private Result compensate(
      ResearchPayment payment, ResearchPaymentState finalState, String reason) {
    boolean resourceRefunded = refundResources(payment);
    boolean treasuryRefunded = refundTreasury(payment);
    if (!resourceRefunded || !treasuryRefunded) {
      return new Result(Outcome.RETRYABLE_FAILURE, payment);
    }
    ResearchPayment compensated = payment.transition(finalState, now(), reason);
    saveBestEffort(compensated);
    Outcome outcome =
        switch (finalState) {
          case INSUFFICIENT_RESOURCES -> Outcome.INSUFFICIENT_RESOURCES;
          case REFUNDED -> Outcome.REFUNDED;
          default -> Outcome.RETRYABLE_FAILURE;
        };
    return new Result(outcome, compensated);
  }

  private boolean refundTreasury(ResearchPayment payment) {
    if (!payment.hasTreasuryCost()
        || !spendingService.hasSpendingReceipt(payment.treasuryDebitId())
        || creditService.hasCreditReceipt(payment.treasuryRefundId())) {
      return true;
    }
    return creditService
        .credit(
            new NationCreditService.CreditRequest(
                payment.treasuryRefundId(),
                payment.nationId(),
                payment.treasuryCost(),
                NationCreditService.CreditCategory.RESEARCH_REFUND,
                "Refund for research " + payment.technologyKey()))
        .applied();
  }

  private boolean refundResources(ResearchPayment payment) {
    if (!payment.hasResourceCosts()
        || !hasResourceReceipt(payment.resourceDebitId())
        || hasResourceReceipt(payment.resourceRefundId())) {
      return true;
    }
    return resourceTransactions
        .grant(
            new NationResourceTransactionService.TransactionRequest(
                payment.resourceRefundId(),
                payment.nationId(),
                payment.resourceCosts(),
                NationResourceTransactionService.Category.COMPENSATION_REFUND,
                "Refund for research " + payment.technologyKey()))
        .applied();
  }

  private boolean hasAnyRefundReceipt(ResearchPayment payment) {
    return creditService.hasCreditReceipt(payment.treasuryRefundId())
        || (payment.hasResourceCosts() && hasResourceReceipt(payment.resourceRefundId()));
  }

  private boolean hasResourceReceipt(String transactionId) {
    try {
      return resourceTransactions.hasTransactionReceipt(transactionId);
    } catch (RuntimeException unavailable) {
      throw new ResourceReceiptUnavailable(unavailable);
    }
  }

  private static final class ResourceReceiptUnavailable extends RuntimeException {
    private ResourceReceiptUnavailable(RuntimeException cause) {
      super(cause);
    }
  }

  private void saveBestEffort(ResearchPayment payment) {
    try {
      store.save(payment);
    } catch (RuntimeException ignored) {
      // Financial and resource receipts reconstruct the durable state on retry.
    }
  }

  private Instant now() {
    return clock.instant();
  }
}
