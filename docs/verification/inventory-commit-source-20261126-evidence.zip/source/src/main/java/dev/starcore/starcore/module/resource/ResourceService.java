package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.util.Collection;
import java.util.Map;

public interface ResourceService {
  Collection<String> availableResourceTypes();

  Map<String, Long> stockpile(NationId nationId);

  long amount(NationId nationId, String resourceType);

  /**
   * A persistence failure returns false even if storage committed before acknowledgement failed.
   * Use {@link NationResourceTransactionService} with a stable ID for retryable operations.
   */
  boolean grant(NationId nationId, String resourceType, long amount);

  /** Same unconfirmed-persistence and retry semantics as {@link #grant}. */
  boolean consume(NationId nationId, String resourceType, long amount);

  String summary();
}
