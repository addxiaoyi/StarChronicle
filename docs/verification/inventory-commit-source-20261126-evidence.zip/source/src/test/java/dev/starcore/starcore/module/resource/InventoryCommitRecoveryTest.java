package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.*;
import java.lang.reflect.Proxy;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.bukkit.plugin.java.JavaPlugin;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.sqlite.SQLiteDataSource;

class InventoryCommitRecoveryTest {
  @TempDir Path directory;
  static final NationId NATION = FactorySnapshotVersionTest.NATION;

  enum Action {
    DIRECT_GRANT,
    DIRECT_CONSUME,
    KEYED_GRANT,
    KEYED_CONSUME;

    boolean keyed() {
      return this == KEYED_GRANT || this == KEYED_CONSUME;
    }

    long expected() {
      return this == DIRECT_GRANT || this == KEYED_GRANT ? 8 : 4;
    }

    Object apply(ResourceModule module, String id) {
      var request =
          new TransactionRequest(id, NATION, Map.of("industrial", 2L), Category.OTHER, id);
      return switch (this) {
        case DIRECT_GRANT -> module.grant(NATION, "industrial", 2);
        case DIRECT_CONSUME -> module.consume(NATION, "industrial", 2);
        case KEYED_GRANT -> module.grant(request).status();
        case KEYED_CONSUME -> module.consume(request).status();
      };
    }
  }

  static Stream<Arguments> storesAndActions() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(engine -> Stream.of(Action.values()).map(action -> Arguments.of(engine, action)));
  }

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @MethodSource("storesAndActions")
  void lostAcknowledgementRestoresTheCommittedInventoryAndAllFactoryProofs(
      String engine, Action action) throws Exception {
    var fixture = fixture(engine);
    var module = fixture.module();
    fixture.fault.arm(false, false);
    assertEquals(action.keyed() ? Status.ALREADY_APPLIED : false, action.apply(module, "lost"));
    assertFalse(fixture.fault.armed.get());
    assertEquals(action.expected(), module.amount(NATION, "industrial"));
    assertEquals(fixture.domain, module.authorityDomainId());
    assertProofs(fixture, module, engine.equals("file") ? 4 : 1);
    if (action.keyed()) {
      var receipt = module.transactionReceipt("lost").orElseThrow();
      assertEquals(Map.of("industrial", 2L), receipt.resources());
      assertEquals(Status.ALREADY_APPLIED, action.apply(module, "lost"));
      var conflicting =
          new TransactionRequest("lost", NATION, Map.of("industrial", 3L), Category.OTHER, "lost");
      assertEquals(Status.REJECTED, module.grant(conflicting).status());
    }
    assertTrue(module.grant(NATION, "luxury", 1));
    var restarted = fixture.module();
    assertEquals(action.expected(), restarted.amount(NATION, "industrial"));
    assertEquals(1, restarted.amount(NATION, "luxury"));
    if (action.keyed()) assertEquals(Status.ALREADY_APPLIED, action.apply(restarted, "lost"));
    assertProofs(fixture, restarted, engine.equals("file") ? 4 : 1);
  }

  @ParameterizedTest
  @MethodSource("storesAndActions")
  void failureBeforeCommitRestoresOldStateAndAllowsOneSameKeyRetry(String engine, Action action)
      throws Exception {
    var fixture = fixture(engine);
    var module = fixture.module();
    var before = fixture.storage.load();
    fixture.fault.arm(true, false);
    assertEquals(action.keyed() ? Status.REJECTED : false, action.apply(module, "retry"));
    assertFalse(fixture.fault.armed.get());
    assertEquals(before, fixture.storage.load());
    assertEquals(6, module.amount(NATION, "industrial"));
    assertFalse(module.hasTransactionReceipt("retry"));
    assertProofs(fixture, module, 4);
    assertEquals(action.keyed() ? Status.APPLIED : true, action.apply(module, "retry"));
    assertEquals(action.expected(), fixture.module().amount(NATION, "industrial"));
  }

  @ParameterizedTest
  @MethodSource("storesAndActions")
  void failedReconciliationQuarantinesEveryInventoryWriterUntilRestart(String engine, Action action)
      throws Exception {
    var fixture = fixture(engine);
    var module = fixture.module();
    fixture.fault.arm(false, true);
    assertEquals(action.keyed() ? Status.REJECTED : false, action.apply(module, "unreadable"));
    assertTrue(module.authorityDomainId().isBlank());
    assertThrows(IllegalStateException.class, () -> module.transactionReceipt("unreadable"));
    fixture.fault.unreadable = false;
    var committed = fixture.storage.load();
    for (Action later : Action.values()) {
      assertEquals(later.keyed() ? Status.REJECTED : false, later.apply(module, "later"));
    }
    assertEquals(committed, fixture.storage.load());
    assertThrows(IllegalStateException.class, () -> module.hasTransactionReceipt("unreadable"));
    var restarted = fixture.module();
    assertEquals(fixture.domain, restarted.authorityDomainId());
    assertEquals(action.expected(), restarted.amount(NATION, "industrial"));
    if (action.keyed()) assertEquals(Status.ALREADY_APPLIED, action.apply(restarted, "unreadable"));
    assertProofs(fixture, restarted, engine.equals("file") ? 4 : 1);
  }

  @ParameterizedTest
  @EnumSource(Action.class)
  void changedAuthorityAfterCommitNeverBecomesAnAcceptedRollback(Action action) {
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          @Override
          public void save(Properties state) {
            boolean changingDomain = failAfter;
            try {
              super.save(state);
            } finally {
              if (changingDomain)
                this.state.setProperty("resource.authority-domain", UUID.randomUUID().toString());
            }
          }
        };
    var module = new ResourceModule(storage);
    assertTrue(module.grant(NATION, "industrial", 6));
    storage.failAfter = true;
    assertEquals(action.keyed() ? Status.REJECTED : false, action.apply(module, "changed-domain"));
    assertEquals("", module.authorityDomainId());
    assertThrows(IllegalStateException.class, () -> module.transactionReceipt("changed-domain"));
    var saved = storage.load();
    assertFalse(module.grant(NATION, "luxury", 1));
    assertEquals(saved, storage.load());
  }

  @Test
  void missingPersistentAuthorityRejectsInventoryWritesWithoutReplacingIt() {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    storage.state.setProperty("resource.authority-domain", "invalid-domain");
    var module = new ResourceModule(storage);
    var before = storage.load();
    for (Action action : Action.values()) {
      assertEquals(
          action.keyed() ? Status.REJECTED : false, action.apply(module, "invalid-domain"));
    }
    assertEquals(before, storage.load());
  }

  @Test
  void explicitlyInMemoryInventoryStillWorksWithoutPersistentAuthority() {
    var module = new ResourceModule();
    assertTrue(module.grant(NATION, "industrial", 6));
    assertTrue(module.consume(NATION, "industrial", 2));
    assertEquals(Status.APPLIED, Action.KEYED_GRANT.apply(module, "memory"));
    assertEquals(Status.ALREADY_APPLIED, Action.KEYED_GRANT.apply(module, "memory"));
    assertEquals(6, module.amount(NATION, "industrial"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void lostGrantAcknowledgementRestoresANewNationInsteadOfRemovingIt(String engine)
      throws Exception {
    var fixture = fixture(engine);
    var module = fixture.module();
    var newNation = NationId.random();
    fixture.fault.arm(false, false);
    assertFalse(module.grant(newNation, "mineral", 2));
    assertEquals(2, module.amount(newNation, "mineral"));
    assertTrue(module.grant(NATION, "luxury", 1));
    assertEquals(2, fixture.module().amount(newNation, "mineral"));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void failedAuthorityInitializationBlocksInventoryUntilAValidatedRestart(boolean afterCommit) {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    storage.failBefore = !afterCommit;
    storage.failAfter = afterCommit;
    var module = new ResourceModule(storage);
    assertEquals("", module.authorityDomainId());
    var before = storage.load();
    assertFalse(module.grant(NATION, "industrial", 1));
    assertEquals(Status.REJECTED, Action.KEYED_GRANT.apply(module, "initialization"));
    assertThrows(IllegalStateException.class, () -> module.transactionReceipt("initialization"));
    assertEquals(before, storage.load());
    assertTrue(new ResourceModule(storage).grant(NATION, "industrial", 1));
  }

  @ParameterizedTest
  @ValueSource(strings = {"success", "before", "after"})
  void receiptReadersWaitUntilCommitAndReconciliationFinish(String failure) throws Exception {
    var saving = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    var readerStarted = new CountDownLatch(1);
    var armed = new AtomicBoolean();
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          @Override
          public void save(Properties state) {
            if (armed.getAndSet(false)) {
              saving.countDown();
              try {
                if (!release.await(5, TimeUnit.SECONDS))
                  throw new IllegalStateException("test save timed out");
              } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e);
              }
              failBefore = failure.equals("before");
              failAfter = failure.equals("after");
            }
            super.save(state);
          }
        };
    var module = new ResourceModule(storage);
    assertTrue(module.grant(NATION, "industrial", 6));
    armed.set(true);
    try (var pool = Executors.newFixedThreadPool(2)) {
      try {
        var write = pool.submit(() -> Action.KEYED_CONSUME.apply(module, "concurrent"));
        assertTrue(saving.await(5, TimeUnit.SECONDS));
        var read =
            pool.submit(
                () -> {
                  readerStarted.countDown();
                  return module.transactionReceipt("concurrent");
                });
        assertTrue(readerStarted.await(5, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> read.get(100, TimeUnit.MILLISECONDS));
        release.countDown();
        var expected =
            switch (failure) {
              case "before" -> Status.REJECTED;
              case "after" -> Status.ALREADY_APPLIED;
              default -> Status.APPLIED;
            };
        assertEquals(expected, write.get(5, TimeUnit.SECONDS));
        assertEquals(!failure.equals("before"), read.get(5, TimeUnit.SECONDS).isPresent());
        assertEquals(failure.equals("before") ? 6 : 4, module.amount(NATION, "industrial"));
      } finally {
        release.countDown();
      }
    }
  }

  static void assertProofs(Fixture fixture, ResourceModule module, int liveCount) throws Exception {
    for (var run : fixture.runs.values())
      assertEquals(run, module.factoryRun(run.runId()).orElseThrow());
    assertEquals(liveCount, SqlFactoryArchiveTest.liveRuns(module));
    assertEquals(3, fixture.storage.latestProductionSequence());
    assertEquals(0, fixture.storage.latestTransferSequence());
  }

  record Fixture(
      ResourceStateStorage storage, Fault fault, String domain, Map<String, FactoryRun> runs) {
    ResourceModule module() {
      return new ResourceModule(storage, FactorySnapshotVersionTest.CLOCK);
    }
  }

  Fixture fixture(String engine) throws Exception {
    var legacy = FactorySnapshotVersionTest.legacy();
    var fault = new Fault();
    ResourceStateStorage storage;
    if (engine.equals("file")) {
      var plugin = mock(JavaPlugin.class);
      when(plugin.getDataFolder()).thenReturn(directory.toFile());
      when(plugin.getLogger()).thenReturn(Logger.getLogger("inventory-commit-test"));
      var persistence =
          new PersistenceService(plugin, null) {
            @Override
            public Properties loadProperties(String namespace, String fileName) {
              if (fault.unreadable)
                throw new IllegalStateException("read unavailable after commit");
              return super.loadProperties(namespace, fileName);
            }

            @Override
            public void saveProperties(String namespace, String fileName, Properties state) {
              boolean fail = fault.armed.getAndSet(false);
              if (fail && fault.before)
                throw new IllegalStateException("save failed before replacement");
              super.saveProperties(namespace, fileName, state);
              if (fail) {
                fault.unreadable = fault.failRead;
                throw new IllegalStateException("replaced file but acknowledgement lost");
              }
            }
          };
      persistence.start();
      persistence.saveProperties("resource", "resources.properties", legacy);
      storage = new PersistenceResourceStateStorage("resource", persistence);
    } else {
      DataSource actual;
      if (engine.equals("sqlite")) {
        var db = new SQLiteDataSource();
        db.setUrl("jdbc:sqlite:" + directory.resolve("inventory.db"));
        actual = db;
      } else {
        var db = new JdbcDataSource();
        db.setURL("jdbc:h2:mem:inventory-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
        actual = db;
      }
      var db =
          (DataSource)
              Proxy.newProxyInstance(
                  DataSource.class.getClassLoader(),
                  new Class<?>[] {DataSource.class},
                  (p, method, args) -> {
                    if (method.getName().equals("getConnection") && fault.unreadable)
                      throw new SQLException("connection unavailable after commit");
                    Object result = SqlFactoryArchiveTest.invoke(actual, method, args);
                    if (!(result instanceof Connection connection)) return result;
                    return Proxy.newProxyInstance(
                        Connection.class.getClassLoader(),
                        new Class<?>[] {Connection.class},
                        (proxy, call, values) -> {
                          boolean fail =
                              call.getName().equals("commit") && fault.armed.getAndSet(false);
                          if (fail && fault.before)
                            throw new SQLException("commit rejected before applying");
                          Object value = SqlFactoryArchiveTest.invoke(connection, call, values);
                          if (fail) {
                            fault.unreadable = fault.failRead;
                            throw new SQLException("committed but acknowledgement lost");
                          }
                          return value;
                        });
                  });
      storage = new SqlResourceStateStorage(db, legacy, Logger.getLogger("inventory-commit-test"));
    }
    return new Fixture(
        storage,
        fault,
        legacy.getProperty("resource.authority-domain"),
        FactorySnapshotVersionTest.restore(legacy, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
  }

  static class Fault {
    final AtomicBoolean armed = new AtomicBoolean();
    volatile boolean before, failRead, unreadable;

    void arm(boolean before, boolean failRead) {
      this.before = before;
      this.failRead = failRead;
      armed.set(true);
    }
  }
}
