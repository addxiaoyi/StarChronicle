package dev.starcore.starcore.module.technology;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.NationResourceTransactionService;
import dev.starcore.starcore.module.treasury.NationCreditService;
import dev.starcore.starcore.module.treasury.NationSpendingService;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class ResearchPaymentProcessorTest {
  private static final Instant NOW = Instant.parse("2026-03-01T00:00:00Z");
  private static final Clock CLOCK = Clock.fixed(NOW, ZoneOffset.UTC);

  @Test
  void rejectsNullPaymentInsteadOfReportingRetryableFailure() {
    ResearchPaymentProcessor processor =
        processor(new FakeSpending(), new FakeCredit(), new FakeResources(), new MemoryStore());

    assertThrows(IllegalArgumentException.class, () -> processor.process(null, null));
  }

  @Test
  void duplicateExecutionDoesNotRepeatPaymentsOrResearchCommit() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore();
    ResearchPayment payment = payment();
    ResearchPaymentProcessor processor = processor(spending, credit, resources, store);

    ResearchPaymentProcessor.Result first = processor.process(payment, null);
    ResearchPaymentProcessor.Result duplicate = processor.process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.COMMITTED, first.outcome());
    assertEquals(ResearchPaymentProcessor.Outcome.ALREADY_COMMITTED, duplicate.outcome());
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(1, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(1, store.commitCount);
    assertTrue(store.isResearching(payment.nationId(), payment.technologyKey()));
  }

  @Test
  void restartReconstructsDebitsFromReceiptsWithoutRepeatingThem() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore();
    ResearchPayment payment = payment();
    store.prepare(payment);
    spending.spend(spendRequest(payment));
    resources.consume(resourceRequest(payment, payment.resourceDebitId(), false));

    ResearchPaymentProcessor.Result recovered =
        processor(spending, credit, resources, store).process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.COMMITTED, recovered.outcome());
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(1, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(1, store.commitCount);
  }

  @Test
  void insufficientTreasuryBalanceDoesNotConsumeResources() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore();
    ResearchPayment payment = payment();
    spending.insufficient(payment.treasuryDebitId());

    ResearchPaymentProcessor.Result result =
        processor(spending, credit, resources, store).process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.INSUFFICIENT_FUNDS, result.outcome());
    assertEquals(0, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(0, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(0, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(0, store.commitCount);
    assertEquals(ResearchPaymentState.INSUFFICIENT_FUNDS, result.payment().state());
  }

  @Test
  void insufficientResourcesRefundTreasuryDebit() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore();
    ResearchPayment payment = payment();
    resources.insufficient(payment.resourceDebitId());

    ResearchPaymentProcessor.Result result =
        processor(spending, credit, resources, store).process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.INSUFFICIENT_RESOURCES, result.outcome());
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(1, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(0, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(0, store.commitCount);
    assertEquals(ResearchPaymentState.INSUFFICIENT_RESOURCES, result.payment().state());
  }

  @Test
  void researchCommitFailureRefundsTreasuryAndResources() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore();
    store.commitFailure = true;
    ResearchPayment payment = payment();

    ResearchPaymentProcessor.Result result =
        processor(spending, credit, resources, store).process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.REFUNDED, result.outcome());
    assertEquals(1, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(1, resources.appliedCount(payment.resourceRefundId()));
    assertEquals(0, store.commitCount);
    assertEquals(ResearchPaymentState.REFUNDED, result.payment().state());
  }

  @Test
  void treasuryDebitJournalFailureTriggersCompensationBeforeResourceDebit() {
    FakeSpending spending = new FakeSpending();
    FakeCredit credit = new FakeCredit();
    FakeResources resources = new FakeResources();
    MemoryStore store = new MemoryStore(Set.of(1));
    ResearchPayment payment = payment();

    ResearchPaymentProcessor.Result result =
        processor(spending, credit, resources, store).process(payment, null);

    assertEquals(ResearchPaymentProcessor.Outcome.REFUNDED, result.outcome());
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(1, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(0, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(0, store.commitCount);
  }

  @ParameterizedTest
  @ValueSource(ints = {1, 2, 3, 4, 5})
  void unavailableResourceProofKeepsOriginalPaymentForRecoveryWithoutDuplicateDebitsOrRefunds(
      int failedRead) {
    var spending = new FakeSpending();
    var credit = new FakeCredit();
    var resources = new FakeResources();
    var store = new MemoryStore();
    var payment = payment();
    resources.failOnRead = failedRead;
    store.commitFailure = failedRead >= 4;
    var processor = processor(spending, credit, resources, store);

    var failed = processor.process(payment, null);
    assertEquals(ResearchPaymentProcessor.Outcome.RETRYABLE_FAILURE, failed.outcome());
    assertEquals(payment.paymentId(), failed.payment().paymentId());
    assertEquals(failedRead >= 3 ? 1 : 0, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(failedRead >= 4 ? 1 : 0, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(0, resources.appliedCount(payment.resourceRefundId()));
    assertEquals(0, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(0, store.commitCount);

    resources.failOnRead = 0;
    var recovered = processor.process(payment, null);
    assertEquals(
        store.commitFailure
            ? ResearchPaymentProcessor.Outcome.REFUNDED
            : ResearchPaymentProcessor.Outcome.COMMITTED,
        recovered.outcome());
    processor.process(payment, null);
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(1, resources.appliedCount(payment.resourceDebitId()));
    assertEquals(store.commitFailure ? 1 : 0, resources.appliedCount(payment.resourceRefundId()));
    assertEquals(store.commitFailure ? 1 : 0, credit.appliedCount(payment.treasuryRefundId()));
    assertEquals(store.commitFailure ? 0 : 1, store.commitCount);
  }

  @Test
  void treasuryOnlyResearchDoesNotConsultAnUnavailableResourceAuthority() {
    var spending = new FakeSpending();
    var credit = new FakeCredit();
    var resources = new FakeResources();
    var store = new MemoryStore();
    var original = payment();
    var payment =
        ResearchPayment.prepared(
            original.paymentId(),
            original.operationId(),
            original.nationId(),
            original.technologyKey(),
            original.treasuryCost(),
            Map.of(),
            original.researchTimeSeconds(),
            NOW);
    resources.failOnRead = 1;
    assertEquals(
        ResearchPaymentProcessor.Outcome.COMMITTED,
        processor(spending, credit, resources, store).process(payment, null).outcome());
    assertEquals(0, resources.readCalls);
    assertEquals(1, spending.appliedCount(payment.treasuryDebitId()));
    assertEquals(0, resources.appliedCount(payment.resourceDebitId()));
  }

  private static ResearchPaymentProcessor processor(
      FakeSpending spending, FakeCredit credit, FakeResources resources, MemoryStore store) {
    return new ResearchPaymentProcessor(spending, credit, resources, store, CLOCK);
  }

  private static ResearchPayment payment() {
    NationId nationId = new NationId(java.util.UUID.randomUUID());
    String operationId = "technology-research:" + nationId + ":industrialization";
    return ResearchPayment.prepared(
        operationId + ":attempt-1",
        operationId,
        nationId,
        "industrialization",
        new BigDecimal("50.00"),
        Map.of("mineral", 10L, "energy", 5L),
        120,
        NOW);
  }

  private static NationSpendingService.SpendRequest spendRequest(ResearchPayment payment) {
    return new NationSpendingService.SpendRequest(
        payment.treasuryDebitId(),
        payment.nationId(),
        payment.treasuryCost(),
        NationSpendingService.SpendingCategory.RESEARCH,
        "Research");
  }

  private static NationResourceTransactionService.TransactionRequest resourceRequest(
      ResearchPayment payment, String transactionId, boolean refund) {
    return new NationResourceTransactionService.TransactionRequest(
        transactionId,
        payment.nationId(),
        payment.resourceCosts(),
        refund
            ? NationResourceTransactionService.Category.COMPENSATION_REFUND
            : NationResourceTransactionService.Category.RESEARCH,
        "Research");
  }

  private static final class MemoryStore implements ResearchPaymentStore {
    private final Map<String, ResearchPayment> payments = new HashMap<>();
    private final Set<String> activeResearch = new HashSet<>();
    private final Set<Integer> failingSaves;
    private int saveCount;
    private int commitCount;
    private boolean commitFailure;

    private MemoryStore() {
      this(Set.of());
    }

    private MemoryStore(Set<Integer> failingSaves) {
      this.failingSaves = Set.copyOf(failingSaves);
    }

    @Override
    public ResearchPayment prepare(ResearchPayment candidate) {
      ResearchPayment existing = payments.get(candidate.paymentId());
      if (existing != null) {
        if (!existing.sameBusinessOperation(candidate)) {
          throw new IllegalStateException("conflicting payment");
        }
        return existing;
      }
      payments.put(candidate.paymentId(), candidate);
      return candidate;
    }

    @Override
    public void save(ResearchPayment payment) {
      saveCount++;
      if (failingSaves.contains(saveCount)) {
        throw new IllegalStateException("journal unavailable");
      }
      payments.put(payment.paymentId(), payment);
    }

    @Override
    public CommitStatus commitResearch(
        ResearchPayment payment, java.util.function.Consumer<ResearchProgress> onProgress) {
      if (commitFailure) {
        throw new IllegalStateException("research state unavailable");
      }
      String key = key(payment.nationId(), payment.technologyKey());
      payments.put(payment.paymentId(), payment);
      if (!activeResearch.add(key)) {
        return CommitStatus.ALREADY_COMMITTED;
      }
      commitCount++;
      return CommitStatus.COMMITTED;
    }

    @Override
    public Collection<ResearchPayment> allPayments() {
      return List.copyOf(payments.values());
    }

    @Override
    public boolean isResearching(NationId nationId, String technologyKey) {
      return activeResearch.contains(key(nationId, technologyKey));
    }

    private static String key(NationId nationId, String technologyKey) {
      return nationId + ":" + technologyKey;
    }
  }

  private static final class FakeSpending implements NationSpendingService {
    private final Map<String, SpendingReceipt> receipts = new HashMap<>();
    private final Map<String, Integer> applied = new HashMap<>();
    private final Set<String> insufficient = new HashSet<>();

    @Override
    public SpendResult spend(SpendRequest request) {
      SpendingReceipt existing = receipts.get(request.transactionId());
      if (existing != null) {
        return new SpendResult(
            sameSpend(existing, request) ? SpendingStatus.ALREADY_APPLIED : SpendingStatus.REJECTED,
            request.transactionId(),
            BigDecimal.ZERO);
      }
      if (insufficient.contains(request.transactionId())) {
        return new SpendResult(
            SpendingStatus.INSUFFICIENT_FUNDS, request.transactionId(), BigDecimal.ZERO);
      }
      receipts.put(
          request.transactionId(),
          new SpendingReceipt(
              request.transactionId(),
              request.nationId(),
              request.amount(),
              request.category(),
              request.description(),
              NOW));
      applied.merge(request.transactionId(), 1, Integer::sum);
      return new SpendResult(SpendingStatus.APPLIED, request.transactionId(), BigDecimal.ZERO);
    }

    @Override
    public Optional<SpendingReceipt> spendingReceipt(String transactionId) {
      return Optional.ofNullable(receipts.get(transactionId));
    }

    private static boolean sameSpend(SpendingReceipt receipt, SpendRequest request) {
      return receipt.nationId().equals(request.nationId())
          && receipt.amount().compareTo(request.amount()) == 0
          && receipt.category() == request.category();
    }

    private void insufficient(String transactionId) {
      insufficient.add(transactionId);
    }

    private int appliedCount(String transactionId) {
      return applied.getOrDefault(transactionId, 0);
    }
  }

  private static final class FakeCredit implements NationCreditService {
    private final Map<String, CreditReceipt> receipts = new HashMap<>();
    private final Map<String, Integer> applied = new HashMap<>();

    @Override
    public CreditResult credit(CreditRequest request) {
      CreditReceipt existing = receipts.get(request.transactionId());
      if (existing != null) {
        return new CreditResult(
            sameCredit(existing, request) ? CreditStatus.ALREADY_APPLIED : CreditStatus.REJECTED,
            request.transactionId(),
            BigDecimal.ZERO);
      }
      receipts.put(
          request.transactionId(),
          new CreditReceipt(
              request.transactionId(),
              request.nationId(),
              request.amount(),
              request.category(),
              request.description(),
              NOW));
      applied.merge(request.transactionId(), 1, Integer::sum);
      return new CreditResult(CreditStatus.APPLIED, request.transactionId(), BigDecimal.ZERO);
    }

    @Override
    public Optional<CreditReceipt> creditReceipt(String transactionId) {
      return Optional.ofNullable(receipts.get(transactionId));
    }

    private static boolean sameCredit(CreditReceipt receipt, CreditRequest request) {
      return receipt.nationId().equals(request.nationId())
          && receipt.amount().compareTo(request.amount()) == 0
          && receipt.category() == request.category();
    }

    private int appliedCount(String transactionId) {
      return applied.getOrDefault(transactionId, 0);
    }
  }

  private static final class FakeResources implements NationResourceTransactionService {
    private final Map<String, TransactionReceipt> receipts = new HashMap<>();
    private final Map<String, Integer> applied = new HashMap<>();
    private final Set<String> insufficient = new HashSet<>();
    private int readCalls;
    private int failOnRead;

    @Override
    public TransactionResult consume(TransactionRequest request) {
      return apply(request, Operation.CONSUME);
    }

    @Override
    public TransactionResult grant(TransactionRequest request) {
      return apply(request, Operation.GRANT);
    }

    @Override
    public Optional<TransactionReceipt> transactionReceipt(String transactionId) {
      if (++readCalls == failOnRead)
        throw new IllegalStateException("resource authority unavailable");
      return Optional.ofNullable(receipts.get(transactionId));
    }

    private TransactionResult apply(TransactionRequest request, Operation operation) {
      TransactionReceipt existing = receipts.get(request.transactionId());
      if (existing != null) {
        return new TransactionResult(
            sameResource(existing, request, operation) ? Status.ALREADY_APPLIED : Status.REJECTED,
            request.transactionId(),
            Map.of());
      }
      if (operation == Operation.CONSUME && insufficient.contains(request.transactionId())) {
        return new TransactionResult(
            Status.INSUFFICIENT_RESOURCES, request.transactionId(), Map.of());
      }
      receipts.put(
          request.transactionId(),
          new TransactionReceipt(
              request.transactionId(),
              request.nationId(),
              request.resources(),
              operation,
              request.category(),
              request.description(),
              NOW));
      applied.merge(request.transactionId(), 1, Integer::sum);
      return new TransactionResult(Status.APPLIED, request.transactionId(), Map.of());
    }

    private static boolean sameResource(
        TransactionReceipt receipt, TransactionRequest request, Operation operation) {
      return receipt.nationId().equals(request.nationId())
          && receipt.resources().equals(request.resources())
          && receipt.operation() == operation
          && receipt.category() == request.category();
    }

    private void insufficient(String transactionId) {
      insufficient.add(transactionId);
    }

    private int appliedCount(String transactionId) {
      return applied.getOrDefault(transactionId, 0);
    }
  }
}
