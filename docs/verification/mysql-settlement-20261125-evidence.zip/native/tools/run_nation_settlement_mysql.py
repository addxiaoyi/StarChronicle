#!/usr/bin/env python3
"""Run the opt-in national settlement tests against a dedicated loopback MySQL fixture.

Requires STARCORE_SETTLEMENT_MYSQL_URL / USER / PASSWORD in the environment.
The suite refuses port 3306, other catalogs, nonempty tables and foreign tables.
This runner never creates a server, grants permissions or changes server configuration.
"""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlsplit, parse_qs
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TEST = 'dev.starcore.starcore.module.resource.MySqlNationSettlementIntegrationTest'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New directory; existing evidence is never overwritten')
    args = parser.parse_args()
    url = os.environ.get('STARCORE_SETTLEMENT_MYSQL_URL', '')
    if not url.startswith('jdbc:mysql://'):
        raise SystemExit('Require a dedicated MySQL JDBC URL')
    parsed = urlsplit(url.removeprefix('jdbc:'))
    if parsed.hostname != '127.0.0.1' or not parsed.port or parsed.port == 3306 or parsed.path != '/starcore_settlement_it' or parsed.username or parsed.password or parsed.fragment:
        raise SystemExit('Require a non-default loopback port and the dedicated starcore_settlement_it catalog')
    query = parse_qs(parsed.query)
    if any(key.lower() in {'user', 'password'} for key in query):
        raise SystemExit('Credentials must use the child environment, never the JDBC URL')
    if any(not os.environ.get('STARCORE_SETTLEMENT_MYSQL_' + key) for key in ('USER', 'PASSWORD')):
        raise SystemExit('Missing dedicated fixture credentials')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    source = ROOT / ('src/test/java/' + TEST.replace('.', '/') + '.java')
    shutil.copy2(source, output / source.name)
    started = datetime.now(timezone.utc).isoformat()
    command = ['./mvnw', '-o', '-B', '-ntp', '-Dstarcore.mysql.settlement.it=true', '-Dtest=MySqlNationSettlementIntegrationTest', 'test']
    with (output / 'maven.log').open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    report = ROOT / ('target/surefire-reports/TEST-' + TEST + '.xml')
    counts = None
    if report.is_file() and report.stat().st_mtime >= datetime.fromisoformat(started).timestamp():
        shutil.copy2(report, output / report.name)
        counts = {key: int(ET.parse(report).getroot().get(key, 0)) for key in ('tests', 'failures', 'errors', 'skipped')}
    success = result.returncode == 0 and counts is not None and counts['tests'] > 0 and not any(counts[key] for key in ('failures', 'errors', 'skipped'))
    manifest = dict(status='PASSED' if success else 'FAILED', started_utc=started, finished_utc=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode, command=command, tests=counts,
                    target=dict(host='127.0.0.1', port=parsed.port, database='starcore_settlement_it'),
                    native_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                    files={p.name: sha(p) for p in output.iterdir() if p.is_file()})
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest, indent=2))
    raise SystemExit(0 if success else 1)


if __name__ == '__main__':
    main()
