# 国家贸易与生产的 MySQL 专项验收

2026-11-25：真实 MySQL Community Server 8.4.13（镜像服务器更新号8.4.13.1）上的31项国家贸易／生产集成测试通过，零失败／错误／跳过。产品源码未修改；本增量新增测试和复验工具，不生成或替换上一生产候选的冻结JAR。

数据库是本机独立Docker容器`starcore-settlement-mysql-20261125`，仅绑定127.0.0.1:33316，专用库与账号均为`starcore_settlement_it`。镜像`public.ecr.aws/docker/library/mysql@sha256:8c233bad33d520a7aae1c1e619c3a9775f4a1ba2d463d692fada04ec7f40be00`；所有11张实际资产／权威表为InnoDB，默认隔离REPEATABLE-READ，STRICT_TRANS_TABLES，二进制日志开启。JDBC采用TLS加密的loopback连接；没有外部主机身份／生产TLS验收结论。

## 实际覆盖

- 同一库存上的生产投入、国库直售、生产完成、重建模块及原请求重放，核对库存、国库、两类资产回执与独立来源。
- 开工／领取／取消三种转换，分别在事件INSERT、head UPDATE、资源revision UPDATE及库存INSERT处用真实MySQL触发器拒绝，共12个故障窗口；整个数据库的逐表逐列快照必须完全回到原值。
- 交易分别在库存、资源回执、结算及国库写入处拒绝；双方资产和所有回执共同回滚，移除故障后同一报价可成交。
- JDBC commit已真实成功后注入回应丢失；三种生产转换及贸易重载后不重复扣除、发放或退款。进一步模拟重读也失败，阻止普通资产写入，重新创建服务后可核对已提交请求。
- 两套独立资源／国库模块和独立持久队列同时领取同一批次、同时接受同一报价，只有一个实际提交；旧库存快照不能覆盖新生产或用于交易。
- 提交被暂停时，另一真实MySQL连接看不到未提交生产或交易的任何资产／回执变化；删除完整生产尾事件后，重载与普通资产写入拒绝。

测试类`MySqlNationSettlementIntegrationTest`仅在`-Dstarcore.mysql.settlement.it=true`时启用，拒绝常用3306端口、非loopback、其他库、外来表、非空表和既有触发器。只有完成这些检查才允许清理本测试拥有的11张表；测试账号没有全局SUPER权限。每个测试关闭自己创建的存储队列，SQL连接及线程池均关闭。

故障触发器需要独立服务器设置`log_bin_trust_function_creators=ON`。首轮20项中13项通过、7项因缺少此测试设置无法创建触发器而报错；保留原失败XML和日志。仅该专用容器设置后20项全通过，扩展到31项后全通过；最终通过可复验入口再执行31项。Docker Hub首次镜像拉取超时日志保留，后改用同一官方镜像的ECR镜像源并固定digest。

## 复验

在新的独立MySQL8.4实例创建上述专用库与限于该库的账号，所有表应为空。提供以下环境变量（密码通过本地私密配置注入，不写入仓库或命令参数）：

```text
STARCORE_SETTLEMENT_MYSQL_URL=jdbc:mysql://127.0.0.1:专用端口/starcore_settlement_it?...TLS参数...
STARCORE_SETTLEMENT_MYSQL_USER=专用账号
STARCORE_SETTLEMENT_MYSQL_PASSWORD=私密配置中的密码
JAVA_HOME=/path/to/java21
```

```bash
python3 tools/run_nation_settlement_mysql.py --output target/mysql-settlement-UNIQUE
```

入口使用仓库Wrapper离线执行实际测试，将本次Java测试源码、原始日志、Surefire XML、逐文件哈希和开始／结束时间保存在新目录；已有目录拒绝覆盖。它不启动数据库、不改服务端配置或授权。运行前须有本仓库的离线依赖；否则可先按常规构建流程准备依赖。

## 范围和续接

本增量基于`7ff849643b0b1541dacd83f8fe3962b9c2a0fdae`，产品与已验收源码`59ed52abbed5521eff6383df004985b1e13e1bbe`的`src/main`和`pom.xml`一致。完整产品构建仍对应原7,354项（21既有跳过）、冻结原生JAR`26e6fb895d0ee6422c8347b63dc442763b475ef5eb91f8c92c94702fb2ebb886`及上一14次Paper／SQLite组合启动。本次没有重跑或重标完整构建数字；31项是实际开启的MySQL专项，不是默认跳过的通过数。

这不是Paper切换MySQL后的全栈实服验收。没有实际数据库进程崩溃／断电、逻辑备份恢复、主从复制、外部TLS身份校验或长期容量结论。兼容结论只覆盖上述InnoDB表、版本、隔离及代码路径，不扩展到非事务表。生产原等待时间在测试中由Clock精确推进，国籍与线程授权通过受控测试提供者；真实非OP命令和自然等待的证据仍属于上一Paper验收。

下一步在独立Paper组合接入该数据库，完成生产／贸易命令、原生持久化、Chronicle收件与贡献以及数据库和游戏服务重启联合检查。候选未合并或部署生产服，十阶段仍active。配对Chronicle分支`codex/mysql-settlement-20261125`的`docs/MYSQL-SETTLEMENT-TEST-REPORT.md`保存证据包、机器清单和十阶段交接入口。
