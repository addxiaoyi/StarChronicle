package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Properties;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class TreasurySnapshotValidationTest {
  @org.junit.jupiter.api.io.TempDir java.nio.file.Path directory;

  static Stream<Arguments> damaged() {
    return Stream.of(
        Arguments.of("count", "2147483647"),
        Arguments.of("spending.count", "-1"),
        Arguments.of("credit.count", "broken"),
        Arguments.of("transfer.count", "0"),
        Arguments.of("treasury.0.nationId", "1-1-1-1-1"),
        Arguments.of("treasury.0.balance", "-1"),
        Arguments.of("treasury.0.balance", "1000000000000000.01"),
        Arguments.of("treasury.0.balance", "1.001"),
        Arguments.of("spending.0.amount", "0"),
        Arguments.of("spending.0.amount", "0.009"),
        Arguments.of("spending.0.refunded", "yes"),
        Arguments.of("spending.0.nationId", "bad"),
        Arguments.of("credit.0.transactionId", " "),
        Arguments.of("credit.0.category", "bad"),
        Arguments.of("credit.0.appliedAt", "9223372036854775808"),
        Arguments.of("transfer.0.payerId", TreasuryCommitRecoveryTest.RECEIVER.toString()),
        Arguments.of("transfer.0.receiverId", "bad"),
        Arguments.of("transfer.0.appliedAt", "bad"),
        Arguments.of("treasury.01.balance", "10.00"),
        Arguments.of("credit.0.amout", "5.00"),
        Arguments.of("authorityDomainId", ""));
  }

  @ParameterizedTest
  @MethodSource("damaged")
  void damagedInitialStateIsRejectedBeforeMutationOrDomainCreation(String key, String value)
      throws Exception {
    var storage = new TreasuryCommitRecoveryTest.MemoryStorage();
    var state = TreasuryCommitRecoveryTest.seed();
    state.setProperty(key, value);
    storage.save(state);
    assertThrows(IllegalStateException.class, () -> TreasuryCommitRecoveryTest.loaded(storage));
    assertEquals(state, storage.load());
  }

  @ParameterizedTest
  @ValueSource(strings = {"treasury", "spending", "credit", "transfer"})
  void duplicateIdentityAndMissingDeclaredRowAreRejected(String collection) {
    var state = TreasuryCommitRecoveryTest.seed();
    String countKey = collection.equals("treasury") ? "count" : collection + ".count";
    int count = Integer.parseInt(state.getProperty(countKey));
    state.setProperty(countKey, Integer.toString(count + 1));
    assertThrows(IllegalStateException.class, () -> TreasuryStateValidation.read(state));
    for (String key : state.stringPropertyNames().toArray(String[]::new))
      if (key.startsWith(collection + ".0."))
        state.setProperty(
            collection + "." + count + key.substring((collection + ".0").length()),
            state.getProperty(key));
    assertThrows(IllegalStateException.class, () -> TreasuryStateValidation.read(state));
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void corruptedPersistedStateStaysIntactUntilRepairedAndReloaded(String engine) throws Exception {
    var helper = new TreasuryCommitRecoveryTest();
    helper.directory = directory;
    try {
      var fixture = helper.fixture(engine);
      var valid = fixture.storage().load();
      var broken = fixture.storage().load();
      broken.setProperty("transfer.0.amount", "broken");
      fixture.storage().save(broken);
      assertThrows(
          IllegalStateException.class, () -> TreasuryCommitRecoveryTest.loaded(fixture.storage()));
      assertEquals(broken, fixture.storage().load());
      fixture.storage().save(valid);
      assertTrue(
          TreasuryCommitRecoveryTest.loaded(fixture.storage())
              .hasTransferReceipt("preserved-transfer"));
    } finally {
      helper.shutdown();
    }
  }

  @Test
  void inheritedPropertiesAndOlderOptionalFieldsRemainSupported() throws Exception {
    var values = TreasuryCommitRecoveryTest.seed();
    values.remove("authorityDomainId");
    values.remove("spending.0.refunded");
    values.remove("spending.0.description");
    values.setProperty("treasury.0.balance", "100.000");
    var inherited = new Properties(values);
    var state = TreasuryStateValidation.read(inherited);
    assertEquals(2, state.balances().size());
    assertEquals(1, state.transferReceipts().size());
    assertFalse(state.spendingReceipts().get("refund").refunded());
    assertNull(state.authorityDomainId());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void badLegacyFileIsRejectedBeforeSqlRowsAndCanBeRepaired(String engine) throws Exception {
    javax.sql.DataSource source;
    if (engine.equals("sqlite")) {
      var db = new org.sqlite.SQLiteDataSource();
      db.setUrl("jdbc:sqlite:" + directory.resolve("import.db"));
      source = db;
    } else {
      var db = new org.h2.jdbcx.JdbcDataSource();
      db.setURL("jdbc:h2:" + directory.resolve("import").toString().replace('\\', '/'));
      source = db;
    }
    var legacy = TreasuryCommitRecoveryTest.seed();
    legacy.setProperty("transfer.0.amount", "broken");
    var storage =
        new SqlTreasuryStateStorage(source, legacy, java.util.logging.Logger.getAnonymousLogger());
    try {
      assertThrows(IllegalStateException.class, storage::load);
      assertEquals("broken", legacy.getProperty("transfer.0.amount"));
      try (var connection = source.getConnection();
          var statement = connection.createStatement();
          var rows = statement.executeQuery("SELECT COUNT(*) FROM starcore_treasury_state")) {
        assertTrue(rows.next());
        assertEquals(0, rows.getInt(1));
      }
      legacy.setProperty("transfer.0.amount", "1.00");
      assertTrue(
          TreasuryCommitRecoveryTest.loaded(storage).hasTransferReceipt("preserved-transfer"));
    } finally {
      storage.shutdown();
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void failedInitialDomainSaveCannotExposeAuthorityOrOverwriteDisk(boolean before)
      throws Exception {
    var armed = new java.util.concurrent.atomic.AtomicBoolean(true);
    var storage =
        new TreasuryCommitRecoveryTest.MemoryStorage() {
          @Override
          public void save(Properties value) {
            boolean fail = armed.getAndSet(false);
            if (fail && before) throw new IllegalStateException("before initial save");
            super.save(value);
            if (fail) throw new IllegalStateException("after initial save");
          }
        };
    var module = new TreasuryModule();
    var field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    assertThrows(
        IllegalStateException.class, () -> TreasuryCommitRecoveryTest.invoke(module, "loadState"));
    var original = storage.load();
    assertNull(module.authorityDomainId());
    assertThrows(
        IllegalStateException.class, () -> module.transfer(TreasuryCommitRecoveryTest.transfer()));
    TreasuryCommitRecoveryTest.invoke(module, "flushState");
    assertEquals(original, storage.load());
    var restarted = TreasuryCommitRecoveryTest.loaded(storage);
    assertNotNull(restarted.authorityDomainId());
    if (!before)
      assertEquals(original.getProperty("authorityDomainId"), restarted.authorityDomainId());
  }
}
