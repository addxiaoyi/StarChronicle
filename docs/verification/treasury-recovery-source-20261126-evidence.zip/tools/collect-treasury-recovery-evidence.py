import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


for label in ('final-test', 'package', 'sbom'):
    text = (root / f'run/treasury-recovery-{label}-20261126.log').read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text, label
log = (root / 'run/treasury-recovery-final-test-20261126.log').read_text(encoding='utf-8', errors='replace')
totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
packages = {}
suites = {}
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', log):
    report = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(report.read_bytes())
    assert name not in suites
    suites[name] = int(suite.attrib['tests'])
    package = 'resource' if '.resource.' in name else 'treasury' if '.treasury.' in name else 'technology'
    packages[package] = packages.get(package, 0) + suites[name]
    for key in totals:
        totals[key] += int(suite.attrib[key])
    add(report, 'native-final/surefire/' + report.name)
assert packages == {'resource': 1049, 'treasury': 184, 'technology': 13}, packages
assert all(totals[key] == 0 for key in ('failures', 'errors', 'skipped'))
assert suites['dev.starcore.starcore.module.treasury.TreasuryCommitRecoveryTest'] == 77
assert suites['dev.starcore.starcore.module.treasury.TreasurySnapshotValidationTest'] == 33
red_results = {}
for label in ('red', 'red2'):
    directory = root / f'run/treasury-recovery-{label}-20261126'
    xml = ET.fromstring(next(directory.glob('TEST-*.xml')).read_bytes())
    red_results[label] = {key: int(xml.attrib[key]) for key in totals}
    for path in directory.iterdir():
        add(path, label + '/' + path.name)
assert red_results['red'] == {'tests': 77, 'failures': 47, 'errors': 18, 'skipped': 0}
assert red_results['red2'] == {'tests': 77, 'failures': 59, 'errors': 0, 'skipped': 0}
for directory in (root / 'run').glob('treasury-recovery-failure-*'):
    for path in directory.rglob('*'):
        if path.is_file():
            add(path, 'prior-failures/' + directory.name + '/' + path.relative_to(directory).as_posix())
for path in (root / 'run').glob('treasury-recovery-*.log'):
    add(path, 'logs/' + path.name)
add(root / 'run/transfer-read-final-ci-20261126.json', 'github/baseline-ci.json')
contracts = {}
for label, folder in (('treasury', 'treasury-recovery-contract-20261126-1'), ('factory', 'factory-contract-treasury-recovery-20261126-1')):
    directory = root / 'run' / folder
    contracts[label] = json.loads((directory / 'manifest.json').read_text())
    assert contracts[label]['status'] == 'PASS'
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java', '.txt'):
            add(path, label + '/' + path.relative_to(directory).as_posix())
for name in ('TreasuryRecoveryProbe.java', 'run-treasury-recovery-contract.py', 'FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-treasury-recovery-evidence.py')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
source_hashes = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        source_hashes[name] = digest((native / name).read_bytes())
starcore_hash = digest((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle_hash = digest((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore_hash == contracts['treasury']['artifacts']['starcore.jar'] == contracts['factory']['artifacts']['starcore.jar']
assert chronicle_hash == contracts['factory']['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': '0b8043f34900481d24fd748c54264a6898064ffe', 'starcore': '305d8a77778de1f897a25503db9522bd8725dffc'},
    'scope': 'Native treasury commit reconciliation, receipt/balance monitor, durable internal IDs for legacy deposits/withdrawals, player deposit uncertainty without blind refund, strict canonical/legacy import validation and quarantine; no Minecraft',
    'red_tests': red_results, 'native_tests': totals, 'tests_by_package': packages,
    'new_tests': 112, 'native_source_hashes': source_hashes,
    'packaging': 'Separate sequential 256 MiB JVMs for testing and packaging; verify skips recompilation/tests and uses tested class output; independent online 36-component SBOM',
    'chronicle_tests': 'No main-source changes or new local full verify. Previous 957-test JAR retained. Baseline Linux Maven verification #135 passed.',
    'artifacts': {'starcore_sha256': starcore_hash, 'starchronicle_sha256': chronicle_hash},
    'contracts': contracts,
    'coverage': 'Focused native suite only; forkCount=0 and jacoco.skip=true. MySQL integration test not selected.',
    'limits': [
        'Uncertain native operations throw TreasuryTransactionUncertainException; the original ID must be reconciled before retry or compensation. Quarantine is not released by restored connectivity or periodic refresh.',
        'Legacy bool APIs generate internal receipts; these remain resident and fully persisted. Long-term treasury capacity is not certified.',
        'Reads use the current committed local snapshot, not multi-instance linearizable reads. SQL revision conflicts and refresh retain their scope.',
        'Player treasury credit uncertainty enters manual review; external personal economy and treasury do not share a transaction.',
        'Stable trade execution IDs, frozen terms, cross-service recovery and durable quota reservations are still pending.',
        'Missing authority domain, detached modules and third-party providers do not establish durable native authority.',
        'Current file/SQLite/H2 and packaged JVM validation do not certify Minecraft, MySQL, Folia or third-party stacks.'
    ]
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: digest(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/treasury-recovery-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(archive.read(name)) == expected
summary['evidence_zip_sha256'] = digest(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'treasury-recovery-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': packages, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
