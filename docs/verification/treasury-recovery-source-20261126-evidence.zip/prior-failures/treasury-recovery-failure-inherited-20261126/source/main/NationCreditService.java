package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/** Idempotent national credit boundary used by recoverable financial workflows. */
public interface NationCreditService {

  enum CreditCategory {
    TERRITORY_RENT,
    COMPENSATION_REFUND,
    BUDGET_SPENDING_REFUND,
    RESEARCH_REFUND,
    TREATY,
    NATIONAL_EVENT,
    OTHER
  }

  enum CreditStatus {
    APPLIED,
    ALREADY_APPLIED,
    REJECTED
  }

  record CreditRequest(
      String transactionId,
      NationId nationId,
      BigDecimal amount,
      CreditCategory category,
      String description) {
    public CreditRequest {
      transactionId = requireTransactionId(transactionId);
      nationId = Objects.requireNonNull(nationId, "nationId");
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
    }
  }

  record CreditReceipt(
      String transactionId,
      NationId nationId,
      BigDecimal amount,
      CreditCategory category,
      String description,
      Instant appliedAt) {
    public CreditReceipt {
      transactionId = requireTransactionId(transactionId);
      nationId = Objects.requireNonNull(nationId, "nationId");
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
      appliedAt = Objects.requireNonNull(appliedAt, "appliedAt");
    }

    boolean matches(CreditRequest request) {
      return nationId.equals(request.nationId())
          && amount.compareTo(request.amount()) == 0
          && category == request.category();
    }
  }

  record CreditResult(CreditStatus status, String transactionId, BigDecimal balanceAfter) {
    public boolean applied() {
      return status == CreditStatus.APPLIED || status == CreditStatus.ALREADY_APPLIED;
    }
  }

  /** Unresolved native persistence errors throw; reconcile this ID before retry or compensation. */
  CreditResult credit(CreditRequest request);

  /** Native reads wait for commit/reconciliation and throw while the module is quarantined. */
  Optional<CreditReceipt> creditReceipt(String transactionId);

  default boolean hasCreditReceipt(String transactionId) {
    return creditReceipt(transactionId).isPresent();
  }

  private static String requireTransactionId(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      throw new IllegalArgumentException("transactionId must not be blank");
    }
    return transactionId;
  }

  private static BigDecimal requirePositive(BigDecimal amount) {
    if (amount == null || amount.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    BigDecimal normalized = amount.setScale(2, RoundingMode.DOWN);
    if (normalized.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    return normalized;
  }
}
