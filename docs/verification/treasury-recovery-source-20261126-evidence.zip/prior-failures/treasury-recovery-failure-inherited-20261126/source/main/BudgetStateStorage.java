package dev.starcore.starcore.module.treasury;

import java.util.Optional;
import java.util.Properties;

interface BudgetStateStorage {
  Properties load();

  void save(Properties properties);

  /** Read without adopting the write revision until the owner validates the snapshot. */
  default Optional<BudgetStateRefresh> refreshIfChanged() {
    return Optional.empty();
  }

  default void acceptRefresh(BudgetStateRefresh refresh) {}
}
