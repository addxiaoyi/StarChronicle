package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Immutable receipt for one idempotent national expense. */
public record NationSpendingReceipt(
    UUID transactionId,
    NationId nationId,
    BudgetCategory category,
    BigDecimal amount,
    BigDecimal budgetAmount,
    BigDecimal treasuryAmount,
    UUID budgetId,
    String description,
    Instant spentAt,
    boolean refunded) {
  private static final int SCALE = 2;

  public NationSpendingReceipt {
    transactionId = Objects.requireNonNull(transactionId, "transactionId");
    nationId = Objects.requireNonNull(nationId, "nationId");
    category = Objects.requireNonNull(category, "category");
    amount = normalizeNonNegative(amount, "amount");
    budgetAmount = normalizeNonNegative(budgetAmount, "budgetAmount");
    treasuryAmount = normalizeNonNegative(treasuryAmount, "treasuryAmount");
    if (amount.signum() <= 0) {
      throw new IllegalArgumentException("amount must be positive");
    }
    if (budgetAmount.add(treasuryAmount).compareTo(amount) != 0) {
      throw new IllegalArgumentException("budgetAmount + treasuryAmount must equal amount");
    }
    if (budgetAmount.signum() > 0 && budgetId == null) {
      throw new IllegalArgumentException("budgetId is required when budgetAmount is positive");
    }
    if (budgetAmount.signum() == 0 && budgetId != null) {
      throw new IllegalArgumentException("budgetId must be null when no budget funds were used");
    }
    description = description == null ? "" : description.trim();
    spentAt = Objects.requireNonNull(spentAt, "spentAt");
  }

  public NationSpendingSource source() {
    if (budgetAmount.signum() > 0 && treasuryAmount.signum() > 0) {
      return NationSpendingSource.MIXED;
    }
    return budgetAmount.signum() > 0 ? NationSpendingSource.BUDGET : NationSpendingSource.TREASURY;
  }

  public NationSpendingReceipt asRefunded() {
    return refunded
        ? this
        : new NationSpendingReceipt(
            transactionId,
            nationId,
            category,
            amount,
            budgetAmount,
            treasuryAmount,
            budgetId,
            description,
            spentAt,
            true);
  }

  private static BigDecimal normalizeNonNegative(BigDecimal value, String name) {
    Objects.requireNonNull(value, name);
    BigDecimal normalized = value.setScale(SCALE, RoundingMode.DOWN);
    if (normalized.signum() < 0) {
      throw new IllegalArgumentException(name + " must be non-negative");
    }
    return normalized;
  }
}
