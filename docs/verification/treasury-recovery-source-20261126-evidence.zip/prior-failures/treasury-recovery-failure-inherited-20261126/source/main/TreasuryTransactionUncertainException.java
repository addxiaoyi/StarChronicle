package dev.starcore.starcore.module.treasury;

/**
 * No definitive commit result is available. Reconcile the original ID before retry or compensation.
 */
public final class TreasuryTransactionUncertainException extends IllegalStateException {
  private final String transactionId;

  TreasuryTransactionUncertainException(String transactionId, Throwable cause) {
    super("Treasury transaction outcome is unknown; reconcile original ID " + transactionId, cause);
    this.transactionId = transactionId;
  }

  public String transactionId() {
    return transactionId;
  }
}
