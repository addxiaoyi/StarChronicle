package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetBill;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

record BudgetStateSnapshot(
    Map<UUID, BudgetBill> budgets,
    Map<NationId, UUID> currentBudgets,
    Map<UUID, NationSpendingReceipt> receipts) {
  BudgetStateSnapshot {
    budgets = Map.copyOf(new LinkedHashMap<>(Objects.requireNonNull(budgets, "budgets")));
    currentBudgets =
        Map.copyOf(new LinkedHashMap<>(Objects.requireNonNull(currentBudgets, "currentBudgets")));
    receipts = Map.copyOf(new LinkedHashMap<>(Objects.requireNonNull(receipts, "receipts")));
  }

  static BudgetStateSnapshot empty() {
    return new BudgetStateSnapshot(Map.of(), Map.of(), Map.of());
  }
}
