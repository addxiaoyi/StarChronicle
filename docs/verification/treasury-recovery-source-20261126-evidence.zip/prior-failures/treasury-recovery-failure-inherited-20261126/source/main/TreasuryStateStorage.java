package dev.starcore.starcore.module.treasury;

import java.util.Optional;
import java.util.Properties;

interface TreasuryStateStorage {
  Properties load();

  void save(Properties properties);

  /** Reads a newer SQL snapshot without changing the revision used by subsequent writes. */
  default Optional<TreasuryStateRefresh> refreshIfChanged() {
    return Optional.empty();
  }

  /** Adopts a refreshed revision only after its owner safely applies the snapshot. */
  default boolean acceptRefresh(TreasuryStateRefresh refresh) {
    return true;
  }

  default void saveAsync(Properties properties) {
    save(properties);
  }
}
