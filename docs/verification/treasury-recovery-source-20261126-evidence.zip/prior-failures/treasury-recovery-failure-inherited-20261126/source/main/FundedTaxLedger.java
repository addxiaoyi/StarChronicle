package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class FundedTaxLedger {
    private static final String TABLE = "treasury_funded_taxes";

    private final ConcurrentMap<java.util.UUID, TaxQuote> funded = new ConcurrentHashMap<>();
    private final DatabaseService database;

    FundedTaxLedger() {
        this.database = null;
    }

    FundedTaxLedger(DatabaseService database) {
        this.database = Objects.requireNonNull(database, "database");
        database.execute("""
            CREATE TABLE IF NOT EXISTS treasury_funded_taxes (
                transaction_id VARCHAR(36) PRIMARY KEY,
                nation_id VARCHAR(36) NOT NULL,
                tax_type VARCHAR(32) NOT NULL,
                payer_id VARCHAR(36) NOT NULL,
                taxable_amount VARCHAR(64) NOT NULL,
                tax_amount VARCHAR(64) NOT NULL
            )
            """);
    }

    boolean claim(TaxQuote quote) {
        Objects.requireNonNull(quote, "quote");
        if (database != null) {
            return claimPersistent(quote);
        }
        TaxQuote existing = funded.putIfAbsent(quote.transactionId(), quote);
        return resolveClaim(quote, existing);
    }

    boolean release(TaxQuote quote) {
        Objects.requireNonNull(quote, "quote");
        if (database != null) {
            return database.update(
                "DELETE FROM " + TABLE + " WHERE transaction_id = ? AND nation_id = ? "
                    + "AND tax_type = ? AND payer_id = ? AND taxable_amount = ? AND tax_amount = ?",
                values(quote)
            ) == 1;
        }
        return funded.remove(quote.transactionId(), quote);
    }

    private boolean claimPersistent(TaxQuote quote) {
        try {
            database.update(
                "INSERT INTO " + TABLE + " (transaction_id, nation_id, tax_type, payer_id, "
                    + "taxable_amount, tax_amount) VALUES (?, ?, ?, ?, ?, ?)",
                values(quote)
            );
            return true;
        } catch (RuntimeException insertFailure) {
            TaxQuote existing;
            try {
                existing = find(quote.transactionId());
            } catch (RuntimeException lookupFailure) {
                insertFailure.addSuppressed(lookupFailure);
                throw new IllegalStateException(
                    "Unable to claim funded tax transaction " + quote.transactionId(),
                    insertFailure
                );
            }
            if (existing == null) {
                throw new IllegalStateException(
                    "Unable to claim funded tax transaction " + quote.transactionId(),
                    insertFailure
                );
            }
            return resolveClaim(quote, existing);
        }
    }

    private boolean resolveClaim(TaxQuote quote, TaxQuote existing) {
        if (existing == null) {
            return true;
        }
        if (existing.equals(quote)) {
            return false;
        }
        throw new IllegalStateException(
            "Tax transaction id was reused with different details: " + quote.transactionId());
    }

    private TaxQuote find(UUID transactionId) {
        return database.query(
            "SELECT nation_id, tax_type, payer_id, taxable_amount, tax_amount FROM "
                + TABLE + " WHERE transaction_id = ?",
            rows -> {
                try {
                    if (!rows.next()) {
                        return null;
                    }
                    return new TaxQuote(
                        transactionId,
                        new NationId(UUID.fromString(rows.getString("nation_id"))),
                        TaxType.valueOf(rows.getString("tax_type")),
                        UUID.fromString(rows.getString("payer_id")),
                        new BigDecimal(rows.getString("taxable_amount")),
                        new BigDecimal(rows.getString("tax_amount"))
                    );
                } catch (SQLException exception) {
                    throw new IllegalStateException(
                        "Unable to read funded tax transaction " + transactionId,
                        exception
                    );
                }
            },
            transactionId.toString()
        );
    }

    private Object[] values(TaxQuote quote) {
        return new Object[]{
            quote.transactionId().toString(),
            quote.nationId().value().toString(),
            quote.type().name(),
            quote.payerId().toString(),
            quote.taxableAmount().toPlainString(),
            quote.taxAmount().toPlainString()
        };
    }
}
