package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxPayer;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

final class TaxQuoteFactory {

    TaxQuote quote(
        UUID transactionId,
        NationId nationId,
        TaxConfig config,
        UUID payerId,
        BigDecimal taxableAmount
    ) {
        Objects.requireNonNull(config, "config");
        BigDecimal gross = Objects.requireNonNull(taxableAmount, "taxableAmount")
            .setScale(2, RoundingMode.DOWN);
        if (gross.signum() < 0) {
            throw new IllegalArgumentException("Taxable amount cannot be negative");
        }

        TaxPayer payer = new TaxPayer(payerId, gross);
        TaxContext context = contextFor(config.type(), payer);
        BigDecimal assessed = new TaxAssessment()
            .assess(config.type(), config, context)
            .stream()
            .map(TaxFunding.Charge::amount)
            .findFirst()
            .orElse(BigDecimal.ZERO);
        BigDecimal withheld = assessed.min(gross).setScale(2, RoundingMode.DOWN);
        return new TaxQuote(
            transactionId, nationId, config.type(), payerId, gross, withheld);
    }

    TaxContext contextFor(TaxType type, TaxPayer payer) {
        return switch (type) {
            case BUSINESS_TAX -> new TaxContext(
                0, 0, 1, payer.taxableAmount(), List.of(), List.of(payer), List.of());
            case TARIFF -> new TaxContext(
                0, 0, 0, payer.taxableAmount(), List.of(), List.of(), List.of(payer));
            default -> throw new IllegalArgumentException(
                "Transaction tax quote is unsupported for " + type);
        };
    }
}
