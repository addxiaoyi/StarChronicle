package dev.starcore.starcore.module.treasury;

/** Identifies where a committed national expense was funded. */
public enum NationSpendingSource {
  BUDGET,
  TREASURY,
  MIXED
}
