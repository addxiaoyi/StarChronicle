package dev.starcore.starcore.module.treasury;

/** The database commit may have succeeded even though its acknowledgement was lost. */
final class TreasuryStateReconciliationException extends IllegalStateException {
  TreasuryStateReconciliationException(Throwable cause) {
    super("Treasury state commit outcome is uncertain; reload canonical state", cause);
  }
}
