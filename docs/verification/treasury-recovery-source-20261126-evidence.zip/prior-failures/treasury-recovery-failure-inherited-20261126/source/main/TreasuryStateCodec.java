package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

final class TreasuryStateCodec {
  private static final int SCALE = 2;
  private static final Logger LOGGER = Logger.getLogger(TreasuryStateCodec.class.getName());

  private TreasuryStateCodec() {}

  record TreasuryState(
      String authorityDomainId,
      Map<NationId, BigDecimal> balances,
      Map<String, NationSpendingService.SpendingReceipt> spendingReceipts,
      Map<String, NationCreditService.CreditReceipt> creditReceipts,
      Map<String, NationTransferService.TransferReceipt> transferReceipts) {
    TreasuryState(
        Map<NationId, BigDecimal> balances,
        Map<String, NationSpendingService.SpendingReceipt> spendingReceipts,
        Map<String, NationCreditService.CreditReceipt> creditReceipts,
        Map<String, NationTransferService.TransferReceipt> transferReceipts) {
      this(null, balances, spendingReceipts, creditReceipts, transferReceipts);
    }

    TreasuryState {
      authorityDomainId = parseAuthorityDomain(authorityDomainId);
      balances = Map.copyOf(balances);
      spendingReceipts = Map.copyOf(spendingReceipts);
      creditReceipts = Map.copyOf(creditReceipts);
      transferReceipts = Map.copyOf(transferReceipts);
    }

    static TreasuryState empty() {
      return new TreasuryState(null, Map.of(), Map.of(), Map.of(), Map.of());
    }
  }

  static Properties toProperties(Map<NationId, BigDecimal> balances) {
    return toProperties(new TreasuryState(null, balances, Map.of(), Map.of(), Map.of()));
  }

  static Properties toProperties(TreasuryState state) {
    Properties properties = new Properties();
    if (state.authorityDomainId() != null) {
      properties.setProperty("authorityDomainId", state.authorityDomainId());
    }
    writeBalances(properties, state.balances());
    writeSpendingReceipts(properties, state.spendingReceipts());
    writeCreditReceipts(properties, state.creditReceipts());
    writeTransferReceipts(properties, state.transferReceipts());
    return properties;
  }

  static Map<NationId, BigDecimal> fromProperties(Properties properties) {
    return stateFromProperties(properties).balances();
  }

  static TreasuryState stateFromProperties(Properties properties) {
    if (properties == null || properties.isEmpty()) {
      return TreasuryState.empty();
    }
    return new TreasuryState(
        parseAuthorityDomain(properties.getProperty("authorityDomainId")),
        readBalances(properties),
        readSpendingReceipts(properties),
        readCreditReceipts(properties),
        readTransferReceipts(properties));
  }

  private static String parseAuthorityDomain(String value) {
    if (value == null || value.isBlank()) return null;
    try {
      return UUID.fromString(value).toString().equals(value) ? value : null;
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static void writeBalances(Properties properties, Map<NationId, BigDecimal> balances) {
    List<Map.Entry<NationId, BigDecimal>> snapshot =
        balances.entrySet().stream()
            .filter(entry -> entry.getValue() != null && entry.getValue().signum() != 0)
            .sorted((left, right) -> left.getKey().toString().compareTo(right.getKey().toString()))
            .toList();
    properties.setProperty("count", String.valueOf(snapshot.size()));
    for (int index = 0; index < snapshot.size(); index++) {
      Map.Entry<NationId, BigDecimal> entry = snapshot.get(index);
      String prefix = "treasury." + index + '.';
      properties.setProperty(prefix + "nationId", entry.getKey().toString());
      properties.setProperty(prefix + "balance", normalize(entry.getValue()).toPlainString());
    }
  }

  private static void writeSpendingReceipts(
      Properties properties, Map<String, NationSpendingService.SpendingReceipt> receipts) {
    List<NationSpendingService.SpendingReceipt> snapshot =
        receipts.values().stream()
            .sorted((left, right) -> left.transactionId().compareTo(right.transactionId()))
            .toList();
    properties.setProperty("spending.count", String.valueOf(snapshot.size()));
    for (int index = 0; index < snapshot.size(); index++) {
      NationSpendingService.SpendingReceipt receipt = snapshot.get(index);
      String prefix = "spending." + index + '.';
      properties.setProperty(prefix + "transactionId", receipt.transactionId());
      properties.setProperty(prefix + "nationId", receipt.nationId().toString());
      properties.setProperty(prefix + "amount", normalize(receipt.amount()).toPlainString());
      properties.setProperty(prefix + "category", receipt.category().name());
      properties.setProperty(prefix + "description", receipt.description());
      properties.setProperty(
          prefix + "appliedAt", String.valueOf(receipt.appliedAt().toEpochMilli()));
      properties.setProperty(prefix + "refunded", Boolean.toString(receipt.refunded()));
    }
  }

  private static void writeCreditReceipts(
      Properties properties, Map<String, NationCreditService.CreditReceipt> receipts) {
    List<NationCreditService.CreditReceipt> snapshot =
        receipts.values().stream()
            .sorted((left, right) -> left.transactionId().compareTo(right.transactionId()))
            .toList();
    properties.setProperty("credit.count", String.valueOf(snapshot.size()));
    for (int index = 0; index < snapshot.size(); index++) {
      NationCreditService.CreditReceipt receipt = snapshot.get(index);
      String prefix = "credit." + index + '.';
      properties.setProperty(prefix + "transactionId", receipt.transactionId());
      properties.setProperty(prefix + "nationId", receipt.nationId().toString());
      properties.setProperty(prefix + "amount", normalize(receipt.amount()).toPlainString());
      properties.setProperty(prefix + "category", receipt.category().name());
      properties.setProperty(prefix + "description", receipt.description());
      properties.setProperty(
          prefix + "appliedAt", String.valueOf(receipt.appliedAt().toEpochMilli()));
    }
  }

  private static void writeTransferReceipts(
      Properties properties, Map<String, NationTransferService.TransferReceipt> receipts) {
    List<NationTransferService.TransferReceipt> snapshot =
        receipts.values().stream()
            .sorted((left, right) -> left.transactionId().compareTo(right.transactionId()))
            .toList();
    properties.setProperty("transfer.count", String.valueOf(snapshot.size()));
    for (int index = 0; index < snapshot.size(); index++) {
      NationTransferService.TransferReceipt receipt = snapshot.get(index);
      String prefix = "transfer." + index + '.';
      properties.setProperty(prefix + "transactionId", receipt.transactionId());
      properties.setProperty(prefix + "payerId", receipt.payerId().toString());
      properties.setProperty(prefix + "receiverId", receipt.receiverId().toString());
      properties.setProperty(prefix + "amount", normalize(receipt.amount()).toPlainString());
      properties.setProperty(prefix + "category", receipt.category().name());
      properties.setProperty(prefix + "description", receipt.description());
      properties.setProperty(
          prefix + "appliedAt", String.valueOf(receipt.appliedAt().toEpochMilli()));
    }
  }

  private static Map<NationId, BigDecimal> readBalances(Properties properties) {
    int count = parseInt(properties.getProperty("count"), 0);
    Map<NationId, BigDecimal> balances = new LinkedHashMap<>();
    for (int index = 0; index < count; index++) {
      String prefix = "treasury." + index + '.';
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      BigDecimal balance = parseAmount(properties.getProperty(prefix + "balance"));
      if (nationId != null && balance != null && balance.signum() > 0) {
        balances.put(nationId, balance);
      }
    }
    return balances;
  }

  private static Map<String, NationSpendingService.SpendingReceipt> readSpendingReceipts(
      Properties properties) {
    int count = parseInt(properties.getProperty("spending.count"), 0);
    Map<String, NationSpendingService.SpendingReceipt> receipts = new LinkedHashMap<>();
    for (int index = 0; index < count; index++) {
      String prefix = "spending." + index + '.';
      String transactionId = properties.getProperty(prefix + "transactionId");
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      BigDecimal amount = parseAmount(properties.getProperty(prefix + "amount"));
      NationSpendingService.SpendingCategory category =
          parseSpendingCategory(properties.getProperty(prefix + "category"));
      Instant appliedAt = parseInstant(properties.getProperty(prefix + "appliedAt"));
      if (invalid(transactionId, nationId, amount, category, appliedAt)) continue;
      receipts.put(
          transactionId,
          new NationSpendingService.SpendingReceipt(
              transactionId,
              nationId,
              amount,
              category,
              properties.getProperty(prefix + "description", ""),
              appliedAt,
              Boolean.parseBoolean(properties.getProperty(prefix + "refunded", "false"))));
    }
    return receipts;
  }

  private static Map<String, NationCreditService.CreditReceipt> readCreditReceipts(
      Properties properties) {
    int count = parseInt(properties.getProperty("credit.count"), 0);
    Map<String, NationCreditService.CreditReceipt> receipts = new LinkedHashMap<>();
    for (int index = 0; index < count; index++) {
      String prefix = "credit." + index + '.';
      String transactionId = properties.getProperty(prefix + "transactionId");
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      BigDecimal amount = parseAmount(properties.getProperty(prefix + "amount"));
      NationCreditService.CreditCategory category =
          parseCreditCategory(properties.getProperty(prefix + "category"));
      Instant appliedAt = parseInstant(properties.getProperty(prefix + "appliedAt"));
      if (invalid(transactionId, nationId, amount, category, appliedAt)) continue;
      receipts.put(
          transactionId,
          new NationCreditService.CreditReceipt(
              transactionId,
              nationId,
              amount,
              category,
              properties.getProperty(prefix + "description", ""),
              appliedAt));
    }
    return receipts;
  }

  private static Map<String, NationTransferService.TransferReceipt> readTransferReceipts(
      Properties properties) {
    int count = parseInt(properties.getProperty("transfer.count"), 0);
    Map<String, NationTransferService.TransferReceipt> receipts = new LinkedHashMap<>();
    for (int index = 0; index < count; index++) {
      String prefix = "transfer." + index + '.';
      String transactionId = properties.getProperty(prefix + "transactionId");
      NationId payerId = parseNationId(properties.getProperty(prefix + "payerId"));
      NationId receiverId = parseNationId(properties.getProperty(prefix + "receiverId"));
      BigDecimal amount = parseAmount(properties.getProperty(prefix + "amount"));
      NationTransferService.TransferCategory category =
          parseTransferCategory(properties.getProperty(prefix + "category"));
      Instant appliedAt = parseInstant(properties.getProperty(prefix + "appliedAt"));
      if (transactionId == null
          || transactionId.isBlank()
          || payerId == null
          || receiverId == null
          || payerId.equals(receiverId)
          || amount == null
          || amount.signum() <= 0
          || category == null
          || appliedAt == null) continue;
      receipts.put(
          transactionId,
          new NationTransferService.TransferReceipt(
              transactionId,
              payerId,
              receiverId,
              amount,
              category,
              properties.getProperty(prefix + "description", ""),
              appliedAt));
    }
    return receipts;
  }

  private static boolean invalid(
      String transactionId,
      NationId nationId,
      BigDecimal amount,
      Object category,
      Instant appliedAt) {
    return transactionId == null
        || transactionId.isBlank()
        || nationId == null
        || amount == null
        || amount.signum() <= 0
        || category == null
        || appliedAt == null;
  }

  private static BigDecimal normalize(BigDecimal amount) {
    return amount.setScale(SCALE, RoundingMode.DOWN);
  }

  private static NationId parseNationId(String value) {
    if (value == null) return null;
    try {
      return new NationId(UUID.fromString(value));
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static BigDecimal parseAmount(String value) {
    if (value == null) return null;
    try {
      return normalize(new BigDecimal(value));
    } catch (NumberFormatException exception) {
      LOGGER.log(
          Level.WARNING,
          "Treasury state amount ignored code=TREASURY_STATE_AMOUNT_FAILURE",
          exception);
      return null;
    }
  }

  private static Instant parseInstant(String value) {
    if (value == null) return null;
    try {
      return Instant.ofEpochMilli(Long.parseLong(value));
    } catch (NumberFormatException exception) {
      return null;
    }
  }

  private static NationSpendingService.SpendingCategory parseSpendingCategory(String value) {
    try {
      return value == null ? null : NationSpendingService.SpendingCategory.valueOf(value);
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static NationCreditService.CreditCategory parseCreditCategory(String value) {
    try {
      return value == null ? null : NationCreditService.CreditCategory.valueOf(value);
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static NationTransferService.TransferCategory parseTransferCategory(String value) {
    try {
      return value == null ? null : NationTransferService.TransferCategory.valueOf(value);
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static int parseInt(String value, int fallback) {
    if (value == null) return fallback;
    try {
      return Integer.parseInt(value);
    } catch (NumberFormatException exception) {
      return fallback;
    }
  }
}
