package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** 财政服务接口 整合国库、税收、贷款、破产、预算的统一财政管理系统 */
public interface TreasuryService {

  /**
   * Stable identity of this persisted treasury data domain.
   *
   * <p>A missing value means that the backing state predates the authority-domain marker or could
   * not be loaded safely. Integrations that attribute durable receipts must fail closed when this
   * method returns {@code null}.
   */
  default String authorityDomainId() {
    return null;
  }

  // ==================== 基础操作 (原 TreasuryModule) ====================

  /** 获取国家国库余额 */
  BigDecimal balance(NationId nationId);

  /** 存入国库 */
  void deposit(NationId nationId, BigDecimal amount);

  /** 存入国库（带描述） */
  default void deposit(NationId nationId, BigDecimal amount, String description) {
    deposit(nationId, amount);
  }

  /**
   * 尝试将完整金额存入国库。
   *
   * <p>返回 {@code true} 仅表示完整金额已经被接受；实现不得以部分入账返回成功。 默认实现保持旧实现兼容：调用 {@link #deposit(NationId,
   * BigDecimal)}，未抛异常即视为成功。
   *
   * <p>The native implementation persists an internal credit ID. An uncertain result throws {@link
   * TreasuryTransactionUncertainException}; do not retry or compensate under a new ID.
   */
  default boolean tryDeposit(NationId nationId, BigDecimal amount) {
    deposit(nationId, amount);
    return true;
  }

  /**
   * 从国库取出（仅当余额充足且持久化成功时）
   *
   * @return 是否成功
   * @throws TreasuryTransactionUncertainException if the native commit cannot be reconciled; its
   *     transaction ID must be reconciled before retry or compensation
   */
  boolean withdraw(NationId nationId, BigDecimal amount);

  /** 在两个国家国库之间转账。接收方未完整入账时必须补偿付款方； 补偿失败属于严重一致性故障并抛出异常，禁止静默返回。 */
  default boolean transfer(NationId from, NationId to, BigDecimal amount) {
    if (from == null || to == null || amount == null || amount.signum() <= 0 || from.equals(to)) {
      return false;
    }
    if (!withdraw(from, amount)) {
      return false;
    }

    RuntimeException receiverFailure = null;
    try {
      if (tryDeposit(to, amount)) {
        return true;
      }
    } catch (RuntimeException failure) {
      receiverFailure = failure;
    }

    try {
      if (!tryDeposit(from, amount)) {
        throw new IllegalStateException("Treasury transfer compensation was rejected");
      }
    } catch (RuntimeException refundFailure) {
      IllegalStateException criticalFailure =
          new IllegalStateException(
              "Treasury transfer compensation failed after receiver credit failure", refundFailure);
      if (receiverFailure != null) {
        criticalFailure.addSuppressed(receiverFailure);
      }
      throw criticalFailure;
    }
    return false;
  }

  /** 获取服务摘要 */
  String summary();

  // ==================== 税收操作 (TaxationService) ====================

  /** 获取国家所有税种配置 */
  Map<TaxationService.TaxType, TaxationService.TaxConfig> getTaxConfigs(NationId nationId);

  /** 获取特定税种配置 */
  TaxationService.TaxConfig getTaxConfig(NationId nationId, TaxationService.TaxType type);

  /** 设置税种配置 */
  void setTaxConfig(
      NationId nationId, TaxationService.TaxType type, TaxationService.TaxConfig config);

  /** 征收指定税种 */
  BigDecimal collectTax(
      NationId nationId, TaxationService.TaxType type, TaxationService.TaxContext context);

  /** 征收所有启用税种 */
  Map<TaxationService.TaxType, BigDecimal> collectAllTaxes(
      NationId nationId, TaxationService.TaxContext context);

  /** 获取税收历史 */
  List<TaxationService.TaxRevenue> getTaxHistory(
      NationId nationId, TaxationService.TaxType type, int limit);

  // ==================== 贷款/国债操作 (LoanService) ====================

  /** 申请贷款 */
  LoanService.NationDebt applyForLoan(
      NationId nationId,
      NationId creditorId,
      BigDecimal principal,
      BigDecimal annualInterestRate,
      int totalInstallments);

  /** 偿还债务 */
  boolean repayDebt(UUID debtId, BigDecimal amount);

  /** 偿还分期 */
  boolean payInstallment(UUID debtId);

  /** 免除债务 */
  boolean forgiveDebt(UUID debtId);

  /** 获取债务记录 */
  Optional<LoanService.NationDebt> getDebt(UUID debtId);

  /** 获取国家所有债务 */
  List<LoanService.NationDebt> getDebtsByNation(NationId nationId);

  /** 获取国家有效债务 */
  List<LoanService.NationDebt> getActiveDebts(NationId nationId);

  /** 获取国家总债务 */
  BigDecimal getTotalDebt(NationId nationId);

  /** 检查是否可以借款 */
  boolean canBorrow(NationId nationId, BigDecimal amount);

  /** 获取最大可借额度 */
  BigDecimal getMaxBorrowableAmount(NationId nationId);

  /** 获取债务健康度（0-100） */
  int getDebtHealthScore(NationId nationId);

  // ==================== 破产操作 (BankruptcyService) ====================

  /**
   * 进入破产状态（推荐使用带显式原因的版本）
   *
   * @deprecated Use {@link #enterBankruptcy(NationId, BankruptcyService.BankruptcyReason, String)}
   *     instead
   */
  @Deprecated
  void enterBankruptcy(NationId nationId, String reason);

  /** 进入破产状态 */
  void enterBankruptcy(
      NationId nationId, BankruptcyService.BankruptcyReason reason, String description);

  /** 退出破产状态 */
  boolean exitBankruptcy(NationId nationId);

  /** 检查破产状态 */
  boolean isBankrupt(NationId nationId);

  /** 获取破产记录 */
  Optional<BankruptcyService.BankruptcyRecord> getBankruptcyRecord(NationId nationId);

  /** 获取破产天数 */
  long getBankruptcyDays(NationId nationId);

  /** 检查功能是否受限 */
  boolean isRestricted(NationId nationId, BankruptcyService.Restriction restriction);

  /** 获取所有受限功能 */
  List<BankruptcyService.Restriction> getActiveRestrictions(NationId nationId);

  /** 提前解除破产 */
  boolean earlyExitBankruptcy(NationId nationId);

  /** 获取所有破产国家 */
  List<NationId> getAllBankruptNations();

  // ==================== 预算操作 (BudgetService) ====================

  /** 创建预算草案 */
  BudgetService.BudgetBill createBudgetDraft(NationId nationId, int year, int month);

  /** 添加预算条目 */
  void addBudgetEntry(
      UUID billId, BudgetService.BudgetCategory category, String description, BigDecimal amount);

  /** 提交预算 */
  BudgetService.BudgetBill submitBudget(UUID billId);

  /** 执行预算 */
  boolean executeBudget(UUID billId);

  /** 取消预算 */
  boolean cancelBudget(UUID billId);

  /** 获取当前预算 */
  Optional<BudgetService.BudgetBill> getCurrentBudget(NationId nationId);

  /** 获取预算历史 */
  List<BudgetService.BudgetBill> getBudgetHistory(NationId nationId, int limit);

  /** 获取预算执行报告 */
  BudgetService.BudgetExecutionReport getBudgetExecutionReport(UUID billId);

  /** 获取月度支出 */
  BigDecimal getMonthlySpending(NationId nationId, int year, int month);

  /** 获取年度支出 */
  BigDecimal getYearlySpending(NationId nationId, int year);

  // ==================== 综合状态查询 ====================

  /** 财政健康报告 */
  record FinanceHealthReport(
      NationId nationId,
      BigDecimal balance,
      BigDecimal totalDebt,
      BigDecimal maxDebtLimit,
      int debtHealthScore,
      boolean isBankrupt,
      List<BankruptcyService.Restriction> activeRestrictions,
      List<TaxationService.TaxType> enabledTaxTypes,
      BigDecimal monthlyIncome,
      BigDecimal monthlyExpense,
      Instant generatedAt) {}

  /** 获取财政健康报告 */
  FinanceHealthReport getFinanceHealthReport(NationId nationId);

  /**
   * 获取今日收入（从事件日志计算的真实数据）
   *
   * @param nationId 国家ID
   * @return 今日总收入
   */
  BigDecimal getTodayIncome(NationId nationId);

  /**
   * 获取今日支出（从事件日志计算的真实数据）
   *
   * @param nationId 国家ID
   * @return 今日总支出
   */
  BigDecimal getTodayExpense(NationId nationId);

  /**
   * 获取国库余额排行前 N 的国家
   *
   * @param limit 数量上限
   * @return 按余额降序的国家 ID 列表
   */
  default List<NationId> getTopTreasuryNations(int limit) {
    return List.of();
  }
}
