package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/** Idempotent atomic transfer boundary for moving money between national treasuries. */
public interface NationTransferService {

  enum TransferCategory {
    REPARATION,
    TRIBUTE,
    TREATY,
    LOAN,
    OTHER
  }

  enum TransferStatus {
    APPLIED,
    ALREADY_APPLIED,
    INSUFFICIENT_FUNDS,
    REJECTED;

    public EconomyTransactionState economyState() {
      return switch (this) {
        case APPLIED, ALREADY_APPLIED -> EconomyTransactionState.COMMITTED;
        case INSUFFICIENT_FUNDS -> EconomyTransactionState.DEBIT_FAILED;
        case REJECTED -> EconomyTransactionState.CANCELLED;
      };
    }
  }

  record TransferRequest(
      String transactionId,
      NationId payerId,
      NationId receiverId,
      BigDecimal amount,
      TransferCategory category,
      String description) {
    public TransferRequest {
      transactionId = requireTransactionId(transactionId);
      payerId = Objects.requireNonNull(payerId, "payerId");
      receiverId = Objects.requireNonNull(receiverId, "receiverId");
      if (payerId.equals(receiverId)) {
        throw new IllegalArgumentException("payerId and receiverId must differ");
      }
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
    }
  }

  record TransferReceipt(
      String transactionId,
      NationId payerId,
      NationId receiverId,
      BigDecimal amount,
      TransferCategory category,
      String description,
      Instant appliedAt) {
    public TransferReceipt {
      transactionId = requireTransactionId(transactionId);
      payerId = Objects.requireNonNull(payerId, "payerId");
      receiverId = Objects.requireNonNull(receiverId, "receiverId");
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
      appliedAt = Objects.requireNonNull(appliedAt, "appliedAt");
    }

    boolean matches(TransferRequest request) {
      return payerId.equals(request.payerId())
          && receiverId.equals(request.receiverId())
          && amount.compareTo(request.amount()) == 0
          && category == request.category();
    }
  }

  record TransferResult(
      TransferStatus status,
      String transactionId,
      BigDecimal payerBalanceAfter,
      BigDecimal receiverBalanceAfter) {
    public boolean applied() {
      return status == TransferStatus.APPLIED || status == TransferStatus.ALREADY_APPLIED;
    }
  }

  /**
   * Applies or reconciles the original ID. Native persistence errors with no readable canonical
   * result throw {@link TreasuryTransactionUncertainException}; callers must not compensate or
   * assign another ID until reconciliation. A confirmed matching receipt returns ALREADY_APPLIED.
   */
  TransferResult transfer(TransferRequest request);

  /**
   * Returns a committed local snapshot. Native reads wait for an in-flight save and reconciliation,
   * and throw while the module is quarantined. Absence is not proof of authority availability;
   * durable integrations also require a valid {@link TreasuryService#authorityDomainId()}.
   */
  Optional<TransferReceipt> transferReceipt(String transactionId);

  default boolean hasTransferReceipt(String transactionId) {
    return transferReceipt(transactionId).isPresent();
  }

  private static String requireTransactionId(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      throw new IllegalArgumentException("transactionId must not be blank");
    }
    return transactionId;
  }

  private static BigDecimal requirePositive(BigDecimal amount) {
    if (amount == null || amount.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    BigDecimal normalized = amount.setScale(2, RoundingMode.DOWN);
    if (normalized.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    return normalized;
  }
}
