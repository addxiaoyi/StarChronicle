package dev.starcore.starcore.module.treasury;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HexFormat;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Supplier;
import javax.sql.DataSource;

/** Synchronous, fail-closed shared budgets; no independent file fallback in SQL mode. */
final class SqlBudgetStateStorage implements BudgetStateStorage {
  private static final String TABLE = "starcore_budget_state";
  private static final String REVISION = "__starcore_revision__";
  private static final String IMPORT = "__starcore_legacy_sha256__";
  private final Supplier<DataSource> dataSource;
  private final BudgetStateStorage legacy;
  private final BudgetStateCodec codec = new BudgetStateCodec();
  private long expectedRevision;
  private boolean loaded;

  SqlBudgetStateStorage(Supplier<DataSource> dataSource, BudgetStateStorage legacy) {
    this.dataSource = java.util.Objects.requireNonNull(dataSource);
    this.legacy = java.util.Objects.requireNonNull(legacy);
  }

  @Override
  public synchronized Properties load() {
    try (Connection connection = dataSource.get().getConnection()) {
      String product = connection.getMetaData().getDatabaseProductName();
      boolean mysql = "MySQL".equals(product) || "MariaDB".equals(product);
      try (var statement = connection.createStatement()) {
        statement.execute(
            "CREATE TABLE IF NOT EXISTS "
                + TABLE
                + " (property_key VARCHAR(191) PRIMARY KEY, property_value TEXT NOT NULL)"
                + (mysql ? " ENGINE=InnoDB" : ""));
      }
      if (mysql) {
        try (var statement =
            connection.prepareStatement(
                "SELECT ENGINE FROM information_schema.tables WHERE table_schema = DATABASE() AND"
                    + " table_name = ?")) {
          statement.setString(1, TABLE);
          try (var rows = statement.executeQuery()) {
            if (!rows.next() || !"InnoDB".equalsIgnoreCase(rows.getString(1))) {
              throw new SQLException("Shared budgets require an InnoDB table");
            }
          }
        }
      }
      Properties local = canonical(legacy.load());
      String fingerprint = hasState(local) ? fingerprint(local) : "";
      Snapshot shared = read(connection);
      if (shared.revision() == 0) {
        expectedRevision = 0;
        try {
          write(connection, local, fingerprint);
        } catch (BudgetStateConflictException concurrentInitialization) {
          // A racing initializer may only win with a compatible legacy file.
        }
        shared = read(connection);
      }
      if (!fingerprint.isEmpty() && !fingerprint.equals(shared.legacyFingerprint())) {
        throw new IllegalStateException(
            "Conflicting legacy budgets.properties; reconcile before enabling this instance");
      }
      Properties validated = canonical(shared.properties());
      expectedRevision = shared.revision();
      loaded = true;
      return validated;
    } catch (BudgetStateReconciliationException failure) {
      throw failure;
    } catch (Exception failure) {
      throw new IllegalStateException("Budget SQL state load failed", failure);
    }
  }

  @Override
  public synchronized Optional<BudgetStateRefresh> refreshIfChanged() {
    requireLoaded();
    try (Connection connection = dataSource.get().getConnection()) {
      try (var statement =
          connection.prepareStatement(
              "SELECT property_value FROM " + TABLE + " WHERE property_key = ?")) {
        statement.setString(1, REVISION);
        try (var rows = statement.executeQuery()) {
          if (rows.next() && Long.toString(expectedRevision).equals(rows.getString(1)))
            return Optional.empty();
        }
      }
      Snapshot snapshot = read(connection);
      if (snapshot.revision() < expectedRevision) {
        throw new SQLException("Budget SQL revision moved backwards or disappeared");
      }
      return snapshot.revision() == expectedRevision
          ? Optional.empty()
          : Optional.of(new BudgetStateRefresh(snapshot.properties(), snapshot.revision()));
    } catch (Exception failure) {
      throw new IllegalStateException("Budget SQL state refresh failed", failure);
    }
  }

  @Override
  public synchronized void acceptRefresh(BudgetStateRefresh refresh) {
    if (refresh.revision() < expectedRevision) {
      throw new IllegalStateException("Cannot adopt an older budget revision");
    }
    expectedRevision = refresh.revision();
  }

  @Override
  public synchronized void save(Properties properties) {
    requireLoaded();
    Properties validated = canonical(properties);
    Connection connection = null;
    boolean written = false;
    try {
      connection = dataSource.get().getConnection();
      write(connection, validated, null);
      written = true;
    } catch (BudgetStateConflictException | BudgetStateReconciliationException failure) {
      throw failure;
    } catch (Exception failure) {
      throw new IllegalStateException("Budget SQL state write failed", failure);
    } finally {
      if (connection != null) {
        try {
          connection.close();
        } catch (SQLException closeFailure) {
          // A release error after acknowledged commit must never cause a financial compensation.
          if (!written) throw new BudgetStateReconciliationException(closeFailure);
        }
      }
    }
  }

  private void write(Connection connection, Properties properties, String legacyFingerprint)
      throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    boolean commitAttempted = false;
    boolean committed = false;
    connection.setAutoCommit(false);
    try {
      long next = Math.addExact(expectedRevision, 1);
      if (expectedRevision == 0) {
        try (var statement =
            connection.prepareStatement(
                "INSERT INTO " + TABLE + " (property_key, property_value) VALUES (?, ?)")) {
          statement.setString(1, REVISION);
          statement.setString(2, Long.toString(next));
          statement.executeUpdate();
        }
      } else {
        try (var statement =
            connection.prepareStatement(
                "UPDATE "
                    + TABLE
                    + " SET property_value = ? WHERE property_key = ? AND property_value = ?")) {
          statement.setString(1, Long.toString(next));
          statement.setString(2, REVISION);
          statement.setString(3, Long.toString(expectedRevision));
          if (statement.executeUpdate() != 1) {
            throw new BudgetStateConflictException(new SQLException("Budget revision changed"));
          }
        }
      }
      try (var statement =
          connection.prepareStatement(
              "DELETE FROM " + TABLE + " WHERE property_key <> ? AND property_key <> ?")) {
        statement.setString(1, REVISION);
        statement.setString(2, IMPORT);
        statement.executeUpdate();
      }
      try (var statement =
          connection.prepareStatement(
              "INSERT INTO " + TABLE + " (property_key, property_value) VALUES (?, ?)")) {
        for (String key : properties.stringPropertyNames()) {
          statement.setString(1, key);
          statement.setString(2, properties.getProperty(key));
          statement.addBatch();
        }
        if (legacyFingerprint != null) {
          statement.setString(1, IMPORT);
          statement.setString(2, legacyFingerprint);
          statement.addBatch();
        }
        statement.executeBatch();
      }
      commitAttempted = true;
      connection.commit();
      committed = true;
      expectedRevision = next;
    } catch (Exception failure) {
      try {
        connection.rollback();
      } catch (SQLException rollbackFailure) {
        failure.addSuppressed(rollbackFailure);
      }
      if (commitAttempted) throw new BudgetStateReconciliationException(failure);
      if (failure instanceof BudgetStateConflictException conflict) throw conflict;
      if (failure instanceof SQLException sql
          && (SqlTreasuryStateStorage.isConcurrentWriteConflict(sql)
              || sql.getErrorCode() == 1062
              || "23505".equals(sql.getSQLState())
              || (sql.getErrorCode() & 0xff) == 19)) {
        throw new BudgetStateConflictException(failure);
      }
      throw failure;
    } finally {
      try {
        connection.setAutoCommit(previousAutoCommit);
      } catch (SQLException resetFailure) {
        if (committed) throw new BudgetStateReconciliationException(resetFailure);
        throw resetFailure;
      }
    }
  }

  private Snapshot read(Connection connection) throws SQLException {
    Properties result = new Properties();
    long revision = 0;
    String imported = "";
    boolean hasRows = false;
    try (PreparedStatement statement =
            connection.prepareStatement(
                "SELECT property_key, property_value FROM " + TABLE + " ORDER BY property_key");
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        hasRows = true;
        String key = rows.getString(1), value = rows.getString(2);
        if (REVISION.equals(key)) {
          try {
            revision = Long.parseLong(value);
            if (revision < 1) throw new NumberFormatException("nonpositive revision");
          } catch (NumberFormatException failure) {
            throw new SQLException("Invalid budget revision", failure);
          }
        } else if (IMPORT.equals(key)) {
          imported = value;
        } else {
          result.setProperty(key, value);
        }
      }
    }
    if (revision == 0 && hasRows) throw new SQLException("Budget revision is missing");
    if (revision > 0
        && !result
            .stringPropertyNames()
            .containsAll(
                java.util.Set.of(
                    "schema.version", "budget.count", "current.count", "spending.count"))) {
      throw new SQLException("Budget SQL snapshot header is incomplete");
    }
    return new Snapshot(result, revision, imported);
  }

  private Properties canonical(Properties properties) {
    return codec.toProperties(codec.fromProperties(properties));
  }

  private boolean hasState(Properties properties) {
    BudgetStateSnapshot state = codec.fromProperties(properties);
    return !state.budgets().isEmpty()
        || !state.currentBudgets().isEmpty()
        || !state.receipts().isEmpty();
  }

  private static String fingerprint(Properties properties) throws Exception {
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    for (String key : properties.stringPropertyNames().stream().sorted().toList()) {
      for (String value : new String[] {key, properties.getProperty(key)}) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        digest.update(java.nio.ByteBuffer.allocate(4).putInt(bytes.length).array());
        digest.update(bytes);
      }
    }
    return HexFormat.of().formatHex(digest.digest());
  }

  private void requireLoaded() {
    if (!loaded) throw new IllegalStateException("Budget SQL state must be loaded first");
  }

  private record Snapshot(Properties properties, long revision, String legacyFingerprint) {}
}
