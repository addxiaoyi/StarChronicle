package dev.starcore.starcore.module.treasury;

import java.time.Duration;
import java.time.Instant;

final class TaxCollectionWindow {

    private final Instant lastCollectedAt;
    private final Duration interval;
    private final Instant now;

    TaxCollectionWindow(Instant lastCollectedAt, long intervalMinutes, Instant now) {
        if (intervalMinutes <= 0) {
            throw new IllegalArgumentException("intervalMinutes must be positive");
        }
        this.lastCollectedAt = lastCollectedAt;
        this.interval = Duration.ofMinutes(intervalMinutes);
        this.now = now;
    }

    boolean isDue() {
        return lastCollectedAt == null || !lastCollectedAt.plus(interval).isAfter(now);
    }

    Duration period(Duration bootstrapPeriod) {
        return lastCollectedAt == null
            ? bootstrapPeriod
            : Duration.between(lastCollectedAt, now);
    }
}
