package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.foundation.economy.EconomyService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

final class TaxFunding {
  private static final int SCALE = 2;
  private final EconomyService economy;

  TaxFunding(EconomyService economy) {
    this.economy = Objects.requireNonNull(economy, "economy");
  }

  Result collect(List<Charge> charges) {
    Objects.requireNonNull(charges, "charges");
    BigDecimal collected = BigDecimal.ZERO;
    List<UUID> failed = new ArrayList<>();
    List<Charge> funded = new ArrayList<>();
    for (Charge charge : charges) {
      if (charge.amount().signum() == 0) {
        continue;
      }
      boolean withdrawn;
      try {
        withdrawn = economy.withdraw(charge.playerId(), charge.amount());
      } catch (RuntimeException exception) {
        withdrawn = false;
      }
      if (withdrawn) {
        collected = collected.add(charge.amount());
        funded.add(charge);
      } else {
        failed.add(charge.playerId());
      }
    }
    return new Result(
        collected.setScale(SCALE, RoundingMode.DOWN), List.copyOf(failed), List.copyOf(funded));
  }

  RefundResult refund(Result result) {
    Objects.requireNonNull(result, "result");
    List<Charge> failedRefunds = new ArrayList<>();
    for (Charge charge : result.fundedCharges()) {
      boolean refunded;
      try {
        refunded = economy.deposit(charge.playerId(), charge.amount());
      } catch (RuntimeException exception) {
        refunded = false;
      }
      if (!refunded) {
        failedRefunds.add(charge);
      }
    }
    return new RefundResult(List.copyOf(failedRefunds));
  }

  record Charge(UUID playerId, BigDecimal amount) {
    Charge {
      Objects.requireNonNull(playerId, "playerId");
      Objects.requireNonNull(amount, "amount");
      if (amount.signum() < 0) {
        throw new IllegalArgumentException("Tax charge cannot be negative");
      }
      amount = amount.setScale(SCALE, RoundingMode.DOWN);
    }
  }

  record Result(BigDecimal collected, List<UUID> failedPayers, List<Charge> fundedCharges) {
    Result {
      Objects.requireNonNull(collected, "collected");
      failedPayers = List.copyOf(failedPayers);
      fundedCharges = List.copyOf(fundedCharges);
    }
  }

  record RefundResult(List<Charge> failedRefunds) {
    RefundResult {
      failedRefunds = List.copyOf(failedRefunds);
    }

    boolean complete() {
      return failedRefunds.isEmpty();
    }
  }
}
