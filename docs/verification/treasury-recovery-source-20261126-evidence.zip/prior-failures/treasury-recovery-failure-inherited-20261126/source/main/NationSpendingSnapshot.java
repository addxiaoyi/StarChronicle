package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Read-only diagnostic projection of one nation's funded budget and actual spending. */
public record NationSpendingSnapshot(
    NationId nationId,
    UUID activeBudgetId,
    Map<BudgetCategory, BigDecimal> allocatedByCategory,
    Map<BudgetCategory, BigDecimal> budgetSpentByCategory,
    Map<BudgetCategory, BigDecimal> budgetRemainingByCategory,
    Map<BudgetCategory, BigDecimal> treasuryFallbackByCategory,
    long committedTransactions,
    long refundedTransactions) {
  private static final int SCALE = 2;

  public NationSpendingSnapshot {
    nationId = Objects.requireNonNull(nationId, "nationId");
    allocatedByCategory = immutableMoneyMap(allocatedByCategory);
    budgetSpentByCategory = immutableMoneyMap(budgetSpentByCategory);
    budgetRemainingByCategory = immutableMoneyMap(budgetRemainingByCategory);
    treasuryFallbackByCategory = immutableMoneyMap(treasuryFallbackByCategory);
    if (committedTransactions < 0 || refundedTransactions < 0) {
      throw new IllegalArgumentException("transaction counts must be non-negative");
    }
  }

  public BigDecimal allocated(BudgetCategory category) {
    return allocatedByCategory.getOrDefault(category, zero());
  }

  public BigDecimal budgetSpent(BudgetCategory category) {
    return budgetSpentByCategory.getOrDefault(category, zero());
  }

  public BigDecimal budgetRemaining(BudgetCategory category) {
    return budgetRemainingByCategory.getOrDefault(category, zero());
  }

  public BigDecimal treasuryFallback(BudgetCategory category) {
    return treasuryFallbackByCategory.getOrDefault(category, zero());
  }

  public static NationSpendingSnapshot empty(NationId nationId) {
    return new NationSpendingSnapshot(
        nationId, null, Map.of(), Map.of(), Map.of(), Map.of(), 0L, 0L);
  }

  private static Map<BudgetCategory, BigDecimal> immutableMoneyMap(
      Map<BudgetCategory, BigDecimal> source) {
    EnumMap<BudgetCategory, BigDecimal> copy = new EnumMap<>(BudgetCategory.class);
    if (source != null) {
      source.forEach(
          (category, amount) -> {
            Objects.requireNonNull(category, "category");
            Objects.requireNonNull(amount, "amount");
            BigDecimal normalized = amount.setScale(SCALE, RoundingMode.DOWN);
            if (normalized.signum() < 0) {
              throw new IllegalArgumentException("snapshot amounts must be non-negative");
            }
            copy.put(category, normalized);
          });
    }
    return Collections.unmodifiableMap(copy);
  }

  private static BigDecimal zero() {
    return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
  }
}
