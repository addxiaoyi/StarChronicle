package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/** Classified and idempotent national spending boundary. */
public interface NationSpendingService {

  enum SpendingCategory {
    TERRITORY_RENT,
    TERRITORY_LEASE_FEE,
    RESEARCH,
    MILITARY,
    TREATY,
    NATIONAL_EVENT,
    OTHER
  }

  enum SpendingStatus {
    APPLIED,
    ALREADY_APPLIED,
    INSUFFICIENT_FUNDS,
    REJECTED
  }

  record SpendRequest(
      String transactionId,
      NationId nationId,
      BigDecimal amount,
      SpendingCategory category,
      String description) {
    public SpendRequest {
      transactionId = requireTransactionId(transactionId);
      nationId = Objects.requireNonNull(nationId, "nationId");
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
    }
  }

  record SpendingReceipt(
      String transactionId,
      NationId nationId,
      BigDecimal amount,
      SpendingCategory category,
      String description,
      Instant appliedAt,
      boolean refunded) {
    public SpendingReceipt {
      transactionId = requireTransactionId(transactionId);
      nationId = Objects.requireNonNull(nationId, "nationId");
      amount = requirePositive(amount);
      category = Objects.requireNonNull(category, "category");
      description = description == null ? "" : description;
      appliedAt = Objects.requireNonNull(appliedAt, "appliedAt");
    }

    public SpendingReceipt(
        String transactionId,
        NationId nationId,
        BigDecimal amount,
        SpendingCategory category,
        String description,
        Instant appliedAt) {
      this(transactionId, nationId, amount, category, description, appliedAt, false);
    }

    boolean matches(SpendRequest request) {
      return !refunded
          && nationId.equals(request.nationId())
          && amount.compareTo(request.amount()) == 0
          && category == request.category();
    }
  }

  record SpendResult(SpendingStatus status, String transactionId, BigDecimal balanceAfter) {
    public boolean applied() {
      return status == SpendingStatus.APPLIED || status == SpendingStatus.ALREADY_APPLIED;
    }
  }

  /** Unresolved native persistence errors throw; reconcile this ID before retry or compensation. */
  SpendResult spend(SpendRequest request);

  /** Native reads wait for commit/reconciliation and throw while the module is quarantined. */
  Optional<SpendingReceipt> spendingReceipt(String transactionId);

  default boolean hasSpendingReceipt(String transactionId) {
    return spendingReceipt(transactionId).isPresent();
  }

  /**
   * Refund a previous spending transaction
   *
   * @param transactionId the transaction ID to refund
   * @return true if refund was successful, false otherwise
   */
  default boolean refund(java.util.UUID transactionId) {
    return refund(transactionId.toString());
  }

  /**
   * Refund a previous spending transaction
   *
   * @param transactionId the transaction ID to refund
   * @return true if refund was successful, false otherwise
   */
  default boolean refund(String transactionId) {
    // Default implementation returns false - subclasses should override
    return false;
  }

  /**
   * Get spending snapshot for a nation
   *
   * @param nationId the nation ID
   * @return optional spending snapshot
   */
  default Optional<SpendingSnapshot> spendingSnapshot(NationId nationId) {
    // Default implementation returns empty - subclasses should override
    return Optional.empty();
  }

  record SpendingSnapshot(
      NationId nationId,
      BigDecimal totalBudget,
      BigDecimal spent,
      BigDecimal remaining,
      Instant snapshotTime) {}

  private static String requireTransactionId(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      throw new IllegalArgumentException("transactionId must not be blank");
    }
    return transactionId;
  }

  private static BigDecimal requirePositive(BigDecimal amount) {
    if (amount == null || amount.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    BigDecimal normalized = amount.setScale(2, RoundingMode.DOWN);
    if (normalized.signum() <= 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
    return normalized;
  }
}
