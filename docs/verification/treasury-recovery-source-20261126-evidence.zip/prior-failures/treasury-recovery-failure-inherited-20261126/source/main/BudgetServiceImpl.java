package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetBill;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetConfig;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetEntry;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetExecutionReport;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

/** Owns funded national budgets and idempotent budget-first spending receipts. */
public final class BudgetServiceImpl
    implements StarCoreModule, BudgetService, NationSpendingService {
  private static final int SCALE = 2;
  private static final String STORAGE_NAMESPACE = "treasury";

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "budget",
          "预算管理系统",
          ModuleLayer.MODULE,
          List.of("nation", "treasury"),
          List.of(BudgetService.class, NationSpendingService.class),
          "Provides persistent funded budgets and budget-first national spending.");

  private final Object stateLock = new Object();
  private final Map<UUID, BudgetBill> budgets = new LinkedHashMap<>();
  private final Map<NationId, UUID> currentBudgets = new LinkedHashMap<>();
  private final Map<UUID, NationSpendingReceipt> receipts = new LinkedHashMap<>();
  private final BudgetStateCodec stateCodec = new BudgetStateCodec();
  private final Clock clock;

  private volatile BudgetConfig budgetConfig = BudgetConfig.defaults();
  private BudgetStateStorage stateStorage;
  private TreasuryService treasuryService;
  private NationCreditService nationCreditService;
  private BukkitTask monthlyResetTask;
  private StarCoreContext currentContext;
  private boolean stateLoaded;
  private boolean reconciliationRequired;

  public BudgetServiceImpl() {
    this(null, null, Clock.systemDefaultZone());
  }

  BudgetServiceImpl(BudgetStateStorage stateStorage, TreasuryService treasuryService, Clock clock) {
    this(stateStorage, treasuryService, null, clock);
  }

  BudgetServiceImpl(
      BudgetStateStorage stateStorage,
      TreasuryService treasuryService,
      NationCreditService nationCreditService,
      Clock clock) {
    this.stateStorage = stateStorage;
    this.treasuryService = treasuryService;
    this.nationCreditService = nationCreditService;
    this.clock = Objects.requireNonNull(clock, "clock");
    if (stateStorage != null) {
      loadState();
    }
  }

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  @Override
  public void enable(StarCoreContext context) {
    this.currentContext = Objects.requireNonNull(context, "context");
    this.treasuryService = context.serviceRegistry().require(TreasuryService.class);
    this.nationCreditService = context.serviceRegistry().require(NationCreditService.class);
    if (stateStorage == null) {
      context.persistenceService().ensureNamespace(STORAGE_NAMESPACE).join();
      stateStorage =
          new PersistenceBudgetStateStorage(STORAGE_NAMESPACE, context.persistenceService());
      if (context.databaseService().isRunning()) {
        stateStorage =
            new SqlBudgetStateStorage(
                () ->
                    context
                        .databaseService()
                        .dataSource()
                        .orElseThrow(
                            () ->
                                new IllegalStateException("Budget SQL DataSource is unavailable")),
                stateStorage);
      }
    }
    loadState();
    startMonthlyResetTask(context);
  }

  @Override
  public void disable(StarCoreContext context) {
    stopMonthlyResetTask();
    // Every mutation is persisted synchronously; shutdown must not rewrite an idle SQL snapshot.
    currentContext = null;
  }

  @Override
  public BudgetBill createBudgetDraft(NationId nationId, int year, int month) {
    Objects.requireNonNull(nationId, "nationId");
    if (month < 1 || month > 12) {
      throw new IllegalArgumentException("month must be between 1 and 12");
    }
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill existing = currentBudgetLocked(nationId).orElse(null);
      if (existing != null && existing.year() == year && existing.month() == month) {
        return existing;
      }
      return persistMutationLocked(
          () -> {
            UUID billId = UUID.randomUUID();
            BudgetBill draft =
                new BudgetBill(
                    billId,
                    nationId,
                    year,
                    month,
                    List.of(),
                    zero(),
                    BudgetBill.BudgetStatus.DRAFT,
                    null,
                    null);
            budgets.put(billId, draft);
            currentBudgets.put(nationId, billId);
            return draft;
          });
    }
  }

  @Override
  public void addBudgetEntry(
      UUID billId, BudgetCategory category, String description, BigDecimal amount) {
    Objects.requireNonNull(billId, "billId");
    Objects.requireNonNull(category, "category");
    BigDecimal normalized = requirePositive(amount, "amount");
    synchronized (stateLock) {
      refreshStateLocked();
      persistMutationLocked(
          () -> {
            BudgetBill budget = requireBudgetLocked(billId);
            if (budget.status() != BudgetBill.BudgetStatus.DRAFT) {
              throw new IllegalStateException("Cannot modify non-draft budget");
            }
            List<BudgetEntry> newEntries = new ArrayList<>(budget.entries());
            newEntries.add(
                new BudgetEntry(
                    UUID.randomUUID(),
                    category,
                    description == null ? "" : description.trim(),
                    normalized,
                    clock.instant()));
            BigDecimal newTotal = normalize(budget.totalAmount().add(normalized));
            BigDecimal maxSingle = budgetConfig.maxSingleBudget();
            if (maxSingle != null
                && maxSingle.signum() > 0
                && newTotal.compareTo(normalize(maxSingle)) > 0) {
              throw new IllegalStateException("Budget exceeds maximum single budget limit");
            }
            budgets.put(
                billId,
                new BudgetBill(
                    budget.billId(),
                    budget.nationId(),
                    budget.year(),
                    budget.month(),
                    List.copyOf(newEntries),
                    newTotal,
                    budget.status(),
                    budget.approvedAt(),
                    budget.approvedBy()));
            return null;
          });
    }
  }

  @Override
  public BudgetBill submitBudget(UUID billId) {
    Objects.requireNonNull(billId, "billId");
    BudgetBill submitted;
    synchronized (stateLock) {
      refreshStateLocked();
      submitted =
          persistMutationLocked(
              () -> {
                BudgetBill budget = requireBudgetLocked(billId);
                if (budget.status() != BudgetBill.BudgetStatus.DRAFT) {
                  throw new IllegalStateException("Budget already submitted");
                }
                if (budget.totalAmount().signum() <= 0) {
                  throw new IllegalStateException("Budget has no entries");
                }
                boolean autoApprove = !budgetConfig.requireApproval();
                BudgetBill result =
                    new BudgetBill(
                        budget.billId(),
                        budget.nationId(),
                        budget.year(),
                        budget.month(),
                        budget.entries(),
                        budget.totalAmount(),
                        autoApprove
                            ? BudgetBill.BudgetStatus.APPROVED
                            : BudgetBill.BudgetStatus.PROPOSED,
                        autoApprove ? clock.instant() : null,
                        autoApprove ? "AUTO" : null);
                budgets.put(billId, result);
                return result;
              });
    }
    recordBudgetEvent(
        submitted.nationId(), "submitted", "amount=" + submitted.totalAmount().toPlainString());
    return submitted;
  }

  @Override
  public boolean approveBudget(UUID billId, String approvedBy) {
    Objects.requireNonNull(billId, "billId");
    String actor = approvedBy == null || approvedBy.isBlank() ? "SYSTEM" : approvedBy.trim();
    BudgetBill approved;
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill existing = budgets.get(billId);
      if (existing == null) {
        return false;
      }
      if (existing.status() == BudgetBill.BudgetStatus.APPROVED
          || existing.status() == BudgetBill.BudgetStatus.EXECUTED) {
        return true;
      }
      if (existing.status() != BudgetBill.BudgetStatus.PROPOSED) {
        return false;
      }
      approved =
          persistMutationLocked(
              () -> {
                BudgetBill budget = requireBudgetLocked(billId);
                BudgetBill result =
                    new BudgetBill(
                        budget.billId(),
                        budget.nationId(),
                        budget.year(),
                        budget.month(),
                        budget.entries(),
                        budget.totalAmount(),
                        BudgetBill.BudgetStatus.APPROVED,
                        clock.instant(),
                        actor);
                budgets.put(billId, result);
                return result;
              });
    }
    recordBudgetEvent(approved.nationId(), "approved", "actor=" + actor);
    return true;
  }

  @Override
  public boolean executeBudget(UUID billId) {
    Objects.requireNonNull(billId, "billId");
    BudgetBill executed;
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill budget = budgets.get(billId);
      if (budget == null) {
        return false;
      }
      if (budget.status() == BudgetBill.BudgetStatus.EXECUTED) {
        return true;
      }
      if (budget.status() != BudgetBill.BudgetStatus.APPROVED) {
        return false;
      }
      TreasuryService treasury = requireTreasuryService();
      if (!treasury.withdraw(budget.nationId(), budget.totalAmount())) {
        recordBudgetEvent(
            budget.nationId(),
            "insufficient-funds",
            "amount="
                + budget.totalAmount().toPlainString()
                + ";balance="
                + treasury.balance(budget.nationId()).toPlainString());
        return false;
      }

      BudgetStateSnapshot before = snapshotLocked();
      executed =
          new BudgetBill(
              budget.billId(),
              budget.nationId(),
              budget.year(),
              budget.month(),
              budget.entries(),
              budget.totalAmount(),
              BudgetBill.BudgetStatus.EXECUTED,
              budget.approvedAt() == null ? clock.instant() : budget.approvedAt(),
              budget.approvedBy() == null ? "SYSTEM" : budget.approvedBy());
      budgets.put(billId, executed);
      try {
        persistStateLocked();
      } catch (RuntimeException persistenceFailure) {
        restoreLocked(before);
        if (persistenceFailure instanceof BudgetStateReconciliationException)
          throw persistenceFailure;
        compensateTreasuryCredit(
            treasury,
            budget.nationId(),
            budget.totalAmount(),
            "Budget funding compensation failed",
            persistenceFailure);
        throw new IllegalStateException("Failed to persist funded budget", persistenceFailure);
      }
    }
    recordBudgetEvent(
        executed.nationId(), "funded", "amount=" + executed.totalAmount().toPlainString());
    return true;
  }

  @Override
  public boolean cancelBudget(UUID billId) {
    Objects.requireNonNull(billId, "billId");
    BudgetBill cancelled;
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill budget = budgets.get(billId);
      if (budget == null || budget.status() == BudgetBill.BudgetStatus.EXECUTED) {
        return false;
      }
      cancelled =
          persistMutationLocked(
              () -> {
                BudgetBill result =
                    new BudgetBill(
                        budget.billId(),
                        budget.nationId(),
                        budget.year(),
                        budget.month(),
                        budget.entries(),
                        budget.totalAmount(),
                        BudgetBill.BudgetStatus.CANCELLED,
                        budget.approvedAt(),
                        budget.approvedBy());
                budgets.put(billId, result);
                currentBudgets.remove(budget.nationId(), billId);
                return result;
              });
    }
    recordBudgetEvent(cancelled.nationId(), "cancelled", "billId=" + billId);
    return true;
  }

  // ==================== NationSpendingService 实现 ====================

  @Override
  public SpendResult spend(SpendRequest request) {
    Objects.requireNonNull(request, "request");
    UUID transactionId =
        UUID.nameUUIDFromBytes(
            request.transactionId().getBytes(java.nio.charset.StandardCharsets.UTF_8));
    BudgetCategory category = mapSpendingCategoryToBudgetCategory(request.category());

    Optional<SpendingMutation> mutationOpt =
        spendInternal(
            transactionId, request.nationId(), category, request.amount(), request.description());

    if (mutationOpt.isEmpty()) {
      TreasuryService treasury = requireTreasuryService();
      return new SpendResult(
          SpendingStatus.INSUFFICIENT_FUNDS,
          request.transactionId(),
          treasury.balance(request.nationId()));
    }

    SpendingMutation mutation = mutationOpt.get();
    TreasuryService treasury = requireTreasuryService();
    return new SpendResult(
        mutation.alreadyApplied() ? SpendingStatus.ALREADY_APPLIED : SpendingStatus.APPLIED,
        request.transactionId(),
        treasury.balance(request.nationId()));
  }

  @Override
  public Optional<SpendingReceipt> spendingReceipt(String transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    UUID uuid =
        UUID.nameUUIDFromBytes(transactionId.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    synchronized (stateLock) {
      refreshStateLocked();
      NationSpendingReceipt receipt = receipts.get(uuid);
      if (receipt == null) {
        return Optional.empty();
      }
      return Optional.of(
          new SpendingReceipt(
              transactionId,
              receipt.nationId(),
              receipt.amount(),
              mapBudgetCategoryToSpendingCategory(receipt.category()),
              receipt.description(),
              receipt.spentAt(),
              receipt.refunded()));
    }
  }

  @Override
  public boolean refund(String transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    UUID uuid =
        UUID.nameUUIDFromBytes(transactionId.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    return refundInternal(uuid);
  }

  @Override
  public Optional<SpendingSnapshot> spendingSnapshot(NationId nationId) {
    Objects.requireNonNull(nationId, "nationId");
    synchronized (stateLock) {
      refreshStateLocked();
      // Calculate total spent by this nation
      BigDecimal totalSpent =
          receipts.values().stream()
              .filter(r -> r.nationId().equals(nationId))
              .filter(r -> !r.refunded())
              .map(NationSpendingReceipt::amount)
              .reduce(zero(), BigDecimal::add);

      // Get current balance from treasury
      BigDecimal currentBalance = zero();
      if (treasuryService != null) {
        currentBalance = treasuryService.balance(nationId);
      }

      // Total budget = current balance + total spent
      BigDecimal totalBudget = currentBalance.add(totalSpent);

      return Optional.of(
          new SpendingSnapshot(nationId, totalBudget, totalSpent, currentBalance, clock.instant()));
    }
  }

  private BudgetCategory mapSpendingCategoryToBudgetCategory(SpendingCategory category) {
    return switch (category) {
      case TERRITORY_RENT, TERRITORY_LEASE_FEE -> BudgetCategory.INFRASTRUCTURE;
      case RESEARCH -> BudgetCategory.RESEARCH;
      case MILITARY -> BudgetCategory.MILITARY;
      case TREATY -> BudgetCategory.DIPLOMACY;
      case NATIONAL_EVENT -> BudgetCategory.ADMINISTRATION;
      case OTHER -> BudgetCategory.OTHER;
    };
  }

  private SpendingCategory mapBudgetCategoryToSpendingCategory(BudgetCategory category) {
    return switch (category) {
      case RESEARCH -> SpendingCategory.RESEARCH;
      case MILITARY -> SpendingCategory.MILITARY;
      case DIPLOMACY -> SpendingCategory.TREATY;
      case INFRASTRUCTURE -> SpendingCategory.TERRITORY_RENT;
      case ADMINISTRATION -> SpendingCategory.NATIONAL_EVENT;
      default -> SpendingCategory.OTHER;
    };
  }

  // ==================== 内部支出方法 ====================

  private Optional<SpendingMutation> spendInternal(
      UUID transactionId,
      NationId nationId,
      BudgetCategory category,
      BigDecimal amount,
      String description) {
    Objects.requireNonNull(transactionId, "transactionId");
    Objects.requireNonNull(nationId, "nationId");
    Objects.requireNonNull(category, "category");
    BigDecimal normalized = requirePositive(amount, "amount");
    String normalizedDescription = description == null ? "" : description.trim();
    NationSpendingReceipt committed;

    synchronized (stateLock) {
      refreshStateLocked();
      NationSpendingReceipt existing = receipts.get(transactionId);
      if (existing != null) {
        verifyIdempotentRequest(existing, nationId, category, normalized, normalizedDescription);
        if (existing.refunded()) {
          throw new IllegalStateException("Spending transaction was already refunded");
        }
        return Optional.of(new SpendingMutation(true));
      }

      BudgetBill activeBudget = activeFundedBudgetLocked(nationId).orElse(null);
      BigDecimal budgetAmount = zero();
      UUID budgetId = null;
      if (activeBudget != null) {
        BigDecimal remaining = budgetRemainingLocked(activeBudget, category);
        budgetAmount = remaining.min(normalized);
        if (budgetAmount.signum() > 0) {
          budgetId = activeBudget.billId();
        }
      }
      BigDecimal treasuryAmount = normalize(normalized.subtract(budgetAmount));
      TreasuryService treasury = null;
      if (treasuryAmount.signum() > 0) {
        treasury = requireTreasuryService();
        if (!treasury.withdraw(nationId, treasuryAmount)) {
          return Optional.empty();
        }
      }

      BudgetStateSnapshot before = snapshotLocked();
      committed =
          new NationSpendingReceipt(
              transactionId,
              nationId,
              category,
              normalized,
              budgetAmount,
              treasuryAmount,
              budgetId,
              normalizedDescription,
              clock.instant(),
              false);
      receipts.put(transactionId, committed);
      try {
        persistStateLocked();
      } catch (RuntimeException persistenceFailure) {
        restoreLocked(before);
        if (persistenceFailure instanceof BudgetStateReconciliationException)
          throw persistenceFailure;
        if (treasuryAmount.signum() > 0) {
          compensateTreasuryCredit(
              treasury,
              nationId,
              treasuryAmount,
              "Nation spending compensation failed",
              persistenceFailure);
        }
        throw new IllegalStateException("Failed to persist national spending", persistenceFailure);
      }
    }

    recordSpendingEvent("committed", committed);
    return Optional.of(new SpendingMutation(false));
  }

  private record SpendingMutation(boolean alreadyApplied) {}

  private synchronized boolean refundInternal(UUID transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    NationSpendingReceipt existing;
    synchronized (stateLock) {
      refreshStateLocked();
      existing = receipts.get(transactionId);
      if (existing == null) {
        return false;
      }
      if (existing.refunded()) {
        return true;
      }
    }

    if (existing.treasuryAmount().signum() > 0) {
      NationCreditService.CreditResult credit =
          requireNationCreditService()
              .credit(
                  new NationCreditService.CreditRequest(
                      "budget-spending-refund:" + transactionId,
                      existing.nationId(),
                      existing.treasuryAmount(),
                      NationCreditService.CreditCategory.BUDGET_SPENDING_REFUND,
                      "Budget spending refund: " + existing.description()));
      if (!credit.applied()) {
        return false;
      }
    }

    NationSpendingReceipt refunded;
    synchronized (stateLock) {
      refreshStateLocked();
      NationSpendingReceipt current = receipts.get(transactionId);
      if (current == null) {
        return false;
      }
      if (current.refunded()) {
        return true;
      }
      BudgetStateSnapshot before = snapshotLocked();
      refunded = current.asRefunded();
      receipts.put(transactionId, refunded);
      try {
        persistStateLocked();
      } catch (RuntimeException persistenceFailure) {
        restoreLocked(before);
        throw new IllegalStateException(
            "Failed to persist national spending refund", persistenceFailure);
      }
    }
    recordSpendingEvent("refunded", refunded);
    return true;
  }

  private Optional<NationSpendingReceipt> receiptInternal(UUID transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    synchronized (stateLock) {
      refreshStateLocked();
      return Optional.ofNullable(receipts.get(transactionId));
    }
  }

  private NationSpendingSnapshot detailedSpendingSnapshot(NationId nationId) {
    Objects.requireNonNull(nationId, "nationId");
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill activeBudget = activeFundedBudgetLocked(nationId).orElse(null);
      EnumMap<BudgetCategory, BigDecimal> allocated = moneyMap();
      EnumMap<BudgetCategory, BigDecimal> budgetSpent = moneyMap();
      EnumMap<BudgetCategory, BigDecimal> remaining = moneyMap();
      EnumMap<BudgetCategory, BigDecimal> treasuryFallback = moneyMap();

      if (activeBudget != null) {
        for (BudgetEntry entry : activeBudget.entries()) {
          allocated.merge(entry.category(), entry.amount(), BigDecimal::add);
        }
      }
      long committedCount = 0L;
      long refundedCount = 0L;
      for (NationSpendingReceipt receipt : receipts.values()) {
        if (!receipt.nationId().equals(nationId)) {
          continue;
        }
        if (receipt.refunded()) {
          refundedCount++;
          continue;
        }
        committedCount++;
        treasuryFallback.merge(receipt.category(), receipt.treasuryAmount(), BigDecimal::add);
        if (activeBudget != null && activeBudget.billId().equals(receipt.budgetId())) {
          budgetSpent.merge(receipt.category(), receipt.budgetAmount(), BigDecimal::add);
        }
      }
      for (BudgetCategory category : BudgetCategory.values()) {
        BigDecimal categoryAllocated = allocated.getOrDefault(category, zero());
        BigDecimal categorySpent = budgetSpent.getOrDefault(category, zero());
        remaining.put(category, categoryAllocated.subtract(categorySpent).max(zero()));
      }
      return new NationSpendingSnapshot(
          nationId,
          activeBudget == null ? null : activeBudget.billId(),
          allocated,
          budgetSpent,
          remaining,
          treasuryFallback,
          committedCount,
          refundedCount);
    }
  }

  @Override
  public Optional<BudgetBill> getBudget(UUID billId) {
    Objects.requireNonNull(billId, "billId");
    synchronized (stateLock) {
      refreshStateLocked();
      return Optional.ofNullable(budgets.get(billId));
    }
  }

  @Override
  public Optional<BudgetBill> getCurrentBudget(NationId nationId) {
    Objects.requireNonNull(nationId, "nationId");
    synchronized (stateLock) {
      refreshStateLocked();
      return currentBudgetLocked(nationId);
    }
  }

  @Override
  public List<BudgetBill> getBudgetHistory(NationId nationId, int limit) {
    Objects.requireNonNull(nationId, "nationId");
    if (limit <= 0) {
      return List.of();
    }
    synchronized (stateLock) {
      refreshStateLocked();
      return budgets.values().stream()
          .filter(budget -> budget.nationId().equals(nationId))
          .sorted(
              Comparator.comparingInt(BudgetBill::year)
                  .thenComparingInt(BudgetBill::month)
                  .thenComparing(budget -> budget.billId().toString())
                  .reversed())
          .limit(limit)
          .toList();
    }
  }

  @Override
  public BudgetExecutionReport getBudgetExecutionReport(UUID billId) {
    Objects.requireNonNull(billId, "billId");
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill budget = budgets.get(billId);
      if (budget == null) {
        return null;
      }
      List<BudgetExecutionReport.CategorySpending> categories = new ArrayList<>();
      BigDecimal totalSpent = zero();
      for (BudgetCategory category : BudgetCategory.values()) {
        BigDecimal allocated =
            budget.entries().stream()
                .filter(entry -> entry.category() == category)
                .map(BudgetEntry::amount)
                .reduce(zero(), BigDecimal::add);
        BigDecimal spent =
            receipts.values().stream()
                .filter(receipt -> !receipt.refunded())
                .filter(receipt -> budget.billId().equals(receipt.budgetId()))
                .filter(receipt -> receipt.category() == category)
                .map(NationSpendingReceipt::budgetAmount)
                .reduce(zero(), BigDecimal::add);
        totalSpent = totalSpent.add(spent);
        categories.add(
            new BudgetExecutionReport.CategorySpending(
                category, normalize(allocated), normalize(spent)));
      }
      BigDecimal remaining = budget.totalAmount().subtract(totalSpent).max(zero());
      return new BudgetExecutionReport(
          billId,
          budget.nationId(),
          budget.approvedAt() == null ? clock.instant() : budget.approvedAt(),
          budget.totalAmount(),
          normalize(totalSpent),
          normalize(remaining),
          List.copyOf(categories));
    }
  }

  @Override
  public BigDecimal getMonthlySpending(NationId nationId, int year, int month) {
    Objects.requireNonNull(nationId, "nationId");
    if (month < 1 || month > 12) {
      throw new IllegalArgumentException("month must be between 1 and 12");
    }
    YearMonth target = YearMonth.of(year, month);
    synchronized (stateLock) {
      refreshStateLocked();
      return receipts.values().stream()
          .filter(receipt -> !receipt.refunded())
          .filter(receipt -> receipt.nationId().equals(nationId))
          .filter(receipt -> receiptMonth(receipt).equals(target))
          .map(NationSpendingReceipt::amount)
          .reduce(zero(), BigDecimal::add)
          .setScale(SCALE, RoundingMode.DOWN);
    }
  }

  @Override
  public BigDecimal getYearlySpending(NationId nationId, int year) {
    Objects.requireNonNull(nationId, "nationId");
    synchronized (stateLock) {
      refreshStateLocked();
      return receipts.values().stream()
          .filter(receipt -> !receipt.refunded())
          .filter(receipt -> receipt.nationId().equals(nationId))
          .filter(receipt -> receiptMonth(receipt).getYear() == year)
          .map(NationSpendingReceipt::amount)
          .reduce(zero(), BigDecimal::add)
          .setScale(SCALE, RoundingMode.DOWN);
    }
  }

  @Override
  public BigDecimal getCategorySpending(NationId nationId, BudgetCategory category) {
    Objects.requireNonNull(nationId, "nationId");
    Objects.requireNonNull(category, "category");
    synchronized (stateLock) {
      refreshStateLocked();
      return receipts.values().stream()
          .filter(receipt -> !receipt.refunded())
          .filter(receipt -> receipt.nationId().equals(nationId))
          .filter(receipt -> receipt.category() == category)
          .map(NationSpendingReceipt::amount)
          .reduce(zero(), BigDecimal::add)
          .setScale(SCALE, RoundingMode.DOWN);
    }
  }

  @Override
  public boolean isOverBudget(NationId nationId, BudgetCategory category, BigDecimal amount) {
    Objects.requireNonNull(nationId, "nationId");
    Objects.requireNonNull(category, "category");
    BigDecimal normalized = requirePositive(amount, "amount");
    synchronized (stateLock) {
      refreshStateLocked();
      BudgetBill active = activeFundedBudgetLocked(nationId).orElse(null);
      return active != null && budgetRemainingLocked(active, category).compareTo(normalized) < 0;
    }
  }

  @Override
  public BudgetConfig getBudgetConfig() {
    return budgetConfig;
  }

  @Override
  public void setBudgetConfig(BudgetConfig config) {
    budgetConfig = Objects.requireNonNull(config, "config");
  }

  private Optional<BudgetBill> currentBudgetLocked(NationId nationId) {
    UUID billId = currentBudgets.get(nationId);
    return billId == null ? Optional.empty() : Optional.ofNullable(budgets.get(billId));
  }

  private Optional<BudgetBill> activeFundedBudgetLocked(NationId nationId) {
    YearMonth now = YearMonth.now(clock);
    return currentBudgetLocked(nationId)
        .filter(budget -> budget.status() == BudgetBill.BudgetStatus.EXECUTED)
        .filter(budget -> budget.year() == now.getYear())
        .filter(budget -> budget.month() == now.getMonthValue());
  }

  private BigDecimal budgetRemainingLocked(BudgetBill budget, BudgetCategory category) {
    BigDecimal allocated =
        budget.entries().stream()
            .filter(entry -> entry.category() == category)
            .map(BudgetEntry::amount)
            .reduce(zero(), BigDecimal::add);
    BigDecimal spent =
        receipts.values().stream()
            .filter(receipt -> !receipt.refunded())
            .filter(receipt -> budget.billId().equals(receipt.budgetId()))
            .filter(receipt -> receipt.category() == category)
            .map(NationSpendingReceipt::budgetAmount)
            .reduce(zero(), BigDecimal::add);
    return normalize(allocated.subtract(spent).max(zero()));
  }

  private BudgetBill requireBudgetLocked(UUID billId) {
    BudgetBill budget = budgets.get(billId);
    if (budget == null) {
      throw new IllegalArgumentException("Budget not found: " + billId);
    }
    return budget;
  }

  private TreasuryService requireTreasuryService() {
    TreasuryService treasury = treasuryService;
    if (treasury == null && currentContext != null) {
      treasury = currentContext.serviceRegistry().find(TreasuryService.class).orElse(null);
      treasuryService = treasury;
    }
    if (treasury == null) {
      throw new IllegalStateException("Treasury service is not available");
    }
    return treasury;
  }

  private NationCreditService requireNationCreditService() {
    NationCreditService creditService = nationCreditService;
    if (creditService == null && currentContext != null) {
      creditService = currentContext.serviceRegistry().find(NationCreditService.class).orElse(null);
      nationCreditService = creditService;
    }
    if (creditService == null) {
      throw new IllegalStateException("Nation credit service is not available");
    }
    return creditService;
  }

  private void verifyIdempotentRequest(
      NationSpendingReceipt existing,
      NationId nationId,
      BudgetCategory category,
      BigDecimal amount,
      String description) {
    if (!existing.nationId().equals(nationId)
        || existing.category() != category
        || existing.amount().compareTo(amount) != 0
        || !existing.description().equals(description)) {
      throw new IllegalArgumentException(
          "Spending transaction id is already used by a different request: "
              + existing.transactionId());
    }
  }

  private boolean safeTryDeposit(TreasuryService treasury, NationId nationId, BigDecimal amount) {
    try {
      return treasury.tryDeposit(nationId, amount);
    } catch (RuntimeException failure) {
      logWarning("Treasury refund threw for " + nationId + ": " + failure.getMessage());
      return false;
    }
  }

  private void compensateTreasuryCredit(
      TreasuryService treasury,
      NationId nationId,
      BigDecimal amount,
      String message,
      RuntimeException originalFailure) {
    if (safeTryDeposit(treasury, nationId, amount)) {
      return;
    }
    IllegalStateException critical = new IllegalStateException(message, originalFailure);
    reconciliationRequired = true;
    throw critical;
  }

  private <T> T persistMutationLocked(Supplier<T> mutation) {
    BudgetStateSnapshot before = snapshotLocked();
    T result;
    try {
      result = mutation.get();
      persistStateLocked();
      return result;
    } catch (RuntimeException failure) {
      restoreLocked(before);
      throw failure;
    }
  }

  private BudgetStateSnapshot snapshotLocked() {
    return new BudgetStateSnapshot(budgets, currentBudgets, receipts);
  }

  private void restoreLocked(BudgetStateSnapshot snapshot) {
    budgets.clear();
    budgets.putAll(snapshot.budgets());
    currentBudgets.clear();
    currentBudgets.putAll(snapshot.currentBudgets());
    receipts.clear();
    receipts.putAll(snapshot.receipts());
  }

  private void loadState() {
    synchronized (stateLock) {
      if (stateLoaded || stateStorage == null) {
        return;
      }
      BudgetStateSnapshot loaded = stateCodec.fromProperties(stateStorage.load());
      restoreLocked(loaded);
      stateLoaded = true;
    }
  }

  private void persistStateLocked() {
    if (stateStorage != null) {
      try {
        stateStorage.save(stateCodec.toProperties(snapshotLocked()));
      } catch (BudgetStateReconciliationException uncertain) {
        reconciliationRequired = true;
        throw uncertain;
      }
    }
  }

  private void refreshStateLocked() {
    if (reconciliationRequired) {
      throw new IllegalStateException("Budget requires restart and financial reconciliation");
    }
    if (stateStorage != null) {
      stateStorage
          .refreshIfChanged()
          .ifPresent(
              refresh -> {
                BudgetStateSnapshot validated = stateCodec.fromProperties(refresh.properties());
                stateStorage.acceptRefresh(refresh);
                restoreLocked(validated);
              });
    }
  }

  private YearMonth receiptMonth(NationSpendingReceipt receipt) {
    ZoneId zone = clock.getZone();
    return YearMonth.from(receipt.spentAt().atZone(zone));
  }

  private void startMonthlyResetTask(StarCoreContext context) {
    stopMonthlyResetTask();
    monthlyResetTask =
        Bukkit.getScheduler()
            .runTaskTimer(
                context.plugin(),
                this::performMonthlyReset,
                20L * 60 * 60 * 24,
                20L * 60 * 60 * 24);
  }

  private void stopMonthlyResetTask() {
    if (monthlyResetTask != null) {
      monthlyResetTask.cancel();
      monthlyResetTask = null;
    }
  }

  private void performMonthlyReset() {
    YearMonth now = YearMonth.now(clock);
    List<UUID> toCancel = new ArrayList<>();
    List<UUID> toExecute = new ArrayList<>();
    synchronized (stateLock) {
      refreshStateLocked();
      for (UUID billId : currentBudgets.values()) {
        BudgetBill budget = budgets.get(billId);
        if (budget == null || budget.status() != BudgetBill.BudgetStatus.APPROVED) {
          continue;
        }
        YearMonth period = YearMonth.of(budget.year(), budget.month());
        if (!period.isBefore(now)) {
          continue;
        }
        if (budgetConfig.requireApproval()) {
          toCancel.add(billId);
        } else {
          toExecute.add(billId);
        }
      }
    }
    toCancel.forEach(this::cancelBudget);
    toExecute.forEach(this::executeBudget);
  }

  private void recordBudgetEvent(NationId nationId, String action, String details) {
    recordEvent(
        nationId,
        "treasury.budget." + action,
        "Budget " + action + ": " + details,
        "action=" + action + ";" + details);
  }

  private void recordSpendingEvent(String action, NationSpendingReceipt receipt) {
    recordEvent(
        receipt.nationId(),
        "treasury.spending." + action,
        "National spending "
            + action
            + ": "
            + receipt.amount().toPlainString()
            + " ("
            + receipt.source()
            + ")",
        "action="
            + action
            + ";transactionId="
            + receipt.transactionId()
            + ";category="
            + receipt.category().name()
            + ";amount="
            + receipt.amount().toPlainString()
            + ";budgetAmount="
            + receipt.budgetAmount().toPlainString()
            + ";treasuryAmount="
            + receipt.treasuryAmount().toPlainString());
  }

  private void recordEvent(NationId nationId, String type, String message, String context) {
    StarCoreContext contextRef = currentContext;
    if (contextRef == null) {
      return;
    }
    EventService eventService = contextRef.serviceRegistry().find(EventService.class).orElse(null);
    if (eventService == null) {
      return;
    }
    try {
      eventService.record(nationId, type, message, context);
    } catch (RuntimeException failure) {
      logWarning("Post-commit finance event failed: " + failure.getMessage());
    }
  }

  private void logWarning(String message) {
    if (currentContext != null) {
      currentContext.plugin().getLogger().warning("[Budget] " + message);
    }
  }

  private static EnumMap<BudgetCategory, BigDecimal> moneyMap() {
    EnumMap<BudgetCategory, BigDecimal> values = new EnumMap<>(BudgetCategory.class);
    for (BudgetCategory category : BudgetCategory.values()) {
      values.put(category, zero());
    }
    return values;
  }

  private static BigDecimal requirePositive(BigDecimal value, String name) {
    Objects.requireNonNull(value, name);
    BigDecimal normalized = normalize(value);
    if (normalized.signum() <= 0) {
      throw new IllegalArgumentException(name + " must be positive");
    }
    return normalized;
  }

  private static BigDecimal normalize(BigDecimal value) {
    Objects.requireNonNull(value, "value");
    BigDecimal normalized = value.setScale(SCALE, RoundingMode.DOWN);
    if (normalized.signum() < 0) {
      throw new IllegalArgumentException("money value must be non-negative");
    }
    return normalized;
  }

  private static BigDecimal zero() {
    return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
  }
}
