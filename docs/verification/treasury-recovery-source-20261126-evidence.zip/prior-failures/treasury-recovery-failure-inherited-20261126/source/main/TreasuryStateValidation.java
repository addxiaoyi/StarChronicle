package dev.starcore.starcore.module.treasury;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

/** Rejects incomplete snapshots before the compatibility decoder can skip damaged rows. */
final class TreasuryStateValidation {
  private static final BigDecimal MAX_BALANCE = new BigDecimal("1000000000000000.00");

  private TreasuryStateValidation() {}

  static TreasuryStateCodec.TreasuryState read(Properties properties) {
    if (properties == null) throw invalid("null snapshot");
    for (var entry : properties.entrySet())
      if (!(entry.getKey() instanceof String) || !(entry.getValue() instanceof String))
        throw invalid("non-text property");
    var keys = properties.stringPropertyNames();
    if (keys.contains("authorityDomainId")) uuid(properties, "authorityDomainId");
    rows(properties, keys, "treasury", "count", Set.of("nationId", "balance"), 2);
    rows(
        properties,
        keys,
        "spending",
        "spending.count",
        Set.of(
            "transactionId",
            "nationId",
            "amount",
            "category",
            "description",
            "appliedAt",
            "refunded"),
        5);
    rows(
        properties,
        keys,
        "credit",
        "credit.count",
        Set.of("transactionId", "nationId", "amount", "category", "description", "appliedAt"),
        5);
    rows(
        properties,
        keys,
        "transfer",
        "transfer.count",
        Set.of(
            "transactionId",
            "payerId",
            "receiverId",
            "amount",
            "category",
            "description",
            "appliedAt"),
        6);
    return TreasuryStateCodec.stateFromProperties(properties);
  }

  private static void rows(
      Properties properties,
      Set<String> keys,
      String collection,
      String countKey,
      Set<String> fields,
      int minimumFields) {
    int count;
    try {
      count = Integer.parseInt(properties.getProperty(countKey, "0"));
      if (count < 0 || count > keys.size() / minimumFields) throw invalid(countKey);
    } catch (NumberFormatException error) {
      throw invalid(countKey);
    }
    for (String key : keys) {
      if (!key.startsWith(collection + ".") || key.equals(countKey)) continue;
      String suffix = key.substring(collection.length() + 1);
      int dot = suffix.indexOf('.');
      if (dot < 1) throw invalid(key);
      String index = suffix.substring(0, dot);
      try {
        int value = Integer.parseInt(index);
        if (value < 0
            || value >= count
            || !Integer.toString(value).equals(index)
            || !fields.contains(suffix.substring(dot + 1))) throw invalid(key);
      } catch (NumberFormatException error) {
        throw invalid(key);
      }
    }
    Set<String> identities = new HashSet<>();
    for (int index = 0; index < count; index++) {
      String row = collection + "." + index + ".";
      if (collection.equals("treasury")) {
        if (!identities.add(uuid(properties, row + "nationId"))) throw invalid(row + "nationId");
        amount(properties, row + "balance", true);
        continue;
      }
      if (!identities.add(required(properties, row + "transactionId")))
        throw invalid(row + "transactionId");
      amount(properties, row + "amount", false);
      try {
        Long.parseLong(required(properties, row + "appliedAt"));
      } catch (NumberFormatException error) {
        throw invalid(row + "appliedAt");
      }
      String category = required(properties, row + "category");
      try {
        switch (collection) {
          case "spending" -> {
            uuid(properties, row + "nationId");
            NationSpendingService.SpendingCategory.valueOf(category);
            String refunded = properties.getProperty(row + "refunded", "false");
            if (!refunded.equals("true") && !refunded.equals("false"))
              throw invalid(row + "refunded");
          }
          case "credit" -> {
            uuid(properties, row + "nationId");
            NationCreditService.CreditCategory.valueOf(category);
          }
          case "transfer" -> {
            String payer = uuid(properties, row + "payerId");
            if (payer.equals(uuid(properties, row + "receiverId")))
              throw invalid(row + "receiverId");
            NationTransferService.TransferCategory.valueOf(category);
          }
          default -> throw invalid(collection);
        }
      } catch (IllegalArgumentException error) {
        throw invalid(row + "category");
      }
    }
  }

  private static String required(Properties properties, String key) {
    String value = properties.getProperty(key);
    if (value == null || value.isBlank()) throw invalid(key);
    return value;
  }

  private static String uuid(Properties properties, String key) {
    String value = required(properties, key);
    try {
      if (!UUID.fromString(value).toString().equals(value)) throw invalid(key);
    } catch (IllegalArgumentException error) {
      throw invalid(key);
    }
    return value;
  }

  private static void amount(Properties properties, String key, boolean zeroAllowed) {
    try {
      BigDecimal amount = new BigDecimal(required(properties, key));
      if (amount.signum() < 0
          || (!zeroAllowed && amount.signum() == 0)
          || amount.compareTo(MAX_BALANCE) > 0) throw invalid(key);
      amount.setScale(2, RoundingMode.UNNECESSARY);
    } catch (IllegalArgumentException | ArithmeticException error) {
      throw invalid(key);
    }
  }

  private static IllegalStateException invalid(String key) {
    return new IllegalStateException("Invalid treasury state: " + key);
  }
}
