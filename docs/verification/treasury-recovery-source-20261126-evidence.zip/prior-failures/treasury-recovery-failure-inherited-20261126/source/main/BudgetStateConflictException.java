package dev.starcore.starcore.module.treasury;

/** A stale budget writer must refresh before the caller explicitly retries. */
final class BudgetStateConflictException extends IllegalStateException {
  BudgetStateConflictException(Throwable cause) {
    super("Budget state changed on another instance; retry after refresh", cause);
  }
}
