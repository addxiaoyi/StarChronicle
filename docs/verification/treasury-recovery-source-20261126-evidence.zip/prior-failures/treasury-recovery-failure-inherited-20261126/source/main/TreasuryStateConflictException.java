package dev.starcore.starcore.module.treasury;

final class TreasuryStateConflictException extends IllegalStateException {
  TreasuryStateConflictException(Throwable cause) {
    super(
        "code=TREASURY_STATE_CONFLICT Treasury state changed concurrently; reload and retry",
        cause);
  }
}
