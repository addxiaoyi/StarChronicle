package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.treasury.TaxationService.PlayerIncome;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxPayer;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

final class TaxAssessment {
    private static final int SCALE = 2;
    private static final BigDecimal ONE_HUNDRED = new BigDecimal("100");

    List<TaxFunding.Charge> assess(TaxType type, TaxConfig config, TaxContext context) {
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(config, "config");
        Objects.requireNonNull(context, "context");
        if (!config.enabled() || config.type() != type) {
            return List.of();
        }
        validateRate(config.percentRate());

        return switch (type) {
            case LAND_TAX -> landCharges(config, context);
            case BUSINESS_TAX -> percentageCharges(context.businessPayers(), config);
            case INCOME_TAX -> incomeCharges(context.playerIncomes(), config);
            case TARIFF -> percentageCharges(context.tariffPayers(), config);
        };
    }

    private List<TaxFunding.Charge> landCharges(TaxConfig config, TaxContext context) {
        if (config.fixedAmount().signum() <= 0 || context.claimCount() <= 0) {
            return List.of();
        }
        List<UUID> payers = new ArrayList<>(new LinkedHashSet<>(
            context.playerIncomes().stream().map(PlayerIncome::playerId).toList()));
        if (payers.isEmpty()) {
            return List.of();
        }

        BigDecimal total = config.fixedAmount()
            .multiply(BigDecimal.valueOf(context.claimCount()))
            .setScale(SCALE, RoundingMode.DOWN);
        BigDecimal share = total.divide(
            BigDecimal.valueOf(payers.size()), SCALE, RoundingMode.DOWN);
        BigDecimal allocated = BigDecimal.ZERO;
        List<TaxFunding.Charge> charges = new ArrayList<>(payers.size());
        for (int index = 0; index < payers.size(); index++) {
            BigDecimal amount = index == payers.size() - 1
                ? total.subtract(allocated)
                : share;
            charges.add(new TaxFunding.Charge(payers.get(index), amount));
            allocated = allocated.add(amount);
        }
        return List.copyOf(charges);
    }

    private List<TaxFunding.Charge> incomeCharges(
        List<PlayerIncome> incomes,
        TaxConfig config
    ) {
        List<TaxFunding.Charge> charges = new ArrayList<>();
        for (PlayerIncome income : incomes) {
            if (income == null || income.playerId() == null || income.income() == null
                || income.income().signum() <= 0
                || income.income().compareTo(config.minimumBalance()) < 0) {
                continue;
            }
            BigDecimal amount = config.fixedAmount().signum() > 0
                ? config.fixedAmount()
                : percentage(income.income(), config.percentRate());
            if (amount.signum() > 0) {
                charges.add(new TaxFunding.Charge(income.playerId(), amount));
            }
        }
        return List.copyOf(charges);
    }

    private List<TaxFunding.Charge> percentageCharges(
        List<TaxPayer> payers,
        TaxConfig config
    ) {
        Map<UUID, BigDecimal> bases = new LinkedHashMap<>();
        for (TaxPayer payer : payers) {
            if (payer.taxableAmount().signum() > 0) {
                bases.merge(payer.playerId(), payer.taxableAmount(), BigDecimal::add);
            }
        }

        List<TaxFunding.Charge> charges = new ArrayList<>(bases.size());
        for (Map.Entry<UUID, BigDecimal> entry : bases.entrySet()) {
            BigDecimal amount = config.fixedAmount().signum() > 0
                ? config.fixedAmount()
                : percentage(entry.getValue(), config.percentRate());
            if (amount.signum() > 0) {
                charges.add(new TaxFunding.Charge(entry.getKey(), amount));
            }
        }
        return List.copyOf(charges);
    }

    private BigDecimal percentage(BigDecimal base, BigDecimal rate) {
        if (rate.signum() <= 0) {
            return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
        }
        return base.multiply(rate)
            .divide(ONE_HUNDRED, SCALE, RoundingMode.DOWN);
    }

    private void validateRate(BigDecimal rate) {
        if (rate == null || rate.signum() < 0 || rate.compareTo(ONE_HUNDRED) > 0) {
            throw new IllegalArgumentException("Tax percent rate must be between 0 and 100");
        }
    }
}
