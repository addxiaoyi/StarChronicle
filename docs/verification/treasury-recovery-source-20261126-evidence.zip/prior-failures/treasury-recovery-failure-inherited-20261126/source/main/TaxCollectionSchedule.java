package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class TaxCollectionSchedule {
    private static final String PROPERTY_PREFIX = "taxCursor.";

    private final ConcurrentMap<CursorKey, Instant> cursors = new ConcurrentHashMap<>();

    List<DueTax> dueTaxes(
        NationId nationId,
        Map<TaxType, TaxConfig> configs,
        Instant now,
        Duration bootstrapPeriod
    ) {
        Objects.requireNonNull(nationId, "nationId");
        Objects.requireNonNull(configs, "configs");
        Objects.requireNonNull(now, "now");
        Objects.requireNonNull(bootstrapPeriod, "bootstrapPeriod");

        List<DueTax> due = new ArrayList<>();
        for (TaxType type : TaxType.values()) {
            TaxConfig config = configs.get(type);
            if (config == null || !config.enabled() || !config.autoCollect()) {
                continue;
            }
            TaxCollectionWindow window = new TaxCollectionWindow(
                cursors.get(new CursorKey(nationId, type)),
                config.collectionIntervalMinutes(),
                now
            );
            if (window.isDue()) {
                due.add(new DueTax(type, window.period(bootstrapPeriod)));
            }
        }
        return List.copyOf(due);
    }

    void markCollected(NationId nationId, TaxType type, Instant collectedAt) {
        cursors.put(
            new CursorKey(
                Objects.requireNonNull(nationId, "nationId"),
                Objects.requireNonNull(type, "type")
            ),
            Objects.requireNonNull(collectedAt, "collectedAt")
        );
    }

    Optional<Instant> lastCollectedAt(NationId nationId, TaxType type) {
        return Optional.ofNullable(cursors.get(new CursorKey(nationId, type)));
    }

    void load(Properties properties) {
        Objects.requireNonNull(properties, "properties");
        cursors.clear();
        for (String name : properties.stringPropertyNames()) {
            if (!name.startsWith(PROPERTY_PREFIX)) {
                continue;
            }
            String key = name.substring(PROPERTY_PREFIX.length());
            int separator = key.lastIndexOf('.');
            if (separator <= 0 || separator == key.length() - 1) {
                throw new IllegalArgumentException("Invalid tax cursor property: " + name);
            }
            NationId nationId = NationId.fromString(key.substring(0, separator));
            TaxType type = TaxType.valueOf(key.substring(separator + 1));
            Instant collectedAt = Instant.parse(properties.getProperty(name));
            cursors.put(new CursorKey(nationId, type), collectedAt);
        }
    }

    void save(Properties properties) {
        Objects.requireNonNull(properties, "properties");
        properties.stringPropertyNames().stream()
            .filter(name -> name.startsWith(PROPERTY_PREFIX))
            .toList()
            .forEach(properties::remove);
        cursors.forEach((key, instant) -> properties.setProperty(
            PROPERTY_PREFIX + key.nationId() + "." + key.type().name(),
            instant.toString()
        ));
    }

    record DueTax(TaxType type, Duration period) {
        DueTax {
            Objects.requireNonNull(type, "type");
            Objects.requireNonNull(period, "period");
        }
    }

    private record CursorKey(NationId nationId, TaxType type) {}
}
