package dev.starcore.starcore.module.treasury;

/** Never compensate a debit when the budget commit may already be durable. */
final class BudgetStateReconciliationException extends IllegalStateException {
  BudgetStateReconciliationException(Throwable cause) {
    super("Budget commit outcome is uncertain; restart and reconcile canonical state", cause);
  }
}
