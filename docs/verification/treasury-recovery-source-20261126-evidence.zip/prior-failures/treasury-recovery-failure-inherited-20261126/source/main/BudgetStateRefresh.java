package dev.starcore.starcore.module.treasury;

import java.util.Properties;

/** Detached shared budget state with its optimistic write revision. */
record BudgetStateRefresh(Properties properties, long revision) {
  BudgetStateRefresh {
    properties = copy(properties);
  }

  @Override
  public Properties properties() {
    return copy(properties);
  }

  private static Properties copy(Properties source) {
    Properties copy = new Properties();
    copy.putAll(source);
    return copy;
  }
}
