package dev.starcore.starcore.module.treasury;

import java.util.Properties;

/** A detached treasury snapshot and the SQL revision from which it was read. */
record TreasuryStateRefresh(Properties properties, long revision) {
  TreasuryStateRefresh {
    properties = copy(properties);
  }

  @Override
  public Properties properties() {
    return copy(properties);
  }

  private static Properties copy(Properties source) {
    Properties copy = new Properties();
    copy.putAll(source);
    return copy;
  }
}
