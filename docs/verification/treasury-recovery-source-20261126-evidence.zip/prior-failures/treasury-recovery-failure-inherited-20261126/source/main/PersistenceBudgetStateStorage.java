package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.Objects;
import java.util.Properties;

final class PersistenceBudgetStateStorage implements BudgetStateStorage {
  private static final String FILE_NAME = "budgets.properties";

  private final String namespace;
  private final PersistenceService persistenceService;

  PersistenceBudgetStateStorage(String namespace, PersistenceService persistenceService) {
    this.namespace = Objects.requireNonNull(namespace, "namespace");
    this.persistenceService = Objects.requireNonNull(persistenceService, "persistenceService");
  }

  @Override
  public Properties load() {
    return persistenceService.loadProperties(namespace, FILE_NAME);
  }

  @Override
  public void save(Properties properties) {
    persistenceService.saveProperties(namespace, FILE_NAME, properties);
  }
}
