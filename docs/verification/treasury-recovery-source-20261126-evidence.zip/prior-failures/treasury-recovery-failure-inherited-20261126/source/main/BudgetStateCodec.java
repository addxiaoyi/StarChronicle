package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetBill;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetEntry;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

final class BudgetStateCodec {
  static final int CURRENT_SCHEMA_VERSION = 2;
  private static final int SCALE = 2;

  Properties toProperties(BudgetStateSnapshot snapshot) {
    Objects.requireNonNull(snapshot, "snapshot");
    Properties properties = new Properties();
    properties.setProperty("schema.version", Integer.toString(CURRENT_SCHEMA_VERSION));

    List<BudgetBill> budgets =
        snapshot.budgets().values().stream()
            .sorted(Comparator.comparing(budget -> budget.billId().toString()))
            .toList();
    properties.setProperty("budget.count", Integer.toString(budgets.size()));
    for (int i = 0; i < budgets.size(); i++) {
      writeBudget(properties, "budget." + i + ".", budgets.get(i));
    }

    List<Map.Entry<NationId, UUID>> current =
        snapshot.currentBudgets().entrySet().stream()
            .sorted(Comparator.comparing(entry -> entry.getKey().value().toString()))
            .toList();
    properties.setProperty("current.count", Integer.toString(current.size()));
    for (int i = 0; i < current.size(); i++) {
      String prefix = "current." + i + ".";
      properties.setProperty(prefix + "nationId", current.get(i).getKey().value().toString());
      properties.setProperty(prefix + "billId", current.get(i).getValue().toString());
    }

    List<NationSpendingReceipt> receipts =
        snapshot.receipts().values().stream()
            .sorted(Comparator.comparing(receipt -> receipt.transactionId().toString()))
            .toList();
    properties.setProperty("spending.count", Integer.toString(receipts.size()));
    for (int i = 0; i < receipts.size(); i++) {
      writeReceipt(properties, "spending." + i + ".", receipts.get(i));
    }
    return properties;
  }

  BudgetStateSnapshot fromProperties(Properties properties) {
    Objects.requireNonNull(properties, "properties");
    if (properties.isEmpty()) {
      return BudgetStateSnapshot.empty();
    }

    String schemaText = properties.getProperty("schema.version");
    int schemaVersion = schemaText == null ? 1 : parseInt(schemaText, "schema.version");
    if (schemaVersion < 1 || schemaVersion > CURRENT_SCHEMA_VERSION) {
      throw new IllegalArgumentException(
          "Unsupported budget state schema version: " + schemaVersion);
    }

    boolean legacy = schemaText == null || schemaVersion == 1;
    String countKey = legacy ? "count" : "budget.count";
    int budgetCount = parseNonNegativeInt(properties.getProperty(countKey, "0"), countKey);

    Map<UUID, BudgetBill> budgets = new LinkedHashMap<>();
    for (int i = 0; i < budgetCount; i++) {
      BudgetBill budget = readBudget(properties, "budget." + i + ".");
      if (budgets.putIfAbsent(budget.billId(), budget) != null) {
        throw new IllegalArgumentException("Duplicate budget id: " + budget.billId());
      }
    }

    Map<NationId, UUID> currentBudgets =
        legacy ? deriveCurrentBudgets(budgets) : readCurrentBudgets(properties, budgets);
    Map<UUID, NationSpendingReceipt> receipts =
        legacy ? synthesizeLegacyReceipts(budgets) : readReceipts(properties, budgets);
    validateAggregateBudgetSpending(budgets, receipts);
    return new BudgetStateSnapshot(budgets, currentBudgets, receipts);
  }

  private void writeBudget(Properties properties, String prefix, BudgetBill budget) {
    properties.setProperty(prefix + "billId", budget.billId().toString());
    properties.setProperty(prefix + "nationId", budget.nationId().value().toString());
    properties.setProperty(prefix + "year", Integer.toString(budget.year()));
    properties.setProperty(prefix + "month", Integer.toString(budget.month()));
    properties.setProperty(prefix + "totalAmount", normalize(budget.totalAmount()).toPlainString());
    properties.setProperty(prefix + "status", budget.status().name());
    properties.setProperty(
        prefix + "approvedAt",
        budget.approvedAt() == null ? "" : Long.toString(budget.approvedAt().toEpochMilli()));
    properties.setProperty(
        prefix + "approvedBy", budget.approvedBy() == null ? "" : budget.approvedBy());

    List<BudgetEntry> entries = List.copyOf(budget.entries());
    properties.setProperty(prefix + "entries", Integer.toString(entries.size()));
    for (int i = 0; i < entries.size(); i++) {
      BudgetEntry entry = entries.get(i);
      String entryPrefix = prefix + "entry." + i + ".";
      properties.setProperty(entryPrefix + "entryId", entry.entryId().toString());
      properties.setProperty(entryPrefix + "category", entry.category().name());
      properties.setProperty(entryPrefix + "description", entry.description());
      properties.setProperty(entryPrefix + "amount", normalize(entry.amount()).toPlainString());
      properties.setProperty(
          entryPrefix + "createdAt", Long.toString(entry.createdAt().toEpochMilli()));
    }
  }

  private BudgetBill readBudget(Properties properties, String prefix) {
    UUID billId = parseUuid(required(properties, prefix + "billId"), prefix + "billId");
    NationId nationId =
        new NationId(parseUuid(required(properties, prefix + "nationId"), prefix + "nationId"));
    int year = parseInt(required(properties, prefix + "year"), prefix + "year");
    int month = parseInt(required(properties, prefix + "month"), prefix + "month");
    if (month < 1 || month > 12) {
      throw new IllegalArgumentException(prefix + "month must be between 1 and 12");
    }
    BigDecimal totalAmount =
        parseMoney(properties.getProperty(prefix + "totalAmount", "0"), prefix + "totalAmount");
    BudgetBill.BudgetStatus status =
        parseEnum(
            BudgetBill.BudgetStatus.class,
            properties.getProperty(prefix + "status", "DRAFT"),
            prefix + "status");
    Instant approvedAt = parseOptionalInstant(properties.getProperty(prefix + "approvedAt"));
    String approvedBy = blankToNull(properties.getProperty(prefix + "approvedBy"));

    int entryCount =
        parseNonNegativeInt(properties.getProperty(prefix + "entries", "0"), prefix + "entries");
    List<BudgetEntry> entries = new ArrayList<>(entryCount);
    Set<UUID> entryIds = new HashSet<>();
    BigDecimal computedTotal = zero();
    for (int i = 0; i < entryCount; i++) {
      String entryPrefix = prefix + "entry." + i + ".";
      UUID entryId =
          parseUuid(required(properties, entryPrefix + "entryId"), entryPrefix + "entryId");
      if (!entryIds.add(entryId)) {
        throw new IllegalArgumentException("Duplicate budget entry id: " + entryId);
      }
      BudgetCategory category =
          parseEnum(
              BudgetCategory.class,
              properties.getProperty(entryPrefix + "category", BudgetCategory.OTHER.name()),
              entryPrefix + "category");
      String description = properties.getProperty(entryPrefix + "description", "");
      BigDecimal amount =
          parsePositiveMoney(
              properties.getProperty(entryPrefix + "amount", "0"), entryPrefix + "amount");
      Instant createdAt =
          parseInstant(required(properties, entryPrefix + "createdAt"), entryPrefix + "createdAt");
      entries.add(new BudgetEntry(entryId, category, description, amount, createdAt));
      computedTotal = computedTotal.add(amount);
    }
    if (computedTotal.compareTo(totalAmount) != 0) {
      throw new IllegalArgumentException(
          "Budget total does not match entries for "
              + billId
              + ": "
              + totalAmount
              + " != "
              + computedTotal);
    }
    return new BudgetBill(
        billId,
        nationId,
        year,
        month,
        List.copyOf(entries),
        totalAmount,
        status,
        approvedAt,
        approvedBy);
  }

  private Map<NationId, UUID> readCurrentBudgets(
      Properties properties, Map<UUID, BudgetBill> budgets) {
    int count = parseNonNegativeInt(properties.getProperty("current.count", "0"), "current.count");
    if (count == 0) {
      return deriveCurrentBudgets(budgets);
    }
    Map<NationId, UUID> current = new LinkedHashMap<>();
    for (int i = 0; i < count; i++) {
      String prefix = "current." + i + ".";
      NationId nationId =
          new NationId(parseUuid(required(properties, prefix + "nationId"), prefix + "nationId"));
      UUID billId = parseUuid(required(properties, prefix + "billId"), prefix + "billId");
      BudgetBill budget = budgets.get(billId);
      if (budget == null || !budget.nationId().equals(nationId)) {
        throw new IllegalArgumentException(
            "Current budget index references an invalid budget: " + nationId + " -> " + billId);
      }
      if (current.putIfAbsent(nationId, billId) != null) {
        throw new IllegalArgumentException("Duplicate current budget index for " + nationId);
      }
    }
    return current;
  }

  private Map<NationId, UUID> deriveCurrentBudgets(Map<UUID, BudgetBill> budgets) {
    Map<NationId, BudgetBill> latest = new HashMap<>();
    for (BudgetBill budget : budgets.values()) {
      if (budget.status() == BudgetBill.BudgetStatus.CANCELLED
          || budget.status() == BudgetBill.BudgetStatus.REJECTED) {
        continue;
      }
      latest.merge(
          budget.nationId(),
          budget,
          (left, right) -> compareBudgetPeriod(left, right) >= 0 ? left : right);
    }
    Map<NationId, UUID> current = new LinkedHashMap<>();
    latest.entrySet().stream()
        .sorted(Comparator.comparing(entry -> entry.getKey().value().toString()))
        .forEach(entry -> current.put(entry.getKey(), entry.getValue().billId()));
    return current;
  }

  private int compareBudgetPeriod(BudgetBill left, BudgetBill right) {
    int year = Integer.compare(left.year(), right.year());
    if (year != 0) {
      return year;
    }
    int month = Integer.compare(left.month(), right.month());
    if (month != 0) {
      return month;
    }
    return left.billId().toString().compareTo(right.billId().toString());
  }

  private void writeReceipt(Properties properties, String prefix, NationSpendingReceipt receipt) {
    properties.setProperty(prefix + "transactionId", receipt.transactionId().toString());
    properties.setProperty(prefix + "nationId", receipt.nationId().value().toString());
    properties.setProperty(prefix + "category", receipt.category().name());
    properties.setProperty(prefix + "amount", receipt.amount().toPlainString());
    properties.setProperty(prefix + "budgetAmount", receipt.budgetAmount().toPlainString());
    properties.setProperty(prefix + "treasuryAmount", receipt.treasuryAmount().toPlainString());
    properties.setProperty(
        prefix + "budgetId", receipt.budgetId() == null ? "" : receipt.budgetId().toString());
    properties.setProperty(prefix + "description", receipt.description());
    properties.setProperty(prefix + "spentAt", Long.toString(receipt.spentAt().toEpochMilli()));
    properties.setProperty(prefix + "refunded", Boolean.toString(receipt.refunded()));
  }

  private Map<UUID, NationSpendingReceipt> readReceipts(
      Properties properties, Map<UUID, BudgetBill> budgets) {
    int count =
        parseNonNegativeInt(properties.getProperty("spending.count", "0"), "spending.count");
    Map<UUID, NationSpendingReceipt> receipts = new LinkedHashMap<>();
    for (int i = 0; i < count; i++) {
      String prefix = "spending." + i + ".";
      UUID transactionId =
          parseUuid(required(properties, prefix + "transactionId"), prefix + "transactionId");
      NationId nationId =
          new NationId(parseUuid(required(properties, prefix + "nationId"), prefix + "nationId"));
      BudgetCategory category =
          parseEnum(
              BudgetCategory.class, required(properties, prefix + "category"), prefix + "category");
      BigDecimal amount =
          parsePositiveMoney(required(properties, prefix + "amount"), prefix + "amount");
      BigDecimal budgetAmount =
          parseMoney(required(properties, prefix + "budgetAmount"), prefix + "budgetAmount");
      BigDecimal treasuryAmount =
          parseMoney(required(properties, prefix + "treasuryAmount"), prefix + "treasuryAmount");
      String budgetIdText = blankToNull(properties.getProperty(prefix + "budgetId"));
      UUID budgetId = budgetIdText == null ? null : parseUuid(budgetIdText, prefix + "budgetId");
      String description = properties.getProperty(prefix + "description", "");
      Instant spentAt = parseInstant(required(properties, prefix + "spentAt"), prefix + "spentAt");
      boolean refunded = Boolean.parseBoolean(properties.getProperty(prefix + "refunded", "false"));
      NationSpendingReceipt receipt =
          new NationSpendingReceipt(
              transactionId,
              nationId,
              category,
              amount,
              budgetAmount,
              treasuryAmount,
              budgetId,
              description,
              spentAt,
              refunded);
      validateReceiptBudget(receipt, budgets);
      if (receipts.putIfAbsent(transactionId, receipt) != null) {
        throw new IllegalArgumentException("Duplicate spending transaction id: " + transactionId);
      }
    }
    return receipts;
  }

  private void validateReceiptBudget(NationSpendingReceipt receipt, Map<UUID, BudgetBill> budgets) {
    if (receipt.budgetAmount().signum() == 0) {
      return;
    }
    BudgetBill budget = budgets.get(receipt.budgetId());
    if (budget == null
        || !budget.nationId().equals(receipt.nationId())
        || budget.status() != BudgetBill.BudgetStatus.EXECUTED) {
      throw new IllegalArgumentException(
          "Spending receipt references an invalid funded budget: " + receipt.transactionId());
    }
  }

  private void validateAggregateBudgetSpending(
      Map<UUID, BudgetBill> budgets, Map<UUID, NationSpendingReceipt> receipts) {
    Map<UUID, Map<BudgetCategory, BigDecimal>> allocated = new HashMap<>();
    for (BudgetBill budget : budgets.values()) {
      Map<BudgetCategory, BigDecimal> byCategory = new HashMap<>();
      for (BudgetEntry entry : budget.entries()) {
        byCategory.merge(entry.category(), entry.amount(), BigDecimal::add);
      }
      allocated.put(budget.billId(), byCategory);
    }

    Map<UUID, Map<BudgetCategory, BigDecimal>> spent = new HashMap<>();
    for (NationSpendingReceipt receipt : receipts.values()) {
      if (receipt.refunded() || receipt.budgetAmount().signum() == 0) {
        continue;
      }
      Map<BudgetCategory, BigDecimal> byCategory =
          spent.computeIfAbsent(receipt.budgetId(), ignored -> new HashMap<>());
      BigDecimal total =
          byCategory.merge(receipt.category(), receipt.budgetAmount(), BigDecimal::add);
      BigDecimal limit =
          allocated
              .getOrDefault(receipt.budgetId(), Map.of())
              .getOrDefault(receipt.category(), zero());
      if (total.compareTo(limit) > 0) {
        throw new IllegalArgumentException(
            "Persisted spending exceeds funded budget allocation: budget="
                + receipt.budgetId()
                + ", category="
                + receipt.category()
                + ", spent="
                + total.toPlainString()
                + ", allocated="
                + limit.toPlainString());
      }
    }
  }

  private Map<UUID, NationSpendingReceipt> synthesizeLegacyReceipts(Map<UUID, BudgetBill> budgets) {
    Map<UUID, NationSpendingReceipt> receipts = new LinkedHashMap<>();
    budgets.values().stream()
        .filter(budget -> budget.status() == BudgetBill.BudgetStatus.EXECUTED)
        .sorted(Comparator.comparing(budget -> budget.billId().toString()))
        .forEach(
            budget -> {
              for (BudgetEntry entry : budget.entries()) {
                UUID transactionId =
                    UUID.nameUUIDFromBytes(
                        ("legacy-budget:" + budget.billId() + ":" + entry.entryId())
                            .getBytes(StandardCharsets.UTF_8));
                Instant spentAt =
                    budget.approvedAt() == null ? entry.createdAt() : budget.approvedAt();
                NationSpendingReceipt receipt =
                    new NationSpendingReceipt(
                        transactionId,
                        budget.nationId(),
                        entry.category(),
                        entry.amount(),
                        entry.amount(),
                        zero(),
                        budget.billId(),
                        "Legacy executed allocation: " + entry.description(),
                        spentAt,
                        false);
                receipts.put(transactionId, receipt);
              }
            });
    return receipts;
  }

  private static String required(Properties properties, String key) {
    String value = properties.getProperty(key);
    if (value == null || value.isBlank()) {
      throw new IllegalArgumentException("Missing budget state property: " + key);
    }
    return value.trim();
  }

  private static int parseNonNegativeInt(String value, String name) {
    int parsed = parseInt(value, name);
    if (parsed < 0) {
      throw new IllegalArgumentException(name + " must be non-negative");
    }
    return parsed;
  }

  private static int parseInt(String value, String name) {
    try {
      return Integer.parseInt(value.trim());
    } catch (RuntimeException failure) {
      throw new IllegalArgumentException("Invalid integer for " + name + ": " + value, failure);
    }
  }

  private static UUID parseUuid(String value, String name) {
    try {
      return UUID.fromString(value.trim());
    } catch (RuntimeException failure) {
      throw new IllegalArgumentException("Invalid UUID for " + name + ": " + value, failure);
    }
  }

  private static BigDecimal parseMoney(String value, String name) {
    try {
      BigDecimal parsed = new BigDecimal(value.trim()).setScale(SCALE, RoundingMode.DOWN);
      if (parsed.signum() < 0) {
        throw new IllegalArgumentException(name + " must be non-negative");
      }
      return parsed;
    } catch (NumberFormatException failure) {
      throw new IllegalArgumentException("Invalid money value for " + name + ": " + value, failure);
    }
  }

  private static BigDecimal parsePositiveMoney(String value, String name) {
    BigDecimal parsed = parseMoney(value, name);
    if (parsed.signum() <= 0) {
      throw new IllegalArgumentException(name + " must be positive");
    }
    return parsed;
  }

  private static Instant parseOptionalInstant(String value) {
    String normalized = blankToNull(value);
    return normalized == null ? null : parseInstant(normalized, "instant");
  }

  private static Instant parseInstant(String value, String name) {
    try {
      return Instant.ofEpochMilli(Long.parseLong(value.trim()));
    } catch (RuntimeException failure) {
      throw new IllegalArgumentException("Invalid instant for " + name + ": " + value, failure);
    }
  }

  private static <E extends Enum<E>> E parseEnum(Class<E> type, String value, String name) {
    try {
      return Enum.valueOf(type, value.trim());
    } catch (RuntimeException failure) {
      throw new IllegalArgumentException("Invalid enum value for " + name + ": " + value, failure);
    }
  }

  private static String blankToNull(String value) {
    return value == null || value.isBlank() ? null : value.trim();
  }

  private static BigDecimal normalize(BigDecimal value) {
    Objects.requireNonNull(value, "value");
    BigDecimal normalized = value.setScale(SCALE, RoundingMode.DOWN);
    if (normalized.signum() < 0) {
      throw new IllegalArgumentException("money value must be non-negative");
    }
    return normalized;
  }

  private static BigDecimal zero() {
    return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
  }
}
