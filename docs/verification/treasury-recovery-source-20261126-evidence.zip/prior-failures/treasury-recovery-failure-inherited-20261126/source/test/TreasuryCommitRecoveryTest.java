package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.bukkit.plugin.java.JavaPlugin;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.sqlite.SQLiteDataSource;

class TreasuryCommitRecoveryTest {
  @TempDir Path directory;
  static final NationId PAYER = new NationId(new UUID(0, 1));
  static final NationId RECEIVER = new NationId(new UUID(0, 2));
  static final String DOMAIN = new UUID(0, 3).toString();

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  enum Action {
    TRANSFER,
    SPEND,
    CREDIT,
    REFUND,
    DEPOSIT,
    WITHDRAW;

    boolean apply(TreasuryModule module) {
      return switch (this) {
        case TRANSFER -> module.transfer(transfer()).applied();
        case SPEND -> module.spend(spend()).applied();
        case CREDIT -> module.credit(credit()).applied();
        case REFUND -> module.refund("refund");
        case DEPOSIT -> module.tryDeposit(RECEIVER, new BigDecimal("20.00"));
        case WITHDRAW -> module.withdraw(PAYER, new BigDecimal("20.00"));
      };
    }

    boolean observed(TreasuryModule module) {
      return switch (this) {
        case TRANSFER -> module.transferReceipt("transfer").isPresent();
        case SPEND -> module.spendingReceipt("spend").isPresent();
        case CREDIT -> module.creditReceipt("credit").isPresent();
        case REFUND -> module.spendingReceipt("refund").orElseThrow().refunded();
        case DEPOSIT -> module.balance(RECEIVER).compareTo(new BigDecimal("30.00")) == 0;
        case WITHDRAW -> module.balance(PAYER).compareTo(new BigDecimal("80.00")) == 0;
      };
    }

    void balances(TreasuryModule module, boolean applied) {
      String payer =
          !applied
              ? "100.00"
              : switch (this) {
                case TRANSFER, SPEND, WITHDRAW -> "80.00";
                case REFUND -> "105.00";
                default -> "100.00";
              };
      String receiver =
          applied && (this == TRANSFER || this == CREDIT || this == DEPOSIT) ? "30.00" : "10.00";
      assertEquals(new BigDecimal(payer), module.balance(PAYER));
      assertEquals(new BigDecimal(receiver), module.balance(RECEIVER));
    }
  }

  static Stream<Arguments> commits() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(
            engine ->
                Arrays.stream(Action.values())
                    .flatMap(
                        action ->
                            Stream.of(true, false)
                                .map(before -> Arguments.of(engine, action, before))));
  }

  @ParameterizedTest
  @MethodSource("commits")
  void failedAcknowledgementReconcilesWholeStateAndOriginalId(
      String engine, Action action, boolean before) throws Exception {
    var fixture = fixture(engine);
    var module = loaded(fixture.storage);
    fixture.fault.arm(before, false);
    assertEquals(!before, action.apply(module));
    action.balances(module, !before);
    assertEquals(!before, action.observed(module));
    assertEquals(DOMAIN, module.authorityDomainId());
    assertTrue(module.creditReceipt("preserved-credit").isPresent());
    assertTrue(module.transferReceipt("preserved-transfer").isPresent());
    var restarted = loaded(fixture.storage);
    action.balances(restarted, !before);
    if (action != Action.DEPOSIT && action != Action.WITHDRAW) {
      assertTrue(action.apply(restarted));
      assertTrue(action.apply(restarted));
      action.balances(restarted, true);
    }
  }

  static Stream<Arguments> quarantines() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(
            engine -> Arrays.stream(Action.values()).map(action -> Arguments.of(engine, action)));
  }

  @ParameterizedTest
  @MethodSource("quarantines")
  void unavailableReconciliationQuarantinesAllReadsWritesAndFlush(String engine, Action action)
      throws Exception {
    var fixture = fixture(engine);
    var module = loaded(fixture.storage);
    fixture.fault.arm(false, true);
    assertThrows(IllegalStateException.class, () -> action.apply(module));
    assertNull(module.authorityDomainId());
    fixture.fault.unreadable = false;
    Properties durable = fixture.storage.load();
    for (Action blocked : Action.values())
      assertThrows(IllegalStateException.class, () -> blocked.apply(module));
    assertThrows(IllegalStateException.class, () -> module.transferReceipt("absent"));
    assertThrows(IllegalStateException.class, () -> module.spendingReceipt("refund"));
    assertThrows(IllegalStateException.class, () -> module.creditReceipt("preserved-credit"));
    assertThrows(IllegalStateException.class, () -> module.balance(PAYER));
    assertFalse(module.refreshStateIfChanged());
    invoke(module, "flushState");
    assertEquals(durable, fixture.storage.load());
    var restarted = loaded(fixture.storage);
    assertEquals(DOMAIN, restarted.authorityDomainId());
    action.balances(restarted, true);
    assertTrue(action.observed(restarted));
  }

  static Stream<Arguments> readers() {
    return Arrays.stream(Action.values())
        .flatMap(
            action ->
                Stream.of("none", "before", "after").map(failure -> Arguments.of(action, failure)));
  }

  @ParameterizedTest
  @MethodSource("readers")
  void readerWaitsUntilSaveAndReconciliationFinish(Action action, String failure) throws Exception {
    var saving = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    var reading = new CountDownLatch(1);
    var armed = new AtomicBoolean();
    TreasuryStateStorage storage =
        new MemoryStorage() {
          @Override
          public void save(Properties value) {
            if (armed.getAndSet(false)) {
              saving.countDown();
              try {
                assertTrue(release.await(5, TimeUnit.SECONDS));
              } catch (InterruptedException error) {
                throw new IllegalStateException(error);
              }
              if (failure.equals("before")) throw new IllegalStateException("before write");
              super.save(value);
              if (failure.equals("after")) throw new IllegalStateException("after write");
            } else super.save(value);
          }
        };
    storage.save(seed());
    var module = loaded(storage);
    armed.set(true);
    try (var workers = Executors.newFixedThreadPool(2)) {
      try {
        var write = workers.submit(() -> action.apply(module));
        assertTrue(saving.await(5, TimeUnit.SECONDS));
        var read =
            workers.submit(
                () -> {
                  reading.countDown();
                  return action.observed(module);
                });
        assertTrue(reading.await(5, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> read.get(100, TimeUnit.MILLISECONDS));
        release.countDown();
        assertEquals(!failure.equals("before"), write.get(5, TimeUnit.SECONDS));
        assertEquals(!failure.equals("before"), read.get(5, TimeUnit.SECONDS));
      } finally {
        release.countDown();
      }
    }
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"changed-domain", "missing-domain", "bad-transfer", "bad-balance", "null-state"})
  void invalidCanonicalStateNeverBecomesProofOfAbsence(String corruption) throws Exception {
    var storage =
        new MemoryStorage() {
          @Override
          public void save(Properties value) {
            super.save(value);
            if (value.getProperty("transfer.count").equals("2")) {
              switch (corruption) {
                case "changed-domain" ->
                    state.setProperty("authorityDomainId", UUID.randomUUID().toString());
                case "missing-domain" -> state.remove("authorityDomainId");
                case "bad-transfer" -> state.setProperty("transfer.1.amount", "broken");
                case "bad-balance" -> state.setProperty("treasury.0.balance", "broken");
                case "null-state" -> state = null;
              }
              throw new IllegalStateException("lost acknowledgement with invalid recovery data");
            }
          }

          @Override
          public Properties load() {
            return state == null ? null : super.load();
          }
        };
    storage.save(seed());
    var module = loaded(storage);
    assertThrows(IllegalStateException.class, () -> module.transfer(transfer()));
    assertNull(module.authorityDomainId());
    assertThrows(IllegalStateException.class, () -> module.transferReceipt("transfer"));
  }

  static Properties seed() {
    return TreasuryStateCodec.toProperties(
        new TreasuryStateCodec.TreasuryState(
            DOMAIN,
            Map.of(PAYER, new BigDecimal("100.00"), RECEIVER, new BigDecimal("10.00")),
            Map.of(
                "refund",
                new NationSpendingService.SpendingReceipt(
                    "refund",
                    PAYER,
                    new BigDecimal("5.00"),
                    NationSpendingService.SpendingCategory.OTHER,
                    "original",
                    Instant.EPOCH)),
            Map.of(
                "preserved-credit",
                new NationCreditService.CreditReceipt(
                    "preserved-credit",
                    PAYER,
                    BigDecimal.ONE,
                    NationCreditService.CreditCategory.OTHER,
                    "original",
                    Instant.EPOCH)),
            Map.of(
                "preserved-transfer",
                new NationTransferService.TransferReceipt(
                    "preserved-transfer",
                    PAYER,
                    RECEIVER,
                    BigDecimal.ONE,
                    NationTransferService.TransferCategory.OTHER,
                    "original",
                    Instant.EPOCH))));
  }

  static NationTransferService.TransferRequest transfer() {
    return new NationTransferService.TransferRequest(
        "transfer",
        PAYER,
        RECEIVER,
        new BigDecimal("20.00"),
        NationTransferService.TransferCategory.OTHER,
        "recovery");
  }

  static NationSpendingService.SpendRequest spend() {
    return new NationSpendingService.SpendRequest(
        "spend",
        PAYER,
        new BigDecimal("20.00"),
        NationSpendingService.SpendingCategory.OTHER,
        "recovery");
  }

  static NationCreditService.CreditRequest credit() {
    return new NationCreditService.CreditRequest(
        "credit",
        RECEIVER,
        new BigDecimal("20.00"),
        NationCreditService.CreditCategory.OTHER,
        "recovery");
  }

  static TreasuryModule loaded(TreasuryStateStorage storage) throws Exception {
    var module = new TreasuryModule();
    Field field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    invoke(module, "loadState");
    return module;
  }

  static void invoke(TreasuryModule module, String name) throws Exception {
    Method method = TreasuryModule.class.getDeclaredMethod(name);
    method.setAccessible(true);
    try {
      method.invoke(module);
    } catch (InvocationTargetException error) {
      if (error.getCause() instanceof RuntimeException failure) throw failure;
      throw error;
    }
  }

  static class MemoryStorage implements TreasuryStateStorage {
    Properties state = new Properties();

    @Override
    public Properties load() {
      var result = new Properties();
      result.putAll(state);
      return result;
    }

    @Override
    public void save(Properties next) {
      state = new Properties();
      state.putAll(next);
    }
  }

  record Fixture(TreasuryStateStorage storage, Fault fault) {}

  static class Fault {
    AtomicBoolean armed = new AtomicBoolean();
    boolean before, failRead;
    volatile boolean unreadable;

    void arm(boolean before, boolean failRead) {
      this.before = before;
      this.failRead = failRead;
      armed.set(true);
    }
  }

  Fixture fixture(String engine) throws Exception {
    var fault = new Fault();
    TreasuryStateStorage storage;
    if (engine.equals("file")) {
      var plugin = mock(JavaPlugin.class);
      when(plugin.getDataFolder()).thenReturn(directory.toFile());
      when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
      var persistence =
          new PersistenceService(plugin, null) {
            @Override
            public Properties loadProperties(String namespace, String name) {
              if (fault.unreadable) throw new IllegalStateException("read unavailable");
              return super.loadProperties(namespace, name);
            }

            @Override
            public void saveProperties(String namespace, String name, Properties value) {
              boolean fail = fault.armed.getAndSet(false);
              if (fail && fault.before) throw new IllegalStateException("before file write");
              super.saveProperties(namespace, name, value);
              if (fail) {
                fault.unreadable = fault.failRead;
                throw new IllegalStateException("after file write");
              }
            }
          };
      persistence.start();
      storage = new PersistenceTreasuryStateStorage("test", persistence);
    } else {
      DataSource actual;
      if (engine.equals("sqlite")) {
        var source = new SQLiteDataSource();
        source.setUrl("jdbc:sqlite:" + directory.resolve("treasury.db"));
        actual = source;
      } else {
        var source = new JdbcDataSource();
        source.setURL("jdbc:h2:" + directory.resolve("treasury").toString().replace('\\', '/'));
        actual = source;
      }
      var source =
          (DataSource)
              Proxy.newProxyInstance(
                  getClass().getClassLoader(),
                  new Class<?>[] {DataSource.class},
                  (proxy, method, args) -> {
                    if (fault.unreadable) throw new SQLException("read unavailable");
                    Object result = forward(actual, method, args);
                    if (!(result instanceof Connection connection)) return result;
                    return Proxy.newProxyInstance(
                        getClass().getClassLoader(),
                        new Class<?>[] {Connection.class},
                        (p, call, values) -> {
                          boolean fail =
                              call.getName().equals("commit") && fault.armed.getAndSet(false);
                          if (fail && fault.before) throw new SQLException("before commit");
                          Object value = forward(connection, call, values);
                          if (fail) {
                            fault.unreadable = fault.failRead;
                            throw new SQLException("after commit");
                          }
                          return value;
                        });
                  });
      storage = new SqlTreasuryStateStorage(source, new Properties(), Logger.getAnonymousLogger());
      storage.load();
    }
    storage.save(seed());
    return new Fixture(storage, fault);
  }

  static Object forward(Object target, Method method, Object[] args) throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException error) {
      throw error.getCause();
    }
  }
}
