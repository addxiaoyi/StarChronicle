package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class TaxationServiceInputValidationTest {

  @Test
  void nullNationQueriesFailClosedWithoutCreatingConfiguration() {
    TaxationServiceImpl taxation = new TaxationServiceImpl();

    assertThat(taxation.getTaxConfigs(null)).isEmpty();
    assertThat(taxation.getTaxConfig(null, TaxType.LAND_TAX)).isNull();
    assertThat(taxation.getTaxConfigs(NationId.random())).isNotEmpty();
  }

  @Test
  void nullTaxTypeQueryReturnsNoConfiguration() {
    TaxationServiceImpl taxation = new TaxationServiceImpl();

    assertThat(taxation.getTaxConfig(NationId.random(), null)).isNull();
  }

  @Test
  void rejectsNegativeFixedTaxAmountAtConfigurationBoundary() {
    assertThatIllegalArgumentException()
        .isThrownBy(
            () ->
                new TaxConfig(
                    TaxType.BUSINESS_TAX,
                    true,
                    new BigDecimal("-0.01"),
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    1440,
                    false));
  }
}
