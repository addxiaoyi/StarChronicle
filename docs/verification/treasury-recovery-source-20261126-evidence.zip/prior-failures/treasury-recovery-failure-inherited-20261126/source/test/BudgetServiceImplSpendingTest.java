package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;

class BudgetServiceImplSpendingTest {

  @Test
  void idleInstanceRefreshesPublicReceiptsAndStatisticsBeforeReplayingSpend() {
    RecordingStorage shared = new RecordingStorage();
    BudgetStateStorage observerStorage =
        new BudgetStateStorage() {
          @Override
          public Properties load() {
            return shared.load();
          }

          @Override
          public void save(Properties value) {
            shared.save(value);
          }

          @Override
          public java.util.Optional<BudgetStateRefresh> refreshIfChanged() {
            return java.util.Optional.of(new BudgetStateRefresh(shared.load(), 1));
          }
        };
    TreasuryService treasury = mock(TreasuryService.class);
    when(treasury.withdraw(any(), any())).thenReturn(true);
    when(treasury.balance(any())).thenReturn(new BigDecimal("75.00"));
    Clock clock = Clock.fixed(Instant.parse("2026-11-05T12:00:00Z"), ZoneOffset.UTC);
    NationId nation = NationId.random();
    BudgetServiceImpl first = new BudgetServiceImpl(shared, treasury, clock);
    BudgetServiceImpl observer = new BudgetServiceImpl(observerStorage, treasury, clock);
    var request =
        new NationSpendingService.SpendRequest(
            "shared-policy",
            nation,
            new BigDecimal("25.00"),
            NationSpendingService.SpendingCategory.NATIONAL_EVENT,
            "policy");

    first.spend(request);

    assertThat(observer.spendingSnapshot(nation).orElseThrow().spent())
        .isEqualByComparingTo("25.00");
    assertThat(observer.spendingReceipt(request.transactionId())).isPresent();
    assertThat(observer.getMonthlySpending(nation, 2026, 11)).isEqualByComparingTo("25.00");
    assertThat(observer.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
    verify(treasury, times(1)).withdraw(nation, new BigDecimal("25.00"));
  }

  @Test
  void reportsNewAndRepeatedSpendsAccuratelyAcrossRestart() {
    RecordingStorage storage = new RecordingStorage();
    TreasuryService treasury = mock(TreasuryService.class);
    AtomicReference<BigDecimal> balance = new AtomicReference<>(new BigDecimal("100.00"));
    when(treasury.withdraw(any(), any()))
        .thenAnswer(
            invocation -> {
              BigDecimal amount = invocation.getArgument(1);
              if (balance.get().compareTo(amount) < 0) {
                return false;
              }
              balance.updateAndGet(value -> value.subtract(amount));
              return true;
            });
    when(treasury.balance(any())).thenAnswer(invocation -> balance.get());
    Clock clock = Clock.fixed(Instant.parse("2026-11-05T12:00:00Z"), ZoneOffset.UTC);
    NationId nationId = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "policy:paid:activation-1",
            nationId,
            new BigDecimal("25.00"),
            NationSpendingService.SpendingCategory.NATIONAL_EVENT,
            "policy activation");
    BudgetServiceImpl service = new BudgetServiceImpl(storage, treasury, clock);

    assertThat(service.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.APPLIED);
    assertThat(service.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);

    BudgetServiceImpl restarted = new BudgetServiceImpl(storage, treasury, clock);
    assertThat(restarted.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
    assertThat(balance.get()).isEqualByComparingTo("75.00");
    assertThat(restarted.spendingReceipt(request.transactionId())).isPresent();
    verify(treasury).withdraw(nationId, new BigDecimal("25.00"));
  }

  @Test
  void retriesRefundAfterRestartWithoutCreditingTreasuryTwice() {
    RecordingStorage storage = new RecordingStorage(2);
    TreasuryService treasury = mock(TreasuryService.class);
    AtomicReference<BigDecimal> balance = new AtomicReference<>(new BigDecimal("100.00"));
    when(treasury.withdraw(any(), any()))
        .thenAnswer(
            invocation -> {
              BigDecimal amount = invocation.getArgument(1);
              if (balance.get().compareTo(amount) < 0) {
                return false;
              }
              balance.updateAndGet(value -> value.subtract(amount));
              return true;
            });
    NationCreditService creditService = mock(NationCreditService.class);
    AtomicReference<NationCreditService.CreditReceipt> creditReceipt = new AtomicReference<>();
    when(creditService.credit(any()))
        .thenAnswer(
            invocation -> {
              NationCreditService.CreditRequest request = invocation.getArgument(0);
              NationCreditService.CreditReceipt existing = creditReceipt.get();
              if (existing != null) {
                assertEquals(existing.transactionId(), request.transactionId());
                return new NationCreditService.CreditResult(
                    NationCreditService.CreditStatus.ALREADY_APPLIED,
                    request.transactionId(),
                    balance.get());
              }
              balance.updateAndGet(value -> value.add(request.amount()));
              creditReceipt.set(
                  new NationCreditService.CreditReceipt(
                      request.transactionId(),
                      request.nationId(),
                      request.amount(),
                      request.category(),
                      request.description(),
                      Instant.now()));
              return new NationCreditService.CreditResult(
                  NationCreditService.CreditStatus.APPLIED, request.transactionId(), balance.get());
            });

    Clock clock = Clock.fixed(Instant.parse("2026-11-05T12:00:00Z"), ZoneOffset.UTC);
    NationId nationId = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "mercenary-hire:contract-refund-retry",
            nationId,
            new BigDecimal("25.00"),
            NationSpendingService.SpendingCategory.MILITARY,
            "mercenary hire");
    BudgetServiceImpl service = new BudgetServiceImpl(storage, treasury, creditService, clock);

    assertEquals(NationSpendingService.SpendingStatus.APPLIED, service.spend(request).status());
    assertThrows(IllegalStateException.class, () -> service.refund(request.transactionId()));
    assertFalse(service.spendingReceipt(request.transactionId()).orElseThrow().refunded());
    assertEquals(new BigDecimal("100.00"), balance.get());

    BudgetServiceImpl restarted = new BudgetServiceImpl(storage, treasury, creditService, clock);
    assertTrue(restarted.refund(request.transactionId()));
    assertTrue(restarted.spendingReceipt(request.transactionId()).orElseThrow().refunded());
    assertEquals(new BigDecimal("100.00"), balance.get());
    verify(creditService, times(2)).credit(any());
  }

  private static final class RecordingStorage implements BudgetStateStorage {
    private Properties properties = new Properties();
    private final int failAtSave;
    private int saves;

    private RecordingStorage() {
      this(-1);
    }

    private RecordingStorage(int failAtSave) {
      this.failAtSave = failAtSave;
    }

    @Override
    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(properties);
      return copy;
    }

    @Override
    public void save(Properties next) {
      saves++;
      if (saves == failAtSave) {
        throw new IllegalStateException("injected budget storage failure");
      }
      properties = new Properties();
      properties.putAll(next);
    }
  }
}
