package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class TaxQuoteFactoryTest {

    @Test
    void withholdsBusinessTaxFromGrossProceedsBeforePayingTheSeller() {
        NationId nationId = NationId.random();
        UUID sellerId = UUID.randomUUID();
        TaxConfig config = new TaxConfig(
            TaxType.BUSINESS_TAX, true, BigDecimal.ZERO, new BigDecimal("5"),
            BigDecimal.ZERO, 1440, false);
        UUID transactionId = UUID.randomUUID();

        TaxQuote quote = new TaxQuoteFactory().quote(
            transactionId, nationId, config, sellerId, new BigDecimal("100.00"));

        assertThat(quote.transactionId()).isEqualTo(transactionId);
        assertThat(quote.taxableAmount()).isEqualByComparingTo("100.00");
        assertThat(quote.taxAmount()).isEqualByComparingTo("5.00");
        assertThat(quote.netAmount()).isEqualByComparingTo("95.00");
    }

    @Test
    void neverWithholdsMoreThanTheGrossProceeds() {
        TaxConfig config = new TaxConfig(
            TaxType.BUSINESS_TAX, true, new BigDecimal("20.00"), BigDecimal.ZERO,
            BigDecimal.ZERO, 1440, false);

        TaxQuote quote = new TaxQuoteFactory().quote(
            UUID.randomUUID(), NationId.random(), config, UUID.randomUUID(),
            new BigDecimal("10.00"));

        assertThat(quote.taxAmount()).isEqualByComparingTo("10.00");
        assertThat(quote.netAmount()).isEqualByComparingTo("0.00");
    }
}
