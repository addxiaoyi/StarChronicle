package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class FundedTaxLedgerTest {

    @Test
    void claimsEachTransactionOnceAndAllowsRetryAfterFundingFailure() {
        FundedTaxLedger ledger = new FundedTaxLedger();
        TaxQuote quote = quote(UUID.randomUUID(), "5.00");

        assertThat(ledger.claim(quote)).isTrue();
        assertThat(ledger.claim(quote)).isFalse();

        ledger.release(quote);
        assertThat(ledger.claim(quote)).isTrue();
    }

    @Test
    void rejectsAReusedTransactionIdWithDifferentTaxDetails() {
        FundedTaxLedger ledger = new FundedTaxLedger();
        UUID transactionId = UUID.randomUUID();
        ledger.claim(quote(transactionId, "5.00"));

        assertThatThrownBy(() -> ledger.claim(quote(transactionId, "6.00")))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining(transactionId.toString());
    }

    private TaxQuote quote(UUID transactionId, String taxAmount) {
        return new TaxQuote(
            transactionId,
            NationId.random(),
            TaxType.BUSINESS_TAX,
            UUID.randomUUID(),
            new BigDecimal("100.00"),
            new BigDecimal(taxAmount)
        );
    }
}
