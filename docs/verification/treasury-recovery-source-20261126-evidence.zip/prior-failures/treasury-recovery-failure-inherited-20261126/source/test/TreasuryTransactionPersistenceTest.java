package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import org.junit.jupiter.api.Test;

class TreasuryTransactionPersistenceTest {

  @Test
  void depositRollsBackWhenSynchronousPersistenceFails() throws Exception {
    TreasuryModule module = moduleWith(new SequencedStorage(Set.of(1, 2)));
    NationId nationId = NationId.random();

    assertFalse(module.tryDeposit(nationId, new BigDecimal("25.00")));
    assertMoney("0.00", module.balance(nationId));
    assertThrows(
        IllegalStateException.class, () -> module.deposit(nationId, new BigDecimal("25.00")));
    assertMoney("0.00", module.balance(nationId));
  }

  @Test
  void withdrawRollsBackWhenSynchronousPersistenceFails() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(2));
    TreasuryModule module = moduleWith(storage);
    NationId nationId = NationId.random();

    assertTrue(module.tryDeposit(nationId, new BigDecimal("40.00")));
    assertFalse(module.withdraw(nationId, new BigDecimal("10.00")));
    assertMoney("40.00", module.balance(nationId));
  }

  @Test
  void transferCompensatesPayerWhenReceiverPersistenceFails() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(3));
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();

    assertTrue(module.tryDeposit(payer, new BigDecimal("100.00")));
    assertTrue(module.tryDeposit(receiver, new BigDecimal("10.00")));

    assertFalse(module.transfer(payer, receiver, new BigDecimal("30.00")));
    assertMoney("100.00", module.balance(payer));
    assertMoney("10.00", module.balance(receiver));
    assertEquals(3, storage.saveCount());
  }

  @Test
  void transferRemainsAtomicWhenPersistenceFailsAgain() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(3, 4));
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();

    assertTrue(module.tryDeposit(payer, new BigDecimal("100.00")));
    assertTrue(module.tryDeposit(receiver, new BigDecimal("10.00")));

    assertFalse(module.transfer(payer, receiver, new BigDecimal("30.00")));
    assertMoney("100.00", module.balance(payer));
    assertMoney("10.00", module.balance(receiver));
  }

  @Test
  void idempotentSpendAndCreditSurviveRestart() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of());
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationSpendingService.SpendRequest spend =
        new NationSpendingService.SpendRequest(
            "territory-rent:contract-a:period-1:debit",
            payer,
            new BigDecimal("25.00"),
            NationSpendingService.SpendingCategory.TERRITORY_RENT,
            "daily rent");
    NationCreditService.CreditRequest credit =
        new NationCreditService.CreditRequest(
            "territory-rent:contract-a:period-1:credit",
            receiver,
            new BigDecimal("25.00"),
            NationCreditService.CreditCategory.TERRITORY_RENT,
            "daily rent");

    assertTrue(module.tryDeposit(payer, new BigDecimal("100.00")));
    assertEquals(NationSpendingService.SpendingStatus.APPLIED, module.spend(spend).status());
    assertEquals(
        NationSpendingService.SpendingStatus.ALREADY_APPLIED, module.spend(spend).status());
    assertEquals(NationCreditService.CreditStatus.APPLIED, module.credit(credit).status());
    assertEquals(NationCreditService.CreditStatus.ALREADY_APPLIED, module.credit(credit).status());
    assertEquals(3, storage.saveCount());

    TreasuryModule restarted = loadedModuleWith(storage);
    assertMoney("75.00", restarted.balance(payer));
    assertMoney("25.00", restarted.balance(receiver));
    assertTrue(restarted.hasSpendingReceipt(spend.transactionId()));
    assertTrue(restarted.hasCreditReceipt(credit.transactionId()));
    assertEquals(
        NationSpendingService.SpendingStatus.ALREADY_APPLIED, restarted.spend(spend).status());
    assertEquals(
        NationCreditService.CreditStatus.ALREADY_APPLIED, restarted.credit(credit).status());
    assertMoney("75.00", restarted.balance(payer));
    assertMoney("25.00", restarted.balance(receiver));
    assertEquals(3, storage.saveCount());
  }

  @Test
  void spendingRefundRemainsIdempotentAndVisibleAcrossRestart() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of());
    TreasuryModule module = moduleWith(storage);
    NationId nationId = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "mercenary-hire:contract-a",
            nationId,
            new BigDecimal("20.00"),
            NationSpendingService.SpendingCategory.MILITARY,
            "mercenary hire");

    assertTrue(module.tryDeposit(nationId, new BigDecimal("50.00")));
    assertEquals(NationSpendingService.SpendingStatus.APPLIED, module.spend(request).status());
    assertTrue(module.refund(request.transactionId()));
    assertTrue(module.spendingReceipt(request.transactionId()).orElseThrow().refunded());
    assertMoney("50.00", module.balance(nationId));

    TreasuryModule restarted = loadedModuleWith(storage);
    assertTrue(restarted.spendingReceipt(request.transactionId()).orElseThrow().refunded());
    assertTrue(restarted.refund(request.transactionId()));
    assertEquals(NationSpendingService.SpendingStatus.REJECTED, restarted.spend(request).status());
    assertMoney("50.00", restarted.balance(nationId));
    assertEquals(3, storage.saveCount());
  }

  @Test
  void idempotentAtomicTransferSurvivesRestart() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of());
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "reparation:agreement-a:installment-1",
            payer,
            receiver,
            new BigDecimal("30.00"),
            NationTransferService.TransferCategory.REPARATION,
            "war reparation installment");

    assertTrue(module.tryDeposit(payer, new BigDecimal("100.00")));
    assertEquals(NationTransferService.TransferStatus.APPLIED, module.transfer(request).status());
    assertEquals(
        NationTransferService.TransferStatus.ALREADY_APPLIED, module.transfer(request).status());
    assertMoney("70.00", module.balance(payer));
    assertMoney("30.00", module.balance(receiver));
    assertEquals(2, storage.saveCount());

    TreasuryModule restarted = loadedModuleWith(storage);
    assertTrue(restarted.hasTransferReceipt(request.transactionId()));
    assertEquals(
        NationTransferService.TransferStatus.ALREADY_APPLIED, restarted.transfer(request).status());
    assertMoney("70.00", restarted.balance(payer));
    assertMoney("30.00", restarted.balance(receiver));
    assertEquals(2, storage.saveCount());
  }

  @Test
  void atomicTransferInsufficientFundsDoesNotPersist() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of());
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "tribute:agreement-b:period-1",
            payer,
            receiver,
            new BigDecimal("25.00"),
            NationTransferService.TransferCategory.TRIBUTE,
            "monthly tribute");

    NationTransferService.TransferResult result = module.transfer(request);

    assertEquals(NationTransferService.TransferStatus.INSUFFICIENT_FUNDS, result.status());
    assertFalse(module.hasTransferReceipt(request.transactionId()));
    assertMoney("0.00", module.balance(payer));
    assertMoney("0.00", module.balance(receiver));
    assertEquals(0, storage.saveCount());
  }

  @Test
  void atomicTransferPersistenceFailureRollsBackBothBalancesAndReceipt() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(3));
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "reparation:agreement-c:installment-1",
            payer,
            receiver,
            new BigDecimal("20.00"),
            NationTransferService.TransferCategory.REPARATION,
            "war reparation installment");

    assertTrue(module.tryDeposit(payer, new BigDecimal("50.00")));
    assertTrue(module.tryDeposit(receiver, new BigDecimal("5.00")));
    NationTransferService.TransferResult result = module.transfer(request);

    assertEquals(NationTransferService.TransferStatus.REJECTED, result.status());
    assertFalse(module.hasTransferReceipt(request.transactionId()));
    assertMoney("50.00", module.balance(payer));
    assertMoney("5.00", module.balance(receiver));
  }

  @Test
  void insufficientSpendDoesNotCreateReceiptOrPersist() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of());
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "territory-rent:contract-b:period-1:debit",
            payer,
            new BigDecimal("10.00"),
            NationSpendingService.SpendingCategory.TERRITORY_RENT,
            "daily rent");

    NationSpendingService.SpendResult outcome = module.spend(request);

    assertEquals(NationSpendingService.SpendingStatus.INSUFFICIENT_FUNDS, outcome.status());
    assertFalse(module.hasSpendingReceipt(request.transactionId()));
    assertMoney("0.00", module.balance(payer));
    assertEquals(0, storage.saveCount());
  }

  @Test
  void spendPersistenceFailureRollsBackBalanceAndReceipt() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(2));
    TreasuryModule module = moduleWith(storage);
    NationId payer = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "territory-rent:contract-c:period-1:debit",
            payer,
            new BigDecimal("20.00"),
            NationSpendingService.SpendingCategory.TERRITORY_RENT,
            "daily rent");

    assertTrue(module.tryDeposit(payer, new BigDecimal("50.00")));
    NationSpendingService.SpendResult outcome = module.spend(request);

    assertEquals(NationSpendingService.SpendingStatus.REJECTED, outcome.status());
    assertMoney("50.00", module.balance(payer));
    assertFalse(module.hasSpendingReceipt(request.transactionId()));
  }

  @Test
  void creditPersistenceFailureRollsBackBalanceAndReceipt() throws Exception {
    SequencedStorage storage = new SequencedStorage(Set.of(1));
    TreasuryModule module = moduleWith(storage);
    NationId receiver = NationId.random();
    NationCreditService.CreditRequest request =
        new NationCreditService.CreditRequest(
            "territory-rent:contract-d:period-1:credit",
            receiver,
            new BigDecimal("20.00"),
            NationCreditService.CreditCategory.TERRITORY_RENT,
            "daily rent");

    NationCreditService.CreditResult outcome = module.credit(request);

    assertEquals(NationCreditService.CreditStatus.REJECTED, outcome.status());
    assertMoney("0.00", module.balance(receiver));
    assertFalse(module.hasCreditReceipt(request.transactionId()));
  }

  private static TreasuryModule moduleWith(TreasuryStateStorage storage) throws Exception {
    TreasuryModule module = new TreasuryModule();
    Field field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    return module;
  }

  private static TreasuryModule loadedModuleWith(TreasuryStateStorage storage) throws Exception {
    TreasuryModule module = moduleWith(storage);
    Method loadState = TreasuryModule.class.getDeclaredMethod("loadState");
    loadState.setAccessible(true);
    loadState.invoke(module);
    return module;
  }

  private static void assertMoney(String expected, BigDecimal actual) {
    assertEquals(0, new BigDecimal(expected).compareTo(actual));
  }

  private static final class SequencedStorage implements TreasuryStateStorage {
    private final Set<Integer> failingSaves;
    private int saveCount;
    private Properties persisted = new Properties();

    private SequencedStorage(Set<Integer> failingSaves) {
      this.failingSaves = new HashSet<>(failingSaves);
    }

    @Override
    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(persisted);
      return copy;
    }

    @Override
    public void save(Properties properties) {
      saveCount++;
      if (failingSaves.contains(saveCount)) {
        throw new IllegalStateException("Injected treasury persistence failure #" + saveCount);
      }
      Properties copy = new Properties();
      copy.putAll(properties);
      persisted = copy;
    }

    private int saveCount() {
      return saveCount;
    }
  }
}
