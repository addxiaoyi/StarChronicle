package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxPayer;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class TaxationServiceProviderMatrixTest {

    @Test
    void rejectedTreasuryCreditRefundsEverySuccessfulProviderWithdrawal() throws Exception {
        EconomyService economy = mock(EconomyService.class);
        TreasuryService treasury = mock(TreasuryService.class);
        UUID payer = UUID.randomUUID();
        NationId nation = NationId.random();
        when(economy.withdraw(payer, new BigDecimal("5.00"))).thenReturn(true);
        when(economy.deposit(payer, new BigDecimal("5.00"))).thenReturn(true);
        when(treasury.tryDeposit(nation, new BigDecimal("5.00"))).thenReturn(false);
        TaxationServiceImpl taxes = taxation(economy, treasury, nation);

        BigDecimal collected = taxes.collectTax(
            nation,
            TaxType.BUSINESS_TAX,
            new TaxContext(
                0, 0, 1, new BigDecimal("100.00"), List.of(),
                List.of(new TaxPayer(payer, new BigDecimal("100.00"))), List.of())
        );

        assertThat(collected).isEqualByComparingTo("0.00");
        verify(economy).withdraw(payer, new BigDecimal("5.00"));
        verify(economy).deposit(payer, new BigDecimal("5.00"));
        verify(treasury).tryDeposit(nation, new BigDecimal("5.00"));
    }

    @Test
    void concurrentCollectionCannotChargeTheSameAvailableBalanceTwice() throws Exception {
        EconomyService economy = mock(EconomyService.class);
        TreasuryService treasury = mock(TreasuryService.class);
        UUID payer = UUID.randomUUID();
        NationId nation = NationId.random();
        AtomicReference<BigDecimal> balance = new AtomicReference<>(new BigDecimal("5.00"));
        Object lock = new Object();
        when(economy.withdraw(eq(payer), eq(new BigDecimal("5.00")))).thenAnswer(invocation -> {
            synchronized (lock) {
                if (balance.get().compareTo(new BigDecimal("5.00")) < 0) {
                    return false;
                }
                balance.set(balance.get().subtract(new BigDecimal("5.00")));
                return true;
            }
        });
        when(treasury.tryDeposit(nation, new BigDecimal("5.00"))).thenReturn(true);
        TaxationServiceImpl taxes = taxation(economy, treasury, nation);
        TaxContext context = new TaxContext(
            0, 0, 1, new BigDecimal("100.00"), List.of(),
            List.of(new TaxPayer(payer, new BigDecimal("100.00"))), List.of());

        CountDownLatch start = new CountDownLatch(1);
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            Future<BigDecimal> first = pool.submit(() -> {
                start.await();
                return taxes.collectTax(nation, TaxType.BUSINESS_TAX, context);
            });
            Future<BigDecimal> second = pool.submit(() -> {
                start.await();
                return taxes.collectTax(nation, TaxType.BUSINESS_TAX, context);
            });
            start.countDown();

            BigDecimal total = first.get().add(second.get());
            assertThat(total).isEqualByComparingTo("5.00");
        } finally {
            pool.shutdownNow();
        }

        assertThat(balance.get()).isEqualByComparingTo("0.00");
        verify(treasury, times(1)).tryDeposit(nation, new BigDecimal("5.00"));
    }

    private TaxationServiceImpl taxation(
        EconomyService economy,
        TreasuryService treasury,
        NationId nation
    ) throws ReflectiveOperationException {
        ServiceRegistry services = new ServiceRegistry();
        services.register(EconomyService.class, economy);
        services.register(TreasuryService.class, treasury);
        JavaPlugin plugin = mock(JavaPlugin.class);
        when(plugin.getLogger()).thenReturn(Logger.getLogger(
            TaxationServiceProviderMatrixTest.class.getName()));
        StarCoreContext context = new StarCoreContext(
            plugin, null, null, null, null, null,
            null, null, null, null, services
        );

        TaxationServiceImpl taxes = new TaxationServiceImpl();
        Field currentContext = TaxationServiceImpl.class.getDeclaredField("currentContext");
        currentContext.setAccessible(true);
        currentContext.set(taxes, context);
        taxes.getTaxConfigs(nation).put(
            TaxType.BUSINESS_TAX,
            new TaxConfig(
                TaxType.BUSINESS_TAX, true, BigDecimal.ZERO,
                new BigDecimal("5.00"), BigDecimal.ZERO, 1440, false)
        );
        return taxes;
    }
}
