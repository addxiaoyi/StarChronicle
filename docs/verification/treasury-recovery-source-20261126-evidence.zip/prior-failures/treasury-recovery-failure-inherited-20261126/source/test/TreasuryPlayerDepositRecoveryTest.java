package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.transaction.PendingRefund;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TreasuryPlayerDepositRecoveryTest {
  @TempDir Path temporaryDirectory;

  @org.junit.jupiter.params.ParameterizedTest
  @org.junit.jupiter.params.provider.ValueSource(booleans = {false, true})
  void lostTreasuryAcknowledgementNeverTriggersAnUnverifiedPlayerRefund(boolean unreadable)
      throws Exception {
    UUID player = UUID.randomUUID();
    BigDecimal amount = new BigDecimal("20.00");
    var economy = mock(InternalEconomyService.class);
    when(economy.withdraw(player, amount)).thenReturn(true);
    var ledger = new RefundLedger(temporaryDirectory.resolve("refunds.properties"), logger());
    var module = module(economy, ledger, logger());
    var armed = new java.util.concurrent.atomic.AtomicBoolean();
    var failed = new java.util.concurrent.atomic.AtomicBoolean();
    var storage =
        new TreasuryCommitRecoveryTest.MemoryStorage() {
          @Override
          public void save(Properties value) {
            super.save(value);
            if (armed.getAndSet(false)) {
              failed.set(true);
              throw new IllegalStateException("committed credit but response lost");
            }
          }

          @Override
          public Properties load() {
            if (unreadable && failed.get()) throw new IllegalStateException("recovery unavailable");
            return super.load();
          }
        };
    storage.save(TreasuryCommitRecoveryTest.seed());
    setField(module, "stateStorage", storage);
    TreasuryCommitRecoveryTest.invoke(module, "loadState");
    armed.set(true);
    var result =
        module.depositFromPlayerResult(player, TreasuryCommitRecoveryTest.RECEIVER, amount);
    assertEquals(
        unreadable
            ? TreasuryModule.PlayerDepositStatus.MANUAL_REVIEW
            : TreasuryModule.PlayerDepositStatus.COMPLETED,
        result.status());
    org.mockito.Mockito.verify(economy, org.mockito.Mockito.never()).deposit(player, amount);
    if (unreadable) {
      var restored = new RefundLedger(temporaryDirectory.resolve("refunds.properties"), logger());
      assertTrue(restored.snapshot().getFirst().manualReview());
      assertEquals(result.transactionId(), restored.snapshot().getFirst().transactionId());
      assertTrue(restored.due(Instant.now().plusSeconds(10), RefundOwner.NATION).isEmpty());
    } else assertTrue(ledger.snapshot().isEmpty());
    failed.set(false);
    var restarted = TreasuryCommitRecoveryTest.loaded(storage);
    assertEquals(new BigDecimal("30.00"), restarted.balance(TreasuryCommitRecoveryTest.RECEIVER));
    assertTrue(restarted.hasCreditReceipt("treasury:player-deposit:" + result.transactionId()));
  }

  @Test
  void rejectedImmediateRefundIsPersistedAndRetriedAfterRecoveryWindow() throws Exception {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    BigDecimal amount = new BigDecimal("25.00");
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.withdraw(playerId, amount)).thenReturn(true);
    when(economy.deposit(playerId, amount)).thenReturn(false, true);
    RefundLedger ledger =
        new RefundLedger(temporaryDirectory.resolve("refunds.properties"), logger());
    TreasuryModule module = module(economy, ledger, logger());
    setField(module, "stateStorage", new RejectingStorage());

    TreasuryModule.PlayerDepositResult result =
        module.depositFromPlayerResult(playerId, nationId, amount);

    assertEquals(TreasuryModule.PlayerDepositStatus.REFUND_PENDING, result.status());
    assertTrue(result.transactionId() != null);
    PendingRefund pending = ledger.snapshot().getFirst();
    assertEquals(result.transactionId(), pending.transactionId());
    assertEquals(playerId, pending.accountId());
    assertEquals(0, pending.amount().compareTo(amount));
    assertEquals(RefundOwner.NATION, pending.owner());
    assertTrue(pending.reason().startsWith("treasury-player-deposit:"));

    assertEquals(1, module.retryPendingPlayerDepositRefunds(Instant.now().plusSeconds(5)));
    assertTrue(ledger.snapshot().isEmpty());
    assertFalse(ledger.isDeliveryAttemptActive(result.transactionId()));
    verify(economy, times(2)).deposit(playerId, amount);
  }

  @Test
  void successfulImmediateRefundIsReportedWithoutCreatingRetryEntry() throws Exception {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    BigDecimal amount = new BigDecimal("10.00");
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.withdraw(playerId, amount)).thenReturn(true);
    when(economy.deposit(playerId, amount)).thenReturn(true);
    RefundLedger ledger =
        new RefundLedger(temporaryDirectory.resolve("refunds.properties"), logger());
    TreasuryModule module = module(economy, ledger, logger());
    setField(module, "stateStorage", new RejectingStorage());

    TreasuryModule.PlayerDepositResult result =
        module.depositFromPlayerResult(playerId, nationId, amount);

    assertEquals(TreasuryModule.PlayerDepositStatus.REFUNDED, result.status());
    assertTrue(ledger.snapshot().isEmpty());
    verify(economy).deposit(playerId, amount);
  }

  @Test
  void refundRetryPersistsInterruptionMarkerBeforeCreditingPlayer() throws Exception {
    UUID playerId = UUID.randomUUID();
    BigDecimal amount = new BigDecimal("17.00");
    InternalEconomyService economy = mock(InternalEconomyService.class);
    RefundLedger ledger =
        new RefundLedger(temporaryDirectory.resolve("refunds.properties"), logger());
    ledger.record(pendingRefund(playerId, amount));
    doAnswer(
            invocation -> {
              assertTrue(ledger.snapshot().getFirst().manualReview());
              return true;
            })
        .when(economy)
        .deposit(playerId, amount);
    TreasuryModule module = module(economy, ledger, logger());

    assertEquals(1, module.retryPendingPlayerDepositRefunds(Instant.now()));

    assertTrue(ledger.snapshot().isEmpty());
    verify(economy).deposit(playerId, amount);
  }

  @Test
  void uncertainRefundRetrySurvivesRestartInManualReview() throws Exception {
    UUID playerId = UUID.randomUUID();
    BigDecimal amount = new BigDecimal("17.00");
    Path ledgerFile = temporaryDirectory.resolve("refunds.properties");
    RefundLedger ledger = new RefundLedger(ledgerFile, logger());
    ledger.record(pendingRefund(playerId, amount));
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.deposit(playerId, amount))
        .thenThrow(new IllegalStateException("injected uncertain delivery result"));
    TreasuryModule module = module(economy, ledger, logger());

    assertEquals(0, module.retryPendingPlayerDepositRefunds(Instant.now()));

    RefundLedger recoveredLedger = new RefundLedger(ledgerFile, logger());
    PendingRefund recovered = recoveredLedger.snapshot().getFirst();
    assertTrue(recovered.manualReview());
    assertFalse(recoveredLedger.due(Instant.now(), RefundOwner.NATION).contains(recovered));
    assertFalse(ledger.isDeliveryAttemptActive(recovered.transactionId()));
    verify(economy).deposit(playerId, amount);
  }

  @Test
  void missingRefundLedgerSurfacesManualReviewInsteadOfClaimingNoBalanceChange() throws Exception {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    BigDecimal amount = new BigDecimal("5.00");
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.withdraw(playerId, amount)).thenReturn(true);
    when(economy.deposit(playerId, amount)).thenReturn(false);
    TreasuryModule module = module(economy, null, logger());
    setField(module, "stateStorage", new RejectingStorage());

    TreasuryModule.PlayerDepositResult result =
        module.depositFromPlayerResult(playerId, nationId, amount);

    assertEquals(TreasuryModule.PlayerDepositStatus.MANUAL_REVIEW, result.status());
    assertTrue(result.transactionId() != null);
  }

  @Test
  void ledgerWriteFailureIsReportedAsManualReview() throws Exception {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    BigDecimal amount = new BigDecimal("5.00");
    InternalEconomyService economy = mock(InternalEconomyService.class);
    when(economy.withdraw(playerId, amount)).thenReturn(true);
    when(economy.deposit(playerId, amount)).thenReturn(false);
    Path nonDirectory = temporaryDirectory.resolve("not-a-directory");
    Files.writeString(nonDirectory, "file");
    RefundLedger ledger = new RefundLedger(nonDirectory.resolve("refunds.properties"), logger());
    TreasuryModule module = module(economy, ledger, logger());
    setField(module, "stateStorage", new RejectingStorage());

    TreasuryModule.PlayerDepositResult result =
        module.depositFromPlayerResult(playerId, nationId, amount);

    assertEquals(TreasuryModule.PlayerDepositStatus.MANUAL_REVIEW, result.status());
    assertTrue(result.transactionId() != null);
  }

  private static TreasuryModule module(
      InternalEconomyService economy, RefundLedger ledger, Logger logger) throws Exception {
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    ServiceRegistry services = new ServiceRegistry();
    StarCoreContext context =
        new StarCoreContext(
            plugin, null, null, null, null, null, null, null, economy, null, services);
    TreasuryModule module = new TreasuryModule();
    setField(module, "currentContext", context);
    setField(module, "refundLedger", ledger);
    setField(module, "stateStorage", new RejectingStorage());
    return module;
  }

  private static PendingRefund pendingRefund(UUID playerId, BigDecimal amount) {
    return new PendingRefund(
            UUID.randomUUID(),
            playerId,
            amount,
            "treasury-player-deposit:test",
            0,
            Instant.EPOCH,
            "injected pending refund")
        .ownedBy(RefundOwner.NATION);
  }

  private static void setField(TreasuryModule module, String name, Object value) throws Exception {
    Field field = TreasuryModule.class.getDeclaredField(name);
    field.setAccessible(true);
    field.set(module, value);
  }

  private static Logger logger() {
    Logger logger = Logger.getAnonymousLogger();
    logger.setUseParentHandlers(false);
    return logger;
  }

  private static final class RejectingStorage implements TreasuryStateStorage {
    @Override
    public Properties load() {
      return new Properties();
    }

    @Override
    public void save(Properties properties) {
      throw new IllegalStateException("injected treasury persistence failure");
    }
  }
}
