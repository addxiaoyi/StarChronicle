package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;

import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import org.junit.jupiter.api.Test;

class NationTransferEconomyStateTest {
  @Test
  void transferStatusesMapToCanonicalStates() {
    assertEquals(
        EconomyTransactionState.COMMITTED,
        NationTransferService.TransferStatus.APPLIED.economyState());
    assertEquals(
        EconomyTransactionState.COMMITTED,
        NationTransferService.TransferStatus.ALREADY_APPLIED.economyState());
    assertEquals(
        EconomyTransactionState.DEBIT_FAILED,
        NationTransferService.TransferStatus.INSUFFICIENT_FUNDS.economyState());
    assertEquals(
        EconomyTransactionState.CANCELLED,
        NationTransferService.TransferStatus.REJECTED.economyState());
  }
}
