package dev.starcore.starcore.module.treasury;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class TaxCollectionWindowTest {

    @Test
    void blocksRepeatedCollectionUntilTheConfiguredIntervalEnds() {
        Instant now = Instant.parse("2026-07-19T00:00:00Z");

        TaxCollectionWindow recent = new TaxCollectionWindow(
            now.minus(Duration.ofMinutes(30)), 60, now);
        TaxCollectionWindow due = new TaxCollectionWindow(
            now.minus(Duration.ofMinutes(61)), 60, now);

        assertThat(recent.isDue()).isFalse();
        assertThat(due.isDue()).isTrue();
        assertThat(due.period(Duration.ofDays(30))).isEqualTo(Duration.ofMinutes(61));
    }

    @Test
    void firstCollectionUsesTheExplicitBootstrapPeriod() {
        Instant now = Instant.parse("2026-07-19T00:00:00Z");
        TaxCollectionWindow first = new TaxCollectionWindow(null, 1440, now);

        assertThat(first.isDue()).isTrue();
        assertThat(first.period(Duration.ofDays(30))).isEqualTo(Duration.ofDays(30));
    }

    @Test
    void rejectsNonPositiveIntervals() {
        Instant now = Instant.parse("2026-07-19T00:00:00Z");

        assertThatIllegalArgumentException()
            .isThrownBy(() -> new TaxCollectionWindow(null, 0, now));
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new TaxCollectionWindow(null, -1, now));
    }
}
