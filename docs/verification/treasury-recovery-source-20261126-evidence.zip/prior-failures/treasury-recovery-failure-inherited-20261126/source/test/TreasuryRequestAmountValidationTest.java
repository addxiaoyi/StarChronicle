package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.time.Instant;
import org.junit.jupiter.api.Test;

class TreasuryRequestAmountValidationTest {
  private static final BigDecimal SUB_CENT = new BigDecimal("0.001");

  @Test
  void spendingRequestRejectsAmountsBelowOneCent() {
    assertThrows(
        IllegalArgumentException.class,
        () ->
            new NationSpendingService.SpendRequest(
                "spend-1",
                NationId.random(),
                SUB_CENT,
                NationSpendingService.SpendingCategory.OTHER,
                "test"));
  }

  @Test
  void creditRequestRejectsAmountsBelowOneCent() {
    assertThrows(
        IllegalArgumentException.class,
        () ->
            new NationCreditService.CreditRequest(
                "credit-1",
                NationId.random(),
                SUB_CENT,
                NationCreditService.CreditCategory.OTHER,
                "test"));
  }

  @Test
  void transferRequestRejectsAmountsBelowOneCent() {
    assertThrows(
        IllegalArgumentException.class,
        () ->
            new NationTransferService.TransferRequest(
                "transfer-1",
                NationId.random(),
                NationId.random(),
                SUB_CENT,
                NationTransferService.TransferCategory.OTHER,
                "test"));
  }

  @Test
  void spendingRequestNormalizesAmountsToCentsBeforeReceiptMatching() {
    NationId nationId = NationId.random();
    NationSpendingService.SpendRequest request =
        new NationSpendingService.SpendRequest(
            "spend-precision",
            nationId,
            new BigDecimal("12.349"),
            NationSpendingService.SpendingCategory.OTHER,
            "test");
    NationSpendingService.SpendingReceipt receipt =
        new NationSpendingService.SpendingReceipt(
            "spend-precision",
            nationId,
            new BigDecimal("12.34"),
            NationSpendingService.SpendingCategory.OTHER,
            "test",
            Instant.now());

    assertTrue(receipt.matches(request));
  }

  @Test
  void creditRequestNormalizesAmountsToCentsBeforeReceiptMatching() {
    NationId nationId = NationId.random();
    NationCreditService.CreditRequest request =
        new NationCreditService.CreditRequest(
            "credit-precision",
            nationId,
            new BigDecimal("12.349"),
            NationCreditService.CreditCategory.OTHER,
            "test");
    NationCreditService.CreditReceipt receipt =
        new NationCreditService.CreditReceipt(
            "credit-precision",
            nationId,
            new BigDecimal("12.34"),
            NationCreditService.CreditCategory.OTHER,
            "test",
            Instant.now());

    assertTrue(receipt.matches(request));
  }

  @Test
  void transferRequestNormalizesAmountsToCentsBeforeReceiptMatching() {
    NationId payerId = NationId.random();
    NationId receiverId = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "transfer-precision",
            payerId,
            receiverId,
            new BigDecimal("12.349"),
            NationTransferService.TransferCategory.OTHER,
            "test");
    NationTransferService.TransferReceipt receipt =
        new NationTransferService.TransferReceipt(
            "transfer-precision",
            payerId,
            receiverId,
            new BigDecimal("12.34"),
            NationTransferService.TransferCategory.OTHER,
            "test",
            Instant.now());

    assertTrue(receipt.matches(request));
  }
}
