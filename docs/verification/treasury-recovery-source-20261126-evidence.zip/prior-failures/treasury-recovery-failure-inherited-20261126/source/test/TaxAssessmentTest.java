package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.module.treasury.TaxationService.PlayerIncome;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxPayer;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class TaxAssessmentTest {

    @Test
    void assessesEveryTaxAgainstAnExplicitPayer() {
        UUID alice = UUID.randomUUID();
        UUID bob = UUID.randomUUID();
        UUID carol = UUID.randomUUID();
        TaxContext context = new TaxContext(
            1,
            3,
            2,
            new BigDecimal("350.00"),
            List.of(
                new PlayerIncome(alice, new BigDecimal("100.00"), new BigDecimal("1000.00")),
                new PlayerIncome(bob, new BigDecimal("50.00"), new BigDecimal("1000.00")),
                new PlayerIncome(carol, BigDecimal.ZERO, new BigDecimal("1000.00"))
            ),
            List.of(
                new TaxPayer(alice, new BigDecimal("200.00")),
                new TaxPayer(bob, new BigDecimal("100.00"))
            ),
            List.of(new TaxPayer(carol, new BigDecimal("50.00")))
        );
        TaxAssessment assessment = new TaxAssessment();

        assertThat(assessment.assess(TaxType.LAND_TAX, fixed(TaxType.LAND_TAX, "10.00"), context))
            .extracting(TaxFunding.Charge::amount)
            .containsExactly(
                new BigDecimal("3.33"),
                new BigDecimal("3.33"),
                new BigDecimal("3.34")
            );
        assertThat(assessment.assess(TaxType.BUSINESS_TAX, percent(TaxType.BUSINESS_TAX, "10"), context))
            .extracting(TaxFunding.Charge::amount)
            .containsExactly(new BigDecimal("20.00"), new BigDecimal("10.00"));
        assertThat(assessment.assess(TaxType.INCOME_TAX, percent(TaxType.INCOME_TAX, "10"), context))
            .extracting(TaxFunding.Charge::amount)
            .containsExactly(new BigDecimal("10.00"), new BigDecimal("5.00"));
        assertThat(assessment.assess(TaxType.TARIFF, percent(TaxType.TARIFF, "3"), context))
            .extracting(TaxFunding.Charge::amount)
            .containsExactly(new BigDecimal("1.50"));
    }

    @Test
    void fundingOnlyReportsMoneyActuallyWithdrawn() {
        UUID funded = UUID.randomUUID();
        UUID shortOfFunds = UUID.randomUUID();
        TestEconomy economy = new TestEconomy(Map.of(
            funded, new BigDecimal("20.00"),
            shortOfFunds, new BigDecimal("2.00")
        ));
        TaxFunding funding = new TaxFunding(economy);

        TaxFunding.Result result = funding.collect(List.of(
            new TaxFunding.Charge(funded, new BigDecimal("10.00")),
            new TaxFunding.Charge(shortOfFunds, new BigDecimal("5.00"))
        ));

        assertThat(result.collected()).isEqualByComparingTo("10.00");
        assertThat(result.failedPayers()).containsExactly(shortOfFunds);
        assertThat(economy.getBalance(funded)).isEqualByComparingTo("10.00");
        assertThat(economy.getBalance(shortOfFunds)).isEqualByComparingTo("2.00");

        funding.refund(result);

        assertThat(economy.getBalance(funded)).isEqualByComparingTo("20.00");
        assertThat(economy.getBalance(shortOfFunds)).isEqualByComparingTo("2.00");
    }

    private TaxConfig fixed(TaxType type, String amount) {
        return new TaxConfig(type, true, new BigDecimal(amount), BigDecimal.ZERO,
            BigDecimal.ZERO, 1440, true);
    }

    private TaxConfig percent(TaxType type, String rate) {
        return new TaxConfig(type, true, BigDecimal.ZERO, new BigDecimal(rate),
            BigDecimal.ZERO, 1440, true);
    }

    private static final class TestEconomy implements EconomyService {
        private final Map<UUID, BigDecimal> balances;

        private TestEconomy(Map<UUID, BigDecimal> balances) {
            this.balances = new HashMap<>(balances);
        }

        @Override public BigDecimal getBalance(UUID playerId) { return balances.getOrDefault(playerId, BigDecimal.ZERO); }
        @Override public boolean has(UUID playerId, BigDecimal amount) { return getBalance(playerId).compareTo(amount) >= 0; }
        @Override public boolean deposit(UUID playerId, BigDecimal amount) { balances.merge(playerId, amount, BigDecimal::add); return true; }
        @Override public boolean withdraw(UUID playerId, BigDecimal amount) {
            if (!has(playerId, amount)) return false;
            balances.put(playerId, getBalance(playerId).subtract(amount));
            return true;
        }
        @Override public boolean setBalance(UUID playerId, BigDecimal amount) { balances.put(playerId, amount); return true; }
        @Override public boolean transfer(UUID from, UUID to, BigDecimal amount) { return false; }
        @Override public Map<UUID, BigDecimal> getAllBalances() { return Map.copyOf(balances); }
        @Override public boolean hasAccount(UUID playerId) { return balances.containsKey(playerId); }
        @Override public void createAccount(UUID playerId) { balances.putIfAbsent(playerId, BigDecimal.ZERO); }
    }
}
