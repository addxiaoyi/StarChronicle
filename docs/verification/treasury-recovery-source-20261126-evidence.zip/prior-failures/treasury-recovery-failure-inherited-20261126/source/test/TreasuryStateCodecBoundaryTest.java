package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;

import dev.starcore.starcore.module.nation.model.NationId;
import java.util.Properties;
import org.junit.jupiter.api.Test;

class TreasuryStateCodecBoundaryTest {

  @Test
  void skipsBalanceWithExplicitlyInvalidAmountInsteadOfTurningItIntoZero() {
    Properties properties = new Properties();
    properties.setProperty("count", "1");
    properties.setProperty("treasury.0.nationId", NationId.random().toString());
    properties.setProperty("treasury.0.balance", "not-money");

    assertThat(TreasuryStateCodec.stateFromProperties(properties).balances()).isEmpty();
  }

  @Test
  void skipsSpendingReceiptWithExplicitlyInvalidAmount() {
    Properties properties = new Properties();
    properties.setProperty("spending.count", "1");
    properties.setProperty("spending.0.transactionId", "spend-1");
    properties.setProperty("spending.0.nationId", NationId.random().toString());
    properties.setProperty("spending.0.amount", "not-money");
    properties.setProperty("spending.0.category", "OTHER");
    properties.setProperty("spending.0.appliedAt", "1755388800000");

    assertThat(TreasuryStateCodec.stateFromProperties(properties).spendingReceipts()).isEmpty();
  }

  @Test
  void skipsTransferReceiptWithExplicitlyInvalidTimestamp() {
    Properties properties = new Properties();
    properties.setProperty("transfer.count", "1");
    properties.setProperty("transfer.0.transactionId", "transfer-1");
    properties.setProperty("transfer.0.payerId", NationId.random().toString());
    properties.setProperty("transfer.0.receiverId", NationId.random().toString());
    properties.setProperty("transfer.0.amount", "5.00");
    properties.setProperty("transfer.0.category", "OTHER");
    properties.setProperty("transfer.0.appliedAt", "not-an-epoch");

    assertThat(TreasuryStateCodec.stateFromProperties(properties).transferReceipts()).isEmpty();
  }
}
