package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class TreasuryAuthorityDomainTest {

  @Test
  void cleanStateMintsOneDomainAndRestartKeepsIt() throws Exception {
    MemoryStorage storage = new MemoryStorage();
    TreasuryModule first = loaded(storage);

    String authority = first.authorityDomainId();
    assertNotNull(authority);
    assertEquals(authority, UUID.fromString(authority).toString());
    assertEquals(authority, storage.properties.getProperty("authorityDomainId"));

    TreasuryModule restarted = loaded(storage);
    assertEquals(authority, restarted.authorityDomainId());
    assertEquals(authority, storage.properties.getProperty("authorityDomainId"));
  }

  @Test
  void legacyStateWithDataDoesNotSilentlyMintAnotherDomain() throws Exception {
    MemoryStorage storage = new MemoryStorage();
    NationId nation = NationId.random();
    storage.properties.setProperty("count", "1");
    storage.properties.setProperty("treasury.0.nationId", nation.toString());
    storage.properties.setProperty("treasury.0.balance", "10.00");

    TreasuryModule module = loaded(storage);

    assertNull(module.authorityDomainId());
    assertFalse(storage.properties.containsKey("authorityDomainId"));
  }

  @Test
  void malformedDomainMarkerIsIgnoredAndDoesNotBecomeAuthority() {
    Properties properties = new Properties();
    properties.setProperty("authorityDomainId", "not-a-uuid");

    TreasuryStateCodec.TreasuryState state = TreasuryStateCodec.stateFromProperties(properties);

    assertNull(state.authorityDomainId());
  }

  @Test
  void malformedDomainMarkerDoesNotRotateACleanStore() {
    MemoryStorage storage = new MemoryStorage();
    storage.properties.setProperty("authorityDomainId", "not-a-uuid");

    assertThrows(Exception.class, () -> loaded(storage));
    assertEquals("not-a-uuid", storage.properties.getProperty("authorityDomainId"));
  }

  @Test
  void codecRoundTripPreservesCanonicalDomainMarker() {
    String authority = UUID.randomUUID().toString();
    Properties properties = new Properties();
    properties.setProperty("authorityDomainId", authority);

    TreasuryStateCodec.TreasuryState state = TreasuryStateCodec.stateFromProperties(properties);
    Properties encoded = TreasuryStateCodec.toProperties(state);

    assertEquals(authority, state.authorityDomainId());
    assertEquals(authority, encoded.getProperty("authorityDomainId"));
  }

  private static TreasuryModule loaded(MemoryStorage storage) throws Exception {
    TreasuryModule module = new TreasuryModule();
    Field field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    Method load = TreasuryModule.class.getDeclaredMethod("loadState");
    load.setAccessible(true);
    load.invoke(module);
    return module;
  }

  private static final class MemoryStorage implements TreasuryStateStorage {
    private Properties properties = new Properties();

    @Override
    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(properties);
      return copy;
    }

    @Override
    public void save(Properties next) {
      properties = new Properties();
      properties.putAll(next);
    }
  }
}
