package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.database.DatabaseService;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.sqlite.SQLiteDataSource;

class BankruptcyServicePersistenceDiagnosticsTest {

  @Test
  void skipsMalformedRecordAndLogsStableKeyContext() throws Exception {
    String url = "jdbc:sqlite:file:bankruptcy-diagnostics?mode=memory&cache=shared";
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl(url);
    try (Connection anchor = dataSource.getConnection();
        Statement statement = anchor.createStatement()) {
      statement.execute(
          "CREATE TABLE starcore_bankruptcy_state ("
              + "property_key VARCHAR(191) PRIMARY KEY, property_value TEXT NOT NULL)");
      statement.execute(
          "INSERT INTO starcore_bankruptcy_state "
              + "(property_key, property_value) VALUES "
              + "('00000000-0000-0000-0000-000000000001', '{\"reason\":\"broken\"}')");

      Logger logger = Logger.getLogger(BankruptcyServicePersistenceDiagnosticsTest.class.getName());
      List<LogRecord> records = new ArrayList<>();
      Handler handler = recordingHandler(records);
      logger.addHandler(handler);
      try {
        JavaPlugin plugin = mock(JavaPlugin.class);
        when(plugin.getLogger()).thenReturn(logger);
        DatabaseService database = mock(DatabaseService.class);
        when(database.isRunning()).thenReturn(true);
        when(database.dataSource()).thenReturn(Optional.of(dataSource));
        StarCoreContext context =
            new StarCoreContext(
                plugin, null, null, null, null, null, database, null, null, null, null);

        BankruptcyServiceImpl service = new BankruptcyServiceImpl();
        Method loadRecords =
            BankruptcyServiceImpl.class.getDeclaredMethod("loadRecords", StarCoreContext.class);
        loadRecords.setAccessible(true);

        assertThatCode(() -> loadRecords.invoke(service, context)).doesNotThrowAnyException();
        assertThat(records.stream().map(LogRecord::getMessage).toList())
            .anyMatch(
                message ->
                    message.contains("code=BANKRUPTCY_RECORD_DESERIALIZATION_FAILURE")
                        && message.contains("key=00000000-0000-0000-0000-000000000001"));
      } finally {
        logger.removeHandler(handler);
      }
    }
  }

  private static Handler recordingHandler(List<LogRecord> records) {
    return new Handler() {
      @Override
      public void publish(LogRecord record) {
        records.add(record);
      }

      @Override
      public void flush() {}

      @Override
      public void close() {}
    };
  }
}
