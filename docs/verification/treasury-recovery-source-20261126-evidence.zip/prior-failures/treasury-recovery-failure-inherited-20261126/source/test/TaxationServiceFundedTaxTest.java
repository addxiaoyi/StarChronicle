package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.database.SqliteDatabaseService;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class TaxationServiceFundedTaxTest {

    @Test
    void restartDoesNotFundTheSameTaxTransactionTwice() throws Exception {
        try (SqliteDatabaseService database = new SqliteDatabaseService()) {
            TreasuryService treasury = mock(TreasuryService.class);
            StarCoreContext context = context(database, treasury);
            NationId nationId = NationId.random();
            UUID payerId = UUID.randomUUID();
            UUID transactionId = UUID.randomUUID();

            TaxationServiceImpl first = taxation(context, nationId);
            TaxQuote quote = first.quoteTax(
                transactionId,
                nationId,
                TaxType.BUSINESS_TAX,
                payerId,
                new BigDecimal("100.00")
            );
            assertThat(first.fundTax(quote)).isEqualByComparingTo("5.00");

            TaxationServiceImpl restarted = taxation(context, nationId);

            assertThat(restarted.fundTax(quote)).isEqualByComparingTo("0.00");
            verify(treasury, times(1)).tryDeposit(
                eq(nationId),
                argThat(amount -> amount.compareTo(new BigDecimal("5.00")) == 0)
            );
        }
    }

    @Test
    void restartRejectsReusedTransactionIdWithDifferentTaxDetails() throws Exception {
        try (SqliteDatabaseService database = new SqliteDatabaseService()) {
            TreasuryService treasury = mock(TreasuryService.class);
            StarCoreContext context = context(database, treasury);
            NationId nationId = NationId.random();
            UUID transactionId = UUID.randomUUID();

            TaxationServiceImpl first = taxation(context, nationId);
            TaxQuote original = first.quoteTax(
                transactionId,
                nationId,
                TaxType.BUSINESS_TAX,
                UUID.randomUUID(),
                new BigDecimal("100.00")
            );
            assertThat(first.fundTax(original)).isEqualByComparingTo("5.00");

            TaxationServiceImpl restarted = taxation(context, nationId);
            TaxQuote conflicting = restarted.quoteTax(
                transactionId,
                nationId,
                TaxType.BUSINESS_TAX,
                UUID.randomUUID(),
                new BigDecimal("200.00")
            );

            assertThatThrownBy(() -> restarted.fundTax(conflicting))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining(transactionId.toString());
        }
    }

    @Test
    void reversingFundedTaxWithdrawsTreasuryAndAllowsSafeRetry() throws Exception {
        try (SqliteDatabaseService database = new SqliteDatabaseService()) {
            TreasuryService treasury = mock(TreasuryService.class);
            StarCoreContext context = context(database, treasury);
            NationId nationId = NationId.random();
            TaxationServiceImpl taxes = taxation(context, nationId);
            TaxQuote quote = taxes.quoteTax(
                UUID.randomUUID(), nationId, TaxType.BUSINESS_TAX,
                UUID.randomUUID(), new BigDecimal("100.00"));
            when(treasury.withdraw(nationId, new BigDecimal("5.00"))).thenReturn(true);

            assertThat(taxes.fundTax(quote)).isEqualByComparingTo("5.00");
            assertThat(taxes.reverseFundedTax(quote)).isEqualByComparingTo("5.00");
            assertThat(taxes.reverseFundedTax(quote)).isEqualByComparingTo("0.00");

            TaxationServiceImpl restarted = taxation(context, nationId);
            assertThat(restarted.fundTax(quote)).isEqualByComparingTo("5.00");
            verify(treasury, times(1)).withdraw(nationId, new BigDecimal("5.00"));
            verify(treasury, times(2)).tryDeposit(nationId, new BigDecimal("5.00"));
        }
    }

    @Test
    void failedTreasuryWithdrawalKeepsFundedClaimForRetry() throws Exception {
        try (SqliteDatabaseService database = new SqliteDatabaseService()) {
            TreasuryService treasury = mock(TreasuryService.class);
            StarCoreContext context = context(database, treasury);
            NationId nationId = NationId.random();
            TaxationServiceImpl taxes = taxation(context, nationId);
            TaxQuote quote = taxes.quoteTax(
                UUID.randomUUID(), nationId, TaxType.BUSINESS_TAX,
                UUID.randomUUID(), new BigDecimal("100.00"));
            taxes.fundTax(quote);
            when(treasury.withdraw(nationId, new BigDecimal("5.00"))).thenReturn(false);

            assertThatThrownBy(() -> taxes.reverseFundedTax(quote))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining(quote.transactionId().toString());

            TaxationServiceImpl restarted = taxation(context, nationId);
            assertThat(restarted.fundTax(quote)).isEqualByComparingTo("0.00");
        }
    }

    private StarCoreContext context(
        SqliteDatabaseService database,
        TreasuryService treasury
    ) {
        ServiceRegistry services = new ServiceRegistry();
        services.register(TreasuryService.class, treasury);
        when(treasury.tryDeposit(any(NationId.class), any(BigDecimal.class))).thenReturn(true);
        return new StarCoreContext(
            null, null, null, null, null, null,
            database, null, null, null, services
        );
    }

    private TaxationServiceImpl taxation(
        StarCoreContext context,
        NationId nationId
    ) throws ReflectiveOperationException {
        TaxationServiceImpl taxes = new TaxationServiceImpl();
        Field currentContext = TaxationServiceImpl.class.getDeclaredField("currentContext");
        currentContext.setAccessible(true);
        currentContext.set(taxes, context);
        taxes.getTaxConfigs(nationId).put(
            TaxType.BUSINESS_TAX,
            new TaxConfig(
                TaxType.BUSINESS_TAX,
                true,
                BigDecimal.ZERO,
                new BigDecimal("5.00"),
                BigDecimal.ZERO,
                1440,
                false
            )
        );
        return taxes;
    }
}
