package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.database.SqliteDatabaseService;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxPayer;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class TaxationServiceCompensationFailureTest {

  @Test
  void auditFailureAfterFundingMustNotReportSuccessAndLeavesRetryableAuditState() throws Exception {
    try (SqliteDatabaseService database = new SqliteDatabaseService()) {
      createExpectedTables(database);
      NationId nationId = NationId.random();
      TreasuryService treasury = mock(TreasuryService.class);
      EventService events = mock(EventService.class);
      when(treasury.tryDeposit(nationId, new BigDecimal("10.00"))).thenReturn(true);
      when(treasury.withdraw(nationId, new BigDecimal("10.00"))).thenReturn(true);
      AtomicBoolean failAudit = new AtomicBoolean(true);
      doAnswer(
              invocation -> {
                if (failAudit.getAndSet(false)) {
                  throw new IllegalStateException("audit unavailable");
                }
                return null;
              })
          .when(events)
          .record(any(), anyString(), anyString(), anyString());
      TaxationServiceImpl taxes = taxation(context(database, treasury, events), nationId);
      TaxationService.TaxQuote quote =
          taxes.quoteTax(
              UUID.randomUUID(),
              nationId,
              TaxType.BUSINESS_TAX,
              UUID.randomUUID(),
              new BigDecimal("100.00"));
      assertThat(quote.taxAmount()).isEqualByComparingTo("10.00");

      assertThatThrownBy(() -> taxes.fundTax(quote))
          .isInstanceOf(IllegalStateException.class)
          .hasMessageContaining(quote.transactionId().toString());
      verify(treasury).withdraw(nationId, new BigDecimal("10.00"));

      TaxationServiceImpl retry = taxation(context(database, treasury, events), nationId);
      assertThat(retry.fundTax(quote)).isEqualByComparingTo("10.00");
    }
  }

  @Test
  void failedRefundMustLeavePersistentCompensationForRetry() throws Exception {
    try (SqliteDatabaseService database = new SqliteDatabaseService()) {
      createExpectedTables(database);
      NationId nationId = NationId.random();
      UUID payerId = UUID.randomUUID();
      TreasuryService treasury = mock(TreasuryService.class);
      EventService events = mock(EventService.class);
      EconomyService economy = mock(EconomyService.class);
      when(treasury.tryDeposit(nationId, new BigDecimal("10.00"))).thenReturn(false);
      when(economy.withdraw(payerId, new BigDecimal("10.00"))).thenReturn(true);
      when(economy.deposit(payerId, new BigDecimal("10.00"))).thenReturn(false);
      TaxationServiceImpl taxes = taxation(context(database, treasury, events, economy), nationId);

      assertThatThrownBy(
              () ->
                  taxes.collectTax(
                      nationId,
                      TaxType.BUSINESS_TAX,
                      new TaxContext(
                          0,
                          0,
                          1,
                          BigDecimal.ZERO,
                          List.of(),
                          List.of(new TaxPayer(payerId, new BigDecimal("100.00"))),
                          List.of())))
          .isInstanceOf(IllegalStateException.class);

      int pendingCompensations =
          database.query(
              "SELECT COUNT(*) FROM treasury_tax_compensations WHERE payer_id = ? AND status ="
                  + " 'PENDING'",
              rows -> {
                try {
                  rows.next();
                  return rows.getInt(1);
                } catch (java.sql.SQLException exception) {
                  throw new IllegalStateException(exception);
                }
              },
              payerId.toString());
      assertThat(pendingCompensations).isEqualTo(1);
    }
  }

  private static void createExpectedTables(SqliteDatabaseService database) {
    database.execute(
        """
        CREATE TABLE treasury_tax_compensations (
            compensation_id VARCHAR(36) PRIMARY KEY,
            kind VARCHAR(32) NOT NULL,
            nation_id VARCHAR(36) NOT NULL,
            tax_type VARCHAR(32) NOT NULL,
            payer_id VARCHAR(36),
            amount VARCHAR(64) NOT NULL,
            status VARCHAR(16) NOT NULL,
            created_at VARCHAR(64) NOT NULL
        )
        """);
  }

  private static StarCoreContext context(
      SqliteDatabaseService database, TreasuryService treasury, EventService events) {
    return context(database, treasury, events, mock(EconomyService.class));
  }

  private static StarCoreContext context(
      SqliteDatabaseService database,
      TreasuryService treasury,
      EventService events,
      EconomyService economy) {
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(Logger.getLogger("TaxationServiceCompensationFailureTest"));
    ServiceRegistry services = new ServiceRegistry();
    services.register(TreasuryService.class, treasury);
    services.register(EventService.class, events);
    services.register(EconomyService.class, economy);
    return new StarCoreContext(
        plugin, null, null, null, null, null, database, null, null, null, services);
  }

  private static TaxationServiceImpl taxation(StarCoreContext context, NationId nationId) {
    TaxationServiceImpl taxes = new TaxationServiceImpl();
    setField(taxes, "currentContext", context);
    taxes
        .getTaxConfigs(nationId)
        .put(
            TaxType.BUSINESS_TAX,
            new TaxConfig(
                TaxType.BUSINESS_TAX,
                true,
                BigDecimal.ZERO,
                new BigDecimal("10.00"),
                BigDecimal.ZERO,
                1440,
                false));
    return taxes;
  }

  private static void setField(Object target, String name, Object value) {
    try {
      var field = target.getClass().getDeclaredField(name);
      field.setAccessible(true);
      field.set(target, value);
    } catch (ReflectiveOperationException exception) {
      throw new IllegalStateException("Unable to prepare taxation test context", exception);
    }
  }
}
