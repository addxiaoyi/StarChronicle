package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class LoanServiceValidationTest {

  @Test
  void rejectsNullNationAndAmountAtLoanBoundaries() {
    LoanServiceImpl service = new LoanServiceImpl();

    assertThat(service.getDebt(null)).isEmpty();
    assertThat(service.getDebtsByNation(null)).isEmpty();
    assertThat(service.getActiveDebts(null)).isEmpty();
    assertThat(service.getOverdueDebts(null)).isEmpty();
    assertThat(service.getTotalDebt(null)).isZero();
    assertThat(service.getTotalDebtWithInterest(null)).isZero();
    assertThat(service.canBorrow(null, BigDecimal.ONE)).isFalse();
    assertThat(service.canBorrow(NationId.random(), null)).isFalse();
    assertThat(service.getMaxBorrowableAmount(null)).isZero();
    assertThat(service.getDebtHealthScore(null)).isEqualTo(100);
  }

  @Test
  void rejectsNullDebtIdsWithoutTouchingPersistenceOrTreasury() {
    LoanServiceImpl service = new LoanServiceImpl();

    assertThat(service.repayDebt(null, BigDecimal.ONE)).isFalse();
    assertThat(service.payInstallment(null)).isFalse();
    assertThat(service.forgiveDebt(null)).isFalse();
  }

  @Test
  void rejectsNullBorrowerBeforeCreatingLoan() {
    LoanServiceImpl service = new LoanServiceImpl();

    assertThatThrownBy(() -> service.applyForLoan(null, null, BigDecimal.ONE, BigDecimal.ONE, 1))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void keepsQueriesSafeBeforeModuleEnable() {
    LoanServiceImpl service = new LoanServiceImpl();
    NationId nationId = NationId.random();

    assertThat(service.getDebtHealthScore(nationId)).isEqualTo(50);

    service.setLoanConfig(
        new LoanService.LoanConfig(new BigDecimal("-1.00"), BigDecimal.ONE, 1, 1, 1, 1));
    assertThat(service.getMaxBorrowableAmount(nationId)).isZero();
  }

  @Test
  void rejectsLoanCreationBeforeEnableWithoutMutatingDebtState() {
    LoanServiceImpl service = new LoanServiceImpl();
    NationId nationId = NationId.random();

    assertThatThrownBy(
            () -> service.applyForLoan(nationId, null, BigDecimal.ONE, BigDecimal.ONE, 1))
        .isInstanceOf(IllegalStateException.class)
        .hasMessage("Loan service is not enabled");
    assertThat(service.getDebtsByNation(nationId)).isEmpty();
  }
}
