package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class TreasuryDiagnosticsTest {

  @Test
  void depositPersistenceFailureLogsStableCodeAndCause() throws Exception {
    AtomicReference<LogRecord> lastRecord = new AtomicReference<>();
    Logger logger = capturingLogger(lastRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    TreasuryModule module = moduleWith(new RejectingStorage(), plugin);
    NationId nationId = NationId.random();

    assertFalse(module.tryDeposit(nationId, new BigDecimal("25.00")));

    assertTrue(lastRecord.get().getMessage().contains("code=TREASURY_DEPOSIT_PERSISTENCE_FAILURE"));
    assertTrue(lastRecord.get().getMessage().contains("operation=deposit"));
    assertTrue(lastRecord.get().getMessage().contains("reconciled=true"));
    assertTrue(lastRecord.get().getMessage().contains("nation=" + nationId));
    assertTrue(lastRecord.get().getMessage().contains("amount=25.00"));
    assertTrue(lastRecord.get().getMessage().matches(".*txId=\\d+.*"));
    assertSame(RejectingStorage.FAILURE, lastRecord.get().getThrown());
  }

  @Test
  void withdrawPersistenceFailureLogsStableCodeAndCause() throws Exception {
    AtomicReference<LogRecord> lastRecord = new AtomicReference<>();
    Logger logger = capturingLogger(lastRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    SequencedStorage storage = new SequencedStorage(Set.of(2));
    TreasuryModule module = moduleWith(storage, plugin);
    NationId nationId = NationId.random();

    assertTrue(module.tryDeposit(nationId, new BigDecimal("40.00")));
    assertFalse(module.withdraw(nationId, new BigDecimal("10.00")));
    assertTrue(module.balance(nationId).compareTo(new BigDecimal("40.00")) == 0);

    assertTrue(
        lastRecord.get().getMessage().contains("code=TREASURY_WITHDRAW_PERSISTENCE_FAILURE"));
    assertTrue(lastRecord.get().getMessage().contains("operation=withdraw"));
    assertTrue(lastRecord.get().getMessage().contains("reconciled=true"));
    assertTrue(lastRecord.get().getMessage().contains("nation=" + nationId));
    assertTrue(lastRecord.get().getMessage().contains("amount=10.00"));
    assertTrue(lastRecord.get().getMessage().matches(".*txId=\\d+.*"));
    assertSame(storage.failure, lastRecord.get().getThrown());
  }

  @Test
  void spendPersistenceFailureLogsStableCodeAndRollsBackBalanceAndReceipt() throws Exception {
    AtomicReference<LogRecord> lastRecord = new AtomicReference<>();
    Logger logger = capturingLogger(lastRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    TreasuryModule module = moduleWith(new RejectingStorage(), plugin);
    NationId nationId = NationId.random();

    // Seed balance directly via reflection so spend is not rejected for insufficient funds
    setBalance(module, nationId, new BigDecimal("100.00"));

    var result =
        module.spend(
            new NationSpendingService.SpendRequest(
                "spend-1",
                nationId,
                new BigDecimal("12.50"),
                NationSpendingService.SpendingCategory.RESEARCH,
                "lab"));

    assertFalse(result.applied());
    assertTrue(lastRecord.get().getMessage().contains("code=TREASURY_SPEND_PERSISTENCE_FAILURE"));
    assertTrue(lastRecord.get().getMessage().contains("operation=spend"));
    assertTrue(lastRecord.get().getMessage().contains("reconciled=true"));
    assertTrue(lastRecord.get().getMessage().contains("nation=" + nationId));
    assertTrue(lastRecord.get().getMessage().contains("amount=12.50"));
    assertTrue(lastRecord.get().getMessage().matches(".*txId=\\d+.*"));
    assertSame(RejectingStorage.FAILURE, lastRecord.get().getThrown());
    assertFalse(module.hasSpendingReceipt("spend-1"));
    assertTrue(module.balance(nationId).compareTo(new BigDecimal("100.00")) == 0);
  }

  @Test
  void creditPersistenceFailureLogsStableCodeAndRollsBackBalanceAndReceipt() throws Exception {
    AtomicReference<LogRecord> lastRecord = new AtomicReference<>();
    Logger logger = capturingLogger(lastRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    TreasuryModule module = moduleWith(new RejectingStorage(), plugin);
    NationId nationId = NationId.random();

    setBalance(module, nationId, new BigDecimal("50.00"));

    var result =
        module.credit(
            new NationCreditService.CreditRequest(
                "credit-1",
                nationId,
                new BigDecimal("30.00"),
                NationCreditService.CreditCategory.COMPENSATION_REFUND,
                "reparation"));

    assertFalse(result.applied());
    assertTrue(lastRecord.get().getMessage().contains("code=TREASURY_CREDIT_PERSISTENCE_FAILURE"));
    assertTrue(lastRecord.get().getMessage().contains("operation=credit"));
    assertTrue(lastRecord.get().getMessage().contains("reconciled=true"));
    assertTrue(lastRecord.get().getMessage().contains("nation=" + nationId));
    assertTrue(lastRecord.get().getMessage().contains("amount=30.00"));
    assertTrue(lastRecord.get().getMessage().matches(".*txId=\\d+.*"));
    assertSame(RejectingStorage.FAILURE, lastRecord.get().getThrown());
    assertFalse(module.hasCreditReceipt("credit-1"));
    assertTrue(module.balance(nationId).compareTo(new BigDecimal("50.00")) == 0);
  }

  @Test
  void transferPersistenceFailureLogsStableCodeAndRollsBackBothBalances() throws Exception {
    AtomicReference<LogRecord> lastRecord = new AtomicReference<>();
    Logger logger = capturingLogger(lastRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    TreasuryModule module = moduleWith(new RejectingStorage(), plugin);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();

    setBalance(module, payer, new BigDecimal("100.00"));
    setBalance(module, receiver, new BigDecimal("20.00"));

    var result =
        module.transfer(
            new NationTransferService.TransferRequest(
                "transfer-1",
                payer,
                receiver,
                new BigDecimal("18.00"),
                NationTransferService.TransferCategory.LOAN,
                "tribute"));

    assertFalse(result.applied());
    assertTrue(
        lastRecord.get().getMessage().contains("code=TREASURY_TRANSFER_PERSISTENCE_FAILURE"));
    assertTrue(lastRecord.get().getMessage().contains("operation=transfer"));
    assertTrue(lastRecord.get().getMessage().contains("reconciled=true"));
    assertTrue(lastRecord.get().getMessage().contains("nation=" + payer));
    assertTrue(lastRecord.get().getMessage().contains("amount=18.00"));
    assertTrue(lastRecord.get().getMessage().matches(".*txId=\\d+.*"));
    assertSame(RejectingStorage.FAILURE, lastRecord.get().getThrown());
    assertFalse(module.hasTransferReceipt("transfer-1"));
    assertTrue(module.balance(payer).compareTo(new BigDecimal("100.00")) == 0);
    assertTrue(module.balance(receiver).compareTo(new BigDecimal("20.00")) == 0);
  }

  @Test
  void persistenceTxIdMonotonicallyIncreasesAcrossFailures() throws Exception {
    AtomicReference<LogRecord> firstRecord = new AtomicReference<>();
    AtomicReference<LogRecord> secondRecord = new AtomicReference<>();
    Logger logger = capturingLoggerChain(firstRecord, secondRecord);
    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getLogger()).thenReturn(logger);
    TreasuryModule module = moduleWith(new SequencedStorage(Set.of(1, 2)), plugin);
    NationId nationId = NationId.random();

    assertFalse(module.tryDeposit(nationId, new BigDecimal("10.00")));
    assertFalse(module.tryDeposit(nationId, new BigDecimal("20.00")));

    long firstTxId = extractTxId(firstRecord.get().getMessage());
    long secondTxId = extractTxId(secondRecord.get().getMessage());
    assertTrue(secondTxId > firstTxId);
  }

  private static long extractTxId(String message) {
    String prefix = "txId=";
    int idx = message.indexOf(prefix);
    if (idx < 0) throw new IllegalArgumentException("txId not found");
    int end = message.indexOf(' ', idx);
    String num = message.substring(idx + prefix.length(), end < 0 ? message.length() : end);
    return Long.parseLong(num);
  }

  private static TreasuryModule moduleWith(TreasuryStateStorage storage, JavaPlugin plugin)
      throws Exception {
    TreasuryModule module = new TreasuryModule();
    StarCoreContext context =
        new StarCoreContext(plugin, null, null, null, null, null, null, null, null, null, null);
    Field storageField = TreasuryModule.class.getDeclaredField("stateStorage");
    storageField.setAccessible(true);
    storageField.set(module, storage);
    Field contextField = TreasuryModule.class.getDeclaredField("currentContext");
    contextField.setAccessible(true);
    contextField.set(module, context);
    return module;
  }

  private static void setBalance(TreasuryModule module, NationId nationId, BigDecimal amount)
      throws Exception {
    Field balancesField = TreasuryModule.class.getDeclaredField("balances");
    balancesField.setAccessible(true);
    @SuppressWarnings("unchecked")
    ConcurrentMap<NationId, BigDecimal> balances =
        (ConcurrentMap<NationId, BigDecimal>) balancesField.get(module);
    balances.put(nationId, amount);
    Field storageField = TreasuryModule.class.getDeclaredField("stateStorage");
    storageField.setAccessible(true);
    if (storageField.get(module) instanceof RejectingStorage storage) {
      storage.persisted = TreasuryStateCodec.toProperties(balances);
    }
  }

  private static Logger capturingLogger(AtomicReference<LogRecord> lastRecord) {
    Logger logger = Logger.getAnonymousLogger();
    logger.setUseParentHandlers(false);
    logger.addHandler(
        new Handler() {
          @Override
          public void publish(LogRecord record) {
            lastRecord.set(record);
          }

          @Override
          public void flush() {}

          @Override
          public void close() {}
        });
    return logger;
  }

  private static Logger capturingLoggerChain(
      AtomicReference<LogRecord> first, AtomicReference<LogRecord> second) {
    Logger logger = Logger.getAnonymousLogger();
    logger.setUseParentHandlers(false);
    final int[] count = {0};
    logger.addHandler(
        new Handler() {
          @Override
          public void publish(LogRecord record) {
            if (count[0] == 0) {
              first.set(record);
            } else if (count[0] == 1) {
              second.set(record);
            }
            count[0]++;
          }

          @Override
          public void flush() {}

          @Override
          public void close() {}
        });
    return logger;
  }

  private static final class RejectingStorage implements TreasuryStateStorage {
    private Properties persisted = new Properties();
    private static final IllegalStateException FAILURE =
        new IllegalStateException("treasury storage unavailable");

    @Override
    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(persisted);
      return copy;
    }

    @Override
    public void save(Properties properties) {
      throw FAILURE;
    }

    @Override
    public void saveAsync(Properties properties) {
      throw FAILURE;
    }
  }

  private static final class SequencedStorage implements TreasuryStateStorage {
    private final Set<Integer> failingSaves;
    private int saveCount;
    private Properties persisted = new Properties();
    private IllegalStateException failure;

    private SequencedStorage(Set<Integer> failingSaves) {
      this.failingSaves = failingSaves;
    }

    @Override
    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(persisted);
      return copy;
    }

    @Override
    public void save(Properties properties) {
      saveCount++;
      if (failingSaves.contains(saveCount)) {
        failure = new IllegalStateException("treasury storage unavailable #" + saveCount);
        throw failure;
      }
      persisted = new Properties();
      persisted.putAll(properties);
    }

    @Override
    public void saveAsync(Properties properties) {
      save(properties);
    }
  }
}
