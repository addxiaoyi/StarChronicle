package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class TreasuryNationBoundaryTest {

  @Test
  void rejectsNullNationAcrossBasicTreasuryEntryPoints() {
    TreasuryModule module = new TreasuryModule();

    assertThat(module.balance(null)).isZero();
    assertThat(module.tryDeposit(null, BigDecimal.ONE)).isFalse();
    assertThat(module.withdraw(null, BigDecimal.ONE)).isFalse();
    assertThatThrownBy(() -> module.deposit(null, BigDecimal.ONE))
        .isInstanceOf(IllegalStateException.class);
    assertThat(module.balance(NationId.random())).isZero();
  }

  @Test
  void rewardRejectsNullNationBeforeEventOrBalanceAccess() {
    TreasuryModule module = new TreasuryModule();

    assertThatThrownBy(() -> module.reward(null, BigDecimal.ONE, "actor", "reason"))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void rejectsNullNationAcrossDelegatedWriteEntryPoints() {
    TreasuryModule module = new TreasuryModule();

    assertThatThrownBy(() -> module.setTaxConfig(null, TaxationService.TaxType.LAND_TAX, null))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> module.applyForLoan(null, null, BigDecimal.ONE, BigDecimal.ONE, 1))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> module.enterBankruptcy(null, "invalid"))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> module.createBudgetDraft(null, 2026, 8))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> module.getFinanceHealthReport(null))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void nullNationQueriesFailClosedWithoutReachingOptionalServices() {
    TreasuryModule module = new TreasuryModule();

    assertThat(module.getTaxConfigs(null)).isEmpty();
    assertThat(module.getTaxConfig(null, TaxationService.TaxType.LAND_TAX)).isNull();
    assertThat(module.collectTax(null, TaxationService.TaxType.LAND_TAX, null)).isZero();
    assertThat(module.collectAllTaxes(null, null)).isEmpty();
    assertThat(module.getTaxHistory(null, TaxationService.TaxType.LAND_TAX, 10)).isEmpty();
    assertThat(module.getDebtsByNation(null)).isEmpty();
    assertThat(module.getActiveDebts(null)).isEmpty();
    assertThat(module.getTotalDebt(null)).isZero();
    assertThat(module.canBorrow(null, BigDecimal.ONE)).isFalse();
    assertThat(module.getMaxBorrowableAmount(null)).isZero();
    assertThat(module.getDebtHealthScore(null)).isEqualTo(100);
    assertThat(module.exitBankruptcy(null)).isFalse();
    assertThat(module.isBankrupt(null)).isFalse();
    assertThat(module.getBankruptcyRecord(null)).isEmpty();
    assertThat(module.getBankruptcyDays(null)).isZero();
    assertThat(module.isRestricted(null, BankruptcyService.Restriction.BORROW_MONEY)).isFalse();
    assertThat(module.getActiveRestrictions(null)).isEmpty();
    assertThat(module.earlyExitBankruptcy(null)).isFalse();
    assertThat(module.getCurrentBudget(null)).isEmpty();
    assertThat(module.getBudgetHistory(null, 10)).isEmpty();
    assertThat(module.getMonthlySpending(null, 2026, 8)).isZero();
    assertThat(module.getYearlySpending(null, 2026)).isZero();
    assertThat(module.getTodayIncome(null)).isZero();
    assertThat(module.getTodayExpense(null)).isZero();
  }
}
