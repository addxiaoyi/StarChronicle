package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import dev.starcore.starcore.module.treasury.BankruptcyService.BankruptcyReason;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** BankruptcyReason 枚举测试。 */
@DisplayName("BankruptcyReason")
class BankruptcyReasonTest {

  @Test
  @DisplayName("4 个原因，字段都非空")
  void allValues() {
    assertEquals(4, BankruptcyReason.values().length);
    for (BankruptcyReason r : BankruptcyReason.values()) {
      assertNotNull(r.getConfigKey());
      assertNotNull(r.getDisplayName());
      assertNotNull(r.getDescription());
      assertFalse(r.getConfigKey().isEmpty());
    }
  }

  @Test
  @DisplayName("configKey 唯一")
  void uniqueConfigKeys() {
    java.util.Set<String> seen = new java.util.HashSet<>();
    for (BankruptcyReason r : BankruptcyReason.values()) {
      assertFalse(seen.contains(r.getConfigKey()), "Duplicate configKey: " + r.getConfigKey());
      seen.add(r.getConfigKey());
    }
  }
}
