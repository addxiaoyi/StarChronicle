package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetBill;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetEntry;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class BudgetStateCodecTest {
  private static final Instant NOW = Instant.parse("2026-07-15T00:00:00Z");

  @Test
  void roundTripsFundedBudgetAndSpendingReceipt() {
    BudgetStateCodec codec = new BudgetStateCodec();
    NationId nationId = NationId.random();
    UUID billId = UUID.randomUUID();
    BudgetBill budget = fundedBudget(nationId, billId, new BigDecimal("100.00"));
    UUID transactionId = UUID.randomUUID();
    NationSpendingReceipt receipt =
        new NationSpendingReceipt(
            transactionId,
            nationId,
            BudgetCategory.MILITARY,
            new BigDecimal("45.00"),
            new BigDecimal("40.00"),
            new BigDecimal("5.00"),
            billId,
            "army supply",
            NOW,
            false);

    BudgetStateSnapshot decoded =
        codec.fromProperties(
            codec.toProperties(
                new BudgetStateSnapshot(
                    Map.of(billId, budget),
                    Map.of(nationId, billId),
                    Map.of(transactionId, receipt))));

    assertEquals(budget, decoded.budgets().get(billId));
    assertEquals(billId, decoded.currentBudgets().get(nationId));
    assertEquals(receipt, decoded.receipts().get(transactionId));
  }

  @Test
  void legacyExecutedBudgetMigratesAsFullyConsumed() {
    BudgetStateCodec codec = new BudgetStateCodec();
    NationId nationId = NationId.random();
    UUID billId = UUID.randomUUID();
    UUID entryId = UUID.randomUUID();
    Properties legacy = new Properties();
    legacy.setProperty("count", "1");
    legacy.setProperty("budget.0.billId", billId.toString());
    legacy.setProperty("budget.0.nationId", nationId.toString());
    legacy.setProperty("budget.0.year", "2026");
    legacy.setProperty("budget.0.month", "7");
    legacy.setProperty("budget.0.totalAmount", "100.00");
    legacy.setProperty("budget.0.status", "EXECUTED");
    legacy.setProperty("budget.0.approvedAt", Long.toString(NOW.toEpochMilli()));
    legacy.setProperty("budget.0.approvedBy", "legacy");
    legacy.setProperty("budget.0.entries", "1");
    legacy.setProperty("budget.0.entry.0.entryId", entryId.toString());
    legacy.setProperty("budget.0.entry.0.category", "MILITARY");
    legacy.setProperty("budget.0.entry.0.description", "old army budget");
    legacy.setProperty("budget.0.entry.0.amount", "100.00");
    legacy.setProperty("budget.0.entry.0.createdAt", Long.toString(NOW.toEpochMilli()));

    BudgetStateSnapshot migrated = codec.fromProperties(legacy);

    assertEquals(billId, migrated.currentBudgets().get(nationId));
    assertEquals(1, migrated.receipts().size());
    NationSpendingReceipt receipt = migrated.receipts().values().iterator().next();
    assertEquals(new BigDecimal("100.00"), receipt.amount());
    assertEquals(new BigDecimal("100.00"), receipt.budgetAmount());
    assertEquals(BigDecimal.ZERO.setScale(2), receipt.treasuryAmount());
    assertEquals(billId, receipt.budgetId());
    assertTrue(receipt.description().startsWith("Legacy executed allocation:"));
  }

  @Test
  void rejectsFutureSchemaAndPersistedBudgetOverspend() {
    BudgetStateCodec codec = new BudgetStateCodec();
    Properties future = new Properties();
    future.setProperty("schema.version", "3");
    assertThrows(IllegalArgumentException.class, () -> codec.fromProperties(future));

    NationId nationId = NationId.random();
    UUID billId = UUID.randomUUID();
    BudgetBill budget = fundedBudget(nationId, billId, new BigDecimal("100.00"));
    UUID transactionId = UUID.randomUUID();
    NationSpendingReceipt overspent =
        new NationSpendingReceipt(
            transactionId,
            nationId,
            BudgetCategory.MILITARY,
            new BigDecimal("101.00"),
            new BigDecimal("101.00"),
            BigDecimal.ZERO,
            billId,
            "corrupt",
            NOW,
            false);
    Properties corrupt =
        codec.toProperties(
            new BudgetStateSnapshot(
                Map.of(billId, budget),
                Map.of(nationId, billId),
                Map.of(transactionId, overspent)));

    assertThrows(IllegalArgumentException.class, () -> codec.fromProperties(corrupt));
  }

  private static BudgetBill fundedBudget(NationId nationId, UUID billId, BigDecimal allocation) {
    BudgetEntry entry =
        new BudgetEntry(UUID.randomUUID(), BudgetCategory.MILITARY, "military", allocation, NOW);
    return new BudgetBill(
        billId,
        nationId,
        2026,
        7,
        List.of(entry),
        allocation,
        BudgetBill.BudgetStatus.EXECUTED,
        NOW,
        "tester");
  }
}
