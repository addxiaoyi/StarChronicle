package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.mysql.cj.jdbc.MysqlDataSource;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Properties;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import javax.sql.DataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class SqlBudgetStateStorageTest {
  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2026-11-18T12:00:00Z"), ZoneOffset.UTC);
  @TempDir Path temporary;
  private DataSource mysql;

  @BeforeEach
  void optionalDisposableMysql() throws Exception {
    if (!Boolean.getBoolean("starcore.budget.mysql.it")) return;
    String url = System.getenv("STARCORE_BUDGET_MYSQL_URL");
    assertThat(url).matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/starcore_budget_it(?:\\?.*)?");
    var source = new MysqlDataSource();
    source.setURL(url);
    source.setUser(System.getenv("STARCORE_BUDGET_MYSQL_USER"));
    source.setPassword(System.getenv("STARCORE_BUDGET_MYSQL_PASSWORD"));
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      assertThat(connection.getCatalog()).isEqualTo("starcore_budget_it");
      statement.execute(
          "CREATE TABLE IF NOT EXISTS starcore_budget_state (property_key VARCHAR(191) PRIMARY KEY,"
              + " property_value TEXT NOT NULL) ENGINE=InnoDB");
      try (var rows = statement.executeQuery("SELECT 1 FROM starcore_budget_state LIMIT 1")) {
        assertThat(rows.next()).as("owned budget integration fixture must start empty").isFalse();
      }
    }
    mysql = source;
  }

  @AfterEach
  void clearOwnedMysqlFixture() throws Exception {
    if (mysql == null) return;
    try (var connection = mysql.getConnection();
        var statement = connection.createStatement()) {
      statement.executeUpdate("DELETE FROM starcore_budget_state");
    }
  }

  @Test
  void simultaneousSameIdSpendCommitsOneReceiptAndCompensatesTheLosingDebit() throws Exception {
    DataSource source = database();
    TreasuryService treasury = treasury();
    AtomicReference<BigDecimal> balance = new AtomicReference<>(new BigDecimal("100.00"));
    var barrier = new CyclicBarrier(2);
    when(treasury.withdraw(any(), any()))
        .thenAnswer(
            call -> {
              balance.updateAndGet(value -> value.subtract(call.getArgument(1)));
              barrier.await(10, TimeUnit.SECONDS);
              return true;
            });
    when(treasury.tryDeposit(any(), any()))
        .thenAnswer(
            call -> {
              balance.updateAndGet(value -> value.add(call.getArgument(1)));
              return true;
            });
    when(treasury.balance(any())).thenAnswer(ignored -> balance.get());
    var first = new BudgetServiceImpl(storage(source), treasury, CLOCK);
    var second = new BudgetServiceImpl(storage(source), treasury, CLOCK);
    var request = request();
    var workers = Executors.newFixedThreadPool(2);
    try {
      var left = workers.submit(() -> attemptSpend(first, request));
      var right = workers.submit(() -> attemptSpend(second, request));
      String leftResult = left.get(20, TimeUnit.SECONDS);
      String rightResult = right.get(20, TimeUnit.SECONDS);
      assertThat(java.util.List.of(leftResult, rightResult))
          .containsExactlyInAnyOrder("APPLIED", "CONFLICT");
      assertThat(first.spendingReceipt(request.transactionId())).isPresent();
      assertThat(second.spendingReceipt(request.transactionId())).isPresent();
      assertThat(first.spend(request).status())
          .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
      assertThat(second.spend(request).status())
          .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
      assertThat(balance.get()).isEqualByComparingTo("75.00");
      verify(treasury, times(2)).withdraw(any(), any());
      verify(treasury, times(1)).tryDeposit(any(), any());
    } finally {
      workers.shutdownNow();
    }
  }

  private static String attemptSpend(
      BudgetServiceImpl service, NationSpendingService.SpendRequest request) {
    try {
      return service.spend(request).status().name();
    } catch (IllegalStateException conflict) {
      if (conflict.getCause() instanceof BudgetStateConflictException) return "CONFLICT";
      throw conflict;
    }
  }

  @Test
  void independentInstancesRefreshReceiptsReplayAndRefundAfterRestart() {
    DataSource database = database();
    TreasuryService treasury = treasury();
    var balance = new AtomicReference<>(new BigDecimal("100.00"));
    when(treasury.balance(any())).thenAnswer(ignored -> balance.get());
    when(treasury.withdraw(any(), any()))
        .thenAnswer(
            call -> {
              balance.updateAndGet(value -> value.subtract(call.getArgument(1)));
              return true;
            });
    NationCreditService credits = mock(NationCreditService.class);
    AtomicBoolean credited = new AtomicBoolean();
    when(credits.credit(any()))
        .thenAnswer(
            call -> {
              var request = (NationCreditService.CreditRequest) call.getArgument(0);
              boolean first = credited.compareAndSet(false, true);
              if (first) balance.updateAndGet(value -> value.add(request.amount()));
              return new NationCreditService.CreditResult(
                  first
                      ? NationCreditService.CreditStatus.APPLIED
                      : NationCreditService.CreditStatus.ALREADY_APPLIED,
                  request.transactionId(),
                  balance.get());
            });
    var first = new BudgetServiceImpl(storage(database), treasury, credits, CLOCK);
    var second = new BudgetServiceImpl(storage(database), treasury, credits, CLOCK);
    var request = request();
    assertThat(first.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.APPLIED);
    assertThat(second.spendingReceipt(request.transactionId())).isPresent();
    assertThat(second.spendingSnapshot(request.nationId()).orElseThrow().spent())
        .isEqualByComparingTo("25.00");
    assertThat(second.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
    assertThat(second.refund(request.transactionId())).isTrue();
    assertThat(first.spendingReceipt(request.transactionId()).orElseThrow().refunded()).isTrue();
    assertThat(first.getMonthlySpending(request.nationId(), 2026, 11)).isEqualByComparingTo("0.00");
    assertThat(first.spendingSnapshot(request.nationId()).orElseThrow().spent())
        .isEqualByComparingTo("0.00");
    assertThat(first.spendingSnapshot(request.nationId()).orElseThrow().totalBudget())
        .isEqualByComparingTo("100.00");
    var restarted = new BudgetServiceImpl(storage(database), treasury, credits, CLOCK);
    assertThat(restarted.refund(request.transactionId())).isTrue();
    assertThat(balance.get()).isEqualByComparingTo("100.00");
    verify(treasury, times(1)).withdraw(any(), any());
    verify(credits, times(1)).credit(any());
  }

  @Test
  void fundedBudgetPropagatesAndCannotBeFundedAgainOnAnotherInstance() {
    DataSource database = database();
    TreasuryService treasury = treasury();
    var first = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    var second = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    NationId nation = NationId.random();
    var bill = first.createBudgetDraft(nation, 2026, 11);
    second.addBudgetEntry(
        bill.billId(),
        BudgetService.BudgetCategory.ADMINISTRATION,
        "policy",
        new BigDecimal("50.00"));
    first.submitBudget(bill.billId());
    assertThat(second.approveBudget(bill.billId(), "test")).isTrue();
    assertThat(first.executeBudget(bill.billId())).isTrue();
    assertThat(second.executeBudget(bill.billId())).isTrue();
    var request =
        new NationSpendingService.SpendRequest(
            "funded-policy",
            nation,
            new BigDecimal("25.00"),
            NationSpendingService.SpendingCategory.NATIONAL_EVENT,
            "funded policy");
    second.spend(request);
    assertThat(first.getBudgetExecutionReport(bill.billId()).totalSpent())
        .isEqualByComparingTo("25.00");
    assertThat(first.getCurrentBudget(nation)).isPresent();
    assertThat(first.getBudgetHistory(nation, 10)).hasSize(1);
    assertThat(first.spendingReceipt(request.transactionId())).isPresent();
    verify(treasury, times(1)).withdraw(nation, new BigDecimal("50.00"));
    verify(treasury, times(1)).withdraw(any(), any());
  }

  @Test
  void staleWriterCannotEraseAnotherInstancesSnapshot() {
    DataSource database = database();
    var stale = storage(database);
    stale.load();
    var first = new BudgetServiceImpl(storage(database), treasury(), CLOCK);
    var bill = first.createBudgetDraft(NationId.random(), 2026, 11);
    assertThatThrownBy(() -> stale.save(new Properties()))
        .isInstanceOf(BudgetStateConflictException.class);
    var refresh = stale.refreshIfChanged().orElseThrow();
    assertThat(new BudgetStateCodec().fromProperties(refresh.properties()).budgets())
        .containsKey(bill.billId());
    stale.acceptRefresh(refresh);
    stale.save(refresh.properties());
    assertThat(stale.refreshIfChanged()).isEmpty();
  }

  @Test
  void staleSpendCompensatesOnlyItsOwnDebitAndCanBeExplicitlyRetried() {
    DataSource database = database();
    TreasuryService treasury = treasury();
    var first = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    var rival = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    AtomicBoolean collide = new AtomicBoolean(true);
    when(treasury.withdraw(any(), any()))
        .thenAnswer(
            ignored -> {
              if (collide.compareAndSet(true, false))
                rival.createBudgetDraft(NationId.random(), 2026, 11);
              return true;
            });
    var request = request();
    assertThatThrownBy(() -> first.spend(request))
        .hasCauseInstanceOf(BudgetStateConflictException.class);
    verify(treasury).tryDeposit(request.nationId(), request.amount());
    assertThat(first.spendingReceipt(request.transactionId())).isEmpty();
    assertThat(first.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.APPLIED);
    assertThat(rival.spendingReceipt(request.transactionId())).isPresent();
    verify(treasury, times(2)).withdraw(any(), any());
    verify(treasury, times(1)).tryDeposit(any(), any());
  }

  @Test
  void migrationRetainsOriginalFileAndRejectsDivergentSecondInstance() {
    DataSource source = database();
    MemoryStorage original = new MemoryStorage();
    var local = new BudgetServiceImpl(original, treasury(), CLOCK);
    var bill = local.createBudgetDraft(NationId.random(), 2026, 11);
    Properties archived = original.load();
    var sql = new SqlBudgetStateStorage(() -> source, original);
    var migrated = new BudgetServiceImpl(sql, treasury(), CLOCK);
    migrated.cancelBudget(bill.billId());
    assertThat(original.load()).isEqualTo(archived);
    var restart =
        new BudgetServiceImpl(new SqlBudgetStateStorage(() -> source, original), treasury(), CLOCK);
    assertThat(restart.getBudget(bill.billId()).orElseThrow().status())
        .isEqualTo(BudgetService.BudgetBill.BudgetStatus.CANCELLED);
    assertThat(new BudgetServiceImpl(storage(source), treasury(), CLOCK).getBudget(bill.billId()))
        .isPresent();
    MemoryStorage other = new MemoryStorage();
    new BudgetServiceImpl(other, treasury(), CLOCK).createBudgetDraft(NationId.random(), 2026, 11);
    assertThatThrownBy(() -> new SqlBudgetStateStorage(() -> source, other).load())
        .hasMessageContaining("Budget SQL state load failed")
        .hasRootCauseMessage(
            "Conflicting legacy budgets.properties; reconcile before enabling this instance");
  }

  @Test
  void databaseFailureNeverFallsBackToLocalStateOrDebitsTreasury() {
    DataSource source = database();
    MemoryStorage legacy = new MemoryStorage();
    AtomicBoolean offline = new AtomicBoolean();
    var storage =
        new SqlBudgetStateStorage(
            () -> {
              if (offline.get()) throw new IllegalStateException("database offline");
              return source;
            },
            legacy);
    TreasuryService treasury = treasury();
    var budget = new BudgetServiceImpl(storage, treasury, CLOCK);
    offline.set(true);
    assertThatThrownBy(() -> budget.spend(request())).hasMessageContaining("refresh failed");
    assertThatThrownBy(storage::load).hasMessageContaining("load failed");
    assertThatThrownBy(() -> storage.save(new Properties())).hasMessageContaining("write failed");
    verify(treasury, never()).withdraw(any(), any());
    assertThat(legacy.load()).isEmpty();
  }

  @Test
  void invalidRefreshIsRejectedWithoutAdoptingItsWriteRevision() throws Exception {
    DataSource source = database();
    var storage = storage(source);
    var service = new BudgetServiceImpl(storage, treasury(), CLOCK);
    try (var connection = source.getConnection();
        var statement = connection.createStatement()) {
      statement.executeUpdate(
          "UPDATE starcore_budget_state SET property_value = '2' WHERE property_key ="
              + " '__starcore_revision__'");
      statement.executeUpdate(
          "UPDATE starcore_budget_state SET property_value = '-1' WHERE property_key ="
              + " 'spending.count'");
      assertThatThrownBy(() -> service.spendingSnapshot(NationId.random()))
          .isInstanceOf(IllegalArgumentException.class);
      statement.executeUpdate(
          "UPDATE starcore_budget_state SET property_value = '0' WHERE property_key ="
              + " 'spending.count'");
    }
    assertThat(service.spendingSnapshot(NationId.random()).orElseThrow().spent())
        .isEqualByComparingTo("0.00");
    assertThat(storage.refreshIfChanged()).isEmpty();
  }

  @Test
  void lostCommitAcknowledgementDoesNotRefundAndBlocksUntilRestart() {
    DataSource database = database();
    AtomicBoolean fail = new AtomicBoolean();
    DataSource intercepted =
        intercept(
            database,
            connection -> {
              if (fail.compareAndSet(true, false)) throw new IllegalStateException("lose-ack");
            },
            false);
    TreasuryService treasury = treasury();
    var budget = new BudgetServiceImpl(storage(intercepted), treasury, CLOCK);
    fail.set(true);
    var request = request();
    assertThatThrownBy(() -> budget.spend(request))
        .isInstanceOf(BudgetStateReconciliationException.class);
    verify(treasury, never()).tryDeposit(any(), any());
    assertThatThrownBy(() -> budget.spend(request)).hasMessageContaining("requires restart");
    var restarted = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    assertThat(restarted.spend(request).status())
        .isEqualTo(NationSpendingService.SpendingStatus.ALREADY_APPLIED);
    verify(treasury, times(1)).withdraw(any(), any());
  }

  @Test
  void connectionReleaseErrorAfterAcknowledgedCommitDoesNotCauseRefund() {
    DataSource database = database();
    TreasuryService treasury = treasury();
    var budget = new BudgetServiceImpl(storage(database), treasury, CLOCK);
    // Load on a normal connection; only subsequent save connection release is faulty.
    var loaded = storage(intercept(database, ignored -> {}, true));
    loaded.load();
    var other =
        new BudgetServiceImpl(
            new BudgetStateStorage() {
              public Properties load() {
                return loaded.load();
              }

              public void save(Properties next) {
                loaded.save(next);
              }

              public java.util.Optional<BudgetStateRefresh> refreshIfChanged() {
                return loaded.refreshIfChanged();
              }

              public void acceptRefresh(BudgetStateRefresh refresh) {
                loaded.acceptRefresh(refresh);
              }
            },
            treasury,
            CLOCK);
    assertThat(other.spend(request()).status())
        .isEqualTo(NationSpendingService.SpendingStatus.APPLIED);
    verify(treasury, never()).tryDeposit(any(), any());
  }

  private DataSource database() {
    if (mysql != null) return mysql;
    var source = new SQLiteDataSource();
    source.setUrl("jdbc:sqlite:" + temporary.resolve("budget.db"));
    return source;
  }

  private SqlBudgetStateStorage storage(DataSource source) {
    return new SqlBudgetStateStorage(() -> source, new MemoryStorage());
  }

  private TreasuryService treasury() {
    TreasuryService treasury = mock(TreasuryService.class);
    when(treasury.withdraw(any(), any())).thenReturn(true);
    when(treasury.tryDeposit(any(), any())).thenReturn(true);
    when(treasury.balance(any())).thenReturn(new BigDecimal("75.00"));
    return treasury;
  }

  private NationSpendingService.SpendRequest request() {
    return new NationSpendingService.SpendRequest(
        "budget-shared-test",
        NationId.random(),
        new BigDecimal("25.00"),
        NationSpendingService.SpendingCategory.NATIONAL_EVENT,
        "policy");
  }

  private static DataSource intercept(
      DataSource source, Consumer<Connection> afterCommit, boolean failClose) {
    return (DataSource)
        Proxy.newProxyInstance(
            DataSource.class.getClassLoader(),
            new Class<?>[] {DataSource.class},
            (proxy, method, arguments) -> {
              try {
                Object result = method.invoke(source, arguments);
                if (!method.getName().equals("getConnection")) return result;
                Connection connection = (Connection) result;
                AtomicBoolean committed = new AtomicBoolean();
                return Proxy.newProxyInstance(
                    Connection.class.getClassLoader(),
                    new Class<?>[] {Connection.class},
                    (ignored, operation, parameters) -> {
                      try {
                        Object value = operation.invoke(connection, parameters);
                        if (operation.getName().equals("commit")) {
                          committed.set(true);
                          afterCommit.accept(connection);
                        }
                        if (operation.getName().equals("close") && failClose && committed.get())
                          throw new SQLException("release failed");
                        return value;
                      } catch (InvocationTargetException failure) {
                        throw failure.getCause();
                      }
                    });
              } catch (InvocationTargetException failure) {
                throw failure.getCause();
              }
            });
  }

  private static final class MemoryStorage implements BudgetStateStorage {
    private Properties value = new Properties();

    public Properties load() {
      Properties copy = new Properties();
      copy.putAll(value);
      return copy;
    }

    public void save(Properties next) {
      value = new Properties();
      value.putAll(next);
    }
  }
}
