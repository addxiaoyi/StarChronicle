package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class TreasuryModuleRefreshLifecycleTest {

  @Test
  void disableCancelsRefreshAndDiscardsAnInFlightSnapshot() throws Exception {
    TreasuryModule module = new TreasuryModule();
    StarCoreContext context = mock(StarCoreContext.class);
    StarCoreScheduler scheduler = mock(StarCoreScheduler.class);
    JavaPlugin plugin = mock(JavaPlugin.class);
    StarCoreScheduler.GlobalRepeatingTask refreshTask = mock(StarCoreScheduler.GlobalRepeatingTask.class);
    when(context.scheduler()).thenReturn(scheduler);
    when(context.plugin()).thenReturn(plugin);
    when(plugin.getLogger()).thenReturn(Logger.getLogger("TreasuryRefreshLifecycleTest"));

    AtomicReference<Runnable> scheduledRefresh = new AtomicReference<>();
    when(scheduler.runGlobalRepeatingTask(any(Runnable.class), eq(100L), eq(100L)))
        .thenAnswer(
            invocation -> {
              scheduledRefresh.set(invocation.getArgument(0));
              return refreshTask;
            });

    NationId nationId = NationId.random();
    Properties refreshedProperties =
        TreasuryStateCodec.toProperties(
            java.util.Map.of(nationId, new java.math.BigDecimal("50.00")));
    CompletableFuture<Optional<TreasuryStateRefresh>> pendingRefresh = new CompletableFuture<>();
    when(scheduler.<Optional<TreasuryStateRefresh>>runIoAsync(any())).thenReturn(pendingRefresh);
    TreasuryStateStorage storage =
        new TreasuryStateStorage() {
          @Override
          public Properties load() {
            return new Properties();
          }

          @Override
          public void save(Properties properties) {}

          @Override
          public Optional<TreasuryStateRefresh> refreshIfChanged() {
            return Optional.of(new TreasuryStateRefresh(refreshedProperties, 1L));
          }
        };
    setField(module, "currentContext", context);
    setField(module, "stateStorage", storage);
    setField(module, "stateRefreshEnabled", true);

    invoke(module, "scheduleStateRefresh");
    scheduledRefresh.get().run();
    assertThat(pendingRefresh).isNotCompleted();

    module.disable(context);
    pendingRefresh.complete(Optional.of(new TreasuryStateRefresh(refreshedProperties, 1L)));

    verify(refreshTask).cancel();
    verify(scheduler, never()).runGlobalIfAvailable(any(Runnable.class));
    assertThat(module.balance(nationId)).isEqualByComparingTo("0.00");
  }

  private static void setField(Object target, String name, Object value)
      throws ReflectiveOperationException {
    Field field = target.getClass().getDeclaredField(name);
    field.setAccessible(true);
    field.set(target, value);
  }

  private static void invoke(Object target, String name) throws ReflectiveOperationException {
    Method method = target.getClass().getDeclaredMethod(name);
    method.setAccessible(true);
    method.invoke(target);
  }
}
