package dev.starcore.starcore.core.scheduler;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class StarCoreScheduler {
  private final JavaPlugin plugin;
  private final ExecutorService asyncExecutor;
  private final ExecutorService ioExecutor; // Separate executor for I/O operations
  private final AtomicInteger taskIdGenerator = new AtomicInteger(1);
  private volatile boolean shutdown = false;

  // Only tasks which have not started may be rejected as definitely not applied.
  private final Map<CompletableFuture<?>, Runnable> pendingOperations = new ConcurrentHashMap<>();
  private final Set<GlobalRepeatingTask> globalRepeatingTasks = ConcurrentHashMap.newKeySet();
  private final Set<EntityRepeatingTask> entityRepeatingTasks = ConcurrentHashMap.newKeySet();

  // Metrics
  private final AtomicLong completedTasks = new AtomicLong(0);
  private final AtomicLong failedTasks = new AtomicLong(0);
  private final AtomicLong totalTaskDurationNanos = new AtomicLong(0);

  public StarCoreScheduler(JavaPlugin plugin, int asyncThreads) {
    this(
        plugin,
        asyncThreads,
        Math.max(2, asyncThreads / 2)); // Default I/O threads = half of async threads
  }

  public StarCoreScheduler(JavaPlugin plugin, int asyncThreads, int ioThreads) {
    this.plugin = Objects.requireNonNull(plugin, "plugin");
    this.asyncExecutor =
        Executors.newFixedThreadPool(asyncThreads, new StarCoreThreadFactory("async"));
    this.ioExecutor = Executors.newFixedThreadPool(ioThreads, new StarCoreThreadFactory("io"));
  }

  /**
   * True only when the current thread owns this entity. This is not a global/main-thread test.
   * Paper implements the same API for its single owning server thread.
   */
  public boolean isOwnedByCurrentThread(Entity entity) {
    return Bukkit.isOwnedByCurrentRegion(Objects.requireNonNull(entity, "entity"));
  }

  /** Fail before touching entity-local data when a synchronous API is called from elsewhere. */
  public void requireEntityOwner(Entity entity) {
    if (!isOwnedByCurrentThread(entity)) {
      throw new IllegalStateException(
          "Operation requires the entity owning thread; use callForEntity");
    }
  }

  /**
   * Run the whole operation on the entity's owning thread and complete only after it returns. The
   * entity scheduler follows teleports; no global or arbitrary location fallback is used.
   *
   * <p>{@link EntityTaskNotAppliedException} means the body never started. Exceptions from the body
   * do not imply rollback and must not trigger an automatic retry of an external effect. Cancelling
   * a future after its body has started cannot undo that body. The retired callback only completes
   * a future; it never touches entity/world state.
   */
  public <T> CompletableFuture<T> callForEntity(Entity entity, Supplier<T> operation) {
    Objects.requireNonNull(entity, "entity");
    Objects.requireNonNull(operation, "operation");
    CompletableFuture<T> result = new CompletableFuture<>();
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable reject =
        () -> {
          if (claimed.compareAndSet(false, true)) {
            result.completeExceptionally(
                new EntityTaskNotAppliedException(
                    "Entity retired or scheduler stopped before operation started"));
          }
        };
    Runnable execute =
        () -> {
          if (!claimed.compareAndSet(false, true) || result.isDone()) return;
          if (shutdown) {
            result.completeExceptionally(
                new EntityTaskNotAppliedException("Scheduler stopped before operation started"));
            return;
          }
          try {
            requireEntityOwner(entity);
            result.complete(operation.get());
          } catch (Throwable error) {
            result.completeExceptionally(error);
          }
        };
    pendingOperations.put(result, reject);
    result.whenComplete((value, error) -> pendingOperations.remove(result));
    if (shutdown) {
      reject.run();
      return result;
    }
    try {
      if (isOwnedByCurrentThread(entity)) {
        execute.run();
      } else if (!entity.getScheduler().execute(plugin, execute, reject, 1L)) {
        reject.run();
      }
    } catch (Throwable error) {
      if (claimed.compareAndSet(false, true)) result.completeExceptionally(error);
    }
    return result;
  }

  /**
   * Schedule repeated work on the entity's current owner. Shutdown, entity retirement, registration
   * rejection and callback failure retire detached caller state once. Explicit cancellation does
   * not invoke retirement. A zero initial delay means the next tick; callbacks receive the tracked
   * handle.
   */
  public ScheduledTask runAtEntityFixedRate(
      Entity entity,
      Consumer<ScheduledTask> operation,
      Runnable retired,
      long initialDelayTicks,
      long periodTicks) {
    Objects.requireNonNull(entity, "entity");
    Objects.requireNonNull(operation, "operation");
    Objects.requireNonNull(retired, "retired");
    if (initialDelayTicks < 0L || periodTicks < 1L) {
      throw new IllegalArgumentException("Invalid entity task interval");
    }
    if (shutdown) {
      retired.run();
      return null;
    }
    EntityRepeatingTask handle = new EntityRepeatingTask(entity, operation, retired);
    entityRepeatingTasks.add(handle);
    if (shutdown) {
      handle.retire();
      return null;
    }
    try {
      ScheduledTask task =
          entity
              .getScheduler()
              .runAtFixedRate(
                  plugin,
                  handle::run,
                  handle::retire,
                  Math.max(1L, initialDelayTicks),
                  periodTicks);
      handle.attach(task);
      if (task == null || shutdown) handle.retire();
      return task == null ? null : handle;
    } catch (RuntimeException | Error failure) {
      cleanupAfterFailure(handle::retire, failure);
      throw failure;
    }
  }

  private final class EntityRepeatingTask implements ScheduledTask {
    private final Entity entity;
    private final Consumer<ScheduledTask> operation;
    private final Runnable retired;
    private final AtomicBoolean active = new AtomicBoolean(true);
    private volatile ScheduledTask task;
    private boolean backendCancelled;

    private EntityRepeatingTask(
        Entity entity, Consumer<ScheduledTask> operation, Runnable retired) {
      this.entity = entity;
      this.operation = operation;
      this.retired = retired;
    }

    private synchronized void attach(ScheduledTask scheduled) {
      if (task == null) task = scheduled;
      if (!active.get()) cancelBackend();
    }

    private synchronized CancelledState cancelBackend() {
      if (task == null) return CancelledState.CANCELLED_BY_CALLER;
      if (backendCancelled) return CancelledState.CANCELLED_ALREADY;
      backendCancelled = true;
      return task.cancel();
    }

    private void run(ScheduledTask scheduled) {
      attach(scheduled);
      if (!active.get()) return;
      if (shutdown) {
        retire();
        return;
      }
      try {
        requireEntityOwner(entity);
        operation.accept(this);
      } catch (RuntimeException | Error failure) {
        cleanupAfterFailure(this::retire, failure);
        throw failure;
      }
    }

    private CancelledState stop(boolean notifyRetirement) {
      if (!active.compareAndSet(true, false)) return CancelledState.CANCELLED_ALREADY;
      entityRepeatingTasks.remove(this);
      try {
        return cancelBackend();
      } finally {
        if (notifyRetirement) retired.run();
      }
    }

    private void retire() {
      stop(true);
    }

    @Override
    public CancelledState cancel() {
      return stop(false);
    }

    @Override
    public Plugin getOwningPlugin() {
      return plugin;
    }

    @Override
    public boolean isRepeatingTask() {
      return true;
    }

    @Override
    public ExecutionState getExecutionState() {
      ScheduledTask scheduled = task;
      ExecutionState state =
          scheduled == null ? ExecutionState.IDLE : scheduled.getExecutionState();
      if (active.get()) return state;
      return state == ExecutionState.RUNNING || state == ExecutionState.CANCELLED_RUNNING
          ? ExecutionState.CANCELLED_RUNNING
          : ExecutionState.CANCELLED;
    }
  }

  /** Schedule repeated server-global work on Paper's global region or Folia's global region. */
  public GlobalRepeatingTask runGlobalRepeatingTask(
      Runnable operation, long initialDelayTicks, long periodTicks) {
    Objects.requireNonNull(operation, "operation");
    if (initialDelayTicks < 0L || periodTicks < 1L) {
      throw new IllegalArgumentException("Invalid global task interval");
    }
    if (shutdown) return null;

    GlobalRepeatingTask handle = new GlobalRepeatingTask();
    globalRepeatingTasks.add(handle);
    if (shutdown) {
      handle.cancel();
      return null;
    }
    try {
      ScheduledTask task =
          Bukkit.getGlobalRegionScheduler()
              .runAtFixedRate(
                  plugin,
                  scheduledTask -> {
                    handle.attach(scheduledTask);
                    if (shutdown || !handle.isActive()) {
                      handle.cancel();
                      return;
                    }
                    try {
                      operation.run();
                    } catch (RuntimeException | Error failure) {
                      cleanupAfterFailure(handle::cancel, failure);
                      throw failure;
                    }
                  },
                  Math.max(1L, initialDelayTicks),
                  periodTicks);
      handle.attach(task);
      if (task == null || shutdown) handle.cancel();
      return task == null ? null : handle;
    } catch (RuntimeException | Error failure) {
      cleanupAfterFailure(handle::cancel, failure);
      throw failure;
    }
  }

  /** Schedule one operation on Paper's primary or Folia's global region thread. */
  public void runGlobal(Runnable operation) {
    runGlobalIfAvailable(operation);
  }

  /** Schedule one operation and report whether it was accepted before scheduler shutdown. */
  public boolean runGlobalIfAvailable(Runnable operation) {
    Objects.requireNonNull(operation, "operation");
    if (shutdown) return false;
    ScheduledTask task =
        Bukkit.getGlobalRegionScheduler()
            .run(
                plugin,
                ignored -> {
                  if (!shutdown) operation.run();
                });
    return task != null && !shutdown;
  }

  public <T> CompletableFuture<T> callGlobal(Supplier<T> operation) {
    Objects.requireNonNull(operation, "operation");
    CompletableFuture<T> result = new CompletableFuture<>();
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable reject =
        () -> {
          if (claimed.compareAndSet(false, true)) {
            result.completeExceptionally(
                new RejectedExecutionException(
                    "Scheduler stopped before global operation started"));
          }
        };
    pendingOperations.put(result, reject);
    result.whenComplete((value, failure) -> pendingOperations.remove(result));
    if (shutdown) {
      reject.run();
      return result;
    }
    try {
      ScheduledTask task =
          Bukkit.getGlobalRegionScheduler()
              .run(
                  plugin,
                  ignored -> {
                    if (!claimed.compareAndSet(false, true) || result.isDone()) return;
                    if (shutdown) {
                      result.completeExceptionally(
                          new RejectedExecutionException(
                              "Scheduler stopped before global operation started"));
                      return;
                    }
                    try {
                      result.complete(operation.get());
                    } catch (Throwable failure) {
                      result.completeExceptionally(failure);
                    }
                  });
      if (task == null || shutdown) reject.run();
    } catch (Throwable failure) {
      if (claimed.compareAndSet(false, true)) result.completeExceptionally(failure);
    }
    return result;
  }

  public final class GlobalRepeatingTask {
    private final AtomicBoolean active = new AtomicBoolean(true);
    private volatile ScheduledTask scheduledTask;
    private boolean backendCancelled;

    private GlobalRepeatingTask() {}

    private synchronized void attach(ScheduledTask task) {
      if (scheduledTask == null) scheduledTask = task;
      if (!active.get()) cancelBackend();
    }

    private synchronized void cancelBackend() {
      if (scheduledTask != null && !backendCancelled) {
        backendCancelled = true;
        scheduledTask.cancel();
      }
    }

    private boolean isActive() {
      return active.get();
    }

    public boolean cancel() {
      if (!active.compareAndSet(true, false)) return false;
      globalRepeatingTasks.remove(this);
      cancelBackend();
      return true;
    }
  }

  private static void cleanupAfterFailure(Runnable cleanup, Throwable failure) {
    try {
      cleanup.run();
    } catch (RuntimeException | Error cleanupFailure) {
      if (cleanupFailure != failure) failure.addSuppressed(cleanupFailure);
    }
  }

  /** A precise no-application result for an entity task rejected before its body began. */
  public static final class EntityTaskNotAppliedException extends RejectedExecutionException {
    public EntityTaskNotAppliedException(String message) {
      super(message);
    }
  }

  private void rejectPendingOperations() {
    pendingOperations.values().forEach(Runnable::run);
  }

  /** Gets the number of completed tasks. */
  public long getCompletedTaskCount() {
    return completedTasks.get();
  }

  /** Gets the number of failed tasks. */
  public long getFailedTaskCount() {
    return failedTasks.get();
  }

  /** Gets the average task duration in milliseconds. */
  public double getAverageTaskDurationMs() {
    long completed = completedTasks.get();
    if (completed == 0) return 0.0;
    return (double) totalTaskDurationNanos.get() / completed / 1_000_000.0;
  }

  /**
   * 获取异步执行器
   *
   * @return 异步任务的 ExecutorService
   */
  public ExecutorService getAsyncExecutor() {
    return asyncExecutor;
  }

  /** Gets the executor reserved for blocking database and file operations. */
  public ExecutorService getIoExecutor() {
    return ioExecutor;
  }

  /**
   * 异步执行任务
   *
   * @param task 要执行的任务
   * @return 任务 ID，可用于取消
   */
  public int runAsync(Runnable task) {
    if (shutdown) return -1;
    int taskId = taskIdGenerator.getAndIncrement();
    long startNanos = System.nanoTime();
    CompletableFuture.runAsync(task, asyncExecutor)
        .whenComplete(
            (result, ex) -> {
              recordTaskCompletion(startNanos, ex == null);
            })
        .exceptionally(
            ex -> {
              plugin.getLogger().warning("Async task " + taskId + " failed: " + ex.getMessage());
              return null;
            });
    return taskId;
  }

  /**
   * 异步执行 I/O 密集型任务（数据库、文件操作等） 使用独立的 I/O 线程池，避免阻塞计算任务
   *
   * @param task 要执行的任务
   * @return CompletableFuture
   */
  public <T> CompletableFuture<T> runIoAsync(Supplier<T> task) {
    Objects.requireNonNull(task, "task");
    CompletableFuture<T> result = new CompletableFuture<>();
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable reject =
        () -> {
          if (claimed.compareAndSet(false, true)) {
            result.completeExceptionally(
                new RejectedExecutionException("Scheduler stopped before IO operation started"));
          }
        };
    pendingOperations.put(result, reject);
    result.whenComplete((value, failure) -> pendingOperations.remove(result));
    if (shutdown) {
      reject.run();
      return result;
    }
    try {
      ioExecutor.execute(
          () -> {
            if (!claimed.compareAndSet(false, true) || result.isDone()) return;
            if (shutdown) {
              result.completeExceptionally(
                  new RejectedExecutionException("Scheduler stopped before IO operation started"));
              return;
            }
            try {
              result.complete(task.get());
            } catch (Throwable failure) {
              result.completeExceptionally(failure);
            }
          });
    } catch (Throwable failure) {
      if (claimed.compareAndSet(false, true)) result.completeExceptionally(failure);
    }
    return result;
  }

  /**
   * 批量异步执行任务
   *
   * @param tasks 要执行的任务列表
   * @param onAllComplete 所有任务完成后的回调
   */
  public void runAsyncBatch(List<Runnable> tasks, Runnable onAllComplete) {
    if (shutdown || tasks.isEmpty()) {
      if (onAllComplete != null) onAllComplete.run();
      return;
    }
    CompletableFuture<?>[] futures =
        tasks.stream()
            .map(
                task ->
                    CompletableFuture.runAsync(task, asyncExecutor)
                        .whenComplete(
                            (r, ex) -> recordTaskCompletion(System.nanoTime(), ex == null)))
            .toArray(CompletableFuture[]::new);

    CompletableFuture.allOf(futures)
        .whenComplete(
            (result, ex) -> {
              if (onAllComplete != null) {
                runSync(onAllComplete);
              }
            });
  }

  /**
   * 异步执行任务，带完成回调
   *
   * @param task 要执行的任务
   * @param onComplete 完成回调
   * @return 任务 ID，可用于取消
   */
  public int runAsync(Runnable task, Runnable onComplete) {
    if (shutdown) return -1;
    int taskId = taskIdGenerator.getAndIncrement();
    long startNanos = System.nanoTime();
    CompletableFuture.runAsync(task, asyncExecutor)
        .whenComplete(
            (result, ex) -> {
              recordTaskCompletion(startNanos, ex == null);
              if (ex != null) {
                plugin.getLogger().warning("Async task " + taskId + " failed: " + ex.getMessage());
              } else if (onComplete != null) {
                runSync(onComplete);
              }
            });
    return taskId;
  }

  public CompletableFuture<Void> runAsyncVoid(Runnable task) {
    if (shutdown)
      return CompletableFuture.failedFuture(
          new RejectedExecutionException("Scheduler is shut down"));
    long startNanos = System.nanoTime();
    return CompletableFuture.runAsync(task, asyncExecutor)
        .whenComplete(
            (r, ex) -> {
              recordTaskCompletion(startNanos, ex == null);
              if (ex != null) {
                plugin.getLogger().warning("Async task failed: " + ex.getMessage());
              }
            });
  }

  /**
   * 异步执行任务并返回结果
   *
   * @param task 要执行的任务
   * @return CompletableFuture，任务 ID 存储在 exceptionally 中
   */
  public <T> CompletableFuture<T> supplyAsync(Supplier<T> task) {
    if (shutdown)
      return CompletableFuture.failedFuture(
          new RejectedExecutionException("Scheduler is shut down"));
    long startNanos = System.nanoTime();
    return CompletableFuture.supplyAsync(task, asyncExecutor)
        .whenComplete((r, ex) -> recordTaskCompletion(startNanos, ex == null))
        .exceptionally(
            ex -> {
              plugin.getLogger().warning("Async supply task failed: " + ex.getMessage());
              throw new RuntimeException(ex);
            });
  }

  /** Records task completion for metrics. */
  private void recordTaskCompletion(long startNanos, boolean success) {
    if (success) {
      completedTasks.incrementAndGet();
      totalTaskDurationNanos.addAndGet(System.nanoTime() - startNanos);
    } else {
      failedTasks.incrementAndGet();
    }
  }

  /**
   * 同步执行任务（主线程）
   *
   * @param task 要执行的任务
   * @return BukkitTask，用于取消
   */
  public BukkitTask runSync(Runnable task) {
    return Bukkit.getScheduler().runTask(plugin, task);
  }

  /**
   * 同步执行任务（主线程）
   *
   * @param task 要执行的任务
   * @param delayTicks 延迟 tick 数
   * @return BukkitTask，用于取消
   */
  public BukkitTask runSyncLater(Runnable task, long delayTicks) {
    return Bukkit.getScheduler().runTaskLater(plugin, task, delayTicks);
  }

  /**
   * 异步执行任务（主线程）
   *
   * @param task 要执行的任务
   * @param periodTicks 执行间隔 tick 数
   * @return BukkitTask，用于取消
   */
  public BukkitTask runSyncTimer(Runnable task, long delayTicks, long periodTicks) {
    return Bukkit.getScheduler().runTaskTimer(plugin, task, delayTicks, periodTicks);
  }

  /**
   * 在下一个 tick 执行任务（异步）
   *
   * @param task 要执行的任务
   * @return BukkitTask
   */
  public BukkitTask runNextTick(Runnable task) {
    return runSyncLater(task, 1L);
  }

  /**
   * 执行异步任务并在完成时调用回调（跨线程）
   *
   * @param task 要执行的任务
   * @param onComplete 完成回调（异步线程中执行）
   * @return 任务 ID
   */
  public int runAsyncWithCallback(Runnable task, Consumer<Throwable> onComplete) {
    if (shutdown) return -1;
    int taskId = taskIdGenerator.getAndIncrement();
    long startNanos = System.nanoTime();
    CompletableFuture.runAsync(task, asyncExecutor)
        .whenComplete(
            (result, ex) -> {
              recordTaskCompletion(startNanos, ex == null);
              if (onComplete != null) {
                onComplete.accept(ex);
              }
            });
    return taskId;
  }

  /** 关闭调度器，停止所有异步任务 使用优雅关闭，等待正在执行的任务完成 */
  public void shutdown() {
    if (shutdown) return;
    shutdown = true;
    cancelEntityRepeatingTasks();
    cancelGlobalRepeatingTasks();
    rejectPendingOperations();

    // 拒绝新任务
    asyncExecutor.shutdown();
    ioExecutor.shutdown();

    try {
      // 等待现有任务完成，最多等待30秒
      if (!asyncExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
        asyncExecutor.shutdownNow();
      }
      if (!ioExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
        ioExecutor.shutdownNow();
      }
    } catch (InterruptedException e) {
      asyncExecutor.shutdownNow();
      ioExecutor.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }

  /** 立即关闭调度器，不等待任务完成 */
  public void shutdownNow() {
    shutdown = true;
    cancelEntityRepeatingTasks();
    cancelGlobalRepeatingTasks();
    rejectPendingOperations();
    asyncExecutor.shutdownNow();
    ioExecutor.shutdownNow();
  }

  private void cancelGlobalRepeatingTasks() {
    for (GlobalRepeatingTask task : globalRepeatingTasks.toArray(GlobalRepeatingTask[]::new)) {
      cleanupDuringShutdown(task::cancel);
    }
  }

  private void cancelEntityRepeatingTasks() {
    for (EntityRepeatingTask task : entityRepeatingTasks.toArray(EntityRepeatingTask[]::new)) {
      cleanupDuringShutdown(task::retire);
    }
  }

  private void cleanupDuringShutdown(Runnable cleanup) {
    try {
      cleanup.run();
    } catch (RuntimeException | Error failure) {
      plugin
          .getLogger()
          .log(Level.WARNING, "Repeating task cleanup failed during shutdown", failure);
    }
  }

  private static final class StarCoreThreadFactory implements ThreadFactory {
    private final AtomicInteger id = new AtomicInteger();
    private final String prefix;

    StarCoreThreadFactory(String prefix) {
      this.prefix = prefix;
    }

    @Override
    public Thread newThread(Runnable runnable) {
      Thread thread = new Thread(runnable, "starcore-" + prefix + "-" + id.incrementAndGet());
      thread.setDaemon(true);
      // Set thread priority for better responsiveness
      thread.setPriority(Thread.NORM_PRIORITY + 1);
      return thread;
    }
  }
}
