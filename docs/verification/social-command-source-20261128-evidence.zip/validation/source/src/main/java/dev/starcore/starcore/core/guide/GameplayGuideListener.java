package dev.starcore.starcore.core.guide;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.java.JavaPlugin;

public final class GameplayGuideListener implements Listener {

  private static final int[] DASHBOARD_CHAPTER_SLOTS = {10, 11, 12, 13, 15, 16, 19, 20};
  private static final int[] CATEGORY_ITEM_SLOTS = {11, 12, 13, 14, 15, 16, 17};
  private static final int[] SEARCH_ITEM_SLOTS = {
    10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34
  };
  private final JavaPlugin plugin;
  private final GuideActionService actionService;
  private final Set<UUID> awaitingSearch = ConcurrentHashMap.newKeySet();

  public GameplayGuideListener(JavaPlugin plugin) {
    this.plugin = plugin;
    this.actionService = new GuideActionService(plugin);
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
  public void onClick(InventoryClickEvent event) {
    InventoryHolder holder = event.getInventory().getHolder();
    if (!(holder instanceof GameplayGuideGui gui)) return;
    event.setCancelled(true);
    if (!(event.getWhoClicked() instanceof Player player)) return;
    if (event.getClickedInventory() == null
        || !event.getClickedInventory().equals(event.getView().getTopInventory())) return;

    int slot = event.getRawSlot();
    GameplayGuideGui.ViewLevel level = gui.getViewLevel();

    switch (level) {
      case DASHBOARD -> handleDashboardClick(player, gui, slot);
      case CATEGORY_PAGE -> handleCategoryPageClick(player, gui, slot);
      case ITEM_DETAIL -> handleItemDetailClick(player, gui, slot);
      case STATS -> handleStatsClick(player, slot);
      case SEARCH_RESULTS -> handleSearchResultsClick(player, gui, slot);
    }
  }

  private void handleDashboardClick(Player player, GameplayGuideGui gui, int slot) {
    playClickSound(player);
    if (slot == 44) {
      player.closeInventory();
      return;
    }
    if (slot == 40) {
      GameplayGuideGui.openStats(player);
      return;
    }
    if (slot == 39) {
      awaitingSearch.add(player.getUniqueId());
      player.closeInventory();
      player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1.2f);
      player.sendMessage("§b请输入要搜索的玩法关键词，输入“取消”返回指南。");
      return;
    }
    for (int i = 0; i < DASHBOARD_CHAPTER_SLOTS.length; i++) {
      if (slot == DASHBOARD_CHAPTER_SLOTS[i]) {
        GuideChapter chapter = GuideChapter.values()[i];
        if (GuideProgressService.isChapterUnlocked(player, chapter)) {
          GameplayGuideGui.openCategoryPage(player, chapter, 0);
        } else {
          player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1.0f);
          player.sendMessage(
              "§c该章节尚未解锁！需要总进度 " + chapter.getUnlockCondition().getProgressThreshold() + "%");
        }
        return;
      }
    }
  }

  private void handleCategoryPageClick(Player player, GameplayGuideGui gui, int slot) {
    if (slot == 40) {
      playClickSound(player);
      GameplayGuideGui.openDashboard(player);
      return;
    }
    if (slot == 38 && gui.getCurrentPage() > 0) {
      playClickSound(player);
      GameplayGuideGui.openCategoryPage(player, gui.getCurrentChapter(), gui.getCurrentPage() - 1);
      return;
    }
    if (slot == 42) {
      playClickSound(player);
      GameplayGuideGui.openCategoryPage(player, gui.getCurrentChapter(), gui.getCurrentPage() + 1);
      return;
    }
    for (int i = 0; i < CATEGORY_ITEM_SLOTS.length; i++) {
      if (slot == CATEGORY_ITEM_SLOTS[i]) {
        int itemIndex = gui.getCurrentPage() * 7 + i;
        var items = GuideContentProvider.getItems(gui.getCurrentChapter());
        if (itemIndex >= 0 && itemIndex < items.size()) {
          GuideContentProvider.GuideItem gi = items.get(itemIndex);
          boolean unlocked =
              GuideProgressService.getProgress(player)
                      .getUnlockedItems(gui.getCurrentChapter())
                      .contains(gi.id())
                  || GuideProgressService.canAccessItem(player, gui.getCurrentChapter(), gi);
          if (unlocked) {
            playClickSound(player);
            GameplayGuideGui.openItemDetail(player, gui.getCurrentChapter(), gi);
          } else {
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1.0f);
            player.sendMessage("§c该内容尚未解锁！完成前置条件后即可查看。");
          }
        }
        return;
      }
    }
  }

  private void handleItemDetailClick(Player player, GameplayGuideGui gui, int slot) {
    if (slot == 44) {
      playClickSound(player);
      GameplayGuideGui.openCategoryPage(player, gui.getCurrentChapter(), gui.getCurrentPage());
      return;
    }
    if (slot == 40) {
      GuideContentProvider.GuideItem gi = gui.getCurrentItem();
      boolean unlocked =
          GuideProgressService.getProgress(player)
                  .getUnlockedItems(gui.getCurrentChapter())
                  .contains(gi.id())
              || GuideProgressService.canAccessItem(player, gui.getCurrentChapter(), gi);
      if (unlocked) {
        GuideProgressService.setItemUnlocked(player, gui.getCurrentChapter(), gi.id());
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.5f, 1.5f);
        player.sendMessage("§a§l✓ 已标记为学习: §f" + gi.title());
        player.sendMessage(
            "§7总进度: §a" + GuideProgressService.getProgress(player).getTotalProgress() + "%");
        GameplayGuideGui.openItemDetail(player, gui.getCurrentChapter(), gi);
      } else {
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1.0f);
        player.sendMessage("§c需要先解锁此内容");
      }
      return;
    }
    if (slot == 42) {
      GuideContentProvider.GuideItem item = gui.getCurrentItem();
      GuideActionService.ExecutionResult outcome = actionService.execute(player, item);
      switch (outcome) {
        case EXECUTED -> {
          GuideProgressService.setItemUnlocked(player, gui.getCurrentChapter(), item.id());
          player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 1.3f);
          player.sendMessage("§a已为你打开：§f" + GuideAction.forItem(item.id()).orElseThrow().label());
        }
        case REJECTED -> player.sendMessage("§c当前条件不满足，系统已拒绝这项操作。");
        case UNAVAILABLE -> player.sendMessage("§c这项功能当前不可用，请联系管理员检查插件状态。");
        case FAILED -> player.sendMessage("§c操作失败，状态未被指南擅自修改，请稍后重试。");
      }
      return;
    }
  }

  private void handleStatsClick(Player player, int slot) {
    if (slot == 40) {
      playClickSound(player);
      GameplayGuideGui.openMainMenu(player);
    }
  }

  private void handleSearchResultsClick(Player player, GameplayGuideGui gui, int slot) {
    if (slot == 40) {
      playClickSound(player);
      GameplayGuideGui.openMainMenu(player);
      return;
    }

    int resultIndex = -1;
    for (int i = 0; i < SEARCH_ITEM_SLOTS.length; i++) {
      if (SEARCH_ITEM_SLOTS[i] == slot) {
        resultIndex = i;
        break;
      }
    }
    GuideSearchService.SearchResult result = gui.getSearchResult(resultIndex);
    if (result == null) return;

    GuideContentProvider.GuideItem item = result.item();
    if (!GuideProgressService.isChapterUnlocked(player, result.chapter())
        || !GuideProgressService.canAccessItem(player, result.chapter(), item)) {
      player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5f, 1.0f);
      player.sendMessage("§c该内容尚未解锁，先完成指南中的前置内容。");
      return;
    }
    playClickSound(player);
    GameplayGuideGui.openItemDetail(player, result.chapter(), item);
  }

  private void playClickSound(Player player) {
    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof GameplayGuideGui) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onSearchInput(AsyncPlayerChatEvent event) {
    Player player = event.getPlayer();
    if (!awaitingSearch.remove(player.getUniqueId())) return;

    event.setCancelled(true);
    String query = event.getMessage().trim();
    plugin
        .getServer()
        .getScheduler()
        .runTask(
            plugin,
            () -> {
              if (query.isBlank() || query.equalsIgnoreCase("取消")) {
                player.sendMessage("§7已取消搜索。");
                GameplayGuideGui.openMainMenu(player);
                return;
              }
              var results = GuideSearchService.search(query);
              player.sendMessage("§a指南搜索完成：找到 " + results.size() + " 项。");
              GameplayGuideGui.openSearchResults(player, query, results);
            });
  }

  @EventHandler
  public void onQuit(PlayerQuitEvent event) {
    awaitingSearch.remove(event.getPlayer().getUniqueId());
    GuideProgressService.clearProgress(event.getPlayer().getUniqueId());
  }
}
