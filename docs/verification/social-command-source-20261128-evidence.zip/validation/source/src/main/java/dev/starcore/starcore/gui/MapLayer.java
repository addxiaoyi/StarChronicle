package dev.starcore.starcore.gui;

import java.util.*;
import java.util.Objects;

/** 地图图层 表示地图上的一个图层 */
public record MapLayer(
    String id, // 图层ID
    String name, // 图层名称
    double zIndex, // Z层级
    boolean visible, // 是否可见
    String world, // 世界名称
    int width, // 宽度
    int height, // 高度
    Map<String, Object> metadata // 元数据
    ) implements MapElement {

  @Override
  public String getId() {
    return id;
  }

  /** 检查坐标是否在图层范围内 */
  public boolean contains(double x, double y) {
    return x >= 0 && x <= 1.0 && y >= 0 && y <= 1.0;
  }

  /** 获取名称 */
  public String getName() {
    return name;
  }

  /** 获取Z层级（实现MapElement接口） */
  public double getZIndex() {
    return zIndex;
  }

  /** 获取X坐标 */
  public double getX() {
    return width / 2.0;
  }

  /** 获取Y坐标 */
  public double getY() {
    return height / 2.0;
  }

  /** 地图图层构建器 */
  public static Builder builder(String id, String name) {
    return new Builder(id, name);
  }

  public static class Builder {
    private final String id;
    private final String name;
    private double zIndex = 0.0;
    private boolean visible = true;
    private String world = "world";
    private int width = 800;
    private int height = 600;
    private final Map<String, Object> metadata = new HashMap<>();

    private Builder(String id, String name) {
      this.id = Objects.requireNonNull(id);
      this.name = Objects.requireNonNull(name);
    }

    public Builder zIndex(double zIndex) {
      this.zIndex = zIndex;
      return this;
    }

    public Builder visible(boolean visible) {
      this.visible = visible;
      return this;
    }

    public Builder world(String world) {
      this.world = world;
      return this;
    }

    public Builder size(int width, int height) {
      this.width = width;
      this.height = height;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public MapLayer build() {
      return new MapLayer(id, name, zIndex, visible, world, width, height, metadata);
    }
  }
}
