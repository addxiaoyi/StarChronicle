package dev.starcore.starcore.foundation.feedback;

import java.util.Objects;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/** Removes player-scoped feedback tasks as soon as a player leaves the server. */
public final class ParticleFeedbackListener implements Listener {
  private final ParticleFeedbackService feedbackService;

  public ParticleFeedbackListener(ParticleFeedbackService feedbackService) {
    this.feedbackService = Objects.requireNonNull(feedbackService, "feedbackService");
  }

  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    feedbackService.onPlayerQuit(event.getPlayer().getUniqueId());
  }
}
