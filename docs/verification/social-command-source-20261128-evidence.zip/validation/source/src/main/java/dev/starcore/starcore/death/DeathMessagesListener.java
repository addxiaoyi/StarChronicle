package dev.starcore.starcore.death;

import net.kyori.adventure.text.Component;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public final class DeathMessagesListener implements Listener {

  private final DeathMessageService service;

  public DeathMessagesListener(DeathMessageService service) {
    this.service = service;
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onPlayerDeath(PlayerDeathEvent event) {
    Component rendered = service.handleDeath(event);
    if (rendered != null) {
      event.deathMessage(rendered);
    }
  }
}
