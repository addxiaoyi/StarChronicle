package dev.starcore.starcore.dummy;

import java.util.UUID;

/** 单个玩家对单个训练目标的一次训练会话 会话在开始/结束之间累积该玩家的伤害统计，用于结算 DPS 与提交排行榜 */
public final class TrainingSession {

  private final UUID playerId;
  private final UUID dummyId;
  private final DamageTracker tracker = new DamageTracker();
  private long startTime;
  private long endTime;
  private boolean active;

  public TrainingSession(UUID playerId, UUID dummyId) {
    this.playerId = playerId;
    this.dummyId = dummyId;
  }

  public void start() {
    this.startTime = System.currentTimeMillis();
    this.endTime = 0;
    this.active = true;
  }

  public void stop() {
    this.endTime = System.currentTimeMillis();
    this.active = false;
  }

  public UUID getPlayerId() {
    return playerId;
  }

  public UUID getDummyId() {
    return dummyId;
  }

  public DamageTracker getTracker() {
    return tracker;
  }

  public boolean isActive() {
    return active;
  }

  /** 会话时长（毫秒），进行中按当前时间实时计算 */
  public long getDurationMillis() {
    if (startTime == 0) {
      return 0;
    }
    long end =
        active ? System.currentTimeMillis() : (endTime > 0 ? endTime : System.currentTimeMillis());
    return end - startTime;
  }

  /** 会话 DPS，优先按会话时长计算，无时长时回退到命中窗口 */
  public double getSessionDps() {
    long duration = getDurationMillis();
    if (duration <= 0) {
      return tracker.getDps();
    }
    return tracker.getTotalDamage() / (duration / 1000.0);
  }
}
