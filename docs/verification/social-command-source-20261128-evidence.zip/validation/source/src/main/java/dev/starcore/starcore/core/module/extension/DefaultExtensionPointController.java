package dev.starcore.starcore.core.module.extension;

import dev.starcore.starcore.core.extension.ExtensionContributor;
import dev.starcore.starcore.core.extension.ExtensionPoint;
import dev.starcore.starcore.core.extension.ExtensionRegistry;
import java.util.List;
import java.util.Objects;

/** 默认扩展点控制器实现 */
public class DefaultExtensionPointController implements ExtensionPointController {

  private final ModuleExtension moduleExtension;
  private final ExtensionRegistry registry;

  public DefaultExtensionPointController(ModuleExtension moduleExtension) {
    this.moduleExtension = Objects.requireNonNull(moduleExtension, "moduleExtension");
    this.registry = ExtensionRegistry.getInstance();
  }

  @Override
  public ModuleExtension getModuleExtension() {
    return moduleExtension;
  }

  @Override
  public <T, R> void registerContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor) {
    Objects.requireNonNull(extensionPoint, "extensionPoint");
    Objects.requireNonNull(contributor, "contributor");
    registry.registerContributor(extensionPoint, contributor);
  }

  @Override
  public <T, R> void unregisterContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor) {
    Objects.requireNonNull(extensionPoint, "extensionPoint");
    Objects.requireNonNull(contributor, "contributor");
    registry.unregisterContributor(extensionPoint, contributor);
  }

  @Override
  public void unregisterAll() {
    registry.unregisterAllContributors();
  }

  @Override
  public List<ExtensionPoint<?, ?>> getRegisteredExtensionPoints() {
    return registry.getAllExtensionPoints().stream()
        .filter(ep -> moduleExtension.getRequiredExtensionPoints().contains(ep.getName()))
        .toList();
  }

  @Override
  @SuppressWarnings("unchecked")
  public <T, R> T executeExtension(String extensionPointId, R request) {
    return (T) registry.execute(extensionPointId, request);
  }

  @Override
  @SuppressWarnings("unchecked")
  public <T, R> T executeExtensionFirst(String extensionPointId, R request) {
    return (T) registry.executeFirst(extensionPointId, request);
  }

  @Override
  public boolean hasExtensionPoint(String name) {
    return registry.hasExtensionPoint(name);
  }
}
