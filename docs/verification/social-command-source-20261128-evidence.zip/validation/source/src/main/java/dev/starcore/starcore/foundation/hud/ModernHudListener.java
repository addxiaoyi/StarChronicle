package dev.starcore.starcore.foundation.hud;

import dev.starcore.starcore.foundation.util.RandomProvider;
import dev.starcore.starcore.performance.OptimizedMoveListener;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/** 现代 HUD 菜单事件监听器 处理菜单点击事件和动态粒子效果 */
public class ModernHudListener implements org.bukkit.event.Listener {

  private static volatile ModernHudListener instance;
  private final Plugin plugin;
  private volatile boolean closed;

  // 打开的菜单映射
  private final Map<UUID, MenuSession> openMenus = new ConcurrentHashMap<>();
  private final Map<UUID, OpenAttempt> pendingOpens = new HashMap<>();

  static final class OpenAttempt {
    final Player player;
    final ModernHudMenu menu;
    Inventory inventory;

    OpenAttempt(Player player, ModernHudMenu menu) {
      this.player = player;
      this.menu = menu;
    }
  }

  synchronized OpenAttempt beginOpen(Player player, ModernHudMenu menu) {
    requirePlayerOwner(player, plugin);
    OpenAttempt attempt = new OpenAttempt(player, menu);
    pendingOpens.put(player.getUniqueId(), attempt);
    return attempt;
  }

  synchronized boolean currentOpen(OpenAttempt attempt) {
    return currentPlayer(attempt.player)
        && pendingOpens.get(attempt.player.getUniqueId()) == attempt;
  }

  synchronized void prepareOpen(OpenAttempt attempt, Inventory inventory) {
    if (currentOpen(attempt)) attempt.inventory = inventory;
  }

  synchronized boolean commitOpen(OpenAttempt attempt) {
    if (!currentOpen(attempt)
        || attempt.player.getOpenInventory().getTopInventory() != attempt.inventory) return false;
    pendingOpens.remove(attempt.player.getUniqueId());
    stopParticleEffect(attempt.player);
    MenuSession previous =
        openMenus.put(
            attempt.player.getUniqueId(),
            new MenuSession(attempt.player, attempt.menu, attempt.inventory));
    if (previous != null && previous.menu != attempt.menu) {
      if (previous.player == attempt.player) previous.menu.handleClose();
      else previous.menu.retire();
    }
    MenuSession current = openMenus.get(attempt.player.getUniqueId());
    return current != null
        && current.player == attempt.player
        && current.menu == attempt.menu
        && current.inventory == attempt.inventory;
  }

  synchronized void abortOpen(OpenAttempt attempt) {
    if (pendingOpens.get(attempt.player.getUniqueId()) == attempt)
      pendingOpens.remove(attempt.player.getUniqueId());
  }

  // 粒子动画任务
  private final Map<UUID, ParticleRun> particleTasks = new ConcurrentHashMap<>();

  // 背景粒子配置
  private volatile boolean globalParticlesEnabled = true;
  private volatile ParticleType particleType = ParticleType.SPARKLE;
  private volatile double particleSpeed = 0.02;
  private volatile int particleDensity = 3;

  // Move-dispatcher subscription handle; null when not subscribed.
  private volatile Object subscription;
  private OptimizedMoveListener dispatcher;

  /** Subscribe to the central move dispatcher. Idempotent. */
  public synchronized void subscribe(OptimizedMoveListener dispatcher) {
    if (closed || dispatcher == null || subscription != null) return;
    this.dispatcher = dispatcher;
    subscription = dispatcher.registerBlock(this::onBlockMove);
  }

  public synchronized void unsubscribe(OptimizedMoveListener dispatcher) {
    if (this.dispatcher == null || subscription == null) return;
    this.dispatcher.unregister(subscription);
    subscription = null;
    this.dispatcher = null;
  }

  private ModernHudListener(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 初始化监听器 */
  public static ModernHudListener initialize(Plugin plugin) {
    ModernHudListener previous = null;
    ModernHudListener current;
    synchronized (ModernHudListener.class) {
      if (instance != null && instance.plugin != plugin) {
        previous = instance;
        instance = null;
      }
      if (instance == null) {
        instance = new ModernHudListener(plugin);
        plugin.getServer().getPluginManager().registerEvents(instance, plugin);
      }
      current = instance;
    }
    if (previous != null) previous.shutdown();
    return current;
  }

  /** 获取实例 */
  public static ModernHudListener getInstance() {
    ModernHudListener listener = instance;
    if (listener == null || listener.closed) {
      throw new IllegalStateException("ModernHudListener not initialized");
    }
    return listener;
  }

  // ==================== 菜单注册 ====================

  public static void register(Player player, ModernHudMenu menu) {
    getInstance().registerMenu(player, menu);
  }

  private synchronized void registerMenu(Player player, ModernHudMenu menu) {
    if (!currentPlayer(player) || !Bukkit.isOwnedByCurrentRegion(player)) return;
    if (menu.getPlayer() != player)
      throw new IllegalArgumentException("HUD player session differs");
    stopParticleEffect(player);
    openMenus.put(player.getUniqueId(), new MenuSession(player, menu, menu.getInventory()));
  }

  public static void unregister(Player player) {
    getInstance().removeMenu(player, null, false);
  }

  synchronized void closeMenu(Player player, ModernHudMenu menu) {
    MenuSession session = openMenus.get(player.getUniqueId());
    if (session != null && session.player == player && session.menu == menu)
      removeMenu(player, session.inventory, true);
  }

  public static ModernHudMenu getMenu(Player player) {
    MenuSession session = getInstance().openMenus.get(player.getUniqueId());
    return session != null && session.player == player ? session.menu : null;
  }

  private boolean currentPlayer(Player player) {
    return !closed
        && plugin.isEnabled()
        && player.isOnline()
        && plugin.getServer().getPlayer(player.getUniqueId()) == player;
  }

  static void requirePlayerOwner(Player player, Plugin plugin) {
    ModernHudListener listener = getInstance();
    if (listener.plugin != plugin
        || !listener.currentPlayer(player)
        || !Bukkit.isOwnedByCurrentRegion(player)) {
      throw new IllegalStateException("HUD operation requires the current player session owner");
    }
  }

  static void withPlayerOwner(Player player, Plugin plugin, Runnable operation) {
    ModernHudListener listener = getInstance();
    synchronized (listener) {
      requirePlayerOwner(player, plugin);
      operation.run();
    }
  }

  // ==================== 事件处理 ====================

  @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.HIGH)
  public synchronized void onInventoryClick(org.bukkit.event.inventory.InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    MenuSession session = openMenus.get(player.getUniqueId());
    if (session == null
        || session.player != player
        || !currentPlayer(player)
        || !Bukkit.isOwnedByCurrentRegion(player)) {
      return;
    }
    ModernHudMenu menu = session.menu;

    if (event.getView().getTopInventory() != session.inventory) return;
    event.setCancelled(true);

    Inventory clickedInventory = event.getClickedInventory();
    if (clickedInventory == null || !clickedInventory.equals(menu.getInventory())) {
      return;
    }

    int slot = event.getRawSlot();
    if (slot < 0 || slot >= menu.getSize()) {
      return;
    }

    ItemStack item = clickedInventory.getItem(slot);
    if (item == null || item.getType() == Material.AIR) {
      return;
    }

    // 处理点击
    menu.handleClick(player, slot, item);
  }

  @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.HIGH)
  public synchronized void onInventoryDrag(org.bukkit.event.inventory.InventoryDragEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) return;
    MenuSession session = openMenus.get(player.getUniqueId());
    if (session != null
        && session.player == player
        && event.getView().getTopInventory() == session.inventory) {
      event.setCancelled(true);
    }
  }

  @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.HIGH)
  public synchronized void onInventoryClose(org.bukkit.event.inventory.InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }

    if (!currentPlayer(player) || !Bukkit.isOwnedByCurrentRegion(player)) return;
    OpenAttempt attempt = pendingOpens.get(player.getUniqueId());
    if (attempt != null && attempt.player == player && attempt.inventory == event.getInventory()) {
      pendingOpens.remove(player.getUniqueId());
      attempt.menu.retire();
    }
    MenuSession current = openMenus.get(player.getUniqueId());
    boolean refresh = attempt != null && current != null && attempt.menu == current.menu;
    removeMenu(player, event.getInventory(), !refresh);
  }

  @org.bukkit.event.EventHandler
  public void onPlayerQuit(org.bukkit.event.player.PlayerQuitEvent event) {
    removeMenu(event.getPlayer(), null, false);
  }

  private synchronized void removeMenu(Player player, Inventory inventory, boolean notify) {
    MenuSession session = openMenus.get(player.getUniqueId());
    if (inventory == null) {
      OpenAttempt attempt = pendingOpens.get(player.getUniqueId());
      if (attempt != null && attempt.player == player) pendingOpens.remove(player.getUniqueId());
    }
    if (session == null
        || session.player != player
        || (inventory != null && session.inventory != inventory)) return;
    openMenus.remove(player.getUniqueId(), session);
    OpenAttempt attempt = pendingOpens.get(player.getUniqueId());
    if (attempt != null && attempt.player == player && attempt.inventory == inventory)
      pendingOpens.remove(player.getUniqueId());
    stopParticleEffect(player);
    if (notify) session.menu.handleClose();
    else session.menu.retire();
  }

  public synchronized void onBlockMove(Player player, Location from, Location to) {
    MenuSession session = openMenus.get(player.getUniqueId());
    if (session != null
        && session.player == player
        && currentPlayer(player)
        && Bukkit.isOwnedByCurrentRegion(player)
        && session.menu.isOpen()
        && globalParticlesEnabled
        && player.getOpenInventory().getTopInventory() == session.inventory) {
      // 玩家移动时增强粒子效果
      spawnMenuParticles(player, particleDensity * 2);
    }
  }

  // ==================== 粒子动画 ====================

  /** 启动动态背景粒子效果 */
  public synchronized void startParticleEffect(Player player) {
    MenuSession session = openMenus.get(player.getUniqueId());
    if (!globalParticlesEnabled
        || !currentPlayer(player)
        || !Bukkit.isOwnedByCurrentRegion(player)
        || session == null
        || session.player != player) return;
    stopParticleEffect(player);
    ParticleRun started = new ParticleRun(player.getUniqueId(), session);
    particleTasks.put(started.playerId, started);
    try {
      started.attach(
          player
              .getScheduler()
              .runAtFixedRate(
                  plugin,
                  scheduled -> tickParticles(started, scheduled),
                  () -> retire(started),
                  1L,
                  3L));
    } catch (RuntimeException | Error failure) {
      retire(started);
      throw failure;
    }
  }

  /** 停止玩家的粒子效果 */
  public synchronized void stopParticleEffect(Player player) {
    ParticleRun task = particleTasks.get(player.getUniqueId());
    if (task != null && task.session.player == player) retire(task);
  }

  private synchronized void tickParticles(ParticleRun expected, ScheduledTask scheduled) {
    expected.attach(scheduled);
    if (!expected.active || particleTasks.get(expected.playerId) != expected) return;
    Player player = expected.session.player;
    if (!currentPlayer(player)
        || !globalParticlesEnabled
        || openMenus.get(expected.playerId) != expected.session
        || !Bukkit.isOwnedByCurrentRegion(player)) {
      retire(expected);
      return;
    }
    if (!player.isOnline()
        || !expected.session.menu.isOpen()
        || player.getOpenInventory().getTopInventory() != expected.session.inventory) {
      retire(expected);
      return;
    }
    try {
      spawnMenuParticles(player, particleDensity);
    } catch (RuntimeException | Error failure) {
      retire(expected);
      throw failure;
    }
  }

  private synchronized void retire(ParticleRun expected) {
    expected.active = false;
    particleTasks.remove(expected.playerId, expected);
    expected.cancel();
  }

  private record MenuSession(Player player, ModernHudMenu menu, Inventory inventory) {}

  private final class ParticleRun {
    private final UUID playerId;
    private final MenuSession session;
    private boolean active = true;
    private ScheduledTask task;
    private boolean cancelled;

    private ParticleRun(UUID playerId, MenuSession session) {
      this.playerId = playerId;
      this.session = session;
    }

    private void attach(ScheduledTask scheduled) {
      if (task == null) task = scheduled;
      if (scheduled == null) retire(this);
      else if (!active) cancel();
    }

    private void cancel() {
      if (task != null && !cancelled) {
        cancelled = true;
        try {
          task.cancel();
        } catch (RuntimeException failure) {
          plugin.getLogger().warning("HUD particle cancellation failed: " + failure.getMessage());
        }
      }
    }
  }

  // 关键优化：颜色数组提取为静态常量，避免每次粒子刷新都重新分配 5 个 Color 对象
  private static final Color[] SPARKLE_COLORS = {
    Color.WHITE,
    Color.fromRGB(255, 215, 0),
    Color.fromRGB(0, 255, 255),
    Color.fromRGB(255, 182, 193),
    Color.fromRGB(173, 255, 47)
  };
  private static final Color[] AURORA_COLORS = {
    Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.BLUE, Color.PURPLE
  };

  /** 生成菜单粒子效果 */
  private void spawnMenuParticles(Player player, int count) {
    // 关键优化：使用一个共享 Location 配合 add()，而不是循环里 loc.clone() 反复分配
    Location sharedLoc = player.getLocation().add(0, 1.5, 0);

    switch (particleType) {
      case SPARKLE -> spawnSparkleParticles(player, sharedLoc, count);
      case FIREFLY -> spawnFireflyParticles(player, sharedLoc, count);
      case AURORA -> spawnAuroraParticles(player, sharedLoc, count);
      case STARDUST -> spawnStardustParticles(player, sharedLoc, count);
      case BUBBLE -> spawnBubbleParticles(player, sharedLoc, count);
      case NONE -> {
        /* 不生成粒子 */
      }
    }
  }

  /** 闪烁粒子效果 */
  private void spawnSparkleParticles(Player player, Location loc, int count) {
    // 关键优化：loc 在此处复用，循环内不调用 clone()
    for (int i = 0; i < count; i++) {
      double x = (RandomProvider.nextDouble() - 0.5) * 2.5;
      double y = RandomProvider.nextDouble() * 2.0;
      double z = (RandomProvider.nextDouble() - 0.5) * 2.5;

      int colorIndex = RandomProvider.nextInt(SPARKLE_COLORS.length);
      // Bukkit API: spawnParticle 在传入 Location 时实际上需要的是坐标；重复使用 loc.add() 后还原
      loc.add(x, y, z);
      player.spawnParticle(
          Particle.DUST,
          loc,
          1,
          0.05,
          0.05,
          0.05,
          particleSpeed,
          new org.bukkit.Particle.DustOptions(SPARKLE_COLORS[colorIndex], 1));
      loc.subtract(x, y, z);
    }

    // 添加一些星光粒子
    if (RandomProvider.nextInt(5) == 0) {
      loc.add(0, 2.0 + RandomProvider.nextDouble(), 0);
      player.spawnParticle(Particle.END_ROD, loc, 1, 0.1, 0.1, 0.1, 0.01);
      loc.subtract(0, 2.0 + RandomProvider.nextDouble(), 0);
    }
  }

  /** 萤火虫粒子效果 */
  private void spawnFireflyParticles(Player player, Location loc, int count) {
    for (int i = 0; i < count; i++) {
      double angle = RandomProvider.nextDouble() * Math.PI * 2;
      double radius = 1.0 + RandomProvider.nextDouble() * 1.0;
      double height = RandomProvider.nextDouble() * 2.5;

      double x = Math.cos(angle) * radius;
      double z = Math.sin(angle) * radius;

      loc.add(x, height, z);
      player.spawnParticle(Particle.WITCH, loc, 1, 0.02, 0.02, 0.02, particleSpeed);
      loc.subtract(x, height, z);
    }
  }

  /** 极光粒子效果 */
  private void spawnAuroraParticles(Player player, Location loc, int count) {
    for (int i = 0; i < count; i++) {
      double angle = RandomProvider.nextDouble() * Math.PI * 2;
      double radius = 1.5;
      double height = 0.5 + RandomProvider.nextDouble() * 1.5;

      double x = Math.cos(angle) * radius;
      double z = Math.sin(angle) * radius;

      // 关键优化：使用 switch 整数分支索引静态颜色数组（无需生成 hue 浮点）
      int idx = (int) (RandomProvider.nextDouble() * AURORA_COLORS.length);
      Color color = AURORA_COLORS[idx];

      loc.add(x, height, z);
      player.spawnParticle(
          Particle.DUST,
          loc,
          1,
          0.05,
          0.05,
          0.05,
          particleSpeed,
          new org.bukkit.Particle.DustOptions(color, 2));
      loc.subtract(x, height, z);
    }
  }

  /** 星尘粒子效果 */
  private void spawnStardustParticles(Player player, Location loc, int count) {
    for (int i = 0; i < count; i++) {
      double x = (RandomProvider.nextDouble() - 0.5) * 3.0;
      double y = RandomProvider.nextDouble() * 3.0;
      double z = (RandomProvider.nextDouble() - 0.5) * 3.0;

      loc.add(x, y, z);
      player.spawnParticle(Particle.FIREWORK, loc, 1, 0.02, 0.02, 0.02, particleSpeed);
      player.spawnParticle(Particle.END_ROD, loc, 1, 0.01, 0.01, 0.01, 0.005);
      loc.subtract(x, y, z);
    }
  }

  /** 气泡粒子效果 */
  private void spawnBubbleParticles(Player player, Location loc, int count) {
    for (int i = 0; i < count; i++) {
      double x = (RandomProvider.nextDouble() - 0.5) * 2.0;
      double y = RandomProvider.nextDouble() * 2.5;
      double z = (RandomProvider.nextDouble() - 0.5) * 2.0;

      loc.add(x, y, z);
      player.spawnParticle(Particle.ITEM_SNOWBALL, loc, 1, 0.05, 0.05, 0.05, particleSpeed);

      // 偶尔添加水花
      if (RandomProvider.nextInt(10) == 0) {
        player.spawnParticle(Particle.SPLASH, loc, 2, 0.02, 0.02, 0.02, 0.01);
      }
      loc.subtract(x, y, z);
    }
  }

  // ==================== 配置方法 ====================

  public synchronized void setGlobalParticlesEnabled(boolean enabled) {
    this.globalParticlesEnabled = enabled;

    if (!enabled) {
      // 取消所有粒子任务
      List.copyOf(particleTasks.values()).forEach(this::retire);
    }
  }

  public void setParticleType(ParticleType type) {
    this.particleType = type;
  }

  public void setParticleSpeed(double speed) {
    this.particleSpeed = Math.max(0.001, Math.min(0.1, speed));
  }

  public void setParticleDensity(int density) {
    this.particleDensity = Math.max(1, Math.min(10, density));
  }

  public boolean isGlobalParticlesEnabled() {
    return globalParticlesEnabled;
  }

  public ParticleType getParticleType() {
    return particleType;
  }

  // ==================== 清理 ====================

  public void shutdown() {
    synchronized (this) {
      if (closed) return;
      closed = true;
      unsubscribe(dispatcher);
      List.copyOf(particleTasks.values()).forEach(this::retire);
      openMenus.values().forEach(session -> session.menu.retire());
      openMenus.clear();
      pendingOpens.clear();
      org.bukkit.event.HandlerList.unregisterAll(this);
    }
    synchronized (ModernHudListener.class) {
      if (instance == this) instance = null;
    }
  }

  // ==================== 粒子类型枚举 ====================

  public enum ParticleType {
    NONE("无"),
    SPARKLE("闪烁"),
    FIREFLY("萤火虫"),
    AURORA("极光"),
    STARDUST("星尘"),
    BUBBLE("气泡");

    private final String displayName;

    ParticleType(String displayName) {
      this.displayName = displayName;
    }

    public String getDisplayName() {
      return displayName;
    }
  }
}
