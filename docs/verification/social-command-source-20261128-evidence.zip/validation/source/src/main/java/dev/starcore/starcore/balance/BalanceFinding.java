package dev.starcore.starcore.balance;

import java.util.Objects;

public record BalanceFinding(
    String code, BalanceSeverity severity, String summary, String recommendation) {
  public BalanceFinding {
    code = Objects.requireNonNull(code, "code");
    severity = Objects.requireNonNull(severity, "severity");
    summary = Objects.requireNonNull(summary, "summary");
    recommendation = Objects.requireNonNull(recommendation, "recommendation");
  }
}
