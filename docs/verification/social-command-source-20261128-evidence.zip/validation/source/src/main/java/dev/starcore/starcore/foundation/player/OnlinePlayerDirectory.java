package dev.starcore.starcore.foundation.player;

import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface OnlinePlayerDirectory {
    Optional<Player> findOnlinePlayer(UUID playerId);

    Optional<Player> findPlayerById(UUID playerId);

    default Optional<Player> findPlayerByName(String name) {
        if (name == null || name.isBlank()) {
            return Optional.empty();
        }
        return onlinePlayers().stream()
            .filter(p -> p.getName() != null && p.getName().equalsIgnoreCase(name))
            .findFirst();
    }

    Collection<Player> onlinePlayers();

    /**
     * 获取玩家的显示名称
     * @param playerId 玩家ID
     * @return 显示名称（优先在线名称，否则返回UUID字符串）
     */
    default Optional<String> displayName(UUID playerId) {
        return findOnlinePlayer(playerId)
            .map(Player::getName)
            .or(() -> Optional.of(playerId.toString()));
    }

    default List<String> onlinePlayerNames() {
        return onlinePlayers().stream()
            .map(Player::getName)
            .filter(name -> name != null && !name.isBlank())
            .toList();
    }

    default UUID resolvePlayerId(String name) {
        if (name == null || name.isBlank()) {
            return null;
        }
        Optional<Player> online = findPlayerByName(name);
        if (online.isPresent()) {
            return online.get().getUniqueId();
        }
        if (org.bukkit.Bukkit.getServer() != null) {
            try {
                org.bukkit.OfflinePlayer offline = org.bukkit.Bukkit.getOfflinePlayer(name);
                if (offline != null && offline.getUniqueId() != null) {
                    return offline.getUniqueId();
                }
            } catch (Exception ignored) {
            }
        }
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    default String resolvePlayerName(UUID playerId) {
        if (playerId == null) {
            return "未知";
        }
        Optional<Player> online = findOnlinePlayer(playerId);
        if (online.isPresent()) {
            return online.get().getName();
        }
        if (org.bukkit.Bukkit.getServer() != null) {
            try {
                org.bukkit.OfflinePlayer offline = org.bukkit.Bukkit.getOfflinePlayer(playerId);
                if (offline != null && offline.getName() != null) {
                    return offline.getName();
                }
            } catch (Exception ignored) {
            }
        }
        return playerId.toString();
    }
}
