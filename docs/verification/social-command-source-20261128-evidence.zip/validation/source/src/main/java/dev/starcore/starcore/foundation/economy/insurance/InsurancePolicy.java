package dev.starcore.starcore.foundation.economy.insurance;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Persisted player-owned insurance policy. */
public record InsurancePolicy(
    UUID policyId,
    UUID playerId,
    InsuranceCoverage coverage,
    BigDecimal maxPayout,
    BigDecimal deductible,
    BigDecimal premium,
    Instant startsAt,
    Instant expiresAt,
    InsurancePolicyState state,
    UUID claimSourceTransactionId,
    UUID payoutTransactionId,
    String lastError) {
  public InsurancePolicy {
    Objects.requireNonNull(policyId, "policyId");
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(coverage, "coverage");
    Objects.requireNonNull(maxPayout, "maxPayout");
    Objects.requireNonNull(deductible, "deductible");
    Objects.requireNonNull(premium, "premium");
    Objects.requireNonNull(startsAt, "startsAt");
    Objects.requireNonNull(expiresAt, "expiresAt");
    Objects.requireNonNull(state, "state");
    if (maxPayout.signum() <= 0) throw new IllegalArgumentException("maxPayout must be positive");
    if (deductible.signum() < 0 || deductible.compareTo(maxPayout) > 0) {
      throw new IllegalArgumentException("deductible must be within payout range");
    }
    if (premium.signum() <= 0) throw new IllegalArgumentException("premium must be positive");
    if (!expiresAt.isAfter(startsAt))
      throw new IllegalArgumentException("expiresAt must be after startsAt");
  }

  public boolean activeAt(Instant now) {
    return state == InsurancePolicyState.ACTIVE
        && !now.isBefore(startsAt)
        && now.isBefore(expiresAt);
  }

  public BigDecimal payoutFor(BigDecimal sourceAmount) {
    return sourceAmount.subtract(deductible).max(BigDecimal.ZERO).min(maxPayout);
  }
}
