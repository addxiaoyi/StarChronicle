package dev.starcore.starcore.evidence;

import java.util.*;

/** 证据模型 表示一个具体的证据实例 */
public record Evidence(
    String evidenceId, // 证据ID
    String playerId, // 拥有者ID
    EvidenceType type, // 证据类型
    String sourceId, // 来源ID（Boss ID、选择ID等）
    Map<String, Object> metadata, // 元数据
    long obtainedAt, // 获得时间
    long expiresAt, // 过期时间（0表示不过期）
    boolean used // 是否已使用
    ) {

  /** 创建证据构建器 */
  public static Builder builder(String evidenceId, String playerId, EvidenceType type) {
    return new Builder(evidenceId, playerId, type);
  }

  /** 检查证据是否有效 */
  public boolean isValid() {
    if (used) return false;
    if (expiresAt > 0 && System.currentTimeMillis() > expiresAt) return false;
    return true;
  }

  /** 检查证据是否过期 */
  public boolean isExpired() {
    return expiresAt > 0 && System.currentTimeMillis() > expiresAt;
  }

  /** 证据构建器 */
  public static class Builder {
    private final String evidenceId;
    private final String playerId;
    private final EvidenceType type;
    private String sourceId;
    private Map<String, Object> metadata = new HashMap<>();
    private long obtainedAt = System.currentTimeMillis();
    private long expiresAt = 0; // 默认不过期
    private boolean used = false;

    private Builder(String evidenceId, String playerId, EvidenceType type) {
      this.evidenceId = Objects.requireNonNull(evidenceId);
      this.playerId = Objects.requireNonNull(playerId);
      this.type = Objects.requireNonNull(type);
    }

    public Builder sourceId(String sourceId) {
      this.sourceId = sourceId;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public Builder obtainedAt(long obtainedAt) {
      this.obtainedAt = obtainedAt;
      return this;
    }

    public Builder expiresAt(long expiresAt) {
      this.expiresAt = expiresAt;
      return this;
    }

    public Builder expiresIn(long millis) {
      this.expiresAt = System.currentTimeMillis() + millis;
      return this;
    }

    public Builder used(boolean used) {
      this.used = used;
      return this;
    }

    public Evidence build() {
      return new Evidence(
          evidenceId, playerId, type, sourceId, Map.copyOf(metadata), obtainedAt, expiresAt, used);
    }
  }
}
