package dev.starcore.starcore.foundation.economy.transaction;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Immutable input for an idempotent transaction. */
public record TransactionRequest(
    UUID accountId,
    BigDecimal amount,
    RefundOwner owner,
    TransactionType type,
    String reason,
    String idempotencyKey,
    Map<String, String> metadata) {
  public TransactionRequest {
    Objects.requireNonNull(accountId, "accountId");
    Objects.requireNonNull(amount, "amount");
    Objects.requireNonNull(owner, "owner");
    Objects.requireNonNull(type, "type");
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(idempotencyKey, "idempotencyKey");
    Objects.requireNonNull(metadata, "metadata");
    if (amount.signum() <= 0) throw new IllegalArgumentException("amount must be positive");
    if (idempotencyKey.isBlank())
      throw new IllegalArgumentException("idempotencyKey must not be blank");
    metadata = Map.copyOf(metadata);
  }

  public TransactionRequest(
      UUID accountId,
      BigDecimal amount,
      RefundOwner owner,
      TransactionType type,
      String reason,
      String idempotencyKey) {
    this(accountId, amount, owner, type, reason, idempotencyKey, Map.of());
  }
}
