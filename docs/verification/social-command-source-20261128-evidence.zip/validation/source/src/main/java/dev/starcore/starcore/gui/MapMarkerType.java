package dev.starcore.starcore.gui;

/** 地图标记类型 */
public enum MapMarkerType {
  PLAYER_HOME("玩家房屋"),
  PLAYER_LOCATION("玩家位置"),
  NPC_HOME("NPC房屋"),
  RESOURCE_POINT("资源点"),
  DUNGEON("副本入口"),
  BOSS_SPAWN("Boss刷点"),
  QUEST_POINT("任务点"),
  SAFE_ZONE("安全区"),
  NEUTRAL_ZONE("中立区"),
  WAR_ZONE("战场"),
  CUSTOM("自定义");

  private final String description;

  MapMarkerType(String description) {
    this.description = description;
  }

  public String getDescription() {
    return description;
  }
}
