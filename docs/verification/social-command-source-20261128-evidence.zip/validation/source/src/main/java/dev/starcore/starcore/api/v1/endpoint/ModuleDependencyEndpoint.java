package dev.starcore.starcore.api.v1.endpoint;

import static dev.starcore.starcore.api.v1.dto.ModuleDependencyDto.fromLayer;
import static dev.starcore.starcore.api.v1.dto.ModuleDependencyDto.statusToString;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.dto.ModuleDependencyDto;
import dev.starcore.starcore.api.v1.dto.ModuleDependencyDto.CycleDto;
import dev.starcore.starcore.api.v1.dto.ModuleDependencyDto.HealthDto;
import dev.starcore.starcore.api.v1.dto.ModuleDependencyDto.NodeDto;
import dev.starcore.starcore.api.v1.handler.BaseHttpHandler;
import dev.starcore.starcore.core.module.ModuleStatus;
import dev.starcore.starcore.core.monitor.ModuleDependencyMonitor;
import dev.starcore.starcore.core.monitor.ModuleDependencyMonitor.CycleInfo;
import dev.starcore.starcore.core.monitor.ModuleDependencyMonitor.DependencyGraph;
import dev.starcore.starcore.core.monitor.ModuleDependencyMonitor.ModuleNode;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * 模块依赖 REST API 端点
 *
 * <p>导出模块依赖关系图、循环依赖、未满足依赖及服务健康状态。
 *
 * <ul>
 *   <li>GET /api/v1/deps
 *   <li>GET /api/v1/deps/services?moduleId=...
 * </ul>
 */
public final class ModuleDependencyEndpoint extends BaseHttpHandler {

  private final ModuleDependencyMonitor monitor;

  public ModuleDependencyEndpoint(
      Gson gson, ApiAuthService authService, ModuleDependencyMonitor monitor) {
    this(gson, authService, monitor, RestApiConfig.CorsConfig.DEFAULT, false);
  }

  public ModuleDependencyEndpoint(
      Gson gson,
      ApiAuthService authService,
      ModuleDependencyMonitor monitor,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth) {
    super(gson, authService, corsConfig, requiresAuth, null);
    this.monitor = monitor;
  }

  @Override
  protected void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    String path = getPath(exchange);

    if (!isMethod(exchange, "GET")) {
      sendMethodNotAllowed(exchange);
      return;
    }

    if (monitor == null) {
      sendError(
          exchange,
          503,
          "DEPENDENCY_MONITOR_UNAVAILABLE",
          "Module dependency monitor is not available on this server");
      return;
    }

    if (path.equals("/api/v1/deps")) {
      handleGraph(exchange);
    } else if (path.startsWith("/api/v1/deps/services")) {
      Map<String, String> params = parseQueryParams(exchange);
      String moduleId = params.get("moduleId");
      if (moduleId == null || moduleId.isBlank()) {
        sendError(exchange, 400, "INVALID_PARAMETER", "moduleId is required");
        return;
      }
      handleModule(exchange, moduleId.trim());
    } else {
      sendNotFound(exchange, "Endpoint");
    }
  }

  private void handleGraph(HttpExchange exchange) throws IOException {
    DependencyGraph graph = monitor.snapshot();
    List<String> unmet = monitor.unmetDependencies();

    Map<String, NodeDto> nodes = new LinkedHashMap<>();
    int enabledCount = 0;
    int failedCount = 0;
    for (ModuleNode node : graph.nodes().values()) {
      if (node.status() == ModuleStatus.ENABLED) {
        enabledCount++;
      } else if (node.status() == ModuleStatus.FAILED) {
        failedCount++;
      }
      nodes.put(node.id(), toNodeDto(node));
    }

    List<CycleDto> cycles = graph.cycles().stream().map(this::toCycleDto).toList();

    HealthDto health =
        new HealthDto(nodes.size(), enabledCount, failedCount, !cycles.isEmpty(), !unmet.isEmpty());

    ModuleDependencyDto payload = new ModuleDependencyDto(nodes, cycles, unmet, health);

    sendSuccess(exchange, payload, ApiResponse.ResponseMeta.of(generateRequestId()));
  }

  private void handleModule(HttpExchange exchange, String moduleId) throws IOException {
    DependencyGraph graph = monitor.snapshot();
    ModuleNode node = null;
    for (Map.Entry<String, ModuleNode> e : graph.nodes().entrySet()) {
      if (e.getKey().equalsIgnoreCase(moduleId)) {
        node = e.getValue();
        break;
      }
    }

    if (node == null) {
      sendNotFound(exchange, "Module");
      return;
    }

    sendSuccess(exchange, toNodeDto(node));
  }

  private NodeDto toNodeDto(ModuleNode node) {
    List<String> provided = node.providedServices().stream().map(Class::getSimpleName).toList();
    // 排序便于比较；Set 已去重
    Set<String> owned = new TreeSet<>(node.ownedServiceNames());

    return new NodeDto(
        node.id(),
        node.displayName(),
        fromLayer(node.layer()),
        node.dependencies(),
        provided,
        owned,
        statusToString(node.status()),
        node.failureReason());
  }

  private CycleDto toCycleDto(CycleInfo cycle) {
    return new CycleDto(cycle.cycleModules(), cycle.description());
  }
}
