package dev.starcore.starcore.achievement.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

/** 成就GUI点击事件监听器 */
public class AchievementGuiListener implements Listener {

  private final AchievementGui gui;

  public AchievementGuiListener(AchievementGui gui) {
    this.gui = gui;
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    String title = PlainTextComponentSerializer.plainText().serialize(event.getView().title());
    if (title.contains("成就")) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    Component titleComponent = event.getView().title();
    if (titleComponent == null
        || !PlainTextComponentSerializer.plainText().serialize(titleComponent).contains("成就")) {
      return;
    }

    Inventory top = event.getView().getTopInventory();
    if (top == null) {
      return;
    }

    event.setCancelled(true);
    int slot = event.getRawSlot();
    if (event.getClickedInventory() != top
        || slot < 0
        || slot >= top.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)
        || event.getCurrentItem() == null) {
      return;
    }

    gui.handleClick(player, slot, event.getCurrentItem());
  }

  // audit H-001: 修复 PlayerQuitEvent 未清理 playerMenuState 导致的内存泄漏
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    gui.clearPlayerState(event.getPlayer());
  }
}
