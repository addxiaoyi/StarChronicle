package dev.starcore.starcore.balance;

public enum BalanceSeverity {
  INFO,
  WARNING,
  HIGH
}
