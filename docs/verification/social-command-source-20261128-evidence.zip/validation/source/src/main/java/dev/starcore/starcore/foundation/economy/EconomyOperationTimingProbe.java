package dev.starcore.starcore.foundation.economy;

/** Collects optional per-thread timing details for an economy operation. */
public final class EconomyOperationTimingProbe {
  private static final ThreadLocal<MutableTiming> CURRENT = new ThreadLocal<>();

  private EconomyOperationTimingProbe() {}

  public static Scope begin() {
    if (CURRENT.get() != null) {
      throw new IllegalStateException("An economy operation timing probe is already active");
    }
    MutableTiming timing = new MutableTiming();
    CURRENT.set(timing);
    return new Scope(timing);
  }

  static void record(Phase phase, long durationNanos) {
    MutableTiming timing = CURRENT.get();
    if (timing != null && durationNanos > 0L) {
      timing.add(phase, durationNanos);
    }
  }

  public enum Phase {
    ECONOMY_FLUSH_LOCK_WAIT,
    SQL_SAVE_COORDINATION_WAIT,
    SQL_PENDING_SAVE_WAIT,
    SQL_CONNECTION_ACQUIRE,
    SQL_SCHEMA,
    SQL_TRANSACTION_SETUP,
    SQL_BATCH,
    SQL_COMMIT
  }

  public record Snapshot(
      double economyFlushLockWaitMs,
      double sqlSaveCoordinationWaitMs,
      double sqlPendingSaveWaitMs,
      double sqlConnectionAcquireMs,
      double sqlSchemaMs,
      double sqlTransactionSetupMs,
      double sqlBatchMs,
      double sqlCommitMs) {
    private static final Snapshot EMPTY = new Snapshot(0, 0, 0, 0, 0, 0, 0, 0);

    public static Snapshot empty() {
      return EMPTY;
    }

    private static Snapshot from(MutableTiming timing) {
      return new Snapshot(
          timing.millis(Phase.ECONOMY_FLUSH_LOCK_WAIT),
          timing.millis(Phase.SQL_SAVE_COORDINATION_WAIT),
          timing.millis(Phase.SQL_PENDING_SAVE_WAIT),
          timing.millis(Phase.SQL_CONNECTION_ACQUIRE),
          timing.millis(Phase.SQL_SCHEMA),
          timing.millis(Phase.SQL_TRANSACTION_SETUP),
          timing.millis(Phase.SQL_BATCH),
          timing.millis(Phase.SQL_COMMIT));
    }
  }

  public static final class Scope implements AutoCloseable {
    private final MutableTiming timing;
    private boolean closed;

    private Scope(MutableTiming timing) {
      this.timing = timing;
    }

    public Snapshot snapshot() {
      return Snapshot.from(timing);
    }

    @Override
    public void close() {
      if (!closed) {
        CURRENT.remove();
        closed = true;
      }
    }
  }

  private static final class MutableTiming {
    private final long[] durations = new long[Phase.values().length];

    private synchronized void add(Phase phase, long durationNanos) {
      int index = phase.ordinal();
      durations[index] = Math.addExact(durations[index], durationNanos);
    }

    private synchronized double millis(Phase phase) {
      return durations[phase.ordinal()] / 1_000_000.0;
    }
  }
}
