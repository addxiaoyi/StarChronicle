package dev.starcore.starcore.event.random.effect;

import dev.starcore.starcore.event.random.EventEffect;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** 国家效果 对国家层面的属性和状态产生影响 */
public class NationEffect implements EventEffect {

  public enum EffectType {
    MORALE_CHANGE, // 士气变化
    DEFENSE_BONUS, // 防御加成
    COMBAT_BONUS, // 战斗加成
    ECONOMY_BONUS, // 经济加成
    DAMAGE_OVER_TIME, // 持续损失
    BUILDING_DAMAGE, // 建筑损坏
    RESOURCE_DRAIN, // 资源消耗
    REPUTATION_CHANGE // 声望变化
  }

  private final JavaPlugin plugin;
  private final EffectTaskScope scope;
  private volatile NationService nationService;
  private volatile TreasuryService treasuryService;

  private final EffectType effectType;
  private final double value;
  private final int duration;

  // 使用实例变量存储临时状态（替代 nation.data()）
  private static final Map<UUID, NationTempState> nationStates = new ConcurrentHashMap<>();

  public NationEffect(
      JavaPlugin plugin,
      NationService nationService,
      EffectType effectType,
      double value,
      int duration) {
    this(plugin, nationService, effectType, value, duration, null);
  }

  public NationEffect(
      JavaPlugin plugin,
      NationService nationService,
      EffectType effectType,
      double value,
      int duration,
      String message) {
    this.plugin = plugin;
    this.scope = EffectTaskScope.of(plugin);
    this.nationService = nationService;
    this.effectType = effectType;
    this.value = value;
    this.duration = duration;
  }

  public void setNationService(NationService nationService) {
    this.nationService = nationService;
  }

  public void setTreasuryService(TreasuryService treasuryService) {
    this.treasuryService = treasuryService;
  }

  @Override
  public boolean apply(Player player, Location location) {
    if (nationService == null
        || player == null
        || !Bukkit.isOwnedByCurrentRegion(player)
        || !Bukkit.isGlobalTickThread()
        || !scope.active()) {
      return false;
    }

    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      return false;
    }

    return applyNationEffect(nationOpt.get(), player);
  }

  @Override
  public java.util.concurrent.CompletableFuture<Boolean> applyAsync(
      Player player,
      Location location,
      dev.starcore.starcore.event.random.RandomEventRuntime runtime) {
    if (player == null || nationService == null)
      return java.util.concurrent.CompletableFuture.completedFuture(false);
    return runtime
        .player(player, player::getUniqueId)
        .thenCompose(
            playerId ->
                runtime.global(
                    () -> {
                      if (!scope.active()) return false;
                      return nationService
                          .nationOf(playerId)
                          .map(nation -> applyNationEffect(nation, null))
                          .orElse(false);
                    }));
  }

  /** 对指定国家应用效果 */
  public boolean applyToNation(UUID nationId) {
    if (nationService == null || !scope.active() || !Bukkit.isGlobalTickThread()) {
      return false;
    }

    Optional<Nation> nationOpt = nationService.nationById(NationId.of(nationId));
    if (nationOpt.isEmpty()) {
      return false;
    }

    return applyNationEffect(nationOpt.get(), null);
  }

  private boolean applyNationEffect(Nation nation, Player triggerPlayer) {
    if (!scope.active() || !Double.isFinite(value) || effectType == null || duration < 0)
      return false;
    if (effectType == EffectType.DAMAGE_OVER_TIME
        && (value < 0 || value > 100 || duration <= 0 || (value > 0 && treasuryService == null)))
      return false;
    switch (effectType) {
      case MORALE_CHANGE:
        applyMoraleChange(nation);
        return true;

      case DEFENSE_BONUS:
        applyDefenseBonus(nation);
        return true;

      case COMBAT_BONUS:
        applyCombatBonus(nation);
        return true;

      case DAMAGE_OVER_TIME:
        return applyDamageOverTime(nation);

      case BUILDING_DAMAGE:
        applyBuildingDamage(nation);
        return true;

      case RESOURCE_DRAIN:
        applyResourceDrain(nation);
        return true;

      case REPUTATION_CHANGE:
        applyReputationChange(nation);
        return true;

      default:
        return false;
    }
  }

  /** 士气变化 */
  private void applyMoraleChange(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    double currentMorale = state.morale;
    double newMorale = Math.max(0, Math.min(100, currentMorale + value));
    state.morale = newMorale;

    String status = value >= 0 ? "提升" : "下降";
    plugin
        .getLogger()
        .info(
            String.format(
                "国家 %s 士气 %s: %.1f%% -> %.1f%%", nation.name(), status, currentMorale, newMorale));
  }

  /** 防御加成 */
  private void applyDefenseBonus(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    state.defenseBonus += value;

    if (duration > 0) {
      state.defenseBonusExpire = System.currentTimeMillis() + (duration * 1000L);
    }

    plugin
        .getLogger()
        .info(
            String.format("国家 %s 获得 %.0f%% 防御加成 (持续 %d 秒)", nation.name(), value * 100, duration));
  }

  /** 战斗加成 */
  private void applyCombatBonus(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    state.combatBonus += value;

    if (duration > 0) {
      state.combatBonusExpire = System.currentTimeMillis() + (duration * 1000L);
    }

    plugin
        .getLogger()
        .info(
            String.format("国家 %s 获得 %.0f%% 战斗加成 (持续 %d 秒)", nation.name(), value * 100, duration));
  }

  /** 持续损失（用于围城效果） */
  private boolean applyDamageOverTime(Nation nation) {
    if (duration > 0) {
      NationTempState state = getOrCreateState(nation.id());
      state.underSiege = true;
      state.siegeDamageRate = value;
      state.siegeExpire = System.currentTimeMillis() + (duration * 1000L);

      if (!scheduleSiegeDamage(nation.id().value(), duration)) return false;

      // 广播围城开始
      String msg = String.format("§c⚔ 【围城警报】%s 正在遭受围攻！每分钟损失 %.1f%% 资源！", nation.name(), value);
      broadcastToNation(nation, msg);

      return true;
    }
    return false;
  }

  /** 调度围城伤害 */
  private boolean scheduleSiegeDamage(UUID nationId, int durationInSeconds) {
    NationTempState expected = nationStates.get(nationId);
    if (expected == null || expected.owner != scope) return false;
    if (expected.timer != null) expected.timer.cancel();
    Object attempt = new Object();
    expected.siegeAttempt = attempt;
    long[] elapsed = {0};
    try {
      expected.timer =
          scope.repeat(
              timer -> {
                if (nationStates.get(nationId) != expected
                    || !expected.underSiege
                    || expected.siegeAttempt != attempt) {
                  timer.cancel();
                  return;
                }
                elapsed[0] += 20L;
                if (elapsed[0] >= durationInSeconds * 20L
                    || System.currentTimeMillis() >= expected.siegeExpire) {
                  timer.cancel();
                  endSiege(nationId);
                  return;
                }
                if (elapsed[0] % 1200L != 0) return;
                try {
                  Optional<Nation> nation = nationService.nationById(NationId.of(nationId));
                  if (nation.isEmpty()) {
                    timer.cancel();
                    expected.underSiege = false;
                    return;
                  }
                  if (!applySiegeTick(nation.get(), expected.siegeDamageRate)) {
                    timer.cancel();
                    expected.underSiege = false;
                  }
                } catch (RuntimeException failure) {
                  timer.cancel();
                  expected.underSiege = false;
                  plugin
                      .getLogger()
                      .log(java.util.logging.Level.WARNING, "国家围城扣款结果不明，已停止该轮；请核对国库记录", failure);
                }
              },
              20L,
              20L);
      if (!scope.active() || expected.timer.isCancelled()) {
        expected.underSiege = false;
        nationStates.remove(nationId, expected);
        return false;
      }
      return true;
    } catch (RuntimeException failure) {
      expected.underSiege = false;
      throw failure;
    }
  }

  private boolean applySiegeTick(Nation nation, double damageRate) {
    // 简化的围城伤害逻辑：扣除经济
    if (damageRate > 0) {
      if (treasuryService == null) return false;
      BigDecimal balance = treasuryService.balance(nation.id());
      if (balance == null || balance.signum() < 0) return false;
      BigDecimal loss = balance.multiply(BigDecimal.valueOf(damageRate)).movePointLeft(2);
      if (loss.signum() > 0 && !treasuryService.withdraw(nation.id(), loss)) {
        plugin.getLogger().warning("围城扣款未完成，不重复提交本次周期");
        return false;
      }
    }

    // 士气下降
    NationTempState state = getOrCreateState(nation.id());
    state.morale = Math.max(0, state.morale - 1.0);

    // 广播状态
    String msg = String.format("§c⚔ 【围城】%s 正在遭受攻击！资源 -%.1f%%, 士气 -1", nation.name(), damageRate);
    broadcastToNation(nation, msg);
    return true;
  }

  private void endSiege(UUID nationId) {
    NationTempState ending = nationStates.get(nationId);
    if (ending == null || ending.owner != scope) return;
    if (ending.timer != null) ending.timer.cancel();
    ending.underSiege = false;
    Optional<Nation> nationOpt = nationService.nationById(NationId.of(nationId));
    if (nationOpt.isPresent()) {
      Nation nation = nationOpt.get();
      NationTempState state = nationStates.get(nationId);
      if (state != null) {
        state.underSiege = false;
        state.siegeDamageRate = 0;
        state.siegeExpire = 0;
      }

      broadcastToNation(nation, "§a⚔ 【围城结束】蛮族撤退了！");
    }
  }

  /** 建筑损坏 */
  private void applyBuildingDamage(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    state.buildingsDamaged = true;
    state.buildingDamageLevel = (int) value;

    plugin.getLogger().info(String.format("国家 %s 建筑受损，等级: %d", nation.name(), (int) value));
  }

  /** 资源消耗 */
  private void applyResourceDrain(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    state.resourceDrainActive = true;
    state.resourceDrainRate = value;

    plugin.getLogger().info(String.format("国家 %s 资源消耗增加 %.0f%%", nation.name(), value * 100));
  }

  /** 声望变化 */
  private void applyReputationChange(Nation nation) {
    NationTempState state = getOrCreateState(nation.id());
    double currentRep = state.reputation;
    double newRep = Math.max(0, Math.min(100, currentRep + value));
    state.reputation = newRep;

    plugin
        .getLogger()
        .info(String.format("国家 %s 声望变化: %.1f -> %.1f", nation.name(), currentRep, newRep));
  }

  /** 向国家成员广播消息 */
  private void broadcastToNation(Nation nation, String message) {
    if (message == null) return;
    scope.broadcast(nation, message);
  }

  /** 获取或创建国家的临时状态 */
  private NationTempState getOrCreateState(NationId nationId) {
    return nationStates.compute(
        nationId.value(),
        (k, previous) -> {
          if (previous != null && previous.owner == scope) return previous;
          if (previous != null && previous.timer != null) previous.timer.cancel();
          return new NationTempState(scope);
        });
  }

  /** 国家临时状态（存储在内存中） */
  private static class NationTempState {
    final EffectTaskScope owner;
    EffectTaskScope.Timer timer;
    Object siegeAttempt;

    NationTempState(EffectTaskScope owner) {
      this.owner = owner;
    }

    double morale = 100.0;
    double defenseBonus = 0.0;
    long defenseBonusExpire = 0;
    double combatBonus = 0.0;
    long combatBonusExpire = 0;
    boolean underSiege = false;
    double siegeDamageRate = 0;
    long siegeExpire = 0;
    boolean buildingsDamaged = false;
    int buildingDamageLevel = 0;
    boolean resourceDrainActive = false;
    double resourceDrainRate = 0;
    double reputation = 50.0;
  }

  public static void shutdown(org.bukkit.plugin.Plugin plugin) {
    EffectTaskScope.shutdown(plugin);
    nationStates
        .entrySet()
        .removeIf(
            entry -> {
              NationTempState state = entry.getValue();
              if (state.owner.plugin != plugin) return false;
              if (state.timer != null) state.timer.cancel();
              return true;
            });
  }

  public static void shutdownAll() {
    EffectTaskScope.shutdownAll();
    nationStates
        .values()
        .forEach(
            state -> {
              if (state.timer != null) state.timer.cancel();
            });
    nationStates.clear();
  }

  @Override
  public String toString() {
    return String.format(
        "NationEffect{type=%s, value=%.2f, duration=%d}", effectType, value, duration);
  }

  @Override
  public String getType() {
    return "nation";
  }

  @Override
  public String getDescription() {
    return String.format("国家效果 [类型=%s, 数值=%.2f, 持续=%ds]", effectType, value, duration);
  }
}
