package dev.starcore.starcore.core.module.extension;

import java.util.List;
import java.util.Set;

/** 模块扩展接口 供模块 implement 交互的接口 */
public interface ModuleExtension {

  /** 获取扩展 ID */
  String getExtensionId();

  /** 获取扩展的描述 */
  String getExtensionDescription();

  /** 获取所需的扩展点 */
  Set<String> getRequiredExtensionPoints();

  /** 获取扩展点的控制器 */
  ExtensionPointController getExtensionPointController();

  /** 注册此扩展到所需的扩展点 */
  void registerToExtensionPoints();

  /** 卸载此扩展 */
  void unregisterFromExtensionPoints();

  /** 获取扩展的优先级 */
  default int getPriority() {
    return 100;
  }

  /** 获取扩展的版本 */
  default String getVersion() {
    return "1.0.0";
  }

  /** 获取扩展的作者 */
  default String getAuthor() {
    return "Unknown";
  }

  /** 获取扩展的依赖 */
  default List<String> getDependencies() {
    return List.of();
  }

  /** 检查扩展是否启用 */
  default boolean isEnabled() {
    return true;
  }

  /** 设置启用状态 */
  default void setEnabled(boolean enabled) {
    // 默认实现
  }
}
