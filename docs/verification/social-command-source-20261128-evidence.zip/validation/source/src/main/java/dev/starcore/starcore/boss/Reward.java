package dev.starcore.starcore.boss;

import java.util.*;

/** Boss战奖励定义 定义击败Boss或完成遭遇时的奖励内容 */
public record Reward(
    String rewardId, String name, List<RewardItem> items, Map<String, Object> metadata) {

  public static Builder builder(String rewardId, String name) {
    return new Builder(rewardId, name);
  }

  public static class Builder {
    private final String rewardId;
    private final String name;
    private List<RewardItem> items = new ArrayList<>();
    private Map<String, Object> metadata = new HashMap<>();

    public Builder(String rewardId, String name) {
      this.rewardId = Objects.requireNonNull(rewardId);
      this.name = Objects.requireNonNull(name);
    }

    public Builder addItem(RewardItem item) {
      this.items.add(item);
      return this;
    }

    public Builder addItem(String itemId, int amount, double chance) {
      this.items.add(new RewardItem(itemId, amount, chance));
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Reward build() {
      return new Reward(rewardId, name, List.copyOf(items), Map.copyOf(metadata));
    }
  }
}
