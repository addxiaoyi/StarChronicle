package dev.starcore.starcore.api.v1.handler;

import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class RestApiCors {
    private RestApiCors() {}

    public static boolean handlePreflight(
        HttpExchange exchange,
        RestApiConfig.CorsConfig config
    ) throws IOException {
        if (!"OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            return false;
        }

        String origin = exchange.getRequestHeaders().getFirst("Origin");
        if (origin != null && !allowsOrigin(config, origin)) {
            sendPolicyError(exchange, 403, "CORS_ORIGIN_DENIED", "Origin is not allowed");
            return true;
        }

        String requestedMethod = exchange.getRequestHeaders()
            .getFirst("Access-Control-Request-Method");
        if (requestedMethod != null && !allows(config.allowedMethods(), requestedMethod)) {
            sendPolicyError(exchange, 403, "CORS_METHOD_DENIED", "HTTP method is not allowed");
            return true;
        }

        String requestedHeaders = exchange.getRequestHeaders()
            .getFirst("Access-Control-Request-Headers");
        if (requestedHeaders != null) {
            for (String header : requestedHeaders.split(",")) {
                if (!allows(config.allowedHeaders(), header.trim())) {
                    sendPolicyError(exchange, 403, "CORS_HEADER_DENIED", "Request header is not allowed");
                    return true;
                }
            }
        }

        applyHeaders(exchange, config);
        exchange.sendResponseHeaders(204, -1);
        exchange.close();
        return true;
    }

    public static void applyHeaders(
        HttpExchange exchange,
        RestApiConfig.CorsConfig config
    ) {
        String origin = exchange.getRequestHeaders().getFirst("Origin");
        if (!config.enabled() || origin == null || !allowsOrigin(config, origin)) {
            return;
        }
        var headers = exchange.getResponseHeaders();
        headers.set("Access-Control-Allow-Origin", allowsWildcard(config) ? "*" : origin);
        headers.set("Access-Control-Allow-Methods", String.join(", ", config.allowedMethods()));
        headers.set("Access-Control-Allow-Headers", String.join(", ", config.allowedHeaders()));
        headers.set("Access-Control-Max-Age", Integer.toString(config.maxAge()));
        if (!allowsWildcard(config)) {
            headers.set("Vary", "Origin");
        }
    }

    private static boolean allowsOrigin(RestApiConfig.CorsConfig config, String origin) {
        if (!config.enabled()) {
            return false;
        }
        return config.allowedOrigins().stream()
            .map(String::trim)
            .anyMatch(value -> value.equals("*") || value.equalsIgnoreCase(origin));
    }

    private static boolean allowsWildcard(RestApiConfig.CorsConfig config) {
        return config.allowedOrigins().stream().anyMatch(value -> value.trim().equals("*"));
    }

    private static boolean allows(java.util.List<String> allowed, String value) {
        String candidate = value.toLowerCase(Locale.ROOT);
        return allowed.stream().anyMatch(item -> {
            String normalized = item.toLowerCase(Locale.ROOT).trim();
            return normalized.equals("*") || normalized.equals(candidate);
        });
    }

    private static void sendPolicyError(HttpExchange exchange, int status, String code, String message)
        throws IOException {
        byte[] body = ("{\"ok\":false,\"error\":{\"code\":\"" + code
            + "\",\"message\":\"" + message + "\"}}")
            .getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, body.length);
        try (var output = exchange.getResponseBody()) {
            output.write(body);
        }
    }
}
