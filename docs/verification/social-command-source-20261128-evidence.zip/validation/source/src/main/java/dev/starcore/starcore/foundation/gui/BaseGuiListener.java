package dev.starcore.starcore.foundation.gui;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

/** BaseGui 事件监听器 统一处理所有基于 BaseGui 的菜单交互 */
public class BaseGuiListener implements Listener {

  private static final Map<UUID, BaseGui> OPEN_GUIS = new ConcurrentHashMap<>();
  // E-050: 点击冷却防止快速重复点击
  private static final Map<UUID, Long> CLICK_COOLDOWNS = new ConcurrentHashMap<>();
  private static final long CLICK_COOLDOWN_MS = 200;

  private final Plugin plugin;

  public BaseGuiListener(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 注册打开的 GUI */
  public static void registerGui(Player player, BaseGui gui) {
    if (player == null || gui == null) return;
    UUID playerId = player.getUniqueId();
    OPEN_GUIS.put(playerId, gui);
    CLICK_COOLDOWNS.remove(playerId);
  }

  /** 获取玩家当前打开的 GUI */
  public static BaseGui getGui(Player player) {
    return OPEN_GUIS.get(player.getUniqueId());
  }

  /** 注销玩家的 GUI */
  public static void unregisterGui(Player player) {
    if (player == null) return;
    UUID playerId = player.getUniqueId();
    OPEN_GUIS.remove(playerId);
    CLICK_COOLDOWNS.remove(playerId);
  }

  /** Removes only the expected GUI, preserving a replacement opened in the same tick. */
  public static boolean unregisterGui(Player player, BaseGui expected) {
    if (player == null || expected == null) return false;
    UUID playerId = player.getUniqueId();
    boolean removed = OPEN_GUIS.remove(playerId, expected);
    if (removed) CLICK_COOLDOWNS.remove(playerId);
    return removed;
  }

  /** 检查玩家是否有打开的 GUI */
  public static boolean hasGui(Player player) {
    return OPEN_GUIS.containsKey(player.getUniqueId());
  }

  // ==================== 事件处理 ====================

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    UUID playerId = player.getUniqueId();
    BaseGui gui = OPEN_GUIS.get(playerId);
    if (gui == null) {
      return;
    }

    // 取消点击，防止物品移动
    event.setCancelled(true);
    // Dispatch only top-inventory clicks; player inventory clicks stay cancelled but inert.
    org.bukkit.inventory.Inventory topInventory = event.getInventory();
    if (event.getView() != null && event.getView().getTopInventory() != null) {
      topInventory = event.getView().getTopInventory();
    }
    int slot = event.getRawSlot();
    if (topInventory == null
        || slot < 0
        || (topInventory.getSize() > 0 && slot >= topInventory.getSize())) {
      return;
    }
    if (!gui.isOwnInventory(topInventory)
        || (event.getClickedInventory() != null && event.getClickedInventory() != topInventory)) {
      return;
    }

    // Shift-click, number-key, double-click and hotbar swaps must never invoke a GUI action.
    ClickType clickType = event.getClick();
    if (clickType != ClickType.LEFT && clickType != ClickType.RIGHT) {
      return;
    }

    // E-050: 点击冷却防止快速重复点击导致卡顿或重复操作
    long now = System.currentTimeMillis();
    Long lastClick = CLICK_COOLDOWNS.get(playerId);
    if (lastClick != null && now - lastClick < CLICK_COOLDOWN_MS) {
      return;
    }
    CLICK_COOLDOWNS.put(playerId, now);

    gui.handleClick(player, slot);
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    if (!OPEN_GUIS.containsKey(player.getUniqueId())) {
      return;
    }

    // A GUI must own the whole interaction while it is open; otherwise drag actions can bypass
    // click guards.
    event.setCancelled(true);
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onInventoryClose(InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }

    UUID playerId = player.getUniqueId();
    BaseGui gui = OPEN_GUIS.get(playerId);
    if (gui != null
        && gui.isOwnInventory(event.getInventory())
        && OPEN_GUIS.remove(playerId, gui)) {
      CLICK_COOLDOWNS.remove(playerId);
      gui.handleClose();
      gui.clearInteractionState();
    }
  }

  /** 强制关闭所有 GUI */
  public void closeAll() {
    for (UUID uuid : OPEN_GUIS.keySet()) {
      Player player = Bukkit.getPlayer(uuid);
      if (player != null) {
        player.closeInventory();
      }
    }
    OPEN_GUIS.clear();
    CLICK_COOLDOWNS.clear();
  }

  // E-038 修复: 玩家退出时清理 OPEN_GUIS Map 状态
  // E-050 修复: 同时清理点击冷却 Map
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    BaseGui gui = OPEN_GUIS.remove(playerId);
    CLICK_COOLDOWNS.remove(playerId);
    if (gui != null) gui.clearInteractionState();
  }
}
