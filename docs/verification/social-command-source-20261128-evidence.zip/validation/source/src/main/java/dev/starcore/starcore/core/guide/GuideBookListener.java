package dev.starcore.starcore.core.guide;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import java.util.Map;

/** 指南书物品交互监听器 */
public final class GuideBookListener implements Listener {

  @EventHandler(priority = EventPriority.MONITOR)
  public void onPlayerJoin(PlayerJoinEvent event) {
    Player player = event.getPlayer();
    PlayerInventory inventory = player.getInventory();
    for (ItemStack item : inventory.getContents()) {
      if (GuideBook.isGuideBook(item)) return;
    }
    if (GuideBook.isGuideBook(inventory.getItemInOffHand())) return;

    Map<Integer, ItemStack> leftovers = inventory.addItem(GuideBook.createGuideBook());
    if (leftovers.isEmpty()) {
      player.sendMessage("§a已收到 STARCORE 玩法指南，右键打开。");
      return;
    }

    leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
    player.sendMessage("§e背包已满，STARCORE 玩法指南已放在脚边。");
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onPlayerInteract(PlayerInteractEvent event) {
    Player player = event.getPlayer();
    ItemStack item = event.getItem();

    if (!GuideBook.isGuideBook(item)) {
      return;
    }

    event.setCancelled(true);

    if (!event.getAction().isRightClick()) {
      return;
    }

    player.sendMessage("§a正在打开 STARCORE 玩法指南...");
    GameplayGuideGui.openMainMenu(player);
  }
}
