package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService;
import dev.starcore.starcore.module.treasury.LoanService;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.module.treasury.TaxationService.TaxConfig;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import dev.starcore.starcore.module.treasury.TreasuryService;
import dev.starcore.starcore.war.WarBond;
import dev.starcore.starcore.war.WarEconomyService;
import dev.starcore.starcore.war.WarFund;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * 经济模块统一门面。
 *
 * <p>把散落在三处的经济能力收敛到单一入口：个人余额在 foundation，国库/税收/债务/预算在 module.treasury，战争资金/债券/军工在
 * war。跨模块调用方不再需要分别持有三个服务引用， 也不再需要自己判断某个子系统是否已启用。
 *
 * <p>所有依赖都可为空（延迟装配 + 可选模块），查询路径统一用 {@link Optional} 表达 "模块未接入"，避免上层把缺失误判为 0。写操作则让底层异常向上传播——静默失败在金钱
 * 场景下比崩溃危险得多。
 */
public final class EconomyFacade {
  private static final int SCALE = 2;

  private final EconomyService balances;
  private final EconomySettings settings;
  private final Logger logger;

  private volatile TreasuryService treasury;
  private volatile NationService nations;
  private volatile WarEconomyService warEconomy;

  public EconomyFacade(EconomyService balances, EconomySettings settings, Logger logger) {
    this.balances = Objects.requireNonNull(balances, "balances");
    this.settings = settings == null ? EconomySettings.defaults() : settings;
    this.logger = logger;
  }

  /** 延迟装配：treasury/nation/war 模块在 foundation 之后才 enable，必须后绑定。 */
  public EconomyFacade bind(
      TreasuryService treasuryService,
      NationService nationService,
      WarEconomyService warEconomyService) {
    this.treasury = treasuryService;
    this.nations = nationService;
    this.warEconomy = warEconomyService;
    return this;
  }

  public EconomySettings settings() {
    return settings;
  }

  public Optional<TreasuryService> treasury() {
    return Optional.ofNullable(treasury);
  }

  public Optional<WarEconomyService> warEconomy() {
    return Optional.ofNullable(warEconomy);
  }

  public Optional<NationService> nationService() {
    return Optional.ofNullable(nations);
  }

  // ==================== 余额 ====================

  public BigDecimal balanceOf(UUID playerId) {
    return balances.getBalance(playerId);
  }

  public boolean hasBalance(UUID playerId, BigDecimal amount) {
    return balances.has(playerId, amount);
  }

  public boolean deposit(UUID playerId, BigDecimal amount) {
    return balances.deposit(playerId, amount);
  }

  public boolean withdraw(UUID playerId, BigDecimal amount) {
    return balances.withdraw(playerId, amount);
  }

  public boolean transferBetween(UUID from, UUID to, BigDecimal amount) {
    return balances.transfer(from, to, amount);
  }

  public String format(BigDecimal amount) {
    return settings.currencySymbol() + " " + scale(amount).toPlainString();
  }

  // ==================== 国库 ====================

  public BigDecimal treasuryBalance(NationId nationId) {
    return treasury().map(service -> service.balance(nationId)).orElseGet(this::zero);
  }

  public boolean depositToTreasury(NationId nationId, BigDecimal amount, String description) {
    TreasuryService service = requireTreasury("depositToTreasury");
    service.deposit(nationId, amount, description);
    return true;
  }

  public boolean withdrawFromTreasury(NationId nationId, BigDecimal amount) {
    TreasuryService service = requireTreasury("withdrawFromTreasury");
    return service.withdraw(nationId, amount);
  }

  public boolean transferTreasury(NationId from, NationId to, BigDecimal amount) {
    TreasuryService service = requireTreasury("transferTreasury");
    return service.transfer(from, to, amount);
  }

  // ==================== 税收 ====================

  public Map<TaxType, TaxConfig> taxConfigs(NationId nationId) {
    return treasury()
        .map(service -> service.getTaxConfigs(nationId))
        .orElseGet(() -> new EnumMap<>(TaxType.class));
  }

  public Optional<TaxConfig> taxConfig(NationId nationId, TaxType type) {
    return treasury().flatMap(service -> Optional.ofNullable(service.getTaxConfig(nationId, type)));
  }

  /** 写入税种配置前按 economy.yml 的税率上限收敛，越限值被夹到上限而不是抛异常—— 管理命令误输入不应让整个税收子系统不可用。 */
  public void applyTaxConfig(NationId nationId, TaxType type, TaxConfig config) {
    TreasuryService service = requireTreasury("applyTaxConfig");
    service.setTaxConfig(nationId, type, clampTaxRate(config));
  }

  public BigDecimal collectTax(NationId nationId, TaxType type, TaxContext context) {
    return treasury()
        .map(service -> service.collectTax(nationId, type, context))
        .orElseGet(this::zero);
  }

  public Map<TaxType, BigDecimal> collectAllTaxes(NationId nationId, TaxContext context) {
    return treasury()
        .map(service -> service.collectAllTaxes(nationId, context))
        .orElseGet(() -> new EnumMap<>(TaxType.class));
  }

  public List<TaxationService.TaxRevenue> taxHistory(NationId nationId, TaxType type, int limit) {
    return treasury()
        .map(service -> service.getTaxHistory(nationId, type, limit))
        .orElseGet(List::of);
  }

  private TaxConfig clampTaxRate(TaxConfig config) {
    Objects.requireNonNull(config, "config");
    BigDecimal clamped = settings.taxPercentRate(config.percentRate());
    if (clamped.compareTo(config.percentRate()) == 0) {
      return config;
    }
    logInfo("tax rate clamped to cap " + clamped.toPlainString() + " for " + config.type());
    return new TaxConfig(
        config.type(),
        config.enabled(),
        config.fixedAmount(),
        clamped,
        config.minimumBalance(),
        config.collectionIntervalMinutes(),
        config.autoCollect());
  }

  // ==================== 债务 ====================

  public BigDecimal totalDebtOf(NationId nationId) {
    return treasury().map(service -> service.getTotalDebt(nationId)).orElseGet(this::zero);
  }

  public BigDecimal maxBorrowableOf(NationId nationId) {
    return treasury()
        .map(service -> service.getMaxBorrowableAmount(nationId))
        .orElseGet(this::zero);
  }

  public int debtHealthOf(NationId nationId) {
    return treasury().map(service -> service.getDebtHealthScore(nationId)).orElse(100);
  }

  public boolean canBorrow(NationId nationId, BigDecimal amount) {
    return treasury().map(service -> service.canBorrow(nationId, amount)).orElse(false);
  }

  public List<LoanService.NationDebt> activeDebtsOf(NationId nationId) {
    return treasury().map(service -> service.getActiveDebts(nationId)).orElseGet(List::of);
  }

  // ==================== 战争资金 ====================

  /** 战争基金是纯数据对象，调用方自行持有实例；门面只提供参数校验，避免绕过最低捐献额。 */
  public void contributeToWarFund(
      WarFund fund, UUID contributorId, String contributorName, BigDecimal amount) {
    Objects.requireNonNull(fund, "fund");
    BigDecimal normalized = scale(amount);
    BigDecimal minimum = settings.minWarFundContribution();
    if (normalized.compareTo(minimum) < 0) {
      throw new IllegalArgumentException(
          "war fund contribution must be at least " + minimum.toPlainString());
    }
    fund.addContribution(contributorId, contributorName, normalized);
  }

  /** 发行战争债券，利率/期限先按 economy.yml 收敛再交给 WarEconomyService。 */
  public WarBond issueWarBond(
      UUID warId,
      NationId nationId,
      BigDecimal faceValue,
      BigDecimal annualInterestRate,
      int termMonths) {
    WarEconomyService service = requireWarEconomy("issueWarBond");
    BigDecimal face = scale(faceValue);
    if (face.compareTo(settings.minBondFaceValue()) < 0) {
      throw new IllegalArgumentException(
          "bond face value must be at least " + settings.minBondFaceValue().toPlainString());
    }
    if (termMonths > settings.maxBondTermMonths()) {
      throw new IllegalArgumentException(
          "bond term must not exceed " + settings.maxBondTermMonths() + " months");
    }
    BigDecimal rate = settings.decayedInterestRate(termMonths, annualInterestRate);
    if (rate.signum() <= 0) {
      throw new IllegalArgumentException(
          "bond interest rate decayed to zero; choose a shorter term");
    }
    return service.issueWarBond(warId, nationId, face, rate.doubleValue(), termMonths);
  }

  public void purchaseWarBond(UUID bondId, UUID buyerId, String buyerName, BigDecimal amount) {
    requireWarEconomy("purchaseWarBond").purchaseWarBond(bondId, buyerId, buyerName, scale(amount));
  }

  public BigDecimal redeemWarBond(UUID bondId, UUID holderId) {
    return requireWarEconomy("redeemWarBond").redeemWarBond(bondId, holderId);
  }

  public Optional<EconomySnapshot.BondView> warBond(UUID bondId) {
    return warEconomy()
        .flatMap(service -> service.getWarBond(bondId))
        .map(EconomySnapshot.BondView::from);
  }

  public List<EconomySnapshot.BondView> warBondsOf(NationId nationId) {
    return warEconomy()
        .map(
            service ->
                service.getWarBondsOfNation(nationId).stream()
                    .map(EconomySnapshot.BondView::from)
                    .toList())
        .orElseGet(List::of);
  }

  // ==================== 统一查询 ====================

  /** 玩家综合视图：余额 + 所属国家财政。未建国时 nationId/name 为 null，国库字段为 0。 */
  public EconomySnapshot.PlayerFinance playerFinance(UUID playerId) {
    Objects.requireNonNull(playerId, "playerId");
    Optional<Nation> nation = nationOf(playerId);
    NationId nationId = nation.map(Nation::id).orElse(null);
    String nationName = nation.map(Nation::name).orElse(null);

    return new EconomySnapshot.PlayerFinance(
        playerId,
        balances.getBalance(playerId),
        balances.hasAccount(playerId),
        nationId,
        nationName,
        treasuryBalance(nationId),
        totalDebtOf(nationId),
        debtHealthOf(nationId),
        isBankrupt(nationId),
        todayIncomeOf(nationId),
        todayExpenseOf(nationId));
  }

  /** 国家财政视图。treasury 未接入时返回 empty，而不是伪造一份全零报告。 */
  public Optional<EconomySnapshot.NationFinance> nationFinance(NationId nationId) {
    if (nationId == null || treasury == null) {
      return Optional.empty();
    }
    return Optional.of(
        new EconomySnapshot.NationFinance(
            nationId,
            nationNameOf(nationId),
            treasury.balance(nationId),
            treasury.getTotalDebt(nationId),
            treasury.getMaxBorrowableAmount(nationId),
            treasury.getDebtHealthScore(nationId),
            treasury.isBankrupt(nationId),
            treasury.getActiveRestrictions(nationId).stream()
                .map(EconomySnapshot.BankruptcyServiceView::from)
                .toList(),
            treasury.getTaxConfigs(nationId),
            treasury.getTodayIncome(nationId),
            treasury.getTodayExpense(nationId),
            Instant.now()));
  }

  /** 战争财政视图：WarFund 进度 + 该国全部债券。 */
  public Optional<EconomySnapshot.WarFinance> warFinance(
      UUID warId, NationId nationId, WarFund fund) {
    if (warId == null) {
      return Optional.empty();
    }
    return Optional.of(
        new EconomySnapshot.WarFinance(
            warId,
            nationId,
            fund == null ? zero() : fund.targetAmount(),
            fund == null ? zero() : fund.currentAmount(),
            fund == null ? 0.0 : fund.progressPercentage(),
            fund == null ? 0 : fund.contributorCount(),
            fund != null && fund.isTargetReached(),
            nationId == null ? List.of() : warBondsOf(nationId),
            Instant.now()));
  }

  /** 全服财政摘要，逐国聚合；单个国家查询失败不影响其他国家的统计。 */
  public EconomySnapshot.NationFinanceSummary financeSummary() {
    if (treasury == null || nations == null) {
      return new EconomySnapshot.NationFinanceSummary(List.of(), zero(), zero(), 0, Instant.now());
    }
    List<EconomySnapshot.NationFinance> reports = new ArrayList<>();
    BigDecimal totalBalance = BigDecimal.ZERO;
    BigDecimal totalDebt = BigDecimal.ZERO;
    int bankruptCount = 0;

    Collection<Nation> allNations = nations.nations();
    for (Nation nation : allNations) {
      Optional<EconomySnapshot.NationFinance> report = nationFinance(nation.id());
      if (report.isEmpty()) {
        continue;
      }
      EconomySnapshot.NationFinance finance = report.get();
      reports.add(finance);
      totalBalance = totalBalance.add(finance.treasuryBalance());
      totalDebt = totalDebt.add(finance.totalDebt());
      if (finance.bankrupt()) {
        bankruptCount++;
      }
    }
    return new EconomySnapshot.NationFinanceSummary(
        reports, totalBalance, totalDebt, bankruptCount, Instant.now());
  }

  // ==================== 便捷委托 ====================

  public boolean isBankrupt(NationId nationId) {
    if (nationId == null || treasury == null) {
      return false;
    }
    return treasury.isBankrupt(nationId);
  }

  public BigDecimal todayIncomeOf(NationId nationId) {
    if (nationId == null || treasury == null) {
      return zero();
    }
    return treasury.getTodayIncome(nationId);
  }

  public BigDecimal todayExpenseOf(NationId nationId) {
    if (nationId == null || treasury == null) {
      return zero();
    }
    return treasury.getTodayExpense(nationId);
  }

  public Optional<BudgetService.BudgetBill> currentBudget(NationId nationId) {
    return treasury().map(service -> service.getCurrentBudget(nationId)).orElseGet(Optional::empty);
  }

  public Optional<Nation> nationOf(UUID playerId) {
    if (nations == null || playerId == null) {
      return Optional.empty();
    }
    return nations.nationOf(playerId);
  }

  public Optional<Nation> nationByName(String nationName) {
    if (nations == null || nationName == null) {
      return Optional.empty();
    }
    return nations.nationByName(nationName);
  }

  private String nationNameOf(NationId nationId) {
    if (nations == null || nationId == null) {
      return null;
    }
    return nations.nationById(nationId).map(Nation::name).orElse(null);
  }

  private TreasuryService requireTreasury(String operation) {
    TreasuryService service = treasury;
    if (service == null) {
      throw new IllegalStateException("treasury module is unavailable; cannot " + operation);
    }
    return service;
  }

  private WarEconomyService requireWarEconomy(String operation) {
    WarEconomyService service = warEconomy;
    if (service == null) {
      throw new IllegalStateException("war economy service is unavailable; cannot " + operation);
    }
    return service;
  }

  private BigDecimal zero() {
    return BigDecimal.ZERO.setScale(SCALE, java.math.RoundingMode.DOWN);
  }

  private static BigDecimal scale(BigDecimal amount) {
    if (amount == null) {
      throw new IllegalArgumentException("amount must not be null");
    }
    return amount.setScale(SCALE, java.math.RoundingMode.DOWN);
  }

  private void logInfo(String message) {
    if (logger != null) {
      logger.info("[EconomyFacade] " + message);
    }
  }
}
