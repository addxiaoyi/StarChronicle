package dev.starcore.starcore.event;

import java.util.*;

/** 事件定义模型 定义剧情事件的完整结构 */
public record EventDefinition(
    String eventId, // 事件ID
    EventType type, // 事件类型
    String name, // 事件名称
    String description, // 事件描述
    String epochId, // 所属纪元ID
    int order, // 事件顺序
    Set<String> prerequisites, // 前置条件集合
    Set<String> targetNodes, // 目标节点集合
    Map<String, BranchLogic> branchLogics, // 分支逻辑
    Map<String, Object> metadata, // 元数据
    Long createdAt, // 创建时间
    Long updatedAt // 更新时间
    ) {

  /** 分支逻辑定义 */
  public static class BranchLogic {
    private final String branchId;
    private final String condition;
    private final String nextEventId;
    private final Map<String, Object> outcomes;

    public BranchLogic(
        String branchId, String condition, String nextEventId, Map<String, Object> outcomes) {
      this.branchId = branchId;
      this.condition = condition;
      this.nextEventId = nextEventId;
      this.outcomes = outcomes;
    }

    public String getBranchId() {
      return branchId;
    }

    public String getCondition() {
      return condition;
    }

    public String getNextEventId() {
      return nextEventId;
    }

    public Map<String, Object> getOutcomes() {
      return outcomes;
    }
  }

  /** 创建事件定义构建器 */
  public static Builder builder(String eventId, EventType type) {
    return new Builder(eventId, type);
  }

  /** 检查是否满足前置条件 */
  public boolean hasPrerequisites() {
    return prerequisites != null && !prerequisites.isEmpty();
  }

  /** 检查是否有分支逻辑 */
  public boolean hasBranches() {
    return branchLogics != null && !branchLogics.isEmpty();
  }

  /** 获取分支逻辑 */
  public Optional<BranchLogic> getBranch(String branchId) {
    if (branchLogics == null) return Optional.empty();
    return Optional.ofNullable(branchLogics.get(branchId));
  }

  /** 事件定义构建器 */
  public static class Builder {
    private final String eventId;
    private final EventType type;
    private String name;
    private String description;
    private String epochId;
    private int order;
    private Set<String> prerequisites = new HashSet<>();
    private Set<String> targetNodes = new HashSet<>();
    private Map<String, BranchLogic> branchLogics = new HashMap<>();
    private Map<String, Object> metadata = new HashMap<>();
    private Long createdAt = System.currentTimeMillis();
    private Long updatedAt = System.currentTimeMillis();

    private Builder(String eventId, EventType type) {
      this.eventId = Objects.requireNonNull(eventId);
      this.type = Objects.requireNonNull(type);
    }

    public Builder name(String name) {
      this.name = name;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder epochId(String epochId) {
      this.epochId = epochId;
      return this;
    }

    public Builder order(int order) {
      this.order = order;
      return this;
    }

    public Builder addPrerequisite(String prerequisite) {
      this.prerequisites.add(prerequisite);
      return this;
    }

    public Builder addPrerequisites(Collection<String> prerequisites) {
      this.prerequisites.addAll(prerequisites);
      return this;
    }

    public Builder addTargetNode(String targetNode) {
      this.targetNodes.add(targetNode);
      return this;
    }

    public Builder addTargetNodes(Collection<String> targetNodes) {
      this.targetNodes.addAll(targetNodes);
      return this;
    }

    public Builder addBranch(BranchLogic branchLogic) {
      this.branchLogics.put(branchLogic.getBranchId(), branchLogic);
      return this;
    }

    public Builder addBranch(
        String branchId, String condition, String nextEventId, Map<String, Object> outcomes) {
      this.branchLogics.put(branchId, new BranchLogic(branchId, condition, nextEventId, outcomes));
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public EventDefinition build() {
      return new EventDefinition(
          eventId,
          type,
          name,
          description,
          epochId,
          order,
          Set.copyOf(prerequisites),
          Set.copyOf(targetNodes),
          Map.copyOf(branchLogics),
          Map.copyOf(metadata),
          createdAt,
          updatedAt);
    }
  }
}
