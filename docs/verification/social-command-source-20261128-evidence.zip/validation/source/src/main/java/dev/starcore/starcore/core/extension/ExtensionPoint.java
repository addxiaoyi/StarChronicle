package dev.starcore.starcore.core.extension;

import java.util.List;

/**
 * 扩展点接口 定义一个可被其他模块/插件扩展的点
 *
 * @param <T> 扩展点的返回值类型
 * @param <R> 请求/输入参数类型
 */
public interface ExtensionPoint<T, R> {

  /** 获取扩展点的名称 */
  String getName();

  /** 获取扩展点的描述 */
  String getDescription();

  /** 执行扩展点 收集所有注册的贡献者的结果并返回 */
  T execute(R request);

  /** 执行扩展点 只返回第一个非空结果（短路求值） */
  default T executeFirst(R request) {
    return execute(request);
  }

  /** 检查是否有已注册的贡献者 */
  boolean hasContributions();

  /** 获取所有贡献者 */
  List<ExtensionContributor<T, R>> getContributors();
}
