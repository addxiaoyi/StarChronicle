package dev.starcore.starcore.economy.loop;

import dev.starcore.starcore.economy.EconomyManager;
import dev.starcore.starcore.economy.Resource;
import dev.starcore.starcore.economy.ResourceType;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/** 市场动态系统 管理资源价格的动态变化 */
public class MarketDynamics {

  private final EconomyManager economyManager;
  private final Map<ResourceType, MarketData> marketDataMap = new ConcurrentHashMap<>();
  private final Map<String, PlayerMarketData> playerMarketDataMap = new ConcurrentHashMap<>();
  private final Map<ResourceType, AtomicReference<Double>> priceMultipliers =
      new ConcurrentHashMap<>();

  private final List<Consumer<MarketUpdateEvent>> marketUpdateListeners = new ArrayList<>();

  // 市场参数
  private double basePriceVolatility = 0.1; // 基础价格波动性
  private double demandSensitivity = 0.5; // 需求敏感度
  private double supplySensitivity = 0.3; // 供给敏感度
  private double trendMomentum = 0.2; // 趋势动量

  public MarketDynamics(EconomyManager economyManager) {
    this.economyManager = Objects.requireNonNull(economyManager);
    initializeMarketData();
  }

  /** 初始化市场数据 */
  private void initializeMarketData() {
    for (ResourceType type : ResourceType.values()) {
      marketDataMap.put(type, new MarketData(type));
      priceMultipliers.put(type, new AtomicReference<>(1.0));
    }
  }

  /** 记录交易 */
  public void recordTransaction(String playerId, Resource resource, long amount, double price) {
    ResourceType type = resource.type();

    // 更新市场数据
    MarketData marketData = marketDataMap.get(type);
    if (marketData != null) {
      marketData.recordTransaction(amount, price);
    }

    // 更新玩家市场数据
    PlayerMarketData playerData =
        playerMarketDataMap.computeIfAbsent(playerId, id -> new PlayerMarketData(id));
    playerData.recordTransaction(type, amount, price);
  }

  /** 更新市场动态 */
  public void updateMarketDynamics(long currentTime) {
    for (ResourceType type : ResourceType.values()) {
      MarketData marketData = marketDataMap.get(type);
      if (marketData == null) continue;

      // 计算新的价格乘数
      double newMultiplier = calculatePriceMultiplier(type, marketData, currentTime);

      // 应用趋势动量
      AtomicReference<Double> currentRef = priceMultipliers.get(type);
      double currentMultiplier = currentRef.get();
      double momentumAdjusted =
          currentMultiplier * (1 - trendMomentum) + newMultiplier * trendMomentum;

      currentRef.set(momentumAdjusted);

      // 记录市场更新
      marketData.recordMarketUpdate(currentMultiplier, momentumAdjusted, currentTime);
    }

    // 触发市场更新事件
    MarketUpdateEvent event = new MarketUpdateEvent(currentTime, getAllMarketData());
    notifyMarketUpdateListeners(event);
  }

  /** 计算价格乘数 */
  private double calculatePriceMultiplier(
      ResourceType type, MarketData marketData, long currentTime) {
    // 基础波动
    double volatilityFactor =
        1.0
            + (dev.starcore.starcore.foundation.util.RandomProvider.nextDouble() * 2 - 1)
                * basePriceVolatility;

    // 需求影响
    double demandFactor = calculateDemandFactor(type, marketData);

    // 供给影响
    double supplyFactor = calculateSupplyFactor(type, marketData);

    // 综合计算
    double multiplier = volatilityFactor * demandFactor * supplyFactor;

    // 限制范围
    return Math.max(0.1, Math.min(10.0, multiplier));
  }

  /** 计算需求因子 */
  private double calculateDemandFactor(ResourceType type, MarketData marketData) {
    long totalDemand = marketData.getTotalDemand();
    long averageDemand = marketData.getAverageDemand();

    if (averageDemand == 0) return 1.0;

    double demandRatio = (double) totalDemand / averageDemand;
    return 1.0 + (demandRatio - 1.0) * demandSensitivity;
  }

  /** 计算供给因子 */
  private double calculateSupplyFactor(ResourceType type, MarketData marketData) {
    long totalSupply = marketData.getTotalSupply();
    long averageSupply = marketData.getAverageSupply();

    if (averageSupply == 0) return 1.0;

    double supplyRatio = (double) totalSupply / averageSupply;
    return 1.0 - (supplyRatio - 1.0) * supplySensitivity;
  }

  /** 获取资源类型的价格乘数 */
  public double getPriceMultiplier(ResourceType type) {
    return priceMultipliers.getOrDefault(type, new AtomicReference<>(1.0)).get();
  }

  /** 设置资源类型的价格乘数 */
  public void setPriceMultiplier(ResourceType type, double multiplier) {
    priceMultipliers
        .getOrDefault(type, new AtomicReference<>(1.0))
        .set(Math.max(0.1, Math.min(10.0, multiplier)));
  }

  /** 保存价格乘数到文件（与既有内容合并，保留其他前缀的键） */
  public void saveState(File file) {
    Objects.requireNonNull(file);
    Properties properties = new Properties();
    if (file.exists() && file.isFile()) {
      try (InputStream in = new FileInputStream(file)) {
        properties.load(in);
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
            .warning("Failed to read existing market state, overwriting: " + e.getMessage());
      }
    }
    for (Map.Entry<ResourceType, AtomicReference<Double>> entry : priceMultipliers.entrySet()) {
      properties.setProperty(entry.getKey().name(), String.valueOf(entry.getValue().get()));
    }
    File parent = file.getAbsoluteFile().getParentFile();
    if (parent != null && !parent.exists() && !parent.mkdirs()) {
      java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
          .warning("Failed to create directory for market state: " + parent);
      return;
    }
    try (OutputStream out = new FileOutputStream(file)) {
      properties.store(out, "MarketDynamics price multipliers");
    } catch (Exception e) {
      java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
          .warning("Failed to save market state: " + e.getMessage());
    }
  }

  /** 从文件加载价格乘数，缺失类型保持 1.0 */
  public void loadState(File file) {
    Objects.requireNonNull(file);
    if (!file.exists() || !file.isFile()) {
      return;
    }
    Properties properties = new Properties();
    try (InputStream in = new FileInputStream(file)) {
      properties.load(in);
    } catch (Exception e) {
      java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
          .warning("Failed to load market state: " + e.getMessage());
      return;
    }
    for (ResourceType type : ResourceType.values()) {
      String raw = properties.getProperty(type.name());
      if (raw == null) {
        continue;
      }
      try {
        setPriceMultiplier(type, Double.parseDouble(raw.trim()));
      } catch (NumberFormatException e) {
        java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
            .warning("Invalid market multiplier for " + type.name() + ": " + raw);
      }
    }
  }

  /** 获取资源的当前价格 */
  public double getCurrentPrice(Resource resource) {
    double basePrice = resource.baseValue();
    double multiplier = getPriceMultiplier(resource.type());
    return basePrice * multiplier;
  }

  /** 获取市场数据 */
  public MarketData getMarketData(ResourceType type) {
    return marketDataMap.get(type);
  }

  /** 获取所有市场数据 */
  public Collection<MarketData> getAllMarketData() {
    return marketDataMap.values();
  }

  /** 获取玩家市场数据 */
  public PlayerMarketData getPlayerMarketData(String playerId) {
    return playerMarketDataMap.get(playerId);
  }

  /** 注册市场更新监听器 */
  public void addMarketUpdateListener(Consumer<MarketUpdateEvent> listener) {
    marketUpdateListeners.add(Objects.requireNonNull(listener));
  }

  /** 移除市场更新监听器 */
  public void removeMarketUpdateListener(Consumer<MarketUpdateEvent> listener) {
    marketUpdateListeners.remove(listener);
  }

  /** 通知所有市场更新监听器 */
  private void notifyMarketUpdateListeners(MarketUpdateEvent event) {
    for (Consumer<MarketUpdateEvent> listener : marketUpdateListeners) {
      try {
        listener.accept(event);
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(MarketDynamics.class.getName())
            .warning("Error in market update listener: " + e.getMessage());
      }
    }
  }

  /** 设置基础价格波动性 */
  public void setBasePriceVolatility(double volatility) {
    this.basePriceVolatility = Math.max(0, Math.min(1.0, volatility));
  }

  /** 设置需求敏感度 */
  public void setDemandSensitivity(double sensitivity) {
    this.demandSensitivity = Math.max(0, sensitivity);
  }

  /** 设置供给敏感度 */
  public void setSupplySensitivity(double sensitivity) {
    this.supplySensitivity = Math.max(0, sensitivity);
  }

  /** 设置趋势动量 */
  public void setTrendMomentum(double momentum) {
    this.trendMomentum = Math.max(0, Math.min(1.0, momentum));
  }

  /** 重置市场数据 */
  public void resetMarketData() {
    for (MarketData data : marketDataMap.values()) {
      data.reset();
    }
    for (AtomicReference<Double> ref : priceMultipliers.values()) {
      ref.set(1.0);
    }
  }

  /** 市场数据 */
  public static class MarketData {
    private final ResourceType resourceType;
    // 关键优化：使用 ArrayDeque 并设置上限，避免无限增长导致内存泄漏
    // 1000 条记录对性能分析已经足够，保留最近交易
    private static final int MAX_HISTORY = 1000;
    private final ArrayDeque<TransactionRecord> transactionHistory = new ArrayDeque<>(MAX_HISTORY);
    private final ArrayDeque<MarketUpdateRecord> updateHistory = new ArrayDeque<>(MAX_HISTORY);

    private long totalDemand = 0;
    private long totalSupply = 0;
    private long transactionCount = 0;
    private double totalValue = 0.0;
    private long lastUpdateTime = System.currentTimeMillis();

    public MarketData(ResourceType resourceType) {
      this.resourceType = Objects.requireNonNull(resourceType);
    }

    public void recordTransaction(long amount, double price) {
      // 关键优化：超出上限时移除最旧记录
      if (transactionHistory.size() >= MAX_HISTORY) {
        transactionHistory.pollFirst();
      }
      transactionHistory.addLast(new TransactionRecord(System.currentTimeMillis(), amount, price));

      if (amount > 0) {
        totalSupply += amount;
      } else {
        totalDemand += Math.abs(amount);
      }

      totalValue += Math.abs(amount) * price;
      transactionCount++;
      lastUpdateTime = System.currentTimeMillis();
    }

    public void recordMarketUpdate(double oldMultiplier, double newMultiplier, long timestamp) {
      if (updateHistory.size() >= MAX_HISTORY) {
        updateHistory.pollFirst();
      }
      updateHistory.addLast(new MarketUpdateRecord(timestamp, oldMultiplier, newMultiplier));
    }

    public ResourceType getResourceType() {
      return resourceType;
    }

    public long getTotalDemand() {
      return totalDemand;
    }

    public long getTotalSupply() {
      return totalSupply;
    }

    public long getTransactionCount() {
      return transactionCount;
    }

    public double getTotalValue() {
      return totalValue;
    }

    public double getAveragePrice() {
      return transactionCount > 0 ? totalValue / transactionCount : 0.0;
    }

    public long getAverageDemand() {
      return transactionCount > 0 ? totalDemand / transactionCount : 0;
    }

    public long getAverageSupply() {
      return transactionCount > 0 ? totalSupply / transactionCount : 0;
    }

    public long getLastUpdateTime() {
      return lastUpdateTime;
    }

    public List<TransactionRecord> getTransactionHistory() {
      return List.copyOf(transactionHistory);
    }

    public List<MarketUpdateRecord> getUpdateHistory() {
      return List.copyOf(updateHistory);
    }

    public void reset() {
      transactionHistory.clear();
      updateHistory.clear();
      totalDemand = 0;
      totalSupply = 0;
      transactionCount = 0;
      totalValue = 0.0;
    }
  }

  /** 玩家市场数据 */
  public static class PlayerMarketData {
    private final String playerId;
    private final Map<ResourceType, Long> totalPurchased = new ConcurrentHashMap<>();
    private final Map<ResourceType, Long> totalSold = new ConcurrentHashMap<>();
    private final Map<ResourceType, Double> totalSpent = new ConcurrentHashMap<>();
    private final Map<ResourceType, Double> totalEarned = new ConcurrentHashMap<>();

    public PlayerMarketData(String playerId) {
      this.playerId = Objects.requireNonNull(playerId);
    }

    public void recordTransaction(ResourceType type, long amount, double price) {
      if (amount > 0) {
        // 卖出
        totalSold.merge(type, amount, Long::sum);
        totalEarned.merge(type, amount * price, Double::sum);
      } else {
        // 购买
        totalPurchased.merge(type, Math.abs(amount), Long::sum);
        totalSpent.merge(type, Math.abs(amount) * price, Double::sum);
      }
    }

    public String getPlayerId() {
      return playerId;
    }

    public long getTotalPurchased(ResourceType type) {
      return totalPurchased.getOrDefault(type, 0L);
    }

    public long getTotalSold(ResourceType type) {
      return totalSold.getOrDefault(type, 0L);
    }

    public double getTotalSpent(ResourceType type) {
      return totalSpent.getOrDefault(type, 0.0);
    }

    public double getTotalEarned(ResourceType type) {
      return totalEarned.getOrDefault(type, 0.0);
    }

    public Map<ResourceType, Long> getAllPurchased() {
      return Map.copyOf(totalPurchased);
    }

    public Map<ResourceType, Long> getAllSold() {
      return Map.copyOf(totalSold);
    }
  }

  /** 交易记录 */
  public static record TransactionRecord(long timestamp, long amount, double price) {}

  /** 市场更新记录 */
  public static record MarketUpdateRecord(
      long timestamp, double oldMultiplier, double newMultiplier) {}

  /** 市场更新事件 */
  public static class MarketUpdateEvent {
    private final long timestamp;
    private final Collection<MarketData> marketData;

    public MarketUpdateEvent(long timestamp, Collection<MarketData> marketData) {
      this.timestamp = timestamp;
      this.marketData = new ArrayList<>(Objects.requireNonNull(marketData));
    }

    public long getTimestamp() {
      return timestamp;
    }

    public Collection<MarketData> getMarketData() {
      return List.copyOf(marketData);
    }
  }
}
