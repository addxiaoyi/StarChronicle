package dev.starcore.starcore.core.storage;

import dev.starcore.starcore.core.database.DatabaseService;
import java.util.Objects;
import java.util.Optional;
import javax.sql.DataSource;

/** Pins a module state store to the configured backend for its lifetime. */
public final class StateStorageBackend {
  private final DatabaseService database;
  private final boolean databaseMode;
  private final String databaseUrl;

  public StateStorageBackend(DatabaseService database) {
    this.database = Objects.requireNonNull(database, "database");
    synchronized (database) {
      var settings = database.settings();
      databaseMode = database.isRunning() || (settings != null && settings.enabled());
      databaseUrl = databaseMode && settings != null ? settings.jdbcUrl() : null;
    }
  }

  public boolean usesDatabase() {
    synchronized (database) {
      var settings = database.settings();
      if (database.isRunning() != databaseMode
          || (settings != null && settings.enabled() != databaseMode)
          || (databaseMode
              && !Objects.equals(databaseUrl, settings == null ? null : settings.jdbcUrl()))) {
        throw new IllegalStateException("STATE_STORAGE_BACKEND_UNAVAILABLE");
      }
      return databaseMode;
    }
  }

  public Optional<DataSource> dataSource() {
    synchronized (database) {
      if (!usesDatabase()) {
        throw new IllegalStateException("STATE_STORAGE_BACKEND_UNAVAILABLE");
      }
      return database.dataSource();
    }
  }
}
