package dev.starcore.starcore.core.database;

import dev.starcore.starcore.core.config.ConfigurationService;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.Locale;

public record DatabaseSettings(
    boolean enabled,
    boolean failFast,
    DatabaseType type,
    Path sqliteFile,
    String mysqlHost,
    int mysqlPort,
    String mysqlDatabase,
    String mysqlUsername,
    String mysqlPassword,
    String mysqlParameters,
    boolean mysqlAllowInsecure,
    DatabasePoolSettings pool) {
  private static final String SQLITE_DRIVER = "org.sqlite.JDBC";
  private static final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";

  public static DatabaseSettings from(ConfigurationService configuration, Path dataFolder) {
    DatabaseType type = DatabaseType.fromConfig(configuration.databaseType());
    Path sqliteFile = resolveSqliteFile(dataFolder, configuration.databaseSqliteFile());
    return new DatabaseSettings(
        configuration.databaseEnabled(),
        configuration.databaseFailFast(),
        type,
        sqliteFile,
        configuration.databaseMysqlHost(),
        configuration.databaseMysqlPort(),
        configuration.databaseMysqlDatabase(),
        configuration.databaseMysqlUsername(),
        configuration.databaseMysqlPassword(),
        configuration.databaseMysqlParameters(),
        configuration.databaseMysqlAllowInsecure(),
        new DatabasePoolSettings(
            configuration.databasePoolMaximumPoolSize(),
            configuration.databasePoolMinimumIdle(),
            configuration.databasePoolConnectionTimeoutMs(),
            configuration.databasePoolIdleTimeoutMs(),
            configuration.databasePoolMaxLifetimeMs(),
            configuration.databasePoolKeepaliveTimeMs(),
            configuration.databasePoolValidationTimeoutMs(),
            configuration.databasePoolLeakDetectionThresholdMs()));
  }

  public static DatabaseSettings disabled() {
    return new DatabaseSettings(
        false,
        false,
        DatabaseType.SQLITE,
        Path.of("starcore.db").toAbsolutePath().normalize(),
        "127.0.0.1",
        3306,
        "starcore",
        "starcore",
        "",
        "",
        false,
        new DatabasePoolSettings(1, 0, 30_000L, 600_000L, 1_800_000L, 0L, 5_000L, 0L));
  }

  public String jdbcUrl() {
    return switch (type) {
      case SQLITE -> "jdbc:sqlite:" + sqliteFile.toAbsolutePath().normalize();
      case MYSQL -> mysqlJdbcUrl();
    };
  }

  public String driverClassName() {
    return switch (type) {
      case SQLITE -> SQLITE_DRIVER;
      case MYSQL -> MYSQL_DRIVER;
    };
  }

  public String summary(boolean running) {
    if (!enabled) {
      return "已关闭";
    }
    String status = running ? "运行中" : "未连接";
    return switch (type) {
      case SQLITE ->
          "%s %s (%s)"
              .formatted(type.displayName(), status, sqliteFile.toAbsolutePath().normalize());
      case MYSQL ->
          "%s %s (%s:%d/%s)"
              .formatted(type.displayName(), status, mysqlHost, mysqlPort, mysqlDatabase);
    };
  }

  private String mysqlJdbcUrl() {
    String database =
        mysqlDatabase == null || mysqlDatabase.isBlank() ? "starcore" : mysqlDatabase.trim();
    String host = mysqlHost == null || mysqlHost.isBlank() ? "127.0.0.1" : mysqlHost.trim();
    String parameters = secureMysqlParameters(mysqlParameters, mysqlAllowInsecure);
    String base = "jdbc:mysql://%s:%d/%s".formatted(host, mysqlPort, database);
    return parameters.isBlank() ? base : base + "?" + parameters;
  }

  private static String secureMysqlParameters(String rawParameters, boolean allowInsecure) {
    String parameters = rawParameters == null ? "" : rawParameters.trim();
    if (allowInsecure) {
      return parameters;
    }
    if (parameters.isBlank()) {
      return "sslMode=VERIFY_IDENTITY";
    }

    boolean hasSslMode = false;
    boolean verifiedMode = false;
    boolean hasLegacyUseSsl = false;
    boolean disablesCertificateVerification = false;
    for (String parameter : parameters.split("&")) {
      String[] parts = parameter.split("=", 2);
      String key = parts[0].trim().toLowerCase(Locale.ROOT);
      String value = parts.length == 2 ? parts[1].trim() : "";
      switch (key) {
        case "sslmode" -> {
          hasSslMode = true;
          verifiedMode =
              value.equalsIgnoreCase("VERIFY_CA") || value.equalsIgnoreCase("VERIFY_IDENTITY");
        }
        case "usessl" -> hasLegacyUseSsl = true;
        case "verifyservercertificate" ->
            disablesCertificateVerification = value.equalsIgnoreCase("false");
        default -> {
          // Other Connector/J parameters are passed through unchanged.
        }
      }
    }

    if (hasLegacyUseSsl || disablesCertificateVerification || !hasSslMode || !verifiedMode) {
      throw new IllegalArgumentException(
          "MySQL requires sslMode=VERIFY_CA or VERIFY_IDENTITY; "
              + "set database.mysql.allow-insecure=true only for isolated local tests");
    }
    return parameters;
  }

  private static Path resolveSqliteFile(Path dataFolder, String rawFile) {
    String file = rawFile == null || rawFile.isBlank() ? "starcore.db" : rawFile.trim();
    try {
      Path path = Path.of(file);
      if (path.isAbsolute()) {
        return path.normalize();
      }
      Path base = dataFolder == null ? Path.of(".") : dataFolder;
      return base.resolve(path).toAbsolutePath().normalize();
    } catch (InvalidPathException ignored) {
      Path base = dataFolder == null ? Path.of(".") : dataFolder;
      return base.resolve("starcore.db").toAbsolutePath().normalize();
    }
  }
}
