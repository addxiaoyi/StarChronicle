package dev.starcore.starcore.cooking;

/** 烹调状态枚举 */
public enum CookingStatus {
  /** 等待开始 */
  PENDING,

  /** 进行中 */
  IN_PROGRESS,

  /** 已完成 */
  COMPLETED,

  /** 已失败 */
  FAILED,

  /** 已取消 */
  CANCELLED;
}
