package dev.starcore.starcore.cooking;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** 烹饪系统 GUI：展示食谱列表、解锁状态和活跃烹饪会话。 */
public final class CookingGui implements InventoryHolder {

  private static final String TITLE = "§6§l烹饪台";

  private final Player player;
  private final CookingManager cookingManager;
  private final Inventory inventory;

  public CookingGui(Player player, CookingManager cookingManager) {
    this.player = player;
    this.cookingManager = cookingManager;
    this.inventory = Bukkit.createInventory(this, 27, TITLE);
  }

  public void open() {
    populate();
    player.openInventory(inventory);
  }

  private void populate() {
    inventory.clear();

    var recipes = List.copyOf(cookingManager.getAllRecipes());
    int unlocked = cookingManager.getPlayerUnlockedRecipeCount(player.getUniqueId().toString());

    // 统计卡
    inventory.setItem(
        4,
        item(
            Material.CAMPFIRE,
            "§6§l烹饪台",
            List.of(
                "§7食谱总数: §f" + recipes.size(),
                "§7已解锁: §a" + unlocked,
                "§7活跃烹饪: §e" + cookingManager.getActiveSessionCount())));

    // 食谱列表（最多展示 13 个）
    int slot = 10;
    for (int i = 0; i < Math.min(recipes.size(), 13); i++) {
      if (slot == 17 || slot == 18) {
        slot = 19;
      }
      if (slot > 25) break;
      Recipe recipe = recipes.get(i);
      boolean unlockedHere =
          cookingManager.getPlayerUnlockedRecipes(player.getUniqueId().toString()).stream()
              .anyMatch(r -> r.recipeId().equals(recipe.recipeId()));

      inventory.setItem(
          slot,
          item(
              unlockedHere ? Material.COOKED_BEEF : Material.BROWN_MUSHROOM,
              (unlockedHere ? "§a" : "§7") + recipe.recipeId(),
              List.of(unlockedHere ? "§a已解锁" : "§7未解锁")));
      slot++;
    }

    inventory.setItem(22, item(Material.BARRIER, "§c§l关闭", List.of("§7点击关闭此界面")));
  }

  /** 处理点击：仅关闭按钮有效 */
  public void handleClick(int slot) {
    if (slot == 22) {
      player.closeInventory();
    }
  }

  private ItemStack item(Material material, String name, List<String> lore) {
    ItemStack stack = new ItemStack(material);
    ItemMeta meta = stack.getItemMeta();
    if (meta != null) {
      meta.setDisplayName(name);
      meta.setLore(lore);
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      stack.setItemMeta(meta);
    }
    return stack;
  }

  @Override
  public Inventory getInventory() {
    return inventory;
  }
}
