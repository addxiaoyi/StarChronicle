package dev.starcore.starcore.foundation.message;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MessageFormatter {
  private static final Pattern TOKEN_PATTERN =
      Pattern.compile("\\{([A-Za-z0-9_-]*)\\}");

  private MessageFormatter() {}

  public static String format(String pattern, Object... args) {
    if (pattern == null || args == null || args.length == 0) {
      return pattern;
    }

    if (pattern.indexOf('{') < 0) {
      return pattern;
    }

    // 处理 {} 空大括号 (SLF4J 风格)
    if (pattern.contains("{}")) {
      StringBuilder sb = new StringBuilder(pattern.length() + 16);
      int argIdx = 0;
      int cursor = 0;
      int pos;
      while ((pos = pattern.indexOf("{}", cursor)) >= 0) {
        sb.append(pattern, cursor, pos);
        if (argIdx < args.length) {
          sb.append(args[argIdx++]);
        } else {
          sb.append("{}");
        }
        cursor = pos + 2;
      }
      sb.append(pattern.substring(cursor));
      return sb.toString();
    }

    // 提取模式中所有占位符
    List<String> placeholders = new ArrayList<>();
    Matcher matcher = TOKEN_PATTERN.matcher(pattern);
    while (matcher.find()) {
      placeholders.add(matcher.group(1));
    }

    if (placeholders.isEmpty()) {
      return pattern;
    }

    // 判断是否使用键值对命名参数
    Map<String, String> namedPairs = tryExtractNamedPairs(args, placeholders);
    if (namedPairs != null) {
      return formatWithNamedPairs(pattern, namedPairs);
    }

    // 顺序与数字索引单遍替换（避免替换内容二次匹配导致链式替换）
    StringBuilder result = new StringBuilder(pattern.length() + 32);
    matcher.reset();
    int lastEnd = 0;
    int positionalIdx = 0;

    // 检查是否存在数字索引占位符
    boolean hasNumeric = false;
    for (String p : placeholders) {
      if (isNumeric(p)) {
        hasNumeric = true;
        break;
      }
    }

    while (matcher.find()) {
      result.append(pattern, lastEnd, matcher.start());
      String token = matcher.group(1);

      if (isNumeric(token)) {
        int idx = Integer.parseInt(token);
        if (idx >= 0 && idx < args.length) {
          result.append(args[idx]);
        } else {
          result.append('{').append(token).append('}');
        }
      } else {
        if (!hasNumeric && positionalIdx < args.length) {
          result.append(args[positionalIdx++]);
        } else {
          result.append('{').append(token).append('}');
        }
      }
      lastEnd = matcher.end();
    }
    result.append(pattern.substring(lastEnd));
    return result.toString();
  }

  private static boolean isNumeric(String s) {
    if (s.isEmpty()) return false;
    for (int i = 0; i < s.length(); i++) {
      if (!Character.isDigit(s.charAt(i))) return false;
    }
    return true;
  }

  private static Map<String, String> tryExtractNamedPairs(Object[] args, List<String> placeholders) {
    if (args.length < 2 || args.length % 2 != 0) {
      return null;
    }
    for (int i = 0; i < args.length; i += 2) {
      if (!(args[i] instanceof CharSequence)) {
        return null;
      }
    }

    Map<String, String> map = new HashMap<>();
    boolean anyMatched = false;
    for (int i = 0; i < args.length; i += 2) {
      String key = String.valueOf(args[i]);
      if (placeholders.contains(key)) {
        anyMatched = true;
      }
      map.put(key, String.valueOf(args[i + 1]));
    }
    return anyMatched ? map : null;
  }

  private static String formatWithNamedPairs(String pattern, Map<String, String> pairs) {
    StringBuilder result = new StringBuilder(pattern.length() + 32);
    Matcher matcher = TOKEN_PATTERN.matcher(pattern);
    int lastEnd = 0;
    while (matcher.find()) {
      result.append(pattern, lastEnd, matcher.start());
      String token = matcher.group(1);
      if (pairs.containsKey(token)) {
        result.append(pairs.get(token));
      } else {
        result.append('{').append(token).append('}');
      }
      lastEnd = matcher.end();
    }
    result.append(pattern.substring(lastEnd));
    return result.toString();
  }
}
