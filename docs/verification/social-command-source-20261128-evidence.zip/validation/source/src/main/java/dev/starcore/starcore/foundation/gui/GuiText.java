package dev.starcore.starcore.foundation.gui;

import dev.starcore.starcore.foundation.i18n.I18nManager;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;

public final class GuiText {
  private static final Logger LOGGER = Logger.getLogger(GuiText.class.getName());
  private static volatile I18nManager manager;
  private static final ThreadLocal<RequestContext> REQUEST_CONTEXT = new ThreadLocal<>();

  private record RequestContext(I18nManager manager, UUID playerId, Locale locale) {}

  private GuiText() {}

  public static void configure(I18nManager i18nManager) {
    manager = i18nManager;
  }

  public static String get(Player player, String key, String fallback, Object... args) {
    I18nManager current = manager;
    if (current == null) return fallback;
    try {
      UUID playerId = player == null ? null : player.getUniqueId();
      RequestContext context = REQUEST_CONTEXT.get();
      String message =
          context != null
                  && context.manager() == current
                  && Objects.equals(context.playerId(), playerId)
              ? current.getMessage(context.locale(), key, args)
              : current.getPlayerMessage(playerId, key, args);
      return message.equals(key) ? fallback : message;
    } catch (RuntimeException failure) {
      LOGGER.warning("GUI translation failed for key " + key + ": " + failure.getMessage());
      return fallback;
    }
  }

  public static <T> T withPlayerLocale(Player player, Supplier<T> action) {
    Objects.requireNonNull(action, "action");
    I18nManager current = manager;
    if (current == null || player == null) return action.get();

    UUID playerId = player.getUniqueId();
    RequestContext previous = REQUEST_CONTEXT.get();
    if (previous != null
        && previous.manager() == current
        && Objects.equals(previous.playerId(), playerId)) {
      return action.get();
    }

    Locale locale;
    try {
      locale = current.getPlayerLocale(playerId);
    } catch (RuntimeException failure) {
      LOGGER.warning("GUI locale snapshot failed: " + failure.getMessage());
      return withLocaleContext(current, playerId, current.getDefaultLocale(), previous, action);
    }
    return withLocaleContext(current, playerId, locale, previous, action);
  }

  private static <T> T withLocaleContext(
      I18nManager current,
      UUID playerId,
      Locale locale,
      RequestContext previous,
      Supplier<T> action) {
    REQUEST_CONTEXT.set(new RequestContext(current, playerId, locale));
    try {
      return action.get();
    } finally {
      if (previous == null) {
        REQUEST_CONTEXT.remove();
      } else {
        REQUEST_CONTEXT.set(previous);
      }
    }
  }

  public static void withPlayerLocale(Player player, Runnable action) {
    withPlayerLocale(
        player,
        () -> {
          action.run();
          return null;
        });
  }

  public static Component component(Player player, String key, String fallback, Object... args) {
    return LegacyComponentSerializer.legacySection().deserialize(get(player, key, fallback, args));
  }
}
