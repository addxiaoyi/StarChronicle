package dev.starcore.starcore.boss;

import java.util.*;

/** 奖励物品定义 定义单个奖励物品的属性 */
public record RewardItem(
    String itemId,
    int amount,
    double chance,
    String displayName,
    ItemType type,
    Map<String, Object> properties) {

  public enum ItemType {
    MATERIAL("材料", "用于合成的材料"),
    EQUIPMENT("装备", "可装备的物品"),
    CONSUMABLE("消耗品", "可使用的消耗品"),
    CURRENCY("货币", "游戏货币"),
    EXPERIENCE("经验", "经验值"),
    REPUTATION("声望", "声望值"),
    KEY("钥匙", "开启特定内容的钥匙"),
    BLUEPRINT("蓝图", "解锁新内容的蓝图");

    private final String displayName;
    private final String description;

    ItemType(String displayName, String description) {
      this.displayName = displayName;
      this.description = description;
    }

    public String getDisplayName() {
      return displayName;
    }

    public String getDescription() {
      return description;
    }
  }

  public RewardItem(String itemId, int amount, double chance) {
    this(itemId, amount, chance, itemId, ItemType.MATERIAL, Map.of());
  }

  public RewardItem(String itemId, int amount, double chance, String displayName, ItemType type) {
    this(itemId, amount, chance, displayName, type, Map.of());
  }

  public static Builder builder(String itemId, int amount) {
    return new Builder(itemId, amount);
  }

  public static class Builder {
    private final String itemId;
    private final int amount;
    private double chance = 1.0;
    private String displayName = null;
    private ItemType type = ItemType.MATERIAL;
    private Map<String, Object> properties = new HashMap<>();

    public Builder(String itemId, int amount) {
      this.itemId = Objects.requireNonNull(itemId);
      this.amount = amount;
    }

    public Builder chance(double chance) {
      this.chance = Math.max(0.0, Math.min(1.0, chance));
      return this;
    }

    public Builder displayName(String displayName) {
      this.displayName = displayName;
      return this;
    }

    public Builder type(ItemType type) {
      this.type = type;
      return this;
    }

    public Builder property(String key, Object value) {
      this.properties.put(key, value);
      return this;
    }

    public RewardItem build() {
      return new RewardItem(
          itemId,
          amount,
          chance,
          displayName != null ? displayName : itemId,
          type,
          Map.copyOf(properties));
    }
  }
}
