package dev.starcore.starcore.foundation.gui;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.persistence.PersistentDataType;

/** GUI 按钮工厂 - 统一创建各种类型的按钮 提供一致的外观和交互体验 */
public final class ButtonFactory {
  private static final String HUB_ACTION = "starcore:open_hub";

  // 按钮样式常量
  public static final String BUTTON_STYLE_PRIMARY = "primary";
  public static final String BUTTON_STYLE_SECONDARY = "secondary";
  public static final String BUTTON_STYLE_DANGER = "danger";
  public static final String BUTTON_STYLE_SUCCESS = "success";
  public static final String BUTTON_STYLE_INFO = "info";
  public static final String BUTTON_STYLE_DISABLED = "disabled";

  /** 创建主按钮 */
  public static ItemStack createButton(String name, Material material, String... lore) {
    return createStyledButton(name, material, BUTTON_STYLE_PRIMARY, lore);
  }

  /** 创建样式化按钮 */
  public static ItemStack createStyledButton(
      String name, Material material, String style, String... lore) {
    ItemStack item = new ItemStack(material);
    ItemMeta meta = item.getItemMeta();

    if (meta != null) {
      // 应用样式
      Component displayName = applyStyle(name, style);
      meta.displayName(displayName);

      // 设置描述
      List<Component> loreComponents = new ArrayList<>();
      for (String line : lore) {
        loreComponents.add(Component.text(line, NamedTextColor.GRAY));
      }
      meta.lore(loreComponents);

      item.setItemMeta(meta);
    }

    return VisualComponent.normalize(item);
  }

  /**
   * 创建空槽位。
   *
   * <p>旧菜单仍会调用边框工厂方法；空槽让这些调用保留兼容性， 同时把布局层交给内容层级和留白，而不是铺满装饰材质。
   */
  public static ItemStack createEmptySlot() {
    return new ItemStack(Material.AIR);
  }

  /** 兼容旧菜单的边框调用。 */
  public static ItemStack createBorder() {
    return createEmptySlot();
  }

  /** 兼容旧菜单的彩色边框调用。 */
  public static ItemStack createBorder(Material material) {
    return createEmptySlot();
  }

  /** 创建填充边框 */
  public static ItemStack[] createBorders(int size) {
    ItemStack[] items = new ItemStack[size];
    for (int i = 0; i < size; i++) {
      items[i] = createEmptySlot();
    }
    return items;
  }

  /** 创建分隔符 */
  public static ItemStack createSeparator() {
    return createEmptySlot();
  }

  /** 创建状态按钮 */
  public static ItemStack createStatusButton(String label, boolean enabled, String description) {
    String style = enabled ? BUTTON_STYLE_SUCCESS : BUTTON_STYLE_DISABLED;
    Material material =
        enabled ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
    return createStyledButton(label, material, style, description, enabled ? "当前可用" : "当前不可用");
  }

  /** 创建统计按钮（标签 + 数值） */
  public static ItemStack createStatButton(Material material, String label, String value) {
    ItemStack item = new ItemStack(material);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(
          Component.text(label, NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false));
      List<Component> lore = new ArrayList<>();
      lore.add(
          Component.text("§e" + value, NamedTextColor.GOLD).decoration(TextDecoration.BOLD, true));
      meta.lore(lore);
      item.setItemMeta(meta);
    }
    return VisualComponent.normalize(item);
  }

  /** 创建信息按钮 */
  public static ItemStack createInfoButton(String title, String... info) {
    return createStyledButton(title, Material.BOOK, BUTTON_STYLE_INFO, info);
  }

  /** 创建导航按钮（左箭头） */
  public static ItemStack createPrevButton(String label) {
    return createStyledButton(label, Material.ARROW, BUTTON_STYLE_SECONDARY);
  }

  /** 创建导航按钮（右箭头） */
  public static ItemStack createNextButton(String label) {
    return createStyledButton(label, Material.ARROW, BUTTON_STYLE_SECONDARY);
  }

  /** 创建返回按钮 */
  public static ItemStack createBackButton() {
    return createStyledButton("返回", Material.ARROW, BUTTON_STYLE_SECONDARY);
  }

  public static ItemStack createBackButton(Player player) {
    return createStyledButton(
        GuiText.get(player, "gui.back-button", "Back"), Material.ARROW, BUTTON_STYLE_SECONDARY);
  }

  /** 创建关闭按钮 */
  public static ItemStack createCloseButton() {
    return createStyledButton("关闭", Material.BARRIER, BUTTON_STYLE_DANGER);
  }

  public static ItemStack createCloseButton(Player player) {
    return createStyledButton(
        GuiText.get(player, "gui.close-button", "Close"), Material.BARRIER, BUTTON_STYLE_DANGER);
  }

  public static ItemStack createHubButton() {
    return createHubButton("Overview", "Return to the StarCore hub", "Switch to another module");
  }

  public static ItemStack createHubButton(Player player) {
    return createHubButton(
        GuiText.get(player, "gui.hub-button", "Overview"),
        GuiText.get(player, "gui.hub-lore", "Return to the StarCore hub"),
        GuiText.get(player, "gui.hub-hint", "Switch to another module"));
  }

  private static ItemStack createHubButton(String name, String description, String hint) {
    ItemStack item = createStyledButton(name, Material.COMPASS, BUTTON_STYLE_INFO, description, hint);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.getPersistentDataContainer()
          .set(
              org.bukkit.NamespacedKey.fromString("starcore:gui_action"),
              PersistentDataType.STRING,
              HUB_ACTION);
      item.setItemMeta(meta);
    }
    return VisualComponent.normalize(item);
  }

  static boolean isHubButton(ItemStack item, Plugin plugin) {
    if (item == null || plugin == null || !item.hasItemMeta()) return false;
    ItemMeta meta = item.getItemMeta();
    if (HUB_ACTION.equals(
        meta.getPersistentDataContainer()
            .get(org.bukkit.NamespacedKey.fromString("starcore:gui_action"), PersistentDataType.STRING))) {
      return true;
    }
    return item.getType() == Material.COMPASS
        && meta.displayName() != null
        && net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
            .serialize(meta.displayName())
            .equals("总览");
  }

  /** 创建确认按钮 */
  public static ItemStack createConfirmButton(String action) {
    return createStyledButton(
        action == null || action.isBlank() ? "确认" : "确认 " + action,
        Material.LIME_CONCRETE,
        BUTTON_STYLE_SUCCESS);
  }

  /** 创建取消按钮 */
  public static ItemStack createCancelButton() {
    return createStyledButton("取消", Material.RED_CONCRETE, BUTTON_STYLE_DANGER);
  }

  /** 创建玩家头颅按钮（用于显示玩家信息） */
  public static ItemStack createPlayerHead(Player player) {
    return createPlayerHead(player.getName());
  }

  /** 创建玩家头颅按钮 */
  public static ItemStack createPlayerHead(String playerName) {
    ItemStack head = new ItemStack(Material.PLAYER_HEAD);
    ItemMeta meta = head.getItemMeta();
    if (meta != null) {
      meta.displayName(
          Component.text(playerName, NamedTextColor.YELLOW).decorate(TextDecoration.BOLD));
      head.setItemMeta(meta);
    }
    return VisualComponent.normalize(head);
  }

  /** 应用样式到文本 */
  private static Component applyStyle(String text, String style) {
    Component component = Component.text(text);

    return switch (style) {
      case BUTTON_STYLE_PRIMARY -> component.color(NamedTextColor.GOLD);
      case BUTTON_STYLE_SECONDARY -> component.color(NamedTextColor.GRAY);
      case BUTTON_STYLE_DANGER -> component.color(NamedTextColor.RED);
      case BUTTON_STYLE_SUCCESS -> component.color(NamedTextColor.GREEN);
      case BUTTON_STYLE_INFO -> component.color(NamedTextColor.AQUA);
      case BUTTON_STYLE_DISABLED -> component.color(NamedTextColor.DARK_GRAY);
      default -> component.color(NamedTextColor.WHITE);
    };
  }

  /** 创建页码按钮 */
  public static ItemStack createPageButton(int page, int currentPage, int totalPages) {
    if (page == currentPage) {
      return createStyledButton(
          "§6第 " + page + " 页",
          Material.NETHER_STAR,
          BUTTON_STYLE_PRIMARY,
          "当前页面: " + currentPage + "/" + totalPages);
    } else {
      return createStyledButton(
          "§7第 " + page + " 页", Material.PAPER, BUTTON_STYLE_SECONDARY, "共 " + totalPages + " 页");
    }
  }

  /** 创建进度条按钮 */
  public static ItemStack createProgressButton(
      String label, int current, int max, Material fillMaterial, Material emptyMaterial) {
    int percentage = max > 0 ? (current * 100 / max) : 0;
    Material material =
        percentage >= 75
            ? Material.LIME_STAINED_GLASS_PANE
            : percentage >= 50
                ? Material.YELLOW_STAINED_GLASS_PANE
                : percentage >= 25
                    ? Material.ORANGE_STAINED_GLASS_PANE
                    : Material.RED_STAINED_GLASS_PANE;

    String progress = "§7[";
    int bars = 10;
    int filled = (int) (percentage / 10.0);
    for (int i = 0; i < bars; i++) {
      progress += i < filled ? "§a█" : "§7░";
    }
    progress += "§7] " + percentage + "%";

    return createStyledButton(
        label, material, BUTTON_STYLE_INFO, progress, "当前: " + current + " / " + max);
  }

  /**
   * 创建空列表引导项。
   *
   * <p>用于列表为空时(无好友/无军队/无记录等)，给出引导下一步的提示， 而非留白。遵循 UX 决策「空列表显示引导提示项」。
   *
   * @param message 空状态说明，如「你还没有好友」
   * @param actionHint 引导下一步的提示，如「点此添加好友」，可为 null
   */
  public static ItemStack createEmptyState(String message, String actionHint) {
    if (actionHint == null || actionHint.isEmpty()) {
      return createStyledButton("§7" + message, Material.COBWEB, BUTTON_STYLE_SECONDARY);
    }
    return createStyledButton(
        "§7" + message, Material.COBWEB, BUTTON_STYLE_SECONDARY, "", "§e▶ " + actionHint);
  }
}
