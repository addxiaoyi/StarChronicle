package dev.starcore.starcore.foundation.animation;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

/** Menu transitions retain the original player and the exact inventory at every phase. */
public final class MenuTransitionAnimator {
  private final GuiAnimationManager animationManager;
  private final AnimationTaskTracker tasks;
  private final Map<UUID, TransitionState> activeTransitions = new ConcurrentHashMap<>();

  public MenuTransitionAnimator(Plugin plugin, GuiAnimationManager animationManager) {
    this.animationManager = animationManager;
    tasks = new AnimationTaskTracker(plugin);
  }

  private static final class TransitionState {
    final Player player;
    final Inventory from;
    final Inventory to;
    final Consumer<Inventory> complete;
    Inventory expected;
    int slot;
    long phase;

    TransitionState(Player player, Inventory from, Inventory to, Consumer<Inventory> complete) {
      this.player = player;
      this.from = from;
      this.to = to;
      this.complete = complete;
      expected = from;
    }
  }

  public void playSlideTransition(
      Player player, Inventory from, Inventory to, Consumer<Inventory> onComplete) {
    tasks.execute(
        player,
        () -> {
          TransitionState state = begin(player, from, to, onComplete);
          if (state != null) hideNext(state);
        });
  }

  private TransitionState begin(
      Player player, Inventory from, Inventory to, Consumer<Inventory> onComplete) {
    if (player.getOpenInventory().getTopInventory() != from) return null;
    cancelTransition(player);
    if (!animationManager.isTransitionEnabled()) {
      onComplete.accept(to);
      return null;
    }
    TransitionState state = new TransitionState(player, from, to, onComplete);
    activeTransitions.put(player.getUniqueId(), state);
    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.3f, 1.2f);
    return state;
  }

  private boolean current(TransitionState state) {
    if (activeTransitions.get(state.player.getUniqueId()) != state) return false;
    if (state.player.getOpenInventory().getTopInventory() != state.expected) {
      activeTransitions.remove(state.player.getUniqueId(), state);
      return false;
    }
    return true;
  }

  private void hideNext(TransitionState state) {
    later(
        state,
        () -> {
          if (!current(state)) return;
          if (state.slot < state.from.getSize()) {
            state.from.setItem(state.slot++, emptyPane());
            hideNext(state);
          } else {
            state.slot = 0;
            showNext(state);
          }
        },
        2);
  }

  private void showNext(TransitionState state) {
    later(
        state,
        () -> {
          if (!current(state)) return;
          if (state.slot < state.to.getSize()) {
            if (state.slot++ % 9 == 0)
              state.player.playSound(
                  state.player.getLocation(), Sound.BLOCK_STONE_BUTTON_CLICK_ON, 0.1f, 1.5f);
            showNext(state);
          } else finish(state);
        },
        1);
  }

  private void finish(TransitionState state) {
    if (!current(state)) return;
    activeTransitions.remove(state.player.getUniqueId(), state);
    state.complete.accept(state.to);
  }

  private void later(TransitionState state, Runnable action, long delay) {
    long phase = ++state.phase;
    var handle = tasks.runTaskLater(state.player, action, delay);
    tasks.onRetired(
        handle,
        () -> {
          if (state.phase == phase) activeTransitions.remove(state.player.getUniqueId(), state);
        });
  }

  private void delayedOpen(
      Player player,
      Inventory from,
      Inventory to,
      Consumer<Inventory> complete,
      long delay,
      Sound sound,
      boolean fade) {
    tasks.execute(
        player,
        () -> {
          TransitionState state = begin(player, from, to, complete);
          if (state == null) return;
          player.closeInventory();
          state.expected = player.getOpenInventory().getTopInventory();
          later(
              state,
              () -> {
                if (!current(state)) return;
                player.openInventory(to);
                // InventoryOpenEvent may cancel the open or replace it with another menu.
                state.expected = to;
                if (!current(state)) return;
                player.playSound(player.getLocation(), sound, 0.3f, 1.2f);
                if (fade) {
                  later(
                      state,
                      () -> {
                        if (!current(state)) return;
                        player.sendActionBar(Component.text(">> 页面已加载", NamedTextColor.GREEN));
                        finish(state);
                      },
                      3);
                } else finish(state);
              },
              delay);
        });
  }

  public void playFadeTransition(
      Player player, Inventory from, Inventory to, Consumer<Inventory> complete) {
    delayedOpen(player, from, to, complete, 5, Sound.BLOCK_NOTE_BLOCK_BANJO, true);
  }

  public void playRotateTransition(
      Player player, Inventory from, Inventory to, Consumer<Inventory> complete) {
    delayedOpen(player, from, to, complete, 5, Sound.ENTITY_ENDERMAN_TELEPORT, false);
  }

  public void playBounceTransition(
      Player player, Inventory from, Inventory to, Consumer<Inventory> complete) {
    delayedOpen(player, from, to, complete, 5, Sound.ENTITY_PLAYER_LEVELUP, false);
  }

  public void playBlinkTransition(
      Player player, Inventory from, Inventory to, Consumer<Inventory> complete) {
    delayedOpen(player, from, to, complete, 3, Sound.UI_BUTTON_CLICK, false);
  }

  public void cancelTransition(Player player) {
    TransitionState state = activeTransitions.get(player.getUniqueId());
    if (state != null && state.player == player)
      activeTransitions.remove(player.getUniqueId(), state);
    tasks.cancelPlayer(player);
  }

  public void cancelAllTransitions() {
    tasks.cancelAll();
    activeTransitions.clear();
  }

  public void shutdown() {
    tasks.shutdown();
    activeTransitions.clear();
  }

  private ItemStack emptyPane() {
    ItemStack pane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
    ItemMeta meta = pane.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(" "));
      pane.setItemMeta(meta);
    }
    return pane;
  }
}
