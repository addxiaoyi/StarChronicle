package dev.starcore.starcore.core.persistence;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/** 统一的脏数据闭环管理器 提供完整的标记→持久化→验证→清理闭环，确保数据一致性。 */
public final class DirtyDataManager<T> {
  private final String name;
  private final DirtyDataStore<T> store;
  private final DataVerifier<T> verifier;
  private final Map<T, DirtyEntry<T>> dirtyEntries = new IdentityHashMap<>();
  private volatile boolean closed = false;
  private boolean processing;
  private boolean closing;

  public DirtyDataManager(String name, DirtyDataStore<T> store, DataVerifier<T> verifier) {
    this.name = Objects.requireNonNull(name, "name");
    this.store = Objects.requireNonNull(store, "store");
    this.verifier = Objects.requireNonNull(verifier, "verifier");
  }

  public void markDirty(T entity, String reason) {
    synchronized (dirtyEntries) {
      if (closed) {
        throw new IllegalStateException(name + " 已关闭");
      }
      Objects.requireNonNull(entity, "entity");
      Objects.requireNonNull(reason, "reason");
      dirtyEntries.put(entity, new DirtyEntry<>(entity, reason, Instant.now()));
    }
  }

  public void markDirty(T entity) {
    markDirty(entity, "manual");
  }

  public void markAllDirty(Collection<T> entities, String reason) {
    Objects.requireNonNull(entities, "entities");
    Objects.requireNonNull(reason, "reason");
    entities.forEach(entity -> markDirty(entity, reason));
  }

  /** 执行闭环：保存脏数据 → 验证 → 清理 */
  public synchronized DirtyLoopResult processDirtyLoop() {
    if (closed) {
      throw new IllegalStateException(name + " 已关闭");
    }
    if (processing) {
      throw new IllegalStateException(name + " 正在处理脏数据，不能重入");
    }
    processing = true;
    try {
      return processDirtyEntries();
    } finally {
      processing = false;
    }
  }

  private DirtyLoopResult processDirtyEntries() {
    List<DirtyEntry<T>> toProcess;
    synchronized (dirtyEntries) {
      if (dirtyEntries.isEmpty()) {
        return DirtyLoopResult.empty();
      }
      toProcess = List.copyOf(dirtyEntries.values());
    }
    long startTime = System.nanoTime();
    int savedCount = 0;
    int verifiedCount = 0;
    List<String> errors = new ArrayList<>();

    for (DirtyEntry<T> entry : toProcess) {
      synchronized (dirtyEntries) {
        if (dirtyEntries.get(entry.entity()) != entry) {
          continue;
        }
      }
      try {
        store.save(entry.entity());
        savedCount++;

        if (verifier.verify(entry.entity())) {
          verifiedCount++;
          synchronized (dirtyEntries) {
            if (dirtyEntries.get(entry.entity()) == entry) {
              dirtyEntries.remove(entry.entity());
            }
          }
        } else {
          errors.add("验证失败: " + entry.entity());
        }
      } catch (Exception e) {
        errors.add("保存失败: " + entry.entity() + " - " + e.getMessage());
      }
    }

    long durationMs = (System.nanoTime() - startTime) / 1_000_000;
    return new DirtyLoopResult(savedCount, verifiedCount, errors, durationMs);
  }

  public DirtyLoopResult tryProcessDirtyLoop() {
    try {
      return processDirtyLoop();
    } catch (Exception e) {
      return DirtyLoopResult.failed(e.getMessage());
    }
  }

  public int dirtyCount() {
    synchronized (dirtyEntries) {
      return dirtyEntries.size();
    }
  }

  public Set<DirtyEntry<T>> getDirtyEntries() {
    List<DirtyEntry<T>> snapshot;
    synchronized (dirtyEntries) {
      snapshot = List.copyOf(dirtyEntries.values());
    }
    Set<DirtyEntry<T>> entries = Collections.newSetFromMap(new IdentityHashMap<>());
    entries.addAll(snapshot);
    return entries;
  }

  public void clearDirty(T entity) {
    cleanEntry(entity);
  }

  public synchronized void close() {
    if (processing || closing) {
      throw new IllegalStateException(name + " 不能在保存、验证或关闭回调中重入关闭");
    }
    closing = true;
    try {
      synchronized (dirtyEntries) {
        closed = true;
        dirtyEntries.clear();
      }
      store.close();
    } finally {
      closing = false;
    }
  }

  private void cleanEntry(T entity) {
    synchronized (dirtyEntries) {
      dirtyEntries.remove(entity);
    }
  }

  public String getName() {
    return name;
  }

  public boolean isClosed() {
    return closed;
  }

  // === 核心接口 ===

  /** 脏数据存储接口 */
  public interface DirtyDataStore<T> {
    void save(T entity);

    T load(Object key);

    void delete(Object key);

    void close();
  }

  /** 数据验证器接口 */
  @FunctionalInterface
  public interface DataVerifier<T> {
    boolean verify(T entity);
  }

  /** 脏数据条目 */
  public record DirtyEntry<T>(T entity, String reason, Instant markedAt) {}

  /** 循环处理结果 */
  public record DirtyLoopResult(
      int savedCount, int verifiedCount, List<String> errors, long durationMs) {
    private static final DirtyLoopResult EMPTY = new DirtyLoopResult(0, 0, List.of(), 0);

    public static DirtyLoopResult empty() {
      return EMPTY;
    }

    public static DirtyLoopResult failed(String errorMessage) {
      return new DirtyLoopResult(0, 0, List.of(errorMessage), 0);
    }

    public boolean isSuccess() {
      return errors.isEmpty() && savedCount == verifiedCount;
    }

    public double successRate() {
      if (savedCount == 0) return 1.0;
      return (double) verifiedCount / savedCount;
    }
  }
}
