package dev.starcore.starcore.foundation.economy.transaction;

import java.time.Instant;
import java.util.Objects;

/** One durable state transition in a transaction timeline. */
public record TransactionEvent(Instant at, EconomyTransactionState state, String message) {
  public TransactionEvent {
    Objects.requireNonNull(at, "at");
    Objects.requireNonNull(state, "state");
    Objects.requireNonNull(message, "message");
  }
}
