package dev.starcore.starcore.core.monitoring;

/**
 * Receives a complete Prometheus exposition payload.
 *
 * <p>Implementations should fail when the receiver did not acknowledge the payload. The monitoring
 * service records that failure. The acknowledgement's durability depends on the receiver protocol
 * and must be verified separately; an HTTP 2xx response alone does not prove durable storage.
 */
@FunctionalInterface
public interface MetricsReceiver {
  void publish(String prometheusPayload) throws Exception;

  /**
   * Releases resources owned by this receiver.
   *
   * <p>Receivers are often replaced while a plugin is reloaded or disabled. The default keeps
   * simple function receivers source-compatible while allowing network-backed receivers to cancel
   * in-flight work.
   */
  default void close() {}
}
