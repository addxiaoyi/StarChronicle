package dev.starcore.starcore.dummy;

/** 训练目标类型预设 定义血量、护甲（伤害减免）、是否反击、是否移动（转向）、HUD 显示等默认配置 */
public enum TrainingDummyType {

  /** 标准木桩：均衡配置，无减免无反击 */
  STANDARD("标准", 20.0, 0.0, false, false, 0.0, true),

  /** 重甲：高血量高减免，适合测试持续输出 */
  TANK("重甲", 100.0, 0.5, false, false, 0.0, true),

  /** 脆皮：低血量无减免，适合测试爆发 */
  GLASS("脆皮", 10.0, 0.0, false, false, 0.0, true),

  /** 反击型：受伤后延迟反击玩家 */
  AGGRESSIVE("反击", 40.0, 0.1, true, true, 2.0, true),

  /** 固定木桩：不转向、不反击，纯站桩 */
  STATIC("固定", 30.0, 0.2, false, false, 0.0, true);

  private final String displayName;
  private final double maxHealth;
  private final double damageReduction;
  private final boolean counterAttack;
  private final boolean movement;
  private final double counterDamage;
  private final boolean hudEnabled;

  TrainingDummyType(
      String displayName,
      double maxHealth,
      double damageReduction,
      boolean counterAttack,
      boolean movement,
      double counterDamage,
      boolean hudEnabled) {
    this.displayName = displayName;
    this.maxHealth = maxHealth;
    this.damageReduction = damageReduction;
    this.counterAttack = counterAttack;
    this.movement = movement;
    this.counterDamage = counterDamage;
    this.hudEnabled = hudEnabled;
  }

  public String getDisplayName() {
    return displayName;
  }

  public double getMaxHealth() {
    return maxHealth;
  }

  public double getDamageReduction() {
    return damageReduction;
  }

  public boolean isCounterAttack() {
    return counterAttack;
  }

  public boolean isMovement() {
    return movement;
  }

  public double getCounterDamage() {
    return counterDamage;
  }

  public boolean isHudEnabled() {
    return hudEnabled;
  }

  /** 按名称解析类型，支持大小写与常见别名，无法识别时返回 null */
  public static TrainingDummyType fromName(String raw) {
    if (raw == null || raw.isBlank()) {
      return null;
    }

    String key = raw.trim().toLowerCase();
    for (TrainingDummyType type : values()) {
      if (type.name().equalsIgnoreCase(key) || type.displayName.equals(raw.trim())) {
        return type;
      }
    }

    return switch (key) {
      case "normal", "default", "std" -> STANDARD;
      case "tank", "heavy" -> TANK;
      case "glass", "squishy" -> GLASS;
      case "aggressive", "counter" -> AGGRESSIVE;
      case "static", "fixed" -> STATIC;
      default -> null;
    };
  }
}
