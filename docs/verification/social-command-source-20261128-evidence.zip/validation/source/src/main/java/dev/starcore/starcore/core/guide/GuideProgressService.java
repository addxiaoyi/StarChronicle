package dev.starcore.starcore.core.guide;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

/** 指南进度追踪服务 */
public final class GuideProgressService {

  private static final Map<UUID, PlayerProgress> progressMap = new ConcurrentHashMap<>();

  private GuideProgressService() {}

  /** 玩家退出时移除内存中的进度（PlayerQuitEvent 监听方调用） */
  public static void clearProgress(UUID playerId) {
    progressMap.remove(playerId);
  }

  public static PlayerProgress getProgress(Player player) {
    return progressMap.computeIfAbsent(player.getUniqueId(), k -> new PlayerProgress());
  }

  public static boolean isChapterUnlocked(Player player, GuideChapter chapter) {
    PlayerProgress progress = getProgress(player);
    return progress.isChapterUnlocked(chapter);
  }

  public static int getChapterProgress(Player player, GuideChapter chapter) {
    PlayerProgress progress = getProgress(player);
    return progress.getChapterProgress(chapter);
  }

  public static void setItemUnlocked(Player player, GuideChapter chapter, String itemId) {
    PlayerProgress progress = getProgress(player);
    progress.setItemUnlocked(chapter, itemId);
  }

  public static Set<String> getUnlockedItems(Player player, GuideChapter chapter) {
    return getProgress(player).getUnlockedItems(chapter);
  }

  public static boolean canAccessItem(
      Player player, GuideChapter chapter, GuideContentProvider.GuideItem item) {
    PlayerProgress progress = getProgress(player);
    if (!progress.isChapterUnlocked(chapter)) {
      return false;
    }
    for (String prerequisite : item.prerequisites()) {
      GuideChapter prerequisiteChapter = findChapter(prerequisite);
      if (prerequisiteChapter == null
          || !progress.getUnlockedItems(prerequisiteChapter).contains(prerequisite)) {
        return false;
      }
    }
    return true;
  }

  private static GuideChapter findChapter(String itemId) {
    for (GuideChapter chapter : GuideChapter.values()) {
      if (GuideContentProvider.getItem(chapter, itemId) != null) {
        return chapter;
      }
    }
    return null;
  }

  /** 玩家进度数据 */
  public static class PlayerProgress {
    private final Map<GuideChapter, Set<String>> unlockedItems = new EnumMap<>(GuideChapter.class);
    private int totalProgress;

    public boolean isChapterUnlocked(GuideChapter chapter) {
      return chapter.getUnlockCondition().getProgressThreshold() <= totalProgress;
    }

    public int getChapterProgress(GuideChapter chapter) {
      Set<String> items = unlockedItems.getOrDefault(chapter, Collections.emptySet());
      int totalItems = GuideContentProvider.getItemCount(chapter);
      if (totalItems == 0) return 100;
      return (int) ((double) items.size() / totalItems * 100);
    }

    public void setItemUnlocked(GuideChapter chapter, String itemId) {
      unlockedItems.computeIfAbsent(chapter, k -> new HashSet<>()).add(itemId);
      totalProgress = calculateTotalProgress();
    }

    public Set<String> getUnlockedItems(GuideChapter chapter) {
      return unlockedItems.getOrDefault(chapter, Collections.emptySet());
    }

    private int calculateTotalProgress() {
      int totalItems = 0;
      int unlocked = 0;
      for (GuideChapter chapter : GuideChapter.values()) {
        totalItems += GuideContentProvider.getItemCount(chapter);
        unlocked += getUnlockedItems(chapter).size();
      }
      return totalItems > 0 ? (int) ((double) unlocked / totalItems * 100) : 0;
    }

    public int getTotalProgress() {
      return totalProgress;
    }
  }
}
