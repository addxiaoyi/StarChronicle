package dev.starcore.starcore.foundation.economy.transaction;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Small file-backed ledger used to retry money delivery after a partial transaction failure. */
public final class RefundLedger {
  private static final String VERSION = "1";
  private final Path file;
  private final Logger logger;
  private final Map<UUID, PendingRefund> pending = new HashMap<>();
  private final Set<UUID> activeDeliveryAttempts = new HashSet<>();

  public RefundLedger(Path file, Logger logger) {
    this.file = Objects.requireNonNull(file, "file");
    this.logger = Objects.requireNonNull(logger, "logger");
    load();
  }

  public synchronized void record(PendingRefund refund) {
    PendingRefund existing = pending.get(refund.transactionId());
    if (existing != null) {
      if (!sameRefundIdentity(existing, refund)) {
        throw new IllegalArgumentException(
            "Refund transaction ID is already bound to another refund");
      }
      return;
    }
    pending.put(refund.transactionId(), refund);
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.remove(refund.transactionId(), refund);
      throw failure;
    }
  }

  private static boolean sameRefundIdentity(PendingRefund left, PendingRefund right) {
    return left.accountId().equals(right.accountId())
        && left.amount().compareTo(right.amount()) == 0
        && left.reason().equals(right.reason())
        && left.owner() == right.owner();
  }

  public synchronized void markDelivered(UUID transactionId) {
    PendingRefund refund = pending.remove(transactionId);
    if (refund == null) return;
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
  }

  /** Removes one retry row only when both its transaction ID and reason match. */
  public synchronized boolean markDeliveredByReason(String reason, UUID transactionId) {
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(transactionId, "transactionId");
    PendingRefund refund = pending.get(transactionId);
    if (refund == null || !refund.reason().equals(reason)) return false;
    if (!pending.remove(transactionId, refund)) return false;
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
    return true;
  }

  /** Removes a domain refund by its source identity when the ledger has a separate refund UUID. */
  public synchronized boolean markDeliveredByIdentity(
      String reason, UUID accountId, BigDecimal amount, RefundOwner owner) {
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(accountId, "accountId");
    Objects.requireNonNull(amount, "amount");
    Objects.requireNonNull(owner, "owner");
    for (Map.Entry<UUID, PendingRefund> entry : pending.entrySet()) {
      UUID transactionId = entry.getKey();
      PendingRefund refund = entry.getValue();
      if (!refund.reason().equals(reason)
          || !refund.accountId().equals(accountId)
          || refund.amount().compareTo(amount) != 0
          || refund.owner() != owner) {
        continue;
      }
      if (!pending.remove(transactionId, refund)) continue;
      try {
        persist();
      } catch (RuntimeException failure) {
        pending.put(transactionId, refund);
        throw failure;
      }
      return true;
    }
    return false;
  }

  /**
   * Resolves every legacy retry row for a verified domain reason. Prefer the transaction-scoped
   * overload for normal runtime delivery.
   */
  public synchronized int markDeliveredByReason(String reason) {
    Objects.requireNonNull(reason, "reason");
    Map<UUID, PendingRefund> removed = new java.util.LinkedHashMap<>();
    for (UUID transactionId : new ArrayList<>(pending.keySet())) {
      PendingRefund refund = pending.get(transactionId);
      if (refund != null
          && refund.reason().equals(reason)
          && pending.remove(transactionId, refund)) {
        removed.put(transactionId, refund);
      }
    }
    if (removed.isEmpty()) return 0;
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.putAll(removed);
      throw failure;
    }
    return removed.size();
  }

  /** Requeues a reviewed refund only after an operator supplies an explicit retry reason. */
  public synchronized boolean authorizeRetry(
      UUID transactionId, String authorizationReason, Instant retryAt) {
    Objects.requireNonNull(transactionId, "transactionId");
    Objects.requireNonNull(retryAt, "retryAt");
    if (authorizationReason == null || authorizationReason.isBlank()) {
      throw new IllegalArgumentException("authorizationReason must not be blank");
    }
    PendingRefund refund = pending.get(transactionId);
    if (refund == null
        || !refund.manualReview()
        || activeDeliveryAttempts.contains(transactionId)) {
      return false;
    }
    pending.put(
        transactionId,
        new PendingRefund(
            refund.transactionId(),
            refund.accountId(),
            refund.amount(),
            refund.reason(),
            refund.attempts(),
            retryAt,
            "operator-authorized-retry: " + authorizationReason,
            false,
            refund.owner()));
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
    return true;
  }

  public synchronized void markFailed(PendingRefund refund, String error, Instant retryAt) {
    PendingRefund previous = pending.get(refund.transactionId());
    if (previous != null) {
      pending.put(refund.transactionId(), refund.failed(error, retryAt));
      try {
        persist();
      } catch (RuntimeException failure) {
        pending.put(refund.transactionId(), previous);
        throw failure;
      }
    }
  }

  /** Schedules another attempt only when the provider definitively rejected delivery. */
  public synchronized void markRetryableFailure(
      PendingRefund refund, String error, Instant retryAt) {
    PendingRefund current = pending.get(refund.transactionId());
    if (current == null) return;
    pending.put(
        refund.transactionId(),
        new PendingRefund(
            current.transactionId(),
            current.accountId(),
            current.amount(),
            current.reason(),
            current.attempts() + 1,
            retryAt,
            error,
            false,
            current.owner()));
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(refund.transactionId(), current);
      throw failure;
    }
  }

  /** Assigns an owner to a legacy UNKNOWN record after an operator verifies its origin. */
  public synchronized boolean assignOwner(UUID transactionId, RefundOwner owner) {
    return assignOwner(transactionId, owner, "operator owner assignment");
  }

  /** Assigns an owner and preserves the operator's migration reason in the ledger. */
  public synchronized boolean assignOwner(
      UUID transactionId, RefundOwner owner, String migrationReason) {
    Objects.requireNonNull(transactionId, "transactionId");
    Objects.requireNonNull(owner, "owner");
    if (migrationReason == null || migrationReason.isBlank()) {
      throw new IllegalArgumentException("migrationReason must not be blank");
    }
    PendingRefund refund = pending.get(transactionId);
    if (refund == null || refund.owner() != RefundOwner.UNKNOWN || owner == RefundOwner.UNKNOWN) {
      return false;
    }
    pending.put(
        transactionId,
        new PendingRefund(
            refund.transactionId(),
            refund.accountId(),
            refund.amount(),
            refund.reason(),
            refund.attempts(),
            refund.nextAttemptAt(),
            "owner-assigned: " + migrationReason,
            refund.manualReview(),
            owner));
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
    return true;
  }

  /** Returns only deterministic candidates; ambiguous legacy rows return an empty set. */
  public static List<RefundOwner> legacyOwnerCandidates(PendingRefund refund) {
    Objects.requireNonNull(refund, "refund");
    String reason = refund.reason().trim().toLowerCase(Locale.ROOT);
    EnumSet<RefundOwner> candidates = EnumSet.noneOf(RefundOwner.class);
    if (reason.startsWith("dungeon:")) candidates.add(RefundOwner.DUNGEON);
    if (reason.startsWith("trade:")) candidates.add(RefundOwner.TRADE);
    if (reason.startsWith("donation:")) candidates.add(RefundOwner.DONATION);
    if (reason.startsWith("shop:")
        || reason.startsWith("shop-purchase:")
        || reason.startsWith("shop-sale:")
        || reason.startsWith("auction:")
        || reason.startsWith("auction-buyout:")) {
      candidates.add(RefundOwner.SHOP);
    }
    return List.copyOf(candidates);
  }

  /** Marks every retry row for a verified reason so a domain-specific insurer can settle it. */
  public synchronized int markManualReviewByReason(String reason, String reviewReason) {
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(reviewReason, "reviewReason");
    Map<UUID, PendingRefund> previous = new HashMap<>();
    for (Map.Entry<UUID, PendingRefund> entry : pending.entrySet()) {
      PendingRefund refund = entry.getValue();
      if (!refund.reason().equals(reason) || refund.manualReview()) continue;
      previous.put(entry.getKey(), refund);
      entry.setValue(
          new PendingRefund(
              refund.transactionId(),
              refund.accountId(),
              refund.amount(),
              refund.reason(),
              refund.attempts(),
              refund.nextAttemptAt(),
              reviewReason,
              true,
              refund.owner()));
    }
    if (previous.isEmpty()) return 0;
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.putAll(previous);
      throw failure;
    }
    return previous.size();
  }

  public synchronized void markManualReview(UUID transactionId, String reason) {
    PendingRefund refund = pending.get(transactionId);
    if (refund == null) return;
    pending.put(
        transactionId,
        new PendingRefund(
            refund.transactionId(),
            refund.accountId(),
            refund.amount(),
            refund.reason(),
            refund.attempts(),
            refund.nextAttemptAt(),
            reason,
            true,
            refund.owner()));
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
  }

  /** Claims one unreviewed refund for delivery and durably blocks concurrent retries. */
  public synchronized boolean beginDeliveryAttempt(UUID transactionId, String reason) {
    Objects.requireNonNull(transactionId, "transactionId");
    if (reason == null || reason.isBlank()) {
      throw new IllegalArgumentException("reason must not be blank");
    }
    PendingRefund refund = pending.get(transactionId);
    if (refund == null || refund.manualReview() || activeDeliveryAttempts.contains(transactionId))
      return false;
    pending.put(
        transactionId,
        new PendingRefund(
            refund.transactionId(),
            refund.accountId(),
            refund.amount(),
            refund.reason(),
            refund.attempts(),
            refund.nextAttemptAt(),
            reason,
            true,
            refund.owner()));
    try {
      persist();
    } catch (RuntimeException failure) {
      pending.put(transactionId, refund);
      throw failure;
    }
    activeDeliveryAttempts.add(transactionId);
    return true;
  }

  /** Releases the in-process delivery claim after the balance and ledger outcome are reconciled. */
  public synchronized void finishDeliveryAttempt(UUID transactionId) {
    activeDeliveryAttempts.remove(Objects.requireNonNull(transactionId, "transactionId"));
  }

  public synchronized boolean isDeliveryAttemptActive(UUID transactionId) {
    return activeDeliveryAttempts.contains(Objects.requireNonNull(transactionId, "transactionId"));
  }

  public List<PendingRefund> due(Instant now) {
    Objects.requireNonNull(now, "now");
    return snapshot().stream()
        .filter(item -> !item.manualReview())
        .filter(item -> !item.nextAttemptAt().isAfter(now))
        .sorted(Comparator.comparing(PendingRefund::nextAttemptAt))
        .toList();
  }

  /**
   * Returns only entries owned by a subsystem, optionally recognizing that subsystem's legacy
   * records.
   */
  public List<PendingRefund> due(Instant now, RefundOwner owner, boolean force) {
    return due(now, owner, ignored -> false, force);
  }

  public List<PendingRefund> due(
      Instant now,
      RefundOwner owner,
      java.util.function.Predicate<PendingRefund> legacyMatcher,
      boolean force) {
    Objects.requireNonNull(now, "now");
    Objects.requireNonNull(owner, "owner");
    Objects.requireNonNull(legacyMatcher, "legacyMatcher");
    return snapshot().stream()
        .filter(item -> !item.manualReview())
        .filter(item -> force || !item.nextAttemptAt().isAfter(now))
        .filter(
            item ->
                item.owner() == owner
                    || (item.owner() == RefundOwner.UNKNOWN && legacyMatcher.test(item)))
        .sorted(Comparator.comparing(PendingRefund::nextAttemptAt))
        .toList();
  }

  public List<PendingRefund> due(Instant now, RefundOwner owner) {
    return due(now, owner, ignored -> false);
  }

  public List<PendingRefund> due(
      Instant now, RefundOwner owner, java.util.function.Predicate<PendingRefund> legacyMatcher) {
    return due(now, owner, legacyMatcher, false);
  }

  /** Waits for any in-flight write to finish or roll back before copying the retry state. */
  public synchronized List<PendingRefund> snapshot() {
    return new ArrayList<>(pending.values());
  }

  /** Summarizes retry pressure without exposing mutable ledger state. */
  public synchronized RefundLedgerSummary summarize(Instant now) {
    Objects.requireNonNull(now, "now");
    EnumMap<RefundOwner, Integer> ownerCounts = new EnumMap<>(RefundOwner.class);
    int dueEntries = 0;
    int manualReviewEntries = 0;
    int unknownOwnerEntries = 0;
    Instant oldestNextAttemptAt = null;
    for (PendingRefund refund : pending.values()) {
      ownerCounts.merge(refund.owner(), 1, Integer::sum);
      if (refund.owner() == RefundOwner.UNKNOWN) unknownOwnerEntries++;
      if (refund.manualReview()) {
        manualReviewEntries++;
      } else if (!refund.nextAttemptAt().isAfter(now)) {
        dueEntries++;
      }
      if (oldestNextAttemptAt == null || refund.nextAttemptAt().isBefore(oldestNextAttemptAt)) {
        oldestNextAttemptAt = refund.nextAttemptAt();
      }
    }
    return new RefundLedgerSummary(
        pending.size(),
        dueEntries,
        manualReviewEntries,
        unknownOwnerEntries,
        ownerCounts,
        Optional.ofNullable(oldestNextAttemptAt));
  }

  private void load() {
    if (!Files.exists(file)) return;
    Properties properties = new Properties();
    try (InputStream input = Files.newInputStream(file)) {
      properties.load(new InputStreamReader(input, StandardCharsets.UTF_8));
      for (String key : properties.stringPropertyNames()) {
        if (!key.startsWith("refund.") || !key.endsWith(".account")) continue;
        String id = key.substring("refund.".length(), key.length() - ".account".length());
        try {
          UUID transactionId = UUID.fromString(id);
          UUID accountId = UUID.fromString(properties.getProperty(key));
          BigDecimal amount = new BigDecimal(properties.getProperty("refund." + id + ".amount"));
          String reason = properties.getProperty("refund." + id + ".reason", "unspecified");
          int attempts =
              Integer.parseInt(properties.getProperty("refund." + id + ".attempts", "0"));
          Instant next = Instant.parse(properties.getProperty("refund." + id + ".next"));
          String error = properties.getProperty("refund." + id + ".error");
          boolean manualReview =
              Boolean.parseBoolean(properties.getProperty("refund." + id + ".manual", "false"));
          RefundOwner owner = parseOwner(properties.getProperty("refund." + id + ".owner"));
          pending.put(
              transactionId,
              new PendingRefund(
                  transactionId,
                  accountId,
                  amount,
                  reason,
                  attempts,
                  next,
                  error,
                  manualReview,
                  owner));
        } catch (RuntimeException invalid) {
          logger.log(Level.WARNING, "Skipping invalid refund ledger entry " + id, invalid);
        }
      }
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to load refund ledger " + file, exception);
    }
  }

  private void persist() {
    try {
      Files.createDirectories(file.toAbsolutePath().getParent());
      Properties properties = new Properties();
      properties.setProperty("version", VERSION);
      for (PendingRefund refund : pending.values()) {
        String prefix = "refund." + refund.transactionId();
        properties.setProperty(prefix + ".account", refund.accountId().toString());
        properties.setProperty(prefix + ".amount", refund.amount().toPlainString());
        properties.setProperty(prefix + ".reason", refund.reason());
        properties.setProperty(prefix + ".attempts", Integer.toString(refund.attempts()));
        properties.setProperty(prefix + ".next", refund.nextAttemptAt().toString());
        if (refund.lastError() != null)
          properties.setProperty(prefix + ".error", refund.lastError());
        if (refund.manualReview()) properties.setProperty(prefix + ".manual", "true");
        properties.setProperty(prefix + ".owner", refund.owner().name());
      }
      Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
      try (OutputStream output =
          Files.newOutputStream(
              temporary,
              StandardOpenOption.CREATE,
              StandardOpenOption.TRUNCATE_EXISTING,
              StandardOpenOption.WRITE)) {
        properties.store(
            new OutputStreamWriter(output, StandardCharsets.UTF_8), "STARCORE refund retry ledger");
      }
      try {
        Files.move(
            temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
        Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
      }
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to persist refund ledger " + file, exception);
    }
  }

  private static RefundOwner parseOwner(String value) {
    if (value == null || value.isBlank()) return RefundOwner.UNKNOWN;
    try {
      return RefundOwner.valueOf(value);
    } catch (IllegalArgumentException ignored) {
      return RefundOwner.UNKNOWN;
    }
  }

  public static Instant nextRetry(Instant now, int attempts) {
    long seconds = Math.min(3600L, 1L << Math.min(attempts, 12));
    return now.plus(Duration.ofSeconds(seconds));
  }
}
