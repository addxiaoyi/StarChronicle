package dev.starcore.starcore.foundation.economy.transaction;

import java.time.Instant;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Point-in-time health counters for the transaction fabric. */
public record TransactionSummary(
    int totalEntries,
    int activeEntries,
    int manualReviewEntries,
    int failedEntries,
    Map<RefundOwner, Integer> ownerCounts,
    Map<TransactionType, Integer> typeCounts,
    Optional<Instant> oldestUpdatedAt) {
  public TransactionSummary {
    if (totalEntries < 0 || activeEntries < 0 || manualReviewEntries < 0 || failedEntries < 0) {
      throw new IllegalArgumentException("transaction counters must be non-negative");
    }
    if (activeEntries > totalEntries
        || manualReviewEntries > totalEntries
        || failedEntries > totalEntries) {
      throw new IllegalArgumentException("transaction counters exceed total entries");
    }
    Objects.requireNonNull(ownerCounts, "ownerCounts");
    Objects.requireNonNull(typeCounts, "typeCounts");
    Objects.requireNonNull(oldestUpdatedAt, "oldestUpdatedAt");
    EnumMap<RefundOwner, Integer> owners = new EnumMap<>(RefundOwner.class);
    for (RefundOwner owner : RefundOwner.values())
      owners.put(owner, Math.max(0, ownerCounts.getOrDefault(owner, 0)));
    EnumMap<TransactionType, Integer> types = new EnumMap<>(TransactionType.class);
    for (TransactionType type : TransactionType.values())
      types.put(type, Math.max(0, typeCounts.getOrDefault(type, 0)));
    ownerCounts = Collections.unmodifiableMap(owners);
    typeCounts = Collections.unmodifiableMap(types);
  }

  public int ownerCount(RefundOwner owner) {
    return ownerCounts.getOrDefault(Objects.requireNonNull(owner, "owner"), 0);
  }

  public int typeCount(TransactionType type) {
    return typeCounts.getOrDefault(Objects.requireNonNull(type, "type"), 0);
  }
}
