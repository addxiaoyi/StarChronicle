package dev.starcore.starcore.foundation.economy.transaction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Joins durable transaction transitions with the current refund retry ledger.
 *
 * <p>The service is read-only: replay is evidence inspection, never money movement.
 */
public final class EvidenceReplayService {
  private final TransactionFabric transactionFabric;
  private final Optional<RefundLedger> refundLedger;
  private final List<EvidenceReplayProvider> providers = new ArrayList<>();

  public EvidenceReplayService(TransactionFabric transactionFabric) {
    this(transactionFabric, null);
  }

  public EvidenceReplayService(TransactionFabric transactionFabric, RefundLedger refundLedger) {
    this.transactionFabric = Objects.requireNonNull(transactionFabric, "transactionFabric");
    this.refundLedger = Optional.ofNullable(refundLedger);
  }

  public synchronized void registerProvider(EvidenceReplayProvider provider) {
    providers.add(Objects.requireNonNull(provider, "provider"));
  }

  public Optional<EvidenceReplaySnapshot> find(UUID transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    return transactionFabric.find(transactionId).map(record -> join(record, transactionId));
  }

  /** Returns provider evidence without mutating transaction or recovery state. */
  public synchronized List<EvidenceReplayEvent> sourceEvidence(UUID transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    TransactionRecord record =
        transactionFabric
            .find(transactionId)
            .orElseThrow(() -> new IllegalArgumentException("Unknown transaction: " + transactionId));
    return providerEvidence(record, transactionId);
  }

  private EvidenceReplaySnapshot join(TransactionRecord record, UUID transactionId) {
    if (refundLedger.isEmpty()) {
      return new EvidenceReplaySnapshot(
          record, mergedTimeline(record, transactionId), Optional.empty(), EvidenceReplayCorrelation.NONE);
    }

    for (PendingRefund refund : refundLedger.get().snapshot()) {
      if (refund.transactionId().equals(transactionId)) {
        return new EvidenceReplaySnapshot(
            record, mergedTimeline(record, transactionId), Optional.of(refund), EvidenceReplayCorrelation.TRANSACTION_ID);
      }
    }
    for (PendingRefund refund : refundLedger.get().snapshot()) {
      if (refund.reason().equals(record.reason())) {
        return new EvidenceReplaySnapshot(
            record, mergedTimeline(record, transactionId), Optional.of(refund), EvidenceReplayCorrelation.REASON);
      }
    }
    return new EvidenceReplaySnapshot(
        record, mergedTimeline(record, transactionId), Optional.empty(), EvidenceReplayCorrelation.NONE);
  }

  private synchronized List<TransactionEvent> mergedTimeline(
      TransactionRecord record, UUID transactionId) {
    List<TransactionEvent> timeline = new ArrayList<>(record.events());
    for (EvidenceReplayEvent evidence : providerEvidence(record, transactionId)) {
      timeline.add(
          new TransactionEvent(
              evidence.at(), toState(evidence.state()), evidence.source() + ": " + evidence.message()));
    }
    timeline.sort(Comparator.comparing(TransactionEvent::at));
    return List.copyOf(timeline);
  }

  private List<EvidenceReplayEvent> providerEvidence(
      TransactionRecord record, UUID transactionId) {
    List<EvidenceReplayEvent> evidence = new ArrayList<>();
    for (EvidenceReplayProvider provider : providers) {
      for (EvidenceReplayEvent item : provider.replay(transactionId, record)) {
        evidence.add(item);
      }
    }
    return List.copyOf(evidence);
  }

  private static EconomyTransactionState toState(String stateText) {
    try {
      return EconomyTransactionState.valueOf(stateText);
    } catch (IllegalArgumentException ignored) {
      return EconomyTransactionState.MANUAL_REVIEW;
    }
  }
}
