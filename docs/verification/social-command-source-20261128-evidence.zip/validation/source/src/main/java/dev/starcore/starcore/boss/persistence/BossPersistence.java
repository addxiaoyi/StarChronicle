package dev.starcore.starcore.boss.persistence;

import dev.starcore.starcore.boss.BossDefinition;
import dev.starcore.starcore.boss.BossInstance;
import dev.starcore.starcore.boss.BossStatus;
import dev.starcore.starcore.boss.BossType;
import dev.starcore.starcore.persistence.DataStore;
import dev.starcore.starcore.persistence.StorageKey;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Boss系统持久化存储 处理Boss定义和实例的保存与加载 */
public class BossPersistence {

  private final DataStore dataStore;
  private final Map<String, BossDefinition> definitionCache = new ConcurrentHashMap<>();
  private final Map<String, BossInstance> instanceCache = new ConcurrentHashMap<>();

  public BossPersistence(DataStore dataStore) {
    this.dataStore = dataStore;
  }

  /** 保存Boss定义 */
  public void saveDefinition(BossDefinition definition) {
    definitionCache.put(definition.bossId(), definition);
    dataStore.save(StorageKey.BOSS_DEFINITIONS, definition);
  }

  /** 批量保存Boss定义 */
  public void saveAllDefinitions(Collection<BossDefinition> definitions) {
    definitions.forEach(d -> definitionCache.put(d.bossId(), d));
    dataStore.saveAll(StorageKey.BOSS_DEFINITIONS, new ArrayList<>(definitions));
  }

  /** 加载Boss定义 */
  public Optional<BossDefinition> loadDefinition(String bossId) {
    // 先检查缓存
    BossDefinition cached = definitionCache.get(bossId);
    if (cached != null) {
      return Optional.of(cached);
    }
    // 缓存未命中，加载所有定义并填充缓存
    loadAllDefinitions();
    return Optional.ofNullable(definitionCache.get(bossId));
  }

  /** 加载所有Boss定义 */
  public List<BossDefinition> loadAllDefinitions() {
    List<BossDefinition> definitions =
        dataStore.loadAll(StorageKey.BOSS_DEFINITIONS, BossDefinition.class);
    definitions.forEach(d -> definitionCache.put(d.bossId(), d));
    return definitions;
  }

  /** 保存Boss实例 */
  public void saveInstance(BossInstance instance) {
    instanceCache.put(instance.instanceId(), instance);
    dataStore.save(StorageKey.BOSS_INSTANCES, instance);
  }

  /** 批量保存Boss实例 */
  public void saveAllInstances(Collection<BossInstance> instances) {
    instances.forEach(i -> instanceCache.put(i.instanceId(), i));
    dataStore.saveAll(StorageKey.BOSS_INSTANCES, new ArrayList<>(instances));
  }

  /** 加载Boss实例 */
  public Optional<BossInstance> loadInstance(String instanceId) {
    // 先检查缓存
    BossInstance cached = instanceCache.get(instanceId);
    if (cached != null) {
      return Optional.of(cached);
    }
    // 缓存未命中，加载所有实例并填充缓存
    loadAllInstances();
    return Optional.ofNullable(instanceCache.get(instanceId));
  }

  /** 加载所有Boss实例 */
  public List<BossInstance> loadAllInstances() {
    List<BossInstance> instances = dataStore.loadAll(StorageKey.BOSS_INSTANCES, BossInstance.class);
    instances.forEach(i -> instanceCache.put(i.instanceId(), i));
    return instances;
  }

  /** 删除Boss定义 */
  public void deleteDefinition(String bossId) {
    definitionCache.remove(bossId);
    dataStore.delete(StorageKey.BOSS_DEFINITIONS, bossId);
  }

  /** 删除Boss实例 */
  public void deleteInstance(String instanceId) {
    instanceCache.remove(instanceId);
    dataStore.delete(StorageKey.BOSS_INSTANCES, instanceId);
  }

  /** 清空缓存 */
  public void clearCache() {
    definitionCache.clear();
    instanceCache.clear();
  }

  /** 获取活跃的Boss实例 */
  public List<BossInstance> getActiveInstances() {
    return loadAllInstances().stream()
        .filter(i -> i.status() == BossStatus.spawned || i.status() == BossStatus.in_progress)
        .toList();
  }

  /** 获取按类型分组的Boss定义 */
  public Map<BossType, List<BossDefinition>> getDefinitionsByType() {
    Map<BossType, List<BossDefinition>> result = new EnumMap<>(BossType.class);
    loadAllDefinitions()
        .forEach(
            definition ->
                result.computeIfAbsent(definition.type(), k -> new ArrayList<>()).add(definition));
    return result;
  }

  /** 获取按难度分组的Boss定义 */
  public Map<Integer, List<BossDefinition>> getDefinitionsByDifficulty() {
    Map<Integer, List<BossDefinition>> result = new HashMap<>();
    loadAllDefinitions()
        .forEach(
            definition ->
                result.computeIfAbsent(definition.level(), k -> new ArrayList<>()).add(definition));
    return result;
  }

  /** 获取按裂隙分组的Boss实例 */
  public Map<String, List<BossInstance>> getInstancesByRift() {
    Map<String, List<BossInstance>> result = new HashMap<>();
    loadAllInstances()
        .forEach(
            instance ->
                result
                    .computeIfAbsent(instance.riftInstanceId(), k -> new ArrayList<>())
                    .add(instance));
    return result;
  }
}
