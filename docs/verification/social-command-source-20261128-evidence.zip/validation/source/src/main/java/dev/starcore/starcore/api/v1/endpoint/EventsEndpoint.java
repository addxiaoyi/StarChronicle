package dev.starcore.starcore.api.v1.endpoint;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.PageRequest;
import dev.starcore.starcore.api.v1.PageResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.handler.BaseHttpHandler;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.event.NationEventRecord;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.NationId;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/** 事件 REST API 端点 */
public final class EventsEndpoint extends BaseHttpHandler {

  private final EventService eventService;
  private final NationService nationService;

  public EventsEndpoint(
      Gson gson,
      ApiAuthService authService,
      EventService eventService,
      NationService nationService) {
    this(gson, authService, eventService, nationService, RestApiConfig.CorsConfig.DEFAULT, false);
  }

  public EventsEndpoint(
      Gson gson,
      ApiAuthService authService,
      EventService eventService,
      NationService nationService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth) {
    super(
        gson, authService, corsConfig, requiresAuth, ApiAuthService.ApiKeyPermission.READ_NATIONS);
    this.eventService = eventService;
    this.nationService = nationService;
  }

  @Override
  protected void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    String path = getPath(exchange);

    if (path.equals("/api/v1/events")) {
      if (isMethod(exchange, "GET")) {
        handleListEvents(exchange, authContext);
      } else {
        sendMethodNotAllowed(exchange);
      }
    } else if (path.startsWith("/api/v1/events/")) {
      String idPart = path.substring("/api/v1/events/".length());
      if (idPart.isEmpty() || idPart.endsWith("/")) {
        sendNotFound(exchange, "Event");
      } else {
        handleEventById(exchange, authContext, idPart.split("/")[0]);
      }
    } else {
      sendNotFound(exchange, "Endpoint");
    }
  }

  private void handleListEvents(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    Map<String, String> params = parseQueryParams(exchange);
    PageRequest pageRequest = PageRequest.of(params.get("page"), params.get("pageSize"));

    // 可以接受 nationId 参数来过滤特定国家的事件
    String nationIdParam = params.get("nationId");
    List<NationEventRecord> allEvents;

    if (nationIdParam != null && !nationIdParam.isBlank() && nationService != null) {
      try {
        NationId nationId = NationId.fromString(nationIdParam);
        allEvents = eventService.eventsOf(nationId).stream().toList();
      } catch (IllegalArgumentException e) {
        sendError(exchange, 400, "INVALID_NATION_ID", "Invalid nation ID format");
        return;
      }
    } else {
      // 获取所有国家的事件
      if (nationService != null) {
        Map<NationId, List<NationEventRecord>> snapshot = new HashMap<>();
        // 注意：这里假设 EventService 有获取所有国家事件的方法
        // 如果没有，我们需要遍历所有国家
        allEvents =
            nationService.nations().stream()
                .flatMap(nation -> eventService.eventsOf(nation.id()).stream())
                .collect(Collectors.toList());
      } else {
        allEvents = Collections.emptyList();
      }
    }

    // 按时间倒序排列（最新的在前）
    List<NationEventRecord> sortedEvents =
        allEvents.stream()
            .sorted(Comparator.comparing(NationEventRecord::occurredAt).reversed())
            .collect(Collectors.toList());

    long total = sortedEvents.size();

    int fromIndex = (int) Math.min(pageRequest.offset(), sortedEvents.size());
    int toIndex =
        (int) Math.min(pageRequest.offset() + pageRequest.pageSize(), sortedEvents.size());
    List<NationEventRecord> pageEvents =
        fromIndex < toIndex ? sortedEvents.subList(fromIndex, toIndex) : List.of();

    // 转换为 DTO（这里简单地返回记录对象，或者可以创建专门的 DTO）
    List<Map<String, Object>> dtos =
        pageEvents.stream()
            .map(
                event -> {
                  Map<String, Object> map = new HashMap<>();
                  map.put("id", event.id().toString());
                  map.put("nationId", event.nationId().toString());
                  map.put("nationName", getNationName(event.nationId()));
                  map.put("occurredAt", event.occurredAt().toEpochMilli());
                  map.put("type", event.type());
                  map.put("message", event.message());
                  map.put("context", event.context());
                  return map;
                })
            .collect(Collectors.toList());

    PageResponse<Map<String, Object>> response =
        PageResponse.of(dtos, pageRequest.page(), pageRequest.pageSize(), total);

    sendSuccess(
        exchange,
        response,
        ApiResponse.ResponseMeta.of(
            pageRequest.page(), pageRequest.pageSize(), total, generateRequestId()));
  }

  private void handleEventById(HttpExchange exchange, ApiAuthContext authContext, String id)
      throws IOException {
    if (!isMethod(exchange, "GET")) {
      sendMethodNotAllowed(exchange);
      return;
    }

    UUID uuid;
    try {
      uuid = UUID.fromString(id);
    } catch (IllegalArgumentException e) {
      sendError(exchange, 400, "INVALID_ID", "Invalid event ID format");
      return;
    }

    // 查找事件（需要遍历所有国家的事件，因为我们没有按ID查找的方法）
    Optional<NationEventRecord> eventOpt = findEventById(uuid);

    if (eventOpt.isEmpty()) {
      sendNotFound(exchange, "Event");
      return;
    }

    NationEventRecord event = eventOpt.get();
    Map<String, Object> dto = new HashMap<>();
    dto.put("id", event.id().toString());
    dto.put("nationId", event.nationId().toString());
    dto.put("nationName", getNationName(event.nationId()));
    dto.put("occurredAt", event.occurredAt().toEpochMilli());
    dto.put("type", event.type());
    dto.put("message", event.message());
    dto.put("context", event.context());

    sendSuccess(exchange, dto);
  }

  private Optional<NationEventRecord> findEventById(UUID eventId) {
    if (nationService == null) {
      return Optional.empty();
    }

    return nationService.nations().stream()
        .flatMap(nation -> eventService.eventsOf(nation.id()).stream())
        .filter(event -> event.id().equals(eventId))
        .findFirst();
  }

  private String getNationName(NationId nationId) {
    if (nationService == null || nationId == null) {
      return "Unknown";
    }
    return nationService.nationById(nationId).map(nation -> nation.name()).orElse("Unknown");
  }
}
