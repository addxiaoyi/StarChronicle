package dev.starcore.starcore.foundation.economy.transaction;

import java.time.Instant;
import java.util.Objects;

/** Read-only domain or audit evidence joined to a transaction replay. */
public record EvidenceReplayEvent(
    String source, Instant at, String state, String message) {
  public EvidenceReplayEvent {
    if (source == null || source.isBlank()) throw new IllegalArgumentException("source must not be blank");
    at = Objects.requireNonNull(at, "at");
    if (state == null || state.isBlank()) throw new IllegalArgumentException("state must not be blank");
    message = message == null ? "" : message;
  }
}
