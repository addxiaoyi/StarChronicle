package dev.starcore.starcore.achievement;

import java.time.Duration;
import java.util.*;
import java.util.Optional;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** 成就服务接口 */
public interface AchievementService {

  /** 注册成就 */
  void registerAchievement(Achievement achievement);

  /** 批量注册成就 */
  void registerAchievements(Achievement... achievements);

  /** 获取成就 */
  Optional<Achievement> getAchievement(NamespacedKey key);

  /** 获取所有成就 */
  Collection<Achievement> getAllAchievements();

  /** 按分类获取成就 */
  Collection<Achievement> getAchievementsByCategory(AchievementCategory category);

  /** 检查玩家是否已完成成就 */
  boolean hasAchievement(UUID playerId, NamespacedKey key);

  /** 给予玩家成就 */
  boolean grantAchievement(Player player, NamespacedKey key);

  /** 获取玩家已完成的成就 */
  Set<NamespacedKey> getPlayerAchievements(UUID playerId);

  /** 获取玩家成就进度 */
  int getPlayerProgress(UUID playerId);

  /** 获取总成就数量 */
  int getTotalAchievements();

  /** 加载玩家数据 */
  void loadPlayerData(UUID playerId, Set<NamespacedKey> achievements);

  /** 保存玩家数据 */
  Set<NamespacedKey> savePlayerData(UUID playerId);

  /** 获取玩家进度追踪器 */
  AchievementProgress getOrCreateProgress(UUID playerId);

  /** 增加触发器计数 */
  void incrementTrigger(UUID playerId, AchievementTrigger.TriggerType type, int amount);

  /** 默认实现：显示成就通知 */
  default void displayAchievement(Player player, Achievement achievement) {
    Plugin plugin = getPlugin();

    // 1. Toast 弹窗提示（原版样式）
    if (achievement.isShowToast()) {
      sendToast(player, achievement);
    }

    // 2. 聊天栏提示
    if (achievement.isAnnounceToChat()) {
      announceToChat(player, achievement);
    } else {
      sendPrivateMessage(player, achievement);
    }

    // 3. 音效
    playSound(player, achievement);

    // 4. Title显示（大标题）
    sendTitle(player, achievement);
  }

  /** 获取插件实例 */
  Plugin getPlugin();

  /** 发送Toast弹窗 */
  default void sendToast(Player player, Achievement achievement) {
    String frameColor = achievement.getFrameType().getColor();

    Component toastTitle =
        Component.text()
            .append(Component.text("[成就达成] ", NamedTextColor.YELLOW, TextDecoration.BOLD))
            .append(achievement.getTitle())
            .build();

    player.sendActionBar(toastTitle);
    player.sendMessage(Component.text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", NamedTextColor.GOLD));
    player.sendMessage(Component.empty());

    Component achievementText =
        Component.text()
            .append(Component.text("  * ", NamedTextColor.GOLD, TextDecoration.BOLD))
            .append(Component.text("成就达成！", NamedTextColor.YELLOW, TextDecoration.BOLD))
            .append(Component.text(" *", NamedTextColor.GOLD, TextDecoration.BOLD))
            .build();

    player.sendMessage(achievementText);
    player.sendMessage(Component.empty());

    Component titleLine =
        Component.text()
            .append(Component.text("  【", NamedTextColor.GRAY))
            .append(achievement.getTitle().color(getFrameColor(achievement.getFrameType())))
            .append(Component.text("】", NamedTextColor.GRAY))
            .build();

    player.sendMessage(titleLine);

    Component descLine =
        Component.text()
            .append(Component.text("  ", NamedTextColor.GRAY))
            .append(achievement.getDescription().color(NamedTextColor.WHITE))
            .build();

    player.sendMessage(descLine);
    player.sendMessage(Component.empty());
    player.sendMessage(Component.text("▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬", NamedTextColor.GOLD));
  }

  /** 获取框架颜色 */
  default NamedTextColor getFrameColor(Achievement.FrameType frameType) {
    return switch (frameType) {
      case TASK -> NamedTextColor.GREEN;
      case CHALLENGE -> NamedTextColor.LIGHT_PURPLE;
      case GOAL -> NamedTextColor.YELLOW;
    };
  }

  /** 全服广播 */
  default void announceToChat(Player player, Achievement achievement) {
    Component message =
        Component.text()
            .append(Component.text(player.getName(), NamedTextColor.AQUA))
            .append(Component.text(" 完成了成就 ", NamedTextColor.WHITE))
            .append(Component.text("[", NamedTextColor.GRAY))
            .append(achievement.getTitle().color(getFrameColor(achievement.getFrameType())))
            .append(Component.text("]", NamedTextColor.GRAY))
            .build();

    Bukkit.broadcast(message);
  }

  /** 私聊消息 */
  default void sendPrivateMessage(Player player, Achievement achievement) {
    player.sendMessage(
        Component.text()
            .append(Component.text("* ", NamedTextColor.GOLD))
            .append(Component.text("你完成了成就：", NamedTextColor.YELLOW))
            .append(achievement.getTitle().color(getFrameColor(achievement.getFrameType())))
            .build());
  }

  /** 播放音效 */
  default void playSound(Player player, Achievement achievement) {
    Sound sound =
        switch (achievement.getFrameType()) {
          case TASK -> Sound.ENTITY_PLAYER_LEVELUP;
          case CHALLENGE -> Sound.UI_TOAST_CHALLENGE_COMPLETE;
          case GOAL -> Sound.ENTITY_ENDER_DRAGON_GROWL;
        };

    player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
  }

  /** 发送大标题 */
  default void sendTitle(Player player, Achievement achievement) {
    Component title =
        Component.text()
            .append(Component.text("* ", NamedTextColor.GOLD))
            .append(Component.text("成就达成", NamedTextColor.YELLOW, TextDecoration.BOLD))
            .append(Component.text(" *", NamedTextColor.GOLD))
            .build();

    Component subtitle = achievement.getTitle().color(getFrameColor(achievement.getFrameType()));

    player.showTitle(
        Title.title(
            title,
            subtitle,
            Title.Times.times(
                Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(1000))));
  }

  /** 给予奖励 */
  /** Validates reward definitions before achievement completion is persisted. */
  default boolean rewardsAreValid(Achievement achievement) {
    for (String reward : achievement.getRewards()) {
      if (reward == null || reward.isBlank()) return false;
      String[] parts = reward.split(":", 2);
      if (parts.length < 2) return false;
      try {
        switch (parts[0].toLowerCase()) {
          case "money", "coins" -> {
            double amount = Double.parseDouble(parts[1]);
            if (!Double.isFinite(amount) || amount <= 0) return false;
          }
          case "item" -> {
            String[] item = parts[1].split(":");
            if (item.length < 2) return false;
            org.bukkit.Material.valueOf(item[0].toUpperCase());
            if (Integer.parseInt(item[1]) <= 0) return false;
          }
          case "exp", "experience" -> {
            if (Integer.parseInt(parts[1]) <= 0) return false;
          }
          case "command", "cmd" -> {
            if (parts[1].isBlank()) return false;
          }
          default -> {
            return false;
          }
        }
      } catch (RuntimeException invalidReward) {
        return false;
      }
    }
    return true;
  }

  default boolean giveRewards(Player player, Achievement achievement) {
    AchievementProgress progress = getOrCreateProgress(player.getUniqueId());
    if (achievement.getExperience() > 0 && !progress.isRewardDelivered(achievement.getKey(), -1)) {
      player.giveExp(achievement.getExperience());
      progress.markRewardDelivered(achievement.getKey(), -1);
    }
    int rewardIndex = 0;
    for (String reward : achievement.getRewards()) {
      if (progress.isRewardDelivered(achievement.getKey(), rewardIndex)) {
        rewardIndex++;
        continue;
      }
      if (!parseAndGiveReward(player, reward)) {
        return false;
      }
      progress.markRewardDelivered(achievement.getKey(), rewardIndex++);
    }
    return true;
  }

  default boolean parseAndGiveReward(Player player, String reward) {
    if (reward == null || reward.isBlank()) return false;
    String[] parts = reward.split(":", 2);
    if (parts.length < 2) return false;
    try {
      return switch (parts[0].toLowerCase()) {
        case "money", "coins" -> giveMoney(player, parts[1]);
        case "item" -> giveItem(player, parts[1]);
        case "exp", "experience" -> giveExperience(player, parts[1]);
        case "command", "cmd" -> executeCommand(player, parts[1]);
        default -> false;
      };
    } catch (RuntimeException failure) {
      Bukkit.getLogger()
          .warning("Failed to give achievement reward '" + reward + "': " + failure.getMessage());
      return false;
    }
  }

  default boolean giveMoney(Player player, String amountStr) {
    try {
      double amount = Double.parseDouble(amountStr);
      if (!Double.isFinite(amount) || amount <= 0) return false;
      if (Bukkit.getPluginManager().isPluginEnabled("Vault")
          && AchievementVaultBridge.deposit(player, amount)) {
        player.sendMessage(Component.text("+ " + amount + " ���", NamedTextColor.GOLD));
        return true;
      }
      return useInternalEconomy(player, amount);
    } catch (RuntimeException failure) {
      player.sendMessage(Component.text("��Ч�Ľ��: " + amountStr, NamedTextColor.RED));
      return false;
    }
  }

  default boolean useInternalEconomy(Player player, double amount) {
    dev.starcore.starcore.foundation.economy.EconomyService economy = getInternalEconomy();
    if (economy == null
        || !economy.deposit(player.getUniqueId(), java.math.BigDecimal.valueOf(amount))) {
      return false;
    }
    player.sendMessage(Component.text("+ " + amount + " ���", NamedTextColor.GOLD));
    return true;
  }

  default dev.starcore.starcore.foundation.economy.EconomyService getInternalEconomy() {
    return null;
  }

  default boolean giveItem(Player player, String itemData) {
    String[] parts = itemData.split(":");
    if (parts.length < 2) return false;
    try {
      org.bukkit.Material material = org.bukkit.Material.valueOf(parts[0].toUpperCase());
      int amount = Integer.parseInt(parts[1]);
      if (material.isAir() || amount <= 0) return false;
      org.bukkit.inventory.ItemStack item = new org.bukkit.inventory.ItemStack(material, amount);
      if (parts.length >= 4) {
        for (int i = 2; i + 1 < parts.length; i += 2) {
          org.bukkit.enchantments.Enchantment enchant =
              org.bukkit.enchantments.Enchantment.getByName(parts[i].toUpperCase());
          if (enchant == null) return false;
          int level = Integer.parseInt(parts[i + 1]);
          if (level <= 0) return false;
          item.addUnsafeEnchantment(enchant, Math.min(level, enchant.getMaxLevel()));
        }
      }
      for (org.bukkit.inventory.ItemStack left : player.getInventory().addItem(item).values()) {
        player.getWorld().dropItemNaturally(player.getLocation(), left);
      }
      player.sendMessage(
          Component.text("��� " + amount + "x ", NamedTextColor.GREEN)
              .append(Component.translatable(material.translationKey())));
      return true;
    } catch (RuntimeException failure) {
      player.sendMessage(Component.text("��Ч����Ʒ: " + itemData, NamedTextColor.RED));
      return false;
    }
  }

  default boolean giveExperience(Player player, String expStr) {
    try {
      int exp = Integer.parseInt(expStr);
      if (exp <= 0) return false;
      player.giveExp(exp);
      player.sendMessage(Component.text("+ " + exp + " ����", NamedTextColor.AQUA));
      return true;
    } catch (RuntimeException failure) {
      return false;
    }
  }

  default boolean executeCommand(Player player, String command) {
    if (command == null || command.isBlank()) return false;
    String finalCommand =
        command
            .replace("{player}", player.getName())
            .replace("{uuid}", player.getUniqueId().toString());
    String baseCommand = finalCommand.split("\\s+")[0].toLowerCase();
    if (baseCommand.startsWith("minecraft:")) baseCommand = baseCommand.substring(10);
    Set<String> allowed =
        Set.of(
            "tp",
            "teleport",
            "effect",
            "particle",
            "playsound",
            "title",
            "tellraw",
            "clear",
            "advancement",
            "experience",
            "xp",
            "broadcast",
            "say");
    if (!allowed.contains(baseCommand)) return false;
    return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommand);
  }
}
