package dev.starcore.starcore.cooking;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.plugin.Plugin;

/** 烹饪 GUI 点击监听 */
public final class CookingGuiListener implements Listener {

  private final CookingManager cookingManager;

  public CookingGuiListener(Plugin plugin, CookingManager cookingManager) {
    this.cookingManager = cookingManager;
  }

  /** 打开烹饪台面板 */
  public void open(Player player) {
    new CookingGui(player, cookingManager).open();
    dev.starcore.starcore.module.gameplay.ActivityBridge.record(
        player.getUniqueId(), "cook_recipe");
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof CookingGui) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getInventory().getHolder() instanceof CookingGui gui)) {
      return;
    }
    event.setCancelled(true);
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    if (event.getClickedInventory() != event.getInventory()) {
      return;
    }
    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.0f);
    gui.handleClick(event.getSlot());
  }
}
