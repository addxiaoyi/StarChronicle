package dev.starcore.starcore.balance;

import dev.starcore.starcore.core.module.ModuleDescriptor;
import dev.starcore.starcore.core.module.ModuleStatus;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class BalanceHealthService {
  private static final BigDecimal FIVE = BigDecimal.valueOf(5L);
  private static final BigDecimal TEN = BigDecimal.TEN;

  public BalanceHealthReport analyze(
      BalanceSnapshot snapshot, Collection<ModuleDescriptor> modules) {
    List<BalanceFinding> findings = new ArrayList<>();
    analyzeModules(snapshot, modules, findings);
    analyzeResourceMinting(snapshot, findings);
    analyzeTerritoryScale(snapshot, findings);
    analyzeAutomaticIncome(snapshot, findings);
    analyzeNationScale(snapshot, findings);
    findings.sort(
        Comparator.comparingInt((BalanceFinding finding) -> severityRank(finding.severity()))
            .reversed()
            .thenComparing(BalanceFinding::code));
    return new BalanceHealthReport(snapshot, findings);
  }

  private void analyzeModules(
      BalanceSnapshot snapshot,
      Collection<ModuleDescriptor> modules,
      List<BalanceFinding> findings) {
    if (snapshot.failedModules() > 0) {
      String failed =
          modules.stream()
              .filter(module -> module.status() == ModuleStatus.FAILED)
              .map(module -> module.metadata().id())
              .sorted()
              .collect(Collectors.joining(", "));
      findings.add(
          new BalanceFinding(
              "MODULE_FAILURES",
              BalanceSeverity.HIGH,
              "存在 " + snapshot.failedModules() + " 个失败模块: " + failed,
              "先修复失败原因，再进行数值平衡；失败模块会让跨模块收益和成本失真。"));
    }

    if (snapshot.enabledModules() >= 60) {
      findings.add(
          new BalanceFinding(
              "MODULE_DENSITY_HIGH",
              BalanceSeverity.HIGH,
              "当前启用 " + snapshot.enabledModules() + " 个模块，功能密度过高。",
              "为生产服建立 lite/standard/grand-strategy 预设，并按服务器定位关闭非核心模块。"));
    } else if (snapshot.enabledModules() >= 35) {
      findings.add(
          new BalanceFinding(
              "MODULE_DENSITY_ELEVATED",
              BalanceSeverity.WARNING,
              "当前启用 " + snapshot.enabledModules() + " 个模块，跨系统叠加较复杂。",
              "重点审查经济、科技、政策、繁荣度和活动奖励是否重复提供同类增益。"));
    }

    Map<String, ModuleDescriptor> byId =
        modules.stream()
            .collect(
                Collectors.toMap(
                    module -> module.metadata().id(),
                    Function.identity(),
                    (first, ignored) -> first));
    for (ModuleDescriptor module : modules) {
      if (module.status() != ModuleStatus.ENABLED) {
        continue;
      }
      for (String dependency : module.metadata().dependencies()) {
        ModuleDescriptor required = byId.get(dependency);
        if (required == null || required.status() != ModuleStatus.ENABLED) {
          findings.add(
              new BalanceFinding(
                  "MODULE_DEPENDENCY_" + module.metadata().id().toUpperCase(),
                  BalanceSeverity.HIGH,
                  "模块 " + module.metadata().id() + " 的依赖 " + dependency + " 未启用。",
                  "修复模块依赖或关闭该模块，避免运行时出现部分功能可用、部分收益失效。"));
        }
      }
    }
  }

  private void analyzeResourceMinting(BalanceSnapshot snapshot, List<BalanceFinding> findings) {
    if (!snapshot.resourceTreasuryIncomeEnabled()) {
      return;
    }
    BigDecimal perDistrict = snapshot.resourceIncomePerDistrictCycle();
    if (snapshot.nationCreateCost().signum() > 0
        && perDistrict.compareTo(snapshot.nationCreateCost()) >= 0) {
      findings.add(
          new BalanceFinding(
              "RESOURCE_MINT_EXCEEDS_NATION_COST",
              BalanceSeverity.HIGH,
              "单个资源区单轮基准国库收入 "
                  + money(perDistrict)
                  + "，不低于建国费用 "
                  + money(snapshot.nationCreateCost())
                  + "。",
              "优先降低资源区直接现金，改为实物资源、交易税或需要物流成本的收入。"));
    } else if (snapshot.claimCost().signum() > 0
        && perDistrict.compareTo(snapshot.claimCost().multiply(FIVE)) >= 0) {
      findings.add(
          new BalanceFinding(
              "RESOURCE_MINT_EXCEEDS_CLAIM_COST",
              BalanceSeverity.WARNING,
              "单个资源区单轮理论收入可覆盖至少 5 次基础圈地费用。",
              "提高领地维护成本，或降低资源刷新现金，使扩张不能仅靠被动收入自我加速。"));
    }

    if (snapshot.hasUnlimitedResourceDistricts()) {
      findings.add(
          new BalanceFinding(
              "RESOURCE_DISTRICTS_UNLIMITED",
              BalanceSeverity.HIGH,
              "资源区数量没有硬上限。",
              "设置资源区硬上限，并让高级资源区承担仓储、运输和行政维护成本。"));
      return;
    }

    BigDecimal maximum = snapshot.maximumResourceIncomePerCycle();
    if (snapshot.nationCreateCost().signum() > 0
        && maximum.compareTo(snapshot.nationCreateCost().multiply(TEN)) >= 0) {
      findings.add(
          new BalanceFinding(
              "RESOURCE_NETWORK_MINT",
              BalanceSeverity.WARNING,
              "成熟国家资源区单轮基准总收入可达 " + money(maximum) + "。",
              "加入资源需求、市场价格衰减、仓储与运输维护费，限制资源区数量的线性印钞。"));
    }
  }

  private void analyzeTerritoryScale(BalanceSnapshot snapshot, List<BalanceFinding> findings) {
    if (snapshot.hasUnlimitedClaimCapacity()) {
      findings.add(
          new BalanceFinding(
              "TERRITORY_CAP_UNLIMITED",
              BalanceSeverity.HIGH,
              "国家领地区块没有数量上限。",
              "设置硬上限或启用等级容量，并加入维护费、行政容量和飞地限制。"));
      return;
    }

    long maximumClaims = snapshot.maximumClaimCapacity();
    if (snapshot.levelClaimLimitEnabled() && snapshot.hardMaxClaims() < 0 && maximumClaims >= 256) {
      findings.add(
          new BalanceFinding(
              "TERRITORY_CAP_UNBOUNDED",
              BalanceSeverity.HIGH,
              "等级公式允许最高约 " + maximumClaims + " 个领地区块，且未设置硬上限。",
              "设置硬上限并加入行政容量、远距维护费和飞地限制，防止大国永久滚雪球。"));
    } else if (maximumClaims >= 128) {
      findings.add(
          new BalanceFinding(
              "TERRITORY_CAP_LARGE",
              BalanceSeverity.WARNING,
              "单国最高领地容量为 " + maximumClaims + " 个区块。",
              "为 32/64/96 区块后的扩张设置递增维护费和治理效率惩罚。"));
    }
  }

  private void analyzeAutomaticIncome(BalanceSnapshot snapshot, List<BalanceFinding> findings) {
    if (snapshot.dailyIncomeAutoEnabled() && snapshot.resourceTreasuryIncomeEnabled()) {
      findings.add(
          new BalanceFinding(
              "STACKED_AUTOMATIC_INCOME",
              BalanceSeverity.WARNING,
              "国家日常收入与资源区国库收入同时自动运行。",
              "确保至少一个系统由真实玩家行为触发，并监控每日货币产生/销毁比。"));
    }
  }

  private void analyzeNationScale(BalanceSnapshot snapshot, List<BalanceFinding> findings) {
    if (snapshot.maxMembersPerNation() < 0) {
      findings.add(
          new BalanceFinding(
              "UNLIMITED_NATION_MEMBERS",
              BalanceSeverity.WARNING,
              "国家成员数量没有上限。",
              "设置成员上限或行政容量，避免成员、税收、资源与军力形成无边际递减的正反馈。"));
    } else if (snapshot.maxMembersPerNation() > 100) {
      findings.add(
          new BalanceFinding(
              "LARGE_NATION_MEMBERSHIP",
              BalanceSeverity.WARNING,
              "单国成员上限为 " + snapshot.maxMembersPerNation() + "。",
              "对超大国家引入治理成本、决议延迟和远距地区自治倾向。"));
    }
  }

  private static int severityRank(BalanceSeverity severity) {
    return switch (severity) {
      case INFO -> 0;
      case WARNING -> 1;
      case HIGH -> 2;
    };
  }

  private static String money(BigDecimal amount) {
    return amount.stripTrailingZeros().toPlainString();
  }
}
