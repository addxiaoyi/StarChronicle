package dev.starcore.starcore.economy;

/** 货币枚举 定义游戏中不同类型的货币 */
public enum Currency {
  /** 星币：主货币 */
  stellar_coin("星币", "SC", "主通用货币"),

  /** 信任点：用于治理和关系 */
  trust_point("信任点", "TP", "治理与关系"),

  /** 记忆碎片：用于烹调 */
  memory_fragment("记忆碎片", "MF", "烹调材料"),

  /** 证据片：用于证明 */
  evidence_fragment("证据片", "EF", "证据收集");

  private final String displayName;
  private final String symbol;
  private final String description;

  Currency(String displayName, String symbol, String description) {
    this.displayName = displayName;
    this.symbol = symbol;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getSymbol() {
    return symbol;
  }

  public String getDescription() {
    return description;
  }

  /** 格式化货币显示 */
  public String format(long amount) {
    return amount + symbol;
  }
}
