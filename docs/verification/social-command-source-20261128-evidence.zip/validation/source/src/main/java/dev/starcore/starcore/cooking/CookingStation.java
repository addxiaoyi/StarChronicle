package dev.starcore.starcore.cooking;

/** 烹调站类型枚举 定义烹调厨房中的不同烹调站 */
public enum CookingStation {
  /** 蒸锅区 */
  steamer("蒸锅区", "Steamer area"),

  /** 炉窑区 */
  kiln("炉窑区", "Kiln area"),

  /** 烤箱区 */
  oven("烤箱区", "Oven area"),

  /** 往事检视厅 */
  memory_inspection("往事检视厅", "Hall of Past Inspection");

  private final String displayName;
  private final String englishName;

  CookingStation(String displayName, String englishName) {
    this.displayName = displayName;
    this.englishName = englishName;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getEnglishName() {
    return englishName;
  }
}
