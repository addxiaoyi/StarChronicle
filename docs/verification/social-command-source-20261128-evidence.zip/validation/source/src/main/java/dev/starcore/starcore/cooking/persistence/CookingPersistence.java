package dev.starcore.starcore.cooking.persistence;

import dev.starcore.starcore.cooking.CookingSession;
import dev.starcore.starcore.cooking.CookingStation;
import dev.starcore.starcore.cooking.CookingStatus;
import dev.starcore.starcore.cooking.Recipe;
import dev.starcore.starcore.persistence.DataStore;
import dev.starcore.starcore.persistence.StorageKey;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 烹调系统持久化存储 处理食谱和烹调会话的保存与加载 */
public class CookingPersistence {

  private final DataStore dataStore;
  private final Map<String, Recipe> recipeCache = new ConcurrentHashMap<>();
  private final Map<String, CookingSession> sessionCache = new ConcurrentHashMap<>();

  public CookingPersistence(DataStore dataStore) {
    this.dataStore = dataStore;
  }

  /** 保存食谱 */
  public void saveRecipe(Recipe recipe) {
    recipeCache.put(recipe.recipeId(), recipe);
    dataStore.save(StorageKey.RECIPES, recipe);
  }

  /** 批量保存食谱 */
  public void saveAllRecipes(Collection<Recipe> recipes) {
    recipes.forEach(r -> recipeCache.put(r.recipeId(), r));
    dataStore.saveAll(StorageKey.RECIPES, new ArrayList<>(recipes));
  }

  /** 加载食谱 */
  public Optional<Recipe> loadRecipe(String recipeId) {
    return Optional.ofNullable(
        recipeCache.computeIfAbsent(
            recipeId,
            k ->
                dataStore.loadAll(StorageKey.RECIPES, Recipe.class).stream()
                    .filter(r -> r.recipeId().equals(recipeId))
                    .findFirst()
                    .orElse(null)));
  }

  /** 加载所有食谱 */
  public List<Recipe> loadAllRecipes() {
    List<Recipe> recipes = dataStore.loadAll(StorageKey.RECIPES, Recipe.class);
    recipes.forEach(r -> recipeCache.put(r.recipeId(), r));
    return recipes;
  }

  /** 保存烹调会话 */
  public void saveSession(CookingSession session) {
    sessionCache.put(session.sessionId(), session);
    dataStore.save(StorageKey.COOKING_SESSIONS, session);
  }

  /** 批量保存烹调会话 */
  public void saveAllSessions(Collection<CookingSession> sessions) {
    sessions.forEach(s -> sessionCache.put(s.sessionId(), s));
    dataStore.saveAll(StorageKey.COOKING_SESSIONS, new ArrayList<>(sessions));
  }

  /** 加载烹调会话 */
  public Optional<CookingSession> loadSession(String sessionId) {
    return Optional.ofNullable(
        sessionCache.computeIfAbsent(
            sessionId,
            k ->
                dataStore.loadAll(StorageKey.COOKING_SESSIONS, CookingSession.class).stream()
                    .filter(s -> s.sessionId().equals(sessionId))
                    .findFirst()
                    .orElse(null)));
  }

  /** 加载所有烹调会话 */
  public List<CookingSession> loadAllSessions() {
    List<CookingSession> sessions =
        dataStore.loadAll(StorageKey.COOKING_SESSIONS, CookingSession.class);
    sessions.forEach(s -> sessionCache.put(s.sessionId(), s));
    return sessions;
  }

  /** 删除食谱 */
  public void deleteRecipe(String recipeId) {
    recipeCache.remove(recipeId);
    dataStore.delete(StorageKey.RECIPES, recipeId);
  }

  /** 删除烹调会话 */
  public void deleteSession(String sessionId) {
    sessionCache.remove(sessionId);
    dataStore.delete(StorageKey.COOKING_SESSIONS, sessionId);
  }

  /** 清空缓存 */
  public void clearCache() {
    recipeCache.clear();
    sessionCache.clear();
  }

  /** 获取活跃的烹调会话 */
  public List<CookingSession> getActiveSessions() {
    return loadAllSessions().stream()
        .filter(s -> s.status() == CookingStatus.IN_PROGRESS || s.status() == CookingStatus.PENDING)
        .toList();
  }

  /** 获取按玩家分组的烹调会话 */
  public Map<String, List<CookingSession>> getSessionsByPlayer() {
    Map<String, List<CookingSession>> result = new HashMap<>();
    loadAllSessions()
        .forEach(
            session ->
                result.computeIfAbsent(session.playerId(), k -> new ArrayList<>()).add(session));
    return result;
  }

  /** 获取按食谱分组的烹调会话 */
  public Map<String, List<CookingSession>> getSessionsByRecipe() {
    Map<String, List<CookingSession>> result = new HashMap<>();
    loadAllSessions()
        .forEach(
            session ->
                result.computeIfAbsent(session.recipeId(), k -> new ArrayList<>()).add(session));
    return result;
  }

  /** 获取按难度分组的食谱 */
  public Map<Integer, List<Recipe>> getRecipesByDifficulty() {
    Map<Integer, List<Recipe>> result = new HashMap<>();
    loadAllRecipes()
        .forEach(
            recipe ->
                result.computeIfAbsent(recipe.difficulty(), k -> new ArrayList<>()).add(recipe));
    return result;
  }

  /** 获取按烹调站分组的食谱 */
  public Map<CookingStation, List<Recipe>> getRecipesByStation() {
    Map<CookingStation, List<Recipe>> result = new HashMap<>();
    loadAllRecipes()
        .forEach(
            recipe -> result.computeIfAbsent(recipe.station(), k -> new ArrayList<>()).add(recipe));
    return result;
  }
}
