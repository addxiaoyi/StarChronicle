package dev.starcore.starcore.core.module.extension;

import dev.starcore.starcore.core.extension.ExtensionPoint;
import dev.starcore.starcore.core.module.ModuleException;
import dev.starcore.starcore.core.module.StarCoreModule;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/** 模块扩展管理器 管理模块的扩展点贡献 */
public final class ModuleExtensionManager {

  private static ModuleExtensionManager instance;

  private final Logger logger;
  private final Map<String, ModuleExtension> extensions = new ConcurrentHashMap<>();
  private final Map<Class<? extends StarCoreModule>, ModuleExtension> moduleToExtension =
      new ConcurrentHashMap<>();

  private ModuleExtensionManager(Logger logger) {
    this.logger = logger;
  }

  /** 获取单例实例 */
  public static synchronized ModuleExtensionManager getInstance() {
    if (instance == null) {
      throw new IllegalStateException("ModuleExtensionManager not initialized.");
    }
    return instance;
  }

  /** 初始化扩展管理器 */
  public static synchronized void init(Logger logger) {
    if (instance == null) {
      instance = new ModuleExtensionManager(logger);
    }
  }

  /** 注册模块扩展 */
  public void registerExtension(StarCoreModule module, ModuleExtension extension) {
    Objects.requireNonNull(module, "module");
    Objects.requireNonNull(extension, "extension");

    String extensionId = getExtensionId(module);
    if (extensions.containsKey(extensionId)) {
      throw new ModuleException("Module extension already registered: " + extensionId);
    }

    extensions.put(extensionId, extension);
    moduleToExtension.put(module.getClass(), extension);

    // 注册到所需的扩展点
    extension.registerToExtensionPoints();

    logger.info(
        "Registered module extension: "
            + extensionId
            + " ("
            + extension.getExtensionDescription()
            + ")");
  }

  /** 注销模块扩展 */
  public void unregisterExtension(StarCoreModule module) {
    Objects.requireNonNull(module, "module");

    String extensionId = getExtensionId(module);
    ModuleExtension extension = extensions.remove(extensionId);
    if (extension != null) {
      extension.unregisterFromExtensionPoints();
      moduleToExtension.remove(module.getClass());
      logger.info("Unregistered module extension: " + extensionId);
    }
  }

  /** 获取模块扩展 */
  public Optional<ModuleExtension> getExtension(StarCoreModule module) {
    String extensionId = getExtensionId(module);
    return Optional.ofNullable(extensions.get(extensionId));
  }

  /** 获取模块扩展（通过类） */
  public Optional<ModuleExtension> getExtension(Class<? extends StarCoreModule> moduleClass) {
    return Optional.ofNullable(moduleToExtension.get(moduleClass));
  }

  /** 获取所有已注册的扩展 */
  public Collection<ModuleExtension> getAllExtensions() {
    return Collections.unmodifiableCollection(extensions.values());
  }

  /** 执行扩展点 */
  public <T, R> T execute(ExtensionPoint<T, R> extensionPoint, R request) {
    return extensionPoint.execute(request);
  }

  /** 执行扩展点（返回第一个结果） */
  public <T, R> T executeFirst(ExtensionPoint<T, R> extensionPoint, R request) {
    return extensionPoint.executeFirst(request);
  }

  /** 清除所有扩展 */
  public void clear() {
    for (ModuleExtension extension : extensions.values()) {
      extension.unregisterFromExtensionPoints();
    }
    extensions.clear();
    moduleToExtension.clear();
    logger.info("All module extensions cleared");
  }

  private String getExtensionId(StarCoreModule module) {
    return module.metadata().id() + "_extension";
  }
}
