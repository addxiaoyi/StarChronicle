package dev.starcore.starcore.boss;

import java.util.*;

/** Boss定义模型 定义Boss的模板和配置 */
public record BossDefinition(
    String bossId, // Boss ID
    String name, // Boss名称
    String description, // Boss描述
    BossType type, // Boss类型
    BossRoute defaultRoute, // 默认路线
    String entityType, // 实体类型（如SKELETON, WITCH等）
    int level, // Boss等级
    double health, // 生命值
    double attackDamage, // 攻击伤害
    Set<String> abilities, // 技能列表
    Set<String> phases, // 阶段列表
    Map<String, Object> metadata, // 元数据
    String eventRef, // 关联事件
    String regionRef, // 关联区域
    int version // 版本号
    ) {

  /** 创建Boss定义构建器 */
  public static Builder builder(String bossId) {
    return new Builder(bossId);
  }

  /** 检查是否有指定阶段 */
  public boolean hasPhase(String phaseId) {
    return phases != null && phases.contains(phaseId);
  }

  /** 获取阶段数量 */
  public int getPhaseCount() {
    return phases != null ? phases.size() : 0;
  }

  /** 检查是否为筛选Boss */
  public boolean isScreeningBoss() {
    return type == BossType.screening;
  }

  /** 检查是否为后期遭遇Boss */
  public boolean isLateEncounterBoss() {
    return type == BossType.late_encounter;
  }

  /** Boss定义构建器 */
  public static class Builder {
    private final String bossId;
    private String name;
    private String description;
    private BossType type = BossType.screening;
    private BossRoute defaultRoute = BossRoute.demanding;
    private String entityType;
    private int level = 1;
    private double health = 100.0;
    private double attackDamage = 10.0;
    private Set<String> abilities = new HashSet<>();
    private Set<String> phases = new HashSet<>();
    private Map<String, Object> metadata = new HashMap<>();
    private String eventRef;
    private String regionRef;
    private int version = 1;

    private Builder(String bossId) {
      this.bossId = Objects.requireNonNull(bossId);
    }

    public Builder name(String name) {
      this.name = name;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder type(BossType type) {
      this.type = type;
      return this;
    }

    public Builder defaultRoute(BossRoute defaultRoute) {
      this.defaultRoute = defaultRoute;
      return this;
    }

    public Builder entityType(String entityType) {
      this.entityType = entityType;
      return this;
    }

    public Builder level(int level) {
      this.level = level;
      return this;
    }

    public Builder health(double health) {
      this.health = health;
      return this;
    }

    public Builder attackDamage(double attackDamage) {
      this.attackDamage = attackDamage;
      return this;
    }

    public Builder addAbility(String ability) {
      this.abilities.add(ability);
      return this;
    }

    public Builder addPhase(String phase) {
      this.phases.add(phase);
      return this;
    }

    public Builder addPhases(String... phases) {
      this.phases.addAll(Arrays.asList(phases));
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public Builder eventRef(String eventRef) {
      this.eventRef = eventRef;
      return this;
    }

    public Builder regionRef(String regionRef) {
      this.regionRef = regionRef;
      return this;
    }

    public Builder version(int version) {
      this.version = version;
      return this;
    }

    public BossDefinition build() {
      return new BossDefinition(
          bossId,
          name,
          description,
          type,
          defaultRoute,
          entityType,
          level,
          health,
          attackDamage,
          Set.copyOf(abilities),
          Set.copyOf(phases),
          Map.copyOf(metadata),
          eventRef,
          regionRef,
          version);
    }
  }
}
