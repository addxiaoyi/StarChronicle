package dev.starcore.starcore.foundation.economy.insurance;

import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Player-facing insurance products mapped to one transaction owner/type pair. */
public enum InsuranceCoverage {
  DUNGEON_ENTRY(RefundOwner.DUNGEON, TransactionType.DUNGEON_ENTRY_FEE, new BigDecimal("0.08")),
  TRADE(RefundOwner.TRADE, TransactionType.TRADE, new BigDecimal("0.06")),
  SHOP(RefundOwner.SHOP, TransactionType.SHOP_PURCHASE, new BigDecimal("0.05")),
  AUCTION(RefundOwner.SHOP, TransactionType.AUCTION_BID, new BigDecimal("0.05")),
  NATION(RefundOwner.NATION, TransactionType.NATION_OPERATION, new BigDecimal("0.07")),
  WAR_REPARATION(RefundOwner.REPARATIONS, TransactionType.WAR_REPARATION, new BigDecimal("0.10")),
  RENT(RefundOwner.RENT, TransactionType.RENT_SETTLEMENT, new BigDecimal("0.09"));

  private final RefundOwner owner;
  private final TransactionType type;
  private final BigDecimal premiumRate;

  InsuranceCoverage(RefundOwner owner, TransactionType type, BigDecimal premiumRate) {
    this.owner = owner;
    this.type = type;
    this.premiumRate = premiumRate;
  }

  public RefundOwner owner() {
    return owner;
  }

  public TransactionType type() {
    return type;
  }

  public BigDecimal premiumFor(BigDecimal maxPayout) {
    BigDecimal premium = maxPayout.multiply(premiumRate).setScale(2, RoundingMode.HALF_UP);
    return premium.max(BigDecimal.ONE);
  }
}
