package dev.starcore.starcore.gui;

/** 地图图标类型 */
public enum MapIconType {
  // 基础类型
  DEFAULT,
  PLAYER,
  NPC,
  MOB,
  BOSS,

  // 资源类型
  RESOURCE,
  ORE,
  TREE,
  HERB,

  // 建筑类型
  BUILDING,
  HOUSE,
  SHOP,
  TEMPLE,

  // 传送类型
  PORTAL,
  TELEPORTER,
  GATE,

  // 事件类型
  EVENT,
  QUEST,
  DUNGEON,

  // 特殊类型
  CUSTOM
}
