package dev.starcore.starcore.boss;

import java.util.*;

/** Boss实例模型 表示一个正在运行的Boss实例 */
public record BossInstance(
    String instanceId, // 实例ID
    String bossId, // Boss定义ID
    String riftInstanceId, // 关联裂隙实例ID
    BossStatus status, // Boss状态
    BossRoute currentRoute, // 当前路线
    Map<String, Object> healthData, // 生命数据
    Map<String, Object> stateData, // 状态数据
    List<String> defeatedRoutes, // 已完成的路线
    String currentPhase, // 当前阶段
    Long spawnedAt, // 出现时间
    Long defeatedAt, // 击败时间
    String winnerId, // 获胜者ID
    Set<String> participants, // 参与者集合
    Map<String, Object> metadata, // 元数据
    String errorMessage, // 错误消息
    int retryCount // 重试次数
    ) {

  /** 创建Boss实例构建器 */
  public static Builder builder(String instanceId, String bossId, String riftInstanceId) {
    return new Builder(instanceId, bossId, riftInstanceId);
  }

  /** 检查Boss是否已击败 */
  public boolean isDefeated() {
    return status == BossStatus.defeated;
  }

  /** 检查Boss是否失败 */
  public boolean isFailed() {
    return status == BossStatus.failed;
  }

  /** 检查Boss是否活跃 */
  public boolean isActive() {
    return status.isActive();
  }

  /** 获取Boss持续时间 */
  public long getDuration() {
    if (spawnedAt == null) return 0;
    Long endTime = defeatedAt != null ? defeatedAt : System.currentTimeMillis();
    return endTime - spawnedAt;
  }

  /** 检查路线是否已完成 */
  public boolean hasDefeatedRoute(BossRoute route) {
    return defeatedRoutes != null && defeatedRoutes.contains(route.name());
  }

  /** Boss实例构建器 */
  public static class Builder {
    private final String instanceId;
    private final String bossId;
    private final String riftInstanceId;
    private BossStatus status = BossStatus.standby;
    private BossRoute currentRoute = BossRoute.demanding;
    private Map<String, Object> healthData = new HashMap<>();
    private Map<String, Object> stateData = new HashMap<>();
    private List<String> defeatedRoutes = new ArrayList<>();
    private String currentPhase;
    private Long spawnedAt;
    private Long defeatedAt;
    private String winnerId;
    private Set<String> participants = new HashSet<>();
    private Map<String, Object> metadata = new HashMap<>();
    private String errorMessage;
    private int retryCount = 0;

    private Builder(String instanceId, String bossId, String riftInstanceId) {
      this.instanceId = Objects.requireNonNull(instanceId);
      this.bossId = Objects.requireNonNull(bossId);
      this.riftInstanceId = Objects.requireNonNull(riftInstanceId);
    }

    public Builder status(BossStatus status) {
      this.status = status;
      return this;
    }

    public Builder currentRoute(BossRoute currentRoute) {
      this.currentRoute = currentRoute;
      return this;
    }

    public Builder healthData(String key, Object value) {
      this.healthData.put(key, value);
      return this;
    }

    public Builder healthData(Map<String, Object> healthData) {
      this.healthData.putAll(healthData);
      return this;
    }

    public Builder stateData(String key, Object value) {
      this.stateData.put(key, value);
      return this;
    }

    public Builder stateData(Map<String, Object> stateData) {
      this.stateData.putAll(stateData);
      return this;
    }

    public Builder addDefeatedRoute(String route) {
      this.defeatedRoutes.add(route);
      return this;
    }

    public Builder defeatedRoutes(List<String> defeatedRoutes) {
      this.defeatedRoutes = new ArrayList<>(defeatedRoutes);
      return this;
    }

    public Builder currentPhase(String currentPhase) {
      this.currentPhase = currentPhase;
      return this;
    }

    public Builder spawnedAt(Long spawnedAt) {
      this.spawnedAt = spawnedAt;
      return this;
    }

    public Builder defeatedAt(Long defeatedAt) {
      this.defeatedAt = defeatedAt;
      return this;
    }

    public Builder winnerId(String winnerId) {
      this.winnerId = winnerId;
      return this;
    }

    public Builder addParticipant(String participant) {
      this.participants.add(participant);
      return this;
    }

    public Builder participants(Set<String> participants) {
      this.participants = new HashSet<>(participants);
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public Builder errorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
      return this;
    }

    public Builder retryCount(int retryCount) {
      this.retryCount = retryCount;
      return this;
    }

    public BossInstance build() {
      return new BossInstance(
          instanceId,
          bossId,
          riftInstanceId,
          status,
          currentRoute,
          Map.copyOf(healthData),
          Map.copyOf(stateData),
          List.copyOf(defeatedRoutes),
          currentPhase,
          spawnedAt,
          defeatedAt,
          winnerId,
          Set.copyOf(participants),
          Map.copyOf(metadata),
          errorMessage,
          retryCount);
    }
  }
}
