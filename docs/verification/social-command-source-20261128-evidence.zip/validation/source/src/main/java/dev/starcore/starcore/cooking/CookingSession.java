package dev.starcore.starcore.cooking;

import java.util.*;

/** 烹调会话模型 表示一个正在进行的烹调过程 */
public record CookingSession(
    String sessionId, // 会话ID
    String playerId, // 玩家ID
    String recipeId, // 食谱ID
    long startedAt, // 开始时间
    long estimatedCompletion, // 预计完成时间
    Map<String, Integer> ingredients, // 使用的食材
    CookingStatus status // 状态
    ) {

  /** 创建烹调会话构建器 */
  public static Builder builder(String sessionId, String playerId, String recipeId) {
    return new Builder(sessionId, playerId, recipeId);
  }

  /** 获取已过去的时间（毫秒） */
  public long getElapsedTime() {
    return System.currentTimeMillis() - startedAt;
  }

  /** 获取剩余时间（毫秒） */
  public long getRemainingTime() {
    long elapsed = getElapsedTime();
    long total = estimatedCompletion - startedAt;
    return Math.max(0, total - elapsed);
  }

  /** 检查是否已超时 */
  public boolean isOverdue() {
    return System.currentTimeMillis() > estimatedCompletion * 2;
  }

  /** 检查是否已完成 */
  public boolean isComplete() {
    return System.currentTimeMillis() >= estimatedCompletion;
  }

  /** 烹调会话构建器 */
  public static class Builder {
    private final String sessionId;
    private final String playerId;
    private final String recipeId;
    private long startedAt = System.currentTimeMillis();
    private long estimatedCompletion = System.currentTimeMillis() + 60000; // 默认1分钟
    private Map<String, Integer> ingredients = new HashMap<>();
    private CookingStatus status = CookingStatus.IN_PROGRESS;

    private Builder(String sessionId, String playerId, String recipeId) {
      this.sessionId = Objects.requireNonNull(sessionId);
      this.playerId = Objects.requireNonNull(playerId);
      this.recipeId = Objects.requireNonNull(recipeId);
    }

    public Builder startedAt(long startedAt) {
      this.startedAt = startedAt;
      return this;
    }

    public Builder estimatedCompletion(long estimatedCompletion) {
      this.estimatedCompletion = estimatedCompletion;
      return this;
    }

    public Builder ingredients(Map<String, Integer> ingredients) {
      this.ingredients = new HashMap<>(ingredients);
      return this;
    }

    public Builder status(CookingStatus status) {
      this.status = status;
      return this;
    }

    public CookingSession build() {
      return new CookingSession(
          sessionId,
          playerId,
          recipeId,
          startedAt,
          estimatedCompletion,
          Map.copyOf(ingredients),
          status);
    }
  }
}
