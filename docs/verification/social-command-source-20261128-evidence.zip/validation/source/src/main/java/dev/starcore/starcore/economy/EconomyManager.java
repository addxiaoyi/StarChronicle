package dev.starcore.starcore.economy;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/** 经济管理器 管理资源、货币和交易 */
public class EconomyManager {

  private final Map<String, Resource> resources = new ConcurrentHashMap<>();
  private final Map<String, Map<Currency, Long>> playerBalances = new ConcurrentHashMap<>();
  private final Map<String, Map<String, Integer>> playerInventory = new ConcurrentHashMap<>();
  // 每玩家一个 Object 锁：用于 trade/subtractItem/addBalance 等组合操作防 check-then-act 竞态
  private final Map<String, Object> playerLocks = new ConcurrentHashMap<>();

  /** 注册资源 */
  public void registerResource(Resource resource) {
    resources.put(resource.resourceId(), resource);
  }

  /** 卸载资源 */
  public void unregisterResource(String resourceId) {
    resources.remove(resourceId);
  }

  /** 获取资源 */
  public Optional<Resource> getResource(String resourceId) {
    return Optional.ofNullable(resources.get(resourceId));
  }

  /** 获取所有资源 */
  public Collection<Resource> getAllResources() {
    return resources.values();
  }

  /** 获取指定类型的资源 */
  public Set<Resource> getResourcesByType(ResourceType type) {
    Set<Resource> result = new HashSet<>();
    for (Resource resource : resources.values()) {
      if (resource.type() == type) {
        result.add(resource);
      }
    }
    return result;
  }

  /** 获取玩家货币余额 */
  public long getBalance(String playerId, Currency currency) {
    return playerBalances
        .computeIfAbsent(playerId, k -> new ConcurrentHashMap<>())
        .getOrDefault(currency, 0L);
  }

  /** 设置玩家货币余额 */
  public void setBalance(String playerId, Currency currency, long amount) {
    playerBalances
        .computeIfAbsent(playerId, k -> new ConcurrentHashMap<>())
        .put(currency, Math.max(0, amount));
  }

  /** 增加玩家货币 */
  public void addBalance(String playerId, Currency currency, long amount) {
    Map<Currency, Long> balances =
        playerBalances.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());
    long current = balances.getOrDefault(currency, 0L);
    balances.put(currency, Math.max(0, current + amount));
    recordTransactionPattern(playerId, currency, amount, "gain_balance");
  }

  /** 减少玩家货币 */
  public boolean subtractBalance(String playerId, Currency currency, long amount) {
    Map<Currency, Long> balances = playerBalances.get(playerId);
    if (balances == null) return false;

    long current = balances.getOrDefault(currency, 0L);
    if (current < amount) return false;

    balances.put(currency, current - amount);
    recordTransactionPattern(playerId, currency, amount, "lose_balance");
    return true;
  }

  /** 获取玩家物品数量 */
  public int getItemAmount(String playerId, String resourceId) {
    return playerInventory
        .computeIfAbsent(playerId, k -> new ConcurrentHashMap<>())
        .getOrDefault(resourceId, 0);
  }

  /** 设置玩家物品数量 */
  public void setItemAmount(String playerId, String resourceId, int amount) {
    playerInventory
        .computeIfAbsent(playerId, k -> new ConcurrentHashMap<>())
        .put(resourceId, Math.max(0, amount));
  }

  /** 增加玩家物品 */
  public void addItem(String playerId, String resourceId, int amount) {
    Map<String, Integer> inventory =
        playerInventory.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());
    int current = inventory.getOrDefault(resourceId, 0);
    inventory.put(resourceId, Math.max(0, current + amount));
  }

  /** 减少玩家物品 */
  public boolean subtractItem(String playerId, String resourceId, int amount) {
    Map<String, Integer> inventory = playerInventory.get(playerId);
    if (inventory == null) return false;

    int current = inventory.getOrDefault(resourceId, 0);
    if (current < amount) return false;

    inventory.put(resourceId, current - amount);
    return true;
  }

  /** 检查玩家是否有足够的物品 */
  public boolean hasItems(String playerId, Map<String, Integer> requiredItems) {
    Map<String, Integer> inventory = playerInventory.get(playerId);
    if (inventory == null) return false;

    for (Map.Entry<String, Integer> entry : requiredItems.entrySet()) {
      int available = inventory.getOrDefault(entry.getKey(), 0);
      if (available < entry.getValue()) {
        return false;
      }
    }
    return true;
  }

  /** 执行交易（扣除物品并增加货币） */
  public boolean trade(
      String playerId, Map<String, Integer> itemsToSell, Currency currency, long amount) {
    // 检查参数
    if (playerId == null
        || itemsToSell == null
        || itemsToSell.isEmpty()
        || currency == null
        || amount <= 0) {
      return false;
    }

    // 加锁防 check-then-act 竞态：同一玩家的两次并发 trade 不可交错执行
    // 锁粒度选择 playerId 字符串（避免对全 manager 锁过粗）
    Object playerLock = playerLocks.computeIfAbsent(playerId, k -> new Object());
    synchronized (playerLock) {
      // 检查物品是否足够
      if (!hasItems(playerId, itemsToSell)) {
        return false;
      }

      // 扣除物品
      for (Map.Entry<String, Integer> entry : itemsToSell.entrySet()) {
        if (!subtractItem(playerId, entry.getKey(), entry.getValue())) {
          // 回滚
          rollbackTrade(playerId, itemsToSell, currency, amount);
          return false;
        }
      }

      // 增加货币
      addBalance(playerId, currency, amount);
      return true;
    }
  }

  /** 交易回滚 */
  private void rollbackTrade(
      String playerId, Map<String, Integer> itemsToSell, Currency currency, long amount) {
    // 归还物品
    for (Map.Entry<String, Integer> entry : itemsToSell.entrySet()) {
      addItem(playerId, entry.getKey(), entry.getValue());
    }
    // 扣除货币（如果已经添加）
    subtractBalance(playerId, currency, amount);
  }

  /** 获取玩家货币余额概览 */
  public Map<Currency, Long> getPlayerBalances(String playerId) {
    return Map.copyOf(playerBalances.getOrDefault(playerId, Map.of()));
  }

  /** 获取玩家物品库存概览 */
  public Map<String, Integer> getPlayerInventory(String playerId) {
    return Map.copyOf(playerInventory.getOrDefault(playerId, Map.of()));
  }

  /** 清理玩家数据 */
  public void clearPlayerData(String playerId) {
    playerBalances.remove(playerId);
    playerInventory.remove(playerId);
    playerSpendingPatterns.remove(playerId);
    playerEarningPatterns.remove(playerId);
    playerTransactions.remove(playerId);
    playerLocks.remove(playerId);
  }

  /** 清理所有经济数据 */
  public void clear() {
    resources.clear();
    playerBalances.clear();
    playerInventory.clear();
    playerLocks.clear();
    transactionLogs.clear();
    playerTransactions.clear();
    playerSpendingPatterns.clear();
    playerEarningPatterns.clear();
    currencyVelocity.clear();
  }

  // ==================== 交易审计 ====================

  private final Map<String, TransactionLog> transactionLogs = new ConcurrentHashMap<>();
  private final Map<String, List<String>> playerTransactions = new ConcurrentHashMap<>();
  private final int maxTransactionLogAgeDays = 30;

  /** 交易日志 */
  public record TransactionLog(
      String transactionId,
      String playerId,
      String type,
      Currency currency,
      long amount,
      long timestamp,
      Map<String, Integer> items,
      String relatedTransactionId,
      String reason,
      boolean reversible,
      boolean reversedAt,
      long reversedTimestamp) {}

  /** 记录交易 */
  private String recordTransaction(
      String playerId,
      String type,
      Currency currency,
      long amount,
      Map<String, Integer> items,
      String relatedId,
      String reason,
      boolean reversible) {
    String transactionId = generateTransactionId();

    TransactionLog log =
        new TransactionLog(
            transactionId,
            playerId,
            type,
            currency,
            amount,
            System.currentTimeMillis(),
            items,
            relatedId,
            reason,
            reversible,
            false,
            0L);

    transactionLogs.put(transactionId, log);
    playerTransactions.computeIfAbsent(playerId, k -> new ArrayList<>()).add(transactionId);

    return transactionId;
  }

  /** 获取交易日志 */
  public Optional<TransactionLog> getTransaction(String transactionId) {
    return Optional.ofNullable(transactionLogs.get(transactionId));
  }

  /** 获取玩家的所有交易 */
  public List<TransactionLog> getPlayerTransactions(String playerId) {
    List<String> ids = playerTransactions.getOrDefault(playerId, List.of());
    List<TransactionLog> result = new ArrayList<>();
    for (String id : ids) {
      TransactionLog log = transactionLogs.get(id);
      if (log != null) {
        result.add(log);
      }
    }
    return result;
  }

  /** 可逆操作：撤销交易 */
  public boolean reverseTransaction(String transactionId, String reason) {
    TransactionLog log = transactionLogs.get(transactionId);
    if (log == null) return false;
    if (log.reversedAt()) return false; // 已经撤销
    if (!log.reversible()) return false; // 不可撤销

    String playerId = log.playerId();

    // 根据交易类型恢复状态
    switch (log.type()) {
      case "gain_balance" -> {
        // 恢复货币
        subtractBalance(playerId, log.currency(), Math.abs(log.amount()));
        // 还原物品（如果有）
        if (log.items() != null) {
          for (Map.Entry<String, Integer> entry : log.items().entrySet()) {
            addItem(playerId, entry.getKey(), entry.getValue());
          }
        }
      }
      case "lose_balance" -> {
        // 恢复货币
        addBalance(playerId, log.currency(), Math.abs(log.amount()));
      }
      case "add_item" -> {
        // 减少物品
        for (Map.Entry<String, Integer> entry : log.items().entrySet()) {
          subtractItem(playerId, entry.getKey(), entry.getValue());
        }
      }
      case "remove_item" -> {
        // 增加物品
        if (log.items() != null) {
          for (Map.Entry<String, Integer> entry : log.items().entrySet()) {
            addItem(playerId, entry.getKey(), entry.getValue());
          }
        }
      }
      case "trade" -> {
        // 还原交易
        Map<String, Integer> items = log.items() != null ? log.items() : Map.of();
        addBalance(playerId, log.currency(), log.amount());
        for (Map.Entry<String, Integer> entry : items.entrySet()) {
          addItem(playerId, entry.getKey(), entry.getValue());
        }
      }
    }

    // 记录撤销
    TransactionLog reversed =
        new TransactionLog(
            "reversed_" + transactionId,
            playerId,
            "reversed",
            null,
            0,
            System.currentTimeMillis(),
            null,
            transactionId,
            reason,
            true,
            true,
            System.currentTimeMillis());
    transactionLogs.put(reversed.transactionId(), reversed);

    return true;
  }

  /** 批量撤销交易 */
  public int reverseTransactions(List<String> transactionIds, String reason) {
    int reversedCount = 0;
    for (String id : transactionIds) {
      if (reverseTransaction(id, reason)) {
        reversedCount++;
      }
    }
    return reversedCount;
  }

  /** 撤销玩家最近的N笔交易 */
  public int reverseRecentTransactions(String playerId, int count) {
    List<TransactionLog> transactions =
        getPlayerTransactions(playerId).stream()
            .filter(t -> !t.reversedAt() && t.reversible())
            .toList();

    List<String> toReverse =
        transactions.stream().limit(count).map(TransactionLog::transactionId).toList();

    return reverseTransactions(toReverse, "recently_reversed_batch");
  }

  /** 获取交易审计报告 */
  public AuditReport getAuditReport(
      String playerId, Instant from, Instant to, Predicate<TransactionLog> filter) {
    List<TransactionLog> transactions =
        getPlayerTransactions(playerId).stream()
            .filter(t -> t.timestamp() >= from.toEpochMilli() && t.timestamp() <= to.toEpochMilli())
            .filter(t -> filter.test(t))
            .toList();

    long totalIn = 0;
    long totalOut = 0;
    Map<Currency, Long> currencyIn = new HashMap<>();
    Map<Currency, Long> currencyOut = new HashMap<>();

    for (TransactionLog t : transactions) {
      if (t.type().startsWith("gain") || t.type().equals("trade")) {
        totalIn += Math.max(0, t.amount());
        currencyIn.merge(t.currency(), Math.abs(t.amount()), Long::sum);
      } else if (t.type().startsWith("lose") || t.type().equals("trade")) {
        totalOut += Math.max(0, t.amount());
        currencyOut.merge(t.currency(), Math.abs(t.amount()), Long::sum);
      }
    }

    return new AuditReport(
        playerId, transactions, totalIn, totalOut, currencyIn, currencyOut, transactions.size());
  }

  /** 交易审计报告 */
  public record AuditReport(
      String playerId,
      List<TransactionLog> transactions,
      long totalInflow,
      long totalOutflow,
      Map<Currency, Long> currencyInflow,
      Map<Currency, Long> currencyOutflow,
      int transactionCount) {}

  /** 生成交易ID */
  private String generateTransactionId() {
    return "tx_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 清理过期交易日志 */
  public int cleanupOldTransactions() {
    long cutoff = System.currentTimeMillis() - (maxTransactionLogAgeDays * 24L * 60 * 60 * 1000);

    int cleaned = 0;
    for (var it = transactionLogs.entrySet().iterator(); it.hasNext(); ) {
      Map.Entry<String, TransactionLog> entry = it.next();
      if (entry.getValue().timestamp() < cutoff && !entry.getValue().reversedAt()) {
        String txId = entry.getKey();
        it.remove();
        cleaned++;
        for (List<String> playerTxList : playerTransactions.values()) {
          playerTxList.remove(txId);
        }
      }
    }
    return cleaned;
  }

  /** 获取活跃交易数量 */
  public int getActiveTransactionCount() {
    return (int) transactionLogs.values().stream().filter(t -> !t.reversedAt()).count();
  }

  // ==================== 经济闭环反馈 ====================

  /** 经济反馈器 - 基于交易模式自动调整经济参数 */
  private final Map<String, Long> playerSpendingPatterns = new ConcurrentHashMap<>();

  private final Map<Currency, Long> currencyVelocity = new ConcurrentHashMap<>();
  private final Map<String, Long> playerEarningPatterns = new ConcurrentHashMap<>();

  /** 记录交易模式 */
  private void recordTransactionPattern(
      String playerId, Currency currency, long amount, String type) {
    if (amount > 0) {
      if (type.equals("gain_balance") || type.equals("trade")) {
        playerEarningPatterns.merge(playerId, amount, Long::sum);
      } else {
        playerSpendingPatterns.merge(playerId, amount, Long::sum);
      }
    }
    currencyVelocity.merge(currency, Math.abs(amount), Long::sum);
  }

  /** 获取经济健康度报告 */
  public EconomicHealthReport getEconomicHealthReport() {
    long totalSpending = playerSpendingPatterns.values().stream().mapToLong(Long::longValue).sum();
    long totalEarnings = playerEarningPatterns.values().stream().mapToLong(Long::longValue).sum();

    double totalVelocity = currencyVelocity.values().stream().mapToLong(Long::longValue).sum();

    double activityIndex = totalSpending + totalEarnings;
    double inflationRisk =
        totalEarnings > totalSpending * 1.5
            ? (totalEarnings - totalSpending) / (double) totalSpending
            : 0;
    double deflationRisk =
        totalSpending > totalEarnings * 1.5
            ? (totalSpending - totalEarnings) / (double) totalEarnings
            : 0;

    return new EconomicHealthReport(
        totalSpending,
        totalEarnings,
        totalVelocity,
        activityIndex,
        inflationRisk,
        deflationRisk,
        Map.copyOf(currencyVelocity));
  }

  public record EconomicHealthReport(
      long totalSpending,
      long totalEarnings,
      double totalVelocity,
      double activityIndex,
      double inflationRisk,
      double deflationRisk,
      Map<Currency, Long> currencyVelocity) {}

  /** 基于经济健康度调整货币政策 */
  public CurrencyPolicy getCurrencyPolicy() {
    EconomicHealthReport health = getEconomicHealthReport();
    double taxRate = health.inflationRisk() > 0.5 ? 0.15 : 0.05;
    taxRate = Math.min(0.25, taxRate);
    double issuanceRate = health.deflationRisk() > 0.3 ? 1.2 : 1.0;
    issuanceRate = Math.min(2.0, issuanceRate);
    double stimulusRate = health.activityIndex() < 1000 ? 0.1 : 0.0;
    return new CurrencyPolicy(taxRate, issuanceRate, stimulusRate);
  }

  public record CurrencyPolicy(double taxRate, double issuanceRate, double stimulusRate) {}

  /** 经济反馈闭环：根据经济状况调整系统参数 */
  public void applyEconomicFeedback() {
    CurrencyPolicy policy = getCurrencyPolicy();
    if (policy.taxRate() > 0.1) {
      applyTax(policy.taxRate());
    }
    if (policy.issuanceRate() < 1.0) {
      applyMoneySupplyAdjustment(policy.issuanceRate());
    }
    if (policy.stimulusRate() > 0) {
      applyStimulus(policy.stimulusRate());
    }
  }

  private void applyTax(double taxRate) {
    for (Map.Entry<String, Map<Currency, Long>> entry : new HashMap<>(playerBalances).entrySet()) {
      String playerId = entry.getKey();
      Map<Currency, Long> balances = entry.getValue();
      for (Map.Entry<Currency, Long> balanceEntry : new HashMap<>(balances).entrySet()) {
        Currency currency = balanceEntry.getKey();
        long balance = balanceEntry.getValue();
        long tax = (long) (balance * taxRate);
        if (tax > 0) {
          subtractBalance(playerId, currency, tax);
        }
      }
    }
  }

  private void applyMoneySupplyAdjustment(double issuanceRate) {
    double adjustmentFactor = 1.0 - issuanceRate;
    if (adjustmentFactor > 0) {
      for (Map.Entry<String, Map<Currency, Long>> entry :
          new HashMap<>(playerBalances).entrySet()) {
        String playerId = entry.getKey();
        Map<Currency, Long> balances = entry.getValue();
        for (Map.Entry<Currency, Long> balanceEntry : new HashMap<>(balances).entrySet()) {
          Currency currency = balanceEntry.getKey();
          long currentBalance = balanceEntry.getValue();
          long adjustment = (long) (currentBalance * adjustmentFactor);
          if (adjustment > 0) {
            subtractBalance(playerId, currency, adjustment);
          }
        }
      }
    }
  }

  private void applyStimulus(double stimulusRate) {
    for (Map.Entry<String, Map<Currency, Long>> entry : new HashMap<>(playerBalances).entrySet()) {
      String playerId = entry.getKey();
      Map<Currency, Long> balances = entry.getValue();
      for (Currency currency : balances.keySet()) {
        long currentOutput = currencyVelocity.getOrDefault(currency, 0L);
        if (currentOutput > 0) {
          long stimulus = (long) (currentOutput * stimulusRate);
          if (stimulus > 0) {
            addBalance(playerId, currency, stimulus);
          }
        }
      }
    }
  }
}
