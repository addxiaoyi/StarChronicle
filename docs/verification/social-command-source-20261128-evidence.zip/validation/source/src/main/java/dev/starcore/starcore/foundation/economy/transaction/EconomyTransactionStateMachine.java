package dev.starcore.starcore.foundation.economy.transaction;

import java.util.Objects;

/** Small immutable state holder that rejects illegal cross-module lifecycle jumps. */
public final class EconomyTransactionStateMachine {
  private EconomyTransactionState state;

  public EconomyTransactionStateMachine() {
    this(EconomyTransactionState.CREATED);
  }

  public EconomyTransactionStateMachine(EconomyTransactionState initialState) {
    state = Objects.requireNonNull(initialState, "initialState");
  }

  public synchronized EconomyTransactionState state() {
    return state;
  }

  public synchronized boolean transition(EconomyTransactionState next) {
    Objects.requireNonNull(next, "next");
    if (state == next) return true;
    if (!state.canTransitionTo(next)) return false;
    state = next;
    return true;
  }

  public synchronized void require(EconomyTransactionState expected) {
    if (state != expected) {
      throw new IllegalStateException(
          "Expected transaction state " + expected + " but was " + state);
    }
  }
}
