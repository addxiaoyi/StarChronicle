package dev.starcore.starcore.integration.craftengine;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.plugin.Plugin;

/**
 * CraftEngine 集成 支持自定义合成、配方、工作台等
 *
 * <p>CraftEngine 是一个自定义合成插件
 */
public final class CraftEngineIntegration {
  private static final String CRAFT_ENGINE_NAMESPACE = "craftengine";
  private final Plugin plugin;
  private boolean enabled = false;

  public CraftEngineIntegration(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 初始化集成 */
  public boolean init() {
    try {
      // 检测 CraftEngine 插件
      Plugin craftEngine = plugin.getServer().getPluginManager().getPlugin("CraftEngine");
      if (craftEngine == null) {
        plugin.getLogger().info("⚠ CraftEngine 未安装");
        return false;
      }

      if (!plugin.getServer().getPluginManager().isPluginEnabled("CraftEngine")) {
        plugin.getLogger().warning("⚠ CraftEngine 已安装但未启用");
        return false;
      }

      // 尝试加载 API（CraftEngine 的实际 API 类名可能不同）
      // 注意：这里使用通用的检测方式
      this.enabled = true;
      plugin.getLogger().info("✅ CraftEngine 集成已启用");
      return true;

    } catch (Exception e) {
      plugin.getLogger().warning("⚠ CraftEngine 集成初始化失败: " + e.getMessage());
      return false;
    }
  }

  /** 打开自定义工作台 */
  public boolean openCraftingTable(Player player, String tableId) {
    if (!enabled || player == null || !isNativeCraftingTable(tableId)) {
      return false;
    }

    try {
      return player.openWorkbench(player.getLocation(), true) != null;
    } catch (Exception e) {
      plugin.getLogger().warning("打开 CraftEngine 工作台失败: " + e.getMessage());
      return false;
    }
  }

  /** 检查配方是否存在 */
  public boolean recipeExists(String recipeId) {
    if (!enabled) {
      return false;
    }

    return findRecipe(resolveRecipeKey(recipeId)) != null;
  }

  /** 检查玩家是否解锁配方 */
  public boolean hasRecipeUnlocked(Player player, String recipeId) {
    if (!enabled || player == null) {
      return false;
    }

    NamespacedKey key = resolveRecipeKey(recipeId);
    if (key == null || findRecipe(key) == null) {
      return false;
    }
    try {
      return player.hasDiscoveredRecipe(key);
    } catch (Exception e) {
      plugin.getLogger().warning("检查 CraftEngine 配方解锁状态失败: " + e.getMessage());
      return false;
    }
  }

  /** 解锁配方 */
  public boolean unlockRecipe(Player player, String recipeId) {
    if (!enabled || player == null) {
      return false;
    }

    NamespacedKey key = resolveRecipeKey(recipeId);
    if (key == null || findRecipe(key) == null) {
      return false;
    }
    try {
      return player.discoverRecipe(key);
    } catch (Exception e) {
      plugin.getLogger().warning("解锁 CraftEngine 配方失败: " + e.getMessage());
      return false;
    }
  }

  /** 锁定配方 */
  public boolean lockRecipe(Player player, String recipeId) {
    if (!enabled || player == null) {
      return false;
    }

    NamespacedKey key = resolveRecipeKey(recipeId);
    if (key == null || findRecipe(key) == null) {
      return false;
    }
    try {
      return player.undiscoverRecipe(key);
    } catch (Exception e) {
      plugin.getLogger().warning("锁定 CraftEngine 配方失败: " + e.getMessage());
      return false;
    }
  }

  /** 获取配方的合成结果 */
  public Optional<ItemStack> getRecipeResult(String recipeId) {
    if (!enabled) {
      return Optional.empty();
    }

    try {
      Recipe recipe = findRecipe(resolveRecipeKey(recipeId));
      if (recipe == null || recipe.getResult() == null) {
        return Optional.empty();
      }
      return Optional.ofNullable(recipe.getResult().clone());
    } catch (Exception e) {
      plugin.getLogger().warning("获取配方结果失败: " + e.getMessage());
      return Optional.empty();
    }
  }

  /** 获取玩家已解锁的配方列表 */
  public List<String> getUnlockedRecipes(Player player) {
    if (!enabled || player == null) {
      return List.of();
    }

    try {
      return player.getDiscoveredRecipes().stream()
          .filter(Objects::nonNull)
          .map(NamespacedKey::toString)
          .sorted()
          .toList();
    } catch (Exception e) {
      plugin.getLogger().warning("获取解锁配方失败: " + e.getMessage());
      return List.of();
    }
  }

  /** 检查是否可以合成 */
  public boolean canCraft(Player player, String recipeId) {
    if (!enabled || player == null || recipeId == null) {
      return false;
    }

    NamespacedKey key = resolveRecipeKey(recipeId);
    if (key == null || findRecipe(key) == null || !hasRecipeUnlocked(player, recipeId)) {
      return false;
    }

    // This contract has no input matrix, so claiming that a craft is possible
    // would skip the material check and make craft() report a false success.
    return false;
  }

  /** 执行合成 */
  public Optional<ItemStack> craft(Player player, String recipeId) {
    // Crafting needs an input matrix and consumption contract that this adapter does not expose.
    return Optional.empty();
  }

  /** 重载配方 */
  public boolean reloadRecipes() {
    if (!enabled) {
      return false;
    }

    try {
      // CraftEngine 重载命令
      return plugin
          .getServer()
          .dispatchCommand(plugin.getServer().getConsoleSender(), "craftengine reload");
    } catch (Exception e) {
      plugin.getLogger().warning("重载 CraftEngine 配方失败: " + e.getMessage());
      return false;
    }
  }

  /** 是否已启用 */
  public boolean isEnabled() {
    return enabled;
  }

  private NamespacedKey resolveRecipeKey(String recipeId) {
    if (recipeId == null) {
      return null;
    }
    String normalized = recipeId.trim();
    if (normalized.isEmpty()) {
      return null;
    }
    try {
      int separator = normalized.indexOf(':');
      if (separator < 0) {
        return new NamespacedKey(CRAFT_ENGINE_NAMESPACE, normalized);
      }
      if (separator == 0
          || separator == normalized.length() - 1
          || normalized.indexOf(':', separator + 1) >= 0) {
        return null;
      }
      return NamespacedKey.fromString(normalized);
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private Recipe findRecipe(NamespacedKey key) {
    if (key == null) {
      return null;
    }
    try {
      return Bukkit.getRecipe(key);
    } catch (RuntimeException exception) {
      plugin.getLogger().warning("查询 CraftEngine 配方失败: " + exception.getMessage());
      return null;
    }
  }

  private boolean isNativeCraftingTable(String tableId) {
    if (tableId == null) {
      return false;
    }
    String normalized = tableId.trim().toLowerCase(Locale.ROOT);
    return normalized.equals("crafting_table") || normalized.equals("minecraft:crafting_table");
  }
}
