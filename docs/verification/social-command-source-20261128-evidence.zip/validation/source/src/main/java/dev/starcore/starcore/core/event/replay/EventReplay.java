package dev.starcore.starcore.core.event.replay;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/** 事件回放系统 记录事件历史并支持回放，便于调试和审计 */
public class EventReplay {

  private final Deque<EventRecord> eventHistory = new ArrayDeque<>();
  private final Map<String, List<EventRecord>> categorizedEvents = new ConcurrentHashMap<>();
  private final int maxHistorySize;
  private final boolean recording;
  private final Set<String> recordedEventTypes;
  private final Predicate<Object> filter;

  public EventReplay() {
    this(1000);
  }

  public EventReplay(int maxHistorySize) {
    this(maxHistorySize, true);
  }

  public EventReplay(int maxHistorySize, boolean recording) {
    this.maxHistorySize = maxHistorySize;
    this.recording = recording;
    this.recordedEventTypes = ConcurrentHashMap.newKeySet();
    this.filter = null;
  }

  public EventReplay(int maxHistorySize, boolean recording, Set<String> recordedEventTypes) {
    this(maxHistorySize, recording, recordedEventTypes, null);
  }

  public EventReplay(
      int maxHistorySize,
      boolean recording,
      Set<String> recordedEventTypes,
      Predicate<Object> filter) {
    this.maxHistorySize = maxHistorySize;
    this.recording = recording;
    this.recordedEventTypes = ConcurrentHashMap.newKeySet();
    if (recordedEventTypes != null) {
      this.recordedEventTypes.addAll(recordedEventTypes);
    }
    this.filter = filter;
  }

  /** 记录事件 */
  public void recordEvent(String eventType, Object event) {
    if (!recording) return;

    // 如果指定了事件类型过滤，则只记录匹配的类型
    if (!recordedEventTypes.isEmpty() && !recordedEventTypes.contains(eventType)) {
      return;
    }

    // 如果有过滤器，则应用过滤
    if (filter != null && !filter.test(event)) {
      return;
    }

    EventRecord record = new EventRecord(eventType, event, System.currentTimeMillis());

    synchronized (eventHistory) {
      eventHistory.addFirst(record);

      // 保持历史记录在最大容量限制内
      while (eventHistory.size() > maxHistorySize) {
        EventRecord removed = eventHistory.removeLast();
        // 同步清理分类事件，防止 unbounded growth
        List<EventRecord> category = categorizedEvents.get(removed.eventType());
        if (category != null) {
          category.remove(removed);
        }
      }
    }

    // 按类别归存
    categorizedEvents.computeIfAbsent(eventType, k -> new ArrayList<>()).add(0, record);
  }

  /** 回放指定类型的事件 */
  public void replay(String eventType, ReplayHandler handler) {
    List<EventRecord> events = categorizedEvents.get(eventType);
    if (events == null) return;

    for (EventRecord record : events) {
      try {
        handler.handle(record);
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(EventReplay.class.getName())
            .warning("Error replaying event: " + e.getMessage());
      }
    }
  }

  /** 回放所有事件 */
  public void replayAll(ReplayHandler handler) {
    synchronized (eventHistory) {
      for (EventRecord record : eventHistory) {
        try {
          handler.handle(record);
        } catch (Exception e) {
          java.util.logging.Logger.getLogger(EventReplay.class.getName())
              .warning("Error replaying event: " + e.getMessage());
        }
      }
    }
  }

  /** 按时间范围回放事件 */
  public void replayByTimeRange(long startTime, long endTime, ReplayHandler handler) {
    synchronized (eventHistory) {
      for (EventRecord record : eventHistory) {
        if (record.timestamp() >= startTime && record.timestamp() <= endTime) {
          try {
            handler.handle(record);
          } catch (Exception e) {
            java.util.logging.Logger.getLogger(EventReplay.class.getName())
                .warning("Error replaying event: " + e.getMessage());
          }
        }
      }
    }
  }

  /** 获取事件历史 */
  public List<EventRecord> getEventHistory() {
    synchronized (eventHistory) {
      return List.copyOf(eventHistory);
    }
  }

  /** 获取指定类型的事件历史 */
  public List<EventRecord> getEventHistory(String eventType) {
    List<EventRecord> events = categorizedEvents.get(eventType);
    return events != null ? List.copyOf(events) : List.of();
  }

  /** 获取最近的事件 */
  public Optional<EventRecord> getLatestEvent() {
    synchronized (eventHistory) {
      return eventHistory.isEmpty() ? Optional.empty() : Optional.of(eventHistory.getFirst());
    }
  }

  /** 获取特定类型的最近事件 */
  public Optional<EventRecord> getLatestEvent(String eventType) {
    List<EventRecord> events = categorizedEvents.get(eventType);
    return events == null || events.isEmpty() ? Optional.empty() : Optional.of(events.get(0));
  }

  /** 获取事件统计 */
  public EventStatistics getStatistics() {
    Map<String, Long> typeCounts = new HashMap<>();
    for (Map.Entry<String, List<EventRecord>> entry : categorizedEvents.entrySet()) {
      typeCounts.put(entry.getKey(), (long) entry.getValue().size());
    }

    long totalEvents = eventHistory.size();
    long uniqueTypes = categorizedEvents.size();

    return new EventStatistics(totalEvents, uniqueTypes, typeCounts);
  }

  /** 清除事件历史 */
  public void clear() {
    synchronized (eventHistory) {
      eventHistory.clear();
    }
    categorizedEvents.clear();
  }

  /** 缩减事件历史 */
  public void trim(int maxSize) {
    synchronized (eventHistory) {
      while (eventHistory.size() > maxSize) {
        EventRecord removed = eventHistory.removeLast();
        List<EventRecord> category = categorizedEvents.get(removed.eventType());
        if (category != null) {
          category.remove(removed);
        }
      }
    }
  }

  /** 注册事件类型 */
  public void registerEventType(String eventType) {
    recordedEventTypes.add(eventType);
  }

  /** 获取已记录的事件类型 */
  public Set<String> getRecordedEventTypes() {
    return Set.copyOf(recordedEventTypes);
  }

  /** 获取记录的事件数量 */
  public int getRecordedEventCount() {
    synchronized (eventHistory) {
      return eventHistory.size();
    }
  }

  /** 获取指定类型的记录事件 */
  @SuppressWarnings("unchecked")
  public <T> List<T> getRecordedEventsByType(Class<T> eventType) {
    return getEventHistory(eventType.getName()).stream()
        .map(record -> (T) record.event())
        .collect(Collectors.toList());
  }

  /** 回放所有记录的事件 */
  public void replayEvents() {
    replayAll(record -> {});
  }

  /** 按时间范围获取事件记录 */
  public List<EventRecord> getEventsInTimeRange(long startTime, long endTime) {
    return getEventHistory().stream()
        .filter(record -> record.timestamp() >= startTime && record.timestamp() <= endTime)
        .collect(Collectors.toList());
  }

  /** 记录事件（使用类名作为类型） */
  public void recordEvent(Object event) {
    recordEvent(event.getClass().getName(), event);
  }

  /** 记录带时间戳的事件 */
  public void recordEventWithTimestamp(Object event, long timestamp) {
    EventRecord record = new EventRecord(event.getClass().getName(), event, timestamp);
    synchronized (eventHistory) {
      eventHistory.addFirst(record);
      while (eventHistory.size() > maxHistorySize) {
        EventRecord removed = eventHistory.removeLast();
        // 同步清理分类事件，防止 unbounded growth
        List<EventRecord> category = categorizedEvents.get(removed.eventType());
        if (category != null) {
          category.remove(removed);
        }
      }
    }
    categorizedEvents
        .computeIfAbsent(event.getClass().getName(), k -> new ArrayList<>())
        .add(0, record);
  }

  /** 设置记录过滤器 */
  public EventReplay withFilter(Predicate<Object> filter) {
    return new EventReplay(this.maxHistorySize, this.recording, this.recordedEventTypes, filter);
  }

  /** 导出事件历史 */
  public List<Map<String, Object>> exportHistory() {
    List<Map<String, Object>> result = new ArrayList<>();
    synchronized (eventHistory) {
      for (EventRecord record : eventHistory) {
        Map<String, Object> entry = new HashMap<>();
        entry.put("eventType", record.eventType());
        entry.put("eventClassName", record.event().getClass().getName());
        entry.put("timestamp", Instant.ofEpochMilli(record.timestamp()).toString());
        entry.put("event", record.event());
        result.add(entry);
      }
    }
    return result;
  }

  /** 回放处理器接口 */
  @FunctionalInterface
  public interface ReplayHandler {
    void handle(EventRecord record);
  }

  /** 事件记录 */
  public static record EventRecord(String eventType, Object event, long timestamp) {}

  /** 事件统计 */
  public static record EventStatistics(
      long totalEvents, long uniqueTypes, Map<String, Long> typeCounts) {}
}
