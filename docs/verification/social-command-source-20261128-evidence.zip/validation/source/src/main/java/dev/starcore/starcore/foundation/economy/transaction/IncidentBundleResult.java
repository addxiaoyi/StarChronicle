package dev.starcore.starcore.foundation.economy.transaction;

import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Result of a completed incident bundle export. */
public record IncidentBundleResult(
        UUID transactionId,
        Path archive,
        String archiveSha256,
        List<String> entries,
        List<String> errors) {
    public IncidentBundleResult {
        Objects.requireNonNull(transactionId, "transactionId");
        Objects.requireNonNull(archive, "archive");
        if (archiveSha256 == null || archiveSha256.isBlank()) {
            throw new IllegalArgumentException("archiveSha256 must not be blank");
        }
        entries = List.copyOf(Objects.requireNonNull(entries, "entries"));
        errors = List.copyOf(Objects.requireNonNull(errors, "errors"));
    }

    public boolean complete() {
        return errors.isEmpty();
    }
}
