package dev.starcore.starcore.foundation.economy.transaction;

/** Explains how a refund retry entry was correlated to a durable transaction. */
public enum EvidenceReplayCorrelation {
  TRANSACTION_ID,
  REASON,
  NONE
}
