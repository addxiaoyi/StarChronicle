package dev.starcore.starcore.economy;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import dev.starcore.starcore.war.WarBond;
import dev.starcore.starcore.war.WarEconomyService;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * 经济业务统一查询入口。
 *
 * <p>聚合已有经济/财政服务，不再让调用方分别持有多个引用：玩家余额在 foundation， 国库/税收/债务/预算/破产在 module.treasury（TreasuryService
 * 已内部委托 TaxationService、 LoanService、BudgetService、BankruptcyService），战争债券在 war。
 *
 * <p>查询路径统一用 0 / false / 100 / empty 表达"子系统未接入"，绝不伪造数据；写操作 （存取款）让底层异常向上传播——金钱场景下的静默失败比崩溃危险。
 */
public interface EconomyService {

  // ==================== 玩家账户 ====================

  BigDecimal getPlayerBalance(UUID playerId);

  boolean depositPlayer(UUID playerId, BigDecimal amount);

  boolean withdrawPlayer(UUID playerId, BigDecimal amount);

  boolean transferPlayer(UUID from, UUID to, BigDecimal amount);

  // ==================== 国家国库 ====================

  BigDecimal getNationBalance(NationId nationId);

  BigDecimal getNationTotalDebt(NationId nationId);

  BigDecimal getNationMaxBorrowable(NationId nationId);

  int getNationDebtHealth(NationId nationId);

  boolean isNationBankrupt(NationId nationId);

  BigDecimal getNationTodayIncome(NationId nationId);

  BigDecimal getNationTodayExpense(NationId nationId);

  Map<TaxationService.TaxType, TaxationService.TaxConfig> getNationTaxConfigs(NationId nationId);

  Optional<BudgetService.BudgetBill> getNationCurrentBudget(NationId nationId);

  Optional<TreasuryService.FinanceHealthReport> getNationFinanceHealth(NationId nationId);

  // ==================== 战争财政 ====================

  List<WarBond> getWarBondsOf(NationId nationId);

  Optional<WarBond> getWarBond(UUID bondId);

  // ==================== 底层服务句柄 ====================

  Optional<TreasuryService> getTreasuryService();

  Optional<WarEconomyService> getWarEconomyService();

  String summary();
}
