package dev.starcore.starcore.essentials.player;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.logging.Level;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** Names captured on each original player owner, for nonblocking command completion. */
public final class PlayerNameDirectory implements AutoCloseable {
  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final BooleanSupplier lifetime;
  private final Object gate = new Object();
  private final Map<UUID, CapturedName> names = new ConcurrentHashMap<>();
  private final Map<UUID, PendingName> pending = new ConcurrentHashMap<>();
  private volatile boolean closed;

  public PlayerNameDirectory(
      Plugin plugin, FoliaCompatScheduler scheduler, BooleanSupplier lifetime) {
    this.plugin = Objects.requireNonNull(plugin);
    this.scheduler = Objects.requireNonNull(scheduler);
    this.lifetime = Objects.requireNonNull(lifetime);
  }

  private boolean active() {
    return !closed && plugin.isEnabled() && lifetime.getAsBoolean();
  }

  /** Requires this player's owner; joins also replace any pending capture from an older session. */
  public void observe(Player player) {
    if (!active()) return;
    UUID id = player.getUniqueId();
    if (!player.isOnline() || player.getServer().getPlayer(id) != player) {
      forget(player);
      return;
    }
    String name = player.getName();
    synchronized (gate) {
      if (!active() || plugin.getServer().getPlayer(id) != player) return;
      if (name != null && !name.isBlank()) names.put(id, new CapturedName(player, name));
      pending.remove(id);
    }
  }

  /**
   * Uses only the immutable UUID and captured object identity; old quit events spare new sessions.
   */
  public void forget(Player player) {
    UUID id = player.getUniqueId();
    synchronized (gate) {
      names.computeIfPresent(id, (key, value) -> value.player == player ? null : value);
      pending.computeIfPresent(id, (key, value) -> value.player == player ? null : value);
    }
  }

  /** Enumerates identities only. Names and online state are read later on each entity owner. */
  public void refresh() {
    if (!active()) return;
    try {
      for (Player player : List.copyOf(plugin.getServer().getOnlinePlayers())) {
        UUID id = player.getUniqueId();
        PendingName token = new PendingName(player);
        synchronized (gate) {
          if (!active()) return;
          CapturedName existing = names.get(id);
          if (existing != null && existing.player == player) continue;
          if (pending.putIfAbsent(id, token) != null) continue;
        }
        AtomicBoolean claimed = new AtomicBoolean();
        Runnable retired =
            () -> {
              if (claimed.compareAndSet(false, true)) pending.remove(id, token);
            };
        try {
          scheduler.runAtEntity(
              player,
              ignored -> {
                if (!claimed.compareAndSet(false, true)) return;
                try {
                  if (pending.get(id) == token && active()) observe(player);
                } catch (RuntimeException failure) {
                  plugin.getLogger().log(Level.FINE, "Player name capture unavailable", failure);
                } finally {
                  pending.remove(id, token);
                }
              },
              retired);
        } catch (RuntimeException failure) {
          retired.run();
          plugin
              .getLogger()
              .log(Level.FINE, "Player name capture registration unavailable", failure);
        }
      }
    } catch (RuntimeException failure) {
      plugin.getLogger().log(Level.FINE, "Player name enumeration unavailable", failure);
    }
  }

  /**
   * A detached, sorted snapshot; server lookup checks identity without reading foreign entities.
   */
  public List<String> names(UUID exclude, String prefix) {
    if (!active()) return List.of();
    String normalized = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
    List<String> result = new ArrayList<>();
    for (var entry : names.entrySet()) {
      CapturedName value = entry.getValue();
      if (plugin.getServer().getPlayer(entry.getKey()) != value.player) {
        names.remove(entry.getKey(), value);
      } else if (!entry.getKey().equals(exclude)
          && value.name.toLowerCase(Locale.ROOT).startsWith(normalized)) {
        result.add(value.name);
      }
    }
    result.sort(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder()));
    return List.copyOf(result);
  }

  @Override
  public void close() {
    synchronized (gate) {
      closed = true;
      names.clear();
      pending.clear();
    }
  }

  private static final class CapturedName {
    final Player player;
    final String name;

    CapturedName(Player player, String name) {
      this.player = player;
      this.name = name;
    }
  }

  private static final class PendingName {
    final Player player;

    PendingName(Player player) {
      this.player = player;
    }
  }
}
