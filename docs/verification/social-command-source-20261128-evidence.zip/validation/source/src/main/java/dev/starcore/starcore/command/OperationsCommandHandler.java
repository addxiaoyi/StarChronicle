package dev.starcore.starcore.command;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.health.ModuleHealthCenter;
import dev.starcore.starcore.core.health.ModuleHealthEntry;
import dev.starcore.starcore.core.health.ModuleHealthSnapshot;
import dev.starcore.starcore.foundation.economy.transaction.EvidenceReplayService;
import dev.starcore.starcore.foundation.economy.transaction.IncidentBundleResult;
import dev.starcore.starcore.foundation.economy.transaction.IncidentBundleService;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

/** Operator command surface for the cross-module health center. */
public final class OperationsCommandHandler implements CommandExecutor, TabCompleter {
  private final ModuleHealthCenter healthCenter;
  private final TransactionFabric transactionFabric;
  private final EvidenceReplayService evidenceReplay;
  private final IncidentBundleService incidentBundles;

  public OperationsCommandHandler(StarCoreContext context) {
    this.healthCenter = context.serviceRegistry().require(ModuleHealthCenter.class);
    this.transactionFabric = context.serviceRegistry().require(TransactionFabric.class);
    this.evidenceReplay = context.serviceRegistry().require(EvidenceReplayService.class);
    this.incidentBundles = context.serviceRegistry().require(IncidentBundleService.class);
  }

  OperationsCommandHandler(ModuleHealthCenter healthCenter, TransactionFabric transactionFabric) {
    this(healthCenter, transactionFabric, new EvidenceReplayService(transactionFabric), null);
  }

  OperationsCommandHandler(
      ModuleHealthCenter healthCenter,
      TransactionFabric transactionFabric,
      EvidenceReplayService evidenceReplay) {
    this(healthCenter, transactionFabric, evidenceReplay, null);
  }

  OperationsCommandHandler(
      ModuleHealthCenter healthCenter,
      TransactionFabric transactionFabric,
      EvidenceReplayService evidenceReplay,
      IncidentBundleService incidentBundles) {
    this.healthCenter = java.util.Objects.requireNonNull(healthCenter, "healthCenter");
    this.transactionFabric =
        java.util.Objects.requireNonNull(transactionFabric, "transactionFabric");
    this.evidenceReplay = java.util.Objects.requireNonNull(evidenceReplay, "evidenceReplay");
    this.incidentBundles = incidentBundles;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    String[] normalized = new String[args.length + 1];
    normalized[0] = "operations";
    System.arraycopy(args, 0, normalized, 1, args.length);
    handle(sender, normalized);
    return true;
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    if (!sender.hasPermission("starcore.admin")) return List.of();
    if (args.length == 1)
      return prefixMatches(List.of("health", "status", "replay", "timeline", "bundle"), args[0]);
    if (args.length == 2
        && ("replay".equalsIgnoreCase(args[0]) || "timeline".equalsIgnoreCase(args[0]))) {
      return List.of();
    }
    return List.of();
  }

  private static List<String> prefixMatches(List<String> values, String prefix) {
    String normalized = prefix == null ? "" : prefix.toLowerCase(java.util.Locale.ROOT);
    return values.stream().filter(value -> value.startsWith(normalized)).toList();
  }

  void handle(CommandSender sender, String[] args) {
    if (!sender.hasPermission("starcore.admin")) {
      sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
      return;
    }
    if (args.length < 2) {
      usage(sender);
      return;
    }
    switch (args[1].toLowerCase(java.util.Locale.ROOT)) {
      case "health", "status" ->
          health(sender, args.length > 2 && "modules".equalsIgnoreCase(args[2]));
      case "replay", "timeline" -> replay(sender, args);
      case "bundle", "export" -> bundle(sender, args);
      default -> usage(sender);
    }
  }

  private void bundle(CommandSender sender, String[] args) {
    if (incidentBundles == null) {
      sender.sendMessage(
          Component.text("Incident bundle service is unavailable.", NamedTextColor.RED));
      return;
    }
    if (args.length < 3) {
      sender.sendMessage(
          Component.text("Usage: /starcore ops bundle <transactionId>", NamedTextColor.YELLOW));
      return;
    }
    final java.util.UUID transactionId;
    try {
      transactionId = java.util.UUID.fromString(args[2]);
    } catch (IllegalArgumentException invalid) {
      sender.sendMessage(Component.text("Invalid transactionId.", NamedTextColor.RED));
      return;
    }
    try {
      IncidentBundleResult result = incidentBundles.create(transactionId);
      sender.sendMessage(
          Component.text(
              "Incident bundle created: path="
                  + result.archive()
                  + " entries="
                  + result.entries().size()
                  + " sha256="
                  + result.archiveSha256()
                  + " errors="
                  + result.errors().size(),
              result.complete() ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
      for (String error : result.errors()) {
        sender.sendMessage(
            Component.text("Bundle evidence warning: " + error, NamedTextColor.YELLOW));
      }
    } catch (IllegalArgumentException | IllegalStateException failure) {
      sender.sendMessage(
          Component.text("Incident bundle failed: " + failure.getMessage(), NamedTextColor.RED));
    }
  }

  private void replay(CommandSender sender, String[] args) {
    if (args.length < 3) {
      sender.sendMessage(
          Component.text("Usage: /starcore ops replay <transactionId>", NamedTextColor.YELLOW));
      return;
    }
    final java.util.UUID transactionId;
    try {
      transactionId = java.util.UUID.fromString(args[2]);
    } catch (IllegalArgumentException invalid) {
      sender.sendMessage(Component.text("Invalid transactionId.", NamedTextColor.RED));
      return;
    }
    var evidence = evidenceReplay.find(transactionId).orElse(null);
    if (evidence == null) {
      sender.sendMessage(Component.text("Transaction not found.", NamedTextColor.RED));
      return;
    }
    TransactionRecord record = evidence.transaction();
    sender.sendMessage(
        Component.text(
            "Transaction "
                + record.transactionId()
                + " owner="
                + record.owner()
                + " type="
                + record.type()
                + " state="
                + record.state()
                + " amount="
                + record.amount().toPlainString()
                + " correlation="
                + evidence.correlation(),
            NamedTextColor.GOLD));
    sender.sendMessage(
        Component.text("Evidence: correlation=" + evidence.correlation(), NamedTextColor.GRAY));
    if (!record.metadata().isEmpty()) {
      sender.sendMessage(
          Component.text(
              "Metadata: " + new java.util.TreeMap<>(record.metadata()), NamedTextColor.GRAY));
    }
    evidence
        .pendingRefund()
        .ifPresent(
            refund ->
                sender.sendMessage(
                    Component.text(
                        "Refund ledger: owner="
                            + refund.owner()
                            + " attempts="
                            + refund.attempts()
                            + " next="
                            + refund.nextAttemptAt()
                            + " manual="
                            + refund.manualReview()
                            + " error="
                            + refund.lastError(),
                        NamedTextColor.YELLOW)));
    for (var event : evidence.timeline()) {
      sender.sendMessage(
          Component.text(
              event.at() + " state=" + event.state() + " message=" + event.message(),
              NamedTextColor.GRAY));
    }
  }

  private void health(CommandSender sender, boolean details) {
    ModuleHealthSnapshot snapshot = healthCenter.snapshot();
    sender.sendMessage(
        Component.text(
            "STARCORE health: enabled="
                + snapshot.enabledModules()
                + " failed="
                + snapshot.failedModules()
                + " transactions="
                + snapshot.transactions().totalEntries()
                + " refunds="
                + snapshot.refunds().totalEntries(),
            snapshot.failedModules() == 0 ? NamedTextColor.GREEN : NamedTextColor.RED));
    sender.sendMessage(
        Component.text(
            "Recovery: txActive="
                + snapshot.transactions().activeEntries()
                + " txFailed="
                + snapshot.transactions().failedEntries()
                + " txManual="
                + snapshot.transactions().manualReviewEntries()
                + " refundDue="
                + snapshot.refunds().dueEntries()
                + " refundManual="
                + snapshot.refunds().manualReviewEntries()
                + " refundUnknown="
                + snapshot.refunds().unknownOwnerEntries(),
            NamedTextColor.GRAY));
    if (!details) return;
    for (ModuleHealthEntry module : snapshot.modules()) {
      NamedTextColor color =
          switch (module.status()) {
            case ENABLED -> NamedTextColor.GREEN;
            case FAILED -> NamedTextColor.RED;
            case REGISTERED, STARTING -> NamedTextColor.YELLOW;
            case DISABLED -> NamedTextColor.GRAY;
          };
      String failure = module.failureReason() == null ? "" : " error=" + module.failureReason();
      sender.sendMessage(
          Component.text(
              module.id() + " status=" + module.status() + " layer=" + module.layer() + failure,
              color));
    }
  }

  private void usage(CommandSender sender) {
    sender.sendMessage(
        Component.text(
            "Usage: /starcore ops <health|status> [modules] | replay <transactionId> | bundle"
                + " <transactionId>",
            NamedTextColor.YELLOW));
  }
}
