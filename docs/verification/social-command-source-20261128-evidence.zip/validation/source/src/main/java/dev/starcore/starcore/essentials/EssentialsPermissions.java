package dev.starcore.starcore.essentials;

import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

/** Configurable permission nodes shared by Essentials commands and menus. */
public record EssentialsPermissions(
    String warpUse,
    String warpSet,
    String warpDelete,
    String spawnUse,
    String setSpawn,
    String nickname,
    String nicknameColor,
    String balanceOthers,
    String economyAdmin) {

  public static EssentialsPermissions defaults() {
    return new EssentialsPermissions(
        "starcore.warp.use",
        "starcore.warp.set",
        "starcore.warp.delete",
        "starcore.spawn",
        "starcore.setspawn",
        "starcore.nick",
        "starcore.nick.color",
        "starcore.balance.others",
        "starcore.eco.admin");
  }

  /** Loads permission nodes from the supported Essentials config keys. */
  public static EssentialsPermissions from(FileConfiguration config) {
    EssentialsPermissions defaults = defaults();
    if (config == null) {
      return defaults;
    }
    return new EssentialsPermissions(
        permission(config, "essentials.permissions.warp.use", defaults.warpUse()),
        permission(config, "essentials.permissions.warp.set", defaults.warpSet()),
        permission(config, "essentials.permissions.warp.delete", defaults.warpDelete()),
        permission(config, "essentials.permissions.spawn.use", defaults.spawnUse()),
        permission(config, "essentials.permissions.spawn.set", defaults.setSpawn()),
        permission(config, "essentials.permissions.nickname.set", defaults.nickname()),
        permission(config, "essentials.permissions.nickname.color", defaults.nicknameColor()),
        permission(
            config, "essentials.permissions.economy.balance-others", defaults.balanceOthers()),
        permission(config, "essentials.permissions.economy.admin", defaults.economyAdmin()));
  }

  private static String permission(FileConfiguration config, String path, String fallback) {
    String value = config.getString(path);
    return value == null ? fallback : value.trim();
  }

  /** Empty permission nodes intentionally disable that permission check. */
  public static boolean permits(CommandSender sender, String permission) {
    return permission == null
        || permission.isBlank()
        || (sender != null && sender.hasPermission(permission));
  }
}
