package dev.starcore.starcore.core.guide;

/** 玩法指南章节定义 - 含主题和解锁条件 */
public enum GuideChapter {
  GETTING_STARTED("新手入门", "了解游戏基础玩法", 1, GuideTheme.GETTING_STARTED, UnlockCondition.ALWAYS),
  NATION_BUILDING(
      "国家建设", "创建或加入国家，发展壮大", 2, GuideTheme.NATION_BUILDING, UnlockCondition.NATION_MEMBER),
  ECONOMY_SYSTEM("经济系统", "税收、贸易、国库管理", 3, GuideTheme.ECONOMY, UnlockCondition.NATION_MEMBER),
  MILITARY_SYSTEM("军事系统", "军队组建、战争、防御", 4, GuideTheme.MILITARY, UnlockCondition.NATION_OFFICER),
  DIPLOMACY("外交系统", "同盟、外交关系、条约", 5, GuideTheme.DIPLOMACY, UnlockCondition.NATION_OFFICER),
  TECHNOLOGY("科技研究", "研究科技，提升国力", 6, GuideTheme.TECHNOLOGY, UnlockCondition.TECH_UNLOCKED),
  SOCIAL_LIFE("社交生活", "公会、组队、聊天", 7, GuideTheme.SOCIAL, UnlockCondition.ALWAYS),
  SPECIAL_FEATURES("特色玩法", "随机事件、副本、排行榜", 8, GuideTheme.SPECIAL, UnlockCondition.VETERAN);

  private final String title;
  private final String description;
  private final int order;
  private final GuideTheme theme;
  private final UnlockCondition unlockCondition;

  GuideChapter(
      String title,
      String description,
      int order,
      GuideTheme theme,
      UnlockCondition unlockCondition) {
    this.title = title;
    this.description = description;
    this.order = order;
    this.theme = theme;
    this.unlockCondition = unlockCondition;
  }

  public String getTitle() {
    return title;
  }

  public String getDescription() {
    return description;
  }

  public int getOrder() {
    return order;
  }

  public GuideTheme getTheme() {
    return theme;
  }

  public UnlockCondition getUnlockCondition() {
    return unlockCondition;
  }

  /** 解锁条件定义 */
  public enum UnlockCondition {
    ALWAYS("始终可见", 0),
    NATION_MEMBER("加入国家后解锁", 20),
    NATION_OFFICER("成为国家管理员后解锁", 50),
    TECH_UNLOCKED("解锁科技系统后解锁", 40),
    VETERAN("成为资深玩家后解锁", 30);

    private final String displayName;
    private final int progressThreshold;

    UnlockCondition(String displayName, int progressThreshold) {
      this.displayName = displayName;
      this.progressThreshold = progressThreshold;
    }

    public String getDisplayName() {
      return displayName;
    }

    public int getProgressThreshold() {
      return progressThreshold;
    }
  }
}
