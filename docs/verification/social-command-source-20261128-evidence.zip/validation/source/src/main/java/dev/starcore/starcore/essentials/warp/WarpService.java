package dev.starcore.starcore.essentials.warp;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import org.bukkit.Location;

/** 传送点系统 管理全服公共传送点 */
public final class WarpService {
  private static final Logger LOGGER = Logger.getLogger(WarpService.class.getName());
  private static final Pattern WARP_NAME_PATTERN = Pattern.compile("[a-zA-Z0-9_]+");
  private static final int MIN_NAME_LENGTH = 2;
  private static final int MAX_NAME_LENGTH = 20;

  // 所有传送点 名称 -> 位置 - 使用ConcurrentHashMap保证线程安全
  private volatile Map<String, Location> warps = new ConcurrentHashMap<>();

  /** 设置传送点 */
  public boolean setWarp(String name, Location location) {
    String normalizedName = normalizeName(name);
    if (normalizedName == null || location == null) {
      return false;
    }

    Location storedLocation = location.clone();
    if (storedLocation == null) {
      return false;
    }

    warps.put(normalizedName, storedLocation);
    return true;
  }

  /** 删除传送点 */
  public boolean deleteWarp(String name) {
    String normalizedName = normalizeName(name);
    if (normalizedName == null) {
      return false;
    }

    return warps.remove(normalizedName) != null;
  }

  /** 获取传送点 */
  public Optional<Location> getWarp(String name) {
    String normalizedName = normalizeName(name);
    if (normalizedName == null) {
      return Optional.empty();
    }

    Location location = warps.get(normalizedName);
    return location == null ? Optional.empty() : Optional.of(location.clone());
  }

  /** 获取所有传送点名称 */
  public List<String> getWarpNames() {
    return warps.keySet().stream().sorted().toList();
  }

  /** 检查传送点是否存在 */
  public boolean warpExists(String name) {
    String normalizedName = normalizeName(name);
    if (normalizedName == null) {
      return false;
    }

    return warps.containsKey(normalizedName);
  }

  /** 获取传送点数量 */
  public int getWarpCount() {
    return warps.size();
  }

  /** 加载数据 */
  public void loadData(Map<String, Location> data) {
    if (data == null || data.isEmpty()) {
      warps = new ConcurrentHashMap<>();
      return;
    }

    int invalidEntries = 0;
    int duplicateNames = 0;
    Map<String, Location> loadedWarps = new ConcurrentHashMap<>();
    List<Map.Entry<String, Location>> entries =
        data.entrySet().stream()
            .sorted(
                Comparator.comparing(Map.Entry::getKey, Comparator.nullsFirst(String::compareTo)))
            .toList();

    for (Map.Entry<String, Location> entry : entries) {
      String normalizedName = normalizeName(entry.getKey());
      Location location = entry.getValue();
      Location storedLocation = location == null ? null : location.clone();
      if (normalizedName == null || storedLocation == null) {
        invalidEntries++;
      } else if (loadedWarps.putIfAbsent(normalizedName, storedLocation) != null) {
        // If legacy data contains names differing only by case, the lexically first source key
        // wins so loading produces the same result regardless of the input map's iteration order.
        duplicateNames++;
      }
    }

    warps = loadedWarps;

    if (invalidEntries > 0 || duplicateNames > 0) {
      LOGGER.warning(
          "ESSENTIALS_WARP_LOAD_SKIPPED invalidEntries="
              + invalidEntries
              + " duplicateNames="
              + duplicateNames);
    }
  }

  /** 保存数据 */
  public Map<String, Location> saveData() {
    Map<String, Location> snapshot = new ConcurrentHashMap<>();
    warps.forEach(
        (name, location) -> {
          Location copy = location.clone();
          if (copy != null) {
            snapshot.put(name, copy);
          }
        });
    return snapshot;
  }

  /** 清空所有传送点 */
  public void clear() {
    warps.clear();
  }

  private static String normalizeName(String name) {
    if (!isValidWarpName(name)) {
      return null;
    }
    return name.toLowerCase(Locale.ROOT);
  }

  /** Returns whether a warp name can be safely used as a single YAML key segment. */
  public static boolean isValidWarpName(String name) {
    return name != null
        && name.length() >= MIN_NAME_LENGTH
        && name.length() <= MAX_NAME_LENGTH
        && WARP_NAME_PATTERN.matcher(name).matches();
  }
}
