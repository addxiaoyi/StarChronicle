package dev.starcore.starcore.integration.oraxen;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/**
 * Oraxen 集成 支持自定义物品、方块、家具、武器等
 *
 * <p>Oraxen 是另一个流行的自定义物品插件 官网: https://www.oraxen.com/
 */
public final class OraxenIntegration {
  private static final int MAX_STACK_SIZE = 64;

  private final Plugin plugin;
  private boolean enabled = false;
  private Class<?> oraxenItemsClass;
  private boolean testModeFlag = false;

  /** 测试钩子：当 {@link #getCustomItem} 在测试模式无法通过反射获取物品时使用。 */
  private java.util.function.Function<String, ItemStack> testItemProvider;

  public OraxenIntegration(Plugin plugin) {
    this.plugin = Objects.requireNonNull(plugin, "plugin");
  }

  /**
   * 初始化集成
   *
   * <p>如果存在 {@code starcore.test.enableOraxen} 系统属性且为 {@code true}，则跳过 Oraxen API 类加载检查
   * （仅用于测试环境，让集成测试可以模拟"已启用但 Oraxen JAR 不在 classpath"的情形）。
   */
  public boolean init() {
    enabled = false;
    oraxenItemsClass = null;
    try {
      // 检测 Oraxen 插件
      if (plugin.getServer().getPluginManager().getPlugin("Oraxen") == null) {
        plugin.getLogger().info("⚠ Oraxen 未安装");
        return false;
      }

      if (!plugin.getServer().getPluginManager().isPluginEnabled("Oraxen")) {
        plugin.getLogger().warning("⚠ Oraxen 已安装但未启用");
        return false;
      }

      // 测试模式：跳过 API 类加载，避免 ClassNotFoundException
      boolean testMode = "true".equalsIgnoreCase(System.getProperty("starcore.test.enableOraxen"));
      if (testMode) {
        // 测试模式：使用 Bukkit ItemStack 类作为占位，启用后 item 操作返回真实 ItemStack
        // 注意：反射调用会失败，测试通过 mock ItemStack 来绕过
        oraxenItemsClass = null; // 让反射方法在测试模式下走 mock 路径
        testModeFlag = true;
      } else {
        // 检查 API 类是否存在
        oraxenItemsClass = Class.forName("io.th0rgal.oraxen.api.OraxenItems");
        testModeFlag = false;
      }

      this.enabled = true;
      plugin.getLogger().info("✅ Oraxen 集成已启用" + (testMode ? " (test mode)" : ""));
      return true;

    } catch (ClassNotFoundException e) {
      plugin.getLogger().warning("⚠ Oraxen 集成初始化失败 code=ORAXEN_API_MISSING: API 未找到（可能版本不兼容）");
      return false;
    } catch (LinkageError e) {
      plugin.getLogger().warning("⚠ Oraxen 集成初始化失败 code=ORAXEN_API_LINKAGE: " + e.getMessage());
      return false;
    } catch (RuntimeException e) {
      plugin.getLogger().warning("⚠ Oraxen 集成初始化失败 code=ORAXEN_INIT_FAILURE: " + e.getMessage());
      return false;
    }
  }

  /** 检查是否为自定义物品 */
  public boolean isCustomItem(ItemStack item) {
    if (!enabled || item == null) {
      return false;
    }

    try {
      Class<?> oraxenItemsClass = apiClass();
      Object itemId = oraxenItemsClass.getMethod("getIdByItem", ItemStack.class).invoke(null, item);
      return itemId != null;
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin
          .getLogger()
          .fine("Oraxen item lookup failed code=ORAXEN_ITEM_LOOKUP_FAILURE: " + e.getMessage());
      return false;
    }
  }

  /** 获取自定义物品ID */
  public Optional<String> getCustomItemId(ItemStack item) {
    if (!enabled || item == null) {
      return Optional.empty();
    }

    try {
      Class<?> oraxenItemsClass = apiClass();
      Object itemId = oraxenItemsClass.getMethod("getIdByItem", ItemStack.class).invoke(null, item);
      return Optional.ofNullable(itemId != null ? itemId.toString() : null);
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin.getLogger().warning("获取 Oraxen 物品ID失败 code=ORAXEN_ITEM_ID_FAILURE: " + e.getMessage());
      return Optional.empty();
    }
  }

  /** 通过ID创建自定义物品 */
  public Optional<ItemStack> getCustomItem(String itemId) {
    if (!enabled || itemId == null || itemId.isBlank()) {
      return Optional.empty();
    }

    // 测试模式 + 注入的 provider：绕过反射
    if (testModeFlag && testItemProvider != null) {
      ItemStack item = testItemProvider.apply(itemId);
      return Optional.ofNullable(item);
    }

    try {
      Class<?> oraxenItemsClass = apiClass();
      Object itemBuilder =
          oraxenItemsClass.getMethod("getItemById", String.class).invoke(null, itemId);
      if (itemBuilder != null) {
        ItemStack item = (ItemStack) itemBuilder.getClass().getMethod("build").invoke(itemBuilder);
        return Optional.ofNullable(item);
      }
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin
          .getLogger()
          .warning(
              "创建 Oraxen 物品失败 code=ORAXEN_ITEM_BUILD_FAILURE (" + itemId + "): " + e.getMessage());
    }
    return Optional.empty();
  }

  /** 通过ID创建自定义物品（指定数量） */
  public Optional<ItemStack> getCustomItem(String itemId, int amount) {
    if (!enabled || itemId == null || itemId.isBlank() || amount <= 0) {
      return Optional.empty();
    }

    return getCustomItem(itemId)
        .map(
            item -> {
              item.setAmount(Math.min(amount, MAX_STACK_SIZE));
              return item;
            });
  }

  /** 给予玩家自定义物品 */
  public boolean giveCustomItem(Player player, String itemId, int amount) {
    if (!enabled || player == null || itemId == null || itemId.isBlank() || amount <= 0) {
      return false;
    }

    Optional<ItemStack> item = getCustomItem(itemId, amount);
    if (item.isEmpty()) {
      return false;
    }
    Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item.get());
    if (!leftovers.isEmpty()) {
      plugin.getLogger().warning("给予 Oraxen 物品未完成 code=ORAXEN_INVENTORY_OVERFLOW: " + itemId);
      return false;
    }
    return true;
  }

  /** 检查玩家是否拥有自定义物品 */
  public boolean hasCustomItem(Player player, String itemId) {
    if (!enabled || player == null || itemId == null || itemId.isBlank()) {
      return false;
    }

    try {
      Class<?> oraxenItemsClass = apiClass();
      for (ItemStack item : player.getInventory().getContents()) {
        if (item != null) {
          Object id = oraxenItemsClass.getMethod("getIdByItem", ItemStack.class).invoke(null, item);
          if (id != null && itemId.equals(id.toString())) {
            return true;
          }
        }
      }
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin
          .getLogger()
          .warning("检查 Oraxen 物品失败 code=ORAXEN_INVENTORY_LOOKUP_FAILURE: " + e.getMessage());
    }

    return false;
  }

  /** 检查自定义物品是否存在 */
  public boolean customItemExists(String itemId) {
    if (!enabled || itemId == null || itemId.isBlank()) {
      return false;
    }

    try {
      Class<?> oraxenItemsClass = apiClass();
      Object result = oraxenItemsClass.getMethod("exists", String.class).invoke(null, itemId);
      return result != null && (Boolean) result;
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin
          .getLogger()
          .fine(
              "Oraxen item existence lookup failed code=ORAXEN_EXISTS_LOOKUP_FAILURE: "
                  + e.getMessage());
      return false;
    }
  }

  private Class<?> apiClass() throws ClassNotFoundException {
    if (oraxenItemsClass == null) {
      throw new ClassNotFoundException("Oraxen API is not initialized");
    }
    return oraxenItemsClass;
  }

  /** 是否已启用 */
  public boolean isEnabled() {
    return enabled;
  }
}
