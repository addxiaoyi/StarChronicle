package dev.starcore.starcore.identity;

import java.util.*;

/** 代理令牌模型 代表玩家向另一个玩家授予的代理权 */
public record ProxyToken(
    String tokenId, // 令牌ID
    String grantorId, // 授予者ID
    String granteeId, // 被授予者ID
    String scope, // 代理范围
    long grantedAt, // 授予时间
    long expiresAt, // 过期时间
    boolean isActive, // 是否活跃
    Map<String, Object> metadata // 元数据
    ) {

  /** 创建代理令牌构建器 */
  public static Builder builder(String tokenId, String grantorId, String granteeId) {
    return new Builder(tokenId, grantorId, granteeId);
  }

  /** 检查令牌是否有效 */
  public boolean isValid() {
    return isActive && (expiresAt == 0 || System.currentTimeMillis() < expiresAt);
  }

  /** 检查是否在有效范围内 */
  public boolean isInScope(String action) {
    // 简化处理：如果scope为"all"则允许所有操作
    return "all".equals(scope);
  }

  /** 代理令牌构建器 */
  public static class Builder {
    private final String tokenId;
    private final String grantorId;
    private final String granteeId;
    private String scope = "all";
    private long grantedAt = System.currentTimeMillis();
    private long expiresAt = 0; // 永不过期
    private boolean isActive = true;
    private Map<String, Object> metadata = new HashMap<>();

    private Builder(String tokenId, String grantorId, String granteeId) {
      this.tokenId = Objects.requireNonNull(tokenId);
      this.grantorId = Objects.requireNonNull(grantorId);
      this.granteeId = Objects.requireNonNull(granteeId);
    }

    public Builder scope(String scope) {
      this.scope = scope;
      return this;
    }

    public Builder grantedAt(long grantedAt) {
      this.grantedAt = grantedAt;
      return this;
    }

    public Builder expiresAt(long expiresAt) {
      this.expiresAt = expiresAt;
      return this;
    }

    public Builder expiresIn(long millis) {
      this.expiresAt = System.currentTimeMillis() + millis;
      return this;
    }

    public Builder active(boolean active) {
      this.isActive = active;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public ProxyToken build() {
      return new ProxyToken(
          tokenId,
          grantorId,
          granteeId,
          scope,
          grantedAt,
          expiresAt,
          isActive,
          Map.copyOf(metadata));
    }
  }
}
