package dev.starcore.starcore.foundation.economy.transaction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import dev.starcore.starcore.core.health.ModuleHealthCenter;
import dev.starcore.starcore.core.health.ModuleHealthEntry;
import dev.starcore.starcore.core.health.ModuleHealthSnapshot;
import dev.starcore.starcore.core.metrics.CacheStats;
import dev.starcore.starcore.core.metrics.OperationStats;
import dev.starcore.starcore.core.metrics.PerformanceSnapshot;
import dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService;
import dev.starcore.starcore.foundation.economy.insurance.InsurancePolicy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Creates read-only, structured evidence bundles for one economy transaction. */
public final class IncidentBundleService {
    private static final int SCHEMA_VERSION = 1;
    private static final String MANIFEST = "manifest.json";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path outputDirectory;
    private final TransactionFabric transactions;
    private final RefundLedger refunds;
    private final EvidenceReplayService replay;
    private final ModuleHealthCenter healthCenter;
    private final EconomyInsuranceService insurance;
    private final Logger logger;
    private final CopyOnWriteArrayList<NamedProvider> providers = new CopyOnWriteArrayList<>();

    public IncidentBundleService(
            Path outputDirectory,
            TransactionFabric transactions,
            RefundLedger refunds,
            EvidenceReplayService replay,
            ModuleHealthCenter healthCenter,
            EconomyInsuranceService insurance,
            Logger logger) {
        this.outputDirectory = Objects.requireNonNull(outputDirectory, "outputDirectory");
        this.transactions = Objects.requireNonNull(transactions, "transactions");
        this.refunds = Objects.requireNonNull(refunds, "refunds");
        this.replay = Objects.requireNonNull(replay, "replay");
        this.healthCenter = Objects.requireNonNull(healthCenter, "healthCenter");
        this.insurance = Objects.requireNonNull(insurance, "insurance");
        this.logger = Objects.requireNonNull(logger, "logger");
    }

    public synchronized void registerArtifactProvider(
            String providerId, IncidentArtifactProvider provider) {
        if (providerId == null || providerId.isBlank()) {
            throw new IllegalArgumentException("providerId must not be blank");
        }
        providers.add(new NamedProvider(providerId, Objects.requireNonNull(provider, "provider")));
    }

    public IncidentBundleResult create(UUID transactionId) {
        Objects.requireNonNull(transactionId, "transactionId");
        TransactionRecord transaction =
                transactions
                        .find(transactionId)
                        .orElseThrow(
                                () ->
                                        new IllegalArgumentException(
                                                "Transaction not found: " + transactionId));
        EvidenceReplaySnapshot evidence =
                replay.find(transactionId)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Replay evidence disappeared: " + transactionId));
        ModuleHealthSnapshot health = healthCenter.snapshot();
        List<String> errors = new ArrayList<>();
        List<IncidentArtifact> artifacts = collectArtifacts(transactionId, transaction, errors);
        List<EvidenceReplayEvent> providerEvidence = replay.sourceEvidence(transactionId);

        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put("transaction.json", jsonBytes(transactionDocument(transaction)));
        entries.put("refund.json", jsonBytes(refundDocument(evidence)));
        entries.put("audit.json", jsonBytes(auditDocument(providerEvidence)));
        entries.put("domain-evidence.json", jsonBytes(domainDocument(providerEvidence, artifacts)));
        entries.put("health.json", jsonBytes(healthDocument(health)));
        entries.put("insurance.json", jsonBytes(insuranceDocument(transactionId)));

        entries.put(MANIFEST, jsonBytes(manifest(transactionId, transaction, entries, errors)));
        List<String> orderedEntries = entries.keySet().stream().sorted().toList();
        byte[] archiveBytes = zipBytes(entries, orderedEntries);

        try {
            Files.createDirectories(outputDirectory);
            Path normalizedOutput = outputDirectory.toAbsolutePath().normalize();
            Path archive = normalizedOutput.resolve(transactionId + ".zip").normalize();
            if (!archive.getParent().equals(normalizedOutput)) {
                throw new IllegalStateException("Incident bundle path escaped output directory");
            }
            Path temporary = archive.resolveSibling(archive.getFileName() + ".tmp");
            Files.write(
                    temporary,
                    archiveBytes,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
            try {
                Files.move(
                        temporary,
                        archive,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
                Files.move(temporary, archive, StandardCopyOption.REPLACE_EXISTING);
            }
            return new IncidentBundleResult(
                    transactionId, archive, sha256(archiveBytes), orderedEntries, errors);
        } catch (IOException exception) {
            throw new IllegalStateException(
                    "Unable to write incident bundle " + transactionId, exception);
        }
    }

    private List<IncidentArtifact> collectArtifacts(
            UUID transactionId, TransactionRecord transaction, List<String> errors) {
        List<IncidentArtifact> artifacts = new ArrayList<>();
        for (NamedProvider named : providers) {
            try {
                List<IncidentArtifact> provided =
                        named.provider().export(transactionId, transaction);
                if (provided != null) {
                    artifacts.addAll(provided);
                }
            } catch (RuntimeException failure) {
                String message = named.id() + ": " + safeMessage(failure);
                errors.add(message);
                logger.log(
                        Level.WARNING, "Incident artifact provider failed: " + named.id(), failure);
            }
        }
        return artifacts;
    }

    private Map<String, Object> manifest(
            UUID transactionId,
            TransactionRecord transaction,
            Map<String, byte[]> entries,
            List<String> errors) {
        Map<String, Object> manifest = new LinkedHashMap<>();
        manifest.put("schemaVersion", SCHEMA_VERSION);
        manifest.put("generatedAt", Instant.now().toString());
        manifest.put("transactionId", transactionId.toString());
        manifest.put("owner", transaction.owner().name());
        manifest.put("type", transaction.type().name());
        List<Map<String, Object>> files = new ArrayList<>();
        entries.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(
                        entry -> {
                            Map<String, Object> file = new LinkedHashMap<>();
                            file.put("name", entry.getKey());
                            file.put("bytes", entry.getValue().length);
                            file.put("sha256", sha256(entry.getValue()));
                            files.add(file);
                        });
        manifest.put("entries", files);
        manifest.put("errors", List.copyOf(errors));
        return manifest;
    }

    private Map<String, Object> transactionDocument(TransactionRecord transaction) {
        Map<String, Object> document = new LinkedHashMap<>();
        document.put("transactionId", transaction.transactionId().toString());
        document.put("accountId", transaction.accountId().toString());
        document.put("amount", transaction.amount().toPlainString());
        document.put("owner", transaction.owner().name());
        document.put("type", transaction.type().name());
        document.put("reason", transaction.reason());
        document.put("idempotencyKey", transaction.idempotencyKey());
        document.put("metadata", transaction.metadata());
        document.put("state", transaction.state().name());
        document.put("attempts", transaction.attempts());
        document.put("createdAt", transaction.createdAt().toString());
        document.put("updatedAt", transaction.updatedAt().toString());
        document.put("lastError", transaction.lastError());
        document.put(
                "timeline",
                transaction.events().stream()
                        .map(IncidentBundleService::transactionEvent)
                        .toList());
        return document;
    }

    private Map<String, Object> refundDocument(EvidenceReplaySnapshot evidence) {
        Map<String, Object> document = new LinkedHashMap<>();
        document.put("correlation", evidence.correlation().name());
        document.put(
                "entry", evidence.pendingRefund().map(IncidentBundleService::refund).orElse(null));
        document.put("summary", refundSummary(refunds.summarize(Instant.now())));
        return document;
    }

    private Map<String, Object> auditDocument(List<EvidenceReplayEvent> evidence) {
        return evidenceDocument(
                "audit-log",
                evidence.stream().filter(item -> item.source().equals("audit-log")).toList());
    }

    private Map<String, Object> domainDocument(
            List<EvidenceReplayEvent> providerEvidence, List<IncidentArtifact> artifacts) {
        List<Map<String, Object>> events =
                providerEvidence.stream()
                        .filter(item -> !item.source().equals("audit-log"))
                        .map(IncidentBundleService::replayEvent)
                        .collect(java.util.stream.Collectors.toCollection(ArrayList::new));
        for (IncidentArtifact artifact : artifacts) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("source", artifact.source());
            item.put("kind", artifact.kind());
            item.put(
                    "events",
                    artifact.events().stream().map(IncidentBundleService::replayEvent).toList());
            events.add(item);
        }
        Map<String, Object> document = new LinkedHashMap<>();
        document.put("events", events);
        document.put("providerCount", artifacts.size());
        return document;
    }

    private Map<String, Object> evidenceDocument(
            String source, List<EvidenceReplayEvent> evidence) {
        Map<String, Object> document = new LinkedHashMap<>();
        document.put("source", source);
        document.put("events", evidence.stream().map(IncidentBundleService::replayEvent).toList());
        return document;
    }

    private Map<String, Object> insuranceDocument(UUID transactionId) {
        Map<String, Object> document = new LinkedHashMap<>();
        List<InsurancePolicy> policies = insurance.evidenceForTransaction(transactionId);
        document.put(
                "policies", policies.stream().map(IncidentBundleService::insurancePolicy).toList());
        return document;
    }

    private Map<String, Object> healthDocument(ModuleHealthSnapshot snapshot) {
        Map<String, Object> document = new LinkedHashMap<>();
        document.put("capturedAt", snapshot.capturedAt().toString());
        document.put("enabledModules", snapshot.enabledModules());
        document.put("failedModules", snapshot.failedModules());
        document.put(
                "modules", snapshot.modules().stream().map(IncidentBundleService::module).toList());
        document.put("transactions", transactionSummary(snapshot.transactions()));
        document.put("refunds", refundSummary(snapshot.refunds()));
        document.put("performance", performance(snapshot.performance()));
        return document;
    }

    private static Map<String, Object> transactionEvent(TransactionEvent event) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("at", event.at().toString());
        item.put("state", event.state().name());
        item.put("message", event.message());
        return item;
    }

    private static Map<String, Object> refund(PendingRefund refund) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("transactionId", refund.transactionId().toString());
        item.put("accountId", refund.accountId().toString());
        item.put("amount", refund.amount().toPlainString());
        item.put("reason", refund.reason());
        item.put("attempts", refund.attempts());
        item.put("nextAttemptAt", refund.nextAttemptAt().toString());
        item.put("lastError", refund.lastError());
        item.put("manualReview", refund.manualReview());
        item.put("owner", refund.owner().name());
        return item;
    }

    private static Map<String, Object> refundSummary(RefundLedgerSummary summary) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("totalEntries", summary.totalEntries());
        item.put("dueEntries", summary.dueEntries());
        item.put("manualReviewEntries", summary.manualReviewEntries());
        item.put("unknownOwnerEntries", summary.unknownOwnerEntries());
        item.put(
                "ownerCounts",
                summary.ownerCounts().entrySet().stream()
                        .collect(
                                java.util.stream.Collectors.toMap(
                                        entry -> entry.getKey().name(),
                                        Map.Entry::getValue,
                                        (left, right) -> right,
                                        LinkedHashMap::new)));
        item.put(
                "oldestNextAttemptAt",
                summary.oldestNextAttemptAt().map(Instant::toString).orElse(null));
        return item;
    }

    private static Map<String, Object> transactionSummary(TransactionSummary summary) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("totalEntries", summary.totalEntries());
        item.put("activeEntries", summary.activeEntries());
        item.put("manualReviewEntries", summary.manualReviewEntries());
        item.put("failedEntries", summary.failedEntries());
        item.put(
                "ownerCounts",
                summary.ownerCounts().entrySet().stream()
                        .collect(
                                java.util.stream.Collectors.toMap(
                                        entry -> entry.getKey().name(),
                                        Map.Entry::getValue,
                                        (left, right) -> right,
                                        LinkedHashMap::new)));
        item.put(
                "typeCounts",
                summary.typeCounts().entrySet().stream()
                        .collect(
                                java.util.stream.Collectors.toMap(
                                        entry -> entry.getKey().name(),
                                        Map.Entry::getValue,
                                        (left, right) -> right,
                                        LinkedHashMap::new)));
        item.put("oldestUpdatedAt", summary.oldestUpdatedAt().map(Instant::toString).orElse(null));
        return item;
    }

    private static Map<String, Object> module(ModuleHealthEntry module) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("id", module.id());
        item.put("displayName", module.displayName());
        item.put("layer", module.layer().name());
        item.put("status", module.status().name());
        item.put("lastChangedAt", module.lastChangedAt().toString());
        item.put("failureReason", module.failureReason());
        item.put("dependencies", module.dependencies());
        return item;
    }

    private static Map<String, Object> performance(PerformanceSnapshot snapshot) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("timestamp", snapshot.timestamp().toString());
        item.put("uptimeMillis", snapshot.uptime().toMillis());
        item.put(
                "operations",
                snapshot.operations().entrySet().stream()
                        .sorted(Map.Entry.comparingByKey())
                        .collect(
                                java.util.stream.Collectors.toMap(
                                        Map.Entry::getKey,
                                        entry -> operation(entry.getValue()),
                                        (left, right) -> right,
                                        LinkedHashMap::new)));
        item.put(
                "caches",
                snapshot.caches().entrySet().stream()
                        .sorted(Map.Entry.comparingByKey())
                        .collect(
                                java.util.stream.Collectors.toMap(
                                        Map.Entry::getKey,
                                        entry -> cache(entry.getValue()),
                                        (left, right) -> right,
                                        LinkedHashMap::new)));
        return item;
    }

    private static Map<String, Object> operation(OperationStats stats) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("calls", stats.calls());
        item.put("averageNanos", stats.averageDuration().toNanos());
        item.put("minNanos", stats.minDuration().toNanos());
        item.put("maxNanos", stats.maxDuration().toNanos());
        return item;
    }

    private static Map<String, Object> cache(CacheStats stats) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("hits", stats.hits());
        item.put("misses", stats.misses());
        item.put("hitRate", stats.hitRate());
        return item;
    }

    private static Map<String, Object> replayEvent(EvidenceReplayEvent event) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("source", event.source());
        item.put("at", event.at().toString());
        item.put("state", event.state());
        item.put("message", event.message());
        return item;
    }

    private static Map<String, Object> insurancePolicy(InsurancePolicy policy) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("policyId", policy.policyId().toString());
        item.put("playerId", policy.playerId().toString());
        item.put("coverage", policy.coverage().name());
        item.put("maxPayout", policy.maxPayout().toPlainString());
        item.put("deductible", policy.deductible().toPlainString());
        item.put("premium", policy.premium().toPlainString());
        item.put("startsAt", policy.startsAt().toString());
        item.put("expiresAt", policy.expiresAt().toString());
        item.put("state", policy.state().name());
        item.put(
                "claimSourceTransactionId",
                Optional.ofNullable(policy.claimSourceTransactionId())
                        .map(UUID::toString)
                        .orElse(null));
        item.put(
                "payoutTransactionId",
                Optional.ofNullable(policy.payoutTransactionId()).map(UUID::toString).orElse(null));
        item.put("lastError", policy.lastError());
        return item;
    }

    private static byte[] jsonBytes(Object value) {
        return (GSON.toJson(value) + System.lineSeparator()).getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] zipBytes(Map<String, byte[]> entries, List<String> orderedEntries) {
        try (ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                OutputStream output = buffer;
                ZipOutputStream zip = new ZipOutputStream(output, StandardCharsets.UTF_8)) {
            for (String entryName : orderedEntries) {
                ZipEntry entry = new ZipEntry(entryName);
                entry.setTime(0L);
                zip.putNextEntry(entry);
                zip.write(entries.get(entryName));
                zip.closeEntry();
            }
            zip.finish();
            return buffer.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to build incident bundle archive", exception);
        }
    }

    private static String sha256(byte[] content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content);
            StringBuilder result = new StringBuilder(hash.length * 2);
            for (byte value : hash) {
                result.append(String.format("%02x", value));
            }
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is unavailable", impossible);
        }
    }

    private static String safeMessage(RuntimeException failure) {
        String message = failure.getMessage();
        return message == null || message.isBlank() ? failure.getClass().getSimpleName() : message;
    }

    private record NamedProvider(String id, IncidentArtifactProvider provider) {}
}
