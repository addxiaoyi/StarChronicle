package dev.starcore.starcore.foundation.economy.transaction;

/** Canonical business operation types tracked by the transaction fabric. */
public enum TransactionType {
  DUNGEON_ENTRY_FEE,
  DUNGEON_REWARD,
  DONATION,
  TRADE,
  SHOP_PURCHASE,
  SHOP_SALE,
  AUCTION_BID,
  NATION_OPERATION,
  WAR_REPARATION,
  RENT_SETTLEMENT,
  INSURANCE_PAYOUT,
  MERCENARY_HIRE,
  MERCENARY_RENEWAL,
  PLAYER_TRANSFER,
  OTHER
}
