package dev.starcore.starcore.foundation.territory.model;

import java.io.Serializable;
import java.util.Objects;

public record ChunkCoordinate(String world, int x, int z) implements Serializable {
  public ChunkCoordinate {
    Objects.requireNonNull(world, "world");
  }

  @Override
  public String toString() {
    return world + ':' + x + ':' + z;
  }
}
