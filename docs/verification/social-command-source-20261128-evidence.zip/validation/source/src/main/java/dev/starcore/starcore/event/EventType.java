package dev.starcore.starcore.event;

/** 事件类型枚举 定义剧情事件的不同类别 */
public enum EventType {
  /** 主线必经事件：必须形成正式结论或缺省补偿 */
  main("主线", "必经剧情事件"),

  /** 公共事件：全服选择、听证、迁移，单一正式运行，多时段参与 */
  public_event("公共", "全服选择、听证、迁移"),

  /** 支线事件：补充证据与人物线，可错过，必须有知识补偿 */
  side("支线", "补充证据与人物线"),

  /** 可复刻事件：资源、训练、日常副本，单次结果不直接改写公共选择 */
  repeatable("可复刻", "资源、训练、日常副本"),

  /** 归档复演：补看、追赶、无奖励复演，不伪造亲历或全服状态 */
  archive_replay("归档复演", "补看、追赶复演"),

  /** 原型事件：镜像、隔离试验，不进入正史，除非显式采纳结果 */
  prototype("原型", "镜像、隔离试验");

  private final String displayName;
  private final String description;

  EventType(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 是否为必须事件 */
  public boolean isRequired() {
    return this == main || this == public_event;
  }

  /** 是否为全服事件 */
  public boolean isGlobal() {
    return this == main || this == public_event;
  }

  /** 是否可复现 */
  public boolean isReplayable() {
    return this == archive_replay || this == prototype || this == repeatable;
  }
}
