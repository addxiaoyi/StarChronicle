package dev.starcore.starcore.core.extension;

/** 扩展点元数据 存储扩展点的基本信息 */
public record ExtensionMetadata(
    String id,
    String name,
    String description,
    long registrationTime,
    String version,
    String author) {

  public ExtensionMetadata(String id, String name, String description, long registrationTime) {
    this(id, name, description, registrationTime, "1.0.0", "System");
  }

  public ExtensionMetadata withVersion(String version) {
    return new ExtensionMetadata(id, name, description, registrationTime, version, author);
  }

  public ExtensionMetadata withAuthor(String author) {
    return new ExtensionMetadata(id, name, description, registrationTime, version, author);
  }
}
