package dev.starcore.starcore.core.event;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/** 事件桥接器 - 跨系统事件通信 实现系统间的解耦事件传递和处理 */
public class EventBridge {

  private static final int MAX_DEPTH = 32;
  private static final int MAX_PAYLOAD_SIZE = 1024 * 1024; // 1MB payload limit
  private static final int MAX_SUBSCRIBERS_PER_TYPE = 1000;
  private static final int MAX_PUBLISH_PER_SECOND_PER_THREAD = 1000;
  private static final int RATE_WINDOW_MS = 1000;

  private final ThreadLocal<Integer> publishDepth = ThreadLocal.withInitial(() -> 0);
  private final Map<String, List<Consumer<Object>>> eventSubscribers = new ConcurrentHashMap<>();
  private final ExecutorService asyncExecutor;
  // 速率限制：线程局部计数器，重置周期为1秒
  private final ThreadLocal<Long> lastRateCheckTime = new ThreadLocal<>();
  private final ThreadLocal<Integer> publishCountInWindow = ThreadLocal.withInitial(() -> 0);

  /** 使用自定义线程池的构造函数 */
  public EventBridge() {
    // 创建有界的线程池，防止资源耗尽
    this.asyncExecutor =
        new ThreadPoolExecutor(
            Runtime.getRuntime().availableProcessors() * 2,
            Runtime.getRuntime().availableProcessors() * 2,
            60L,
            TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(256),
            r -> {
              Thread t = new Thread(r, "EventBridge-Async");
              t.setDaemon(true);
              return t;
            },
            new ThreadPoolExecutor.CallerRunsPolicy() // 拒绝策略：在调用线程执行，防止丢失事件
            );
  }

  /**
   * 订阅事件
   *
   * @param eventType 事件类型
   * @param handler 事件处理器
   * @return 取消订阅的Runnable
   */
  public Runnable subscribe(String eventType, Consumer<Object> handler) {
    if (eventType == null || handler == null) {
      throw new IllegalArgumentException("Event type and handler cannot be null");
    }

    // 使用CopyOnWriteArrayList确保线程安全
    List<Consumer<Object>> handlers =
        eventSubscribers.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>());

    // 防止重复订阅
    if (handlers.contains(handler)) {
      return () -> {}; // 空操作
    }

    handlers.add(handler);

    // 返回取消订阅的Runnable
    return () -> unsubscribe(eventType, handler);
  }

  /**
   * 取消订阅
   *
   * @param eventType 事件类型
   * @param handler 事件处理器
   */
  public void unsubscribe(String eventType, Consumer<Object> handler) {
    if (eventType == null || handler == null) return;

    List<Consumer<Object>> handlers = eventSubscribers.get(eventType);
    if (handlers != null) {
      handlers.remove(handler);
      // 清理空列表
      if (handlers.isEmpty()) {
        eventSubscribers.remove(eventType);
      }
    }
  }

  /** 速率限制检查：每线程每秒最多 MAX_PUBLISH_PER_SECOND_PER_THREAD 次发布 */
  private boolean checkRateLimit() {
    long now = System.currentTimeMillis();
    Long lastCheck = lastRateCheckTime.get();
    if (lastCheck == null || now - lastCheck >= RATE_WINDOW_MS) {
      lastRateCheckTime.set(now);
      publishCountInWindow.set(1);
      return true;
    }
    int count = publishCountInWindow.get();
    if (count >= MAX_PUBLISH_PER_SECOND_PER_THREAD) {
      return false;
    }
    publishCountInWindow.set(count + 1);
    return true;
  }

  /** 验证事件数据大小 */
  private void validatePayload(Object eventData) {
    if (eventData == null) return;

    // 简单的大小估计
    String dataStr = eventData.toString();
    if (dataStr.length() > MAX_PAYLOAD_SIZE) {
      throw new IllegalArgumentException(
          "Event payload too large: "
              + dataStr.length()
              + " bytes (max: "
              + MAX_PAYLOAD_SIZE
              + ")");
    }
  }

  /**
   * 发布事件
   *
   * @param eventType 事件类型
   * @param eventData 事件数据
   */
  public void publish(String eventType, Object eventData) {
    if (eventType == null) return;

    // 速率限制：防止事件洪泛攻击
    if (!checkRateLimit()) {
      java.util.logging.Logger.getLogger(EventBridge.class.getName())
          .warning("Event publish rate limit exceeded for " + eventType + ", dropping event");
      return;
    }

    // 防止递归发布
    int depth = publishDepth.get();
    if (depth >= MAX_DEPTH) {
      java.util.logging.Logger.getLogger(EventBridge.class.getName())
          .warning("Event recursion depth exceeded for " + eventType + ": " + depth);
      return;
    }

    try {
      publishDepth.set(depth + 1);

      // 验证payload大小
      validatePayload(eventData);

      List<Consumer<Object>> handlers = eventSubscribers.get(eventType);
      if (handlers != null && !handlers.isEmpty()) {
        // 限制订阅者数量
        if (handlers.size() > MAX_SUBSCRIBERS_PER_TYPE) {
          java.util.logging.Logger.getLogger(EventBridge.class.getName())
              .warning("Too many subscribers for event type: " + eventType);
          return;
        }

        // 使用快照迭代，避免ConcurrentModificationException
        List<Consumer<Object>> snapshot = new ArrayList<>(handlers);
        for (Consumer<Object> handler : snapshot) {
          try {
            handler.accept(eventData);
          } catch (Exception e) {
            System.getLogger(EventBridge.class.getName())
                .log(
                    System.Logger.Level.ERROR,
                    "EventBridge handler failed for event type: "
                        + eventType
                        + ", data class: "
                        + (eventData != null ? eventData.getClass().getName() : "null")
                        + ", handler: "
                        + handler.getClass().getName(),
                    e);
          } catch (Error e) {
            System.getLogger(EventBridge.class.getName())
                .log(
                    System.Logger.Level.ERROR,
                    "Critical error in EventBridge handler for event type: "
                        + eventType
                        + ", data class: "
                        + (eventData != null ? eventData.getClass().getName() : "null")
                        + ", handler: "
                        + handler.getClass().getName(),
                    e);
            // 重新抛出 Error，因为这通常是严重问题（如 OutOfMemoryError）
            throw e;
          }
        }
      }
    } finally {
      publishDepth.set(depth);
    }
  }

  /**
   * 发布事件（异步）
   *
   * @param eventType 事件类型
   * @param eventData 事件数据
   * @return 异步完成的CompletableFuture
   */
  public CompletableFuture<Void> publishAsync(String eventType, Object eventData) {
    if (eventType == null) {
      return CompletableFuture.completedFuture(null);
    }

    return CompletableFuture.runAsync(
        () -> {
          try {
            publish(eventType, eventData);
          } catch (Exception e) {
            System.getLogger(EventBridge.class.getName())
                .log(
                    System.Logger.Level.ERROR,
                    "Async event publishing failed for event type: "
                        + eventType
                        + ", data class: "
                        + (eventData != null ? eventData.getClass().getName() : "null"),
                    e);
          }
        },
        asyncExecutor);
  }

  /**
   * 获取订阅者数量
   *
   * @param eventType 事件类型
   * @return 订阅者数量
   */
  public int getSubscriberCount(String eventType) {
    return eventSubscribers.getOrDefault(eventType, Collections.emptyList()).size();
  }

  /**
   * 获取所有事件类型
   *
   * @return 事件类型集合
   */
  public Set<String> getAllEventTypes() {
    return Set.copyOf(eventSubscribers.keySet());
  }

  /** 清空所有订阅 */
  public void clearAllSubscriptions() {
    eventSubscribers.clear();
  }

  /**
   * 清空特定事件类型的订阅
   *
   * @param eventType 事件类型
   */
  public void clearSubscriptions(String eventType) {
    if (eventType != null) {
      eventSubscribers.remove(eventType);
    }
  }

  /** 关闭异步执行器 */
  public void shutdown() {
    asyncExecutor.shutdown();
    try {
      if (!asyncExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
        asyncExecutor.shutdownNow();
      }
    } catch (InterruptedException e) {
      asyncExecutor.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }

  /** 事件类型常量 */
  public static class EventTypes {
    // Boss系统事件
    public static final String BOSS_SPAWN = "boss.spawn";
    public static final String BOSS_DEFEATED = "boss.defeated";
    public static final String BOSS_DEATH = "boss.death";
    public static final String BOSS_HEALTH_CHANGE = "boss.health_change";

    // 烹调系统事件
    public static final String COOKING_START = "cooking.start";
    public static final String COOKING_COMPLETE = "cooking.complete";
    public static final String COOKING_FAIL = "cooking.fail";
    public static final String RECIPE_UNLOCK = "recipe.unlock";

    // 裂隙系统事件
    public static final String RIFT_OPEN = "rift.open";
    public static final String RIFT_CLOSE = "rift.close";
    public static final String RIFT_ENTER = "rift.enter";
    public static final String RIFT_EXIT = "rift.exit";
    public static final String RIFT_COMPLETE = "rift.complete";

    // 纪元系统事件
    public static final String EPOCH_START = "epoch.start";
    public static final String EPOCH_END = "epoch.end";
    public static final String EPOCH_TRANSITION = "epoch.transition";
    public static final String EPOCH_MILESTONE = "epoch.milestone";

    // 玩家相关事件
    public static final String PLAYER_JOIN = "player.join";
    public static final String PLAYER_QUIT = "player.quit";
    public static final String PLAYER_LEVEL_UP = "player.level_up";
    public static final String PLAYER_ACHIEVEMENT = "player.achievement";

    // 系统事件
    public static final String SYSTEM_READY = "system.ready";
    public static final String SYSTEM_SHUTDOWN = "system.shutdown";
    public static final String CONFIG_RELOAD = "config.reload";
  }
}
