package dev.starcore.starcore.foundation.economy.transaction;

import java.util.List;
import java.util.Objects;

/** Structured, read-only domain evidence included in an incident bundle. */
public record IncidentArtifact(String source, String kind, List<EvidenceReplayEvent> events) {
    public IncidentArtifact {
        if (source == null || source.isBlank()) {
            throw new IllegalArgumentException("source must not be blank");
        }
        if (kind == null || kind.isBlank()) {
            throw new IllegalArgumentException("kind must not be blank");
        }
        events = List.copyOf(Objects.requireNonNull(events, "events"));
    }
}
