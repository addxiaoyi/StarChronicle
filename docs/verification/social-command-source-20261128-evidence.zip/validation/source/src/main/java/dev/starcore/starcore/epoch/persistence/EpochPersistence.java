package dev.starcore.starcore.epoch.persistence;

import dev.starcore.starcore.epoch.Epoch;
import dev.starcore.starcore.epoch.EpochState;
import dev.starcore.starcore.persistence.DataStore;
import dev.starcore.starcore.persistence.StorageKey;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 纪元系统持久化存储 处理纪元实例的保存与加载 */
public class EpochPersistence {

  private final DataStore dataStore;
  private final Map<String, Epoch> instanceCache = new ConcurrentHashMap<>();

  public EpochPersistence(DataStore dataStore) {
    this.dataStore = dataStore;
  }

  /** 保存纪元实例 */
  public void saveEpoch(Epoch epoch) {
    instanceCache.put(epoch.epochRunId(), epoch);
    dataStore.save(StorageKey.EPOCH_INSTANCES, epoch);
  }

  /** 批量保存纪元实例 */
  public void saveAllEpochs(Collection<Epoch> epochs) {
    epochs.forEach(e -> instanceCache.put(e.epochRunId(), e));
    dataStore.saveAll(StorageKey.EPOCH_INSTANCES, new ArrayList<>(epochs));
  }

  /** 加载纪元实例 */
  public Optional<Epoch> loadEpoch(String epochId) {
    return Optional.ofNullable(
        instanceCache.computeIfAbsent(
            epochId,
            k ->
                dataStore.loadAll(StorageKey.EPOCH_INSTANCES, Epoch.class).stream()
                    .filter(e -> e.epochRunId().equals(epochId))
                    .findFirst()
                    .orElse(null)));
  }

  /** 加载所有纪元实例 */
  public List<Epoch> loadAllEpochs() {
    List<Epoch> epochs = dataStore.loadAll(StorageKey.EPOCH_INSTANCES, Epoch.class);
    epochs.forEach(e -> instanceCache.put(e.epochRunId(), e));
    return epochs;
  }

  /** 删除纪元实例 */
  public void deleteEpoch(String epochId) {
    instanceCache.remove(epochId);
    dataStore.delete(StorageKey.EPOCH_INSTANCES, epochId);
  }

  /** 清空缓存 */
  public void clearCache() {
    instanceCache.clear();
  }

  /** 获取活跃纪元 */
  public List<Epoch> getActiveEpochs() {
    return loadAllEpochs().stream()
        .filter(e -> e.state() == EpochState.active || e.state() == EpochState.preparing)
        .toList();
  }

  /** 获取已完成纪元 */
  public List<Epoch> getCompletedEpochs() {
    return loadAllEpochs().stream()
        .filter(e -> e.state() == EpochState.archived || e.state() == EpochState.completed)
        .toList();
  }

  /** 获取按状态分组的纪元 */
  public Map<EpochState, List<Epoch>> getEpochsByState() {
    Map<EpochState, List<Epoch>> result = new HashMap<>();
    loadAllEpochs()
        .forEach(epoch -> result.computeIfAbsent(epoch.state(), k -> new ArrayList<>()).add(epoch));
    return result;
  }

  /** 获取最近完成的纪元 */
  public Optional<Epoch> getLatestCompletedEpoch() {
    return getCompletedEpochs().stream()
        .filter(e -> e.archivedAt() != null)
        .min(Comparator.comparing(Epoch::archivedAt));
  }
}
