package dev.starcore.starcore.choice;

import java.util.*;

/** 公共选择实例模型 表示一个正在运行的选择实例 */
public record ChoiceInstance(
    String instanceId, // 实例ID
    String choiceId, // 选择定义ID
    String epochRunId, // 纪元运行ID
    ChoiceStatus status, // 当前状态
    Map<String, ChoiceDefinition.Option> options, // 选项集合
    Set<String> participants, // 参与者集合
    List<String> minorityOpinions, // 少数意见
    String selectedOption, // 已选选项
    int proposalVersion, // 提案版本
    long createdAt, // 创建时间
    long updatedAt, // 更新时间
    Map<String, String> votes // playerId -> optionId 投票记录
    ) {

  /** 创建选择实例构建器 */
  public static Builder builder(String instanceId, String choiceId) {
    return new Builder(instanceId, choiceId);
  }

  /** 检查是否已选定 */
  public boolean isSelected() {
    return status == ChoiceStatus.selected || status == ChoiceStatus.provisional;
  }

  /** 检查是否处于投票阶段 */
  public boolean isVoting() {
    return status == ChoiceStatus.participation_open || status == ChoiceStatus.participation_closed;
  }

  /** 获取每个选项的支持人数 */
  public Map<String, Integer> getVoteCounts() {
    Map<String, Integer> counts = new HashMap<>();
    for (String optionId : options.keySet()) {
      counts.put(optionId, 0);
    }
    for (String votedOption : votes.values()) {
      counts.merge(votedOption, 1, Integer::sum);
    }
    return counts;
  }

  /** 检查选项是否被选中 */
  public boolean isOptionSelected(String optionId) {
    return selectedOption != null && selectedOption.equals(optionId);
  }

  /** 选择实例构建器 */
  public static class Builder {
    private final String instanceId;
    private final String choiceId;
    private String epochRunId;
    private ChoiceStatus status = ChoiceStatus.drafting;
    private Map<String, ChoiceDefinition.Option> options = new LinkedHashMap<>();
    private Set<String> participants = new HashSet<>();
    private List<String> minorityOpinions = new ArrayList<>();
    private String selectedOption;
    private int proposalVersion = 1;
    private Map<String, String> votes = new HashMap<>();
    private long createdAt = System.currentTimeMillis();
    private long updatedAt = System.currentTimeMillis();

    private Builder(String instanceId, String choiceId) {
      this.instanceId = Objects.requireNonNull(instanceId);
      this.choiceId = Objects.requireNonNull(choiceId);
    }

    public Builder epochRunId(String epochRunId) {
      this.epochRunId = epochRunId;
      return this;
    }

    public Builder status(ChoiceStatus status) {
      this.status = status;
      return this;
    }

    public Builder options(Map<String, ChoiceDefinition.Option> options) {
      this.options = new LinkedHashMap<>(options);
      return this;
    }

    public Builder addOption(ChoiceDefinition.Option option) {
      this.options.put(option.optionId(), option);
      return this;
    }

    public Builder addOption(String optionId, String description) {
      this.options.put(optionId, ChoiceDefinition.Option.of(optionId, description));
      return this;
    }

    public Builder addVote(String playerId, String optionId) {
      this.votes.put(playerId, optionId);
      return this;
    }

    public Builder votes(Map<String, String> votes) {
      this.votes = new HashMap<>(votes);
      return this;
    }

    public Builder addParticipant(String participant) {
      this.participants.add(participant);
      return this;
    }

    public Builder participants(Set<String> participants) {
      this.participants = new HashSet<>(participants);
      return this;
    }

    public Builder addMinorityOpinion(String opinion) {
      this.minorityOpinions.add(opinion);
      return this;
    }

    public Builder minorityOpinions(List<String> opinions) {
      this.minorityOpinions = new ArrayList<>(opinions);
      return this;
    }

    public Builder selectedOption(String selectedOption) {
      this.selectedOption = selectedOption;
      return this;
    }

    public Builder proposalVersion(int proposalVersion) {
      this.proposalVersion = proposalVersion;
      return this;
    }

    public Builder createdAt(long createdAt) {
      this.createdAt = createdAt;
      return this;
    }

    public Builder updatedAt(long updatedAt) {
      this.updatedAt = updatedAt;
      return this;
    }

    public ChoiceInstance build() {
      return new ChoiceInstance(
          instanceId,
          choiceId,
          epochRunId,
          status,
          Map.copyOf(options),
          Set.copyOf(participants),
          List.copyOf(minorityOpinions),
          selectedOption,
          proposalVersion,
          createdAt,
          updatedAt,
          votes.isEmpty() ? Map.of() : Map.copyOf(votes));
    }
  }
}
