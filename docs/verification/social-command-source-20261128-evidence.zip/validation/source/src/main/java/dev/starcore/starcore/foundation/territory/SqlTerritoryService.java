package dev.starcore.starcore.foundation.territory;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.foundation.territory.model.ChunkCoordinate;
import dev.starcore.starcore.foundation.territory.model.TerritoryClaim;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.sql.DataSource;

public final class SqlTerritoryService implements TerritoryService {
  private static final String NAMESPACE = "territory";
  private static final String FILE_NAME = "claims.properties";
  private static final String TABLE_NAME = "starcore_territory_claims";

  private final Supplier<Optional<DataSource>> dataSourceSupplier;
  private final Supplier<Collection<TerritoryClaim>> legacyClaimSupplier;
  private final Logger logger;
  private final ConcurrentMap<ChunkCoordinate, TerritoryClaim> claims = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, Set<ChunkCoordinate>> ownerIndex = new ConcurrentHashMap<>();

  // 异步操作支持：同一坐标严格按调用顺序串行持久化。
  private final Object persistenceLock = new Object();
  private final ConcurrentMap<ChunkCoordinate, CompletableFuture<Void>> pendingOperations =
      new ConcurrentHashMap<>();
  private final ExecutorService persistenceExecutor;
  private final AtomicBoolean closed = new AtomicBoolean(false);

  // 统计信息
  private volatile int cacheHits = 0;
  private volatile int cacheMisses = 0;

  public SqlTerritoryService(
      DatabaseService databaseService, PersistenceService persistenceService, Logger logger) {
    this(
        databaseService::dataSource,
        () ->
            TerritoryStateCodec.fromProperties(
                    persistenceService.loadProperties(NAMESPACE, FILE_NAME))
                .values(),
        logger);
  }

  SqlTerritoryService(
      Supplier<Optional<DataSource>> dataSourceSupplier,
      Supplier<Collection<TerritoryClaim>> legacyClaimSupplier,
      Logger logger) {
    this.dataSourceSupplier = Objects.requireNonNull(dataSourceSupplier, "dataSourceSupplier");
    this.legacyClaimSupplier = Objects.requireNonNull(legacyClaimSupplier, "legacyClaimSupplier");
    this.logger = Objects.requireNonNull(logger, "logger");
    this.persistenceExecutor =
        Executors.newSingleThreadExecutor(
            runnable -> {
              Thread thread = new Thread(runnable, "starcore-territory-persistence");
              thread.setDaemon(true);
              return thread;
            });
    initialize();
  }

  @Override
  public synchronized Optional<TerritoryClaim> claimAt(ChunkCoordinate coordinate) {
    Objects.requireNonNull(coordinate, "coordinate");

    // 首先检查缓存
    TerritoryClaim cached = claims.get(coordinate);
    if (cached != null) {
      cacheHits++;
      return Optional.of(cached);
    }

    cacheMisses++;
    return Optional.empty();
  }

  @Override
  public synchronized boolean isClaimed(ChunkCoordinate coordinate) {
    Objects.requireNonNull(coordinate, "coordinate");
    return claims.containsKey(coordinate);
  }

  @Override
  public synchronized boolean claim(String ownerId, ChunkCoordinate coordinate) {
    Objects.requireNonNull(ownerId, "ownerId");
    Objects.requireNonNull(coordinate, "coordinate");
    ensureOpen();

    if (claims.containsKey(coordinate)) {
      return false;
    }

    TerritoryClaim claim = new TerritoryClaim(ownerId, coordinate);
    cache(claim);
    persistClaimAsync(ownerId, coordinate);
    return true;
  }

  @Override
  public synchronized boolean unclaim(String ownerId, ChunkCoordinate coordinate) {
    Objects.requireNonNull(ownerId, "ownerId");
    Objects.requireNonNull(coordinate, "coordinate");
    ensureOpen();

    TerritoryClaim existing = claims.get(coordinate);
    if (existing == null || !existing.ownerId().equals(ownerId)) {
      return false;
    }

    uncache(existing);
    persistUnclaimAsync(ownerId, coordinate);
    return true;
  }

  @Override
  public synchronized boolean unclaimDurably(String ownerId, ChunkCoordinate coordinate) {
    return unclaimClaimsDurably(List.of(new TerritoryClaim(ownerId, coordinate)));
  }

  @Override
  public synchronized boolean unclaimClaimsDurably(Collection<TerritoryClaim> expectedClaims) {
    List<TerritoryClaim> requested = List.copyOf(expectedClaims);
    ensureOpen();

    Set<ChunkCoordinate> coordinates = new HashSet<>();
    for (TerritoryClaim expected : requested) {
      if (!coordinates.add(expected.coordinate())) {
        throw new IllegalArgumentException("Durable unclaim contains duplicate coordinates");
      }
      TerritoryClaim cached = claims.get(expected.coordinate());
      if (cached != null && !cached.ownerId().equals(expected.ownerId())) {
        return false;
      }
    }
    for (TerritoryClaim expected : requested) {
      awaitPendingPersistence(expected.coordinate());
    }
    if (!requested.isEmpty() && !deleteClaimsDurably(requested)) {
      return false;
    }
    for (TerritoryClaim expected : requested) {
      TerritoryClaim cached = claims.get(expected.coordinate());
      if (cached != null && cached.ownerId().equals(expected.ownerId())) {
        uncache(cached);
      }
    }
    return true;
  }

  @Override
  public synchronized boolean transferClaims(
      String sourceOwnerId, String targetOwnerId, Collection<ChunkCoordinate> coordinates) {
    ClaimTransfer transfer = ClaimTransfer.of(sourceOwnerId, targetOwnerId, coordinates);
    boolean cacheMatches =
        transfer.coordinates().stream()
            .allMatch(coordinate -> isCachedOwner(transfer.sourceOwnerId(), coordinate));
    boolean hasPendingWrites =
        transfer.coordinates().stream().anyMatch(pendingOperations::containsKey);
    if (!cacheMatches || hasPendingWrites) {
      return false;
    }

    try (Connection connection = openConnection()) {
      if (!transferInTransaction(connection, transfer)) {
        return false;
      }
    } catch (SQLException exception) {
      throw new IllegalStateException("Unable to transfer territory claims atomically", exception);
    }

    for (ChunkCoordinate coordinate : transfer.coordinates()) {
      TerritoryClaim current = claims.get(coordinate);
      uncache(current);
      cache(new TerritoryClaim(transfer.targetOwnerId(), coordinate));
    }
    return true;
  }

  @Override
  public synchronized int claimedChunkCount() {
    return claims.size();
  }

  @Override
  public synchronized Collection<TerritoryClaim> claimsByOwner(String ownerId) {
    Set<ChunkCoordinate> coordinates = ownerIndex.get(ownerId);
    if (coordinates == null || coordinates.isEmpty()) {
      return List.of();
    }
    return coordinates.stream()
        .map(claims::get)
        .filter(Objects::nonNull)
        .sorted(Comparator.comparing(claim -> claim.coordinate().toString()))
        .collect(Collectors.toList());
  }

  /** 获取缓存命中率 */
  public double getCacheHitRate() {
    int total = cacheHits + cacheMisses;
    return total > 0 ? (double) cacheHits / total : 1.0;
  }

  /** 获取缓存统计信息 */
  public String getCacheStats() {
    return String.format(
        "TerritoryCache[hits=%d, misses=%d, hitRate=%.1f%%, size=%d]",
        cacheHits, cacheMisses, getCacheHitRate() * 100, claims.size());
  }

  /** 异步持久化声明操作 */
  private void persistClaimAsync(String ownerId, ChunkCoordinate coordinate) {
    queuePersistence(
        coordinate, () -> insertClaim(ownerId, coordinate), "Failed to persist territory claim: ");
  }

  /** 异步持久化取消声明操作 */
  private void persistUnclaimAsync(String ownerId, ChunkCoordinate coordinate) {
    queuePersistence(
        coordinate, () -> deleteClaim(ownerId, coordinate), "Failed to delete territory claim: ");
  }

  private void queuePersistence(
      ChunkCoordinate coordinate, SqlOperation operation, String failurePrefix) {
    CompletableFuture<Void> next;
    synchronized (persistenceLock) {
      ensureOpen();
      CompletableFuture<Void> previous = pendingOperations.get(coordinate);
      CompletableFuture<Void> base =
          previous == null
              ? CompletableFuture.completedFuture(null)
              : previous.handle((ignored, failure) -> null);
      next =
          base.thenRunAsync(
              () -> {
                try {
                  operation.run();
                } catch (Exception failure) {
                  logger.warning(failurePrefix + coordinate + " - " + failure.getMessage());
                }
              },
              persistenceExecutor);
      pendingOperations.put(coordinate, next);
    }
    CompletableFuture<Void> tracked = next;
    tracked.whenComplete((ignored, failure) -> pendingOperations.remove(coordinate, tracked));
  }

  private void awaitPendingPersistence(ChunkCoordinate coordinate) {
    CompletableFuture<Void> pending;
    synchronized (persistenceLock) {
      pending = pendingOperations.get(coordinate);
    }
    if (pending == null) {
      return;
    }
    try {
      pending.join();
    } catch (CompletionException failure) {
      throw new IllegalStateException(
          "Unable to finish queued territory write before durable unclaim " + coordinate,
          failure.getCause() == null ? failure : failure.getCause());
    }
  }

  private void initialize() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      loadFromDatabase(connection);
      if (claims.isEmpty()) {
        importLegacyClaims(connection);
      }
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to initialize SQL territory repository", exception);
    }
  }

  private void ensureTable(Connection connection) throws SQLException {
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_territory_claims (
              world_name VARCHAR(191) NOT NULL,
              chunk_x INTEGER NOT NULL,
              chunk_z INTEGER NOT NULL,
              owner_id VARCHAR(64) NOT NULL,
              PRIMARY KEY (world_name, chunk_x, chunk_z)
          )
          """);
    }
    ensureOwnerIndex(connection);
  }

  private void loadFromDatabase(Connection connection) throws SQLException {
    clearCache();
    try (PreparedStatement statement =
            connection.prepareStatement(
                """
                SELECT world_name, chunk_x, chunk_z, owner_id
                FROM starcore_territory_claims
                ORDER BY world_name, chunk_x, chunk_z
                """);
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        TerritoryClaim claim =
            new TerritoryClaim(
                rows.getString("owner_id"),
                new ChunkCoordinate(
                    rows.getString("world_name"), rows.getInt("chunk_x"), rows.getInt("chunk_z")));
        cache(claim);
      }
    }
  }

  private void importLegacyClaims(Connection connection) throws SQLException {
    Collection<TerritoryClaim> legacyClaims = legacyClaimSupplier.get();
    if (legacyClaims.isEmpty()) {
      return;
    }
    try (PreparedStatement statement =
        connection.prepareStatement(
            """
            INSERT INTO starcore_territory_claims (world_name, chunk_x, chunk_z, owner_id)
            VALUES (?, ?, ?, ?)
            """)) {
      for (TerritoryClaim claim : legacyClaims) {
        statement.setString(1, claim.coordinate().world());
        statement.setInt(2, claim.coordinate().x());
        statement.setInt(3, claim.coordinate().z());
        statement.setString(4, claim.ownerId());
        statement.addBatch();
      }
      statement.executeBatch();
    }
    clearCache();
    for (TerritoryClaim claim : legacyClaims) {
      cache(claim);
    }
    logger.info(
        "Imported " + legacyClaims.size() + " legacy STARCORE territory claims into SQL storage.");
  }

  private void insertClaim(String ownerId, ChunkCoordinate coordinate) {
    try (Connection connection = openConnection();
        PreparedStatement statement =
            connection.prepareStatement(
                """
                INSERT INTO starcore_territory_claims (world_name, chunk_x, chunk_z, owner_id)
                VALUES (?, ?, ?, ?)
                """)) {
      statement.setString(1, coordinate.world());
      statement.setInt(2, coordinate.x());
      statement.setInt(3, coordinate.z());
      statement.setString(4, ownerId);
      statement.executeUpdate();
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to persist territory claim " + coordinate, exception);
    }
  }

  private void deleteClaim(String ownerId, ChunkCoordinate coordinate) {
    try (Connection connection = openConnection();
        PreparedStatement statement =
            connection.prepareStatement(
                """
                DELETE FROM starcore_territory_claims
                WHERE world_name = ? AND chunk_x = ? AND chunk_z = ? AND owner_id = ?
                """)) {
      statement.setString(1, coordinate.world());
      statement.setInt(2, coordinate.x());
      statement.setInt(3, coordinate.z());
      statement.setString(4, ownerId);
      int affected = statement.executeUpdate();
      if (affected == 0) {
        throw new IllegalStateException("No SQL territory claim row was deleted for " + coordinate);
      }
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to delete territory claim " + coordinate, exception);
    }
  }

  private boolean deleteClaimsDurably(Collection<TerritoryClaim> expectedClaims) {
    try (Connection connection = openConnection()) {
      connection.setAutoCommit(false);
      try {
        try (PreparedStatement delete =
                connection.prepareStatement(
                    """
                    DELETE FROM starcore_territory_claims
                    WHERE world_name = ? AND chunk_x = ? AND chunk_z = ? AND owner_id = ?
                    """);
            PreparedStatement lookup =
                connection.prepareStatement(
                    """
                    SELECT owner_id FROM starcore_territory_claims
                    WHERE world_name = ? AND chunk_x = ? AND chunk_z = ?
                    """)) {
          for (TerritoryClaim expected : expectedClaims) {
            ChunkCoordinate coordinate = expected.coordinate();
            delete.setString(1, coordinate.world());
            delete.setInt(2, coordinate.x());
            delete.setInt(3, coordinate.z());
            delete.setString(4, expected.ownerId());
            if (delete.executeUpdate() == 0) {
              lookup.setString(1, coordinate.world());
              lookup.setInt(2, coordinate.x());
              lookup.setInt(3, coordinate.z());
              try (ResultSet result = lookup.executeQuery()) {
                if (result.next()) {
                  connection.rollback();
                  return false;
                }
              }
            }
          }
        }
        connection.commit();
        return true;
      } catch (SQLException failure) {
        try {
          connection.rollback();
        } catch (SQLException rollbackFailure) {
          failure.addSuppressed(rollbackFailure);
        }
        throw failure;
      }
    } catch (SQLException failure) {
      throw new IllegalStateException(
          "Unable to durably delete " + expectedClaims.size() + " territory claims", failure);
    }
  }

  private void ensureOwnerIndex(Connection connection) throws SQLException {
    DatabaseMetaData metadata = connection.getMetaData();
    try (ResultSet indexes = metadata.getIndexInfo(null, null, TABLE_NAME, false, false)) {
      while (indexes.next()) {
        String indexName = indexes.getString("INDEX_NAME");
        if ("idx_starcore_territory_claims_owner".equalsIgnoreCase(indexName)) {
          return;
        }
      }
    }
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE INDEX idx_starcore_territory_claims_owner ON " + TABLE_NAME + " (owner_id)");
    }
  }

  private Connection openConnection() throws SQLException {
    DataSource dataSource =
        dataSourceSupplier
            .get()
            .orElseThrow(() -> new IllegalStateException("STARCORE database is not running"));
    return dataSource.getConnection();
  }

  private boolean transferInTransaction(Connection connection, ClaimTransfer transfer)
      throws SQLException {
    connection.setAutoCommit(false);
    try (PreparedStatement statement =
        connection.prepareStatement(
            """
            UPDATE starcore_territory_claims
            SET owner_id = ?
            WHERE world_name = ? AND chunk_x = ? AND chunk_z = ? AND owner_id = ?
            """)) {
      for (ChunkCoordinate coordinate : transfer.coordinates()) {
        statement.setString(1, transfer.targetOwnerId());
        statement.setString(2, coordinate.world());
        statement.setInt(3, coordinate.x());
        statement.setInt(4, coordinate.z());
        statement.setString(5, transfer.sourceOwnerId());
        if (statement.executeUpdate() != 1) {
          connection.rollback();
          return false;
        }
      }
      connection.commit();
      return true;
    } catch (SQLException exception) {
      try {
        connection.rollback();
      } catch (SQLException rollbackFailure) {
        exception.addSuppressed(rollbackFailure);
      }
      throw exception;
    }
  }

  @Override
  public synchronized void shutdown() {
    if (!closed.compareAndSet(false, true)) {
      return;
    }
    CompletableFuture<Void> drain;
    synchronized (persistenceLock) {
      drain = CompletableFuture.allOf(pendingOperations.values().toArray(CompletableFuture[]::new));
    }
    try {
      drain.get(5, TimeUnit.SECONDS);
    } catch (InterruptedException interrupted) {
      Thread.currentThread().interrupt();
      logger.warning("Interrupted while draining territory persistence queue");
    } catch (Exception failure) {
      logger.warning("Failed to drain territory persistence queue: " + failure.getMessage());
    } finally {
      persistenceExecutor.shutdown();
    }
    try {
      if (!persistenceExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
        persistenceExecutor.shutdownNow();
        logger.warning("Timed out waiting for territory persistence queue to stop");
      }
    } catch (InterruptedException interrupted) {
      persistenceExecutor.shutdownNow();
      Thread.currentThread().interrupt();
    } finally {
      pendingOperations.clear();
    }
  }

  private void ensureOpen() {
    if (closed.get()) {
      throw new IllegalStateException("Territory service is already closed");
    }
  }

  private boolean isCachedOwner(String ownerId, ChunkCoordinate coordinate) {
    TerritoryClaim claim = claims.get(coordinate);
    return claim != null && claim.ownerId().equals(ownerId);
  }

  private void cache(TerritoryClaim claim) {
    claims.put(claim.coordinate(), claim);
    ownerIndex
        .computeIfAbsent(claim.ownerId(), ignored -> ConcurrentHashMap.newKeySet())
        .add(claim.coordinate());
  }

  private void uncache(TerritoryClaim claim) {
    claims.remove(claim.coordinate(), claim);
    ownerIndex.computeIfPresent(
        claim.ownerId(),
        (ignored, coordinates) -> {
          coordinates.remove(claim.coordinate());
          return coordinates.isEmpty() ? null : coordinates;
        });
  }

  private void clearCache() {
    claims.clear();
    ownerIndex.clear();
  }

  @FunctionalInterface
  private interface SqlOperation {
    void run() throws Exception;
  }
}
