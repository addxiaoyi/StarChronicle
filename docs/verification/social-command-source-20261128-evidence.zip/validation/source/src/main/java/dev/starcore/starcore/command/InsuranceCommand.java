package dev.starcore.starcore.command;

import dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService;
import dev.starcore.starcore.foundation.economy.insurance.InsuranceClaimReceipt;
import dev.starcore.starcore.foundation.economy.insurance.InsuranceCoverage;
import dev.starcore.starcore.foundation.economy.insurance.InsurancePolicy;
import dev.starcore.starcore.foundation.economy.insurance.InsuranceQuote;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** Player-facing economy insurance commands. */
public final class InsuranceCommand implements CommandExecutor, TabCompleter {
  private final EconomyInsuranceService insurance;

  public InsuranceCommand(EconomyInsuranceService insurance) {
    this.insurance = java.util.Objects.requireNonNull(insurance, "insurance");
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("Insurance is player-scoped.");
      return true;
    }
    if (args.length == 0 || "help".equalsIgnoreCase(args[0])) {
      help(player);
      return true;
    }
    try {
      switch (args[0].toLowerCase(Locale.ROOT)) {
        case "quote" -> quote(player, args);
        case "buy" -> buy(player, args);
        case "list" -> list(player);
        case "claim" -> claim(player, args);
        case "retry" -> retry(player);
        default -> help(player);
      }
    } catch (IllegalArgumentException | IllegalStateException failure) {
      player.sendMessage("Insurance: " + failure.getMessage());
    }
    return true;
  }

  private void quote(Player player, String[] args) {
    Parsed parsed = parse(args);
    InsuranceQuote quote =
        insurance.quote(
            player.getUniqueId(),
            parsed.coverage(),
            parsed.maxPayout(),
            parsed.deductible(),
            parsed.days());
    player.sendMessage(
        "Quote: coverage="
            + quote.coverage()
            + " max="
            + quote.maxPayout()
            + " deductible="
            + quote.deductible()
            + " premium="
            + quote.premium()
            + " days="
            + quote.durationDays());
  }

  private void buy(Player player, String[] args) {
    Parsed parsed = parse(args);
    InsurancePolicy policy =
        insurance.buy(
            insurance.quote(
                player.getUniqueId(),
                parsed.coverage(),
                parsed.maxPayout(),
                parsed.deductible(),
                parsed.days()));
    player.sendMessage(
        "Insurance active: "
            + policy.policyId()
            + " coverage="
            + policy.coverage()
            + " premium="
            + policy.premium()
            + " expires="
            + policy.expiresAt());
  }

  private void list(Player player) {
    List<InsurancePolicy> policies = insurance.policies(player.getUniqueId(), Instant.now());
    if (policies.isEmpty()) {
      player.sendMessage("No insurance policies.");
      return;
    }
    for (InsurancePolicy policy : policies) {
      player.sendMessage(
          policy.policyId()
              + " coverage="
              + policy.coverage()
              + " state="
              + policy.state()
              + " max="
              + policy.maxPayout()
              + " expires="
              + policy.expiresAt());
    }
  }

  private void claim(Player player, String[] args) {
    if (args.length < 2)
      throw new IllegalArgumentException("Usage: /insurance claim <transactionId>");
    UUID transactionId = UUID.fromString(args[1]);
    InsuranceClaimReceipt receipt =
        insurance.claim(player.getUniqueId(), transactionId, Instant.now()).orElseThrow();
    player.sendMessage(
        "Insurance claim paid: "
            + receipt.payout()
            + " transaction="
            + receipt.payoutTransactionId());
  }

  private void retry(Player player) {
    int count = insurance.retryPendingClaims(Instant.now());
    player.sendMessage("Insurance claim retries completed: " + count);
  }

  private static Parsed parse(String[] args) {
    if (args.length < 3) {
      throw new IllegalArgumentException(
          "Usage: /insurance <quote|buy> <coverage> <maxPayout> [deductible] [days]");
    }
    InsuranceCoverage coverage = InsuranceCoverage.valueOf(args[1].toUpperCase(Locale.ROOT));
    BigDecimal maxPayout = new BigDecimal(args[2]);
    BigDecimal deductible = args.length >= 4 ? new BigDecimal(args[3]) : BigDecimal.ZERO;
    int days = args.length >= 5 ? Integer.parseInt(args[4]) : 7;
    return new Parsed(coverage, maxPayout, deductible, days);
  }

  private static void help(Player player) {
    player.sendMessage("/insurance quote <coverage> <max> [deductible] [days]");
    player.sendMessage("/insurance buy <coverage> <max> [deductible] [days]");
    player.sendMessage("/insurance list | claim <transactionId> | retry");
    player.sendMessage("Coverage: " + Arrays.toString(InsuranceCoverage.values()));
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    if (args.length == 1)
      return prefix(List.of("quote", "buy", "list", "claim", "retry", "help"), args[0]);
    if (args.length == 2
        && ("quote".equalsIgnoreCase(args[0]) || "buy".equalsIgnoreCase(args[0]))) {
      return prefix(Arrays.stream(InsuranceCoverage.values()).map(Enum::name).toList(), args[1]);
    }
    return List.of();
  }

  private static List<String> prefix(List<String> values, String input) {
    String normalized = input == null ? "" : input.toLowerCase(Locale.ROOT);
    return values.stream()
        .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(normalized))
        .toList();
  }

  private record Parsed(
      InsuranceCoverage coverage, BigDecimal maxPayout, BigDecimal deductible, int days) {}
}
