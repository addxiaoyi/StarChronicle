package dev.starcore.starcore.core.event.chain;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;

/** 事件链 将多个相关事件串联在一起，支持链式处理和回滚 */
public class EventChain {

  private final String chainId;
  private final List<ChainLink> links = new ArrayList<>();
  private final Map<String, Object> sharedContext = new ConcurrentHashMap<>();
  private final long createdAt;
  private volatile boolean active = true;
  private volatile boolean completed = false;

  public EventChain(String chainId) {
    this.chainId = Objects.requireNonNull(chainId);
    this.createdAt = System.currentTimeMillis();
  }

  /** 添加链式处理步骤 */
  public <T> EventChain addStep(String stepName, Class<T> eventType, Function<T, T> processor) {
    links.add(new ChainLink(stepName, eventType, processor, null));
    return this;
  }

  /** 添加监听器步骤 */
  public <T> EventChain addListener(String stepName, Class<T> eventType, Consumer<T> listener) {
    links.add(new ChainLink(stepName, eventType, null, listener));
    return this;
  }

  /** 执行事件链 */
  @SuppressWarnings("unchecked")
  public <T> T execute(T initialEvent) {
    if (!active) {
      throw new IllegalStateException("Event chain is not active");
    }

    Object currentEvent = initialEvent;
    ChainLink failedLink = null;
    Exception failureException = null;

    for (ChainLink link : links) {
      try {
        if (link.eventType.isInstance(currentEvent)) {
          if (link.processor != null) {
            currentEvent = link.processor.apply((T) currentEvent);
          } else if (link.listener != null) {
            link.listener.accept((T) currentEvent);
          }
        }
      } catch (Exception e) {
        failedLink = link;
        failureException = e;
        break;
      }
    }

    if (failedLink != null) {
      // 回滚已完成的步骤
      rollback(failureException);
      throw new EventChainException(
          "Event chain step '" + failedLink.stepName + "' failed", failureException);
    }

    completed = true;
    return (T) currentEvent;
  }

  /** 异步执行事件链 */
  public <T> void executeAsync(
      T initialEvent, Consumer<T> onComplete, Consumer<Exception> onError) {
    Thread.startVirtualThread(
        () -> {
          try {
            T result = execute(initialEvent);
            if (onComplete != null) {
              onComplete.accept(result);
            }
          } catch (Exception e) {
            if (onError != null) {
              onError.accept(e);
            }
          }
        });
  }

  /** 回滚事件链 */
  public void rollback(Exception cause) {
    if (!active) return;

    // 记录回滚信息
    sharedContext.put("rollback_cause", cause);
    sharedContext.put("rollback_time", System.currentTimeMillis());

    // 执行回滚监听器
    for (int i = links.size() - 1; i >= 0; i--) {
      ChainLink link = links.get(i);
      try {
        if (link.rollbackHandler != null) {
          link.rollbackHandler.run();
        }
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(EventChain.class.getName())
            .warning("Error during rollback of step '" + link.stepName + "': " + e.getMessage());
      }
    }

    active = false;
  }

  /** 添加回滚处理器 */
  public EventChain addRollbackHandler(String stepName, Runnable rollbackHandler) {
    for (ChainLink link : links) {
      if (link.stepName.equals(stepName)) {
        link.rollbackHandler = rollbackHandler;
        break;
      }
    }
    return this;
  }

  /** 获取共享上下文 */
  public <T> T putSharedContext(String key, T value) {
    sharedContext.put(key, value);
    return value;
  }

  /** 获取共享上下文 */
  @SuppressWarnings("unchecked")
  public <T> T getSharedContext(String key) {
    return (T) sharedContext.get(key);
  }

  /** 检查事件链是否活跃 */
  public boolean isActive() {
    return active;
  }

  /** 检查事件链是否已完成 */
  public boolean isCompleted() {
    return completed;
  }

  /** 获取事件链ID */
  public String getChainId() {
    return chainId;
  }

  /** 获取创建时间 */
  public long getCreatedAt() {
    return createdAt;
  }

  /** 获取链式步骤 */
  public List<ChainLink> getLinks() {
    return List.copyOf(links);
  }

  /** 获取共享上下文 */
  public Map<String, Object> getSharedContext() {
    return Map.copyOf(sharedContext);
  }

  /** 链式链接 */
  public static class ChainLink {
    final String stepName;
    final Class<?> eventType;
    final Function<Object, Object> processor;
    final Consumer<Object> listener;
    volatile Runnable rollbackHandler;

    <T> ChainLink(
        String stepName, Class<T> eventType, Function<T, T> processor, Consumer<T> listener) {
      this.stepName = Objects.requireNonNull(stepName);
      this.eventType = Objects.requireNonNull(eventType);
      this.processor = (Function<Object, Object>) processor;
      this.listener = (Consumer<Object>) listener;
      this.rollbackHandler = null;
    }
  }

  /** 事件链异常 */
  public static class EventChainException extends RuntimeException {
    public EventChainException(String message, Throwable cause) {
      super(message, cause);
    }
  }
}
