package dev.starcore.starcore.api;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleDescriptor;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;

public final class StarCoreApiProvider implements StarCoreApi {
    private final StarCoreContext context;

    public StarCoreApiProvider(StarCoreContext context) {
        this.context = Objects.requireNonNull(context, "context");
    }

    @Override
    public String version() {
        return context.plugin().getPluginMeta().getVersion();
    }

    @Override
    public Collection<ModuleDescriptor> modules() {
        return context.moduleManager().descriptors();
    }

    @Override
    public <T> Optional<T> service(Class<T> serviceType) {
        Optional<T> service = context.serviceRegistry().find(serviceType);
        if (service.isPresent()) {
            return service;
        }
        return Optional.empty();
    }
}
