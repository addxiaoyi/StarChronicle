package dev.starcore.starcore.foundation.animation;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** Original-session tasks. The BukkitTask facade is only an internal cancellation handle. */
public final class AnimationTaskTracker {
  private final Plugin plugin;
  private final Set<Pending> tasks = new HashSet<>();
  private static final AtomicInteger IDS = new AtomicInteger(-1);
  private boolean closed;

  public AnimationTaskTracker(Plugin plugin) {
    this.plugin = plugin;
  }

  public void execute(Player player, Runnable action) {
    Pending pending = add(player, null, null, false, ignored -> action.run());
    if (pending == null) return;
    try {
      if (Bukkit.isOwnedByCurrentRegion(player)) fire(pending);
      else
        pending.attach(
            player.getScheduler().run(plugin, ignored -> fire(pending), pending::cancel));
    } catch (RuntimeException | Error failure) {
      pending.cancel();
      throw failure;
    }
  }

  public BukkitTask runTaskLater(Player player, Runnable action, long delay) {
    return schedule(player, null, ignored -> action.run(), delay, 0);
  }

  BukkitTask runTaskLater(Player player, Inventory inventory, Runnable action, long delay) {
    return schedule(player, inventory, ignored -> action.run(), delay, 0);
  }

  BukkitTask runTaskTimer(Player player, Consumer<BukkitTask> action, long delay, long period) {
    if (period < 1) throw new IllegalArgumentException("Animation period must be positive");
    return schedule(player, null, action, delay, period);
  }

  private BukkitTask schedule(
      Player player, Inventory inventory, Consumer<BukkitTask> action, long delay, long period) {
    Pending pending = add(player, inventory, null, period > 0, action);
    if (pending == null) return null;
    try {
      ScheduledTask task =
          period > 0
              ? player
                  .getScheduler()
                  .runAtFixedRate(
                      plugin, ignored -> fire(pending), pending::cancel, Math.max(1, delay), period)
              : player
                  .getScheduler()
                  .runDelayed(
                      plugin, ignored -> fire(pending), pending::cancel, Math.max(1, delay));
      pending.attach(task);
      return pending;
    } catch (RuntimeException | Error failure) {
      pending.cancel();
      throw failure;
    }
  }

  /**
   * World-only sound effects are routed to the destination region and use an immutable location.
   */
  public void atLocation(Location location, Consumer<Location> action) {
    if (location == null || location.getWorld() == null) return;
    Location copy = location.clone();
    Pending pending = add(null, null, copy, false, ignored -> action.accept(copy));
    if (pending == null) return;
    try {
      pending.attach(
          plugin.getServer().getRegionScheduler().run(plugin, copy, ignored -> fire(pending)));
    } catch (RuntimeException | Error failure) {
      pending.cancel();
      throw failure;
    }
  }

  private synchronized Pending add(
      Player player,
      Inventory expected,
      Location location,
      boolean repeating,
      Consumer<BukkitTask> action) {
    if (closed || !plugin.isEnabled() || (player == null && location == null)) return null;
    Pending pending = new Pending(player, expected, location, repeating, action);
    tasks.add(pending);
    return pending;
  }

  private void fire(Pending pending) {
    synchronized (this) {
      if (!tasks.contains(pending) || pending.cancelled || pending.running) return;
      pending.running = true;
    }
    Player player = pending.player;
    if (isClosed()
        || !plugin.isEnabled()
        || (player != null
            && (!Bukkit.isOwnedByCurrentRegion(player)
                || !player.isOnline()
                || plugin.getServer().getPlayer(player.getUniqueId()) != player
                || (pending.inventory != null
                    && player.getOpenInventory().getTopInventory() != pending.inventory)))
        || (pending.location != null && !Bukkit.isOwnedByCurrentRegion(pending.location))) {
      pending.cancel();
      return;
    }
    try {
      // Do not hold a tracker lock across user callbacks or another animation manager.
      // Shutdown retires queued work; an already admitted owner callback may finish.
      if (!pending.isCancelled()) pending.action.accept(pending);
    } catch (RuntimeException | Error failure) {
      pending.cancel();
      throw failure;
    } finally {
      if (!pending.repeating) pending.cancel();
      synchronized (this) {
        pending.running = false;
      }
    }
  }

  void cancelPlayer(Player player) {
    for (Pending task : snapshot()) if (task.player == player) task.cancel();
  }

  void cancelAll() {
    for (Pending task : snapshot()) task.cancel();
  }

  private synchronized Set<Pending> snapshot() {
    return Set.copyOf(tasks);
  }

  void onRetired(BukkitTask task, Runnable cleanup) {
    synchronized (this) {
      if (task instanceof Pending pending && !pending.cancelled) {
        pending.cleanup = cleanup;
        return;
      }
    }
    cleanup.run();
  }

  synchronized boolean isClosed() {
    return closed;
  }

  public void shutdown() {
    synchronized (this) {
      if (closed) return;
      closed = true;
    }
    cancelAll();
  }

  private final class Pending implements BukkitTask {
    final int id = IDS.getAndDecrement();
    final Player player;
    final Inventory inventory;
    final Location location;
    final boolean repeating;
    final Consumer<BukkitTask> action;
    boolean cancelled;
    boolean running;
    boolean backendCancelled;
    ScheduledTask scheduled;
    Runnable cleanup;

    Pending(
        Player player,
        Inventory inventory,
        Location location,
        boolean repeating,
        Consumer<BukkitTask> action) {
      this.player = player;
      this.inventory = inventory;
      this.location = location;
      this.repeating = repeating;
      this.action = action;
    }

    void attach(ScheduledTask task) {
      boolean retire;
      synchronized (AnimationTaskTracker.this) {
        scheduled = task;
        retire = task == null || cancelled;
      }
      if (retire) cancel();
    }

    private void cancelBackend() {
      ScheduledTask handle;
      synchronized (AnimationTaskTracker.this) {
        if (scheduled == null || backendCancelled) return;
        backendCancelled = true;
        handle = scheduled;
      }
      try {
        handle.cancel();
      } catch (RuntimeException failure) {
        plugin.getLogger().warning("Animation cancellation failed: " + failure.getMessage());
      }
    }

    @Override
    public void cancel() {
      Runnable action;
      synchronized (AnimationTaskTracker.this) {
        cancelled = true;
        tasks.remove(this);
        action = cleanup;
        cleanup = null;
      }
      cancelBackend();
      if (action != null) action.run();
    }

    @Override
    public boolean isCancelled() {
      synchronized (AnimationTaskTracker.this) {
        return cancelled;
      }
    }

    @Override
    public int getTaskId() {
      return id;
    }

    @Override
    public Plugin getOwner() {
      return plugin;
    }

    @Override
    public boolean isSync() {
      return true;
    }
  }
}
