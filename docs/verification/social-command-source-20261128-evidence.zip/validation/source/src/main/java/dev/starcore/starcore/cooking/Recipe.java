package dev.starcore.starcore.cooking;

import java.util.*;

/** 食谱模型 表示一个烹调食谱 */
public record Recipe(
    String recipeId, // 食谱ID
    String name, // 食谱名称
    String description, // 描述
    CookingStation station, // 烹调站
    Set<String> ingredients, // 食材
    Map<String, Integer> ingredientAmounts, // 食材数量
    int cookingTime, // 烹调时间（秒）
    int difficulty, // 难度（1-10）
    Set<String> tags, // 标签
    String resultItem, // 结果物品
    int resultAmount, // 结果数量
    Map<String, Object> effects // 效果
    ) {

  /** 创建食谱构建器 */
  public static Builder builder(String recipeId, String name, CookingStation station) {
    return new Builder(recipeId, name, station);
  }

  /** 检查是否有特定食材 */
  public boolean hasIngredient(String ingredient) {
    return ingredients.contains(ingredient);
  }

  /** 获取食材数量 */
  public int getIngredientAmount(String ingredient) {
    return ingredientAmounts.getOrDefault(ingredient, 0);
  }

  /** 检查是否可以烹调（有足够食材） */
  public boolean canCook(Map<String, Integer> availableIngredients) {
    for (Map.Entry<String, Integer> entry : ingredientAmounts.entrySet()) {
      int available = availableIngredients.getOrDefault(entry.getKey(), 0);
      if (available < entry.getValue()) {
        return false;
      }
    }
    return true;
  }

  /** 食谱构建器 */
  public static class Builder {
    private final String recipeId;
    private final String name;
    private final CookingStation station;
    private String description = "";
    private final Set<String> ingredients = new HashSet<>();
    private final Map<String, Integer> ingredientAmounts = new HashMap<>();
    private int cookingTime = 60;
    private int difficulty = 1;
    private final Set<String> tags = new HashSet<>();
    private String resultItem = "";
    private int resultAmount = 1;
    private final Map<String, Object> effects = new HashMap<>();

    private Builder(String recipeId, String name, CookingStation station) {
      this.recipeId = Objects.requireNonNull(recipeId);
      this.name = Objects.requireNonNull(name);
      this.station = Objects.requireNonNull(station);
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder addIngredient(String ingredient, int amount) {
      this.ingredients.add(ingredient);
      this.ingredientAmounts.put(ingredient, amount);
      return this;
    }

    public Builder cookingTime(int seconds) {
      this.cookingTime = Math.max(1, seconds);
      return this;
    }

    public Builder difficulty(int level) {
      this.difficulty = Math.max(1, Math.min(10, level));
      return this;
    }

    public Builder addTag(String tag) {
      this.tags.add(tag);
      return this;
    }

    public Builder result(String item, int amount) {
      this.resultItem = item;
      this.resultAmount = Math.max(1, amount);
      return this;
    }

    public Builder addEffect(String key, Object value) {
      this.effects.put(key, value);
      return this;
    }

    public Recipe build() {
      return new Recipe(
          recipeId,
          name,
          description,
          station,
          Set.copyOf(ingredients),
          Map.copyOf(ingredientAmounts),
          cookingTime,
          difficulty,
          Set.copyOf(tags),
          resultItem,
          resultAmount,
          Map.copyOf(effects));
    }
  }
}
