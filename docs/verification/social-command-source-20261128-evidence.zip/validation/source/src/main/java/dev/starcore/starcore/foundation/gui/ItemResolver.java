package dev.starcore.starcore.foundation.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

/**
 * 统一物品解析器。
 *
 * 把配置文件里的材质字符串解析成 {@link ItemStack}，支持三种写法：
 * <ul>
 *   <li>原版材质名，如 {@code DIAMOND_SWORD}（大小写不敏感）</li>
 *   <li>自定义物品插件命名空间，如 {@code oraxen:ruby_sword}、{@code itemsadder:iron_helmet}</li>
 *   <li>模组物品命名空间（混合端），如 {@code create:brass_ingot} —— 走 Bukkit 命名空间 Registry</li>
 * </ul>
 *
 * 解析失败时回退到给定的默认材质并打印一次警告，绝不抛异常 —— 避免非法配置导致菜单打不开。
 *
 * <p>本类自包含：通过反射探测 Oraxen / ItemsAdder，不依赖任何需要接线的集成管理器，
 * 因此可以在插件生命周期的任意阶段安全调用。</p>
 */
public final class ItemResolver {

    private ItemResolver() {}

    private static final Logger LOG = Logger.getLogger("StarCore-ItemResolver");

    /** 已警告过的无效材质串，避免刷屏（每个串只警告一次）。 */
    private static final java.util.Set<String> WARNED = ConcurrentHashMap.newKeySet();

    // 自定义物品插件可用性：null=未探测，TRUE/FALSE=已探测结果
    private static Boolean oraxenAvailable;
    private static Boolean itemsAdderAvailable;

    /**
     * 把材质字符串解析成 ItemStack。
     *
     * @param raw     配置里的原始字符串，可能是原版材质名或 {@code namespace:id}
     * @param fallback 解析失败时使用的原版材质
     * @return 永不为 null 的 ItemStack
     */
    public static ItemStack resolve(String raw, Material fallback) {
        if (raw == null || raw.isBlank()) {
            return new ItemStack(fallback);
        }
        String value = raw.trim();

        // 含冒号 → 命名空间物品（自定义插件或模组）
        int colon = value.indexOf(':');
        if (colon > 0 && colon < value.length() - 1) {
            Optional<ItemStack> custom = resolveNamespaced(value);
            if (custom.isPresent()) {
                return custom.get();
            }
            // 命名空间物品没解析出来 → 尝试当作 minecraft:xxx 的原版名处理
            String namespace = value.substring(0, colon).toLowerCase(Locale.ROOT);
            if (namespace.equals("minecraft")) {
                Material m = Material.matchMaterial(value.substring(colon + 1).toUpperCase(Locale.ROOT));
                if (m != null) {
                    return new ItemStack(m);
                }
            }
            warnOnce(value, fallback);
            return new ItemStack(fallback);
        }

        // 原版材质名
        Material m = Material.matchMaterial(value.toUpperCase(Locale.ROOT));
        if (m != null) {
            return new ItemStack(m);
        }
        warnOnce(value, fallback);
        return new ItemStack(fallback);
    }

    /**
     * 只解析成 Material（不支持自定义物品的场景），失败回退。
     * 用于仍以 Material 建模的旧配置字段。
     */
    public static Material resolveMaterial(String raw, Material fallback) {
        if (raw == null || raw.isBlank()) {
            return fallback;
        }
        String value = raw.trim();
        // 剥离 minecraft: 前缀
        if (value.toLowerCase(Locale.ROOT).startsWith("minecraft:")) {
            value = value.substring("minecraft:".length());
        }
        Material m = Material.matchMaterial(value.toUpperCase(Locale.ROOT));
        if (m != null) {
            return m;
        }
        warnOnce(value, fallback);
        return fallback;
    }

    /** 判断一个字符串是否是自定义/模组命名空间物品的写法。 */
    public static boolean isNamespaced(String raw) {
        if (raw == null) return false;
        int colon = raw.indexOf(':');
        return colon > 0 && colon < raw.trim().length() - 1
            && !raw.trim().toLowerCase(Locale.ROOT).startsWith("minecraft:");
    }

    // ==================== 内部：命名空间物品解析 ====================

    private static Optional<ItemStack> resolveNamespaced(String value) {
        int colon = value.indexOf(':');
        String namespace = value.substring(0, colon).toLowerCase(Locale.ROOT);
        String id = value.substring(colon + 1);

        // Oraxen: 物品 id 不带命名空间前缀，但社区习惯写 oraxen:<id>
        if (namespace.equals("oraxen")) {
            return fromOraxen(id);
        }
        // ItemsAdder: 习惯写 itemsadder:<namespace_id> 或直接 <ns>:<id>
        if (namespace.equals("itemsadder") || namespace.equals("ia")) {
            return fromItemsAdder(id);
        }

        // 其它命名空间：先试 Oraxen（Oraxen id 可以是任意串），再试 ItemsAdder 的 ns:id，
        // 最后当作模组物品走 Bukkit Registry。
        Optional<ItemStack> ora = fromOraxen(value.contains(":") && !namespace.equals("oraxen") ? value : id);
        if (ora.isPresent()) return ora;

        Optional<ItemStack> ia = fromItemsAdder(value);
        if (ia.isPresent()) return ia;

        return fromVanillaNamespace(value);
    }

    /** 通过反射从 Oraxen 取物品，Oraxen 不在时返回 empty。 */
    private static Optional<ItemStack> fromOraxen(String id) {
        if (!isOraxenAvailable()) {
            return Optional.empty();
        }
        try {
            Class<?> api = Class.forName("io.th0rgal.oraxen.api.OraxenItems");
            Object builder = api.getMethod("getItemById", String.class).invoke(null, id);
            if (builder != null) {
                Object stack = builder.getClass().getMethod("build").invoke(builder);
                if (stack instanceof ItemStack is) {
                    return Optional.of(is);
                }
            }
        } catch (Throwable ignored) {
            // Oraxen 版本不兼容或物品不存在 → 交给下一级 fallback
        }
        return Optional.empty();
    }

    /** 通过反射从 ItemsAdder 取物品，未安装时返回 empty。 */
    private static Optional<ItemStack> fromItemsAdder(String namespacedId) {
        if (!isItemsAdderAvailable()) {
            return Optional.empty();
        }
        try {
            Class<?> stackClass = Class.forName("dev.lone.itemsadder.api.CustomStack");
            Object custom = stackClass.getMethod("getInstance", String.class).invoke(null, namespacedId);
            if (custom != null) {
                Object stack = stackClass.getMethod("getItemStack").invoke(custom);
                if (stack instanceof ItemStack is) {
                    return Optional.of(is);
                }
            }
        } catch (Throwable ignored) {
            // 未安装 / 版本不兼容 / 物品不存在
        }
        return Optional.empty();
    }

    /** 模组物品（混合端）：走 Bukkit 命名空间 Registry 查 Material。 */
    private static Optional<ItemStack> fromVanillaNamespace(String namespacedId) {
        try {
            Material m = Material.matchMaterial(namespacedId);
            if (m != null) {
                return Optional.of(new ItemStack(m));
            }
        } catch (Throwable ignored) {
        }
        return Optional.empty();
    }

    // ==================== 插件可用性探测（缓存） ====================

    private static boolean isOraxenAvailable() {
        if (oraxenAvailable == null) {
            oraxenAvailable = Bukkit.getPluginManager().getPlugin("Oraxen") != null;
        }
        return oraxenAvailable;
    }

    private static boolean isItemsAdderAvailable() {
        if (itemsAdderAvailable == null) {
            itemsAdderAvailable = Bukkit.getPluginManager().getPlugin("ItemsAdder") != null;
        }
        return itemsAdderAvailable;
    }

    /** 重置探测缓存（插件热重载后调用）。 */
    public static void resetProbeCache() {
        oraxenAvailable = null;
        itemsAdderAvailable = null;
        WARNED.clear();
    }

    private static void warnOnce(String value, Material fallback) {
        if (WARNED.add(value)) {
            LOG.warning("[StarCore] 无法解析物品 '" + value + "'，回退为 " + fallback.name()
                + "（若为自定义物品，请确认 Oraxen/ItemsAdder 已安装且物品 ID 正确）");
        }
    }
}
