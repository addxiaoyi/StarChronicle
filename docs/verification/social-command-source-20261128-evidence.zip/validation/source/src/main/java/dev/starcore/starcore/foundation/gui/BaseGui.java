package dev.starcore.starcore.foundation.gui;

import dev.starcore.starcore.foundation.animation.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

/**
 * StarCore GUI 基类 - 现代化 UX 版本 提供统一的菜单创建、导航、动画和交互处理
 *
 * <p>增强特性：
 *
 * <ul>
 *   <li>VisualComponent 集成：统一视觉组件库
 *   <li>动画反馈：打开/关闭/点击/成功/失败动画
 *   <li>面包屑导航：清晰的导航路径
 *   <li>现代化按钮：活跃/禁用/选中状态
 *   <li>进度组件：进度条、状态指示
 * </ul>
 */
public abstract class BaseGui implements InventoryHolder {

  // ==================== 静态配置 ====================
  protected static final int SLOT_BACK = 45;
  protected static final int SLOT_INFO = 49;
  protected static final int SLOT_PREV = 48;
  protected static final int SLOT_NEXT = 50;
  protected static final int SLOT_CLOSE = 53;

  // 颜色配置
  protected static final TextColor COLOR_TITLE = NamedTextColor.GOLD;
  protected static final TextColor COLOR_ITEM = NamedTextColor.WHITE;
  protected static final TextColor COLOR_HIGHLIGHT = NamedTextColor.YELLOW;
  protected static final TextColor COLOR_DISABLED = NamedTextColor.GRAY;
  protected static final TextColor COLOR_NAV = NamedTextColor.AQUA;

  // ==================== 实例字段 ====================
  protected final Player player;
  protected final Plugin plugin;
  protected GuiAnimationRegistry animations;

  protected Inventory inventory;
  protected String menuId;
  protected Component title;
  protected int page = 0;
  protected int totalPages = 1;

  // 导航历史（面包屑）
  protected final Deque<BaseGui> history = new ArrayDeque<>();
  protected String breadcrumbPath = "";

  // 事件处理
  protected final Map<Integer, Consumer<Player>> clickHandlers = new ConcurrentHashMap<>();
  protected final Map<Integer, Predicate<Player>> conditionHandlers = new ConcurrentHashMap<>();

  // 当前菜单的物品缓存（用于动画效果）
  protected Map<Integer, ItemStack> previousItems = new ConcurrentHashMap<>();
  protected long lastUpdateTime = 0;

  public BaseGui(Player player, Plugin plugin, String menuId, Component title) {
    this.player = player;
    this.plugin = plugin;
    this.menuId = menuId;
    this.title = title;

    try {
      this.animations = GuiAnimationRegistry.getInstance();
    } catch (IllegalStateException e) {
      this.animations = null;
    }
  }

  // ==================== 抽象方法 ====================
  protected abstract void buildContent();

  protected abstract int getSize();

  // ==================== 生命周期 ====================
  public void open() {
    open(0);
  }

  public void open(int page) {
    this.page = Math.max(0, page);
    build();

    if (animations != null) {
      animations.playMenuOpen(player, menuId);
    }

    BaseGuiListener.registerGui(player, this);
    player.openInventory(inventory);
  }

  protected void build() {
    int size = getSize();
    if (size % 9 != 0) size = ((size / 9) + 1) * 9;
    size = Math.max(9, Math.min(54, size));

    inventory = Bukkit.createInventory(this, size, title);

    clickHandlers.clear();
    conditionHandlers.clear();

    // 现代背景填充
    fillModernBackground();

    previousItems.clear();
    for (int i = 0; i < size; i++) {
      if (inventory.getItem(i) != null) {
        previousItems.put(i, inventory.getItem(i).clone());
      }
    }

    buildContent();
    buildNavigation();

    lastUpdateTime = System.currentTimeMillis();
  }

  public void refresh() {
    build();
    player.openInventory(inventory);
  }

  public void close() {
    if (animations != null) {
      animations.playMenuClose(player);
    }
    BaseGuiListener.unregisterGui(player, this);
    player.closeInventory();
    clearInteractionState();
  }

  /** Releases handlers and snapshots without closing another GUI opened for the same player. */
  public void clearInteractionState() {
    clickHandlers.clear();
    conditionHandlers.clear();
    previousItems.clear();
    history.clear();
  }

  protected void goBack() {
    if (!history.isEmpty()) {
      BaseGui previous = history.pop();
      previous.open(previous.page);
    } else {
      close();
    }
  }

  protected void pushToHistory(BaseGui gui) {
    gui.history.addAll(this.history);
    gui.history.push(this);
  }

  // ==================== 现代化背景 ====================
  protected void fillModernBackground() {
    // Empty slots give content room to breathe; only meaningful controls occupy the canvas.
    inventory.clear();
  }

  // ==================== 现代化导航栏 ====================
  protected void buildNavigation() {
    int size = inventory.getSize();

    // 返回按钮
    if (size > SLOT_BACK) {
      setClickableButton(
          SLOT_BACK,
          Material.BARRIER,
          Component.text("§c✕ 返回", NamedTextColor.RED),
          List.of(Component.empty(), Component.text("§7返回上一级", NamedTextColor.GRAY)),
          p -> {
            goBack();
          });
    }

    // 信息/帮助按钮
    if (size > SLOT_INFO) {
      List<Component> infoLore = new ArrayList<>();
      infoLore.add(Component.empty());
      infoLore.add(Component.text("§7菜单: §f" + menuId, NamedTextColor.WHITE));
      infoLore.add(
          Component.text("§7页码: §f" + (page + 1) + "/" + totalPages, NamedTextColor.WHITE));
      if (!breadcrumbPath.isEmpty()) {
        infoLore.add(Component.text("§7路径: §f" + breadcrumbPath, NamedTextColor.WHITE));
      }
      infoLore.add(Component.empty());
      setButton(
          SLOT_INFO,
          Material.NETHER_STAR,
          Component.text("§8📖 信息", NamedTextColor.DARK_GRAY),
          infoLore);
    }

    // 上一页
    if (size > SLOT_PREV && page > 0) {
      setClickableButton(
          SLOT_PREV,
          Material.ARROW,
          Component.text("§7⟵ 上一页", NamedTextColor.GRAY),
          List.of(Component.text("§7第 " + page + " 页", NamedTextColor.GRAY)),
          p -> {
            page--;
            refresh();
          });
    }

    // 下一页
    if (size > SLOT_NEXT && page < totalPages - 1) {
      setClickableButton(
          SLOT_NEXT,
          Material.ARROW,
          Component.text("§7下一页 ⟶", NamedTextColor.GRAY),
          List.of(Component.text("§7第 " + (page + 2) + " 页", NamedTextColor.GRAY)),
          p -> {
            page++;
            refresh();
          });
    }

    if (size >= 54 && inventory.getItem(52) == null) {
      inventory.setItem(52, ButtonFactory.createHubButton());
    }

    // 关闭按钮
    if (size >= SLOT_CLOSE + 1) {
      setClickableButton(
          SLOT_CLOSE,
          Material.BEDROCK,
          Component.text("§c✕ 关闭", NamedTextColor.RED),
          List.of(Component.empty(), Component.text("§7点击关闭菜单", NamedTextColor.GRAY)),
          p -> close());
    }
  }

  // ==================== 内容构建工具（增强版） ====================
  protected void setButton(int slot, Material material, String name, String... lore) {
    ItemStack item = new ItemStack(material);
    setButton(
        slot,
        item,
        Component.text(name),
        Arrays.stream(lore).map(Component::text).collect(Collectors.toList()));
  }

  protected void setButton(int slot, Material material, Component name, List<Component> lore) {
    ItemStack item = new ItemStack(material);
    setButton(slot, item, name, lore);
  }

  protected void setButton(int slot, Material material, Component name, Component... lore) {
    setButton(slot, material, name, Arrays.asList(lore));
  }

  protected void setButton(int slot, ItemStack item, String name, List<String> lore) {
    setButton(
        slot,
        item,
        Component.text(name),
        lore.stream().map(Component::text).collect(Collectors.toList()));
  }

  protected void setButton(int slot, ItemStack item, Component name, List<Component> lore) {
    if (item == null || item.getType() == Material.AIR) return;

    VisualComponent.normalize(item);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(name == null ? Component.empty() : name);
      meta.lore(lore == null ? List.of() : lore);
      item.setItemMeta(meta);
    }

    if (inventory == null || slot < 0 || slot >= inventory.getSize()) return;
    inventory.setItem(slot, item);
  }

  // ==================== 增强型按钮 ====================
  protected void setActiveButton(
      int slot,
      Material material,
      String name,
      List<String> description,
      Consumer<Player> onClick) {
    ItemStack item = VisualComponent.activeButton(material, name, description);
    setButton(
        slot,
        item,
        Component.text(name),
        description.stream().map(Component::text).collect(Collectors.toList()));
    clickHandlers.put(slot, onClick);
  }

  protected void setDisabledButton(int slot, Material material, String name, String reason) {
    ItemStack item = VisualComponent.disabledButton(material, name, reason);
    setButton(
        slot,
        item,
        Component.text("§c" + name, NamedTextColor.RED),
        List.of(Component.text("§c✗ " + reason, NamedTextColor.RED)));
  }

  protected void setSelectedButton(
      int slot,
      Material material,
      String name,
      List<String> description,
      Consumer<Player> onClick) {
    ItemStack item = VisualComponent.selectedButton(material, name, description);
    setButton(
        slot,
        item,
        Component.text("§6◆ " + name, NamedTextColor.GOLD),
        description.stream().map(Component::text).collect(Collectors.toList()));
    clickHandlers.put(slot, onClick);
  }

  protected void setHoverButton(
      int slot, Material material, String name, List<String> hoverText, Consumer<Player> onClick) {
    ItemStack item = VisualComponent.hoverButton(material, name, hoverText);
    setButton(
        slot,
        item,
        Component.text(name),
        hoverText.stream().map(Component::text).collect(Collectors.toList()));
    clickHandlers.put(slot, onClick);
  }

  // ==================== 通用可点击按钮 ====================
  protected void setClickableButton(
      int slot, Material material, String name, List<String> lore, Consumer<Player> onClick) {
    ItemStack item = new ItemStack(material);
    setButton(slot, item, name, lore);
    clickHandlers.put(slot, onClick);
  }

  protected void setClickableButton(
      int slot, Material material, Component name, List<Component> lore, Consumer<Player> onClick) {
    ItemStack item = new ItemStack(material);
    setButton(slot, item, name, lore);
    clickHandlers.put(slot, onClick);
  }

  protected void setClickableButton(
      int slot,
      Material material,
      String name,
      List<String> lore,
      Consumer<Player> onClick,
      Predicate<Player> condition) {
    ItemStack item = new ItemStack(material);
    setButton(slot, item, name, lore);
    clickHandlers.put(slot, onClick);
    conditionHandlers.put(slot, condition);

    if (condition != null && !condition.test(player)) {
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
        meta.displayName(Component.text("§c" + name, NamedTextColor.RED));
        meta.lore(
            lore.stream()
                .map(l -> Component.text("§c" + l, NamedTextColor.RED))
                .collect(Collectors.toList()));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
      }
      if (inventory != null && slot >= 0 && slot < inventory.getSize()) {
        inventory.setItem(slot, item);
      }
    }
  }

  protected void setClickableButton(
      int slot,
      Material material,
      Component name,
      List<Component> lore,
      Consumer<Player> onClick,
      Predicate<Player> condition) {
    ItemStack item = new ItemStack(material);
    setButton(slot, item, name, lore);
    clickHandlers.put(slot, onClick);
    conditionHandlers.put(slot, condition);

    if (condition != null && !condition.test(player)) {
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
        meta.displayName(name.color(NamedTextColor.GRAY));
        meta.lore(
            lore.stream().map(l -> l.color(NamedTextColor.GRAY)).collect(Collectors.toList()));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
      }
      if (inventory != null && slot >= 0 && slot < inventory.getSize()) {
        inventory.setItem(slot, item);
      }
    }
  }

  // ==================== 统计卡片 ====================
  protected void setStatCard(int slot, Material icon, String label, String value, String hint) {
    ItemStack card = VisualComponent.statCard(icon, label, value, hint);
    setButton(
        slot,
        card,
        Component.text("§6◆ " + label, NamedTextColor.GOLD),
        card.getItemMeta() != null ? card.getItemMeta().lore() : List.of());
  }

  // ==================== 空状态 ====================
  protected void setEmptyState(int slot, Material icon, String title, String hint) {
    ItemStack empty = VisualComponent.emptyState(icon, title, hint);
    setButton(
        slot,
        empty,
        Component.text("§8" + title, NamedTextColor.DARK_GRAY),
        empty.getItemMeta() != null ? empty.getItemMeta().lore() : List.of());
  }

  // ==================== 进度条 ====================
  protected void setProgressBar(int slot, double current, double max, int length) {
    ItemStack bar = VisualComponent.progressBar(current, max, length);
    setButton(
        slot,
        bar,
        Component.text("§8进度面板", NamedTextColor.DARK_GRAY),
        bar.getItemMeta() != null ? bar.getItemMeta().lore() : List.of());
  }

  protected void setRingProgress(int slot, double percent, String label) {
    ItemStack ring = VisualComponent.ringProgress(percent, label);
    setButton(
        slot,
        ring,
        Component.text("§8状态指示", NamedTextColor.DARK_GRAY),
        ring.getItemMeta() != null ? ring.getItemMeta().lore() : List.of());
  }

  // ==================== 分页工具 ====================
  protected int calculatePages(int totalItems, int itemsPerPage) {
    if (itemsPerPage <= 0) return 1;
    return Math.max(1, (int) Math.ceil((double) Math.max(0, totalItems) / itemsPerPage));
  }

  protected <T> List<T> getPageItems(List<T> allItems, int itemsPerPage) {
    if (allItems == null || allItems.isEmpty() || itemsPerPage <= 0) {
      return Collections.emptyList();
    }
    int start = Math.max(0, page) * itemsPerPage;
    int end = Math.min(start + itemsPerPage, allItems.size());
    if (start >= allItems.size()) return Collections.emptyList();
    return List.copyOf(allItems.subList(start, end));
  }

  protected void setTotalPages(int totalPages) {
    this.totalPages = Math.max(1, totalPages);
    this.page = Math.max(0, Math.min(page, this.totalPages - 1));
  }

  // ==================== 事件处理 ====================
  public boolean handleClick(Player clicker, int slot) {
    if (!clicker.equals(player) || slot < 0) {
      return false;
    }

    Predicate<Player> condition = conditionHandlers.get(slot);
    if (condition != null && !condition.test(clicker)) {
      if (animations != null) animations.playFailureSound(clicker);
      return true;
    }

    Consumer<Player> handler = clickHandlers.get(slot);
    if (handler != null) {
      if (animations != null) animations.playSelectSound(clicker);
      try {
        handler.accept(clicker);
      } catch (RuntimeException failure) {
        if (plugin != null) {
          plugin.getLogger().log(
              java.util.logging.Level.WARNING,
              "GUI action failed: " + menuId + " slot=" + slot,
              failure);
        }
        playFailure("操作失败，请稍后重试");
      }
      return true;
    }
    return false;
  }

  public void handleClose() {
    if (animations != null) animations.playMenuClose(player);
  }

  public boolean isOwnInventory(Inventory inventory) {
    return this.inventory != null && this.inventory.equals(inventory);
  }

  // ==================== 动画反馈 ====================
  protected void playSuccess(String message) {
    if (animations != null) {
      animations.playSuccess(player, message);
    } else {
      player.sendMessage(Component.text("§a✓ " + message, NamedTextColor.GREEN));
    }
  }

  protected void playFailure(String message) {
    if (animations != null) {
      animations.playFailure(player, message);
    } else {
      player.sendMessage(Component.text("§c✗ " + message, NamedTextColor.RED));
    }
  }

  protected void playRareEffect(String itemName) {
    if (animations != null) animations.playRareItem(player, itemName);
  }

  protected void playParticle(ParticleEffectManager.ParticlePreset preset) {
    if (animations != null) animations.playParticle(player, preset);
  }

  protected void playTransition(BaseGui targetGui) {
    if (animations != null && inventory != null) {
      pushToHistory(targetGui);
      targetGui.open();
    } else {
      targetGui.open();
    }
  }

  protected void playNavigate() {
    if (animations != null) animations.playNavigateSound(player);
  }

  // ==================== 面包屑 ====================
  protected void setBreadcrumb(String path) {
    this.breadcrumbPath = path;
  }

  // ==================== 工具方法 ====================
  protected void sendMessage(String message) {
    player.sendMessage(Component.text(message));
  }

  protected void sendColoredMessage(String message) {
    player.sendMessage(Component.text(message.replace("&", "§")));
  }

  private static final DecimalFormat INT_FORMAT = new DecimalFormat("#,##0");
  private static final DecimalFormat DEC_FORMAT = new DecimalFormat("#,##0.00");
  private static final ThreadLocal<DecimalFormat> INT_FORMAT_TL =
      ThreadLocal.withInitial(() -> new DecimalFormat("#,##0"));
  private static final ThreadLocal<DecimalFormat> DEC_FORMAT_TL =
      ThreadLocal.withInitial(() -> new DecimalFormat("#,##0.00"));

  protected String getPlayerName() {
    return player.getName();
  }

  protected boolean hasPermission(String permission) {
    return player.hasPermission(permission);
  }

  // 使用 ThreadLocal<DecimalFormat> 缓存格式化器：DecimalFormat 非线程安全但 ThreadLocal 避免每次新建
  protected String formatNumber(long number) {
    return INT_FORMAT_TL.get().format(number);
  }

  protected String formatNumber(double number) {
    return DEC_FORMAT_TL.get().format(number);
  }

  protected String createProgressBar(double current, double max, int length) {
    int safeLength = Math.max(0, length);
    double ratio = max > 0 && Double.isFinite(current) ? current / max : 0;
    int filled = (int) Math.round(Math.max(0, Math.min(1, ratio)) * safeLength);
    int empty = safeLength - filled;
    StringBuilder bar = new StringBuilder();
    bar.append("§a");
    for (int i = 0; i < filled; i++) bar.append("█");
    bar.append("§7");
    for (int i = 0; i < empty; i++) bar.append("█");
    return bar.toString();
  }

  // ==================== InventoryHolder ====================
  @Override
  public Inventory getInventory() {
    return inventory;
  }
}
