package dev.starcore.starcore.dummy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 训练假人命令 /dummy create <名称> [类型] - 创建假人 /dummy remove <ID> - 删除假人 /dummy list - 列出所有假人 /dummy tp
 * <ID> - 传送到假人 /dummy spawn|despawn <ID> - 生成/取消生成假人 /dummy stats <ID> - 显示假人统计 /dummy reset <ID> -
 * 重置假人统计 /dummy set <ID> <属性> <值> - 设置属性 /dummy type <ID> <类型> - 设置假人类型 /dummy equip <ID> -
 * 复制你的装备到假人 /dummy skin <ID> [玩家名] - 设置皮肤 /dummy session start <ID>|stop|stats - 训练会话 /dummy hud -
 * 切换自身 HUD /dummy feedback - 切换命中反馈 /dummy top [数量] - 查看 DPS 排行榜
 */
public final class TrainingDummyCommand implements CommandExecutor, TabCompleter {

  private static final List<String> SUB_COMMANDS =
      Arrays.asList(
          "create",
          "remove",
          "list",
          "tp",
          "spawn",
          "despawn",
          "stats",
          "reset",
          "set",
          "type",
          "equip",
          "skin",
          "session",
          "hud",
          "feedback",
          "top");

  private static final List<String> SET_PROPERTIES =
      Arrays.asList(
          "health",
          "maxhealth",
          "invulnerable",
          "healthbar",
          "autorespawn",
          "respawndelay",
          "lookatplayer",
          "reduction",
          "counterattack",
          "counterdamage",
          "movement",
          "hud",
          "record");

  private final TrainingDummyManager dummyManager;

  public TrainingDummyCommand(TrainingDummyManager dummyManager) {
    this.dummyManager = dummyManager;
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (args.length == 0) {
      sendHelp(sender);
      return true;
    }

    switch (args[0].toLowerCase()) {
      case "create" -> handleCreate(sender, args);
      case "remove", "delete" -> handleRemove(sender, args);
      case "list" -> handleList(sender);
      case "tp", "teleport" -> handleTeleport(sender, args);
      case "spawn" -> handleSpawn(sender, args);
      case "despawn" -> handleDespawn(sender, args);
      case "stats", "statistics" -> handleStats(sender, args);
      case "reset" -> handleReset(sender, args);
      case "set" -> handleSet(sender, args);
      case "type" -> handleType(sender, args);
      case "equip", "equipment" -> handleEquip(sender, args);
      case "skin" -> handleSkin(sender, args);
      case "session" -> handleSession(sender, args);
      case "hud" -> handleHud(sender);
      case "feedback" -> handleFeedback(sender);
      case "top", "leaderboard" -> handleTop(sender, args);
      default -> sendHelp(sender);
    }

    return true;
  }

  /** 创建假人 */
  private void handleCreate(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy create <名称> [类型]");
      return;
    }

    TrainingDummyType type = TrainingDummyType.STANDARD;
    if (args.length >= 3) {
      TrainingDummyType parsed = TrainingDummyType.fromName(args[2]);
      if (parsed == null) {
        sender.sendMessage("§c未知类型: " + args[2] + " §7可用: " + typeNames());
        return;
      }
      type = parsed;
    }

    String name = args[1];
    TrainingDummy dummy = dummyManager.createDummy(name, player.getLocation(), type);

    // 默认复制玩家装备和皮肤
    dummy.copyEquipment(player);
    dummy.copySkin(player);

    dummyManager.spawnDummy(dummy.getId());

    sender.sendMessage("§a已创建训练假人: " + name + " §7[" + type.getDisplayName() + "]");
    sender.sendMessage("§7ID: " + dummy.getId().toString().substring(0, 8));
    sender.sendMessage("§7已复制你的装备和皮肤");
  }

  /** 删除假人 */
  private void handleRemove(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy remove <ID>");
      return;
    }

    UUID id = parseId(sender, args[1]);
    if (id == null) {
      return;
    }

    if (dummyManager.removeDummy(id)) {
      sender.sendMessage("§a已删除假人: " + id);
    } else {
      sender.sendMessage("§c假人不存在: " + id);
    }
  }

  /** 列出所有假人 */
  private void handleList(CommandSender sender) {
    var dummies = dummyManager.getAllDummies();

    if (dummies.isEmpty()) {
      sender.sendMessage("§e当前没有训练假人");
      return;
    }

    sender.sendMessage("§6========== 训练假人列表 ==========");
    for (TrainingDummy dummy : dummies) {
      String status = dummy.isSpawned() ? "§a已生成" : "§7未生成";
      String health = String.format("§c%.1f§7/§c%.1f ♥", dummy.getHealth(), dummy.getMaxHealth());

      sender.sendMessage(
          String.format(
              "§e%s §7[%s] §7(ID: %s §7%s)",
              dummy.getName(),
              dummy.getType().getDisplayName(),
              dummy.getId().toString().substring(0, 8),
              status));
      sender.sendMessage("  §7血量: " + health);
      sender.sendMessage(
          String.format(
              "  §7伤害: §c%d §7命中: §f%d §7暴击: §b%d",
              dummy.getTotalDamageReceived(), dummy.getHitCount(), dummy.getCritCount()));
    }
    sender.sendMessage("§6总计: " + dummies.size() + " 个假人");
  }

  /** 传送到假人 */
  private void handleTeleport(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy tp <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    player.teleport(dummy.getLocation());
    sender.sendMessage("§a已传送到假人: " + dummy.getName());
  }

  /** 生成假人 */
  private void handleSpawn(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy spawn <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    sender.sendMessage(
        dummyManager.spawnDummy(dummy.getId()) ? "§a已生成假人: " + dummy.getName() : "§c假人已生成或生成失败");
  }

  /** 取消生成假人 */
  private void handleDespawn(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy despawn <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    sender.sendMessage(
        dummyManager.despawnDummy(dummy.getId()) ? "§a已取消生成假人: " + dummy.getName() : "§c假人未生成");
  }

  /** 显示统计 */
  private void handleStats(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy stats <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();

    sender.sendMessage("§6========== 训练假人统计 ==========");
    sender.sendMessage(
        "§e名称: §f" + dummy.getName() + " §7[" + dummy.getType().getDisplayName() + "§7]");
    sender.sendMessage(
        "§e血量: " + String.format("§c%.1f§7/§c%.1f ♥", dummy.getHealth(), dummy.getMaxHealth()));
    sender.sendMessage("§e血量百分比: " + String.format("§c%.1f%%", dummy.getHealthPercentage()));
    sender.sendMessage(
        "§e伤害减免: §f"
            + String.format("%.0f%%", dummy.getDamageReduction() * 100)
            + " §7反击: §f"
            + (dummy.isCounterAttack() ? "开" : "关")
            + " §7移动: §f"
            + (dummy.isMovement() ? "开" : "关"));
    sender.sendMessage("§e总伤害: §c" + dummy.getTotalDamageReceived());
    sender.sendMessage("§e命中次数: §f" + dummy.getHitCount() + " §7暴击: §b" + dummy.getCritCount());
    sender.sendMessage(String.format("§e平均伤害: §c%.2f", dummy.getAverageDamage()));
    sender.sendMessage(String.format("§eDPS: §c%.2f", dummy.getDPS()));

    if (dummy.getLastAttacker() != null) {
      Player attacker = Bukkit.getPlayer(dummy.getLastAttacker());
      sender.sendMessage("§e最后攻击者: §f" + (attacker != null ? attacker.getName() : "未知"));
    }

    // 每玩家独立统计
    List<UUID> attackers = dummy.getTrackedAttackers();
    if (!attackers.isEmpty()) {
      sender.sendMessage("§7---- 各玩家统计 ----");
      for (UUID attackerId : attackers) {
        DamageTracker tracker = dummy.getAttackerStats(attackerId);
        if (tracker == null) {
          continue;
        }
        Player online = Bukkit.getPlayer(attackerId);
        String name = online != null ? online.getName() : attackerId.toString().substring(0, 8);
        sender.sendMessage(
            String.format(
                "§7%s: §c%.0f §7伤害 §f%d §7命中 §b%d §7暴击 §c%.1f§7DPS",
                name,
                tracker.getTotalDamage(),
                tracker.getHitCount(),
                tracker.getCritCount(),
                tracker.getDps()));
      }
    }
    sender.sendMessage("§6================================");
  }

  /** 重置统计 */
  private void handleReset(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy reset <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    dummy.resetHealth();
    dummy.resetStats();

    sender.sendMessage("§a已重置假人统计: " + dummy.getName());
  }

  /** 设置属性 */
  private void handleSet(CommandSender sender, String[] args) {
    if (args.length < 4) {
      sender.sendMessage("§c用法: /dummy set <ID> <属性> <值>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    String property = args[2].toLowerCase();
    String value = args[3];

    try {
      switch (property) {
        case "health", "hp" -> {
          double health = Double.parseDouble(value);
          if (health < 0) {
            sender.sendMessage("§c血量不能为负数");
            return;
          }
          dummy.setHealth(health);
        }
        case "maxhealth", "maxhp" -> {
          double maxHealth = Double.parseDouble(value);
          if (maxHealth <= 0) {
            sender.sendMessage("§c最大血量必须大于 0");
            return;
          }
          dummy.setMaxHealth(maxHealth);
        }
        case "invulnerable", "god" -> dummy.setInvulnerable(Boolean.parseBoolean(value));
        case "healthbar" -> dummy.setShowHealthBar(Boolean.parseBoolean(value));
        case "autorespawn", "respawn" -> dummy.setAutoRespawn(Boolean.parseBoolean(value));
        case "respawndelay", "delay" -> dummy.setRespawnDelay(Long.parseLong(value));
        case "lookatplayer", "look" -> dummy.setLookAtPlayer(Boolean.parseBoolean(value));
        case "record" -> dummy.setRecordDamage(Boolean.parseBoolean(value));
        case "reduction", "armor" -> dummy.setDamageReduction(Double.parseDouble(value));
        case "counterattack" -> dummy.setCounterAttack(Boolean.parseBoolean(value));
        case "counterdamage" -> dummy.setCounterDamage(Double.parseDouble(value));
        case "movement", "move" -> dummy.setMovement(Boolean.parseBoolean(value));
        case "hud" -> dummy.setHudEnabled(Boolean.parseBoolean(value));
        default -> {
          sender.sendMessage("§c未知属性: " + property);
          return;
        }
      }
      sender.sendMessage("§a已设置 " + property + " = " + value);
    } catch (NumberFormatException e) {
      sender.sendMessage("§c无效的数值: " + value);
    }
  }

  /** 设置类型 */
  private void handleType(CommandSender sender, String[] args) {
    if (args.length < 3) {
      sender.sendMessage("§c用法: /dummy type <ID> <类型> §7可用: " + typeNames());
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummyType type = TrainingDummyType.fromName(args[2]);
    if (type == null) {
      sender.sendMessage("§c未知类型: " + args[2] + " §7可用: " + typeNames());
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    dummy.applyType(type);
    dummy.resetStats();

    sender.sendMessage("§a已将 " + dummy.getName() + " 设为类型: " + type.getDisplayName());
  }

  /** 复制装备 */
  private void handleEquip(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy equip <ID>");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    dummy.copyEquipment(player);
    respawnIfSpawned(dummy);

    sender.sendMessage("§a已复制你的装备到假人: " + dummy.getName());
  }

  /** 设置皮肤 */
  private void handleSkin(CommandSender sender, String[] args) {
    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy skin <ID> [玩家名]");
      return;
    }

    Optional<TrainingDummy> dummyOpt = findDummy(sender, args[1]);
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();

    if (args.length >= 3) {
      dummy.setSkin(args[2]);
      sender.sendMessage("§a已设置皮肤为: " + args[2]);
    } else if (sender instanceof Player player) {
      dummy.copySkin(player);
      sender.sendMessage("§a已复制你的皮肤");
    } else {
      sender.sendMessage("§c请指定玩家名");
      return;
    }

    respawnIfSpawned(dummy);
  }

  /** 训练会话 */
  private void handleSession(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    if (args.length < 2) {
      sender.sendMessage("§c用法: /dummy session start <ID> | stop | stats");
      return;
    }

    switch (args[1].toLowerCase()) {
      case "start" -> {
        if (args.length < 3) {
          sender.sendMessage("§c用法: /dummy session start <ID>");
          return;
        }
        Optional<TrainingDummy> dummyOpt = findDummy(sender, args[2]);
        if (dummyOpt.isEmpty()) {
          return;
        }
        TrainingSession session = dummyManager.startSession(player, dummyOpt.get().getId());
        if (session == null) {
          sender.sendMessage("§c开始会话失败");
          return;
        }
        sender.sendMessage("§a已开始训练会话，目标: " + dummyOpt.get().getName());
      }
      case "stop" -> {
        TrainingSession session = dummyManager.stopSession(player);
        if (session == null) {
          sender.sendMessage("§e当前没有进行中的会话");
          return;
        }
        printSession(sender, session, "§a会话已结束");
      }
      case "stats" -> {
        Optional<TrainingSession> sessionOpt = dummyManager.getSession(player);
        if (sessionOpt.isEmpty() || sessionOpt.get().getTracker().isEmpty()) {
          sender.sendMessage("§e当前没有会话统计");
          return;
        }
        printSession(sender, sessionOpt.get(), "§6当前会话统计");
      }
      default -> sender.sendMessage("§c用法: /dummy session start <ID> | stop | stats");
    }
  }

  /** 切换 HUD */
  private void handleHud(CommandSender sender) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    boolean enabled = dummyManager.toggleHud(player);
    sender.sendMessage(enabled ? "§a已开启训练 HUD" : "§7已关闭训练 HUD");
  }

  /** 切换命中反馈 */
  private void handleFeedback(CommandSender sender) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return;
    }

    boolean enabled = dummyManager.toggleFeedback(player);
    sender.sendMessage(enabled ? "§a已开启命中反馈" : "§7已关闭命中反馈");
  }

  /** 查看排行榜 */
  private void handleTop(CommandSender sender, String[] args) {
    int limit = 10;
    if (args.length >= 2) {
      try {
        limit = Math.max(1, Math.min(50, Integer.parseInt(args[1])));
      } catch (NumberFormatException e) {
        sender.sendMessage("§c无效的数量: " + args[1]);
        return;
      }
    }

    List<DummyLeaderboard.Entry> top = dummyManager.getLeaderboard(limit);
    if (top.isEmpty()) {
      sender.sendMessage("§e暂无训练记录");
      return;
    }

    sender.sendMessage("§6========== 训练 DPS 排行榜 ==========");
    int rank = 1;
    for (DummyLeaderboard.Entry entry : top) {
      sender.sendMessage(
          String.format(
              "§e#%d §f%s §7- §c%.2f §7DPS §8(%.0f 伤害)",
              rank++, entry.name, entry.bestDps, entry.bestDamage));
    }
    sender.sendMessage("§6====================================");
  }

  /** 发送会话结算 */
  private void printSession(CommandSender sender, TrainingSession session, String header) {
    DamageTracker tracker = session.getTracker();
    sender.sendMessage(header);
    sender.sendMessage(String.format("§e时长: §f%.1fs", session.getDurationMillis() / 1000.0));
    sender.sendMessage(String.format("§e总伤害: §c%.0f", tracker.getTotalDamage()));
    sender.sendMessage(
        "§e命中: §f"
            + tracker.getHitCount()
            + " §7暴击: §b"
            + tracker.getCritCount()
            + " §7("
            + String.format("%.1f%%", tracker.getCritRate())
            + "§7)");
    sender.sendMessage(
        String.format(
            "§e最大单次: §c%.1f §7平均: §c%.2f", tracker.getMaxHit(), tracker.getAverageDamage()));
    sender.sendMessage(String.format("§eDPS: §c%.2f", session.getSessionDps()));
  }

  /** 解析 ID 并查找假人，失败时已发送提示 */
  private Optional<TrainingDummy> findDummy(CommandSender sender, String raw) {
    UUID id = parseId(sender, raw);
    if (id == null) {
      return Optional.empty();
    }
    Optional<TrainingDummy> dummy = dummyManager.getDummy(id);
    if (dummy.isEmpty()) {
      sender.sendMessage("§c假人不存在: " + raw);
    }
    return dummy;
  }

  private UUID parseId(CommandSender sender, String raw) {
    try {
      return UUID.fromString(raw);
    } catch (IllegalArgumentException e) {
      sender.sendMessage("§c无效的 UUID: " + raw);
      return null;
    }
  }

  private void respawnIfSpawned(TrainingDummy dummy) {
    if (dummy.isSpawned()) {
      dummyManager.despawnDummy(dummy.getId());
      dummyManager.spawnDummy(dummy.getId());
    }
  }

  private String typeNames() {
    StringBuilder sb = new StringBuilder();
    for (TrainingDummyType type : TrainingDummyType.values()) {
      if (sb.length() > 0) {
        sb.append('§').append('7').append(", ");
      }
      sb.append(type.name());
    }
    return sb.toString();
  }

  /** 显示帮助 */
  private void sendHelp(CommandSender sender) {
    sender.sendMessage("§6========== 训练假人命令 ==========");
    sender.sendMessage("§e/dummy create <名称> [类型] §7- 创建假人");
    sender.sendMessage("§e/dummy remove <ID> §7- 删除假人");
    sender.sendMessage("§e/dummy list §7- 列出所有假人");
    sender.sendMessage("§e/dummy tp <ID> §7- 传送到假人");
    sender.sendMessage("§e/dummy spawn|despawn <ID> §7- 生成/取消生成");
    sender.sendMessage("§e/dummy stats <ID> §7- 显示统计");
    sender.sendMessage("§e/dummy reset <ID> §7- 重置统计");
    sender.sendMessage("§e/dummy set <ID> <属性> <值> §7- 设置属性");
    sender.sendMessage("§e/dummy type <ID> <类型> §7- 设置类型");
    sender.sendMessage("§e/dummy equip <ID> §7- 复制装备");
    sender.sendMessage("§e/dummy skin <ID> [玩家] §7- 设置皮肤");
    sender.sendMessage("§e/dummy session start <ID>|stop|stats §7- 训练会话");
    sender.sendMessage("§e/dummy hud §7- 切换 HUD §7| §e/dummy feedback §7- 切换反馈");
    sender.sendMessage("§e/dummy top [数量] §7- DPS 排行榜");
    sender.sendMessage("§7右键假人查看统计，潜行右键开始会话");
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (args.length == 1) {
      return filter(SUB_COMMANDS, args[0]);
    }

    String sub = args[0].toLowerCase();

    if (args.length == 2 && sub.equals("session")) {
      return filter(Arrays.asList("start", "stop", "stats"), args[1]);
    }

    if (args.length == 3 && sub.equals("set")) {
      return filter(SET_PROPERTIES, args[2]);
    }

    if (args.length == 3 && sub.equals("type")) {
      return filter(typeList(), args[2]);
    }

    if (args.length == 3 && sub.equals("create")) {
      return filter(typeList(), args[2]);
    }

    return new ArrayList<>();
  }

  private List<String> typeList() {
    List<String> names = new ArrayList<>();
    for (TrainingDummyType type : TrainingDummyType.values()) {
      names.add(type.name());
    }
    return names;
  }

  private List<String> filter(List<String> options, String prefix) {
    String lower = prefix.toLowerCase();
    List<String> result = new ArrayList<>();
    for (String option : options) {
      if (option.toLowerCase().startsWith(lower)) {
        result.add(option);
      }
    }
    return result;
  }
}
