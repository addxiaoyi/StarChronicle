package dev.starcore.starcore.cooking;

import java.util.*;

/** 预设食谱集合 定义游戏中的所有食谱 */
public final class Recipes {

  private Recipes() {}

  // ==================== 蒸锅区食谱 ====================

  /** 蒸锅区的基础食谱 */
  public static final Recipe STEAMER_BASIC =
      Recipe.builder("steamer_basic", "基础蒸锅", CookingStation.steamer)
          .description("最基础的蒸锅食谱，适合新手玩家")
          .addIngredient("fish", 1)
          .addIngredient("vegetable", 2)
          .cookingTime(30)
          .difficulty(1)
          .addTag("基础")
          .addTag("新手")
          .result("steamed_dish", 1)
          .addEffect("health", 10)
          .addEffect("satisfaction", 5)
          .build();

  /** 蒸锅区的高级食谱 */
  public static final Recipe STEAMER_ADVANCED =
      Recipe.builder("steamer_advanced", "高级蒸锅", CookingStation.steamer)
          .description("需要精湛技艺的蒸锅食谱")
          .addIngredient("premium_fish", 2)
          .addIngredient("rare_vegetable", 3)
          .addIngredient("spice", 1)
          .cookingTime(90)
          .difficulty(5)
          .addTag("高级")
          .addTag("精通")
          .result("premium_steamed_dish", 2)
          .addEffect("health", 30)
          .addEffect("satisfaction", 20)
          .addEffect("experience", 15)
          .build();

  // ==================== 炉窑区食谱 ====================

  /** 炉窑区的烤制食谱 */
  public static final Recipe KILN_ROAST =
      Recipe.builder("kiln_roast", "炉窑烤制", CookingStation.kiln)
          .description("使用炉窑的高温烤制食物")
          .addIngredient("meat", 3)
          .addIngredient("wood", 2)
          .cookingTime(120)
          .difficulty(3)
          .addTag("烤制")
          .addTag("火系")
          .result("roasted_meat", 2)
          .addEffect("health", 25)
          .addEffect("strength", 10)
          .build();

  /** 炉窑区的陶瓷制作 */
  public static final Recipe KILN_CERAMIC =
      Recipe.builder("kiln_ceramic", "陶瓷制作", CookingStation.kiln)
          .description("在炉窑中烧制陶瓷制品")
          .addIngredient("clay", 5)
          .addIngredient("water", 2)
          .cookingTime(180)
          .difficulty(4)
          .addTag("工艺")
          .addTag("陶瓷")
          .result("ceramic_item", 1)
          .addEffect("craftsmanship", 20)
          .build();

  // ==================== 烤箱区食谱 ====================

  /** 烤箱区的蛋糕食谱 */
  public static final Recipe OVEN_CAKE =
      Recipe.builder("oven_cake", "烤箱蛋糕", CookingStation.oven)
          .description("甜美的蛋糕食谱")
          .addIngredient("flour", 2)
          .addIngredient("egg", 3)
          .addIngredient("sugar", 2)
          .addIngredient("milk", 1)
          .cookingTime(60)
          .difficulty(2)
          .addTag("甜品")
          .addTag("蛋糕")
          .result("cake", 1)
          .addEffect("happiness", 15)
          .addEffect("energy", 10)
          .build();

  /** 烤箱区的面包食谱 */
  public static final Recipe OVEN_BREAD =
      Recipe.builder("oven_bread", "烤箱面包", CookingStation.oven)
          .description("传统的面包食谱")
          .addIngredient("flour", 3)
          .addIngredient("water", 1)
          .addIngredient("yeast", 1)
          .cookingTime(45)
          .difficulty(2)
          .addTag("主食")
          .addTag("面包")
          .result("bread", 2)
          .addEffect("health", 15)
          .addEffect("satisfaction", 10)
          .build();

  // ==================== 往事检视厅食谱 ====================

  /** 往事检视厅的记忆食谱 */
  public static final Recipe MEMORY_INSPECTION =
      Recipe.builder("memory_inspection", "往事检视", CookingStation.memory_inspection)
          .description("通过烹调回忆往事")
          .addIngredient("memory_fragment", 1)
          .addIngredient("emotion", 1)
          .cookingTime(300)
          .difficulty(8)
          .addTag("记忆")
          .addTag("往事")
          .result("memory_dish", 1)
          .addEffect("memory_recovery", 50)
          .addEffect("emotional_impact", 30)
          .build();

  /** 往事检视厅的核心记忆食谱 */
  public static final Recipe MEMORY_CORE =
      Recipe.builder("memory_core", "核心记忆", CookingStation.memory_inspection)
          .description("解锁核心记忆的特殊食谱")
          .addIngredient("core_memory_fragment", 3)
          .addIngredient("pure_emotion", 2)
          .addIngredient("sacrifice", 1)
          .cookingTime(600)
          .difficulty(10)
          .addTag("核心")
          .addTag("终极")
          .result("core_memory_dish", 1)
          .addEffect("memory_recovery", 100)
          .addEffect("emotional_impact", 100)
          .addEffect("enlightenment", 50)
          .build();

  /** 获取所有预设食谱 */
  public static Collection<Recipe> getAllRecipes() {
    return List.of(
        STEAMER_BASIC,
        STEAMER_ADVANCED,
        KILN_ROAST,
        KILN_CERAMIC,
        OVEN_CAKE,
        OVEN_BREAD,
        MEMORY_INSPECTION,
        MEMORY_CORE);
  }

  /** 按烹调站分组食谱 */
  public static Map<CookingStation, Set<Recipe>> getRecipesByStation() {
    Map<CookingStation, Set<Recipe>> map = new EnumMap<>(CookingStation.class);
    for (Recipe recipe : getAllRecipes()) {
      map.computeIfAbsent(recipe.station(), k -> new HashSet<>()).add(recipe);
    }
    return map;
  }

  /** 获取指定烹调站的食谱 */
  public static Set<Recipe> getRecipesForStation(CookingStation station) {
    return getRecipesByStation().getOrDefault(station, Set.of());
  }
}
