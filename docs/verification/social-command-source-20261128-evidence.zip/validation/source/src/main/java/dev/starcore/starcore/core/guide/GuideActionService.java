package dev.starcore.starcore.core.guide;

import dev.starcore.starcore.foundation.gui.NavigationHubMenu;
import java.util.Objects;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** 以玩家身份打开指南推荐的功能入口，权限和参数校验仍由原命令负责。 */
public final class GuideActionService {

  private final JavaPlugin plugin;

  public GuideActionService(JavaPlugin plugin) {
    this.plugin = Objects.requireNonNull(plugin, "plugin");
  }

  public ExecutionResult execute(Player player, GuideContentProvider.GuideItem item) {
    Objects.requireNonNull(player, "player");
    Objects.requireNonNull(item, "item");

    GuideAction action = GuideAction.forItem(item.id()).orElse(null);
    if (action == null) {
      return ExecutionResult.UNAVAILABLE;
    }

    if (action == GuideAction.MENU) {
      try {
        NavigationHubMenu.openHub(plugin, player);
        return ExecutionResult.EXECUTED;
      } catch (RuntimeException exception) {
        logFailure(player, action, exception);
        return ExecutionResult.FAILED;
      }
    }

    if (action.navigationKey() != null) {
      if (!NavigationHubMenu.hasHandler(action.navigationKey())) {
        plugin.getLogger().warning("Guide GUI handler is unavailable: " + action.navigationKey());
        return ExecutionResult.UNAVAILABLE;
      }
      try {
        return NavigationHubMenu.executeHandler(action.navigationKey(), player)
            ? ExecutionResult.EXECUTED
            : ExecutionResult.REJECTED;
      } catch (RuntimeException exception) {
        logFailure(player, action, exception);
        return ExecutionResult.FAILED;
      }
    }

    if (Bukkit.getPluginCommand(action.command()) == null) {
      plugin.getLogger().warning("Guide action command is unavailable: " + action.command());
      return ExecutionResult.UNAVAILABLE;
    }

    try {
      boolean accepted = Bukkit.dispatchCommand(player, action.command());
      return accepted ? ExecutionResult.EXECUTED : ExecutionResult.REJECTED;
    } catch (RuntimeException exception) {
      logFailure(player, action, exception);
      return ExecutionResult.FAILED;
    }
  }

  private void logFailure(Player player, GuideAction action, RuntimeException exception) {
    plugin
        .getLogger()
        .log(
            Level.SEVERE,
            "Guide action failed for " + player.getUniqueId() + ": " + action.name(),
            exception);
  }

  public enum ExecutionResult {
    EXECUTED,
    REJECTED,
    UNAVAILABLE,
    FAILED
  }
}
