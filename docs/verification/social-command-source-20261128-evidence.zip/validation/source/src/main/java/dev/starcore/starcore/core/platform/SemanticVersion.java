package dev.starcore.starcore.core.platform;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public record SemanticVersion(int major, int minor, int patch)
    implements Comparable<SemanticVersion> {
  private static final Pattern VERSION_PATTERN =
      Pattern.compile("^(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?$");

  public static SemanticVersion parse(String raw) {
    if (raw == null) {
      throw new IllegalArgumentException("Version cannot be null");
    }
    Matcher matcher = VERSION_PATTERN.matcher(raw.trim());
    if (!matcher.matches()) {
      throw new IllegalArgumentException("Unsupported version format: " + raw);
    }

    int major = Integer.parseInt(matcher.group(1));
    int minor = matcher.group(2) == null ? 0 : Integer.parseInt(matcher.group(2));
    int patch = matcher.group(3) == null ? 0 : Integer.parseInt(matcher.group(3));
    return new SemanticVersion(major, minor, patch);
  }

  @Override
  public int compareTo(SemanticVersion other) {
    int majorCompare = Integer.compare(this.major, other.major);
    if (majorCompare != 0) {
      return majorCompare;
    }

    int minorCompare = Integer.compare(this.minor, other.minor);
    if (minorCompare != 0) {
      return minorCompare;
    }

    return Integer.compare(this.patch, other.patch);
  }

  @Override
  public String toString() {
    return major + "." + minor + "." + patch;
  }
}
