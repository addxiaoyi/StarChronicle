package dev.starcore.starcore.boss;

/** Boss类型枚举 定义Boss的分类 */
public enum BossType {
  /** 筛选Boss：用于筛选玩家，验证玩家是否符合特定标准 */
  screening("筛选Boss", "用于筛选玩家，验证特定标准"),

  /** 后期遭遇Boss：在后期阶段遭遇的特殊Boss */
  late_encounter("后期遭遇", "后期阶段的特殊Boss");

  private final String displayName;
  private final String description;

  BossType(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }
}
