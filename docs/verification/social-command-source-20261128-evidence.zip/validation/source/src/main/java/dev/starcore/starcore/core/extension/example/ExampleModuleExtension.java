package dev.starcore.starcore.core.extension.example;

import dev.starcore.starcore.core.extension.ExtensionContributor;
import dev.starcore.starcore.core.module.extension.DefaultExtensionPointController;
import dev.starcore.starcore.core.module.extension.ExtensionPointController;
import dev.starcore.starcore.core.module.extension.ModuleExtension;
import java.util.List;
import java.util.Set;

/** 示例模块扩展 展示如何创建和使用模块扩展 */
public class ExampleModuleExtension implements ModuleExtension {

  private final DefaultExtensionPointController extensionPointController;

  public ExampleModuleExtension() {
    this.extensionPointController = new DefaultExtensionPointController(this);

    // 注册伤害计算扩展点的贡献者
    DamageCalculationExtensionPoint damageExtensionPoint = new DamageCalculationExtensionPoint();

    // 添加一个简单的伤害加成贡献者
    ExtensionContributor<
            DamageCalculationExtensionPoint.DamageResult,
            DamageCalculationExtensionPoint.DamageContext>
        damageContributor =
            new ExtensionContributor<>() {

              @Override
              public String getId() {
                return "example_damage_booster";
              }

              @Override
              public String getName() {
                return "示例伤害加成";
              }

              @Override
              public String getDescription() {
                return "示例伤害加成 - 提供10%额外伤害";
              }

              @Override
              public int getPriority() {
                return 100; // 较高的优先级
              }

              @Override
              public DamageCalculationExtensionPoint.DamageResult contribute(
                  DamageCalculationExtensionPoint.DamageContext request) {
                double boostedDamage = request.baseDamage() * 1.10;
                return new DamageCalculationExtensionPoint.DamageResult(
                    boostedDamage, request.baseDamage(), "example_damage_booster");
              }
            };

    extensionPointController.registerContributor(damageExtensionPoint, damageContributor);
  }

  @Override
  public String getExtensionId() {
    return "example_module_extension";
  }

  @Override
  public String getExtensionDescription() {
    return "示例模块扩展 - 展示扩展点使用方法";
  }

  @Override
  public Set<String> getRequiredExtensionPoints() {
    return Set.of("damage_calculation");
  }

  @Override
  public ExtensionPointController getExtensionPointController() {
    return extensionPointController;
  }

  @Override
  public void registerToExtensionPoints() {
    // 扩展点注册逻辑在构造函数中已经完成
    System.out.println("[ExampleModuleExtension] Registered to extension points");
  }

  @Override
  public void unregisterFromExtensionPoints() {
    extensionPointController.unregisterAll();
    System.out.println("[ExampleModuleExtension] Unregistered from extension points");
  }

  @Override
  public List<String> getDependencies() {
    return List.of();
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

  @Override
  public void setEnabled(boolean enabled) {
    // 示例扩展始终启用
  }

  @Override
  public String getVersion() {
    return "1.0.0";
  }

  @Override
  public String getAuthor() {
    return "StarCore Team";
  }
}
