package dev.starcore.starcore.choice;

import java.util.*;

/** 公共选择定义模型 定义公共选择的完整结构 */
public record ChoiceDefinition(
    String choiceId, // 选择ID
    String epochId, // 所属纪元ID
    ChoiceStatus status, // 当前状态
    Map<String, Option> options, // 选项集合
    String eventRef, // 关联事件
    Set<String> participantRequirements, // 参与要求
    Map<String, Object> metadata, // 元数据
    Long createdAt, // 创建时间
    Long updatedAt // 更新时间
    ) {

  /** 选项模型 */
  public record Option(
      String optionId, // 选项ID
      String description, // 选项描述
      Map<String, Object> outcomes, // 结果
      Map<String, Object> costs, // 成本
      String proposerId, // 提案者ID
      Set<String> supporters, // 支持者集合
      String coalitionRef, // 联盟引用
      Map<String, Object> metadata // 元数据
      ) {
    public static Option of(String optionId, String description) {
      return new Option(optionId, description, Map.of(), Map.of(), null, Set.of(), null, Map.of());
    }
  }

  /** 创建选择定义构建器 */
  public static Builder builder(String choiceId) {
    return new Builder(choiceId);
  }

  /** 检查选择是否处于开放状态 */
  public boolean isOpen() {
    return status == ChoiceStatus.participation_open || status == ChoiceStatus.evidence_open;
  }

  /** 获取默认选项 */
  public Optional<Option> getDefaultOption() {
    return options.values().stream().findFirst();
  }

  /** 公共选择定义构建器 */
  public static class Builder {
    private final String choiceId;
    private String epochId;
    private ChoiceStatus status = ChoiceStatus.drafting;
    private Map<String, Option> options = new LinkedHashMap<>();
    private String eventRef;
    private Set<String> participantRequirements = new HashSet<>();
    private Map<String, Object> metadata = new HashMap<>();
    private Long createdAt = System.currentTimeMillis();
    private Long updatedAt = System.currentTimeMillis();

    private Builder(String choiceId) {
      this.choiceId = Objects.requireNonNull(choiceId);
    }

    public Builder epochId(String epochId) {
      this.epochId = epochId;
      return this;
    }

    public Builder status(ChoiceStatus status) {
      this.status = status;
      return this;
    }

    public Builder addOption(Option option) {
      this.options.put(option.optionId(), option);
      return this;
    }

    public Builder addOption(String optionId, String description) {
      this.options.put(optionId, Option.of(optionId, description));
      return this;
    }

    public Builder eventRef(String eventRef) {
      this.eventRef = eventRef;
      return this;
    }

    public Builder addParticipantRequirement(String requirement) {
      this.participantRequirements.add(requirement);
      return this;
    }

    public Builder participantRequirements(Set<String> requirements) {
      this.participantRequirements = new HashSet<>(requirements);
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public ChoiceDefinition build() {
      return new ChoiceDefinition(
          choiceId,
          epochId,
          status,
          Map.copyOf(options),
          eventRef,
          Set.copyOf(participantRequirements),
          Map.copyOf(metadata),
          createdAt,
          updatedAt);
    }
  }
}
