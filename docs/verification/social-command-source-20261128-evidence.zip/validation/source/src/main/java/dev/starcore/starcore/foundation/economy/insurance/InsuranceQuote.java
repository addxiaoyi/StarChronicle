package dev.starcore.starcore.foundation.economy.insurance;

import java.math.BigDecimal;
import java.util.UUID;

/** Quote shown before a player buys coverage. */
public record InsuranceQuote(
    InsuranceCoverage coverage,
    BigDecimal maxPayout,
    BigDecimal deductible,
    BigDecimal premium,
    int durationDays,
    UUID playerId) {}
