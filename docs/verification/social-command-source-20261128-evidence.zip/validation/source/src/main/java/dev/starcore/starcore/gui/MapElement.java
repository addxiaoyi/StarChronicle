package dev.starcore.starcore.gui;

/** 地图元素接口 所有地图元素的基础接口 */
public interface MapElement {

  /** 获取图标ID */
  default String getId() {
    return "";
  }

  /** 获取图标名称 */
  default String getName() {
    return "";
  }

  /** 获取图标描述 */
  default String getDescription() {
    return "";
  }

  /** 获取X坐标 */
  default double getX() {
    return 0;
  }

  /** 获取Y坐标 */
  default double getY() {
    return 0;
  }

  /** 获取Z层级 */
  default double getZIndex() {
    return 0;
  }

  /** 检查坐标是否在元素范围内 */
  boolean contains(double x, double y);
}
