package dev.starcore.starcore.epoch;

import java.util.*;

/** 里程碑定义 表示纪元过程中需要完成的重要目标 */
public record Milestone(
    String milestoneId,
    String epochRunId,
    String name,
    String description,
    String condition,
    boolean completed,
    Long completedAt,
    List<String> dependencies) {

  public static Builder builder(String milestoneId, String epochRunId, String name) {
    return new Builder(milestoneId, epochRunId, name);
  }

  public static class Builder {
    private final String milestoneId;
    private final String epochRunId;
    private final String name;
    private String description = "";
    private String condition = "";
    private boolean completed = false;
    private Long completedAt = null;
    private List<String> dependencies = new ArrayList<>();

    public Builder(String milestoneId, String epochRunId, String name) {
      this.milestoneId = Objects.requireNonNull(milestoneId);
      this.epochRunId = Objects.requireNonNull(epochRunId);
      this.name = Objects.requireNonNull(name);
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder condition(String condition) {
      this.condition = condition;
      return this;
    }

    public Builder completed(boolean completed) {
      this.completed = completed;
      return this;
    }

    public Builder completedAt(Long completedAt) {
      this.completedAt = completedAt;
      return this;
    }

    public Builder addDependency(String dependencyId) {
      this.dependencies.add(dependencyId);
      return this;
    }

    public Builder dependencies(List<String> dependencies) {
      this.dependencies = new ArrayList<>(dependencies);
      return this;
    }

    public Milestone build() {
      return new Milestone(
          milestoneId,
          epochRunId,
          name,
          description,
          condition,
          completed,
          completed ? (completedAt != null ? completedAt : System.currentTimeMillis()) : null,
          List.copyOf(dependencies));
    }
  }
}
