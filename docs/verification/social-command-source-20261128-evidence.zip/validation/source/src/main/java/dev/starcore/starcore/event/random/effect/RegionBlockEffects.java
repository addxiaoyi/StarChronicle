package dev.starcore.starcore.event.random.effect;

import dev.starcore.starcore.event.random.RandomEventRuntime;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

/** Visits coordinates in bounded owner callbacks; no Block reference escapes its owning region. */
final class RegionBlockEffects {
  static final int MAX_RADIUS = 128;
  static final int BLOCKS_PER_TICK = 1024;

  private RegionBlockEffects() {}

  static boolean valid(Location location, int radius) {
    return location != null
        && location.getWorld() != null
        && radius >= 0
        && radius <= MAX_RADIUS
        && Double.isFinite(location.getX())
        && Double.isFinite(location.getY())
        && Double.isFinite(location.getZ())
        && Math.abs(location.getX()) + radius < 30_000_000
        && Math.abs(location.getZ()) + radius < 30_000_000
        && Math.abs(location.getY()) + radius < Integer.MAX_VALUE;
  }

  /** Synchronous compatibility entry: rejects large work and any foreign owner before mutation. */
  static boolean applyNow(Location center, int radius, Predicate<Block> effect) {
    if (!valid(center, radius) || Math.pow(2L * radius + 1, 3) > BLOCKS_PER_TICK) return false;
    Bounds bounds = new Bounds(center.clone(), radius);
    for (int cx = bounds.minX >> 4; cx <= bounds.maxX >> 4; cx++)
      for (int cz = bounds.minZ >> 4; cz <= bounds.maxZ >> 4; cz++)
        if (!Bukkit.isOwnedByCurrentRegion(
            new Location(bounds.world, cx * 16, center.getY(), cz * 16))) return false;
    boolean affected = false;
    for (int x = bounds.minX; x <= bounds.maxX; x++)
      for (int z = bounds.minZ; z <= bounds.maxZ; z++)
        for (int y = bounds.minY; y <= bounds.maxY; y++)
          affected |= effect.test(bounds.world.getBlockAt(x, y, z));
    return affected;
  }

  static CompletableFuture<Boolean> apply(
      RandomEventRuntime runtime, Location center, int radius, Predicate<Block> effect) {
    if (!valid(center, radius)) return CompletableFuture.completedFuture(false);
    Bounds bounds = new Bounds(center.clone(), radius);
    CompletableFuture<Boolean> result = CompletableFuture.completedFuture(false);
    for (int cx = bounds.minX >> 4; cx <= bounds.maxX >> 4; cx++) {
      for (int cz = bounds.minZ >> 4; cz <= bounds.maxZ >> 4; cz++) {
        ChunkScan scan = new ChunkScan(bounds, cx, cz);
        result =
            result.thenCompose(
                previous ->
                    batch(runtime, scan, effect, false).thenApply(applied -> previous || applied));
      }
    }
    return result;
  }

  private static CompletableFuture<Boolean> batch(
      RandomEventRuntime runtime, ChunkScan scan, Predicate<Block> effect, boolean affected) {
    if (scan.done()) return CompletableFuture.completedFuture(affected);
    return runtime
        .regionLater(
            scan.anchor,
            ignored -> {
              boolean applied = affected;
              for (int count = 0; count < BLOCKS_PER_TICK && !scan.done(); count++) {
                applied |= effect.test(scan.bounds.world.getBlockAt(scan.x, scan.y, scan.z));
                scan.advance();
              }
              return applied;
            })
        .thenCompose(applied -> batch(runtime, scan, effect, applied));
  }

  private static final class Bounds {
    final World world;
    final int minX, maxX, minY, maxY, minZ, maxZ;

    Bounds(Location center, int radius) {
      world = center.getWorld();
      minX = center.getBlockX() - radius;
      maxX = center.getBlockX() + radius;
      minZ = center.getBlockZ() - radius;
      maxZ = center.getBlockZ() + radius;
      minY = Math.max(world.getMinHeight(), center.getBlockY() - radius);
      maxY = Math.min(world.getMaxHeight() - 1, center.getBlockY() + radius);
    }
  }

  private static final class ChunkScan {
    final Bounds bounds;
    final Location anchor;
    final int minX, maxX, minZ, maxZ;
    int x, y, z;

    ChunkScan(Bounds bounds, int cx, int cz) {
      this.bounds = bounds;
      minX = Math.max(bounds.minX, cx * 16);
      maxX = Math.min(bounds.maxX, cx * 16 + 15);
      minZ = Math.max(bounds.minZ, cz * 16);
      maxZ = Math.min(bounds.maxZ, cz * 16 + 15);
      x = minX;
      y = bounds.minY;
      z = minZ;
      anchor = new Location(bounds.world, x, y, z);
    }

    boolean done() {
      return x > maxX || bounds.minY > bounds.maxY;
    }

    void advance() {
      if (++y > bounds.maxY) {
        y = bounds.minY;
        if (++z > maxZ) {
          z = minZ;
          x++;
        }
      }
    }
  }
}
