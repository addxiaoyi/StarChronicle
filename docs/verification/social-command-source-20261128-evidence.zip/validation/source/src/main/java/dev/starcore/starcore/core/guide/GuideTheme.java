package dev.starcore.starcore.core.guide;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

/** 指南主题 - 每章独立彩色主题 */
public enum GuideTheme {
  STARCORE_GOLD(
      "STARCORE", NamedTextColor.GOLD, Material.GOLDEN_APPLE, Material.YELLOW_STAINED_GLASS_PANE),
  GETTING_STARTED(
      "新手入门", NamedTextColor.AQUA, Material.IRON_INGOT, Material.CYAN_STAINED_GLASS_PANE),
  NATION_BUILDING(
      "国家建设",
      NamedTextColor.LIGHT_PURPLE,
      Material.COBBLESTONE,
      Material.PURPLE_STAINED_GLASS_PANE),
  ECONOMY("经济系统", NamedTextColor.YELLOW, Material.GOLD_INGOT, Material.YELLOW_STAINED_GLASS_PANE),
  MILITARY("军事系统", NamedTextColor.RED, Material.IRON_SWORD, Material.RED_STAINED_GLASS_PANE),
  DIPLOMACY("外交系统", NamedTextColor.WHITE, Material.PAPER, Material.WHITE_STAINED_GLASS_PANE),
  TECHNOLOGY(
      "科技研究", NamedTextColor.GREEN, Material.CRAFTING_TABLE, Material.GREEN_STAINED_GLASS_PANE),
  SOCIAL("社交生活", NamedTextColor.BLUE, Material.NAME_TAG, Material.BLUE_STAINED_GLASS_PANE),
  SPECIAL(
      "特色玩法", NamedTextColor.LIGHT_PURPLE, Material.DIAMOND, Material.MAGENTA_STAINED_GLASS_PANE);

  private final String displayName;
  private final NamedTextColor color;
  private final Material icon;
  private final Material borderGlass;

  GuideTheme(String displayName, NamedTextColor color, Material icon, Material borderGlass) {
    this.displayName = displayName;
    this.color = color;
    this.icon = icon;
    this.borderGlass = borderGlass;
  }

  public String getDisplayName() {
    return displayName;
  }

  public NamedTextColor getColor() {
    return color;
  }

  public Material getIcon() {
    return icon;
  }

  public Material getBorderGlass() {
    return borderGlass;
  }
}
