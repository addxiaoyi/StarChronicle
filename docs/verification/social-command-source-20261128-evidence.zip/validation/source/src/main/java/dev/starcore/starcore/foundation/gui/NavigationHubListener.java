package dev.starcore.starcore.foundation.gui;

import java.util.logging.Logger;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * {@link NavigationHubMenu} 的点击监听器。
 *
 * <p>通过 {@link InventoryHolder} 身份识别导航中枢，不依赖标题文本。 所有交互都会被取消（防拿取），点击导航按钮则派发对应模块的打开命令。
 */
public final class NavigationHubListener implements Listener {

  private static final Logger LOGGER = Logger.getLogger(NavigationHubListener.class.getName());

  public NavigationHubListener() {
    // No-arg constructor for Bukkit instantiation
  }

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
  public void onClick(InventoryClickEvent event) {
    InventoryHolder holder = event.getInventory().getHolder();
    if (!(holder instanceof NavigationHubMenu hub)) {
      return;
    }

    event.setCancelled(true);

    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    if (!hub.isCurrentSession(player, event.getInventory())) return;

    // 只响应顶部菜单本身的点击
    if (event.getClickedInventory() == null
        || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
      return;
    }

    int slot = event.getRawSlot();
    if (slot == 45) {
      player.closeInventory();
      return;
    }
    if (slot == 49) {
      player.sendMessage(
          net.kyori.adventure.text.Component.text(
              hub.availabilitySummary(), net.kyori.adventure.text.format.NamedTextColor.AQUA));
      player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.1f);
      return;
    }

    NavigationHubMenu.Entry entry = hub.entryForSlot(slot);
    String command = entry == null ? null : entry.command();
    if (command == null || command.isBlank()) {
      return;
    }

    String unavailable = hub.unavailableReason(command, player);
    if (unavailable != null) {
      player.sendMessage(
          net.kyori.adventure.text.Component.text(
              unavailable, net.kyori.adventure.text.format.NamedTextColor.YELLOW));
      return;
    }

    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
    if (hub.executeInstanceHandler(command, player)) {
      return;
    }

    // Handler 未注册时发送提示信息
    player.sendMessage(
        net.kyori.adventure.text.Component.text(
            "此功能当前不可用，请稍后重试", net.kyori.adventure.text.format.NamedTextColor.YELLOW));
    LOGGER.warning("导航命令未处理: " + command);
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof NavigationHubMenu) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onClose(InventoryCloseEvent event) {
    if (event.getInventory().getHolder() instanceof NavigationHubMenu hub) {
      hub.stopRefresh(event.getInventory());
    }
  }
}
