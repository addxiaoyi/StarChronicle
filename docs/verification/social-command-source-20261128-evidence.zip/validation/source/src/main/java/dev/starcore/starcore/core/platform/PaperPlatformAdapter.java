package dev.starcore.starcore.core.platform;

public final class PaperPlatformAdapter implements PlatformAdapter {
    private static final SemanticVersion LEGACY_MIN_PLANNED = new SemanticVersion(1, 21, 9);
    private static final SemanticVersion LEGACY_VALIDATED_TARGET = new SemanticVersion(1, 21, 11);
    private static final SemanticVersion CALENDAR_MIN_PLANNED = new SemanticVersion(26, 1, 0);

    private final String minecraftVersion;
    private final String apiVersion;
    private final SemanticVersion parsedMinecraftVersion;

    public PaperPlatformAdapter(String minecraftVersion, String apiVersion) {
        this.minecraftVersion = minecraftVersion;
        this.apiVersion = apiVersion;
        this.parsedMinecraftVersion = SemanticVersion.parse(minecraftVersion);
    }

    @Override
    public String platformName() {
        return "Paper";
    }

    @Override
    public String minecraftVersion() {
        return minecraftVersion;
    }

    @Override
    public String apiVersion() {
        return apiVersion;
    }

    @Override
    public CompatibilityStatus compatibilityStatus() {
        if (isValidatedRelease()) {
            return CompatibilityStatus.SUPPORTED;
        }
        if (isPlannedRelease()) {
            return CompatibilityStatus.PLANNED;
        }
        return CompatibilityStatus.UNSUPPORTED;
    }

    @Override
    public String supportSummary() {
        return switch (compatibilityStatus()) {
            case SUPPORTED ->
                "validated on Paper/Minecraft 1.21.11 and 26.3 (API " + apiVersion + ")";
            case PLANNED ->
                "adapter supports the 1.21.9+ legacy and 26.1+ calendar version families; runtime validation pending (API "
                    + apiVersion
                    + ")";
            case UNSUPPORTED ->
                "outside current STARCORE compatibility window (API " + apiVersion + ")";
        };
    }

    private boolean isValidatedRelease() {
        return parsedMinecraftVersion.equals(LEGACY_VALIDATED_TARGET)
            || isCalendarRelease(26, 3);
    }

    private boolean isPlannedRelease() {
        boolean legacyRelease =
            parsedMinecraftVersion.major() == 1
                && parsedMinecraftVersion.minor() == 21
                && parsedMinecraftVersion.compareTo(LEGACY_MIN_PLANNED) >= 0;
        boolean calendarRelease = parsedMinecraftVersion.compareTo(CALENDAR_MIN_PLANNED) >= 0;
        return legacyRelease || calendarRelease;
    }

    private boolean isCalendarRelease(int major, int minor) {
        return parsedMinecraftVersion.major() == major && parsedMinecraftVersion.minor() == minor;
    }
}
