package dev.starcore.starcore.dummy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.plugin.Plugin;

/** 训练排行榜 记录每位玩家历史最高 DPS，并以 JSON 持久化到插件数据目录。 内存读写发生在主线程，磁盘写入通过异步任务执行。 */
public final class DummyLeaderboard {

  /** 单条最好成绩，字段保持 public 以便 Gson 直接序列化 */
  public static final class Entry {
    public String playerId;
    public String name;
    public double bestDps;
    public double bestDamage;
    public long achievedAt;

    public Entry() {
      // Gson 反序列化需要无参构造
    }
  }

  private final Map<String, Entry> best = new ConcurrentHashMap<>();
  private final File file;
  private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

  public DummyLeaderboard(File dataFolder) {
    this.file = new File(dataFolder, "dummy-leaderboard.json");
    load();
  }

  /**
   * 提交一次成绩，仅当 DPS 高于历史记录时更新
   *
   * @return 是否刷新了记录
   */
  public boolean submit(UUID playerId, String name, double dps, double damage) {
    if (dps <= 0) {
      return false;
    }

    String key = playerId.toString();
    Entry current = best.get(key);
    if (current != null && current.bestDps >= dps) {
      current.name = name;
      return false;
    }

    Entry entry = new Entry();
    entry.playerId = key;
    entry.name = name;
    entry.bestDps = dps;
    entry.bestDamage = damage;
    entry.achievedAt = System.currentTimeMillis();
    best.put(key, entry);
    return true;
  }

  /** 按 DPS 降序返回前 n 名 */
  public List<Entry> top(int limit) {
    List<Entry> ranked = new ArrayList<>(best.values());
    ranked.sort(Comparator.comparingDouble((Entry e) -> e.bestDps).reversed());
    return ranked.size() > limit ? new ArrayList<>(ranked.subList(0, limit)) : ranked;
  }

  /** 异步落盘，避免阻塞主线程 */
  public void saveAsync(Plugin plugin) {
    plugin.getServer().getScheduler().runTaskAsynchronously(plugin, this::save);
  }

  public void save() {
    Map<String, Entry> snapshot = new ConcurrentHashMap<>(best);
    try {
      File parent = file.getParentFile();
      if (parent != null && !parent.exists() && !parent.mkdirs()) {
        return;
      }
      try (Writer writer = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
        gson.toJson(snapshot, writer);
      }
    } catch (IOException ignored) {
      // 排行榜为可选功能，落盘失败不影响训练主流程
    }
  }

  private void load() {
    if (!file.isFile()) {
      return;
    }

    try (Reader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
      Type type = new TypeToken<Map<String, Entry>>() {}.getType();
      Map<String, Entry> loaded = gson.fromJson(reader, type);
      if (loaded != null) {
        loaded.forEach(
            (key, entry) -> {
              if (entry != null && entry.playerId != null) {
                best.put(key, entry);
              }
            });
      }
    } catch (IOException | RuntimeException ignored) {
      // 文件损坏时以空榜启动
    }
  }
}
