package dev.starcore.starcore.foundation.gui;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

final class NavigationRouter {
  private final Map<String, Function<Player, Boolean>> handlers = new ConcurrentHashMap<>();
  private final Map<String, List<RouteGate>> gates = new ConcurrentHashMap<>();
  private final Logger logger = Logger.getLogger(NavigationRouter.class.getName());

  void registerHandler(String route, Function<Player, Boolean> handler) {
    handlers.put(Objects.requireNonNull(route), Objects.requireNonNull(handler));
  }

  void unregisterHandler(String route) {
    if (route == null) return;
    handlers.remove(route);
    gates.remove(route);
  }

  boolean hasHandler(String route) {
    return route != null && handlers.containsKey(route);
  }

  void registerGate(String route, Predicate<Player> allowed, String reason) {
    gates
        .computeIfAbsent(route, ignored -> new CopyOnWriteArrayList<>())
        .add(new RouteGate(allowed, reason));
  }

  String unavailableReason(String route, Player player) {
    if (!hasHandler(route)) return "模块未启用";
    List<RouteGate> routeGates = gates.get(route);
    if (routeGates == null) return null;
    for (RouteGate gate : routeGates) {
      try {
        if (!gate.allowed().test(player)) return gate.reason();
      } catch (RuntimeException failure) {
        logger.log(Level.WARNING, "Navigation availability check failed: " + route, failure);
        return "状态暂不可用";
      }
    }
    return null;
  }

  boolean executeHandler(String route, Player player) {
    Function<Player, Boolean> handler = handlers.get(route);
    if (handler == null || unavailableReason(route, player) != null) return false;
    try {
      Inventory before =
          player == null || !player.isOnline() ? null : player.getOpenInventory().getTopInventory();
      Component beforeTitle = before == null ? null : player.getOpenInventory().title();
      int beforeSize = before == null ? -1 : before.getSize();
      boolean handled = Boolean.TRUE.equals(handler.apply(player));
      if (player == null || before == null) return handled;
      Inventory after = player.getOpenInventory().getTopInventory();
      return after != before
          || after.getSize() != beforeSize
          || !Objects.equals(player.getOpenInventory().title(), beforeTitle);
    } catch (RuntimeException failure) {
      logger.log(Level.WARNING, "Navigation handler failed: " + route, failure);
      return false;
    }
  }

  List<String> missingRoutes(Map<Integer, NavigationHubMenu.Entry> entries) {
    return entries.values().stream()
        .filter(entry -> !hasHandler(entry.command()))
        .map(entry -> entry.nameFallback() + " (" + entry.command() + ")")
        .toList();
  }

  void clear() {
    handlers.clear();
    gates.clear();
  }

  private record RouteGate(Predicate<Player> allowed, String reason) {}
}

public final class NavigationHubMenu implements InventoryHolder {
  private static final int SIZE = 54;
  private static final int SLOT_CLOSE = 45;
  private static final int SLOT_STATUS = 49;
  private static final NavigationRouter STATIC_ROUTER = new NavigationRouter();
  private static final Set<NavigationHubMenu> ACTIVE_MENUS = ConcurrentHashMap.newKeySet();
  private static final AtomicLong LIFECYCLE = new AtomicLong();

  private final Map<Integer, Entry> entries = defaultEntries();
  private final Map<Integer, String> availabilityStates = new LinkedHashMap<>();
  private final NavigationRouter router;
  private final Plugin plugin;
  private final PlayerMenuTasks ownerTasks;
  private final Object refreshLock = new Object();
  private final long lifecycle = LIFECYCLE.get();
  private volatile Inventory inventory;
  private RefreshSession refreshSession;

  public static NavigationRouter defaultRouter() {
    return STATIC_ROUTER;
  }

  public static void registerHandler(String route, Consumer<Player> handler) {
    STATIC_ROUTER.registerHandler(
        route,
        player -> {
          handler.accept(player);
          return true;
        });
  }

  public static void registerResultHandler(String route, Function<Player, Boolean> handler) {
    STATIC_ROUTER.registerHandler(route, handler);
  }

  public static void unregisterHandler(String route) {
    STATIC_ROUTER.unregisterHandler(route);
  }

  public static void registerGate(String route, Predicate<Player> allowed, String reason) {
    STATIC_ROUTER.registerGate(route, allowed, reason);
  }

  public static String routeUnavailableReason(String route, Player player) {
    return STATIC_ROUTER.unavailableReason(route, player);
  }

  public static boolean hasHandler(String route) {
    return STATIC_ROUTER.hasHandler(route);
  }

  public static boolean executeHandler(String route, Player player) {
    return STATIC_ROUTER.executeHandler(route, player);
  }

  public static List<String> unavailableRoutes() {
    return STATIC_ROUTER.missingRoutes(defaultEntries());
  }

  public static void clearHandlers() {
    LIFECYCLE.incrementAndGet();
    for (NavigationHubMenu menu : List.copyOf(ACTIVE_MENUS)) menu.shutdown();
    STATIC_ROUTER.clear();
  }

  public NavigationHubMenu(NavigationRouter router, Plugin plugin) {
    this.router = Objects.requireNonNull(router);
    this.plugin = plugin;
    this.ownerTasks = plugin == null ? null : new PlayerMenuTasks(plugin);
  }

  public NavigationHubMenu() {
    this(STATIC_ROUTER, null);
  }

  public void registerInstanceHandler(String route, Function<Player, Boolean> handler) {
    router.registerHandler(route, handler);
  }

  public void unregisterInstanceHandler(String route) {
    router.unregisterHandler(route);
  }

  public boolean hasInstanceHandler(String route) {
    return router.hasHandler(route);
  }

  public boolean executeInstanceHandler(String route, Player player) {
    return router.executeHandler(route, player);
  }

  public String unavailableReason(String route, Player player) {
    return router.unavailableReason(route, player);
  }

  public String availabilitySummary() {
    long ready = availabilityStates.values().stream().filter(Objects::isNull).count();
    return GuiText.get(
        null,
        "navigation.status_summary",
        "{ready} / {total} routes ready",
        "ready",
        ready,
        "total",
        entries.size());
  }

  record Entry(
      Material icon,
      String nameKey,
      String nameFallback,
      String descriptionKey,
      String descriptionFallback,
      String command,
      String groupKey,
      String groupFallback) {}

  private static Map<Integer, Entry> defaultEntries() {
    Map<Integer, Entry> entries = new LinkedHashMap<>();
    entries.put(
        10,
        entry(
            Material.GOLDEN_HELMET,
            "navigation.nation",
            "Nation",
            "navigation.nation_lore",
            "Members, territory and nation overview.",
            "sc nation gui",
            "navigation.group_governance",
            "Governance"));
    entries.put(
        12,
        entry(
            Material.PAPER,
            "navigation.government",
            "Government",
            "navigation.government_lore",
            "Government type, reform and national policy.",
            "sc government gui",
            "navigation.group_governance",
            "Governance"));
    entries.put(
        14,
        entry(
            Material.NAME_TAG,
            "navigation.officer",
            "Officers",
            "navigation.officer_lore",
            "Appointments, member duties and permissions.",
            "sc officer gui",
            "navigation.group_governance",
            "Governance"));
    entries.put(
        16,
        entry(
            Material.WHITE_BANNER,
            "navigation.diplomacy",
            "Diplomacy",
            "navigation.diplomacy_lore",
            "Manage relations, alliances and treaties.",
            "diplomacy",
            "navigation.group_governance",
            "Governance"));
    entries.put(
        20,
        entry(
            Material.ENCHANTING_TABLE,
            "navigation.technology",
            "Technology",
            "navigation.technology_lore",
            "Research progress, levels and upgrades.",
            "tech gui",
            "navigation.group_development",
            "Development"));
    entries.put(
        22,
        entry(
            Material.IRON_SWORD,
            "navigation.war",
            "War",
            "navigation.war_lore",
            "War status, battlefield actions and ceasefires.",
            "war gui",
            "navigation.group_military",
            "Military"));
    entries.put(
        24,
        entry(
            Material.SHIELD,
            "navigation.army",
            "Army",
            "navigation.army_lore",
            "Manage national forces, training and deployment.",
            "army",
            "navigation.group_military",
            "Military"));
    entries.put(
        26,
        entry(
            Material.NETHER_STAR,
            "navigation.gameplay",
            "Gameplay",
            "navigation.gameplay_lore",
            "Check-in, daily goals, events and progress.",
            "gameplay",
            "navigation.group_development",
            "Development"));
    entries.put(
        29,
        entry(
            Material.WHEAT,
            "navigation.resources",
            "Resources",
            "navigation.resources_lore",
            "Inventory, market prices, reserves and trade.",
            "resourcegui",
            "navigation.group_economy",
            "Economy"));
    entries.put(
        31,
        entry(
            Material.GOLD_INGOT,
            "navigation.treasury",
            "Treasury",
            "navigation.treasury_lore",
            "Balance, finance records and tax management.",
            "sc treasury gui",
            "navigation.group_economy",
            "Economy"));
    entries.put(
        33,
        entry(
            Material.DIAMOND,
            "navigation.city",
            "City",
            "navigation.city_lore",
            "Manage city development and public works.",
            "sc city gui",
            "navigation.group_economy",
            "Economy"));
    entries.put(
        35,
        entry(
            Material.NETHERITE_SWORD,
            "navigation.dungeon",
            "Dungeons",
            "navigation.dungeon_lore",
            "Choose an instance, challenge bosses and claim rewards.",
            "dungeon",
            "navigation.group_adventure",
            "Adventure"));
    entries.put(
        38,
        entry(
            Material.SKELETON_SKULL,
            "navigation.ranking",
            "Rankings",
            "navigation.ranking_lore",
            "Player, nation and competitive standings.",
            "rank",
            "navigation.group_honors",
            "Honors"));
    entries.put(
        40,
        entry(
            Material.BOOKSHELF,
            "navigation.guide",
            "Guide",
            "navigation.guide_lore",
            "Rules, onboarding and system references.",
            "guide",
            "navigation.group_guide",
            "Guide"));
    entries.put(
        42,
        entry(
            Material.CHEST,
            "navigation.quests",
            "Quests",
            "navigation.quests_lore",
            "Objectives, progress and unclaimed rewards.",
            "questgui",
            "navigation.group_progress",
            "Progress"));
    entries.put(
        44,
        entry(
            Material.NAME_TAG,
            "navigation.titles",
            "Titles",
            "navigation.titles_lore",
            "Collection, unlock conditions and display.",
            "title list",
            "navigation.group_identity",
            "Identity"));
    entries.put(
        46,
        entry(
            Material.PLAYER_HEAD,
            "navigation.social",
            "Social",
            "navigation.social_lore",
            "Friends, guilds, parties and messages.",
            "socialgui",
            "navigation.group_social",
            "Social"));
    entries.put(
        47,
        entry(
            Material.BEACON,
            "navigation.achievements",
            "Achievements",
            "navigation.achievements_lore",
            "Track milestones and claim achievement rewards.",
            "achievements",
            "navigation.group_honors",
            "Honors"));
    entries.put(
        48,
        entry(
            Material.WRITABLE_BOOK,
            "navigation.resolutions",
            "Resolutions",
            "navigation.resolutions_lore",
            "Proposals, votes and national policy.",
            "resolution",
            "navigation.group_governance",
            "Governance"));
    entries.put(
        50,
        entry(
            Material.HEART_OF_THE_SEA,
            "navigation.weather",
            "Weather",
            "navigation.weather_lore",
            "Regional weather, climate effects and tactics.",
            "weathermenu",
            "navigation.group_development",
            "Development"));
    entries.put(
        52,
        entry(
            Material.CAKE,
            "navigation.events",
            "Events",
            "navigation.events_lore",
            "Open competitions, eligibility and schedules.",
            "tournament",
            "navigation.group_competition",
            "Competition"));
    return entries;
  }

  private static Entry entry(
      Material icon,
      String nameKey,
      String nameFallback,
      String descriptionKey,
      String descriptionFallback,
      String command,
      String groupKey,
      String groupFallback) {
    return new Entry(
        icon,
        nameKey,
        nameFallback,
        descriptionKey,
        descriptionFallback,
        command,
        groupKey,
        groupFallback);
  }

  private record SectionLabel(int slot, String key, String fallback, NamedTextColor color) {}

  private static final List<SectionLabel> SECTIONS =
      List.of(
          new SectionLabel(9, "navigation.section_governance", "Governance", NamedTextColor.GOLD),
          new SectionLabel(18, "navigation.section_strategy", "Strategy", NamedTextColor.AQUA),
          new SectionLabel(27, "navigation.section_economy", "Economy", NamedTextColor.GREEN),
          new SectionLabel(
              36, "navigation.section_community", "Community", NamedTextColor.LIGHT_PURPLE));

  @Override
  public Inventory getInventory() {
    return inventory;
  }

  Entry entryForSlot(int slot) {
    return entries.get(slot);
  }

  private void build(Player player) {
    inventory =
        Bukkit.createInventory(
            this,
            SIZE,
            GuiText.component(player, "navigation.title", "STARCORE  ·  Overview")
                .color(NamedTextColor.DARK_GRAY));
    populate(player, inventory);
  }

  private void populate(Player player, Inventory inventory) {
    inventory.setItem(
        4,
        VisualComponent.button(
            Material.COMPASS,
            GuiText.component(player, "navigation.brand", "STARCORE").color(NamedTextColor.GOLD),
            List.of(
                GuiText.component(
                        player, "navigation.brand_lore", "World  ·  Nations  ·  Community")
                    .color(NamedTextColor.GRAY),
                GuiText.component(player, "navigation.live_status", "Live module status")
                    .color(NamedTextColor.DARK_GRAY))));

    for (SectionLabel section : SECTIONS) {
      inventory.setItem(
          section.slot(),
          VisualComponent.button(
              Material.PAPER,
              GuiText.component(player, section.key(), section.fallback()).color(section.color()),
              List.of()));
    }

    availabilityStates.clear();
    for (Map.Entry<Integer, Entry> slotEntry : entries.entrySet()) {
      Entry entry = slotEntry.getValue();
      String reason = router.unavailableReason(entry.command(), player);
      availabilityStates.put(slotEntry.getKey(), reason);
      List<Component> lore =
          List.of(
              GuiText.component(player, entry.descriptionKey(), entry.descriptionFallback())
                  .color(NamedTextColor.GRAY),
              Component.empty(),
              GuiText.component(player, entry.groupKey(), entry.groupFallback())
                  .color(NamedTextColor.DARK_GRAY),
              GuiText.component(
                      player,
                      reason == null ? "navigation.open" : "navigation.unavailable",
                      reason == null ? "Open" : "Unavailable: " + reason,
                      "reason",
                      reason == null ? "" : reason)
                  .color(reason == null ? NamedTextColor.AQUA : NamedTextColor.RED));
      inventory.setItem(
          slotEntry.getKey(),
          VisualComponent.button(
              entry.icon(),
              GuiText.component(player, entry.nameKey(), entry.nameFallback())
                  .color(categoryColor(entry.groupFallback())),
              lore));
    }

    inventory.setItem(SLOT_CLOSE, ButtonFactory.createCloseButton(player));
    inventory.setItem(
        SLOT_STATUS,
        VisualComponent.button(
            Material.NETHER_STAR,
            GuiText.component(player, "navigation.status", "Status").color(NamedTextColor.AQUA),
            List.of(
                GuiText.component(
                        player,
                        "navigation.status_summary",
                        "{ready} / {total} routes ready",
                        "ready",
                        availabilityStates.values().stream().filter(Objects::isNull).count(),
                        "total",
                        entries.size())
                    .color(NamedTextColor.GRAY),
                GuiText.component(player, "navigation.live_status", "Live module status")
                    .color(NamedTextColor.DARK_GRAY))));
  }

  private static NamedTextColor categoryColor(String group) {
    return switch (group) {
      case "国家" -> NamedTextColor.GOLD;
      case "发展", "军事", "冒险" -> NamedTextColor.AQUA;
      case "经济" -> NamedTextColor.GREEN;
      default -> NamedTextColor.LIGHT_PURPLE;
    };
  }

  public void open(Player player) {
    if (player == null) return;
    if (ownerTasks != null) {
      ACTIVE_MENUS.add(this);
      ownerTasks
          .execute(player, null, () -> openOwned(player))
          .whenComplete(
              (ignored, failure) -> {
                if (failure != null) shutdown();
              });
    } else {
      if (!Bukkit.isOwnedByCurrentRegion(player)) {
        throw new IllegalStateException("Navigation menu requires the original player owner");
      }
      openOwned(player);
    }
  }

  private void openOwned(Player player) {
    synchronized (refreshLock) {
      if (lifecycle != LIFECYCLE.get()) {
        ACTIVE_MENUS.remove(this);
        return;
      }
      if (refreshSession != null) {
        RefreshSession previous = refreshSession;
        refreshSession = null;
        cancelRefreshTask(previous.task);
      }
      if (ownerTasks != null) ACTIVE_MENUS.add(this);
      build(player);
      player.openInventory(inventory);
      if (plugin == null) return;
      RefreshSession session = new RefreshSession(player, inventory);
      refreshSession = session;
      try {
        ScheduledTask task =
            player
                .getScheduler()
                .runAtFixedRate(
                    plugin,
                    ignored ->
                        ownerTasks
                            .execute(player, null, () -> refreshAvailability(session))
                            .whenComplete(
                                (unused, failure) -> {
                                  if (failure != null) stopRefreshSession(session);
                                }),
                    () -> stopRefreshSession(session),
                    20L,
                    20L);
        session.task = task;
        if (task == null || refreshSession != session) {
          cancelRefreshTask(task);
          if (task == null) stopRefreshSession(session);
        }
      } catch (RuntimeException failure) {
        stopRefreshSession(session);
        throw failure;
      }
    }
  }

  private void refreshAvailability(RefreshSession session) {
    if (lifecycle != LIFECYCLE.get() || !ownerTasks.valid(session.player, session.inventory)) {
      stopRefreshSession(session);
      return;
    }
    synchronized (refreshLock) {
      if (refreshSession != session) return;
      Player player = session.player;
      boolean changed =
          entries.entrySet().stream()
              .anyMatch(
                  entry ->
                      !Objects.equals(
                          availabilityStates.get(entry.getKey()),
                          router.unavailableReason(entry.getValue().command(), player)));
      if (!changed) return;

      Inventory openInventory = session.inventory;
      Inventory contents = Bukkit.createInventory(null, SIZE);
      populate(player, contents);
      for (int slot = 0; slot < SIZE; slot++) {
        ItemStack next = contents.getItem(slot);
        if (!Objects.equals(openInventory.getItem(slot), next)) {
          openInventory.setItem(slot, next == null ? null : next.clone());
        }
      }
    }
  }

  void stopRefresh() {
    synchronized (refreshLock) {
      if (refreshSession != null) stopRefreshSession(refreshSession);
    }
  }

  void stopRefresh(Inventory expectedInventory) {
    synchronized (refreshLock) {
      if (refreshSession != null && refreshSession.inventory == expectedInventory) {
        stopRefreshSession(refreshSession);
      }
    }
  }

  private void stopRefreshSession(RefreshSession session) {
    synchronized (refreshLock) {
      if (refreshSession != session) return;
      refreshSession = null;
      ACTIVE_MENUS.remove(this);
      cancelRefreshTask(session.task);
    }
  }

  private static void cancelRefreshTask(ScheduledTask task) {
    if (task == null) return;
    try {
      task.cancel();
    } catch (IllegalStateException ignored) {
    }
  }

  public void shutdown() {
    if (ownerTasks != null) ownerTasks.shutdown();
    stopRefresh();
    ACTIVE_MENUS.remove(this);
  }

  boolean isCurrentSession(Player player, Inventory expected) {
    if (lifecycle != LIFECYCLE.get() || inventory != expected) return false;
    if (ownerTasks != null && !ownerTasks.valid(player, expected)) return false;
    synchronized (refreshLock) {
      return plugin == null || (refreshSession != null && refreshSession.player == player);
    }
  }

  private static final class RefreshSession {
    final Player player;
    final Inventory inventory;
    ScheduledTask task;

    RefreshSession(Player player, Inventory inventory) {
      this.player = player;
      this.inventory = inventory;
    }
  }

  public static void openHub(Plugin plugin, Player player) {
    if (plugin != null && player != null) new NavigationHubMenu(STATIC_ROUTER, plugin).open(player);
  }
}
