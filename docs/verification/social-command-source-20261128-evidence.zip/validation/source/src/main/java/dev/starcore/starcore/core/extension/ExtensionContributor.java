package dev.starcore.starcore.core.extension;

/**
 * 扩展贡献者接口 实现此接口的类可以向扩展点贡献功能
 *
 * @param <T> 返回值类型
 * @param <R> 请求/输入参数类型
 */
public interface ExtensionContributor<T, R> {

  /** 获取贡献者的唯一标识符 */
  String getId();

  /** 获取贡献者的名称 */
  String getName();

  /** 获取贡献者的描述 */
  default String getDescription() {
    return "";
  }

  /** 获取贡献者的优先级（数值越小优先级越高） */
  default int getPriority() {
    return 100;
  }

  /** 贡献逻辑 处理请求并返回结果 */
  T contribute(R request);

  /** 检查此贡献者是否适用于给定的请求 */
  default boolean isApplicable(R request) {
    return true;
  }

  /** 获取贡献者的版本 */
  default String getVersion() {
    return "1.0.0";
  }

  /** 获取贡献者的作者 */
  default String getAuthor() {
    return "Unknown";
  }
}
