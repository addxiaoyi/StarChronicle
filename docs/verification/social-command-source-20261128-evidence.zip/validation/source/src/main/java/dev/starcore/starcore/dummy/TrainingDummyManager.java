package dev.starcore.starcore.dummy;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * 训练假人管理器 使用 Paper API 和 ArmorStand 实现，负责生成、伤害统计、会话、HUD 与排行榜。 伤害事件均在主线程触发；统计读写使用线程安全集合，排行榜落盘走异步任务。
 */
public final class TrainingDummyManager implements Listener {

  private static final long HUD_INTERVAL_TICKS = 10L;
  private static final double FACE_RANGE = 12.0;

  private final Plugin plugin;

  // 所有假人
  private final Map<UUID, TrainingDummy> dummies = new ConcurrentHashMap<>();

  // 实体 -> 假人映射
  private final Map<UUID, UUID> entityToDummy = new ConcurrentHashMap<>();

  // 玩家 -> 当前训练会话（每玩家独立）
  private final Map<UUID, TrainingSession> sessions = new ConcurrentHashMap<>();

  // 关闭 HUD / 命中反馈的玩家（默认开启）
  private final Set<UUID> hudDisabled = ConcurrentHashMap.newKeySet();
  private final Set<UUID> feedbackDisabled = ConcurrentHashMap.newKeySet();

  private DummyLeaderboard leaderboard;

  public TrainingDummyManager(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 初始化 */
  public void init() {
    plugin.getServer().getPluginManager().registerEvents(this, plugin);
    this.leaderboard = new DummyLeaderboard(plugin.getDataFolder());

    // 500ms 刷新一次：血量条仅对变化项刷新，同时处理转向与 HUD
    new BukkitRunnable() {
      @Override
      public void run() {
        tick();
      }
    }.runTaskTimer(plugin, 0L, HUD_INTERVAL_TICKS);

    plugin.getLogger().info("✅ 训练假人系统已启用");
  }

  /** 创建假人（默认 STANDARD 类型） */
  public TrainingDummy createDummy(String name, Location location) {
    return createDummy(name, location, TrainingDummyType.STANDARD);
  }

  /** 创建指定类型的假人 */
  public TrainingDummy createDummy(String name, Location location, TrainingDummyType type) {
    UUID id = UUID.randomUUID();
    TrainingDummy dummy = new TrainingDummy(id, name, location);
    dummy.applyType(type);
    dummies.put(id, dummy);
    return dummy;
  }

  /** 生成假人（使用 ArmorStand） */
  public boolean spawnDummy(UUID dummyId) {
    TrainingDummy dummy = dummies.get(dummyId);
    if (dummy == null || dummy.isSpawned()) {
      return false;
    }

    try {
      Location loc = dummy.getLocation();
      ArmorStand stand =
          loc.getWorld()
              .spawn(
                  loc,
                  ArmorStand.class,
                  entity -> {
                    entity.setCustomName(dummy.getName());
                    entity.setCustomNameVisible(true);
                    entity.setGravity(false);
                    entity.setInvulnerable(dummy.isInvulnerable());
                    entity.setCanPickupItems(false);
                    entity.setArms(true);
                    entity.setBasePlate(true);
                    entity.setVisible(true);

                    // 设置装备
                    if (dummy.getHelmet() != null) entity.setHelmet(dummy.getHelmet());
                    if (dummy.getChestplate() != null) entity.setChestplate(dummy.getChestplate());
                    if (dummy.getLeggings() != null) entity.setLeggings(dummy.getLeggings());
                    if (dummy.getBoots() != null) entity.setBoots(dummy.getBoots());
                    if (dummy.getMainHand() != null) {
                      entity.getEquipment().setItemInMainHand(dummy.getMainHand());
                    }
                    if (dummy.getOffHand() != null) {
                      entity.getEquipment().setItemInOffHand(dummy.getOffHand());
                    }
                  });

      dummy.setNpcEntity(stand);
      dummy.setSpawned(true);
      entityToDummy.put(stand.getUniqueId(), dummyId);

      return true;

    } catch (Exception e) {
      plugin.getLogger().warning("生成假人失败: " + e.getMessage());
      return false;
    }
  }

  /** 取消生成假人 */
  public boolean despawnDummy(UUID dummyId) {
    TrainingDummy dummy = dummies.get(dummyId);
    if (dummy == null || !dummy.isSpawned()) {
      return false;
    }

    try {
      Object entity = dummy.getNpcEntity();
      if (entity instanceof Entity bukkitEntity && !bukkitEntity.isDead()) {
        entityToDummy.remove(bukkitEntity.getUniqueId());
        bukkitEntity.remove();
      }

      dummy.setNpcEntity(null);
      dummy.setSpawned(false);
      return true;

    } catch (Exception e) {
      plugin.getLogger().warning("取消生成假人失败: " + e.getMessage());
      return false;
    }
  }

  /** 删除假人 */
  public boolean removeDummy(UUID dummyId) {
    TrainingDummy dummy = dummies.get(dummyId);
    if (dummy == null) {
      return false;
    }

    if (dummy.isSpawned()) {
      despawnDummy(dummyId);
    }

    dummies.remove(dummyId);
    return true;
  }

  /** 获取假人 */
  public Optional<TrainingDummy> getDummy(UUID dummyId) {
    return Optional.ofNullable(dummies.get(dummyId));
  }

  /** 通过实体获取假人 */
  public Optional<TrainingDummy> getDummyByEntity(Entity entity) {
    UUID dummyId = entityToDummy.get(entity.getUniqueId());
    if (dummyId != null) {
      return getDummy(dummyId);
    }
    return Optional.empty();
  }

  /** 检查是否为假人 */
  public boolean isDummy(Entity entity) {
    return entityToDummy.containsKey(entity.getUniqueId());
  }

  /** 获取所有假人 */
  public Collection<TrainingDummy> getAllDummies() {
    return List.copyOf(dummies.values());
  }

  // ==================== 训练会话 ====================

  /** 开始一次训练会话（同一玩家重复开始会先结束旧会话） */
  public TrainingSession startSession(Player player, UUID dummyId) {
    TrainingDummy dummy = dummies.get(dummyId);
    if (dummy == null) {
      return null;
    }

    stopSession(player);

    TrainingSession session = new TrainingSession(player.getUniqueId(), dummyId);
    session.start();
    sessions.put(player.getUniqueId(), session);
    return session;
  }

  /** 结束玩家训练会话，返回结算结果 */
  public TrainingSession stopSession(Player player) {
    TrainingSession session = sessions.get(player.getUniqueId());
    if (session == null || !session.isActive()) {
      return null;
    }

    session.stop();

    if (leaderboard != null) {
      boolean improved =
          leaderboard.submit(
              player.getUniqueId(),
              player.getName(),
              session.getTracker().getDps(),
              session.getTracker().getTotalDamage());
      if (improved) {
        leaderboard.saveAsync(plugin);
      }
    }

    return session;
  }

  public Optional<TrainingSession> getSession(Player player) {
    return Optional.ofNullable(sessions.get(player.getUniqueId()));
  }

  /** 获取排行榜前 n 名 */
  public List<DummyLeaderboard.Entry> getLeaderboard(int limit) {
    return leaderboard == null ? List.of() : leaderboard.top(limit);
  }

  // ==================== 显示开关 ====================

  /** 切换 HUD，返回切换后是否为开启状态 */
  public boolean toggleHud(Player player) {
    UUID id = player.getUniqueId();
    if (hudDisabled.remove(id)) {
      return true;
    }
    hudDisabled.add(id);
    return false;
  }

  public boolean isHudEnabled(Player player) {
    return !hudDisabled.contains(player.getUniqueId());
  }

  /** 切换命中反馈，返回切换后是否为开启状态 */
  public boolean toggleFeedback(Player player) {
    UUID id = player.getUniqueId();
    if (feedbackDisabled.remove(id)) {
      return true;
    }
    feedbackDisabled.add(id);
    return false;
  }

  public boolean isFeedbackEnabled(Player player) {
    return !feedbackDisabled.contains(player.getUniqueId());
  }

  /** Tick 更新 */
  private void tick() {
    for (TrainingDummy dummy : dummies.values()) {
      if (!dummy.isSpawned()) {
        continue;
      }

      // 只对血量变化的 dummy 重新 setCustomName（每 tick 调用代价高）
      if (dummy.isShowHealthBar() && dummy.hasHealthChanged()) {
        updateHealthBar(dummy);
      }

      // 自动重生
      if (dummy.isDead() && dummy.isAutoRespawn()) {
        long timeSinceDeath = System.currentTimeMillis() - dummy.getLastHitTime();
        if (timeSinceDeath >= dummy.getRespawnDelay()) {
          dummy.resetHealth();
          dummy.resetStats();
        }
      }

      if (dummy.isMovement()) {
        faceNearestPlayer(dummy);
      }
    }

    updateHud();
  }

  /** 更新血量条显示 */
  private void updateHealthBar(TrainingDummy dummy) {
    Object entity = dummy.getNpcEntity();
    if (entity instanceof Entity bukkitEntity) {
      String healthBar = dummy.getHealthBar();
      bukkitEntity.setCustomName(dummy.getName() + " " + healthBar);
    }
  }

  /** 让假人转向范围内的最近玩家 */
  private void faceNearestPlayer(TrainingDummy dummy) {
    Object entity = dummy.getNpcEntity();
    if (!(entity instanceof Entity stand)) {
      return;
    }

    Location center = dummy.getLocation();
    Player nearest = null;
    double nearestDist = FACE_RANGE * FACE_RANGE;

    for (Player player : plugin.getServer().getOnlinePlayers()) {
      if (!player.getWorld().equals(center.getWorld())) {
        continue;
      }
      double dist = player.getLocation().distanceSquared(center);
      if (dist <= nearestDist) {
        nearestDist = dist;
        nearest = player;
      }
    }

    if (nearest == null) {
      return;
    }

    double dx = nearest.getX() - stand.getX();
    double dz = nearest.getZ() - stand.getZ();
    float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
    stand.setRotation(yaw, 0f);
  }

  /** 为开启 HUD 的玩家刷新会话 actionbar */
  private void updateHud() {
    for (TrainingSession session : sessions.values()) {
      if (!session.isActive()) {
        continue;
      }

      Player player = plugin.getServer().getPlayer(session.getPlayerId());
      if (player == null || !isHudEnabled(player)) {
        continue;
      }

      TrainingDummy dummy = dummies.get(session.getDummyId());
      if (dummy == null || !dummy.isHudEnabled()) {
        continue;
      }

      player.sendActionBar(DummyDisplay.renderHud(session, dummy));
    }
  }

  /** 处理伤害 */
  @EventHandler
  public void onDamage(EntityDamageByEntityEvent event) {
    if (!(event.getDamager() instanceof Player attacker)) {
      return;
    }

    Optional<TrainingDummy> dummyOpt = getDummyByEntity(event.getEntity());
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();

    // 暴击判定：下落攻击且不在地面
    boolean crit = !attacker.isOnGround() && attacker.getFallDistance() > 0;
    double damage = dummy.reduceDamage(event.getFinalDamage());

    // 记录伤害：假人总统计 + 每玩家独立统计
    dummy.recordHit(damage, attacker.getUniqueId(), crit);

    // 会话统计
    TrainingSession session = sessions.get(attacker.getUniqueId());
    if (session != null && session.isActive() && session.getDummyId().equals(dummy.getId())) {
      session.getTracker().record(damage, crit);
    }

    // 命中反馈（音效/粒子/伤害数字）
    if (isFeedbackEnabled(attacker)) {
      DummyDisplay.hitFeedback(attacker, event.getEntity().getLocation(), damage, crit);
    } else {
      attacker.sendActionBar(DummyDisplay.damageNumber(damage, crit));
    }

    // 无敌假人取消实际伤害但保留统计
    if (dummy.isInvulnerable()) {
      event.setCancelled(true);
    }

    // 死亡且非自动重生时结算
    if (dummy.isDead() && !dummy.isAutoRespawn()) {
      sendStats(attacker, dummy);
    }

    // 反击
    if (dummy.isCounterAttack() && dummy.getCounterDamage() > 0) {
      counterAttack(attacker, dummy);
    }
  }

  /** 假人延迟反击攻击者 */
  private void counterAttack(Player attacker, TrainingDummy dummy) {
    double counterDamage = dummy.getCounterDamage();
    new BukkitRunnable() {
      @Override
      public void run() {
        if (attacker.isOnline() && !attacker.isDead()) {
          attacker.damage(counterDamage);
        }
      }
    }.runTaskLater(plugin, 10L);
  }

  /** 发送统计信息 */
  private void sendStats(Player player, TrainingDummy dummy) {
    player.sendMessage("§6========== 训练统计 ==========");
    player.sendMessage(
        "§e假人: " + dummy.getName() + " §7(" + dummy.getType().getDisplayName() + ")");
    player.sendMessage(
        "§e总伤害: §c"
            + dummy.getTotalDamageReceived()
            + " §7(减免 §f"
            + String.format("%.0f%%", dummy.getDamageReduction() * 100)
            + "§7)");
    player.sendMessage("§e命中次数: §f" + dummy.getHitCount() + " §7暴击: §b" + dummy.getCritCount());
    player.sendMessage(String.format("§e平均伤害: §c%.2f", dummy.getAverageDamage()));
    player.sendMessage(String.format("§eDPS: §c%.2f", dummy.getDPS()));

    DamageTracker mine = dummy.getAttackerStats(player.getUniqueId());
    if (mine != null && !mine.isEmpty()) {
      player.sendMessage(
          String.format(
              "§7你的: §c%.0f §7伤害 §f%d §7命中 §b%d §7暴击 §c%.2f §7DPS",
              mine.getTotalDamage(), mine.getHitCount(), mine.getCritCount(), mine.getDps()));
    }
    player.sendMessage("§6============================");
  }

  /** 处理交互 */
  @EventHandler
  public void onInteract(PlayerInteractAtEntityEvent event) {
    Optional<TrainingDummy> dummyOpt = getDummyByEntity(event.getRightClicked());
    if (dummyOpt.isEmpty()) {
      return;
    }

    TrainingDummy dummy = dummyOpt.get();
    Player player = event.getPlayer();

    // 潜行右键开始会话，普通右键显示统计
    if (player.isSneaking()) {
      TrainingSession session = startSession(player, dummy.getId());
      if (session != null) {
        player.sendMessage("§a已开始训练会话: " + dummy.getName());
      }
    } else {
      sendStats(player, dummy);
    }
  }

  /** 关闭 */
  public void shutdown() {
    for (TrainingDummy dummy : new ArrayList<>(dummies.values())) {
      if (dummy.isSpawned()) {
        despawnDummy(dummy.getId());
      }
    }

    if (leaderboard != null) {
      leaderboard.save();
    }

    dummies.clear();
    entityToDummy.clear();
    sessions.clear();

    plugin.getLogger().info("训练假人系统已关闭");
  }
}
