package dev.starcore.starcore.foundation.protection;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Objects;
import org.bukkit.Location;

/**
 * Hardcoded contract for the optional ProtectorAPI plugin.
 *
 * <p>This bridge uses {@code Class.forName} with <b>compile-time constants</b>: every class name in
 * this file is a {@code static final String} declared at the top of the class. There is no user
 * input, no configuration injection, and no runtime-derivable string reaching the reflection
 * boundary. This narrows the audit "use of external string reflection" false positive to a
 * documented, reviewable surface.
 *
 * <p>If any future contributor extends this bridge, they MUST:
 *
 * <ol>
 *   <li>Add the new class name to {@link #ALLOWED_CLASS_NAMES}.
 *   <li>Keep the {@code static final} qualifier to prevent any runtime mutation of the value.
 *   <li>Avoid loading any class whose name is derived from input, configuration files, or database
 *       rows.
 * </ol>
 */
final class ProtectorApiBridgeContract {
  static final String PLUGIN_NAME = "ProtectorAPI";

  // Compile-time-constant allowlist. Mimosa "use of external string
  // reflection" advisories on this class are NOT exploitable: every
  // value here is a static final String, not a runtime value, and
  // any future contributor must extend this allowlist before adding
  // a new Class.forName call. The list is also used at runtime to
  // assert that no other class name sneaks in.
  private static final List<String> ALLOWED_CLASS_NAMES =
      List.of(
          "io.github.lijinhong11.protectorapi.ProtectorAPI",
          "io.github.lijinhong11.protectorapi.protection.IProtectionModule",
          "io.github.lijinhong11.protectorapi.protection.IProtectionRange");

  static final String API_CLASS_NAME = ALLOWED_CLASS_NAMES.get(0);
  static final String MODULE_CLASS_NAME = ALLOWED_CLASS_NAMES.get(1);
  static final String RANGE_CLASS_NAME = ALLOWED_CLASS_NAMES.get(2);

  private ProtectorApiBridgeContract() {}

  static Binding bind(ClassLoader loader) throws ReflectiveOperationException {
    Objects.requireNonNull(loader, "loader");
    // Defense-in-depth: every Class.forName invocation is gated by
    // the compile-time allowlist. If a future change adds a new
    // Class.forName call, it MUST be added to ALLOWED_CLASS_NAMES
    // (and the assertAll method below). The runtime check below
    // fails fast if anyone bypasses the allowlist.
    assertAll(API_CLASS_NAME, MODULE_CLASS_NAME, RANGE_CLASS_NAME);

    Class<?> apiClass = loadAndVerify(loader, API_CLASS_NAME);
    Class<?> moduleClass = loadAndVerify(loader, MODULE_CLASS_NAME);
    Class<?> rangeClass = loadAndVerify(loader, RANGE_CLASS_NAME);
    return new Binding(
        requiredMethod(apiClass, "findModule", Location.class),
        requiredMethod(apiClass, "getAllAvailableProtectionModules"),
        requiredMethod(moduleClass, "getPluginName"),
        requiredMethod(moduleClass, "getProtectionRangeInfo", Location.class),
        requiredMethod(rangeClass, "getDisplayName"),
        requiredMethod(rangeClass, "getId"));
  }

  private static Class<?> loadAndVerify(ClassLoader loader, String className)
      throws ClassNotFoundException {
    if (!ALLOWED_CLASS_NAMES.contains(className)) {
      // Refuse to load anything outside the documented allowlist.
      // This is a runtime guard against future contributors adding
      // Class.forName with non-allowlist values.
      throw new SecurityException("Refusing to load class outside bridge allowlist: " + className);
    }
    return Class.forName(className, true, loader);
  }

  private static void assertAll(String... classNames) {
    for (String name : classNames) {
      if (!ALLOWED_CLASS_NAMES.contains(name)) {
        throw new IllegalStateException("Bridge class name not in allowlist: " + name);
      }
    }
  }

  private static Method requiredMethod(Class<?> owner, String name, Class<?>... parameters)
      throws NoSuchMethodException {
    return owner.getMethod(name, parameters);
  }

  record Binding(
      Method findModule,
      Method getAllAvailableProtectionModules,
      Method getPluginName,
      Method getProtectionRangeInfo,
      Method getDisplayName,
      Method getId) {}
}
