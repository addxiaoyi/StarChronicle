package dev.starcore.starcore.daily;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * 每日签到日历 GUI。
 *
 * <p>5x7 日历格展示最近 35 天签到状态：已签（绿）、可补签（黄，显示费用）、未签过去（灰）、 今天未签时中央按钮一键签到。补签费用与
 * CheckInService.calculateMakeUpCost 同口径（100×天数）。
 */
public final class CheckInGui implements InventoryHolder {

  /** 补签基础费用，与 CheckInService 内部 calculateMakeUpCost 的 baseCost 保持一致 */
  static final int MAKE_UP_BASE_COST = 100;

  private final Player player;
  private final CheckInService checkInService;
  private final Inventory inventory;
  private final Map<Integer, Integer> makeUpSlots = new HashMap<>();

  public CheckInGui(Player player, CheckInService checkInService) {
    this.player = player;
    this.checkInService = checkInService;
    this.inventory = Bukkit.createInventory(this, 54, "§6§l每日签到");
  }

  /** 打开签到日历并刷新当日数据 */
  public void open() {
    populate();
    player.openInventory(inventory);
  }

  private void populate() {
    inventory.clear();
    makeUpSlots.clear();

    UUID playerId = player.getUniqueId();
    CheckInService.CheckInData data = checkInService.getData(playerId);
    LocalDate today = LocalDate.now();
    LocalDate lastCheckIn = data.getLastCheckIn();

    // 头部信息卡
    inventory.setItem(
        4,
        item(
            Material.GOLDEN_HELMET,
            "§6§l每日签到",
            List.of(
                "§7连续签到: §e" + data.getConsecutiveDays() + " §7天",
                "§7累计签到: §f" + data.getTotalDays() + " §7天",
                data.getLastCheckIn() != null ? "§7上次签到: §f" + data.getLastCheckIn() : "§7尚未签到")));

    // 28 天日历（23 天前 → 今天），4 行 7 列：槽 10-16 / 19-25 / 28-34 / 37-43（避开槽 40 签到按钮）
    LocalDate calendarStart = today.minusDays(27);
    int[] calendarSlots = calendarLayout();
    for (int i = 0; i < calendarSlots.length; i++) {
      LocalDate date = calendarStart.plusDays(i);
      long daysAgo = ChronoUnit.DAYS.between(date, today);
      inventory.setItem(calendarSlots[i], dayItem(data, date, daysAgo, today));
    }

    // 中央今日签到按钮
    boolean checkedToday = today.equals(lastCheckIn);
    if (checkedToday) {
      inventory.setItem(
          40,
          item(
              Material.LIME_DYE,
              "§a§l今日已签到",
              List.of("§7明天再来吧", "§7连续签到 " + data.getConsecutiveDays() + " 天")));
    } else {
      inventory.setItem(
          40,
          item(
              Material.NETHER_STAR,
              "§6§l点我签到",
              List.of(
                  "§7预计奖励: §e" + previewReward(data.getConsecutiveDays()) + " 星币", "", "§e点击签到")));
    }

    inventory.setItem(
        45, item(Material.PAPER, "§7签到规则", List.of("§7连续 3/7/14/30 天有额外奖励", "§7漏签可花费星币补签")));
    inventory.setItem(49, item(Material.BARRIER, "§c§l关闭", List.of("§7点击关闭此界面")));
  }

  private ItemStack dayItem(
      CheckInService.CheckInData data, LocalDate date, long daysAgo, LocalDate today) {
    boolean isFuture = date.isAfter(today);
    boolean isMakeUp = data.getMakeUpDates().contains(date);
    boolean checked = date.equals(data.getLastCheckIn()) || isMakeUp;

    if (isFuture) {
      return item(Material.GRAY_STAINED_GLASS_PANE, "§7" + format(date), List.of("§7未来日期"));
    }
    if (checked) {
      String tag = isMakeUp ? " (补签)" : "";
      return item(Material.LIME_STAINED_GLASS_PANE, "§a✔ " + format(date) + tag, List.of("§a已签到"));
    }
    boolean canMakeUp = !date.equals(today) && data.getLastCheckIn() != null && daysAgo <= 7;
    if (date.equals(today)) {
      return item(
          Material.YELLOW_STAINED_GLASS_PANE,
          "§e" + format(date),
          List.of("§7今天未签到", "§7点击下方按钮签到"));
    }
    if (canMakeUp) {
      int cost = MAKE_UP_BASE_COST * (int) daysAgo;
      makeUpSlots.put(indexOfDate(date), (int) daysAgo);
      return item(
          Material.ORANGE_STAINED_GLASS_PANE,
          "§6" + format(date),
          List.of("§7漏签", "§e点击补签: §f" + cost + " 星币"));
    }
    return item(
        Material.GRAY_STAINED_GLASS_PANE,
        "§8" + format(date),
        List.of(daysAgo > 7 ? "§8已超过补签期限" : "§7未签到"));
  }

  /** 日历格日期 → 标识键。补签点击通过日期反查 daysAgo。 */
  private int indexOfDate(LocalDate date) {
    return date.toEpochDay() >= 0 ? (int) (date.toEpochDay() % 100000) : 0;
  }

  private int[] calendarLayout() {
    int[] slots = new int[35];
    int idx = 0;
    for (int row = 1; row <= 4; row++) {
      for (int col = 1; col <= 7; col++) {
        slots[idx++] = row * 9 + col;
      }
    }
    return slots;
  }

  /** 处理点击：槽 40 签到，补签格补签，槽 49 关闭 */
  public void handleClick(int slot) {
    UUID playerId = player.getUniqueId();
    CheckInService.CheckInData data = checkInService.getData(playerId);
    LocalDate today = LocalDate.now();

    if (slot == 40) {
      if (today.equals(data.getLastCheckIn())) {
        player.sendMessage("§e今天已经签到过了");
        return;
      }
      CheckInService.CheckInResult result = checkInService.checkIn(playerId);
      player.sendMessage(result.success() ? "§a" + result.message() : "§c" + result.message());
      if (result.success()) {
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.2f);
      }
      populate();
      return;
    }

    // 补签：通过槽位日期反查
    Integer daysAgo = makeUpSlotDaysAgo(slot);
    if (daysAgo != null) {
      int cost = MAKE_UP_BASE_COST * daysAgo;
      CheckInService.MakeUpResult result = checkInService.makeUpCheckIn(playerId, daysAgo, cost);
      player.sendMessage(result.success() ? "§a" + result.message() : "§c" + result.message());
      populate();
      return;
    }

    if (slot == 49) {
      player.closeInventory();
    }
  }

  private Integer makeUpSlotDaysAgo(int slot) {
    int[] slots = calendarLayout();
    LocalDate today = LocalDate.now();
    LocalDate calendarStart = today.minusDays(4);
    for (int i = 0; i < slots.length; i++) {
      if (slots[i] == slot) {
        LocalDate date = calendarStart.plusDays(i);
        long daysAgo = ChronoUnit.DAYS.between(date, today);
        if (daysAgo > 0 && daysAgo <= 7) {
          CheckInService.CheckInData data = checkInService.getData(player.getUniqueId());
          boolean checked =
              date.equals(data.getLastCheckIn()) || data.getMakeUpDates().contains(date);
          if (!checked && data.getLastCheckIn() != null && date.isBefore(data.getLastCheckIn())) {
            return (int) daysAgo;
          }
        }
        return null;
      }
    }
    return null;
  }

  private int previewReward(int nextConsecutiveDays) {
    int consecutive = nextConsecutiveDays + 1;
    int bonus = 0;
    if (consecutive >= 30) {
      bonus = 1000;
    } else if (consecutive >= 14) {
      bonus = 500;
    } else if (consecutive >= 7) {
      bonus = 200;
    } else if (consecutive >= 3) {
      bonus = 50;
    }
    return 100 + bonus + consecutive * 10;
  }

  private String format(LocalDate date) {
    return date.getMonthValue() + "月" + date.getDayOfMonth() + "日";
  }

  private ItemStack item(Material material, String name, List<String> lore) {
    ItemStack stack = new ItemStack(material);
    ItemMeta meta = stack.getItemMeta();
    if (meta != null) {
      meta.setDisplayName(name);
      meta.setLore(lore);
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      stack.setItemMeta(meta);
    }
    return stack;
  }

  @Override
  public Inventory getInventory() {
    return inventory;
  }
}
