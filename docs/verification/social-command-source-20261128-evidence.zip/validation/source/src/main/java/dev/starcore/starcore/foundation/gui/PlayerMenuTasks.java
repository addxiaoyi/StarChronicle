package dev.starcore.starcore.foundation.gui;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

public final class PlayerMenuTasks {
  private final Plugin plugin;
  private final Set<Pending> pendingTasks = new HashSet<>();
  private boolean running = true;

  public PlayerMenuTasks(Plugin plugin) {
    this.plugin = java.util.Objects.requireNonNull(plugin);
  }

  public CompletableFuture<Void> execute(Player player, Inventory expected, Runnable action) {
    return call(
        player,
        expected,
        () -> {
          action.run();
          return null;
        });
  }

  public <T> CompletableFuture<T> call(Player player, Inventory expected, Supplier<T> action) {
    return call(player, expected, action, false);
  }

  /** Leave the current inventory event before changing the view, retaining its original session. */
  public CompletableFuture<Void> executeNextTick(
      Player player, Inventory expected, Runnable action) {
    return call(
        player,
        expected,
        () -> {
          action.run();
          return null;
        },
        true);
  }

  private <T> CompletableFuture<T> call(
      Player player, Inventory expected, Supplier<T> action, boolean nextTick) {
    CompletableFuture<T> result = new CompletableFuture<>();
    Pending pending;
    synchronized (this) {
      if (player == null || !running || !plugin.isEnabled()) {
        result.cancel(false);
        return result;
      }
      pending = new Pending(result);
      pendingTasks.add(pending);
    }
    Runnable execute =
        () -> {
          synchronized (this) {
            if (!pendingTasks.remove(pending) || result.isDone()) return;
            try {
              if (!valid(player, expected)) {
                result.cancel(false);
                return;
              }
              result.complete(action.get());
            } catch (Throwable failure) {
              result.completeExceptionally(failure);
            }
          }
        };
    try {
      if (!nextTick && Bukkit.isOwnedByCurrentRegion(player)) {
        execute.run();
      } else {
        ScheduledTask task =
            player.getScheduler().run(plugin, ignored -> execute.run(), () -> retire(pending));
        synchronized (this) {
          pending.task = task;
          if (task == null || !pendingTasks.contains(pending)) {
            cancelTask(task);
            if (task == null) retire(pending);
          }
        }
      }
    } catch (Throwable failure) {
      synchronized (this) {
        pendingTasks.remove(pending);
        result.completeExceptionally(failure);
      }
    }
    return result;
  }

  public synchronized boolean valid(Player player, Inventory expected) {
    return running
        && plugin.isEnabled()
        && Bukkit.isOwnedByCurrentRegion(player)
        && player.isOnline()
        && plugin.getServer().getPlayer(player.getUniqueId()) == player
        && (expected == null || player.getOpenInventory().getTopInventory() == expected);
  }

  public synchronized void shutdown() {
    running = false;
    for (Pending pending : Set.copyOf(pendingTasks)) {
      pending.result.cancel(false);
      cancelTask(pending.task);
    }
    pendingTasks.clear();
  }

  private synchronized void retire(Pending pending) {
    if (pendingTasks.remove(pending)) pending.result.cancel(false);
  }

  private static void cancelTask(ScheduledTask task) {
    if (task == null) return;
    try {
      task.cancel();
    } catch (RuntimeException ignored) {
      // A broken handle cannot prevent other pending futures from being retired on shutdown.
    }
  }

  private static final class Pending {
    final CompletableFuture<?> result;
    ScheduledTask task;

    Pending(CompletableFuture<?> result) {
      this.result = result;
    }
  }
}
