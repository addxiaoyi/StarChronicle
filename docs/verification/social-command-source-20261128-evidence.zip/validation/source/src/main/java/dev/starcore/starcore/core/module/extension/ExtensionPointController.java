package dev.starcore.starcore.core.module.extension;

import dev.starcore.starcore.core.extension.ExtensionContributor;
import dev.starcore.starcore.core.extension.ExtensionPoint;
import java.util.List;

/** 扩展点控制器 用于管理模块与扩展点的交互 */
public interface ExtensionPointController {

  /** 获取关联的模块扩展 */
  ModuleExtension getModuleExtension();

  /** 注册贡献者 */
  <T, R> void registerContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor);

  /** 从扩展点注销贡献者 */
  <T, R> void unregisterContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor);

  /** 注销所有贡献者 */
  void unregisterAll();

  /** 获取所有已注册的扩展点 */
  List<ExtensionPoint<?, ?>> getRegisteredExtensionPoints();

  /** 执行扩展点 */
  <T, R> T executeExtension(String extensionPointId, R request);

  /** 执行扩展点（返回第一个结果） */
  <T, R> T executeExtensionFirst(String extensionPointId, R request);

  /** 检查扩展点是否存在 */
  boolean hasExtensionPoint(String name);
}
