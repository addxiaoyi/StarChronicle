package dev.starcore.starcore.core.persistence;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashSet;
import java.util.Set;

/** Crash-safe single-file replacement with one durable backup generation. */
public final class AtomicFilePersistence {
  private static final String TEMP_SUFFIX = ".tmp";
  private static final String BACKUP_SUFFIX = ".bak";
  private static final String DELETE_SUFFIX = ".delete";
  private static final int LOCK_STRIPES = 64;
  private static final Object[] LOCKS = createLocks();

  private AtomicFilePersistence() {}

  @FunctionalInterface
  public interface PathWriter {
    void write(Path path) throws IOException;
  }

  @FunctionalInterface
  public interface PathValidator {
    boolean isValid(Path path) throws IOException;
  }

  public enum RecoverySource {
    CURRENT,
    TEMP,
    BACKUP,
    MISSING,
    UNRECOVERABLE
  }

  public static void replace(Path target, PathWriter writer) throws IOException {
    Path normalized = normalize(target);
    synchronized (lockFor(normalized)) {
      replaceLocked(normalized, writer);
    }
  }

  private static void replaceLocked(Path normalized, PathWriter writer) throws IOException {
    Path parent = normalized.getParent();
    if (parent != null) {
      Files.createDirectories(parent);
    }

    Path temp = temp(normalized);
    Path backup = backup(normalized);
    Path backupTemp = temp(backup);
    Files.deleteIfExists(temp);
    Files.deleteIfExists(backupTemp);

    try {
      writer.write(temp);
      if (!Files.isRegularFile(temp)) {
        throw new IOException("Atomic writer did not create temporary file: " + temp);
      }
      forceFile(temp);

      if (Files.exists(normalized)) {
        Files.copy(normalized, backupTemp, StandardCopyOption.REPLACE_EXISTING);
        forceFile(backupTemp);
        moveReplace(backupTemp, backup);
      }

      moveReplace(temp, normalized);
      forceDirectory(parent);
    } catch (IOException | RuntimeException failure) {
      Files.deleteIfExists(temp);
      Files.deleteIfExists(backupTemp);
      throw failure;
    }
  }

  public static RecoverySource recover(Path target, PathValidator validator) throws IOException {
    Path normalized = normalize(target);
    synchronized (lockFor(normalized)) {
      return recoverLocked(normalized, validator);
    }
  }

  private static RecoverySource recoverLocked(Path normalized, PathValidator validator)
      throws IOException {
    Path temp = temp(normalized);
    Path backup = backup(normalized);
    Path deleteMarker = deleteMarker(normalized);

    if (Files.exists(deleteMarker)) {
      finishDelete(normalized, deleteMarker);
      return RecoverySource.MISSING;
    }
    if (isValid(normalized, validator)) {
      Files.deleteIfExists(temp);
      return RecoverySource.CURRENT;
    }
    if (isValid(temp, validator)) {
      moveReplace(temp, normalized);
      forceDirectory(normalized.getParent());
      return RecoverySource.TEMP;
    }
    if (isValid(backup, validator)) {
      Path restoreTemp = temp(normalized);
      Files.copy(backup, restoreTemp, StandardCopyOption.REPLACE_EXISTING);
      forceFile(restoreTemp);
      moveReplace(restoreTemp, normalized);
      forceDirectory(normalized.getParent());
      return RecoverySource.BACKUP;
    }

    Files.deleteIfExists(temp);
    boolean anyArtifact = Files.exists(normalized) || Files.exists(backup);
    return anyArtifact ? RecoverySource.UNRECOVERABLE : RecoverySource.MISSING;
  }

  public static void delete(Path target) throws IOException {
    Path normalized = normalize(target);
    synchronized (lockFor(normalized)) {
      Path marker = deleteMarker(normalized);
      if (Files.exists(marker)) {
        finishDelete(normalized, marker);
        return;
      }

      boolean hasRecoveryArtifact =
          Files.exists(temp(normalized)) || Files.exists(backup(normalized));
      if (!Files.exists(normalized) && !hasRecoveryArtifact) {
        return;
      }

      if (Files.exists(normalized)) {
        moveReplace(normalized, marker);
      } else {
        Files.writeString(
            marker, "delete", StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        forceFile(marker);
      }
      forceDirectory(normalized.getParent());
      finishDelete(normalized, marker);
    }
  }

  public static Set<Path> recoveryTargets(Path directory, String primarySuffix) throws IOException {
    Set<Path> targets = new LinkedHashSet<>();
    if (!Files.isDirectory(directory)) {
      return targets;
    }

    try (var paths = Files.list(directory)) {
      paths
          .filter(Files::isRegularFile)
          .forEach(
              path -> {
                String name = path.getFileName().toString();
                if (name.endsWith(primarySuffix)) {
                  targets.add(path);
                } else if (name.endsWith(primarySuffix + TEMP_SUFFIX)) {
                  targets.add(
                      path.resolveSibling(name.substring(0, name.length() - TEMP_SUFFIX.length())));
                } else if (name.endsWith(primarySuffix + BACKUP_SUFFIX)) {
                  targets.add(
                      path.resolveSibling(
                          name.substring(0, name.length() - BACKUP_SUFFIX.length())));
                } else if (name.endsWith(primarySuffix + DELETE_SUFFIX)) {
                  targets.add(
                      path.resolveSibling(
                          name.substring(0, name.length() - DELETE_SUFFIX.length())));
                }
              });
    }
    return targets;
  }

  public static Path temp(Path target) {
    Path normalized = normalize(target);
    return normalized.resolveSibling(normalized.getFileName() + TEMP_SUFFIX);
  }

  public static Path backup(Path target) {
    Path normalized = normalize(target);
    return normalized.resolveSibling(normalized.getFileName() + BACKUP_SUFFIX);
  }

  public static Path deleteMarker(Path target) {
    Path normalized = normalize(target);
    return normalized.resolveSibling(normalized.getFileName() + DELETE_SUFFIX);
  }

  private static void finishDelete(Path target, Path marker) throws IOException {
    Files.deleteIfExists(temp(target));
    Files.deleteIfExists(backup(target));
    Files.deleteIfExists(target);
    Files.deleteIfExists(marker);
    forceDirectory(target.getParent());
  }

  private static boolean isValid(Path path, PathValidator validator) throws IOException {
    if (!Files.isRegularFile(path)) {
      return false;
    }
    try {
      return validator.isValid(path);
    } catch (IOException | RuntimeException invalid) {
      return false;
    }
  }

  private static void moveReplace(Path source, Path target) throws IOException {
    try {
      Files.move(
          source, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
      return;
    } catch (IOException atomicFailure) {
      if (!Files.exists(source) && Files.exists(target)) {
        return;
      }
      try {
        Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
        return;
      } catch (IOException fallbackFailure) {
        fallbackFailure.addSuppressed(atomicFailure);
        throw fallbackFailure;
      }
    }
  }

  private static void forceFile(Path file) throws IOException {
    try (FileChannel channel = FileChannel.open(file, StandardOpenOption.WRITE)) {
      channel.force(true);
    }
  }

  private static void forceDirectory(Path directory) {
    if (directory == null) {
      return;
    }
    try (FileChannel channel = FileChannel.open(directory, StandardOpenOption.READ)) {
      channel.force(true);
    } catch (IOException | UnsupportedOperationException ignored) {
      // Directory fsync is unavailable on some supported filesystem/JDK combinations.
    }
  }

  private static Object[] createLocks() {
    Object[] locks = new Object[LOCK_STRIPES];
    for (int i = 0; i < locks.length; i++) {
      locks[i] = new Object();
    }
    return locks;
  }

  private static Object lockFor(Path target) {
    return LOCKS[Math.floorMod(target.hashCode(), LOCK_STRIPES)];
  }

  private static Path normalize(Path path) {
    if (path == null) {
      throw new IllegalArgumentException("Target path is required");
    }
    return path.toAbsolutePath().normalize();
  }
}
