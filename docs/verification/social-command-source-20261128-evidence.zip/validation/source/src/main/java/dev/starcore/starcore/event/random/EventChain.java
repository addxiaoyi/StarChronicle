package dev.starcore.starcore.event.random;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** 事件链管理器 处理事件之间的链式触发关系，支持延迟触发 */
public class EventChain {

  private final RandomEventService eventService;
  private final Map<UUID, ChainState> activeChains;
  private final Map<String, ChainTriggerTask> pendingTriggers;
  private volatile JavaPlugin plugin;
  private volatile boolean closed;
  private final AtomicInteger taskIds = new AtomicInteger();

  public EventChain(RandomEventService eventService) {
    this.eventService = eventService;
    this.activeChains = new ConcurrentHashMap<>();
    this.pendingTriggers = new ConcurrentHashMap<>();
  }

  /** 设置插件引用（用于调度任务） */
  public synchronized void setPlugin(JavaPlugin plugin) {
    if (closed || (this.plugin != null && this.plugin != plugin))
      throw new IllegalStateException("Event chain owner is already bound or retired");
    this.plugin = Objects.requireNonNull(plugin);
  }

  /**
   * 启动事件链
   *
   * @param eventId 初始事件ID
   * @param player 触发玩家
   * @param location 触发位置
   * @return 事件链ID
   */
  public synchronized UUID startChain(String eventId, Player player, Location location) {
    if (closed) throw new IllegalStateException("Event chain is closed");
    UUID chainId = UUID.randomUUID();
    ChainState state = new ChainState(chainId, eventId, player, location);
    activeChains.put(chainId, state);
    return chainId;
  }

  /**
   * 继续事件链 - 支持延迟触发
   *
   * @param chainId 事件链ID
   * @param nextEventId 下一个事件ID
   * @param delayTicks 延迟时间（tick），0表示立即触发
   * @return 如果成功安排触发返回true
   */
  public boolean continueChain(UUID chainId, String nextEventId, long delayTicks) {
    if (delayTicks < 0) throw new IllegalArgumentException("Negative chain delay");
    ChainState state = activeChains.get(chainId);
    if (closed || state == null || plugin == null || !plugin.isEnabled()) {
      return false;
    }

    // 检查冷却时间
    RandomEvent nextEvent = eventService.getEvent(nextEventId);
    if (nextEvent == null) {
      return false;
    }

    if (!eventService.reserveCooldown(nextEventId, nextEvent.getCooldown())) {
      return false;
    }

    String taskKey = chainId + "_" + nextEventId;
    ChainTriggerTask task = new ChainTriggerTask(taskKey, state, nextEventId, nextEvent);
    ChainTriggerTask previous;
    synchronized (this) {
      if (closed || activeChains.get(chainId) != state) return false;
      previous = pendingTriggers.put(taskKey, task);
      state.addPendingEvent(nextEventId, task.id);
    }
    if (previous != null) previous.cancel();
    try {
      if (delayTicks == 0 && owns(state)) {
        return task.run();
      }
      long delay = Math.max(1, delayTicks);
      ScheduledTask scheduled;
      if (state.player != null)
        scheduled =
            state
                .player
                .getScheduler()
                .runDelayed(plugin, ignored -> task.run(), task::cancel, delay);
      else if (state.location != null && state.location.getWorld() != null)
        scheduled =
            plugin
                .getServer()
                .getRegionScheduler()
                .runDelayed(plugin, state.getLocation(), ignored -> task.run(), delay);
      else
        scheduled =
            plugin
                .getServer()
                .getGlobalRegionScheduler()
                .runDelayed(plugin, ignored -> task.run(), delay);
      task.attach(scheduled);
      return scheduled != null && !task.cancelled;
    } catch (RuntimeException | Error failure) {
      task.cancel();
      throw failure;
    }
  }

  /** 重载 continueChain 以保持向后兼容 */
  public boolean continueChain(UUID chainId, String nextEventId) {
    return continueChain(chainId, nextEventId, 0);
  }

  /** 执行链事件 */
  private boolean executeChainEvent(ChainState state, String nextEventId, RandomEvent nextEvent) {
    if (closed || activeChains.get(state.chainId) != state || !plugin.isEnabled() || !owns(state))
      return false;
    Player player = state.getPlayer();
    Location location = state.getLocation();
    if (player != null
        && (!player.isOnline() || plugin.getServer().getPlayer(player.getUniqueId()) != player))
      return false;

    state.addEvent(nextEventId);

    // 触发下一个事件（冷却已在 continueChain 中设置）
    // The service schedules successors once in this chain, rather than also creating a new chain.
    eventService.triggerChainEvent(nextEvent, player, location, state.chainId);

    return true;
  }

  private boolean owns(ChainState state) {
    if (state.player != null) return Bukkit.isOwnedByCurrentRegion(state.player);
    if (state.location != null && state.location.getWorld() != null)
      return Bukkit.isOwnedByCurrentRegion(state.location);
    return Bukkit.isGlobalTickThread();
  }

  /**
   * 结束事件链
   *
   * @param chainId 事件链ID
   */
  public void endChain(UUID chainId) {
    List<ChainTriggerTask> retired;
    synchronized (this) {
      activeChains.remove(chainId);
      retired =
          pendingTriggers.values().stream()
              .filter(task -> task.state.chainId.equals(chainId))
              .toList();
    }
    retired.forEach(ChainTriggerTask::cancel);
  }

  /**
   * 获取事件链状态
   *
   * @param chainId 事件链ID
   * @return 事件链状态，如果不存在返回null
   */
  public ChainState getChainState(UUID chainId) {
    return activeChains.get(chainId);
  }

  /**
   * 清理过期的事件链
   *
   * @param maxAge 最大存活时间（秒）
   */
  public void cleanupExpiredChains(long maxAge) {
    long now = System.currentTimeMillis();
    List<UUID> toRemove = new ArrayList<>();

    for (Map.Entry<UUID, ChainState> entry : activeChains.entrySet()) {
      long age = (now - entry.getValue().getStartTime()) / 1000;
      if (age > maxAge) {
        toRemove.add(entry.getKey());
      }
    }

    for (UUID chainId : toRemove) {
      endChain(chainId);
    }
  }

  /**
   * 获取活跃事件链数量
   *
   * @return 活跃事件链数量
   */
  public int getActiveChainCount() {
    return activeChains.size();
  }

  /** 获取待触发任务数量 */
  public int getPendingTriggerCount() {
    return pendingTriggers.size();
  }

  public void shutdown() {
    List<ChainTriggerTask> retired;
    synchronized (this) {
      if (closed) return;
      closed = true;
      retired = List.copyOf(pendingTriggers.values());
      activeChains.clear();
    }
    retired.forEach(ChainTriggerTask::cancel);
  }

  /** 链触发任务类 */
  private final class ChainTriggerTask {
    private final int id = taskIds.incrementAndGet();
    private final String key;
    private final ChainState state;
    private final String eventId;
    private final RandomEvent event;
    private ScheduledTask task;
    private volatile boolean cancelled;
    private boolean backendCancelled;

    ChainTriggerTask(String key, ChainState state, String eventId, RandomEvent event) {
      this.key = key;
      this.state = state;
      this.eventId = eventId;
      this.event = event;
    }

    synchronized void attach(ScheduledTask task) {
      this.task = task;
      if (task == null) cancel();
      else if (cancelled) cancelBackend();
    }

    boolean run() {
      synchronized (EventChain.this) {
        if (cancelled || !pendingTriggers.remove(key, this)) return false;
        state.pendingTasks.remove(eventId, id);
      }
      try {
        return executeChainEvent(state, eventId, event);
      } finally {
        cancel();
      }
    }

    void cancel() {
      cancelled = true;
      pendingTriggers.remove(key, this);
      state.pendingTasks.remove(eventId, id);
      cancelBackend();
    }

    private synchronized void cancelBackend() {
      if (task != null && !backendCancelled) {
        backendCancelled = true;
        try {
          task.cancel();
        } catch (IllegalStateException ignored) {
          // already cancelled or completed
        }
      }
    }
  }

  /** 事件链状态类 */
  public static class ChainState {
    private final UUID chainId;
    private final String initialEventId;
    private final Player player;
    private final Location location;
    private final List<String> eventHistory;
    private final long startTime;
    private final Map<String, Object> context;
    private final Map<String, Integer> pendingTasks;

    public ChainState(UUID chainId, String initialEventId, Player player, Location location) {
      this.chainId = chainId;
      this.initialEventId = initialEventId;
      this.player = player;
      this.location = location == null ? null : location.clone();
      this.eventHistory = Collections.synchronizedList(new ArrayList<>());
      this.eventHistory.add(initialEventId);
      this.startTime = System.currentTimeMillis();
      this.context = new ConcurrentHashMap<>();
      this.pendingTasks = new ConcurrentHashMap<>();
    }

    /**
     * 添加事件到历史记录
     *
     * @param eventId 事件ID
     */
    public void addEvent(String eventId) {
      eventHistory.add(eventId);
    }

    /**
     * 添加待处理的任务
     *
     * @param eventId 事件ID
     * @param taskId 任务ID
     */
    public void addPendingEvent(String eventId, int taskId) {
      pendingTasks.put(eventId, taskId);
    }

    public void removePendingEvent(String eventId) {
      pendingTasks.remove(eventId);
    }

    /** 获取待处理的任务 */
    public Map<String, Integer> getPendingTasks() {
      return Map.copyOf(pendingTasks);
    }

    /**
     * 检查事件是否已经在链中触发过
     *
     * @param eventId 事件ID
     * @return 如果已触发返回true
     */
    public boolean hasTriggered(String eventId) {
      return eventHistory.contains(eventId);
    }

    /**
     * 设置上下文数据
     *
     * @param key 键
     * @param value 值
     */
    public void setContext(String key, Object value) {
      context.put(key, value);
    }

    /**
     * 获取上下文数据
     *
     * @param key 键
     * @return 值，如果不存在返回null
     */
    public Object getContext(String key) {
      return context.get(key);
    }

    // Getters
    public UUID getChainId() {
      return chainId;
    }

    public String getInitialEventId() {
      return initialEventId;
    }

    public Player getPlayer() {
      return player;
    }

    public Location getLocation() {
      return location == null ? null : location.clone();
    }

    public List<String> getEventHistory() {
      synchronized (eventHistory) {
        return List.copyOf(eventHistory);
      }
    }

    public long getStartTime() {
      return startTime;
    }

    public int getChainLength() {
      return eventHistory.size();
    }

    public Map<String, Object> getContext() {
      return Map.copyOf(context);
    }
  }
}
