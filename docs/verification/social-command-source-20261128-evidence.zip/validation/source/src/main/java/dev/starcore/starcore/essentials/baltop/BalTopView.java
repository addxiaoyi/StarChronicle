package dev.starcore.starcore.essentials.baltop;

import java.math.BigDecimal;
import java.util.*;

/** Detached data for one displayed ranking. Slot actions use this same snapshot. */
public record BalTopView(
    UUID viewerId,
    int page,
    List<BalTopService.BalTopEntry> entries,
    BigDecimal viewerBalance,
    Map<UUID, String> names) {
  public static final int PAGE_SIZE = 28;

  public BalTopView {
    Objects.requireNonNull(viewerId);
    Objects.requireNonNull(viewerBalance);
    entries = List.copyOf(entries);
    if (entries.size() > 100)
      throw new IllegalArgumentException("Ranking view exceeds 100 entries");
    Set<UUID> ids = new HashSet<>();
    for (var entry : entries) {
      if (!ids.add(Objects.requireNonNull(entry.playerId())))
        throw new IllegalArgumentException("Duplicate ranked account");
      Objects.requireNonNull(entry.balance());
    }
    page = Math.min(Math.max(1, page), Math.max(1, (entries.size() + PAGE_SIZE - 1) / PAGE_SIZE));
    names = Map.copyOf(names);
  }

  public int startIndex() {
    return (page - 1) * PAGE_SIZE;
  }

  public int endIndex() {
    return Math.min(startIndex() + PAGE_SIZE, entries.size());
  }

  public int totalPages() {
    return Math.max(1, (entries.size() + PAGE_SIZE - 1) / PAGE_SIZE);
  }

  public OptionalInt viewerRank() {
    for (int i = 0; i < entries.size(); i++)
      if (entries.get(i).playerId().equals(viewerId)) return OptionalInt.of(i + 1);
    return OptionalInt.empty();
  }

  public String name(UUID playerId) {
    String name = names.get(playerId);
    return name == null || name.isBlank() ? playerId.toString() : name;
  }

  public Set<UUID> neededNames() {
    Set<UUID> ids = new LinkedHashSet<>();
    for (int i = startIndex(); i < endIndex(); i++) ids.add(entries.get(i).playerId());
    viewerRank()
        .ifPresent(
            rank -> {
              if (rank > 1) ids.add(entries.get(rank - 2).playerId());
            });
    return Collections.unmodifiableSet(ids);
  }
}
