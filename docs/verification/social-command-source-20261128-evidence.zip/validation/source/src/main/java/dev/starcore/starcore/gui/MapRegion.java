package dev.starcore.starcore.gui;

import java.util.*;
import java.util.Objects;

/** 地图区域 表示地图上的一个区域 */
public record MapRegion(
    String id, // 区域ID
    String name, // 区域名称
    String description, // 区域描述
    double x, // X坐标（中心点）
    double y, // Y坐标（中心点）
    double width, // 宽度
    double height, // 高度
    double zIndex, // Z层级
    String world, // 世界名称
    String nationId, // 所属国家ID
    Map<String, Object> metadata // 元数据
    ) implements MapElement {

  @Override
  public String getId() {
    return id;
  }

  /** 检查坐标是否在区域范围内 */
  public boolean contains(double checkX, double checkY) {
    double halfWidth = width / 2.0;
    double halfHeight = height / 2.0;
    return checkX >= x - halfWidth
        && checkX <= x + halfWidth
        && checkY >= y - halfHeight
        && checkY <= y + halfHeight;
  }

  /** 获取名称 */
  public String getName() {
    return name;
  }

  /** 获取描述 */
  public String getDescription() {
    return description;
  }

  /** 获取X坐标 */
  public double getX() {
    return x;
  }

  /** 获取Y坐标 */
  public double getY() {
    return y;
  }

  /** 获取Z层级 */
  public double getZIndex() {
    return zIndex;
  }

  /** 地图区域构建器 */
  public static Builder builder(String id, String name) {
    return new Builder(id, name);
  }

  public static class Builder {
    private final String id;
    private final String name;
    private double x = 0.5;
    private double y = 0.5;
    private double width = 0.1;
    private double height = 0.1;
    private double zIndex = 0.0;
    private String description = "";
    private String world = "world";
    private String nationId;
    private final Map<String, Object> metadata = new HashMap<>();

    private Builder(String id, String name) {
      this.id = Objects.requireNonNull(id);
      this.name = Objects.requireNonNull(name);
    }

    public Builder position(double x, double y) {
      this.x = x;
      this.y = y;
      return this;
    }

    public Builder size(double width, double height) {
      this.width = width;
      this.height = height;
      return this;
    }

    public Builder zIndex(double zIndex) {
      this.zIndex = zIndex;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder world(String world) {
      this.world = world;
      return this;
    }

    public Builder nationId(String nationId) {
      this.nationId = nationId;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public MapRegion build() {
      return new MapRegion(
          id, name, description, x, y, width, height, zIndex, world, nationId, metadata);
    }
  }
}
