package dev.starcore.starcore.foundation.economy.insurance;

/** Durable lifecycle for a player insurance policy. */
public enum InsurancePolicyState {
  ACTIVE,
  CLAIM_PENDING,
  CLAIMED,
  EXPIRED,
  CANCELLED
}
