package dev.starcore.starcore.core.health;

import dev.starcore.starcore.core.metrics.PerformanceSnapshot;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerSummary;
import dev.starcore.starcore.foundation.economy.transaction.TransactionSummary;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

/** Cross-cutting health view used by operator commands and future GUI/API surfaces. */
public record ModuleHealthSnapshot(
    Instant capturedAt,
    List<ModuleHealthEntry> modules,
    TransactionSummary transactions,
    RefundLedgerSummary refunds,
    PerformanceSnapshot performance) {
  public ModuleHealthSnapshot {
    Objects.requireNonNull(capturedAt, "capturedAt");
    Objects.requireNonNull(modules, "modules");
    Objects.requireNonNull(transactions, "transactions");
    Objects.requireNonNull(refunds, "refunds");
    Objects.requireNonNull(performance, "performance");
    modules = List.copyOf(modules);
  }

  public long enabledModules() {
    return modules.stream().filter(entry -> entry.status().name().equals("ENABLED")).count();
  }

  public long failedModules() {
    return modules.stream().filter(entry -> entry.status().name().equals("FAILED")).count();
  }
}
