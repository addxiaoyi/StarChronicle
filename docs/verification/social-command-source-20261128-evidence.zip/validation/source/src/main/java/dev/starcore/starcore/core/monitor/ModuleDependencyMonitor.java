package dev.starcore.starcore.core.monitor;

import dev.starcore.starcore.core.module.ModuleDescriptor;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleManager;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.ModuleStatus;
import dev.starcore.starcore.core.service.ServiceRegistry;
import java.util.*;
import java.util.logging.Logger;

/** 模块依赖监控服务。 基于 ModuleManager 和 ServiceRegistry 构建依赖图，检测循环依赖、缺失依赖、服务绑定状态。 命令接口输出依赖关系图，用于架构诊断与排错。 */
public final class ModuleDependencyMonitor {
  private final ModuleManager moduleManager;
  private final ServiceRegistry serviceRegistry;
  private final Logger logger;

  public ModuleDependencyMonitor(
      ModuleManager moduleManager, ServiceRegistry serviceRegistry, Logger logger) {
    this.moduleManager = moduleManager;
    this.serviceRegistry = serviceRegistry;
    this.logger = logger;
  }

  /** 生成完整依赖图快照。 包含模块节点（声明依赖、实际服务、状态）与循环依赖列表。 */
  public DependencyGraph snapshot() {
    Map<String, ModuleNode> nodes = new LinkedHashMap<>();
    Collection<ModuleDescriptor> descriptors = moduleManager.descriptors();

    for (ModuleDescriptor descriptor : descriptors) {
      ModuleMetadata meta = descriptor.metadata();
      List<Class<?>> provided = meta.providedServices();
      // Map serviceType -> impl 是否实际存在于 ServiceRegistry
      Set<String> ownedServiceNames = new LinkedHashSet<>();
      for (Class<?> serviceType : provided) {
        if (serviceRegistry.find(serviceType).isPresent()) {
          ownedServiceNames.add(serviceType.getSimpleName());
        }
      }
      ModuleNode node =
          new ModuleNode(
              meta.id(),
              meta.displayName(),
              meta.layer(),
              meta.dependencies(),
              provided,
              ownedServiceNames,
              descriptor.status(),
              descriptor.failureReason());
      nodes.put(meta.id(), node);
    }

    List<CycleInfo> cycles = detectCycles(nodes);
    return new DependencyGraph(nodes, cycles);
  }

  /** 检测循环依赖，使用 DFS + 显式路径栈。 返回循环链（模块 id 列表）。 */
  private List<CycleInfo> detectCycles(Map<String, ModuleNode> nodes) {
    List<CycleInfo> result = new ArrayList<>();
    Set<String> visited = new HashSet<>();
    Set<String> onStack = new HashSet<>();
    List<String> path = new ArrayList<>();

    for (String id : nodes.keySet()) {
      if (!visited.contains(id)) {
        dfs(id, nodes, visited, onStack, path, result);
      }
    }
    return result;
  }

  private void dfs(
      String id,
      Map<String, ModuleNode> nodes,
      Set<String> visited,
      Set<String> onStack,
      List<String> path,
      List<CycleInfo> result) {
    visited.add(id);
    onStack.add(id);
    path.add(id);

    ModuleNode node = nodes.get(id);
    if (node != null) {
      for (String dep : node.dependencies()) {
        if (!nodes.containsKey(dep)) {
          continue;
        }
        if (!visited.contains(dep)) {
          dfs(dep, nodes, visited, onStack, path, result);
        } else if (onStack.contains(dep)) {
          // 发现循环：从当前路径中 dep 的位置截取到末尾，即可还原闭合成环
          int start = path.indexOf(dep);
          List<String> cycle = new ArrayList<>(path.subList(start, path.size()));
          cycle.add(dep);
          result.add(new CycleInfo(cycle, "循环依赖: " + String.join(" -> ", cycle)));
        }
      }
    }
    onStack.remove(id);
    path.remove(path.size() - 1);
  }

  /** 检测未满足依赖：被依赖模块未启用或不存在。 */
  public List<String> unmetDependencies() {
    List<String> unmet = new ArrayList<>();
    Map<String, ModuleDescriptor> map = new HashMap<>();
    for (ModuleDescriptor d : moduleManager.descriptors()) {
      map.put(d.metadata().id(), d);
    }
    for (ModuleDescriptor d : moduleManager.descriptors()) {
      ModuleMetadata meta = d.metadata();
      for (String dep : meta.dependencies()) {
        ModuleDescriptor depDesc = map.get(dep);
        if (depDesc == null || depDesc.status() != ModuleStatus.ENABLED) {
          unmet.add(meta.id() + " -> " + dep + " [未启用/不存在]");
        }
      }

      for (Class<?> serviceType : meta.providedServices()) {
        if (serviceRegistry.find(serviceType).isEmpty()) {
          unmet.add(meta.id() + " -> service:" + serviceType.getSimpleName() + " [未绑定]");
        }
      }
    }
    return unmet;
  }

  // 工具方法：按图层展示排序
  public List<ModuleNode> sortedNodes() {
    DependencyGraph graph = snapshot();
    List<ModuleNode> list = new ArrayList<>(graph.nodes().values());
    list.sort(
        Comparator.comparing(ModuleNode::layer, Comparator.comparingInt(l -> l.ordinal()))
            .thenComparing(ModuleNode::id));
    return list;
  }

  /** 依赖图容器 */
  public record DependencyGraph(Map<String, ModuleNode> nodes, List<CycleInfo> cycles) {}

  /** 循环依赖信息 */
  public record CycleInfo(List<String> cycleModules, String description) {}

  /** 模块节点 */
  public record ModuleNode(
      String id,
      String displayName,
      ModuleLayer layer,
      List<String> dependencies,
      List<Class<?>> providedServices,
      Set<String> ownedServiceNames,
      ModuleStatus status,
      String failureReason) {}
}
