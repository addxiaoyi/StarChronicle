package dev.starcore.starcore.api.v1.config;

import com.google.gson.annotations.SerializedName;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/** REST API 配置 */
public record RestApiConfig(
    @SerializedName("enabled") boolean enabled,
    @SerializedName("host") String host,
    @SerializedName("port") int port,
    @SerializedName("signingSecret") String signingSecret,
    @SerializedName("cors") CorsConfig cors,
    @SerializedName("rateLimit") RateLimitConfig rateLimit,
    @SerializedName("endpoints") EndpointsConfig endpoints) {
  private static final String DEFAULT_HOST = "127.0.0.1";
  private static final int DEFAULT_PORT = 8717;
  // Mimosa CWE-798: 默认密钥占位符从 env var 读取。
  // 部署时设置 STARCORE_REST_API_DEFAULT_SECRET 即可；若不设置则启动时 ConfigurationService
  // 的 ensureRestApiSigningSecretConfigured() 会自动生成强随机密钥并写回 config.yml。
  private static final String DEFAULT_SIGNING_SECRET = resolveDefaultSigningSecret();

  private static String resolveDefaultSigningSecret() {
    String env = System.getenv("STARCORE_REST_API_DEFAULT_SECRET");
    return env != null && !env.isBlank()
        ? env
        : "STARCORE_DEFAULT_SIGNING_SECRET_REPLACE_AT_FIRST_BOOT";
  }

  public RestApiConfig {
    host = host == null || host.isBlank() ? DEFAULT_HOST : host.trim();
    port = port < 1 || port > 65_535 ? DEFAULT_PORT : port;
    signingSecret =
        signingSecret == null || signingSecret.isBlank() ? DEFAULT_SIGNING_SECRET : signingSecret;
    cors = cors == null ? CorsConfig.DISABLED : cors;
    rateLimit = rateLimit == null ? RateLimitConfig.DEFAULT : rateLimit;
    endpoints = endpoints == null ? EndpointsConfig.DISABLED : endpoints;
  }

  public static final RestApiConfig DEFAULT =
      new RestApiConfig(
          false,
          DEFAULT_HOST,
          DEFAULT_PORT,
          DEFAULT_SIGNING_SECRET,
          CorsConfig.DEFAULT,
          RateLimitConfig.DEFAULT,
          EndpointsConfig.DEFAULT);

  /** CORS 配置 */
  public record CorsConfig(
      @SerializedName("enabled") boolean enabled,
      @SerializedName("allowedOrigins") List<String> allowedOrigins,
      @SerializedName("allowedMethods") List<String> allowedMethods,
      @SerializedName("allowedHeaders") List<String> allowedHeaders,
      @SerializedName("maxAge") int maxAge) {
    public static final CorsConfig DISABLED =
        new CorsConfig(false, List.of(), List.of(), List.of(), 0);

    public CorsConfig {
      allowedOrigins = clean(allowedOrigins, false);
      allowedMethods = clean(allowedMethods, true);
      allowedHeaders = clean(allowedHeaders, false);
      maxAge = Math.max(0, maxAge);
    }

    public static final CorsConfig DEFAULT =
        new CorsConfig(
            true,
            List.of("*"),
            List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"),
            List.of(
                "Content-Type",
                "Authorization",
                "X-API-Key",
                "X-Signature",
                "X-Timestamp",
                "X-Nonce"),
            86400);

    private static List<String> clean(List<String> values, boolean uppercase) {
      if (values == null) {
        return List.of();
      }
      return values.stream()
          .filter(Objects::nonNull)
          .map(String::trim)
          .filter(value -> !value.isBlank())
          .map(value -> uppercase ? value.toUpperCase(Locale.ROOT) : value)
          .distinct()
          .toList();
    }
  }

  /** 速率限制配置 */
  public record RateLimitConfig(
      @SerializedName("enabled") boolean enabled,
      @SerializedName("requestsPerMinute") int requestsPerMinute,
      @SerializedName("burstSize") int burstSize,
      @SerializedName("blockDurationSeconds") int blockDurationSeconds) {
    public RateLimitConfig {
      requestsPerMinute = Math.max(1, requestsPerMinute);
      burstSize = Math.max(1, burstSize);
      blockDurationSeconds = Math.max(1, blockDurationSeconds);
    }

    public static final RateLimitConfig DEFAULT = new RateLimitConfig(true, 60, 10, 60);
  }

  /** 端点配置 */
  public record EndpointsConfig(
      @SerializedName("nations") EndpointConfig nations,
      @SerializedName("territories") EndpointConfig territories,
      @SerializedName("stats") EndpointConfig stats,
      @SerializedName("finance") EndpointConfig finance,
      @SerializedName("deps") EndpointConfig deps,
      @SerializedName("wars") EndpointConfig wars,
      @SerializedName("players") EndpointConfig players,
      @SerializedName("events") EndpointConfig events) {
    public static final EndpointsConfig DISABLED =
        new EndpointsConfig(
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED,
            EndpointConfig.DISABLED);

    public EndpointsConfig {
      nations = nations == null ? EndpointConfig.DISABLED : nations;
      territories = territories == null ? EndpointConfig.DISABLED : territories;
      stats = stats == null ? EndpointConfig.DISABLED : stats;
      finance = finance == null ? EndpointConfig.DISABLED : finance;
      deps = deps == null ? EndpointConfig.DISABLED : deps;
      wars = wars == null ? EndpointConfig.DISABLED : wars;
      players = players == null ? EndpointConfig.DISABLED : players;
      events = events == null ? EndpointConfig.DISABLED : events;
    }

    public static final EndpointsConfig DEFAULT =
        new EndpointsConfig(
            EndpointConfig.DEFAULT,
            EndpointConfig.DEFAULT,
            EndpointConfig.DEFAULT,
            new EndpointConfig(true, true), // finance 需要认证
            new EndpointConfig(true, true), // deps 暴露内部架构，需要认证
            EndpointConfig.DEFAULT,
            EndpointConfig.DEFAULT,
            EndpointConfig.DEFAULT);
  }

  /** 单个端点配置 */
  public record EndpointConfig(
      @SerializedName("enabled") boolean enabled,
      @SerializedName("requiresAuth") boolean requiresAuth) {
    public static final EndpointConfig DEFAULT = new EndpointConfig(true, false);
    public static final EndpointConfig DISABLED = new EndpointConfig(false, true);
  }
}
