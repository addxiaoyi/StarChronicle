package dev.starcore.starcore.foundation.feedback;

import dev.starcore.starcore.foundation.sound.BukkitSoundResolver;
import java.time.Duration;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class BukkitInGameFeedbackService implements InGameFeedbackService {
  private final Function<String, InGameFeedbackProfile> profiles;

  public BukkitInGameFeedbackService(
      org.bukkit.plugin.Plugin plugin, Function<String, InGameFeedbackProfile> profiles) {
    Objects.requireNonNull(plugin, "plugin");
    this.profiles = Objects.requireNonNull(profiles, "profiles");
  }

  @Override
  public void emit(String eventKey, Player player, Location location) {
    Location target = location;
    if (target == null && player != null) {
      target = player.getLocation();
    }
    if (target == null || target.getWorld() == null) {
      return;
    }
    InGameFeedbackProfile profile = profiles.apply(eventKey);
    if (profile == null || !profile.enabled()) {
      return;
    }
    playSound(player, target, profile);
    spawnParticles(target, profile);
    sendPrompts(player, profile);
    // HUD 统一使用 ActionBar/Title；事件反馈不创建 BossBar。
  }

  private void playSound(Player player, Location location, InGameFeedbackProfile profile) {
    sound(profile.sound())
        .ifPresent(
            sound -> {
              if (player != null && player.isOnline()) {
                player.playSound(location, sound, profile.soundVolume(), profile.soundPitch());
                return;
              }
              location
                  .getWorld()
                  .playSound(location, sound, profile.soundVolume(), profile.soundPitch());
            });
  }

  private void spawnParticles(Location location, InGameFeedbackProfile profile) {
    if (profile.particleCount() <= 0) {
      return;
    }
    particle(profile.particle())
        .ifPresent(
            particle ->
                location
                    .getWorld()
                    .spawnParticle(
                        particle,
                        location.clone().add(0.0D, profile.particleYOffset(), 0.0D),
                        profile.particleCount(),
                        profile.particleSpread(),
                        profile.particleSpread(),
                        profile.particleSpread(),
                        0.0D));
  }

  private void sendPrompts(Player player, InGameFeedbackProfile profile) {
    if (player == null || !player.isOnline()) {
      return;
    }
    if (!profile.actionBar().isBlank()) {
      player.sendActionBar(Component.text(profile.actionBar()));
    }
    if (!profile.title().isBlank() || !profile.subtitle().isBlank()) {
      player.showTitle(
          Title.title(
              Component.text(profile.title()),
              Component.text(profile.subtitle()),
              Title.Times.times(
                  ticks(profile.titleFadeInTicks()),
                  ticks(profile.titleStayTicks()),
                  ticks(profile.titleFadeOutTicks()))));
    }
  }

  private Duration ticks(int ticks) {
    return Duration.ofMillis(Math.max(0L, ticks) * 50L);
  }

  private Optional<Sound> sound(String key) {
    return BukkitSoundResolver.resolve(key);
  }

  @SuppressWarnings("deprecation")
  private Optional<Particle> particle(String key) {
    if (key == null || key.isBlank()) {
      return Optional.empty();
    }
    try {
      return Optional.of(Particle.valueOf(key));
    } catch (IllegalArgumentException e) {
      return Optional.empty();
    }
  }
}
