package dev.starcore.starcore.dummy;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** 训练假人数据类 模拟真实玩家用于 PvP 训练 */
public class TrainingDummy {
  private final UUID id;
  private String name;
  private Location location;
  private boolean spawned;

  // 外观配置
  private String skin; // 玩家皮肤
  private ItemStack helmet;
  private ItemStack chestplate;
  private ItemStack leggings;
  private ItemStack boots;
  private ItemStack mainHand;
  private ItemStack offHand;

  // 属性配置
  private double health;
  private double maxHealth;
  private boolean invulnerable;
  private boolean showHealthBar;
  private boolean recordDamage;

  // 行为配置
  private boolean lookAtPlayer;
  private boolean autoRespawn;
  private long respawnDelay; // 毫秒

  // 类型与扩展配置
  private TrainingDummyType type;
  private double damageReduction; // 护甲伤害减免 0.0 - 0.95
  private boolean counterAttack;
  private double counterDamage;
  private boolean movement;
  private boolean hudEnabled;

  // 统计数据
  private long totalDamageReceived;
  private int hitCount;
  private int critCount;
  private long lastHitTime;
  private UUID lastAttacker;

  // 每玩家独立统计
  private final Map<UUID, DamageTracker> attackerStats = new ConcurrentHashMap<>();

  // 实体引用
  private transient Object npcEntity; // NPC 实体对象

  // 关键优化：跟踪上次血量，仅当血量变化时刷新血量条（避免每 tick setCustomName）
  private transient double lastRenderedHealth = -1;

  public TrainingDummy(UUID id, String name, Location location) {
    this.id = id;
    this.name = name;
    this.location = location.clone();
    this.spawned = false;

    // 默认配置
    this.maxHealth = 20.0;
    this.health = maxHealth;
    this.invulnerable = false;
    this.showHealthBar = true;
    this.recordDamage = true;
    this.lookAtPlayer = true;
    this.autoRespawn = true;
    this.respawnDelay = 3000; // 3秒

    // 统计初始化
    this.totalDamageReceived = 0;
    this.hitCount = 0;
    this.critCount = 0;
    this.lastHitTime = 0;

    applyType(TrainingDummyType.STANDARD);
  }

  // Getters
  public UUID getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public Location getLocation() {
    return location.clone();
  }

  public boolean isSpawned() {
    return spawned;
  }

  public String getSkin() {
    return skin;
  }

  public ItemStack getHelmet() {
    return helmet;
  }

  public ItemStack getChestplate() {
    return chestplate;
  }

  public ItemStack getLeggings() {
    return leggings;
  }

  public ItemStack getBoots() {
    return boots;
  }

  public ItemStack getMainHand() {
    return mainHand;
  }

  public ItemStack getOffHand() {
    return offHand;
  }

  public double getHealth() {
    return health;
  }

  public double getMaxHealth() {
    return maxHealth;
  }

  public boolean isInvulnerable() {
    return invulnerable;
  }

  public boolean isShowHealthBar() {
    return showHealthBar;
  }

  public boolean isRecordDamage() {
    return recordDamage;
  }

  public boolean isLookAtPlayer() {
    return lookAtPlayer;
  }

  public boolean isAutoRespawn() {
    return autoRespawn;
  }

  public long getRespawnDelay() {
    return respawnDelay;
  }

  public long getTotalDamageReceived() {
    return totalDamageReceived;
  }

  public int getHitCount() {
    return hitCount;
  }

  public int getCritCount() {
    return critCount;
  }

  public long getLastHitTime() {
    return lastHitTime;
  }

  public UUID getLastAttacker() {
    return lastAttacker;
  }

  public Object getNpcEntity() {
    return npcEntity;
  }

  public TrainingDummyType getType() {
    return type;
  }

  public double getDamageReduction() {
    return damageReduction;
  }

  public boolean isCounterAttack() {
    return counterAttack;
  }

  public double getCounterDamage() {
    return counterDamage;
  }

  public boolean isMovement() {
    return movement;
  }

  public boolean isHudEnabled() {
    return hudEnabled;
  }

  /** 该假人记录过的攻击者 ID 列表 */
  public List<UUID> getTrackedAttackers() {
    return List.copyOf(attackerStats.keySet());
  }

  /** 读取指定玩家对该假人的独立统计，不存在时返回 null */
  public DamageTracker getAttackerStats(UUID attacker) {
    return attackerStats.get(attacker);
  }

  /** 应用类型预设：覆盖血量、减免、反击、移动与 HUD 开关 */
  public void applyType(TrainingDummyType type) {
    this.type = type;
    this.maxHealth = type.getMaxHealth();
    this.damageReduction = type.getDamageReduction();
    this.counterAttack = type.isCounterAttack();
    this.movement = type.isMovement();
    this.counterDamage = type.getCounterDamage();
    this.hudEnabled = type.isHudEnabled();
    resetHealth();
  }

  /** 按护甲减免系数折算实际受到的伤害 */
  public double reduceDamage(double rawDamage) {
    double reduction = Math.max(0.0, Math.min(0.95, damageReduction));
    return rawDamage * (1.0 - reduction);
  }

  /** 检查血量自上次渲染以来是否变化（仅当变化时返回 true，让 tick 重新 setCustomName） */
  public boolean hasHealthChanged() {
    if (health != lastRenderedHealth) {
      lastRenderedHealth = health;
      return true;
    }
    return false;
  }

  // Setters
  public void setName(String name) {
    this.name = name;
  }

  public void setLocation(Location location) {
    this.location = location.clone();
  }

  public void setSpawned(boolean spawned) {
    this.spawned = spawned;
  }

  public void setSkin(String skin) {
    this.skin = skin;
  }

  public void setHelmet(ItemStack helmet) {
    this.helmet = helmet;
  }

  public void setChestplate(ItemStack chestplate) {
    this.chestplate = chestplate;
  }

  public void setLeggings(ItemStack leggings) {
    this.leggings = leggings;
  }

  public void setBoots(ItemStack boots) {
    this.boots = boots;
  }

  public void setMainHand(ItemStack mainHand) {
    this.mainHand = mainHand;
  }

  public void setOffHand(ItemStack offHand) {
    this.offHand = offHand;
  }

  public void setHealth(double health) {
    this.health = Math.max(0, Math.min(health, maxHealth));
  }

  public void setMaxHealth(double maxHealth) {
    this.maxHealth = maxHealth;
  }

  public void setInvulnerable(boolean invulnerable) {
    this.invulnerable = invulnerable;
  }

  public void setShowHealthBar(boolean showHealthBar) {
    this.showHealthBar = showHealthBar;
  }

  public void setRecordDamage(boolean recordDamage) {
    this.recordDamage = recordDamage;
  }

  public void setLookAtPlayer(boolean lookAtPlayer) {
    this.lookAtPlayer = lookAtPlayer;
  }

  public void setAutoRespawn(boolean autoRespawn) {
    this.autoRespawn = autoRespawn;
  }

  public void setRespawnDelay(long respawnDelay) {
    this.respawnDelay = respawnDelay;
  }

  public void setNpcEntity(Object npcEntity) {
    this.npcEntity = npcEntity;
  }

  public void setDamageReduction(double damageReduction) {
    this.damageReduction = Math.max(0.0, Math.min(0.95, damageReduction));
  }

  public void setCounterAttack(boolean counterAttack) {
    this.counterAttack = counterAttack;
  }

  public void setCounterDamage(double counterDamage) {
    this.counterDamage = Math.max(0, counterDamage);
  }

  public void setMovement(boolean movement) {
    this.movement = movement;
  }

  public void setHudEnabled(boolean hudEnabled) {
    this.hudEnabled = hudEnabled;
  }

  /** 记录伤害 */
  public void recordHit(double damage, UUID attacker) {
    recordHit(damage, attacker, false);
  }

  /** 记录伤害（含暴击标记），同时更新假人总统计与该攻击者的独立统计 */
  public void recordHit(double damage, UUID attacker, boolean crit) {
    if (!recordDamage) {
      return;
    }

    this.health = Math.max(0, this.health - damage);
    this.totalDamageReceived += (long) damage;
    this.hitCount++;
    if (crit) {
      this.critCount++;
    }
    this.lastHitTime = System.currentTimeMillis();
    this.lastAttacker = attacker;

    if (attacker != null) {
      attackerStats.computeIfAbsent(attacker, k -> new DamageTracker()).record(damage, crit);
    }
  }

  /** 检查是否死亡 */
  public boolean isDead() {
    return health <= 0;
  }

  /** 重置后强制刷新血量条 */
  public void resetHealth() {
    this.health = maxHealth;
    this.lastRenderedHealth = -1;
  }

  /** 重置统计 */
  public void resetStats() {
    this.totalDamageReceived = 0;
    this.hitCount = 0;
    this.critCount = 0;
    this.lastHitTime = 0;
    this.lastAttacker = null;
    this.attackerStats.clear();
  }

  /** 获取血量百分比 */
  public double getHealthPercentage() {
    return (health / maxHealth) * 100.0;
  }

  /** 获取平均每次伤害 */
  public double getAverageDamage() {
    return hitCount > 0 ? (double) totalDamageReceived / hitCount : 0;
  }

  /** 获取 DPS（每秒伤害） */
  public double getDPS() {
    if (hitCount == 0 || lastHitTime == 0) {
      return 0;
    }

    long duration = lastHitTime - (lastHitTime - (hitCount * 1000L));
    if (duration <= 0) {
      return 0;
    }

    return (totalDamageReceived / (double) duration) * 1000.0;
  }

  /** 复制玩家装备 */
  public void copyEquipment(Player player) {
    this.helmet = player.getInventory().getHelmet();
    this.chestplate = player.getInventory().getChestplate();
    this.leggings = player.getInventory().getLeggings();
    this.boots = player.getInventory().getBoots();
    this.mainHand = player.getInventory().getItemInMainHand();
    this.offHand = player.getInventory().getItemInOffHand();
  }

  /** 复制玩家皮肤 */
  public void copySkin(Player player) {
    this.skin = player.getName();
  }

  /** 获取健康条显示 */
  public String getHealthBar() {
    int total = 20;
    int filled = (int) ((health / maxHealth) * total);

    StringBuilder bar = new StringBuilder("§c");
    for (int i = 0; i < total; i++) {
      if (i < filled) {
        bar.append("♥");
      } else {
        bar.append("§7♥");
      }
    }

    return bar.toString()
        + " §f"
        + String.format("%.1f", health)
        + "§7/§f"
        + String.format("%.1f", maxHealth);
  }
}
