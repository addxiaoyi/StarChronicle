package dev.starcore.starcore.api.v1;

import dev.starcore.starcore.api.v1.config.RestApiConfig;
import java.time.Clock;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

final class RestApiRateLimiter {
    private static final double MILLIS_PER_MINUTE = 60_000.0;

    private final RestApiConfig.RateLimitConfig config;
    private final Clock clock;
    private final ConcurrentMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    RestApiRateLimiter(RestApiConfig.RateLimitConfig config) {
        this(config, Clock.systemUTC());
    }

    RestApiRateLimiter(RestApiConfig.RateLimitConfig config, Clock clock) {
        this.config = Objects.requireNonNull(config, "config");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    boolean allow(String clientKey) {
        if (!config.enabled()) {
            return true;
        }
        long now = clock.millis();
        Bucket bucket = buckets.computeIfAbsent(
            Objects.requireNonNullElse(clientKey, "unknown"),
            ignored -> new Bucket(config.burstSize(), now)
        );
        synchronized (bucket) {
            bucket.refill(now, config);
            if (bucket.blockedUntilMillis > now) {
                return false;
            }
            if (bucket.tokens >= 1.0) {
                bucket.tokens -= 1.0;
                return true;
            }
            bucket.blockedUntilMillis = now + config.blockDurationSeconds() * 1_000L;
            return false;
        }
    }

    long retryAfterSeconds(String clientKey) {
        Bucket bucket = buckets.get(Objects.requireNonNullElse(clientKey, "unknown"));
        if (bucket == null) {
            return 1L;
        }
        synchronized (bucket) {
            long remainingMillis = Math.max(0L, bucket.blockedUntilMillis - clock.millis());
            return Math.max(1L, (remainingMillis + 999L) / 1_000L);
        }
    }

    private static final class Bucket {
        private double tokens;
        private long lastRefillMillis;
        private long blockedUntilMillis;

        private Bucket(int capacity, long createdAtMillis) {
            this.tokens = capacity;
            this.lastRefillMillis = createdAtMillis;
        }

        private void refill(long now, RestApiConfig.RateLimitConfig config) {
            if (now <= lastRefillMillis) {
                return;
            }
            double refill = (now - lastRefillMillis)
                * config.requestsPerMinute()
                / MILLIS_PER_MINUTE;
            tokens = Math.min(config.burstSize(), tokens + refill);
            lastRefillMillis = now;
        }
    }
}
