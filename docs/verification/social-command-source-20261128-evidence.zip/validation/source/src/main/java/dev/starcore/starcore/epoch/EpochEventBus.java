package dev.starcore.starcore.epoch;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/** 纪元事件总线 管理纪元相关的订阅与事件分发 */
public class EpochEventBus {

  private static final Logger LOGGER = Logger.getLogger(EpochEventBus.class.getName());

  private final Map<EpochEventType, List<Consumer<EpochEvent>>> listeners =
      new ConcurrentHashMap<>();
  private final Map<String, List<Consumer<EpochEvent>>> epochListeners = new ConcurrentHashMap<>();
  private final Map<String, List<Consumer<EpochEvent>>> milestoneListeners =
      new ConcurrentHashMap<>();
  private final Map<String, List<Consumer<EpochEvent>>> decisionListeners =
      new ConcurrentHashMap<>();

  private final ExecutorService executorService;
  private final boolean async;

  public EpochEventBus() {
    this(false);
  }

  public EpochEventBus(boolean async) {
    this.async = async;
    this.executorService = async ? Executors.newCachedThreadPool() : null;
  }

  /** 注册事件监听器 */
  public void registerListener(EpochEventType eventType, Consumer<EpochEvent> listener) {
    listeners.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>()).add(listener);
  }

  /** 注册纪元特定的事件监听器 */
  public void registerEpochListener(String epochRunId, Consumer<EpochEvent> listener) {
    epochListeners.computeIfAbsent(epochRunId, k -> new CopyOnWriteArrayList<>()).add(listener);
  }

  /** 注册里程碑特定的事件监听器 */
  public void registerMilestoneListener(String milestoneId, Consumer<EpochEvent> listener) {
    milestoneListeners
        .computeIfAbsent(milestoneId, k -> new CopyOnWriteArrayList<>())
        .add(listener);
  }

  /** 注册决策特定的事件监听器 */
  public void registerDecisionListener(String decisionId, Consumer<EpochEvent> listener) {
    decisionListeners.computeIfAbsent(decisionId, k -> new CopyOnWriteArrayList<>()).add(listener);
  }

  /** 卸载事件监听器 */
  public void unregisterListener(EpochEventType eventType, Consumer<EpochEvent> listener) {
    List<Consumer<EpochEvent>> typeListeners = listeners.get(eventType);
    if (typeListeners != null) {
      typeListeners.remove(listener);
    }
  }

  /** 卸载纪元特定的事件监听器 */
  public void unregisterEpochListener(String epochRunId, Consumer<EpochEvent> listener) {
    List<Consumer<EpochEvent>> typeListeners = epochListeners.get(epochRunId);
    if (typeListeners != null) {
      typeListeners.remove(listener);
    }
  }

  /** 卸载里程碑特定的事件监听器 */
  public void unregisterMilestoneListener(String milestoneId, Consumer<EpochEvent> listener) {
    List<Consumer<EpochEvent>> typeListeners = milestoneListeners.get(milestoneId);
    if (typeListeners != null) {
      typeListeners.remove(listener);
    }
  }

  /** 卸载决策特定的事件监听器 */
  public void unregisterDecisionListener(String decisionId, Consumer<EpochEvent> listener) {
    List<Consumer<EpochEvent>> typeListeners = decisionListeners.get(decisionId);
    if (typeListeners != null) {
      typeListeners.remove(listener);
    }
  }

  /** 发布事件 */
  public void post(EpochEvent event) {
    if (async && executorService != null) {
      executorService.submit(() -> dispatchEvent(event));
    } else {
      dispatchEvent(event);
    }
  }

  /** 同步发布事件 */
  public CompletableFuture<Void> postAsync(EpochEvent event) {
    return CompletableFuture.runAsync(
        () -> dispatchEvent(event),
        executorService != null ? executorService : ForkJoinPool.commonPool());
  }

  private void dispatchEvent(EpochEvent event) {
    // 通知类型监听器
    List<Consumer<EpochEvent>> typeListeners = listeners.get(event.type());
    if (typeListeners != null) {
      for (Consumer<EpochEvent> listener : typeListeners) {
        try {
          listener.accept(event);
        } catch (Exception e) {
          LOGGER.log(Level.SEVERE, "Error in epoch event listener for type " + event.type(), e);
        }
      }
    }

    // 通知纪元监听器
    List<Consumer<EpochEvent>> epochListeners = this.epochListeners.get(event.epochRunId());
    if (epochListeners != null) {
      for (Consumer<EpochEvent> listener : epochListeners) {
        try {
          listener.accept(event);
        } catch (Exception e) {
          LOGGER.log(
              Level.SEVERE, "Error in epoch event listener for epoch " + event.epochRunId(), e);
        }
      }
    }

    // 如果是里程碑事件，通知里程碑监听器
    if (event.type() == EpochEventType.MILESTONE_COMPLETE) {
      String milestoneId = (String) event.metadata().get("milestone_id");
      if (milestoneId != null) {
        List<Consumer<EpochEvent>> milestoneListeners = this.milestoneListeners.get(milestoneId);
        if (milestoneListeners != null) {
          for (Consumer<EpochEvent> listener : milestoneListeners) {
            try {
              listener.accept(event);
            } catch (Exception e) {
              LOGGER.log(
                  Level.SEVERE,
                  "Error in milestone event listener for milestone " + milestoneId,
                  e);
            }
          }
        }
      }
    }

    // 如果是决策事件，通知决策监听器
    if (event.type() == EpochEventType.DECISION_MADE
        || event.type() == EpochEventType.DECISION_LOCKED) {
      String decisionId = (String) event.metadata().get("decision_id");
      if (decisionId != null) {
        List<Consumer<EpochEvent>> decisionListeners = this.decisionListeners.get(decisionId);
        if (decisionListeners != null) {
          for (Consumer<EpochEvent> listener : decisionListeners) {
            try {
              listener.accept(event);
            } catch (Exception e) {
              LOGGER.log(
                  Level.SEVERE, "Error in decision event listener for decision " + decisionId, e);
            }
          }
        }
      }
    }
  }

  /** 清理所有监听器 */
  public void clear() {
    listeners.clear();
    epochListeners.clear();
    milestoneListeners.clear();
    decisionListeners.clear();
  }

  /** 关闭事件总线 */
  public void shutdown() {
    clear();
    if (executorService != null) {
      executorService.shutdown();
    }
  }

  /** 获取监听器数量 */
  public int getListenerCount() {
    return listeners.values().stream().mapToInt(List::size).sum()
        + epochListeners.values().stream().mapToInt(List::size).sum()
        + milestoneListeners.values().stream().mapToInt(List::size).sum()
        + decisionListeners.values().stream().mapToInt(List::size).sum();
  }

  /** 获取注册的事件类型 */
  public Set<EpochEventType> getRegisteredEventTypes() {
    return Set.copyOf(listeners.keySet());
  }

  /** 获取注册的纪元 */
  public Set<String> getRegisteredEpochs() {
    return Set.copyOf(epochListeners.keySet());
  }

  /** 获取注册的里程碑 */
  public Set<String> getRegisteredMilestones() {
    return Set.copyOf(milestoneListeners.keySet());
  }

  /** 获取注册的决策 */
  public Set<String> getRegisteredDecisions() {
    return Set.copyOf(decisionListeners.keySet());
  }
}
