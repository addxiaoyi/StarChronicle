package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BankruptcyService;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.war.WarBond;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * 统一经济视图的不可变快照记录集合。
 *
 * <p>各记录用 {@code Optional}/空集合表达"该子系统未接入"，让调用方能区分 "余额为零"与"模块不可用"，避免把缺失误报为 0。
 */
public final class EconomySnapshot {

  private EconomySnapshot() {}

  /** 个人账户 + 国家国库 + 税收 + 债务的综合视图。 */
  public record PlayerFinance(
      UUID playerId,
      BigDecimal balance,
      boolean accountExists,
      NationId nationId,
      String nationName,
      BigDecimal treasuryBalance,
      BigDecimal totalNationDebt,
      int debtHealthScore,
      boolean bankrupt,
      BigDecimal todayIncome,
      BigDecimal todayExpense) {
    public PlayerFinance {
      Objects.requireNonNull(playerId, "playerId");
      balance = scale(balance);
      treasuryBalance = scale(treasuryBalance);
      totalNationDebt = scale(totalNationDebt);
      todayIncome = scale(todayIncome);
      todayExpense = scale(todayExpense);
    }
  }

  /** 国家财政视图：国库、债务、破产、税种与今日收支。 */
  public record NationFinance(
      NationId nationId,
      String nationName,
      BigDecimal treasuryBalance,
      BigDecimal totalDebt,
      BigDecimal maxBorrowable,
      int debtHealthScore,
      boolean bankrupt,
      List<BankruptcyServiceView> restrictions,
      Map<TaxationService.TaxType, TaxationService.TaxConfig> taxConfigs,
      BigDecimal todayIncome,
      BigDecimal todayExpense,
      Instant generatedAt) {
    public NationFinance {
      Objects.requireNonNull(nationId, "nationId");
      treasuryBalance = scale(treasuryBalance);
      totalDebt = scale(totalDebt);
      maxBorrowable = scale(maxBorrowable);
      todayIncome = scale(todayIncome);
      todayExpense = scale(todayExpense);
      restrictions = restrictions == null ? List.of() : List.copyOf(restrictions);
      taxConfigs = taxConfigs == null ? Map.of() : Map.copyOf(taxConfigs);
      generatedAt = generatedAt == null ? Instant.now() : generatedAt;
    }

    public List<TaxationService.TaxType> enabledTaxTypes() {
      return taxConfigs.entrySet().stream()
          .filter(entry -> entry.getValue() != null && entry.getValue().enabled())
          .map(Map.Entry::getKey)
          .toList();
    }

    /** 国库净值 = 国库余额 - 总债务，用于直观判断财政盈余/赤字。 */
    public BigDecimal netPosition() {
      return scale(treasuryBalance.subtract(totalDebt));
    }
  }

  /** 战争资金视图：WarFund 目标进度与该国持有的战争债券。 */
  public record WarFinance(
      UUID warId,
      NationId nationId,
      BigDecimal fundTargetAmount,
      BigDecimal fundCurrentAmount,
      double fundProgressPercent,
      int contributorCount,
      boolean targetReached,
      List<BondView> bonds,
      Instant generatedAt) {
    public WarFinance {
      Objects.requireNonNull(warId, "warId");
      fundTargetAmount = scale(fundTargetAmount);
      fundCurrentAmount = scale(fundCurrentAmount);
      bonds = bonds == null ? List.of() : List.copyOf(bonds);
      generatedAt = generatedAt == null ? Instant.now() : generatedAt;
    }

    public BigDecimal fundRemaining() {
      BigDecimal remaining = fundTargetAmount.subtract(fundCurrentAmount);
      return remaining.signum() < 0
          ? BigDecimal.ZERO.setScale(2, java.math.RoundingMode.DOWN)
          : scale(remaining);
    }
  }

  /** 战争债券摘要，避免把 WarBond 实体泄漏到门面 API 之外。 */
  public record BondView(
      UUID bondId,
      UUID warId,
      NationId nationId,
      BigDecimal faceValue,
      BigDecimal totalIssued,
      BigDecimal interestRate,
      int termMonths,
      WarBond.BondStatus status,
      Instant issuedAt,
      Instant maturityDate) {
    public BondView {
      Objects.requireNonNull(bondId, "bondId");
      Objects.requireNonNull(warId, "warId");
      Objects.requireNonNull(nationId, "nationId");
      faceValue = scale(faceValue);
      totalIssued = scale(totalIssued);
      interestRate = interestRate == null ? BigDecimal.ZERO : interestRate;
    }

    public static BondView from(WarBond bond) {
      Objects.requireNonNull(bond, "bond");
      return new BondView(
          bond.id(),
          bond.warId(),
          bond.nationId(),
          bond.faceValue(),
          bond.totalIssued(),
          BigDecimal.valueOf(bond.interestRate()),
          bond.termMonths(),
          bond.status(),
          bond.issuedAt(),
          bond.maturityDate());
    }

    public boolean isRedeemable(Instant now) {
      return status == WarBond.BondStatus.MATURED
          || status == WarBond.BondStatus.ACTIVE && !now.isBefore(maturityDate);
    }
  }

  /** 破产限制的扁平视图。 */
  public record BankruptcyServiceView(String configKey, String displayName, String description) {
    public BankruptcyServiceView {
      Objects.requireNonNull(configKey, "configKey");
      displayName = displayName == null ? configKey : displayName;
      description = description == null ? "" : description;
    }

    public static BankruptcyServiceView from(BankruptcyService.Restriction restriction) {
      Objects.requireNonNull(restriction, "restriction");
      return new BankruptcyServiceView(
          restriction.getConfigKey(), restriction.getDisplayName(), restriction.getDescription());
    }
  }

  /** 玩家→国家 的财政摘要列表，供排行榜/GUI 复用。 */
  public record NationFinanceSummary(
      List<NationFinance> nations,
      BigDecimal totalTreasuryBalance,
      BigDecimal totalDebt,
      int bankruptCount,
      Instant generatedAt) {
    public NationFinanceSummary {
      nations = nations == null ? List.of() : List.copyOf(nations);
      totalTreasuryBalance = scale(totalTreasuryBalance);
      totalDebt = scale(totalDebt);
      generatedAt = generatedAt == null ? Instant.now() : generatedAt;
    }
  }

  private static BigDecimal scale(BigDecimal value) {
    return value == null
        ? BigDecimal.ZERO.setScale(2, java.math.RoundingMode.DOWN)
        : value.setScale(2, java.math.RoundingMode.DOWN);
  }
}
