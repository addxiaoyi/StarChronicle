package dev.starcore.starcore.foundation.feedback;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** Player-facing entry point for validating and using particle feedback effects. */
public final class ParticleFeedbackCommand implements CommandExecutor, TabCompleter {
  private static final String PERMISSION = "starcore.feedback.use";
  private final ParticleFeedbackService feedbackService;

  public ParticleFeedbackCommand(ParticleFeedbackService feedbackService) {
    this.feedbackService = feedbackService;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!sender.hasPermission(PERMISSION)) {
      sender.sendMessage("§c你没有使用反馈效果的权限。");
      return true;
    }
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c该命令只能由玩家执行。");
      return true;
    }
    if (args.length == 0) {
      sendUsage(player, label);
      return true;
    }

    String action = args[0].toLowerCase(Locale.ROOT);
    if (action.equals("stop") || action.equals("停止")) {
      feedbackService.stopContinuousFeedback(player);
      player.sendMessage("§a已停止你的持续反馈效果。");
      return true;
    }
    if (action.equals("status") || action.equals("状态")) {
      player.sendMessage(
          "§7持续反馈: "
              + (feedbackService.hasActiveContinuousFeedback(player.getUniqueId())
                  ? "§a运行中"
                  : "§8未运行")
              + " §7| 活跃玩家: §f"
              + feedbackService.activeContinuousFeedbackCount());
      return true;
    }

    boolean continuous = isContinuousAction(action);
    int typeIndex = continuous ? 1 : 0;
    if (args.length <= typeIndex) {
      sendUsage(player, label);
      return true;
    }
    ParticleFeedbackService.FeedbackType type = parseType(args[typeIndex]);
    if (type == null) {
      player.sendMessage("§c未知反馈类型。可用类型: " + typeNames());
      return true;
    }
    ParticleFeedbackService.FeedbackIntensity intensity =
        args.length > typeIndex + 1
            ? parseIntensity(args[typeIndex + 1])
            : ParticleFeedbackService.FeedbackIntensity.MEDIUM;
    if (intensity == null) {
      player.sendMessage("§c未知反馈强度: LOW、MEDIUM、HIGH 或 EPIC。");
      return true;
    }

    if (!continuous) {
      feedbackService.playFeedback(player, type, intensity);
      player.sendMessage("§a反馈效果已播放: §f" + type.name());
      return true;
    }

    int intervalTicks = 20;
    if (args.length > typeIndex + 2) {
      try {
        intervalTicks = Integer.parseInt(args[typeIndex + 2]);
      } catch (NumberFormatException exception) {
        player.sendMessage("§c间隔必须是正整数 tick。");
        return true;
      }
    }
    if (intervalTicks <= 0 || intervalTicks > 1200) {
      player.sendMessage("§c间隔必须在 1 到 1200 tick 之间。");
      return true;
    }
    feedbackService.startContinuousFeedback(player, type, intensity, intervalTicks);
    player.sendMessage("§a已启动持续反馈: §f" + type.name() + " §7(" + intervalTicks + " tick)");
    return true;
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    if (!sender.hasPermission(PERMISSION)) {
      return List.of();
    }
    if (args.length == 1) {
      return prefixMatches(
          java.util.stream.Stream.concat(
                  Stream.of("stop", "status", "continuous", "停止", "状态", "持续"),
                  typeSuggestions().stream())
              .toList(),
          args[0]);
    }
    if (args.length == 2) {
      if (isContinuousAction(args[0])) {
        return prefixMatches(typeSuggestions(), args[1]);
      }
      return isFeedbackType(args[0]) ? prefixMatches(intensitySuggestions(), args[1]) : List.of();
    }
    if (args.length == 3 && isContinuousAction(args[0])) {
      return prefixMatches(intensitySuggestions(), args[2]);
    }
    if (args.length == 4 && isContinuousAction(args[0])) {
      return prefixMatches(List.of("1", "10", "20", "40"), args[3]);
    }
    return List.of();
  }

  private boolean isContinuousAction(String action) {
    return action.equalsIgnoreCase("continuous") || action.equals("持续");
  }

  private boolean isFeedbackType(String value) {
    return Arrays.stream(ParticleFeedbackService.FeedbackType.values())
        .anyMatch(type -> type.name().equalsIgnoreCase(value));
  }

  private List<String> intensitySuggestions() {
    return List.of("LOW", "MEDIUM", "HIGH", "EPIC");
  }

  private void sendUsage(Player player, String label) {
    player.sendMessage("§e/" + label + " <类型> [强度]");
    player.sendMessage("§e/" + label + " continuous <类型> [强度] [间隔tick]");
    player.sendMessage("§e/" + label + " stop|status");
  }

  private ParticleFeedbackService.FeedbackType parseType(String value) {
    try {
      return ParticleFeedbackService.FeedbackType.valueOf(value.toUpperCase(Locale.ROOT));
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private ParticleFeedbackService.FeedbackIntensity parseIntensity(String value) {
    try {
      return ParticleFeedbackService.FeedbackIntensity.valueOf(value.toUpperCase(Locale.ROOT));
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private String typeNames() {
    return typeSuggestions().stream().collect(Collectors.joining("、"));
  }

  private List<String> typeSuggestions() {
    return Arrays.stream(ParticleFeedbackService.FeedbackType.values()).map(Enum::name).toList();
  }

  private List<String> prefixMatches(List<String> values, String prefix) {
    String normalized = prefix.toLowerCase(Locale.ROOT);
    return values.stream()
        .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(normalized))
        .toList();
  }
}
