package dev.starcore.starcore.boss;

import dev.starcore.starcore.core.event.EventBridge;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Boss管理器 管理所有Boss的定义、实例和生命周期 */
public class BossManager {

  private static final long MILLIS_PER_DAY = 24 * 3600 * 1000L;

  private final Map<String, BossDefinition> bossDefinitions = new ConcurrentHashMap<>();
  private final Map<String, BossInstance> bossInstances = new ConcurrentHashMap<>();
  private final Map<String, LateGameEncounter> lateGameEncounters = new ConcurrentHashMap<>();

  // 每日Boss击败次数追踪：playerId -> Map<bossId, count>
  private final Map<String, Map<String, Integer>> dailyBossDefeats = new ConcurrentHashMap<>();

  // 每日重置日期（使用 LocalDate 而非时间戳，确保时区感知）
  private LocalDate dailyResetDate;

  // 时区配置（默认使用系统时区，可通过 setter 配置）
  private ZoneId resetZone = ZoneId.systemDefault();

  private final EventBridge eventBridge;

  // 锁机制
  private final Lock eventResolutionLock = new ReentrantLock();

  // Boss实体追踪：instanceId -> LivingEntity
  private final Map<String, LivingEntity> spawnedEntities = new ConcurrentHashMap<>();

  // Boss世界引用
  private World bossWorld;

  // Boss是否启用实体生成
  private boolean entitySpawningEnabled = false;

  public BossManager() {
    this(null);
  }

  public BossManager(EventBridge eventBridge) {
    this.eventBridge = eventBridge;
    this.dailyResetDate = LocalDate.now(resetZone);
  }

  /** 设置Boss实体生成的世界 */
  public void setBossWorld(World world) {
    this.bossWorld = world;
    this.entitySpawningEnabled = world != null;
  }

  /** 获取Boss实体生成是否启用 */
  public boolean isEntitySpawningEnabled() {
    return entitySpawningEnabled && bossWorld != null;
  }

  /** 设置时区（用于从配置文件读取） */
  public void setResetZone(ZoneId zone) {
    if (zone != null) {
      this.resetZone = zone;
      this.dailyResetDate = LocalDate.now(resetZone);
    }
  }

  /** 获取当前配置的时区 */
  public ZoneId getResetZone() {
    return resetZone;
  }

  /** 注册Boss定义 */
  public void registerBossDefinition(BossDefinition definition) {
    if (definition == null || definition.bossId() == null) {
      throw new IllegalArgumentException("Boss definition and its ID cannot be null");
    }
    bossDefinitions.put(definition.bossId(), definition);
  }

  /** 卸载Boss定义 */
  public void unregisterBossDefinition(String bossId) {
    if (bossId == null) return;
    bossDefinitions.remove(bossId);
  }

  /** 获取Boss定义 */
  public Optional<BossDefinition> getBossDefinition(String bossId) {
    if (bossId == null) return Optional.empty();
    return Optional.ofNullable(bossDefinitions.get(bossId));
  }

  /** 获取所有Boss定义（返回不可变副本） */
  public Collection<BossDefinition> getAllBossDefinitions() {
    return bossDefinitions.values().stream().toList();
  }

  /** 创建Boss实例 */
  public BossInstance createBossInstance(String bossId, String riftInstanceId, String ownerId) {
    if (bossId == null || riftInstanceId == null) {
      throw new IllegalArgumentException("Boss ID and rift instance ID cannot be null");
    }
    BossDefinition definition = bossDefinitions.get(bossId);
    if (definition == null) {
      throw new IllegalArgumentException("Boss definition not found: " + bossId);
    }

    eventResolutionLock.lock();
    try {
      String instanceId = generateInstanceId();
      BossInstance.Builder builder =
          BossInstance.builder(instanceId, bossId, riftInstanceId)
              .status(BossStatus.standby)
              .spawnedAt(System.currentTimeMillis());
      if (ownerId != null) {
        builder.addParticipant(ownerId);
      }

      BossInstance instance = builder.build();
      bossInstances.put(instanceId, instance);
      return instance;
    } finally {
      eventResolutionLock.unlock();
    }
  }

  /** 生成实例ID */
  private String generateInstanceId() {
    return "boss_"
        + System.currentTimeMillis()
        + "_"
        + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 召唤Boss */
  public boolean summonBoss(String instanceId) {
    if (instanceId == null) return false;
    eventResolutionLock.lock();
    try {
      BossInstance instance = bossInstances.get(instanceId);
      if (instance == null) return false;
      // 已终结的Boss不能再召唤
      if (instance.status() == BossStatus.defeated
          || instance.status() == BossStatus.failed
          || instance.status() == BossStatus.archived
          || instance.status() == BossStatus.cancelled) {
        return false;
      }

      BossInstance newInstance =
          new BossInstance(
              instance.instanceId(),
              instance.bossId(),
              instance.riftInstanceId(),
              BossStatus.spawned,
              instance.currentRoute(),
              instance.healthData(),
              instance.stateData(),
              instance.defeatedRoutes(),
              instance.currentPhase(),
              instance.spawnedAt(),
              instance.defeatedAt(),
              instance.winnerId(),
              instance.participants(),
              instance.metadata(),
              instance.errorMessage(),
              instance.retryCount());

      bossInstances.put(instanceId, newInstance);
      publishEvent(EventBridge.EventTypes.BOSS_SPAWN, newInstance);
      if (entitySpawningEnabled) {
        spawnEntity(instance);
      }
      return true;
    } finally {
      eventResolutionLock.unlock();
    }
  }

  public EntityType parseEntityType(String entityType) {
    if (entityType == null || entityType.isBlank()) {
      return EntityType.ZOMBIE;
    }
    return switch (entityType.toUpperCase()) {
      case "SKELETON" -> EntityType.SKELETON;
      case "WITHER" -> EntityType.WITHER;
      case "ENDER_DRAGON" -> EntityType.ENDER_DRAGON;
      case "WITHER_SKELETON" -> EntityType.WITHER_SKELETON;
      case "PILLAGER" -> EntityType.PILLAGER;
      case "EVOKER" -> EntityType.EVOKER;
      case "VINDICATOR" -> EntityType.VINDICATOR;
      case "ELDER_GUARDIAN" -> EntityType.ELDER_GUARDIAN;
      case "GHAST" -> EntityType.GHAST;
      case "MOB" -> EntityType.ZOMBIE;
      default -> {
        try {
          yield EntityType.valueOf(entityType.toUpperCase());
        } catch (IllegalArgumentException e) {
          yield EntityType.ZOMBIE;
        }
      }
    };
  }

  public boolean spawnEntity(BossInstance instance) {
    if (instance == null || bossWorld == null) return false;
    BossDefinition definition = getBossDefinition(instance.bossId()).orElse(null);
    if (definition == null) return false;

    EntityType type = parseEntityType(definition.entityType());
    Location loc = new Location(bossWorld, 0, bossWorld.getHighestBlockYAt(0, 0) + 1, 0);
    LivingEntity entity = (LivingEntity) bossWorld.spawnEntity(loc, type);

    double health = definition.health();
    entity.setHealth(health);
    entity.setCustomName(definition.name());
    entity.setCustomNameVisible(true);

    if (definition.attackDamage() > 0) {
      // 设置攻击伤害通过属性修改器
      entity.getAttribute(Attribute.ATTACK_DAMAGE).setBaseValue(definition.attackDamage());
    }

    // Boss抗性药水效果
    entity.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4));
    entity.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1));
    entity.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1));

    spawnedEntities.put(instance.instanceId(), entity);
    return true;
  }

  public boolean despawnEntity(String instanceId) {
    LivingEntity entity = spawnedEntities.remove(instanceId);
    if (entity != null) {
      entity.remove();
      return true;
    }
    return false;
  }

  public boolean damageBossEntity(String instanceId, double damage, String attacker) {
    LivingEntity entity = spawnedEntities.get(instanceId);
    if (entity == null || entity.isDead()) return false;

    entity.damage(damage);
    publishEvent(
        EventBridge.EventTypes.BOSS_DEATH,
        Map.of(
            "instanceId", instanceId,
            "damage", damage,
            "attacker", attacker,
            "entityHealth", entity.getHealth(),
            "entityMaxHealth", entity.getMaxHealth()));
    return true;
  }

  public LivingEntity getSpawnedEntity(String instanceId) {
    return spawnedEntities.get(instanceId);
  }

  public int getSpawnedEntityCount() {
    return spawnedEntities.size();
  }

  public void clearSpawnedEntities() {
    spawnedEntities.values().forEach(LivingEntity::remove);
    spawnedEntities.clear();
  }

  /**
   * 击败Boss
   *
   * @param instanceId 实例ID
   * @param route 路线标识
   * @param winnerId 获胜者ID（必须是参与者之一）
   */
  public boolean defeatBoss(String instanceId, String route, String winnerId) {
    if (instanceId == null || winnerId == null) return false;
    eventResolutionLock.lock();
    try {
      BossInstance instance = bossInstances.get(instanceId);
      if (instance == null) return false;
      // 已终结的Boss不能被再次击败
      if (instance.status() == BossStatus.defeated
          || instance.status() == BossStatus.failed
          || instance.status() == BossStatus.archived
          || instance.status() == BossStatus.cancelled) {
        return false;
      }
      // IDOR防护：获胜者必须是实例参与者
      if (instance.participants() == null || !instance.participants().contains(winnerId)) {
        return false;
      }

      BossInstance.Builder builder =
          BossInstance.builder(instance.instanceId(), instance.bossId(), instance.riftInstanceId())
              .status(BossStatus.defeated)
              .currentRoute(instance.currentRoute())
              .healthData(instance.healthData())
              .stateData(instance.stateData())
              .spawnedAt(instance.spawnedAt())
              .defeatedAt(System.currentTimeMillis())
              .winnerId(winnerId)
              .participants(instance.participants())
              .metadata(instance.metadata());

      // 添加已完成的路线
      List<String> defeatedRoutes = new ArrayList<>(instance.defeatedRoutes());
      if (route != null && !defeatedRoutes.contains(route)) {
        defeatedRoutes.add(route);
      }
      builder.defeatedRoutes(defeatedRoutes);

      BossInstance newInstance = builder.build();
      bossInstances.put(instanceId, newInstance);

      // 计算原始奖励
      BigDecimal baseReward = calculateBossReward(newInstance);
      // 应用每日递减倍率
      double diminishingMultiplier = getDailyDiminishingMultiplier(winnerId, newInstance.bossId());
      BigDecimal reward =
          baseReward
              .multiply(BigDecimal.valueOf(diminishingMultiplier))
              .setScale(0, java.math.RoundingMode.DOWN);
      // 记录本次击败
      recordBossDefeat(winnerId, newInstance.bossId());

      publishEvent(
          EventBridge.EventTypes.BOSS_DEFEATED,
          Map.of(
              "instance", newInstance,
              "route", route == null ? "" : route,
              "winnerId", winnerId,
              "reward", reward,
              "baseReward", baseReward,
              "diminishingMultiplier", diminishingMultiplier));
      despawnEntity(instanceId);
      return true;
    } finally {
      eventResolutionLock.unlock();
    }
  }

  /** 失败Boss */
  public boolean failBoss(String instanceId, String errorMessage) {
    if (instanceId == null) return false;
    eventResolutionLock.lock();
    try {
      BossInstance instance = bossInstances.get(instanceId);
      if (instance == null) return false;
      // 已终结的Boss不能再次失败
      if (instance.status() == BossStatus.defeated
          || instance.status() == BossStatus.failed
          || instance.status() == BossStatus.archived
          || instance.status() == BossStatus.cancelled) {
        return false;
      }

      BossInstance newInstance =
          new BossInstance(
              instance.instanceId(),
              instance.bossId(),
              instance.riftInstanceId(),
              BossStatus.failed,
              instance.currentRoute(),
              instance.healthData(),
              instance.stateData(),
              instance.defeatedRoutes(),
              instance.currentPhase(),
              instance.spawnedAt(),
              instance.defeatedAt(),
              instance.winnerId(),
              instance.participants(),
              instance.metadata(),
              errorMessage,
              instance.retryCount() + 1);

      bossInstances.put(instanceId, newInstance);
      publishEvent(
          EventBridge.EventTypes.BOSS_DEATH,
          Map.of(
              "instance", newInstance, "errorMessage", errorMessage == null ? "" : errorMessage));
      despawnEntity(instanceId);
      return true;
    } finally {
      eventResolutionLock.unlock();
    }
  }

  /** 获取Boss实例 */
  public Optional<BossInstance> getBossInstance(String instanceId) {
    return Optional.ofNullable(bossInstances.get(instanceId));
  }

  /** 获取Boss实例（内部访问用，返回副本） */
  Map<String, BossInstance> getBossInstances() {
    return Map.copyOf(bossInstances);
  }

  /** 获取Boss实例 */
  public Optional<BossInstance> getBossInstanceById(String bossId) {
    return bossInstances.values().stream().filter(i -> i.bossId().equals(bossId)).findFirst();
  }

  /** 获取指定Boss定义的所有实例 */
  public List<BossInstance> getInstancesByBossId(String bossId) {
    return bossInstances.values().stream().filter(i -> i.bossId().equals(bossId)).toList();
  }

  /** 获取指定裂隙的所有Boss实例 */
  public List<BossInstance> getInstancesByRift(String riftInstanceId) {
    return bossInstances.values().stream()
        .filter(i -> i.riftInstanceId().equals(riftInstanceId))
        .toList();
  }

  /** 获取所有活跃的Boss实例 */
  public List<BossInstance> getActiveInstances() {
    return bossInstances.values().stream().filter(BossInstance::isActive).toList();
  }

  /** 获取所有已击败的Boss实例 */
  public List<BossInstance> getDefeatedInstances() {
    return bossInstances.values().stream().filter(BossInstance::isDefeated).toList();
  }

  /** 检查玩家的Boss进度 */
  public int getPlayerDefeatedCount(String playerId) {
    return (int)
        bossInstances.values().stream()
            .filter(BossInstance::isDefeated)
            .filter(i -> i.participants().contains(playerId))
            .count();
  }

  // ==================== 后期遭遇管理 ====================

  /** 注册后期遭遇 */
  public void registerLateGameEncounter(LateGameEncounter encounter) {
    if (encounter == null || encounter.encounterId() == null) {
      throw new IllegalArgumentException("Encounter and its ID cannot be null");
    }
    lateGameEncounters.put(encounter.encounterId(), encounter);
  }

  /** 卸载后期遭遇 */
  public void unregisterLateGameEncounter(String encounterId) {
    lateGameEncounters.remove(encounterId);
  }

  /** 获取后期遭遇 */
  public Optional<LateGameEncounter> getLateGameEncounter(String encounterId) {
    return Optional.ofNullable(lateGameEncounters.get(encounterId));
  }

  /** 获取所有后期遭遇（返回不可变副本） */
  public Collection<LateGameEncounter> getLateEncounters() {
    return lateGameEncounters.values().stream().toList();
  }

  /** 获取所有活跃Boss实例 */
  public List<BossInstance> getAvailableBosses() {
    return bossInstances.values().stream().filter(BossInstance::isActive).toList();
  }

  /** 根据类型获取后期遭遇 */
  public List<LateGameEncounter> getEncountersByType(LateGameEncounter.EncounterType type) {
    return lateGameEncounters.values().stream().filter(e -> e.type() == type).toList();
  }

  /** 开始后期遭遇 只有当所有Boss定义都可用时才创建实例，避免孤立实例 */
  public Optional<BossInstance> startLateGameEncounter(String encounterId, String ownerId) {
    if (encounterId == null) return Optional.empty();

    LateGameEncounter encounter = lateGameEncounters.get(encounterId);
    if (encounter == null) return Optional.empty();
    if (encounter.bossIds() == null || encounter.bossIds().isEmpty()) return Optional.empty();

    // 验证所有Boss定义都可用
    for (String bossId : encounter.bossIds()) {
      if (getBossDefinition(bossId).isEmpty()) {
        return Optional.empty();
      }
    }

    // 所有定义都可用，才创建实例
    List<BossInstance> instances = new ArrayList<>();
    for (String bossId : encounter.bossIds()) {
      BossInstance instance = createBossInstance(bossId, "encounter_" + encounterId, ownerId);
      instances.add(instance);
    }

    if (instances.isEmpty()) return Optional.empty();

    // 返回第一个Boss实例作为入口
    return Optional.of(instances.get(0));
  }

  /**
   * 根据击败的Boss计算奖励星币 - 基础值: 100 - 每级加成: +50（Boss 等级越高，回报越大） - 每阶段加成: +20（鼓励完成多阶段战斗） - 参与人数加成:
   * +30/人（团队协作有额外收益）
   */
  public BigDecimal calculateBossReward(BossInstance instance) {
    if (instance == null) return BigDecimal.ZERO;
    BossDefinition definition = getBossDefinition(instance.bossId()).orElse(null);
    int bossLevel = (definition != null) ? definition.level() : 1;
    int phaseCount = definition != null ? definition.getPhaseCount() : 0;
    int participantCount = instance.participants() != null ? instance.participants().size() : 1;

    BigDecimal base = new BigDecimal("100");
    BigDecimal levelBonus = new BigDecimal(bossLevel * 50);
    BigDecimal phaseBonus = new BigDecimal(phaseCount * 20);
    BigDecimal partyBonus = new BigDecimal((participantCount - 1) * 30);

    return base.add(levelBonus).add(phaseBonus).add(partyBonus);
  }

  /** 检查并重置每日追踪器（如果日期已变更） 使用显式时区确保跨服务器、跨时区一致性 */
  private void checkDailyReset() {
    LocalDate today = LocalDate.now(resetZone);
    if (!today.equals(dailyResetDate)) {
      dailyBossDefeats.clear();
      dailyResetDate = today;
    }
  }

  /** 获取玩家当日对该Boss的击败次数 */
  public int getDailyDefeatCount(String playerId, String bossId) {
    checkDailyReset();
    Map<String, Integer> playerDefeats = dailyBossDefeats.get(playerId);
    if (playerDefeats == null) return 0;
    return playerDefeats.getOrDefault(bossId, 0);
  }

  /** 根据今日击败次数计算递减奖励倍率 1次: 100%, 2次: 60%, 3次: 30%, 4次+: 10% */
  public double getDailyDiminishingMultiplier(String playerId, String bossId) {
    int count = getDailyDefeatCount(playerId, bossId);
    return switch (count) {
      case 0 -> 1.0;
      case 1 -> 0.6;
      case 2 -> 0.3;
      default -> 0.1;
    };
  }

  /** 记录玩家击败Boss（用于递减奖励追踪） */
  public void recordBossDefeat(String playerId, String bossId) {
    checkDailyReset();
    dailyBossDefeats
        .computeIfAbsent(playerId, k -> new ConcurrentHashMap<>())
        .merge(bossId, 1, Integer::sum);
  }

  /** 清理所有Boss */
  public void clear() {
    clearSpawnedEntities();
    bossDefinitions.clear();
    bossInstances.clear();
    lateGameEncounters.clear();
    dailyBossDefeats.clear();
  }

  /** 发布事件 */
  private void publishEvent(String eventType, Object eventData) {
    if (eventBridge != null) {
      eventBridge.publish(eventType, eventData);
    }
  }
}
