package dev.starcore.starcore.evidence;

/** 证据类型枚举 定义不同类型的证据 */
public enum EvidenceType {
  /** Boss证据：击败Boss获得的证据 */
  boss_defeat("Boss证据", "击败Boss获得的证据"),

  /** 选择证据：参与公共选择获得的证据 */
  choice_participation("选择证据", "参与公共选择获得的证据"),

  /** 事件证据：完成特定事件获得的证据 */
  event_completion("事件证据", "完成特定事件获得的证据"),

  /** 探索证据：探索特定区域获得的证据 */
  exploration("探索证据", "探索特定区域获得的证据"),

  /** 成就证据：达成成就获得的证据 */
  achievement("成就证据", "达成成就获得的证据"),

  /** 交易证据：通过交易获得的证据 */
  trade("交易证据", "通过交易获得的证据"),

  /** 系统证据：系统自动生成的证据 */
  system("系统证据", "系统自动生成的证据");

  private final String displayName;
  private final String description;

  EvidenceType(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 检查是否为玩家获得的证据 */
  public boolean isPlayerEarned() {
    return this == boss_defeat
        || this == choice_participation
        || this == event_completion
        || this == exploration
        || this == achievement;
  }

  /** 检查是否为可交易的证据 */
  public boolean isTradable() {
    return this == boss_defeat || this == exploration || this == achievement || this == trade;
  }
}
