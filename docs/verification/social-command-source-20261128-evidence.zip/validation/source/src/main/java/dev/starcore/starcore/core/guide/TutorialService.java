package dev.starcore.starcore.core.guide;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** 新手引导服务 */
public final class TutorialService {

  private final JavaPlugin plugin;
  private final Map<UUID, TutorialProgress> progressMap = new ConcurrentHashMap<>();

  public TutorialService(JavaPlugin plugin) {
    this.plugin = plugin;
  }

  /** 检查玩家是否需要新手引导 */
  public boolean needsTutorial(Player player) {
    UUID playerId = player.getUniqueId();
    TutorialProgress progress = progressMap.get(playerId);
    return progress == null || !progress.isCompleted();
  }

  /** 开始新手引导 */
  public void startTutorial(Player player) {
    UUID playerId = player.getUniqueId();
    progressMap.put(playerId, new TutorialProgress(playerId));

    player.sendMessage("§6§l=== STARCORE 新手引导 ===");
    player.sendMessage("§7欢迎来到 STARCORE！我将引导你了解游戏基础。");
    player.sendMessage("§7你可以随时打开指南书查看并执行下一步。");
    player.sendMessage("");

    // 打开玩法指南
    GameplayGuideGui.openMainMenu(player);
  }

  /** 完成引导步骤 */
  public void completeStep(Player player, TutorialStep step) {
    UUID playerId = player.getUniqueId();
    TutorialProgress progress = progressMap.computeIfAbsent(playerId, TutorialProgress::new);
    progress.completeStep(step);

    player.sendMessage("§a✓ 完成步骤: " + step.getDescription());

    if (progress.isCompleted()) {
      player.sendMessage("");
      player.sendMessage("§6§l🎉 恭喜！你已完成新手引导！");
      player.sendMessage("§7现在你可以开始正式游戏了。");
      player.sendMessage("§7有任何问题，随时打开指南书继续操作。");
    }
  }

  /** 获取引导进度 */
  public TutorialProgress getProgress(Player player) {
    return progressMap.getOrDefault(
        player.getUniqueId(), new TutorialProgress(player.getUniqueId()));
  }

  /** 引导进度 */
  public static final class TutorialProgress {
    private final UUID playerId;
    private final Map<TutorialStep, Boolean> completedSteps = new ConcurrentHashMap<>();

    public TutorialProgress(UUID playerId) {
      this.playerId = playerId;
    }

    public void completeStep(TutorialStep step) {
      completedSteps.put(step, true);
    }

    public boolean isStepCompleted(TutorialStep step) {
      return completedSteps.getOrDefault(step, false);
    }

    public boolean isCompleted() {
      for (TutorialStep step : TutorialStep.values()) {
        if (!completedSteps.getOrDefault(step, false)) {
          return false;
        }
      }
      return true;
    }

    public int getCompletedCount() {
      return (int) completedSteps.values().stream().filter(Boolean::booleanValue).count();
    }

    public UUID getPlayerId() {
      return playerId;
    }
  }

  /** 引导步骤 */
  public enum TutorialStep {
    VIEW_GUIDE("查看玩法指南"),
    JOIN_OR_CREATE_NATION("加入或创建国家"),
    UNDERSTAND_NATION("了解国家系统"),
    CHECK_ECONOMY("了解经济系统"),
    EXPLORE_FEATURES("探索特色玩法");

    private final String description;

    TutorialStep(String description) {
      this.description = description;
    }

    public String getDescription() {
      return description;
    }
  }
}
