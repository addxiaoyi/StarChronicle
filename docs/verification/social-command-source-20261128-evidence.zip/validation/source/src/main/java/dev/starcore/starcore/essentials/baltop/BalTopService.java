package dev.starcore.starcore.essentials.baltop;

import java.math.BigDecimal;
import java.util.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/** 财富排行榜服务 管理玩家财富排名 */
public final class BalTopService {
  // 排行榜缓存 排名 -> (UUID, 余额)
  // volatile + 不可变快照：异步 recalculateRankings 整体替换、主线程 GUI/命令按索引遍历。
  // 读方先快照到局部变量，避免重算时 size()/get(i) 之间列表被替换导致越界。
  private volatile List<BalTopEntry> topPlayers = List.of();

  // 完整排名数据（用于快速查询玩家排名）。用不可变快照整体替换，避免保存时读到半次更新。
  private volatile Map<UUID, BigDecimal> playerBalances = Map.of();

  // 最后更新时间
  private volatile long lastUpdate = 0;

  // 缓存时间（毫秒）
  private final long cacheTime = 60000; // 1分钟

  /** 更新排行榜 */
  public void updateRankings(Map<UUID, BigDecimal> allBalances) {
    Objects.requireNonNull(allBalances, "allBalances");
    playerBalances = Map.copyOf(allBalances);

    // 重新计算排名
    recalculateRankings();

    lastUpdate = System.currentTimeMillis();
  }

  /** 重新计算排名 */
  private void recalculateRankings() {
    // 本地构建完整快照后一次性替换，读方永远看到一致的列表
    List<BalTopEntry> snapshot =
        playerBalances.entrySet().stream()
            .map(entry -> new BalTopEntry(entry.getKey(), entry.getValue()))
            .sorted(
                Comparator.comparing(BalTopEntry::balance)
                    .reversed()
                    .thenComparing(entry -> entry.playerId().toString()))
            .limit(100) // 只保留前100名
            .toList();
    topPlayers = snapshot;
  }

  /** 获取排行榜 优化：使用 List.copyOf() 返回不可变副本，避免每次调用都 new ArrayList */
  public List<BalTopEntry> getTopPlayers(int limit) {
    List<BalTopEntry> snapshot = topPlayers; // 快照，避免多次读 volatile
    if (snapshot.isEmpty()) {
      return List.of();
    }
    int actualLimit = Math.min(limit, snapshot.size());
    return List.copyOf(snapshot.subList(0, actualLimit));
  }

  /** 获取玩家排名 */
  public OptionalInt getPlayerRank(UUID playerId) {
    List<BalTopEntry> snapshot = topPlayers; // 快照，避免 size()/get(i) 间列表被替换
    for (int i = 0; i < snapshot.size(); i++) {
      if (snapshot.get(i).playerId().equals(playerId)) {
        return OptionalInt.of(i + 1); // 排名从1开始
      }
    }
    return OptionalInt.empty();
  }

  /** 检查是否需要更新 */
  public boolean needsUpdate() {
    return System.currentTimeMillis() - lastUpdate > cacheTime;
  }

  /** 获取排行榜大小 */
  public int size() {
    return topPlayers.size();
  }

  /** 获取玩家余额 */
  public BigDecimal getBalance(UUID playerId) {
    return playerBalances.getOrDefault(playerId, BigDecimal.ZERO);
  }

  /** 加载数据 */
  public void loadData(YamlConfiguration config) {
    ConfigurationSection balancesSection = config.getConfigurationSection("balances");

    if (balancesSection == null) {
      return;
    }

    Map<UUID, BigDecimal> loadedBalances = new HashMap<>();

    for (String uuidStr : balancesSection.getKeys(false)) {
      try {
        UUID playerId = UUID.fromString(uuidStr);
        Object rawBalance = balancesSection.get(uuidStr);
        BigDecimal balance = parseBalance(rawBalance);
        if (balance != null) {
          loadedBalances.put(playerId, balance);
        }
      } catch (IllegalArgumentException e) {
        // 跳过无效 UUID 或余额
      }
    }

    playerBalances = Map.copyOf(loadedBalances);
    recalculateRankings();
    lastUpdate = config.getLong("lastUpdate", System.currentTimeMillis());
  }

  private static BigDecimal parseBalance(Object rawBalance) {
    if (rawBalance instanceof BigDecimal decimal) {
      return decimal;
    }
    if (rawBalance instanceof Number number) {
      return new BigDecimal(number.toString());
    }
    if (rawBalance instanceof String text && !text.isBlank()) {
      return new BigDecimal(text.trim());
    }
    return null;
  }

  /** 保存数据 */
  public void saveData(YamlConfiguration config) {
    saveData(config, persistenceSnapshot());
  }

  /** Returns an immutable point-in-time snapshot for asynchronous persistence. */
  public PersistenceSnapshot persistenceSnapshot() {
    return new PersistenceSnapshot(playerBalances, lastUpdate);
  }

  /** Saves a previously captured snapshot without reading the live cache. */
  public void saveData(YamlConfiguration config, PersistenceSnapshot snapshot) {
    ConfigurationSection balancesSection = config.createSection("balances");

    for (Map.Entry<UUID, BigDecimal> entry : snapshot.balances().entrySet()) {
      balancesSection.set(entry.getKey().toString(), entry.getValue().toPlainString());
    }

    config.set("lastUpdate", snapshot.lastUpdate());
  }

  /** 排行榜条目 */
  public record BalTopEntry(UUID playerId, BigDecimal balance) {}

  public record PersistenceSnapshot(Map<UUID, BigDecimal> balances, long lastUpdate) {
    public PersistenceSnapshot {
      balances = Map.copyOf(balances);
    }
  }
}
