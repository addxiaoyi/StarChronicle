package dev.starcore.starcore.economy;

/** 资源类型枚举 定义游戏中不同类型的资源 */
public enum ResourceType {
  /** 通用资源 */
  generic("通用", "一般资源"),

  /** 能源资源 */
  energy("能源", "用于维持设施运转"),

  /** 矿产资源 */
  mineral("矿产", "用于制造设备"),

  /** 生物资源 */
  biomass("生物质", "用于生物研究"),

  /** 数据资源 */
  data("数据", "用于信息处理"),

  /** 记忆资源 */
  memory("记忆", "用于烹调和知识"),

  /** 信任资源 */
  trust("信任", "用于治理和关系");

  private final String displayName;
  private final String description;

  ResourceType(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }
}
