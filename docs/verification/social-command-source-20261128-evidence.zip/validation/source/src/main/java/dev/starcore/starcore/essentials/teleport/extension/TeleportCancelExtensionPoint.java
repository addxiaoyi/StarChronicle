package dev.starcore.starcore.essentials.teleport.extension;

import dev.starcore.starcore.core.extension.AbstractExtensionPoint;
import dev.starcore.starcore.foundation.territory.model.ChunkCoordinate;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

/**
 * 传送取消扩展点
 *
 * <p>允许取消或修改传送请求。 典型用途：禁用传送到PvP区、敌对领地，实施传送队列，节日活动等。
 */
public class TeleportCancelExtensionPoint
    extends AbstractExtensionPoint<
        TeleportCancelExtensionPoint.CancelResult, TeleportCancelExtensionPoint.CancelContext> {

  public TeleportCancelExtensionPoint() {
    super("teleport_cancel", "传送取消扩展点 - 允许取消或修改传送请求");
  }

  @Override
  protected CancelResult aggregateResults(List<CancelResult> results, CancelContext request) {
    if (results.isEmpty()) {
      return getDefaultResult(request);
    }
    // 任何一个取消都取消整个传送
    for (CancelResult result : results) {
      if (result.cancelled) {
        return result;
      }
    }
    // 如果都没有取消，返回第一个非取消的结果（如果需要修改目标位置）
    for (CancelResult result : results) {
      if (result.decoratedDestination() != null) {
        return result;
      }
    }
    return getDefaultResult(request);
  }

  @Override
  protected CancelResult getDefaultResult(CancelContext request) {
    return new CancelResult(false, request.destination, "default", Map.of());
  }

  /** 传送取消上下文 */
  public record CancelContext(
      Player player,
      Location destination,
      TeleportType teleportType,
      String world,
      Integer x,
      Integer z,
      Long delayedTicks) {
    public CancelContext {
      if (destination == null) {
        destination = player.getLocation();
      }
      if (world == null) {
        world = destination.getWorld() != null ? destination.getWorld().getName() : "unknown";
      }
      if (x == null) {
        x = destination.getBlockX();
      }
      if (z == null) {
        z = destination.getBlockZ();
      }
    }

    public CancelContext(Player player, Location destination, TeleportType type) {
      this(player, destination, type, null, null, null, null);
    }

    public ChunkCoordinate getChunkCoordinate() {
      if (x != null && z != null && world != null) {
        return new ChunkCoordinate(world, x / 16, z / 16);
      }
      if (destination != null && destination.getWorld() != null) {
        return new ChunkCoordinate(
            destination.getWorld().getName(),
            destination.getBlockX() / 16,
            destination.getBlockZ() / 16);
      }
      throw new IllegalStateException("Cannot determine chunk coordinate");
    }

    public World getWorld() {
      if (destination != null) {
        return destination.getWorld();
      }
      return null;
    }
  }

  /** 传送取消结果 */
  public record CancelResult(
      boolean cancelled, Location decoratedDestination, String reason, Map<String, Object> metadata)
      implements Serializable {
    public CancelResult {
      if (metadata == null) {
        metadata = Map.of();
      }
    }
  }

  public enum TeleportType {
    HOME,
    SPAWN,
    WARP,
    TP_A,
    TP_B,
    BACK,
    WEIGHTED,
    CLAIM
  }
}
