package dev.starcore.starcore.daily;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.plugin.Plugin;

/** 签到日历 GUI 点击监听 */
public final class CheckInGuiListener implements Listener {

  private final CheckInService checkInService;

  public CheckInGuiListener(Plugin plugin, CheckInService checkInService) {
    this.checkInService = checkInService;
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof CheckInGui) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getInventory().getHolder() instanceof CheckInGui gui)) {
      return;
    }
    event.setCancelled(true);
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    if (event.getClickedInventory() != event.getInventory()) {
      return;
    }
    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.0f);
    gui.handleClick(event.getSlot());
  }
}
