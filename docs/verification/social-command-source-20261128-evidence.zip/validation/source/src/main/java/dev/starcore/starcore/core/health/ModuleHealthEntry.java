package dev.starcore.starcore.core.health;

import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleStatus;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

/** Health projection for one registered STARCORE module. */
public record ModuleHealthEntry(
    String id,
    String displayName,
    ModuleLayer layer,
    ModuleStatus status,
    Instant lastChangedAt,
    String failureReason,
    List<String> dependencies) {
  public ModuleHealthEntry {
    Objects.requireNonNull(id, "id");
    Objects.requireNonNull(displayName, "displayName");
    Objects.requireNonNull(layer, "layer");
    Objects.requireNonNull(status, "status");
    Objects.requireNonNull(lastChangedAt, "lastChangedAt");
    Objects.requireNonNull(dependencies, "dependencies");
    dependencies = List.copyOf(dependencies);
  }
}
