package dev.starcore.starcore.api.v1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.endpoint.EventsEndpoint;
import dev.starcore.starcore.api.v1.endpoint.FinanceEndpoint;
import dev.starcore.starcore.api.v1.endpoint.ModuleDependencyEndpoint;
import dev.starcore.starcore.api.v1.endpoint.NationEndpoint;
import dev.starcore.starcore.api.v1.endpoint.PlayersEndpoint;
import dev.starcore.starcore.api.v1.endpoint.StatsEndpoint;
import dev.starcore.starcore.api.v1.endpoint.TerritoryEndpoint;
import dev.starcore.starcore.api.v1.endpoint.WarsEndpoint;
import dev.starcore.starcore.api.v1.handler.RestApiCors;
import dev.starcore.starcore.core.monitor.ModuleDependencyMonitor;
import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.foundation.player.PlayerProfileService;
import dev.starcore.starcore.foundation.territory.TerritoryService;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import dev.starcore.starcore.module.war.WarService;
import dev.starcore.starcore.ranking.RankingService;
import dev.starcore.starcore.social.simulation.RelationshipNetwork;
import dev.starcore.starcore.war.WarServiceImpl;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** REST API 服务器 提供完整的 REST API 服务 */
public final class RestApiServer {

  private final Gson gson;
  private final ApiAuthService authService;
  private final NationService nationService;
  private final TerritoryService territoryService;
  private final WarService warService;
  private final WarServiceImpl warServiceImpl;
  private final OnlinePlayerDirectory playerDirectory;
  private final PlayerProfileService playerProfileService;
  private final EventService eventService;
  private final TreasuryService treasuryService;
  private final ModuleDependencyMonitor dependencyMonitor;
  private final RelationshipNetwork relationshipNetwork;
  private final RankingService rankingService;
  private final RestApiConfig config;
  private final RestApiRateLimiter rateLimiter;

  private HttpServer server;
  private ExecutorService executor;
  private volatile long startedAtNanos;
  private final String host;
  private final int port;

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      OnlinePlayerDirectory playerDirectory,
      String host,
      int port,
      ApiAuthService authService) {
    this(
        nationService,
        territoryService,
        warService,
        null,
        playerDirectory,
        null,
        null,
        host,
        port,
        authService,
        RestApiConfig.DEFAULT,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService) {
    this(
        nationService,
        territoryService,
        warService,
        warServiceImpl,
        playerDirectory,
        playerProfileService,
        eventService,
        host,
        port,
        authService,
        RestApiConfig.DEFAULT,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService,
      RestApiConfig config) {
    this(
        nationService,
        territoryService,
        warService,
        warServiceImpl,
        playerDirectory,
        playerProfileService,
        eventService,
        host,
        port,
        authService,
        config,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService,
      RestApiConfig config,
      TreasuryService treasuryService) {
    this(
        nationService,
        territoryService,
        warService,
        warServiceImpl,
        playerDirectory,
        playerProfileService,
        eventService,
        host,
        port,
        authService,
        config,
        treasuryService,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService,
      RestApiConfig config,
      TreasuryService treasuryService,
      ModuleDependencyMonitor dependencyMonitor) {
    this(
        nationService,
        territoryService,
        warService,
        warServiceImpl,
        playerDirectory,
        playerProfileService,
        eventService,
        host,
        port,
        authService,
        config,
        treasuryService,
        dependencyMonitor,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService,
      RestApiConfig config,
      TreasuryService treasuryService,
      ModuleDependencyMonitor dependencyMonitor,
      RelationshipNetwork relationshipNetwork) {
    this(
        nationService,
        territoryService,
        warService,
        warServiceImpl,
        playerDirectory,
        playerProfileService,
        eventService,
        host,
        port,
        authService,
        config,
        treasuryService,
        dependencyMonitor,
        relationshipNetwork,
        null);
  }

  public RestApiServer(
      NationService nationService,
      TerritoryService territoryService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      OnlinePlayerDirectory playerDirectory,
      PlayerProfileService playerProfileService,
      EventService eventService,
      String host,
      int port,
      ApiAuthService authService,
      RestApiConfig config,
      TreasuryService treasuryService,
      ModuleDependencyMonitor dependencyMonitor,
      RelationshipNetwork relationshipNetwork,
      RankingService rankingService) {
    this.nationService = nationService;
    this.territoryService = territoryService;
    this.warService = warService;
    this.warServiceImpl = warServiceImpl;
    this.playerDirectory = playerDirectory;
    this.playerProfileService = playerProfileService;
    this.eventService = eventService;
    this.treasuryService = treasuryService;
    this.dependencyMonitor = dependencyMonitor;
    this.relationshipNetwork = relationshipNetwork;
    this.rankingService = rankingService;
    this.host = host;
    this.port = port;
    this.config = Objects.requireNonNull(config, "config");

    this.gson =
        new GsonBuilder()
            .serializeNulls()
            .setPrettyPrinting()
            .registerTypeAdapter(
                Instant.class,
                (JsonSerializer<Instant>)
                    (value, type, context) -> new JsonPrimitive(value.toString()))
            .create();

    this.authService = authService;
    this.rateLimiter = new RestApiRateLimiter(config.rateLimit());
  }

  /** 启动服务器 */
  public void start() throws IOException {
    if (server != null) {
      return;
    }

    server = HttpServer.create(new InetSocketAddress(host, port), 0);
    executor =
        Executors.newFixedThreadPool(
            Math.max(2, Runtime.getRuntime().availableProcessors()), new RestApiThreadFactory());
    server.setExecutor(executor);

    // 注册处理器
    registerHandlers();

    server.start();
    startedAtNanos = System.nanoTime();
  }

  /** 停止服务器 */
  public void stop() {
    if (server != null) {
      server.stop(0);
      server = null;
    }
    startedAtNanos = 0L;
    if (executor != null) {
      executor.shutdown();
      try {
        if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
          executor.shutdownNow();
        }
      } catch (InterruptedException e) {
        executor.shutdownNow();
        // 不要中断当前线程，只记录日志
        System.getLogger(RestApiServer.class.getName())
            .log(System.Logger.Level.WARNING, "Executor shutdown interrupted");
      }
      executor = null;
    }
  }

  private long uptimeMillis() {
    long started = startedAtNanos;
    if (started == 0L) {
      return 0L;
    }
    return Math.max(0L, TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started));
  }

  /** 注册所有处理器 */
  private void registerHandlers() {
    // 创建端点处理器
    NationEndpoint nationEndpoint =
        new NationEndpoint(
            gson,
            authService,
            nationService,
            config.cors(),
            config.endpoints().nations().requiresAuth());
    TerritoryEndpoint territoryEndpoint =
        new TerritoryEndpoint(
            gson,
            authService,
            territoryService,
            nationService,
            config.cors(),
            config.endpoints().territories().requiresAuth());
    StatsEndpoint statsEndpoint =
        new StatsEndpoint(
            gson,
            authService,
            nationService,
            warService,
            playerDirectory,
            config.cors(),
            config.endpoints().stats().requiresAuth());
    FinanceEndpoint financeEndpoint =
        new FinanceEndpoint(
            gson,
            authService,
            nationService,
            treasuryService,
            config.cors(),
            config.endpoints().finance().requiresAuth());
    ModuleDependencyEndpoint dependencyEndpoint =
        new ModuleDependencyEndpoint(
            gson,
            authService,
            dependencyMonitor,
            config.cors(),
            config.endpoints().deps().requiresAuth());
    WarsEndpoint warsEndpoint =
        new WarsEndpoint(
            gson,
            authService,
            warService,
            warServiceImpl,
            nationService,
            config.cors(),
            config.endpoints().wars().requiresAuth());
    PlayersEndpoint playersEndpoint =
        new PlayersEndpoint(
            gson,
            authService,
            playerDirectory,
            playerProfileService,
            nationService,
            config.cors(),
            config.endpoints().players().requiresAuth(),
            relationshipNetwork,
            rankingService);
    EventsEndpoint eventsEndpoint =
        new EventsEndpoint(
            gson,
            authService,
            eventService,
            nationService,
            config.cors(),
            config.endpoints().events().requiresAuth());

    // 健康检查端点
    HttpHandler healthHandler =
        exchange -> {
          if (handleCorsPreflight(exchange)) return;
          writeJson(
              exchange,
              200,
              ApiResponse.success(
                  Map.of(
                      "status", "ok",
                      "version", "1.0.0",
                      "uptime", uptimeMillis())));
        };

    // 根端点
    HttpHandler rootHandler =
        exchange -> {
          if (handleCorsPreflight(exchange)) return;
          Map<String, String> endpoints = new LinkedHashMap<>();
          endpoints.put("health", "/api/v1/health");
          if (config.endpoints().nations().enabled()) {
            endpoints.put("nations", "/api/v1/nations");
          }
          if (config.endpoints().territories().enabled()) {
            endpoints.put("territories", "/api/v1/territories");
          }
          if (config.endpoints().stats().enabled()) {
            endpoints.put("stats", "/api/v1/stats");
          }
          if (config.endpoints().finance().enabled()) {
            endpoints.put("finance", "/api/v1/finance");
          }
          if (config.endpoints().deps().enabled()) {
            endpoints.put("deps", "/api/v1/deps");
          }
          if (config.endpoints().wars().enabled()) {
            endpoints.put("wars", "/api/v1/wars");
          }
          if (config.endpoints().players().enabled()) {
            endpoints.put("players", "/api/v1/players");
          }
          if (config.endpoints().events().enabled()) {
            endpoints.put("events", "/api/v1/events");
          }
          writeJson(
              exchange,
              200,
              ApiResponse.success(
                  Map.of(
                      "name", "StarCore REST API",
                      "version", "1.0.0",
                      "endpoints", endpoints)));
        };

    // 注册路由
    server.createContext("/", rateLimited(exactPath("/", rootHandler)));
    server.createContext("/api/v1/", rateLimited(exactPath("/api/v1/", rootHandler)));
    server.createContext("/api/v1/health", rateLimited(exactPath("/api/v1/health", healthHandler)));
    server.createContext(
        "/api/v1/nations",
        rateLimited(endpoint(config.endpoints().nations(), nationEndpoint::handle)));
    server.createContext(
        "/api/v1/territories",
        rateLimited(endpoint(config.endpoints().territories(), territoryEndpoint::handle)));
    server.createContext(
        "/api/v1/stats", rateLimited(endpoint(config.endpoints().stats(), statsEndpoint::handle)));
    server.createContext(
        "/api/v1/finance",
        rateLimited(endpoint(config.endpoints().finance(), financeEndpoint::handle)));
    server.createContext(
        "/api/v1/deps",
        rateLimited(endpoint(config.endpoints().deps(), dependencyEndpoint::handle)));
    server.createContext(
        "/api/v1/wars", rateLimited(endpoint(config.endpoints().wars(), warsEndpoint::handle)));
    server.createContext(
        "/api/v1/players",
        rateLimited(endpoint(config.endpoints().players(), playersEndpoint::handle)));
    server.createContext(
        "/api/v1/events",
        rateLimited(endpoint(config.endpoints().events(), eventsEndpoint::handle)));
  }

  private HttpHandler endpoint(RestApiConfig.EndpointConfig endpoint, HttpHandler delegate) {
    if (endpoint.enabled()) {
      return delegate;
    }
    return exchange -> {
      if (handleCorsPreflight(exchange)) {
        return;
      }
      writeJson(exchange, 404, ApiResponse.error("ENDPOINT_DISABLED", "This endpoint is disabled"));
    };
  }

  private HttpHandler rateLimited(HttpHandler delegate) {
    return exchange -> {
      if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
        delegate.handle(exchange);
        return;
      }
      String clientKey =
          exchange.getRemoteAddress() == null
              ? "unknown"
              : exchange.getRemoteAddress().getAddress().getHostAddress();
      if (rateLimiter.allow(clientKey)) {
        delegate.handle(exchange);
        return;
      }
      exchange
          .getResponseHeaders()
          .set("Retry-After", Long.toString(rateLimiter.retryAfterSeconds(clientKey)));
      writeJson(exchange, 429, ApiResponse.error("RATE_LIMITED", "Too many requests; retry later"));
    };
  }

  private HttpHandler exactPath(String expectedPath, HttpHandler delegate) {
    return exchange -> {
      if (!expectedPath.equals(exchange.getRequestURI().getPath())) {
        writeJson(exchange, 404, ApiResponse.error("NOT_FOUND", "Endpoint not found"));
        return;
      }
      delegate.handle(exchange);
    };
  }

  private void writeJson(com.sun.net.httpserver.HttpExchange exchange, int status, Object value)
      throws IOException {
    RestApiCors.applyHeaders(exchange, config.cors());
    byte[] body = gson.toJson(value).getBytes(StandardCharsets.UTF_8);
    exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
    exchange.sendResponseHeaders(status, body.length);
    try (var output = exchange.getResponseBody()) {
      output.write(body);
    }
  }

  /** 处理 CORS 预检请求 */
  private boolean handleCorsPreflight(com.sun.net.httpserver.HttpExchange exchange)
      throws IOException {
    return RestApiCors.handlePreflight(exchange, config.cors());
  }

  /** 设置 CORS 头 */
  private void setCorsHeaders(com.sun.net.httpserver.HttpExchange exchange) {
    RestApiCors.applyHeaders(exchange, config.cors());
  }

  /** 获取认证服务 */
  public ApiAuthService getAuthService() {
    return authService;
  }

  /** 获取 Gson 实例 */
  public Gson getGson() {
    return gson;
  }

  /** 检查服务器是否运行 */
  public boolean isRunning() {
    return server != null;
  }

  /** 获取端口 */
  public int getPort() {
    return port;
  }

  private static final class RestApiThreadFactory implements ThreadFactory {
    private final AtomicInteger id = new AtomicInteger();

    @Override
    public Thread newThread(Runnable runnable) {
      Thread thread = new Thread(runnable, "starcore-rest-api-" + id.incrementAndGet());
      thread.setDaemon(true);
      return thread;
    }
  }
}
