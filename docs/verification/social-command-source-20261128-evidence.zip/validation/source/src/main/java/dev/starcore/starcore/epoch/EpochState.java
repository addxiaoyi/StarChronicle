package dev.starcore.starcore.epoch;

/** 纪元状态枚举 定义纪元生命周期的各个阶段 */
public enum EpochState {
  /** 锁定状态：前纪元尚未满足迁移条件，仅允许只读预览 */
  locked("锁定", "前纪元尚未满足迁移条件"),

  /** 准备中：构建结构、生成快照、计算开局变体，后台预生成 */
  preparing("准备中", "构建结构、生成快照、计算开局变体"),

  /** 就绪状态：准备检查通过，等待运营开启 */
  ready("就绪", "准备检查通过，等待运营开启"),

  /** 活跃状态：正式纪元运行，启动事件、参与、归档局部结果 */
  active("活跃", "正式纪元运行"),

  /** 决策待定：公共方案已开放，尚未形成正式选择 */
  decision_pending("决策待定", "公共方案已开放，尚未形成正式选择"),

  /** 解决待定：已选方案，正在落实不可逆事件 */
  resolution_pending("解决待定", "已选方案，正在落实不可逆事件"),

  /** 迁移准备中：生成迁移包与恢复点 */
  migration_preparing("迁移准备中", "生成迁移包与恢复点"),

  /** 迁移中：正式切换纪元状态，仅运行白名单迁移操作 */
  migrating("迁移中", "正式切换纪元状态"),

  /** 验证中：抽检世界、档案、权限与补偿 */
  verification("验证中", "抽检世界、档案、权限与补偿"),

  /** 已归档：纪元正史完成，仅读档案、重复活动、补看 */
  archived("已归档", "纪元正史完成"),

  /** 暂停中：主动暂停，不继续写入 */
  suspended("暂停中", "主动暂停，不继续写入"),

  /** 恢复中：从快照或操作日志恢复 */
  recovery("恢复中", "从快照或操作日志恢复"),

  /** 已取消：未成为正史的测试运行，保留审计摘要 */
  cancelled("已取消", "未成为正史的测试运行"),

  /** 已完成：纪元正常结束 */
  completed("已完成", "纪元正常结束"),

  /** 归档中：正在归档历史记录 */
  archiving("归档中", "正在归档历史记录");

  private final String displayName;
  private final String description;

  EpochState(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  /** 获取状态显示名称 */
  public String getDisplayName() {
    return displayName;
  }

  /** 获取状态描述 */
  public String getDescription() {
    return description;
  }

  /** 检查状态是否为只读状态 */
  public boolean isReadOnly() {
    return this == locked || this == archived || this == cancelled || this == completed;
  }

  /** 检查状态是否为激活态 */
  public boolean isActive() {
    return this == active;
  }

  /** 检查状态是否为决策阶段 */
  public boolean isInDecisionPhase() {
    return this == decision_pending;
  }

  /** 检查状态是否为解决阶段 */
  public boolean isInResolutionPhase() {
    return this == resolution_pending;
  }

  /** 是否处于准备阶段 */
  public boolean isInPreparationPhase() {
    return this == preparing || this == ready || this == migration_preparing;
  }

  /** 是否处于迁移阶段 */
  public boolean isInMigrationPhase() {
    return this == migration_preparing || this == migrating || this == verification;
  }

  /** 是否处于暂停恢复阶段 */
  public boolean isInSuspensionPhase() {
    return this == suspended || this == recovery;
  }

  /** 是否处于终止阶段 */
  public boolean isInTerminationPhase() {
    return this == archived || this == cancelled || this == completed || this == archiving;
  }

  /** 是否为已完成状态 */
  public boolean isCompleted() {
    return this == completed || this == archiving;
  }
}
