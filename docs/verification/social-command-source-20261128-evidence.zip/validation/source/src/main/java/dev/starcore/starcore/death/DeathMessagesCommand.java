package dev.starcore.starcore.death;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

public class DeathMessagesCommand implements CommandExecutor {

  private final DeathMessageService service;

  public DeathMessagesCommand(DeathMessageService service) {
    this.service = service;
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (args.length == 0) {
      return showHelp(sender);
    }

    switch (args[0].toLowerCase()) {
      case "reload" -> handleReload(sender);
      case "status" -> showStatus(sender);
      default -> {
        sender.sendMessage(ChatColor.RED + "未知参数: " + args[0]);
        showHelp(sender);
      }
    }
    return true;
  }

  private void handleReload(CommandSender sender) {
    if (!sender.hasPermission("starcore.deathmessages.reload")) {
      sender.sendMessage(ChatColor.RED + "你没有权限重载死亡消息配置");
      return;
    }
    if (service.reload()) {
      sender.sendMessage(
          ChatColor.GREEN + "死亡消息配置已重载，共 " + service.getAllConfigs().size() + " 种死亡类型");
    } else {
      sender.sendMessage(ChatColor.RED + "重载失败，请检查 death-messages.yml 语法");
    }
  }

  private void showStatus(CommandSender sender) {
    int configured = service.getAllConfigs().size();
    sender.sendMessage(ChatColor.GOLD + "=== 死亡消息系统 ===");
    sender.sendMessage(
        ChatColor.GRAY
            + "启用状态: "
            + (service.isEnabled() ? ChatColor.GREEN + "开" : ChatColor.RED + "关"));
    sender.sendMessage(ChatColor.GRAY + "已加载类型: " + ChatColor.WHITE + configured);
    sender.sendMessage(ChatColor.GRAY + "配置文件: " + ChatColor.WHITE + "death-messages.yml");
  }

  private boolean showHelp(CommandSender sender) {
    sender.sendMessage(ChatColor.GOLD + "=== 死亡消息系统 ===");
    sender.sendMessage(ChatColor.YELLOW + "/deathmessages reload " + ChatColor.GRAY + "- 重载配置");
    sender.sendMessage(ChatColor.YELLOW + "/deathmessages status " + ChatColor.GRAY + "- 查看状态");
    return true;
  }
}
