package dev.starcore.starcore.foundation.economy.transaction;

import java.time.Instant;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Point-in-time health counters for the shared refund retry ledger. */
public record RefundLedgerSummary(
    int totalEntries,
    int dueEntries,
    int manualReviewEntries,
    int unknownOwnerEntries,
    Map<RefundOwner, Integer> ownerCounts,
    Optional<Instant> oldestNextAttemptAt) {
  public RefundLedgerSummary {
    if (totalEntries < 0 || dueEntries < 0 || manualReviewEntries < 0 || unknownOwnerEntries < 0) {
      throw new IllegalArgumentException("refund ledger counters must be non-negative");
    }
    if (dueEntries > totalEntries
        || manualReviewEntries > totalEntries
        || unknownOwnerEntries > totalEntries) {
      throw new IllegalArgumentException("refund ledger counters exceed total entries");
    }
    Objects.requireNonNull(ownerCounts, "ownerCounts");
    Objects.requireNonNull(oldestNextAttemptAt, "oldestNextAttemptAt");
    EnumMap<RefundOwner, Integer> normalized = new EnumMap<>(RefundOwner.class);
    for (RefundOwner owner : RefundOwner.values()) {
      normalized.put(owner, Math.max(0, ownerCounts.getOrDefault(owner, 0)));
    }
    ownerCounts = Collections.unmodifiableMap(normalized);
  }

  public int ownerCount(RefundOwner owner) {
    return ownerCounts.getOrDefault(Objects.requireNonNull(owner, "owner"), 0);
  }
}
