package dev.starcore.starcore.core.monitoring;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 迁移监控服务
 *
 * <p>负责监控数据库迁移和性能指标： - Flyway 迁移耗时和成功率 - Properties 到 SQL 迁移追踪 - 数据库降级事件记录 - 存储操作性能监控
 *
 * <p>提供 Prometheus 格式的指标导出
 */
public class MigrationMonitoringService {

  private final Logger logger;
  // New for each service lifecycle; binds receiver queries to this publisher.
  private final String monitoringInstanceId = UUID.randomUUID().toString();

  // Flyway 迁移指标
  private final AtomicLong flywayMigrationCount = new AtomicLong(0);
  private final AtomicLong flywayMigrationDurationMs = new AtomicLong(0);
  private final AtomicLong flywayMigrationFailures = new AtomicLong(0);

  // Properties 迁移指标
  private final AtomicLong propertiesToSqlSuccess = new AtomicLong(0);
  private final AtomicLong propertiesToSqlFailure = new AtomicLong(0);
  private final AtomicLong propertiesToSqlDurationMs = new AtomicLong(0);

  // 数据库降级指标
  private final AtomicLong databaseDegradationEvents = new AtomicLong(0);

  // 模块级别的性能指标
  private final ConcurrentHashMap<String, ModuleMetrics> moduleMetrics = new ConcurrentHashMap<>();

  // 可选的模块级 Prometheus 来源。按稳定 ID 注册，避免重载时重复输出同一来源。
  private final ConcurrentHashMap<String, PrometheusMetricsSource> prometheusSources =
      new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, AtomicLong> prometheusSourceFailures =
      new ConcurrentHashMap<>();

  // 可选外部 Prometheus 接收器。未配置时发布操作明确返回未配置，不向外发起网络请求。
  private final Object externalMetricsReceiverLock = new Object();
  private MetricsReceiver externalMetricsReceiver;
  private long externalMetricsReceiverGeneration;
  private final AtomicLong externalMetricsDelivered = new AtomicLong(0);
  private final AtomicLong externalMetricsFailures = new AtomicLong(0);

  // 告警阈值配置
  private final AlertThresholds thresholds;

  public MigrationMonitoringService(Logger logger) {
    this(logger, AlertThresholds.defaults());
  }

  public MigrationMonitoringService(Logger logger, AlertThresholds thresholds) {
    this.logger = logger;
    this.thresholds = thresholds;
  }

  /**
   * Registers or replaces one additional Prometheus source.
   *
   * <p>The returned handle only removes the source instance it registered. This makes a stale
   * handle from a reload unable to remove a newer source with the same ID.
   */
  public AutoCloseable registerPrometheusSource(String sourceId, PrometheusMetricsSource source) {
    String id = requirePrometheusSourceId(sourceId);
    PrometheusMetricsSource replacement = Objects.requireNonNull(source, "source");
    PrometheusMetricsSource previous = prometheusSources.put(id, replacement);
    if (previous != replacement) {
      prometheusSourceFailures.remove(id);
    }
    return () -> unregisterPrometheusSource(id, replacement);
  }

  /** Removes the current source for the supplied ID, if one is registered. */
  public boolean unregisterPrometheusSource(String sourceId) {
    String id = requirePrometheusSourceId(sourceId);
    PrometheusMetricsSource removed = prometheusSources.remove(id);
    if (removed != null) {
      prometheusSourceFailures.remove(id);
      return true;
    }
    return false;
  }

  /** Returns the number of currently registered additional Prometheus sources. */
  public int getPrometheusSourceCount() {
    return prometheusSources.size();
  }

  /** Identifies this publisher lifecycle, including registered business metric sources. */
  public String getMonitoringInstanceId() {
    return monitoringInstanceId;
  }

  private boolean unregisterPrometheusSource(String sourceId, PrometheusMetricsSource expected) {
    if (!prometheusSources.remove(sourceId, expected)) {
      return false;
    }
    prometheusSourceFailures.remove(sourceId);
    return true;
  }

  /**
   * 记录 Flyway 迁移
   *
   * @param scriptsExecuted 执行的脚本数量
   * @param durationMs 迁移耗时（毫秒）
   * @param success 是否成功
   */
  public void recordFlywayMigration(int scriptsExecuted, long durationMs, boolean success) {
    requireNonNegative(scriptsExecuted, "scriptsExecuted");
    requireNonNegative(durationMs, "durationMs");
    flywayMigrationCount.incrementAndGet();
    flywayMigrationDurationMs.addAndGet(durationMs);

    if (!success) {
      flywayMigrationFailures.incrementAndGet();
    }

    logger.info(
        String.format(
            "[监控] Flyway 迁移%s: %d 个脚本, 耗时 %d ms",
            success ? "完成" : "失败", scriptsExecuted, durationMs));

    // 超过阈值发出告警
    if (durationMs > thresholds.flywayMigrationSlowMs) {
      alertSlowMigration(scriptsExecuted, durationMs);
    }

    if (!success) {
      alertMigrationFailure("Flyway", "迁移执行失败");
    }
  }

  /**
   * 记录 Properties 到 SQL 迁移
   *
   * @param module 模块名称
   * @param success 是否成功
   * @param durationMs 迁移耗时（毫秒）
   * @param recordCount 迁移的记录数
   */
  public void recordPropertiesToSqlMigration(
      String module, boolean success, long durationMs, int recordCount) {
    requireModule(module);
    requireNonNegative(durationMs, "durationMs");
    requireNonNegative(recordCount, "recordCount");
    if (success) {
      propertiesToSqlSuccess.incrementAndGet();
      propertiesToSqlDurationMs.addAndGet(durationMs);

      logger.info(
          String.format(
              "[监控] 模块 %s Properties 迁移成功: %d 条记录, 耗时 %d ms", module, recordCount, durationMs));
    } else {
      propertiesToSqlFailure.incrementAndGet();

      logger.warning(String.format("[监控] 模块 %s Properties 迁移失败", module));

      alertMigrationFailure(module, "Properties 到 SQL 迁移失败");
    }
  }

  /**
   * 记录数据库降级事件
   *
   * @param module 模块名称
   * @param reason 降级原因
   */
  public void recordDatabaseDegradation(String module, String reason) {
    requireModule(module);
    Objects.requireNonNull(reason, "reason");
    databaseDegradationEvents.incrementAndGet();

    logger.log(Level.SEVERE, String.format("[监控] 数据库降级到 Properties: 模块=%s, 原因=%s", module, reason));

    // 立即告警 - 这是严重事件
    alertDatabaseDegradation(module, reason);
  }

  /**
   * 记录存储操作性能
   *
   * @param module 模块名称
   * @param operation 操作类型 ("load" 或 "save")
   * @param durationMs 操作耗时（毫秒）
   * @param success 是否成功
   */
  public void recordStorageOperation(
      String module, String operation, long durationMs, boolean success) {
    requireModule(module);
    requireNonNegative(durationMs, "durationMs");
    if (!"load".equals(operation) && !"save".equals(operation)) {
      throw new IllegalArgumentException("operation must be load or save");
    }
    ModuleMetrics metrics = moduleMetrics.computeIfAbsent(module, k -> new ModuleMetrics());

    if ("load".equals(operation)) {
      metrics.recordLoad(durationMs, success);
    } else if ("save".equals(operation)) {
      metrics.recordSave(durationMs, success);
    }

    // 性能告警
    if (durationMs > thresholds.storageOperationSlowMs) {
      alertSlowOperation(module, operation, durationMs);
    }

    // 失败告警
    if (!success) {
      logger.warning(
          String.format("[监控] 存储操作失败: 模块=%s, 操作=%s, 耗时=%d ms", module, operation, durationMs));
    }
  }

  /** 获取监控报告 */
  public MonitoringReport getReport() {
    Map<String, ModuleMetrics> snapshots = new HashMap<>();
    moduleMetrics.forEach((module, metrics) -> snapshots.put(module, metrics.snapshot()));
    return new MonitoringReport(
        flywayMigrationCount.get(),
        flywayMigrationDurationMs.get(),
        flywayMigrationFailures.get(),
        propertiesToSqlSuccess.get(),
        propertiesToSqlFailure.get(),
        propertiesToSqlDurationMs.get(),
        databaseDegradationEvents.get(),
        snapshots);
  }

  /** Registers the receiver used by the explicit external metrics publish operation. */
  public void setExternalMetricsReceiver(MetricsReceiver receiver) {
    MetricsReceiver replacement = Objects.requireNonNull(receiver, "receiver");
    MetricsReceiver previous;
    synchronized (externalMetricsReceiverLock) {
      previous = externalMetricsReceiver;
      externalMetricsReceiver = replacement;
      externalMetricsReceiverGeneration++;
    }
    closeReceiver(previous, replacement);
  }

  /** Removes the external receiver and prevents subsequent network delivery. */
  public void clearExternalMetricsReceiver() {
    MetricsReceiver previous;
    synchronized (externalMetricsReceiverLock) {
      previous = externalMetricsReceiver;
      externalMetricsReceiver = null;
      externalMetricsReceiverGeneration++;
    }
    closeReceiver(previous, null);
  }

  public boolean hasExternalMetricsReceiver() {
    synchronized (externalMetricsReceiverLock) {
      return externalMetricsReceiver != null;
    }
  }

  public long getExternalMetricsDelivered() {
    return externalMetricsDelivered.get();
  }

  public long getExternalMetricsFailures() {
    return externalMetricsFailures.get();
  }

  /**
   * Publishes one complete Prometheus snapshot to the configured receiver.
   *
   * <p>No receiver is contacted when none is configured. Receiver errors are converted to a stable
   * result code so a monitoring outage cannot make a gameplay or database operation look
   * successful.
   */
  public MetricsDeliveryResult publishPrometheusMetrics() {
    MetricsReceiver receiver;
    long receiverGeneration;
    synchronized (externalMetricsReceiverLock) {
      receiver = externalMetricsReceiver;
      receiverGeneration = externalMetricsReceiverGeneration;
    }
    long completedAt = System.currentTimeMillis();
    if (receiver == null) {
      return new MetricsDeliveryResult(false, "METRICS_RECEIVER_UNCONFIGURED", 0, completedAt);
    }
    String payload = exportPrometheusMetrics();
    int payloadBytes = payload.getBytes(StandardCharsets.UTF_8).length;
    try {
      receiver.publish(payload);
      synchronized (externalMetricsReceiverLock) {
        if (externalMetricsReceiver != receiver
            || externalMetricsReceiverGeneration != receiverGeneration) {
          return new MetricsDeliveryResult(
              false, "METRICS_RECEIVER_REPLACED", payloadBytes, System.currentTimeMillis());
        }
        externalMetricsDelivered.incrementAndGet();
        logger.info(
            "METRICS_DELIVERED bytes=" + payloadBytes + " instance=" + monitoringInstanceId);
      }
      return new MetricsDeliveryResult(
          true, "METRICS_DELIVERED", payloadBytes, System.currentTimeMillis());
    } catch (Exception exception) {
      synchronized (externalMetricsReceiverLock) {
        if (externalMetricsReceiver != receiver
            || externalMetricsReceiverGeneration != receiverGeneration) {
          return new MetricsDeliveryResult(
              false, "METRICS_RECEIVER_REPLACED", payloadBytes, System.currentTimeMillis());
        }
        externalMetricsFailures.incrementAndGet();
      }
      logger.log(
          Level.WARNING,
          "METRICS_DELIVERY_FAILED code=METRICS_RECEIVER_FAILED bytes=" + payloadBytes,
          exception);
      return new MetricsDeliveryResult(
          false, "METRICS_RECEIVER_FAILED", payloadBytes, System.currentTimeMillis());
    }
  }

  private void closeReceiver(MetricsReceiver previous, MetricsReceiver replacement) {
    if (previous == null || previous == replacement) {
      return;
    }
    try {
      previous.close();
    } catch (RuntimeException closeFailure) {
      logger.log(Level.WARNING, "METRICS_RECEIVER_CLOSE_FAILED", closeFailure);
    }
  }

  /** Publishes without blocking the caller on a supplied executor. */
  public CompletableFuture<MetricsDeliveryResult> publishPrometheusMetricsAsync(Executor executor) {
    Objects.requireNonNull(executor, "executor");
    CompletableFuture<MetricsDeliveryResult> result = new CompletableFuture<>();
    try {
      executor.execute(
          () -> {
            try {
              result.complete(publishPrometheusMetrics());
            } catch (Throwable failure) {
              result.completeExceptionally(failure);
            }
          });
    } catch (RuntimeException rejection) {
      externalMetricsFailures.incrementAndGet();
      logger.log(Level.WARNING, "METRICS_DELIVERY_FAILED code=METRICS_PUBLISH_REJECTED", rejection);
      result.complete(
          new MetricsDeliveryResult(
              false, "METRICS_PUBLISH_REJECTED", 0, System.currentTimeMillis()));
    }
    return result;
  }

  /** 导出 Prometheus 格式指标 */
  public String exportPrometheusMetrics() {
    StringBuilder metrics = new StringBuilder();
    appendMetricWithLabel(
        metrics,
        "starcore_monitoring_instance_info",
        "gauge",
        "Monitoring service lifecycle identifier",
        "instance_id",
        monitoringInstanceId,
        1);

    // Flyway 迁移指标
    appendMetric(
        metrics,
        "starcore_flyway_migrations_total",
        "counter",
        "Flyway 迁移总次数",
        flywayMigrationCount.get());

    appendMetric(
        metrics,
        "starcore_flyway_migrations_duration_ms_total",
        "counter",
        "Flyway 迁移总耗时（毫秒）",
        flywayMigrationDurationMs.get());

    appendMetric(
        metrics,
        "starcore_flyway_migrations_failures_total",
        "counter",
        "Flyway 迁移失败次数",
        flywayMigrationFailures.get());

    // Properties 迁移指标
    appendMetric(
        metrics,
        "starcore_properties_migrations_success_total",
        "counter",
        "Properties 迁移成功次数",
        propertiesToSqlSuccess.get());

    appendMetric(
        metrics,
        "starcore_properties_migrations_failure_total",
        "counter",
        "Properties 迁移失败次数",
        propertiesToSqlFailure.get());

    appendMetric(
        metrics,
        "starcore_properties_migrations_duration_ms_total",
        "counter",
        "Properties 迁移总耗时（毫秒）",
        propertiesToSqlDurationMs.get());

    // 数据库降级指标
    appendMetric(
        metrics,
        "starcore_database_degradations_total",
        "counter",
        "数据库降级事件总数",
        databaseDegradationEvents.get());

    appendMetric(
        metrics,
        "starcore_external_metrics_deliveries_total",
        "counter",
        "外部指标接收成功次数",
        externalMetricsDelivered.get());

    appendMetric(
        metrics,
        "starcore_external_metrics_failures_total",
        "counter",
        "外部指标接收失败次数",
        externalMetricsFailures.get());

    List<Map.Entry<String, PrometheusMetricsSource>> sources =
        new ArrayList<>(prometheusSources.entrySet());
    sources.sort(Comparator.comparing(Map.Entry::getKey));
    for (Map.Entry<String, PrometheusMetricsSource> entry : sources) {
      try {
        appendSource(metrics, entry.getValue().export());
      } catch (Exception exception) {
        if (prometheusSources.get(entry.getKey()) != entry.getValue()) {
          continue;
        }
        prometheusSourceFailures
            .computeIfAbsent(entry.getKey(), ignored -> new AtomicLong())
            .incrementAndGet();
        logger.log(
            Level.WARNING, "PROMETHEUS_SOURCE_EXPORT_FAILED source=" + entry.getKey(), exception);
      }
    }

    List<Map.Entry<String, AtomicLong>> sourceFailures =
        new ArrayList<>(prometheusSourceFailures.entrySet());
    sourceFailures.sort(Comparator.comparing(Map.Entry::getKey));
    for (Map.Entry<String, AtomicLong> entry : sourceFailures) {
      if (!prometheusSources.containsKey(entry.getKey())) {
        continue;
      }
      appendMetricWithLabel(
          metrics,
          "starcore_prometheus_source_export_failures_total",
          "counter",
          "Prometheus 来源导出失败次数",
          "source",
          entry.getKey(),
          entry.getValue().get());
    }

    // 模块级别指标
    List<Map.Entry<String, ModuleMetrics>> modules = new ArrayList<>(moduleMetrics.entrySet());
    modules.sort(Comparator.comparing(Map.Entry::getKey));
    for (Map.Entry<String, ModuleMetrics> entry : modules) {
      String module = entry.getKey();
      ModuleMetrics m = entry.getValue();

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_total",
          "counter",
          "存储操作总次数",
          "module",
          module,
          "operation",
          "load",
          m.loadCount.get());

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_total",
          "counter",
          "存储操作总次数",
          "module",
          module,
          "operation",
          "save",
          m.saveCount.get());

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_duration_ms_total",
          "counter",
          "存储操作总耗时（毫秒）",
          "module",
          module,
          "operation",
          "load",
          m.loadDurationMs.get());

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_duration_ms_total",
          "counter",
          "存储操作总耗时（毫秒）",
          "module",
          module,
          "operation",
          "save",
          m.saveDurationMs.get());

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_failures_total",
          "counter",
          "存储操作失败次数",
          "module",
          module,
          "operation",
          "load",
          m.loadFailures.get());

      appendMetricWithLabel(
          metrics,
          "starcore_storage_operations_failures_total",
          "counter",
          "存储操作失败次数",
          "module",
          module,
          "operation",
          "save",
          m.saveFailures.get());
    }

    return metrics.toString();
  }

  /** 重置所有指标（仅用于测试） */
  public void resetMetrics() {
    flywayMigrationCount.set(0);
    flywayMigrationDurationMs.set(0);
    flywayMigrationFailures.set(0);
    propertiesToSqlSuccess.set(0);
    propertiesToSqlFailure.set(0);
    propertiesToSqlDurationMs.set(0);
    databaseDegradationEvents.set(0);
    externalMetricsDelivered.set(0);
    externalMetricsFailures.set(0);
    prometheusSourceFailures.clear();
    moduleMetrics.clear();
  }

  // ========== 告警方法 ==========

  private void alertSlowMigration(int scriptsExecuted, long durationMs) {
    logger.log(
        Level.WARNING,
        String.format(
            "[告警] Flyway 迁移缓慢: %d 个脚本耗时 %d ms (阈值: %d ms)",
            scriptsExecuted, durationMs, thresholds.flywayMigrationSlowMs));
  }

  private void alertMigrationFailure(String source, String reason) {
    logger.log(Level.SEVERE, String.format("[告警] 数据库迁移失败: 来源=%s, 原因=%s", source, reason));
  }

  private void alertDatabaseDegradation(String module, String reason) {
    logger.log(
        Level.SEVERE,
        String.format("[告警] 数据库降级事件: 模块=%s, 原因=%s - 系统已降级到 Properties 文件存储", module, reason));
  }

  private void alertSlowOperation(String module, String operation, long durationMs) {
    logger.log(
        Level.WARNING,
        String.format(
            "[告警] 存储操作缓慢: 模块=%s, 操作=%s, 耗时=%d ms (阈值: %d ms)",
            module, operation, durationMs, thresholds.storageOperationSlowMs));
  }

  // ========== 辅助方法 ==========

  private void appendMetric(StringBuilder sb, String name, String type, String help, long value) {
    sb.append("# HELP ").append(name).append(" ").append(escapeHelp(help)).append("\n");
    sb.append("# TYPE ").append(name).append(" ").append(type).append("\n");
    sb.append(name).append(" ").append(value).append("\n\n");
  }

  private void appendMetricWithLabel(
      StringBuilder sb,
      String name,
      String type,
      String help,
      String label1Key,
      String label1Value,
      String label2Key,
      String label2Value,
      long value) {
    // 只在第一次输出时添加 HELP 和 TYPE
    if (!sb.toString().contains("# TYPE " + name + " ")) {
      sb.append("# HELP ").append(name).append(" ").append(escapeHelp(help)).append("\n");
      sb.append("# TYPE ").append(name).append(" ").append(type).append("\n");
    }

    sb.append(name)
        .append("{")
        .append(label1Key)
        .append("=\"")
        .append(escapeLabel(label1Value))
        .append("\",")
        .append(label2Key)
        .append("=\"")
        .append(escapeLabel(label2Value))
        .append("\"")
        .append("} ")
        .append(value)
        .append("\n");
  }

  private void appendMetricWithLabel(
      StringBuilder sb,
      String name,
      String type,
      String help,
      String labelKey,
      String labelValue,
      long value) {
    if (!sb.toString().contains("# TYPE " + name + " ")) {
      sb.append("# HELP ").append(name).append(" ").append(escapeHelp(help)).append("\n");
      sb.append("# TYPE ").append(name).append(" ").append(type).append("\n");
    }

    sb.append(name)
        .append("{")
        .append(labelKey)
        .append("=\"")
        .append(escapeLabel(labelValue))
        .append("\"} ")
        .append(value)
        .append("\n");
  }

  private static void appendSource(StringBuilder metrics, String sourceOutput) {
    if (sourceOutput == null || sourceOutput.isBlank()) {
      return;
    }
    metrics.append(sourceOutput);
    if (metrics.charAt(metrics.length() - 1) != '\n') {
      metrics.append('\n');
    }
    if (metrics.length() < 2 || metrics.charAt(metrics.length() - 2) != '\n') {
      metrics.append('\n');
    }
  }

  private static String escapeHelp(String value) {
    return value.replace("\\", "\\\\").replace("\n", "\\n");
  }

  private static String escapeLabel(String value) {
    return value.replace("\\", "\\\\").replace("\n", "\\n").replace("\"", "\\\"");
  }

  private static String requirePrometheusSourceId(String sourceId) {
    if (sourceId == null || !sourceId.matches("[a-zA-Z0-9_.-]{1,64}")) {
      throw new IllegalArgumentException(
          "Prometheus source ID must use letters, numbers, dot, underscore, or dash");
    }
    return sourceId;
  }

  private static void requireModule(String module) {
    if (module == null || module.isBlank()) {
      throw new IllegalArgumentException("module must not be blank");
    }
  }

  private static void requireNonNegative(long value, String name) {
    if (value < 0) {
      throw new IllegalArgumentException(name + " must not be negative");
    }
  }

  /** Result of one external metrics delivery attempt. */
  public record MetricsDeliveryResult(
      boolean delivered, String code, int payloadBytes, long completedAtEpochMs) {}

  /** 模块性能指标 */
  public static class ModuleMetrics {
    private final AtomicLong loadCount = new AtomicLong(0);
    private final AtomicLong loadDurationMs = new AtomicLong(0);
    private final AtomicLong loadFailures = new AtomicLong(0);

    private final AtomicLong saveCount = new AtomicLong(0);
    private final AtomicLong saveDurationMs = new AtomicLong(0);
    private final AtomicLong saveFailures = new AtomicLong(0);

    public void recordLoad(long durationMs, boolean success) {
      loadCount.incrementAndGet();
      loadDurationMs.addAndGet(durationMs);
      if (!success) {
        loadFailures.incrementAndGet();
      }
    }

    public void recordSave(long durationMs, boolean success) {
      saveCount.incrementAndGet();
      saveDurationMs.addAndGet(durationMs);
      if (!success) {
        saveFailures.incrementAndGet();
      }
    }

    public long getLoadCount() {
      return loadCount.get();
    }

    public long getLoadDurationMs() {
      return loadDurationMs.get();
    }

    public long getLoadFailures() {
      return loadFailures.get();
    }

    public long getSaveCount() {
      return saveCount.get();
    }

    public long getSaveDurationMs() {
      return saveDurationMs.get();
    }

    public long getSaveFailures() {
      return saveFailures.get();
    }

    public double getAverageLoadTimeMs() {
      long count = loadCount.get();
      return count > 0 ? (double) loadDurationMs.get() / count : 0.0;
    }

    public double getAverageSaveTimeMs() {
      long count = saveCount.get();
      return count > 0 ? (double) saveDurationMs.get() / count : 0.0;
    }

    private ModuleMetrics snapshot() {
      ModuleMetrics snapshot = new ModuleMetrics();
      snapshot.loadCount.set(loadCount.get());
      snapshot.loadDurationMs.set(loadDurationMs.get());
      snapshot.loadFailures.set(loadFailures.get());
      snapshot.saveCount.set(saveCount.get());
      snapshot.saveDurationMs.set(saveDurationMs.get());
      snapshot.saveFailures.set(saveFailures.get());
      return snapshot;
    }
  }

  /** 告警阈值配置 */
  public static class AlertThresholds {
    public final long flywayMigrationSlowMs;
    public final long storageOperationSlowMs;

    public AlertThresholds(long flywayMigrationSlowMs, long storageOperationSlowMs) {
      this.flywayMigrationSlowMs = flywayMigrationSlowMs;
      this.storageOperationSlowMs = storageOperationSlowMs;
    }

    public static AlertThresholds defaults() {
      return new AlertThresholds(
          30000, // Flyway 迁移超过 30 秒告警
          5000 // 存储操作超过 5 秒告警
          );
    }
  }
}
