package dev.starcore.starcore.foundation.animation;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Original-owner visual feedback using Paper's hurt animation, sound and player-local particles.
 */
public final class ScreenShakeManager implements org.bukkit.event.Listener {
  private final Plugin plugin;

  // 震动类型枚举
  public enum ShakeType {
    // 基础震动
    LIGHT("轻微震动", 0.3f, 200, 0.05f, 3),
    MEDIUM("中等震动", 0.5f, 350, 0.08f, 5),
    HEAVY("剧烈震动", 0.8f, 500, 0.12f, 8),

    // 爆炸相关
    EXPLOSION("爆炸", 0.7f, 400, 0.15f, 6),
    NUCLEAR("核爆", 1.0f, 800, 0.25f, 12),
    TNT("TNT爆炸", 0.75f, 450, 0.18f, 7),
    CREEPER("苦力怕爆炸", 0.65f, 380, 0.14f, 5),
    BED_EXPLOSION("床爆炸(下界)", 0.7f, 420, 0.16f, 6),
    RESPAWN_ANCHOR("重生锚充能", 0.6f, 600, 0.1f, 8),

    // 战斗相关
    HIT("打击", 0.4f, 150, 0.06f, 2),
    CRITICAL_HIT("暴击", 0.6f, 250, 0.1f, 4),
    DEATH("死亡", 0.5f, 400, 0.08f, 5),
    COMBO("连击", 0.35f, 180, 0.06f, 3),
    PARRY("格挡", 0.45f, 200, 0.07f, 3),
    DODGE("闪避", 0.3f, 150, 0.05f, 2),

    // 地震
    EARTHQUAKE("地震", 0.9f, 1200, 0.2f, 15),
    AFTershock("余震", 0.4f, 300, 0.1f, 4),
    LANDSLIDE("滑坡", 0.6f, 500, 0.12f, 6),

    // 魔法/特效
    MAGIC("魔法", 0.3f, 250, 0.05f, 3),
    LIGHTNING("雷电", 0.6f, 200, 0.12f, 3),
    PORTAL("传送门", 0.4f, 500, 0.06f, 4),
    ENCHANT("附魔", 0.35f, 350, 0.05f, 4),
    CURSE("诅咒", 0.5f, 400, 0.08f, 5),

    // 国家/战争
    WAR_DECLARE("宣战", 0.8f, 600, 0.15f, 7),
    VICTORY("胜利", 0.5f, 400, 0.08f, 5),
    DEFEAT("战败", 0.7f, 500, 0.12f, 6),
    SIEGE("围攻", 0.6f, 800, 0.1f, 8),
    SURRENDER("投降", 0.45f, 350, 0.07f, 4),
    SCOUT("侦察", 0.25f, 200, 0.04f, 2),

    // 警报/通知
    ACHIEVEMENT("成就", 0.3f, 300, 0.04f, 3),
    RARE_FIND("稀有发现", 0.35f, 250, 0.05f, 3),
    ALERT("警报", 0.5f, 400, 0.08f, 5),
    EARTHQUAKE_ALERT("紧急警报", 0.8f, 600, 0.15f, 8),
    INTRUSION("入侵警报", 0.7f, 500, 0.12f, 6),
    BORDER_WARNING("边界警告", 0.4f, 300, 0.06f, 4),

    // 交互
    BUTTON("按钮", 0.15f, 100, 0.02f, 1),
    TELEPORT("传送", 0.4f, 300, 0.06f, 3),
    BEACON("信标激活", 0.25f, 200, 0.04f, 2),
    CRAFT("合成", 0.2f, 150, 0.03f, 2),
    TRADE("交易", 0.25f, 200, 0.04f, 2),

    // 自然/环境
    THUNDER("雷暴", 0.65f, 600, 0.1f, 6),
    STORM("暴风雨", 0.5f, 800, 0.08f, 8),
    RAIN("下雨", 0.2f, 300, 0.03f, 4),
    VOLCANIC("火山喷发", 0.9f, 1000, 0.2f, 10),

    // 建筑/破坏
    BUILD("建造", 0.2f, 150, 0.03f, 2),
    DESTROY("破坏", 0.4f, 250, 0.06f, 3),
    STRUCTURE("结构变化", 0.5f, 400, 0.08f, 5),

    // 特殊事件
    RARE_SPAWN("稀有生物生成", 0.6f, 500, 0.1f, 5),
    BOSS_APPEAR("Boss出现", 0.8f, 700, 0.15f, 8),
    BOSS_DEATH("Boss死亡", 1.0f, 1000, 0.2f, 10),
    DRAGON_FIGHT("龙战斗", 0.75f, 600, 0.12f, 7),
    WITHER_SPAWN("凋零生成", 0.85f, 800, 0.18f, 9),

    // PvP 战斗
    PVP_START("PvP开始", 0.5f, 400, 0.08f, 5),
    FLAG_CAPTURE("夺旗", 0.55f, 350, 0.09f, 4),
    BASE_ATTACK("基地攻击", 0.65f, 450, 0.11f, 6),
    RANK_UP("段位提升", 0.7f, 600, 0.12f, 7);

    private final String displayName;
    private final float intensity; // 震动强度 (0-1)
    private final int duration; // 持续时间 (ms)
    private final float shakeAmplitude; // 晃动幅度
    private final int frequency; // 震动频率

    ShakeType(
        String displayName, float intensity, int duration, float shakeAmplitude, int frequency) {
      this.displayName = displayName;
      this.intensity = intensity;
      this.duration = duration;
      this.shakeAmplitude = shakeAmplitude;
      this.frequency = frequency;
    }

    public String getDisplayName() {
      return displayName;
    }

    public float getIntensity() {
      return intensity;
    }

    public int getDuration() {
      return duration;
    }

    public float getShakeAmplitude() {
      return shakeAmplitude;
    }

    public int getFrequency() {
      return frequency;
    }
  }

  // 震动配置
  public record ShakeConfig(
      float intensity,
      int durationMs,
      float amplitude,
      int frequency,
      boolean cameraShake,
      boolean soundEnabled,
      boolean particleEnabled) {
    public static ShakeConfig from(ShakeType type) {
      return new ShakeConfig(
          type.getIntensity(),
          type.getDuration(),
          type.getShakeAmplitude(),
          type.getFrequency(),
          true, // 使用视觉受伤动画，不传送或更改玩家视角
          true, // 默认播放声音
          type == ShakeType.EXPLOSION || type == ShakeType.NUCLEAR || type == ShakeType.LIGHTNING);
    }

    public static ShakeConfig custom(
        float intensity, int durationMs, float amplitude, int frequency) {
      return new ShakeConfig(intensity, durationMs, amplitude, frequency, true, true, false);
    }
  }

  private final AnimationTaskTracker tasks;
  private final java.util.function.LongSupplier nanoTime;
  private final Map<UUID, ShakeState> activeShakes = new ConcurrentHashMap<>();
  private final Map<UUID, PlayerShakePreferences> playerPrefs = new ConcurrentHashMap<>();
  private final Set<GlobalWork> globalWork = new HashSet<>();
  private volatile boolean closed;
  private volatile long generation;

  private static final class ShakeState {
    final Player player;
    final org.bukkit.World world;
    final ShakeConfig config;
    final long started;
    BukkitTask task;
    long ticks;

    ShakeState(Player player, ShakeConfig config, long started) {
      this.player = player;
      this.started = started;
      this.world = player.getWorld();
      this.config = config;
    }

    boolean expired(long now) {
      return now - started >= (long) config.durationMs() * 1_000_000;
    }
  }

  private static final class PlayerShakePreferences {
    boolean enabled = true;
    float intensityMultiplier = 1;
    final Set<ShakeType> disabledTypes = EnumSet.noneOf(ShakeType.class);
  }

  private static final class GlobalWork {
    io.papermc.paper.threadedregions.scheduler.ScheduledTask task;
  }

  public ScreenShakeManager(Plugin plugin) {
    this(plugin, System::nanoTime);
  }

  ScreenShakeManager(Plugin plugin, java.util.function.LongSupplier nanoTime) {
    this.plugin = Objects.requireNonNull(plugin);
    this.nanoTime = nanoTime;
    tasks = new AnimationTaskTracker(plugin);
  }

  public void shake(Player player, ShakeType type) {
    shake(player, type, ShakeConfig.from(type));
  }

  public void shake(Player player, ShakeType type, ShakeConfig config) {
    Objects.requireNonNull(type);
    Objects.requireNonNull(config);
    if (!Float.isFinite(config.intensity())
        || config.intensity() < 0
        || !Float.isFinite(config.amplitude())
        || config.amplitude() < 0
        || config.durationMs() < 1
        || config.durationMs() > 60_000
        || config.frequency() < 1
        || config.frequency() > 20)
      throw new IllegalArgumentException("Invalid screen feedback configuration");
    tasks.execute(player, () -> startOwned(player, type, config));
  }

  private synchronized void startOwned(Player player, ShakeType type, ShakeConfig config) {
    if (closed) return;
    PlayerShakePreferences prefs =
        playerPrefs.computeIfAbsent(player.getUniqueId(), ignored -> new PlayerShakePreferences());
    if (!prefs.enabled || prefs.disabledTypes.contains(type) || prefs.intensityMultiplier == 0)
      return;
    float intensity = Math.min(2f, config.intensity() * prefs.intensityMultiplier);
    if (intensity == 0) return;
    ShakeConfig effective =
        new ShakeConfig(
            intensity,
            config.durationMs(),
            config.amplitude(),
            config.frequency(),
            config.cameraShake(),
            config.soundEnabled(),
            config.particleEnabled());
    ShakeState previous = activeShakes.get(player.getUniqueId());
    if (previous != null) {
      if (previous.player == player
          && !previous.expired(nanoTime.getAsLong())
          && previous.config.intensity() >= intensity) return;
      retire(previous);
    }
    ShakeState state = new ShakeState(player, effective, nanoTime.getAsLong());
    activeShakes.put(player.getUniqueId(), state);
    try {
      if (effective.soundEnabled()) playShakeSound(player, type);
      if (effective.particleEnabled()) playShakeParticles(player, type);
      state.task = tasks.runTaskTimer(player, handle -> frame(state, handle), 1, 1);
      tasks.onRetired(state.task, () -> activeShakes.remove(player.getUniqueId(), state));
    } catch (RuntimeException | Error failure) {
      retire(state);
      throw failure;
    }
  }

  private synchronized void frame(ShakeState state, BukkitTask task) {
    state.task = task;
    if (closed
        || activeShakes.get(state.player.getUniqueId()) != state
        || state.player.getWorld() != state.world
        || state.expired(nanoTime.getAsLong())
        || state.ticks * 50 >= state.config.durationMs()) {
      task.cancel();
      activeShakes.remove(state.player.getUniqueId(), state);
      return;
    }
    long tick = state.ticks++;
    if (state.config.cameraShake() && tick % Math.max(1, 20 / state.config.frequency()) == 0) {
      // Supported visual-only hurt animation. It neither moves the player nor changes health.
      // Paper exposes a direction, not arbitrary camera displacement or amplitude.
      state.player.playHurtAnimation(tick % 2 == 0 ? 90f : 270f);
    }
  }

  private void retire(ShakeState state) {
    activeShakes.remove(state.player.getUniqueId(), state);
    if (state.task != null) state.task.cancel();
  }

  /** Captures recipients globally, then runs feedback on each original player's owner. */
  public void forEachPlayer(java.util.function.Consumer<Player> action) {
    GlobalWork work = new GlobalWork();
    long epoch;
    synchronized (this) {
      if (closed || !plugin.isEnabled()) return;
      epoch = generation;
      globalWork.add(work);
    }
    try {
      var handle =
          plugin
              .getServer()
              .getGlobalRegionScheduler()
              .run(
                  plugin,
                  ignored -> {
                    synchronized (this) {
                      if (!globalWork.remove(work) || closed || !plugin.isEnabled()) return;
                    }
                    for (Player player : List.copyOf(plugin.getServer().getOnlinePlayers()))
                      tasks.execute(
                          player,
                          () -> {
                            if (!closed && generation == epoch) action.accept(player);
                          });
                  });
      synchronized (this) {
        work.task = handle;
        if (!globalWork.contains(work) && handle != null) handle.cancel();
        if (handle == null) globalWork.remove(work);
      }
    } catch (RuntimeException | Error failure) {
      synchronized (this) {
        globalWork.remove(work);
      }
      throw failure;
    }
  }

  public void shakeAll(ShakeType type) {
    forEachPlayer(player -> shake(player, type));
  }

  public void shakeWithMessage(Player player, ShakeType type, String message) {
    tasks.execute(
        player,
        () -> {
          if (closed) return;
          shake(player, type);
          player.sendActionBar(Component.text(message, NamedTextColor.RED));
        });
  }

  public void shakeAllWithMessage(ShakeType type, String message) {
    forEachPlayer(player -> shakeWithMessage(player, type, message));
  }

  public void shakeAt(ShakeType type, Location location, double radius) {
    if (location == null || location.getWorld() == null) return;
    if (!Double.isFinite(radius) || radius < 0)
      throw new IllegalArgumentException("Invalid radius");
    Location origin = location.clone();
    forEachPlayer(
        player -> {
          if (player.getWorld() == origin.getWorld()
              && player.getLocation().distanceSquared(origin) <= radius * radius)
            shake(player, type);
        });
  }

  public void runLater(Player player, Runnable action, long ticks) {
    tasks.runTaskLater(
        player,
        () -> {
          if (!closed) action.run();
        },
        ticks);
  }

  public synchronized void stopShake(Player player) {
    if (player == null) return;
    ShakeState state = activeShakes.get(player.getUniqueId());
    if (state != null && state.player == player) retire(state);
    tasks.cancelPlayer(player);
  }

  @org.bukkit.event.EventHandler(priority = org.bukkit.event.EventPriority.MONITOR)
  public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) {
    stopShake(event.getPlayer());
  }

  public synchronized void stopAll() {
    generation++;
    for (GlobalWork work : Set.copyOf(globalWork)) if (work.task != null) work.task.cancel();
    globalWork.clear();
    tasks.cancelAll();
    activeShakes.clear();
  }

  public synchronized boolean isShaking(Player player) {
    if (player == null) return false;
    cleanupExpired();
    ShakeState state = activeShakes.get(player.getUniqueId());
    return state != null && state.player == player;
  }

  public void setEnabled(Player player, boolean enabled) {
    tasks.execute(
        player,
        () -> {
          synchronized (this) {
            if (closed) return;
            playerPrefs.computeIfAbsent(
                        player.getUniqueId(), ignored -> new PlayerShakePreferences())
                    .enabled =
                enabled;
            if (!enabled) stopShake(player);
          }
        });
  }

  public void setIntensityMultiplier(Player player, float multiplier) {
    if (!Float.isFinite(multiplier)) throw new IllegalArgumentException("Invalid intensity");
    tasks.execute(
        player,
        () -> {
          synchronized (this) {
            if (closed) return;
            playerPrefs.computeIfAbsent(
                        player.getUniqueId(), ignored -> new PlayerShakePreferences())
                    .intensityMultiplier =
                Math.max(0, Math.min(2, multiplier));
            if (multiplier <= 0) stopShake(player);
          }
        });
  }

  public void disableType(Player player, ShakeType type) {
    changeType(player, type, false);
  }

  public void enableType(Player player, ShakeType type) {
    changeType(player, type, true);
  }

  private void changeType(Player player, ShakeType type, boolean enabled) {
    tasks.execute(
        player,
        () -> {
          synchronized (this) {
            if (closed) return;
            var prefs =
                playerPrefs.computeIfAbsent(
                    player.getUniqueId(), ignored -> new PlayerShakePreferences());
            if (enabled) prefs.disabledTypes.remove(type);
            else prefs.disabledTypes.add(type);
          }
        });
  }

  public synchronized void shutdown() {
    if (closed) return;
    closed = true;
    tasks.shutdown();
    stopAll();
    playerPrefs.clear();
  }

  public synchronized void cleanupExpired() {
    for (ShakeState state : List.copyOf(activeShakes.values()))
      if (state.expired(nanoTime.getAsLong())) retire(state);
  }

  public synchronized int getActiveShakeCount() {
    cleanupExpired();
    return activeShakes.size();
  }

  private void playShakeSound(Player player, ShakeType type) {
    Sound sound =
        switch (type) {
            // 爆炸类
          case EXPLOSION, NUCLEAR -> Sound.ENTITY_GENERIC_EXPLODE;
          case TNT -> Sound.ENTITY_TNT_PRIMED;
          case CREEPER -> Sound.ENTITY_CREEPER_PRIMED;
          case BED_EXPLOSION, RESPAWN_ANCHOR -> Sound.ENTITY_GENERIC_BURN;
          case EARTHQUAKE, LANDSLIDE -> Sound.ENTITY_ENDER_DRAGON_GROWL;

            // 战斗类
          case HIT -> Sound.ENTITY_WITHER_HURT;
          case CRITICAL_HIT -> Sound.ENTITY_WITHER_BREAK_BLOCK;
          case DEATH -> Sound.ENTITY_WITHER_DEATH;
          case COMBO -> Sound.ENTITY_EVOKER_CAST_SPELL;
          case PARRY -> Sound.BLOCK_ANVIL_USE;
          case DODGE -> Sound.ENTITY_SHEEP_SHEAR;

            // 雷电/魔法类
          case LIGHTNING, THUNDER -> Sound.ENTITY_LIGHTNING_BOLT_THUNDER;
          case MAGIC, ENCHANT -> Sound.BLOCK_ENCHANTMENT_TABLE_USE;
          case CURSE -> Sound.ENTITY_WITCH_CELEBRATE;
          case PORTAL -> Sound.ENTITY_ENDERMAN_TELEPORT;

            // 战争类
          case WAR_DECLARE -> Sound.ENTITY_WITHER_SPAWN;
          case VICTORY -> Sound.UI_TOAST_CHALLENGE_COMPLETE;
          case DEFEAT -> Sound.ENTITY_WITHER_DEATH;
          case SIEGE -> Sound.ENTITY_GENERIC_EXPLODE;
          case SURRENDER -> Sound.ENTITY_VILLAGER_TRADE;
          case SCOUT -> Sound.ENTITY_PARROT_AMBIENT;

            // 警报类
          case ALERT, BORDER_WARNING -> Sound.BLOCK_NOTE_BLOCK_BELL;
          case EARTHQUAKE_ALERT -> Sound.BLOCK_BEACON_DEACTIVATE;
          case INTRUSION -> Sound.BLOCK_NOTE_BLOCK_BASS;

            // 交互类
          case ACHIEVEMENT -> Sound.ENTITY_PLAYER_LEVELUP;
          case RARE_FIND -> Sound.UI_TOAST_CHALLENGE_COMPLETE;
          case BEACON -> Sound.BLOCK_BEACON_ACTIVATE;
          case BUTTON -> Sound.BLOCK_STONE_BUTTON_CLICK_ON;
          case TELEPORT -> Sound.ENTITY_ENDERMAN_TELEPORT;
          case CRAFT -> Sound.BLOCK_RESPAWN_ANCHOR_SET_SPAWN;
          case TRADE -> Sound.ENTITY_VILLAGER_AMBIENT;

            // 环境类
          case STORM -> Sound.WEATHER_RAIN;
          case RAIN -> Sound.WEATHER_RAIN;
          case VOLCANIC -> Sound.ENTITY_GENERIC_EXPLODE;

            // 建筑/破坏类
          case BUILD -> Sound.BLOCK_STONE_PLACE;
          case DESTROY -> Sound.BLOCK_STONE_BREAK;
          case STRUCTURE -> Sound.BLOCK_BEACON_DEACTIVATE;

            // 特殊事件类
          case RARE_SPAWN -> Sound.ENTITY_WITHER_SPAWN;
          case BOSS_APPEAR -> Sound.ENTITY_WITHER_SPAWN;
          case BOSS_DEATH -> Sound.ENTITY_WITHER_DEATH;
          case DRAGON_FIGHT -> Sound.ENTITY_ENDER_DRAGON_GROWL;
          case WITHER_SPAWN -> Sound.ENTITY_WITHER_SPAWN;

            // PvP 类
          case PVP_START -> Sound.ENTITY_GENERIC_EXPLODE;
          case FLAG_CAPTURE -> Sound.ENTITY_ITEM_PICKUP;
          case BASE_ATTACK -> Sound.ENTITY_GENERIC_EXPLODE;
          case RANK_UP -> Sound.ENTITY_PLAYER_LEVELUP;

            // 基础震动
          default -> Sound.ENTITY_GENERIC_HURT;
        };

    float volume = type.getIntensity() * 1.2f;
    float pitch = 0.8f + (float) (ThreadLocalRandom.current().nextDouble() * 0.4);

    player.playSound(player.getLocation(), sound, volume, pitch);
  }

  private void playShakeParticles(Player player, ShakeType type) {
    Location loc = player.getLocation();

    switch (type) {
        // 爆炸类
      case EXPLOSION, NUCLEAR, TNT, CREEPER, BED_EXPLOSION, RESPAWN_ANCHOR, VOLCANIC -> {
        player.spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, loc, 3, 0.5, 0.5, 0.5, 0);
        player.spawnParticle(org.bukkit.Particle.FLAME, loc, 30, 1.0, 0.5, 1.0, 0.05);
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 20, 1.0, 0.5, 1.0, 0.02);
        player.spawnParticle(org.bukkit.Particle.LAVA, loc, 15, 0.8, 0.3, 0.8, 0);
      }
        // 雷电类
      case LIGHTNING, THUNDER -> {
        player.spawnParticle(org.bukkit.Particle.FLASH, loc, 2, 0, 0, 0, 0);
        player.spawnParticle(org.bukkit.Particle.ELECTRIC_SPARK, loc, 25, 0.5, 1.0, 0.5, 0.1);
        player.spawnParticle(org.bukkit.Particle.WHITE_ASH, loc, 10, 0.5, 0.5, 0.5, 0);
      }
        // 战争/警报类
      case WAR_DECLARE, SIEGE, BOSS_APPEAR, WITHER_SPAWN -> {
        player.spawnParticle(org.bukkit.Particle.WITCH, loc, 20, 1.0, 0.5, 1.0, 0.03);
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 15, 0.8, 0.5, 0.8, 0.02);
        player.spawnParticle(org.bukkit.Particle.FLAME, loc, 20, 0.8, 0.4, 0.8, 0.03);
      }
        // 胜利/成就类
      case VICTORY, ACHIEVEMENT, RANK_UP -> {
        player.spawnParticle(org.bukkit.Particle.END_ROD, loc, 15, 0.5, 0.5, 0.5, 0.01);
        player.spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER, loc, 20, 0.5, 0.5, 0.5, 0.02);
        player.spawnParticle(org.bukkit.Particle.ITEM_SNOWBALL, loc, 10, 0.3, 0.3, 0.3, 0.01);
      }
        // 魔法/附魔类
      case MAGIC, ENCHANT, CURSE -> {
        player.spawnParticle(org.bukkit.Particle.ENCHANTED_HIT, loc, 15, 0.5, 0.5, 0.5, 0.03);
        player.spawnParticle(org.bukkit.Particle.WITCH, loc, 10, 0.4, 0.4, 0.4, 0.02);
        player.spawnParticle(org.bukkit.Particle.SOUL, loc, 8, 0.3, 0.3, 0.3, 0.01);
      }
        // 传送类
      case PORTAL, TELEPORT -> {
        player.spawnParticle(org.bukkit.Particle.PORTAL, loc, 25, 0.8, 1.0, 0.8, 0.05);
        player.spawnParticle(org.bukkit.Particle.REVERSE_PORTAL, loc, 15, 0.5, 0.6, 0.5, 0.02);
        player.spawnParticle(org.bukkit.Particle.WHITE_ASH, loc, 10, 0.3, 0.3, 0.3, 0);
      }
        // 地震类
      case EARTHQUAKE, LANDSLIDE, AFTershock -> {
        player.spawnParticle(
            org.bukkit.Particle.BLOCK,
            loc,
            30,
            1.0,
            0.2,
            1.0,
            0.03,
            org.bukkit.Material.DIRT.createBlockData());
        player.spawnParticle(
            org.bukkit.Particle.BLOCK,
            loc,
            20,
            0.8,
            0.2,
            0.8,
            0.02,
            org.bukkit.Material.GRAVEL.createBlockData());
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 15, 0.6, 0.3, 0.6, 0.02);
      }
        // Boss 死亡/龙战斗类
      case BOSS_DEATH, DRAGON_FIGHT -> {
        player.spawnParticle(org.bukkit.Particle.DRAGON_BREATH, loc, 30, 1.0, 0.8, 1.0, 0.02);
        player.spawnParticle(org.bukkit.Particle.END_ROD, loc, 25, 0.8, 0.8, 0.8, 0.01);
        player.spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, loc, 2, 0.5, 0.5, 0.5, 0);
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 20, 0.8, 0.5, 0.8, 0.02);
      }
        // 信标/建筑类
      case BEACON, BUILD -> {
        player.spawnParticle(org.bukkit.Particle.END_ROD, loc, 15, 0.5, 0.8, 0.5, 0.01);
        player.spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER, loc, 10, 0.4, 0.4, 0.4, 0.02);
      }
        // 破坏类
      case DESTROY, STRUCTURE -> {
        player.spawnParticle(
            org.bukkit.Particle.BLOCK,
            loc,
            25,
            0.8,
            0.8,
            0.8,
            0.03,
            org.bukkit.Material.STONE.createBlockData());
        player.spawnParticle(
            org.bukkit.Particle.ITEM,
            loc,
            15,
            0.5,
            0.5,
            0.5,
            0.01,
            new org.bukkit.inventory.ItemStack(org.bukkit.Material.COBBLESTONE));
      }
        // 战斗类
      case CRITICAL_HIT, COMBO, PARRY -> {
        player.spawnParticle(org.bukkit.Particle.CRIT, loc, 10, 0.3, 0.3, 0.3, 0.05);
        player.spawnParticle(org.bukkit.Particle.CRIT, loc, 5, 0.2, 0.2, 0.2, 0.03);
      }
        // 天气类
      case STORM, RAIN -> {
        player.spawnParticle(org.bukkit.Particle.DRIPPING_WATER, loc, 20, 0.5, 0.5, 0.5, 0.02);
        player.spawnParticle(org.bukkit.Particle.SPLASH, loc, 15, 0.4, 0.4, 0.4, 0.01);
      }
        // 警报类
      case ALERT, EARTHQUAKE_ALERT, INTRUSION, BORDER_WARNING -> {
        player.spawnParticle(org.bukkit.Particle.FLAME, loc, 15, 0.5, 0.5, 0.5, 0.02);
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 10, 0.4, 0.4, 0.4, 0.02);
      }
        // 稀有发现类
      case RARE_FIND, RARE_SPAWN -> {
        player.spawnParticle(org.bukkit.Particle.END_ROD, loc, 20, 0.6, 0.6, 0.6, 0.01);
        player.spawnParticle(org.bukkit.Particle.NAUTILUS, loc, 15, 0.5, 0.8, 0.5, 0.02);
        player.spawnParticle(org.bukkit.Particle.WHITE_ASH, loc, 10, 0.4, 0.4, 0.4, 0);
      }
        // 战败/投降类
      case DEFEAT, SURRENDER -> {
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 20, 0.6, 0.6, 0.6, 0.02);
        player.spawnParticle(org.bukkit.Particle.ASH, loc, 15, 0.5, 0.5, 0.5, 0.01);
      }
        // PvP 类
      case PVP_START, FLAG_CAPTURE, BASE_ATTACK -> {
        player.spawnParticle(org.bukkit.Particle.FLAME, loc, 15, 0.5, 0.5, 0.5, 0.03);
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc, 10, 0.4, 0.4, 0.4, 0.02);
        player.spawnParticle(
            org.bukkit.Particle.DUST,
            loc,
            12,
            0.3,
            0.3,
            0.3,
            0.01,
            new org.bukkit.Particle.DustOptions(org.bukkit.Color.RED, 1.0f));
      }
        // 默认粒子
      default -> {
        player.spawnParticle(org.bukkit.Particle.SMOKE, loc.add(0, 1, 0), 10, 0.3, 0.3, 0.3, 0.02);
      }
    }
  }
}
