package dev.starcore.starcore.achievement;

import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** 成就服务抽象实现 */
public abstract class AbstractAchievementService implements AchievementService {

  protected final Plugin plugin;

  // 所有注册的成就
  protected final Map<NamespacedKey, Achievement> achievements = new ConcurrentHashMap<>();

  // 玩家已完成的成就
  protected final Map<UUID, Set<NamespacedKey>> playerAchievements = new ConcurrentHashMap<>();
  protected final Map<UUID, AchievementProgress> progressCache = new ConcurrentHashMap<>();

  // D-081: 内部经济服务引用；通过 setEconomyService 注入
  protected dev.starcore.starcore.foundation.economy.EconomyService economyService;

  public void setEconomyService(
      dev.starcore.starcore.foundation.economy.EconomyService economyService) {
    this.economyService = economyService;
  }

  @Override
  public dev.starcore.starcore.foundation.economy.EconomyService getInternalEconomy() {
    return economyService;
  }

  protected AbstractAchievementService(Plugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public Plugin getPlugin() {
    return plugin;
  }

  @Override
  public void registerAchievement(Achievement achievement) {
    achievements.put(achievement.getKey(), achievement);
  }

  @Override
  public void registerAchievements(Achievement... achievements) {
    for (Achievement achievement : achievements) {
      registerAchievement(achievement);
    }
  }

  @Override
  public Optional<Achievement> getAchievement(NamespacedKey key) {
    return Optional.ofNullable(achievements.get(key));
  }

  @Override
  public Collection<Achievement> getAllAchievements() {
    return List.copyOf(achievements.values());
  }

  @Override
  public Collection<Achievement> getAchievementsByCategory(AchievementCategory category) {
    return getAllAchievements();
  }

  @Override
  public boolean hasAchievement(UUID playerId, NamespacedKey key) {
    if (playerId == null || key == null) {
      return false;
    }
    return getOrCreateProgress(playerId).isCompleted(key);
  }

  @Override
  public boolean grantAchievement(Player player, NamespacedKey key) {
    Achievement achievement = achievements.get(key);
    if (achievement == null) {
      return false;
    }

    // 检查是否已完成
    if (hasAchievement(player.getUniqueId(), key)) {
      return false;
    }

    // 检查父成就
    if (!rewardsAreValid(achievement)) {
      return false;
    }

    if (achievement.hasParent()) {
      if (!hasAchievement(player.getUniqueId(), achievement.getParent())) {
        return false;
      }
    }

    // 添加到已完成列表
    Set<NamespacedKey> completed =
        playerAchievements.computeIfAbsent(
            player.getUniqueId(), k -> ConcurrentHashMap.newKeySet());
    if (!completed.add(key)) {
      return false;
    }
    getOrCreateProgress(player.getUniqueId()).markCompleted(key);

    // 触发成就解锁事件
    AchievementUnlockedEvent event = new AchievementUnlockedEvent(player, achievement);
    Bukkit.getPluginManager().callEvent(event);

    // 显示成就通知
    displayAchievement(player, achievement);

    // 给予奖励
    giveRewards(player, achievement);

    return true;
  }

  @Override
  public Set<NamespacedKey> getPlayerAchievements(UUID playerId) {
    return getOrCreateProgress(playerId).getCompletedAchievements();
  }

  @Override
  public int getPlayerProgress(UUID playerId) {
    return getOrCreateProgress(playerId).getCompletedAchievements().size();
  }

  @Override
  public int getTotalAchievements() {
    return achievements.size();
  }

  @Override
  public void loadPlayerData(UUID playerId, Set<NamespacedKey> achievements) {
    if (playerId == null) {
      throw new IllegalArgumentException("playerId must not be null");
    }
    Set<NamespacedKey> incoming = ConcurrentHashMap.newKeySet();
    if (achievements != null) {
      incoming.addAll(achievements);
    }
    Set<NamespacedKey> merged =
        playerAchievements.merge(
            playerId,
            incoming,
            (existing, loaded) -> {
              existing.addAll(loaded);
              return existing;
            });
    AchievementProgress progress = getOrCreateProgress(playerId);
    merged.forEach(progress::markCompleted);
  }

  @Override
  public Set<NamespacedKey> savePlayerData(UUID playerId) {
    return getPlayerAchievements(playerId);
  }

  @Override
  public AchievementProgress getOrCreateProgress(UUID playerId) {
    if (playerId == null) {
      throw new IllegalArgumentException("playerId must not be null");
    }
    return progressCache.computeIfAbsent(
        playerId,
        id -> {
          AchievementProgress progress = new AchievementProgress(id);
          Set<NamespacedKey> completed = playerAchievements.get(id);
          if (completed != null) {
            completed.forEach(progress::markCompleted);
          }
          return progress;
        });
  }

  @Override
  public void incrementTrigger(UUID playerId, AchievementTrigger.TriggerType type, int amount) {
    if (playerId == null || type == null || amount <= 0) {
      return;
    }
    getOrCreateProgress(playerId).incrementTriggerCount(type.name(), amount);
  }
}
