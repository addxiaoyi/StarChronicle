package dev.starcore.starcore.foundation.tooltip;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

/** 快捷栏提示监听器 监听玩家切换物品并显示智能提示 */
public class HotbarTooltipListener implements Listener {

  private static final Pattern HEX_COLOR_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

  private final Plugin plugin;
  private final SmartTooltipService tooltipService;
  private final Map<UUID, Long> lastHintTime;
  private final Map<UUID, BukkitTask> pendingHints;

  public HotbarTooltipListener(
      @NotNull Plugin plugin, @NotNull SmartTooltipService tooltipService) {
    this.plugin = plugin;
    this.tooltipService = tooltipService;
    this.lastHintTime = new ConcurrentHashMap<>();
    this.pendingHints = new ConcurrentHashMap<>();
  }

  /** 监听玩家切换快捷栏物品 */
  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onItemHeld(PlayerItemHeldEvent event) {
    Player player = event.getPlayer();
    ItemStack newItem = player.getInventory().getItem(event.getNewSlot());

    if (newItem == null || newItem.getType() == Material.AIR) {
      return;
    }

    // 取消之前的待处理提示
    cancelPendingHint(player);

    // 检查冷却
    if (!canShowHint(player)) {
      return;
    }

    // 生成快捷栏提示
    String hint = tooltipService.generateHotbarHint(player, newItem);
    if (hint != null && !hint.isEmpty()) {
      showHotbarHint(player, hint);
    }
  }

  /** 监听玩家使用物品 */
  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onPlayerInteract(PlayerInteractEvent event) {
    Player player = event.getPlayer();
    ItemStack item = event.getItem();

    if (item == null || item.getType() == Material.AIR) {
      return;
    }

    // 检查是否有自定义提示
    if (tooltipService.hasCustomTooltip(player, item)) {
      // 可以在这里添加额外的交互反馈
    }
  }

  /** 监听玩家切换主副手 */
  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
    Player player = event.getPlayer();
    ItemStack offhandItem = event.getOffHandItem();

    if (offhandItem == null || offhandItem.getType() == Material.AIR) {
      return;
    }

    // 生成副手物品的提示
    String hint = tooltipService.generateHotbarHint(player, offhandItem);
    if (hint != null && !hint.isEmpty()) {
      // 副手物品的提示可能需要特殊处理
    }
  }

  /** 显示快捷栏提示 */
  private void showHotbarHint(@NotNull Player player, @NotNull String hint) {
    lastHintTime.put(player.getUniqueId(), System.currentTimeMillis());

    Component component =
        Component.text(hint).color(NamedTextColor.WHITE).decoration(TextDecoration.ITALIC, false);

    player.sendActionBar(component);

    // 设置自动消失
    int duration = tooltipService.getConfig().getHotbarHintDuration();
    UUID playerId = player.getUniqueId();
    BukkitTask task =
        plugin
            .getServer()
            .getScheduler()
            .runTaskLater(
                plugin,
                () -> {
                  pendingHints.remove(playerId);
                  if (plugin.isEnabled() && player.isOnline()) {
                    player.sendActionBar(Component.empty());
                  }
                },
                duration * 20L);
    BukkitTask previous = pendingHints.put(playerId, task);
    if (previous != null) {
      previous.cancel();
    }
  }

  /** 检查是否可以显示提示（冷却检查） */
  private boolean canShowHint(@NotNull Player player) {
    if (!tooltipService.isEnabled() || !tooltipService.getConfig().isHotbarHintsEnabled()) {
      return false;
    }

    long lastTime = lastHintTime.getOrDefault(player.getUniqueId(), 0L);
    long cooldown = tooltipService.getConfig().getHotbarHintCooldown();

    return System.currentTimeMillis() - lastTime >= cooldown;
  }

  /** 取消待处理的提示 */
  private void cancelPendingHint(@NotNull Player player) {
    BukkitTask future = pendingHints.remove(player.getUniqueId());
    if (future != null) {
      future.cancel();
      if (player.isOnline()) {
        player.sendActionBar(Component.empty());
      }
    }
  }

  /** 关闭监听器 */
  public void shutdown() {
    pendingHints.values().forEach(BukkitTask::cancel);
    pendingHints.clear();
    lastHintTime.clear();
  }

  // 玩家退出时取消并清理待处理的 Bukkit 提示任务。
  @EventHandler(priority = EventPriority.NORMAL)
  public void onPlayerQuit(PlayerQuitEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    BukkitTask future = pendingHints.remove(playerId);
    if (future != null) {
      future.cancel();
    }
    lastHintTime.remove(playerId);
  }
}
