package dev.starcore.starcore.foundation.economy.transaction;

import java.util.Objects;
import org.bukkit.plugin.Plugin;

/** Shared refund ledger owned by the plugin lifecycle. */
public final class RefundLedgerService {
  private final RefundLedger ledger;

  public RefundLedgerService(Plugin plugin) {
    Objects.requireNonNull(plugin, "plugin");
    this.ledger =
        new RefundLedger(
            plugin.getDataFolder().toPath().resolve("economy/refund-ledger.properties"),
            plugin.getLogger());
  }

  public RefundLedger ledger() {
    return ledger;
  }
}
