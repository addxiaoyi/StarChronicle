package dev.starcore.starcore.economy;

import java.util.*;

/** 资源模型 表示一个具体的资源 */
public record Resource(
    String resourceId, // 资源ID
    String name, // 资源名称
    ResourceType type, // 资源类型
    String description, // 描述
    double baseValue, // 基础价值
    Map<String, Object> properties, // 特性
    Set<String> tags // 标签
    ) {

  /** 创建资源构建器 */
  public static Builder builder(String resourceId, String name, ResourceType type) {
    return new Builder(resourceId, name, type);
  }

  /** 检查是否有特定标签 */
  public boolean hasTag(String tag) {
    return tags.contains(tag);
  }

  /** 获取特性值 */
  public <T> T getProperty(String key, Class<T> type) {
    Object value = properties.get(key);
    if (value != null && type.isInstance(value)) {
      return type.cast(value);
    }
    return null;
  }

  /** 资源构建器 */
  public static class Builder {
    private final String resourceId;
    private final String name;
    private final ResourceType type;
    private String description = "";
    private double baseValue = 1.0;
    private final Map<String, Object> properties = new HashMap<>();
    private final Set<String> tags = new HashSet<>();

    private Builder(String resourceId, String name, ResourceType type) {
      this.resourceId = Objects.requireNonNull(resourceId);
      this.name = Objects.requireNonNull(name);
      this.type = Objects.requireNonNull(type);
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder baseValue(double baseValue) {
      this.baseValue = Math.max(0, baseValue);
      return this;
    }

    public Builder addProperty(String key, Object value) {
      this.properties.put(key, value);
      return this;
    }

    public Builder addTag(String tag) {
      this.tags.add(tag);
      return this;
    }

    public Resource build() {
      return new Resource(
          resourceId, name, type, description, baseValue, Map.copyOf(properties), Set.copyOf(tags));
    }
  }
}
