package dev.starcore.starcore.dummy;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

/** 训练显示与命中反馈 负责构建 HUD（actionbar）文本，以及播放命中音效、粒子与伤害数字 */
public final class DummyDisplay {

  private DummyDisplay() {
    // 工具类，禁止实例化
  }

  /** 构建实时 HUD 文本：DPS / 累计伤害 / 命中 / 暴击 */
  public static String renderHud(TrainingSession session, TrainingDummy dummy) {
    DamageTracker tracker = session.getTracker();
    String health = String.format("%.1f§7/§c%.1f", dummy.getHealth(), dummy.getMaxHealth());
    return String.format(
        "§6DPS §c%.1f §8| §e伤害 §c%.0f §8| §f命中 §e%d §8| §b暴击 §e%d §8| §7血量 §c%s",
        session.getSessionDps(),
        tracker.getTotalDamage(),
        tracker.getHitCount(),
        tracker.getCritCount(),
        health);
  }

  /** 格式化伤害数字文本 */
  public static String damageNumber(double damage, boolean crit) {
    return String.format(crit ? "§b§l暴击 -%.1f ♥" : "§c-%.1f ♥", damage);
  }

  /** 命中反馈：音效 + 粒子 + 伤害数字 */
  public static void hitFeedback(Player attacker, Location hitAt, double damage, boolean crit) {
    attacker.playSound(
        attacker.getLocation(),
        crit ? Sound.ENTITY_PLAYER_ATTACK_CRIT : Sound.ENTITY_PLAYER_ATTACK_STRONG,
        1.0F,
        1.2F);
    attacker.sendActionBar(damageNumber(damage, crit));

    World world = hitAt.getWorld();
    if (world != null) {
      world.spawnParticle(
          crit ? Particle.CRIT : Particle.DAMAGE_INDICATOR,
          hitAt,
          crit ? 12 : 6,
          0.3,
          0.4,
          0.3,
          0.05);
    }
  }
}
