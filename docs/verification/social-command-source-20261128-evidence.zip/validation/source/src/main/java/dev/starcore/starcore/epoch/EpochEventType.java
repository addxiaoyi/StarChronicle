package dev.starcore.starcore.epoch;

/** 纪元事件类型 定义纪元生命周期中的事件类型 */
public enum EpochEventType {
  /** 纪元开始 */
  EPOCH_START("epoch_start", "纪元开始"),

  /** 纪元准备 */
  EPOCH_PREPARE("epoch_prepare", "纪元准备"),

  /** 纪元就绪 */
  EPOCH_READY("epoch_ready", "纪元就绪"),

  /** 纪元激活 */
  EPOCH_ACTIVATE("epoch_activate", "纪元激活"),

  /** 纪元暂停 */
  EPOCH_SUSPEND("epoch_suspend", "纪元暂停"),

  /** 纪元恢复 */
  EPOCH_RESUME("epoch_resume", "纪元恢复"),

  /** 纪元完成 */
  EPOCH_COMPLETE("epoch_complete", "纪元完成"),

  /** 纪元归档 */
  EPOCH_ARCHIVE("epoch_archive", "纪元归档"),

  /** 纪元取消 */
  EPOCH_CANCEL("epoch_cancel", "纪元取消"),

  /** 里程碑达成 */
  MILESTONE_COMPLETE("milestone_complete", "里程碑达成"),

  /** 决策触发 */
  DECISION_TRIGGER("decision_trigger", "决策触发"),

  /** 决策做出 */
  DECISION_MADE("decision_made", "决策做出"),

  /** 决策锁定 */
  DECISION_LOCKED("decision_locked", "决策锁定"),

  /** 迁移开始 */
  MIGRATION_START("migration_start", "迁移开始"),

  /** 迁移完成 */
  MIGRATION_COMPLETE("migration_complete", "迁移完成"),

  /** 验证开始 */
  VERIFICATION_START("verification_start", "验证开始"),

  /** 验证通过 */
  VERIFICATION_PASS("verification_pass", "验证通过"),

  /** 验证失败 */
  VERIFICATION_FAIL("verification_fail", "验证失败"),

  /** 事件发生 */
  EVENT_OCCURRED("event_occurred", "事件发生"),

  /** Boss生成 */
  BOSS_SPAWN("boss_spawn", "Boss生成"),

  /** Boss击败 */
  BOSS_DEFEAT("boss_defeat", "Boss击败"),

  /** Boss失败 */
  BOSS_FAIL("boss_fail", "Boss失败"),

  /** 裂隙开启 */
  RIFT_OPEN("rift_open", "裂隙开启"),

  /** 裂隙关闭 */
  RIFT_CLOSE("rift_close", "裂隙关闭"),

  /** 公共选择 */
  PUBLIC_CHOICE("public_choice", "公共选择"),

  /** 玩家参与 */
  PLAYER_JOIN("player_join", "玩家参与"),

  /** 玩家离开 */
  PLAYER_LEAVE("player_leave", "玩家离开"),

  /** 错误 */
  ERROR("error", "错误"),

  /** 警告 */
  WARNING("warning", "警告"),

  /** 自定义事件 */
  CUSTOM("custom", "自定义事件");

  private final String eventKey;
  private final String displayName;

  EpochEventType(String eventKey, String displayName) {
    this.eventKey = eventKey;
    this.displayName = displayName;
  }

  public String getEventKey() {
    return eventKey;
  }

  public String getDisplayName() {
    return displayName;
  }

  public static EpochEventType fromKey(String eventKey) {
    for (EpochEventType type : values()) {
      if (type.eventKey.equals(eventKey)) {
        return type;
      }
    }
    return CUSTOM;
  }
}
