package dev.starcore.starcore.core.guide;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

/** 玩法指南命令 */
public class GuideCommand extends Command implements CommandExecutor, TabCompleter {

  private final JavaPlugin plugin;

  public GuideCommand(JavaPlugin plugin) {
    super("guide");
    this.plugin = plugin;
    setDescription("打开 STARCORE 玩法指南");
    setUsage("/guide [give|章节]");
    setAliases(java.util.List.of("tutorial", "manual", "starcoreguide"));
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    return execute(sender, label, args);
  }

  @Override
  public boolean execute(
      @NotNull CommandSender sender, @NotNull String commandLabel, @NotNull String[] args) {
    if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
      return handleGive(sender, args);
    }

    if (!(sender instanceof Player player)) {
      sender.sendMessage("此命令只能由玩家执行！");
      return false;
    }

    if (args.length == 0) {
      try {
        GameplayGuideGui.openMainMenu(player);
      } catch (Throwable e) {
        plugin
            .getLogger()
            .severe(
                "[GuideCommand] Error opening guide GUI: "
                    + e.getClass().getSimpleName()
                    + ": "
                    + e.getMessage());
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "[GuideCommand] 操作异常", e);
        player.sendMessage("§c打开指南失败: " + e.getMessage());
        player.sendMessage("§c请联系管理员查看控制台日志");
      }
      return true;
    }

    String chapterName = String.join("_", args).toUpperCase();
    try {
      GuideChapter chapter = GuideChapter.valueOf(chapterName);
      GameplayGuideGui.openChapter(player, chapter, 0);
    } catch (IllegalArgumentException e) {
      player.sendMessage("未知章节！可用章节:");
      for (GuideChapter ch : GuideChapter.values()) {
        player.sendMessage(
            "  /guide " + ch.name().toLowerCase().replace('_', ' ') + " - " + ch.getTitle());
      }
    } catch (Throwable e) {
      plugin
          .getLogger()
          .severe(
              "[GuideCommand] Error opening chapter GUI: "
                  + e.getClass().getSimpleName()
                  + ": "
                  + e.getMessage());
      plugin.getLogger().log(java.util.logging.Level.SEVERE, "[GuideCommand] 操作异常", e);
      player.sendMessage("§c打开章节失败: " + e.getMessage());
      player.sendMessage("§c请联系管理员查看控制台日志");
    }

    return true;
  }

  private boolean handleGive(CommandSender sender, String[] args) {
    Player target;
    if (args.length >= 2) {
      target = plugin.getServer().getPlayer(args[1]);
      if (target == null) {
        sender.sendMessage("§c玩家未找到: " + args[1]);
        return false;
      }
    } else if (sender instanceof Player p) {
      target = p;
    } else {
      sender.sendMessage("§c请指定玩家: /guide give <player>");
      return false;
    }

    try {
      java.util.Map<Integer, org.bukkit.inventory.ItemStack> leftovers =
          target.getInventory().addItem(GuideBook.createGuideBook());
      leftovers
          .values()
          .forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
      if (!leftovers.isEmpty()) {
        target.sendMessage("§e你的背包已满，指南书已放在你脚边。");
      }
      sender.sendMessage("§a已将 STARCORE 玩法指南 交给 " + target.getName());
      if (!sender.equals(target)) {
        target.sendMessage("§a你收到了一本 STARCORE 玩法指南！右键点击即可打开。");
      }
    } catch (Throwable e) {
      plugin
          .getLogger()
          .severe(
              "[GuideCommand] Error giving guide book: "
                  + e.getClass().getSimpleName()
                  + ": "
                  + e.getMessage());
      plugin.getLogger().log(java.util.logging.Level.SEVERE, "[GuideCommand] 操作异常", e);
      sender.sendMessage("§c发放指南失败: " + e.getMessage());
      return false;
    }
    return true;
  }

  @Override
  public List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (args.length == 1) {
      List<String> completions = new java.util.ArrayList<>(List.of("give"));
      completions.addAll(
          Arrays.stream(GuideChapter.values()).map(ch -> ch.name().toLowerCase()).toList());
      return completions.stream().filter(s -> s.startsWith(args[0].toLowerCase())).toList();
    }
    if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
      return null;
    }
    return Collections.emptyList();
  }
}
