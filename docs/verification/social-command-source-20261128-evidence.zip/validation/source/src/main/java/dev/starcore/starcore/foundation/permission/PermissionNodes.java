package dev.starcore.starcore.foundation.permission;

import java.util.Locale;
import java.util.Objects;

public final class PermissionNodes {
    private PermissionNodes() {
    }

    public static String external(String prefix, String externalId) {
        Objects.requireNonNull(prefix, "prefix");
        Objects.requireNonNull(externalId, "externalId");
        String value = externalId.strip().toLowerCase(Locale.ROOT);
        if (value.isEmpty()) {
            throw new IllegalArgumentException("externalId must not be blank");
        }

        StringBuilder node = new StringBuilder(prefix.length() + value.length() + 1);
        node.append(prefix).append('.');
        value.codePoints().forEach(codePoint -> appendCodePoint(node, codePoint));
        return node.toString();
    }

    private static void appendCodePoint(StringBuilder node, int codePoint) {
        if (Character.isLetterOrDigit(codePoint) || codePoint == '_' || codePoint == '-') {
            node.appendCodePoint(codePoint);
            return;
        }
        if (codePoint == ':') {
            node.append('.');
            return;
        }
        node.append('_').append(String.format(Locale.ROOT, "%04x", codePoint));
    }
}
