package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

final class SqlBalanceStorage implements InternalEconomyService.BalanceStorage {
  private static final String NAMESPACE = "economy";
  private static final String FILE_NAME = "player-balances.properties";
  private static final String TABLE_NAME = "starcore_player_balances";
  private static final int MAX_ASYNC_RETRIES = 8;
  private static final long INITIAL_RETRY_DELAY_MILLIS = 250L;
  private static final long MAX_RETRY_DELAY_MILLIS = 5_000L;

  private final Supplier<Optional<DataSource>> dataSourceSupplier;
  private final Supplier<Properties> legacyPropertiesSupplier;
  private final Logger logger;
  private final Executor ioExecutor;
  private final Object saveLock = new Object();
  private CompletableFuture<Void> pendingSave = CompletableFuture.completedFuture(null);
  private Properties queuedSnapshot;
  private boolean saveWorkerScheduled;
  private boolean synchronousSaveInProgress;
  private int consecutiveFailures;
  private long retryGeneration;
  private long asyncSaveVersion;

  /** E-028 修复: loadFromDatabase 加 30s LRU 缓存，避免高频 load() 重复扫全表。 */
  private volatile Properties cachedProperties = null;

  private volatile long cacheTimestamp = 0L;
  private static final long CACHE_TTL_MS = 30_000L;

  SqlBalanceStorage(
      DatabaseService databaseService, PersistenceService persistenceService, Logger logger) {
    this(databaseService, persistenceService, logger, ForkJoinPool.commonPool());
  }

  SqlBalanceStorage(
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger,
      Executor ioExecutor) {
    this(
        databaseService::dataSource,
        () -> persistenceService.loadProperties(NAMESPACE, FILE_NAME),
        logger,
        ioExecutor);
  }

  SqlBalanceStorage(
      Supplier<Optional<DataSource>> dataSourceSupplier,
      Supplier<Properties> legacyPropertiesSupplier,
      Logger logger) {
    this(dataSourceSupplier, legacyPropertiesSupplier, logger, ForkJoinPool.commonPool());
  }

  SqlBalanceStorage(
      Supplier<Optional<DataSource>> dataSourceSupplier,
      Supplier<Properties> legacyPropertiesSupplier,
      Logger logger,
      Executor ioExecutor) {
    this.dataSourceSupplier = Objects.requireNonNull(dataSourceSupplier, "dataSourceSupplier");
    this.legacyPropertiesSupplier =
        Objects.requireNonNull(legacyPropertiesSupplier, "legacyPropertiesSupplier");
    this.logger = Objects.requireNonNull(logger, "logger");
    this.ioExecutor = Objects.requireNonNull(ioExecutor, "ioExecutor");
  }

  @Override
  public Properties load() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      Properties properties = loadFromDatabase(connection);
      if (!properties.isEmpty()) {
        return properties;
      }
      Properties legacy = copy(legacyPropertiesSupplier.get());
      if (legacy.isEmpty()) {
        return legacy;
      }
      writeSnapshot(connection, legacy);
      logger.info(
          "Imported " + legacy.size() + " legacy STARCORE player balances into SQL storage.");
      return legacy;
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to load SQL economy balances", exception);
    }
  }

  @Override
  public void save(Properties properties) {
    Properties snapshot = copy(properties);
    saveSynchronously(() -> writeSnapshot(snapshot), true, Map.of());
  }

  @Override
  public boolean saveAccount(UUID accountId, BigDecimal balance) {
    return saveAccounts(Map.of(accountId, balance));
  }

  @Override
  public boolean saveAccounts(Map<UUID, BigDecimal> accountBalances) {
    Objects.requireNonNull(accountBalances, "accountBalances");
    Map<String, String> normalizedBalances = new TreeMap<>();
    accountBalances.forEach(
        (accountId, balance) ->
            normalizedBalances.put(
                Objects.requireNonNull(accountId, "accountBalances contains a null accountId")
                    .toString(),
                Objects.requireNonNull(balance, "accountBalances contains a null balance")
                    .setScale(2, RoundingMode.DOWN)
                    .toPlainString()));
    if (normalizedBalances.isEmpty()) {
      return true;
    }
    saveSynchronously(() -> writeAccounts(normalizedBalances), false, normalizedBalances);
    return true;
  }

  private void saveSynchronously(
      Runnable write, boolean supersedesQueuedSnapshot, Map<String, String> updatedBalances) {
    CompletableFuture<Void> activeSave;
    long saveVersion;
    long coordinationWaitStartedAtNanos = System.nanoTime();
    synchronized (saveLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.SQL_SAVE_COORDINATION_WAIT,
          System.nanoTime() - coordinationWaitStartedAtNanos);
      retryGeneration++;
      synchronousSaveInProgress = true;
      saveVersion = asyncSaveVersion;
      activeSave = saveWorkerScheduled ? pendingSave : null;
    }

    boolean persisted = false;
    try {
      long pendingSaveWaitStartedAtNanos = System.nanoTime();
      awaitPendingSave(activeSave);
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.SQL_PENDING_SAVE_WAIT,
          System.nanoTime() - pendingSaveWaitStartedAtNanos);
      write.run();
      persisted = true;
    } finally {
      coordinationWaitStartedAtNanos = System.nanoTime();
      synchronized (saveLock) {
        EconomyOperationTimingProbe.record(
            EconomyOperationTimingProbe.Phase.SQL_SAVE_COORDINATION_WAIT,
            System.nanoTime() - coordinationWaitStartedAtNanos);
        if (persisted) {
          if (!updatedBalances.isEmpty() && queuedSnapshot != null) {
            updatedBalances.forEach(queuedSnapshot::setProperty);
          }
          if (supersedesQueuedSnapshot && asyncSaveVersion == saveVersion) {
            queuedSnapshot = null;
          }
          consecutiveFailures = 0;
        }
        synchronousSaveInProgress = false;
        if (queuedSnapshot != null && !saveWorkerScheduled) {
          scheduleSaveWorkerLocked(true);
        }
      }
    }
  }

  @Override
  public void saveAsync(Properties properties) {
    Properties snapshot = copy(properties);
    synchronized (saveLock) {
      queuedSnapshot = snapshot;
      asyncSaveVersion++;
      consecutiveFailures = 0;
      retryGeneration++;
      if (synchronousSaveInProgress || saveWorkerScheduled) {
        return;
      }
      scheduleSaveWorkerLocked(false);
    }
  }

  private void scheduleSaveWorkerLocked(boolean retainSnapshotOnRejection) {
    CompletableFuture<Void> save = new CompletableFuture<>();
    pendingSave = save;
    saveWorkerScheduled = true;
    try {
      ioExecutor.execute(() -> drainPendingSaves(save));
    } catch (RuntimeException rejected) {
      saveWorkerScheduled = false;
      if (!retainSnapshotOnRejection) {
        queuedSnapshot = null;
      } else {
        logger.log(
            Level.SEVERE, "Unable to schedule retry for SQL economy balance snapshot", rejected);
      }
      save.completeExceptionally(rejected);
      if (!retainSnapshotOnRejection) {
        throw rejected;
      }
    }
  }

  private void drainPendingSaves(CompletableFuture<Void> save) {
    while (true) {
      Properties snapshot;
      synchronized (saveLock) {
        if (synchronousSaveInProgress) {
          saveWorkerScheduled = false;
          save.complete(null);
          return;
        }
        snapshot = queuedSnapshot;
        queuedSnapshot = null;
        if (snapshot == null) {
          saveWorkerScheduled = false;
          consecutiveFailures = 0;
          save.complete(null);
          return;
        }
      }

      try {
        writeSnapshot(snapshot);
      } catch (RuntimeException failure) {
        logger.log(
            Level.SEVERE, "Unable to save SQL economy balance snapshot asynchronously", failure);
        synchronized (saveLock) {
          if (queuedSnapshot != null) {
            consecutiveFailures = 0;
            continue;
          }
          queuedSnapshot = snapshot;
          saveWorkerScheduled = false;
          consecutiveFailures++;
          if (!synchronousSaveInProgress && consecutiveFailures <= MAX_ASYNC_RETRIES) {
            scheduleRetryLocked();
          }
        }
        save.completeExceptionally(failure);
        return;
      }

      synchronized (saveLock) {
        consecutiveFailures = 0;
      }
    }
  }

  private void scheduleRetryLocked() {
    int retryNumber = consecutiveFailures;
    long delayMillis =
        Math.min(
            INITIAL_RETRY_DELAY_MILLIS << Math.min(retryNumber - 1, 30), MAX_RETRY_DELAY_MILLIS);
    long generation = retryGeneration;
    CompletableFuture.delayedExecutor(delayMillis, TimeUnit.MILLISECONDS)
        .execute(
            () -> {
              synchronized (saveLock) {
                if (generation != retryGeneration
                    || synchronousSaveInProgress
                    || saveWorkerScheduled
                    || queuedSnapshot == null) {
                  return;
                }
                scheduleSaveWorkerLocked(true);
              }
            });
  }

  private Properties loadFromDatabase(Connection connection) throws SQLException {
    // E-028 修复: 检查缓存是否有效（30s TTL），有效则直接返回，避免重复全表扫描。
    long now = System.currentTimeMillis();
    Properties cached = cachedProperties;
    if (cached != null && now - cacheTimestamp < CACHE_TTL_MS) {
      return copy(cached);
    }
    Properties properties = new Properties();
    try (PreparedStatement statement =
            connection.prepareStatement(
                """
                SELECT account_id, balance
                FROM starcore_player_balances
                ORDER BY account_id
                """);
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        properties.setProperty(rows.getString("account_id"), rows.getString("balance"));
      }
    }
    cachedProperties = copy(properties);
    cacheTimestamp = now;
    return properties;
  }

  private void ensureTable(Connection connection) throws SQLException {
    long startedAtNanos = System.nanoTime();
    try {
      try (Statement statement = connection.createStatement()) {
        statement.execute(
            """
            CREATE TABLE IF NOT EXISTS starcore_player_balances (
                account_id VARCHAR(64) PRIMARY KEY,
                balance DECIMAL(19,2) NOT NULL
            )
            """);
      }
    } finally {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.SQL_SCHEMA, System.nanoTime() - startedAtNanos);
    }
  }

  private void writeSnapshot(Properties properties) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      writeSnapshot(connection, properties);
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to save SQL economy balances", exception);
    } finally {
      // E-026 修复: 写入完成后 invalidate 缓存，下次 load 从 DB 重读保证新鲜。
      cachedProperties = null;
    }
  }

  private void writeAccounts(Map<String, String> accountBalances) {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      long transactionSetupStartedAtNanos = System.nanoTime();
      boolean previousAutoCommit = connection.getAutoCommit();
      connection.setAutoCommit(false);
      try (PreparedStatement upsert = connection.prepareStatement(upsertSql(connection))) {
        EconomyOperationTimingProbe.record(
            EconomyOperationTimingProbe.Phase.SQL_TRANSACTION_SETUP,
            System.nanoTime() - transactionSetupStartedAtNanos);
        long batchStartedAtNanos = System.nanoTime();
        for (Map.Entry<String, String> entry : new TreeMap<>(accountBalances).entrySet()) {
          upsert.setString(1, entry.getKey());
          upsert.setString(2, entry.getValue());
          upsert.addBatch();
        }
        upsert.executeBatch();
        EconomyOperationTimingProbe.record(
            EconomyOperationTimingProbe.Phase.SQL_BATCH, System.nanoTime() - batchStartedAtNanos);
        long commitStartedAtNanos = System.nanoTime();
        try {
          connection.commit();
        } finally {
          EconomyOperationTimingProbe.record(
              EconomyOperationTimingProbe.Phase.SQL_COMMIT,
              System.nanoTime() - commitStartedAtNanos);
        }
      } catch (Exception exception) {
        connection.rollback();
        throw exception;
      } finally {
        connection.setAutoCommit(previousAutoCommit);
      }
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to save SQL economy account balances", exception);
    } finally {
      cachedProperties = null;
    }
  }

  /** E-026 修复: 插件 disable 时调用，确保最后一次 flush 完成后再关闭。 */
  public void shutdown() {
    while (true) {
      CompletableFuture<Void> activeSave;
      synchronized (saveLock) {
        retryGeneration++;
        activeSave = saveWorkerScheduled ? pendingSave : null;
      }
      awaitPendingSave(activeSave);

      Properties queued;
      long saveVersion;
      synchronized (saveLock) {
        queued = queuedSnapshot == null ? null : copy(queuedSnapshot);
        if (queued == null) {
          if (!saveWorkerScheduled) {
            return;
          }
          continue;
        }
        saveVersion = asyncSaveVersion;
        synchronousSaveInProgress = true;
      }

      boolean persisted = false;
      try {
        writeSnapshot(queued);
        persisted = true;
      } catch (RuntimeException exception) {
        logger.log(Level.SEVERE, "Unable to flush queued SQL economy balance snapshot", exception);
      } finally {
        synchronized (saveLock) {
          if (persisted && asyncSaveVersion == saveVersion) {
            queuedSnapshot = null;
            consecutiveFailures = 0;
          }
          synchronousSaveInProgress = false;
          if (queuedSnapshot != null && !saveWorkerScheduled) {
            scheduleSaveWorkerLocked(true);
          }
        }
      }
      if (!persisted) {
        return;
      }
    }
  }

  private void writeSnapshot(Connection connection, Properties properties) throws SQLException {
    // E-024 修复: 使用 INSERT ON DUPLICATE KEY UPDATE 而非 DELETE+INSERT 全表替换。
    // 原审计担忧批量 INSERT 中途抛 SQLException 导致全表已空——ON DUPLICATE KEY UPDATE
    // 每行独立原子，不存在全表清空风险，无需事务回滚。若某行 accountId 超长（VARCHAR(64)
    // 限制），PreparedStatement 会在该行抛 SQLException，事务回滚可恢复，其他行正常写入。
    boolean previousAutoCommit = connection.getAutoCommit();
    connection.setAutoCommit(false);
    try (PreparedStatement upsert = connection.prepareStatement(upsertSql(connection))) {
      for (String accountId : properties.stringPropertyNames()) {
        upsert.setString(1, accountId);
        upsert.setString(2, properties.getProperty(accountId));
        upsert.addBatch();
      }
      upsert.executeBatch();
      connection.commit();
    } catch (Exception exception) {
      connection.rollback();
      throw exception;
    } finally {
      connection.setAutoCommit(previousAutoCommit);
    }
  }

  private String upsertSql(Connection connection) throws SQLException {
    String database = connection.getMetaData().getDatabaseProductName();
    if ("SQLite".equalsIgnoreCase(database)) {
      return
      """
      INSERT INTO starcore_player_balances (account_id, balance)
      VALUES (?, ?)
      ON CONFLICT(account_id) DO UPDATE SET balance = excluded.balance
      """;
    }
    if ("MySQL".equalsIgnoreCase(database) || "MariaDB".equalsIgnoreCase(database)) {
      return
      """
      INSERT INTO starcore_player_balances (account_id, balance)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE balance = VALUES(balance)
      """;
    }
    throw new SQLException("Unsupported database for economy balance upsert: " + database);
  }

  private Connection openConnection() throws SQLException {
    long startedAtNanos = System.nanoTime();
    try {
      DataSource dataSource =
          dataSourceSupplier
              .get()
              .orElseThrow(() -> new IllegalStateException("STARCORE database is not running"));
      return dataSource.getConnection();
    } finally {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.SQL_CONNECTION_ACQUIRE,
          System.nanoTime() - startedAtNanos);
    }
  }

  private void awaitPendingSave(CompletableFuture<Void> future) {
    if (future == null) {
      return;
    }
    try {
      future.join();
    } catch (RuntimeException exception) {
      logger.log(Level.SEVERE, "Unable to finish queued SQL economy balance save", exception);
    }
  }

  private static Properties copy(Properties source) {
    Properties properties = new Properties();
    properties.putAll(source);
    return properties;
  }
}
