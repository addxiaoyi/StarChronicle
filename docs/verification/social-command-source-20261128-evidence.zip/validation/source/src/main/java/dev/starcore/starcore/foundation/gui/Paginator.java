package dev.starcore.starcore.foundation.gui;

import java.util.List;

public final class Paginator<T> {

    private final List<T> items;
    private final int pageSize;

    public Paginator(List<T> items, int pageSize) {
        this.items = items == null ? List.of() : List.copyOf(items);
        this.pageSize = Math.max(1, pageSize);
    }

    public int totalSize() {
        return items.size();
    }

    public int pageCount() {
        if (items.isEmpty()) {
            return 1;
        }
        return (items.size() + pageSize - 1) / pageSize;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public int clampPage(int page) {
        int last = pageCount() - 1;
        if (page < 0) {
            return 0;
        }
        return Math.min(page, last);
    }

    public List<T> page(int page) {
        if (items.isEmpty()) {
            return List.of();
        }
        int safe = clampPage(page);
        int from = safe * pageSize;
        int to = Math.min(from + pageSize, items.size());
        return List.copyOf(items.subList(from, to));
    }

    public boolean hasPrev(int page) {
        return clampPage(page) > 0;
    }

    public boolean hasNext(int page) {
        return clampPage(page) < pageCount() - 1;
    }
}
