package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.core.metrics.PerformanceMetricsService;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.ServicePriority;

/**
 * PlayerVaultEconomyService - Vault 经济集成实现 使用 Vault API 访问第三方经济插件（如 EssentialsX） 当 Vault Economy
 * 服务不可用时返回默认值并记录警告
 */
public final class PlayerVaultEconomyService implements EconomyService {

  private static final BigDecimal ZERO = BigDecimal.ZERO;
  private static final String PROVIDER_LOOKUP_FAILURE_CODE = "VAULT_PROVIDER_LOOKUP_FAILURE";
  private static final String PROVIDER_RESOLUTION_FAILURE_CODE =
      "VAULT_PROVIDER_RESOLUTION_FAILURE";
  private static final String PROVIDER_CANDIDATE_RESOLUTION_FAILURE_CODE =
      "VAULT_PROVIDER_CANDIDATE_RESOLUTION_FAILURE";
  private static final String PROVIDER_PRIORITY_RESOLUTION_FAILURE_CODE =
      "VAULT_PROVIDER_PRIORITY_RESOLUTION_FAILURE";
  private static final String PROVIDER_FALLBACK_RESOLUTION_FAILURE_CODE =
      "VAULT_PROVIDER_FALLBACK_RESOLUTION_FAILURE";
  private static final String BALANCE_READ_FAILURE_CODE = "VAULT_BALANCE_READ_FAILURE";
  private static final String BALANCE_TIMEOUT_CODE = "VAULT_BALANCE_TIMEOUT";
  private static final String BALANCE_CHECK_FAILURE_CODE = "VAULT_BALANCE_CHECK_FAILURE";
  private static final String DEPOSIT_FAILURE_CODE = "VAULT_DEPOSIT_FAILURE";
  private static final String WITHDRAW_FAILURE_CODE = "VAULT_WITHDRAW_FAILURE";
  private static final String SET_BALANCE_FAILURE_CODE = "VAULT_SET_BALANCE_FAILURE";
  private static final String ACCOUNT_CHECK_FAILURE_CODE = "VAULT_ACCOUNT_CHECK_FAILURE";
  private static final String ACCOUNT_CREATE_FAILURE_CODE = "VAULT_ACCOUNT_CREATE_FAILURE";
  private static final String SNAPSHOT_ENUMERATION_FAILURE_CODE =
      "VAULT_BALANCE_SNAPSHOT_ENUMERATION_FAILURE";
  private static final String SNAPSHOT_PLAYER_RESOLUTION_FAILURE_CODE =
      "VAULT_BALANCE_SNAPSHOT_PLAYER_RESOLUTION_FAILURE";
  private static final String SNAPSHOT_BALANCE_READ_FAILURE_CODE =
      "VAULT_BALANCE_SNAPSHOT_READ_FAILURE";
  private static final String PLAYER_RESOLUTION_FAILURE_CODE = "VAULT_PLAYER_RESOLUTION_FAILURE";
  private static final String BALANCE_METRIC_SUCCESS = "economy.vault.getBalance.success";
  private static final String BALANCE_METRIC_FAILURE = "economy.vault.getBalance.failure";
  private static final String BALANCE_METRIC_TIMEOUT = "economy.vault.getBalance.timeout";
  private final Logger logger;
  private final PerformanceMetricsService performanceMetrics;
  private final long providerTimeoutMillis;

  /** audit B-013: 仅记录一次 Vault provider 名，避免每次资金操作刷屏日志 */
  private volatile String loggedProviderName;

  private volatile Economy loggedProvider;
  private volatile boolean providerUnavailableLogged;
  private final Set<UUID> observedPlayerIds = ConcurrentHashMap.newKeySet();
  private final AtomicLong txSeq = new AtomicLong();

  private enum TransferFailureCode {
    WITHDRAW_FAILURE("VAULT_TRANSFER_WITHDRAW_FAILURE"),
    WITHDRAW_EXCEPTION("VAULT_TRANSFER_WITHDRAW_EXCEPTION"),
    RECIPIENT_DEPOSIT_FAILURE("VAULT_TRANSFER_RECIPIENT_DEPOSIT_FAILURE"),
    RECIPIENT_DEPOSIT_EXCEPTION("VAULT_TRANSFER_RECIPIENT_DEPOSIT_EXCEPTION"),
    ROLLBACK_FAILURE("VAULT_TRANSFER_ROLLBACK_FAILURE"),
    ROLLBACK_EXCEPTION("VAULT_TRANSFER_ROLLBACK_EXCEPTION");

    private final String value;

    TransferFailureCode(String value) {
      this.value = value;
    }
  }

  private record ProviderCandidate(
      org.bukkit.plugin.RegisteredServiceProvider<Economy> registration, int priority) {}

  public PlayerVaultEconomyService(Logger logger) {
    this(logger, null);
  }

  public PlayerVaultEconomyService(
      Logger logger, PerformanceMetricsService performanceMetrics) {
    this(logger, performanceMetrics, 0L);
  }

  public PlayerVaultEconomyService(
      Logger logger, PerformanceMetricsService performanceMetrics, long providerTimeoutMillis) {
    this.logger = logger;
    this.performanceMetrics = performanceMetrics;
    this.providerTimeoutMillis = Math.max(0L, Math.min(providerTimeoutMillis, 300_000L));
  }

  private Economy getVaultEconomy() {
    final org.bukkit.plugin.RegisteredServiceProvider<Economy> registration;
    try {
      org.bukkit.plugin.ServicesManager servicesManager = Bukkit.getServicesManager();
      registration = selectExternalRegistration(servicesManager);
    } catch (RuntimeException exception) {
      markProviderUnavailable(
          "code="
              + PROVIDER_LOOKUP_FAILURE_CODE
              + " operation=provider-lookup txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + exception.getClass().getName(),
          exception);
      return null;
    }
    if (registration == null) {
      markProviderUnavailable(
          "No external Vault Economy provider is registered; economy operations fail closed.");
      return null;
    }

    final Economy economy;
    try {
      economy = registration.getProvider();
    } catch (RuntimeException exception) {
      markProviderUnavailable(
          "code="
              + PROVIDER_RESOLUTION_FAILURE_CODE
              + " operation=provider-resolution txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + exception.getClass().getName(),
          exception);
      return null;
    }
    if (economy == null || isStarCoreProvider(economy)) {
      markProviderUnavailable("Vault Economy registration did not contain an external provider.");
      return null;
    }

    String providerName = providerName(economy);
    Economy previousProvider = loggedProvider;
    String previousName = loggedProviderName;
    if (economy != previousProvider || !providerName.equals(previousName)) {
      loggedProvider = economy;
      loggedProviderName = providerName;
      providerUnavailableLogged = false;
      if (logger != null) {
        logger.info(
            previousProvider == null
                ? "Vault Economy provider found: " + providerName
                : "Vault Economy provider switched: " + previousName + " -> " + providerName);
      }
    }
    return economy;
  }

  private org.bukkit.plugin.RegisteredServiceProvider<Economy> selectExternalRegistration(
      org.bukkit.plugin.ServicesManager servicesManager) {
    if (servicesManager == null) {
      return null;
    }
    java.util.Collection<org.bukkit.plugin.RegisteredServiceProvider<Economy>> registrations =
        servicesManager.getRegistrations(Economy.class);
    if (registrations != null && !registrations.isEmpty()) {
      return registrations.stream()
          .filter(java.util.Objects::nonNull)
          .map(
              registration -> {
                final Economy provider;
                try {
                  provider = registration.getProvider();
                } catch (RuntimeException exception) {
                  logProviderResolutionFailure(
                      PROVIDER_CANDIDATE_RESOLUTION_FAILURE_CODE, exception);
                  return null;
                }
                if (provider == null || isStarCoreProvider(provider)) {
                  return null;
                }
                final ServicePriority priority;
                try {
                  priority = registration.getPriority();
                } catch (RuntimeException exception) {
                  logProviderResolutionFailure(
                      PROVIDER_PRIORITY_RESOLUTION_FAILURE_CODE, exception);
                  return null;
                }
                if (priority == null) {
                  logProviderResolutionFailure(
                      PROVIDER_PRIORITY_RESOLUTION_FAILURE_CODE,
                      new IllegalStateException("Vault provider priority was null"));
                  return null;
                }
                return new ProviderCandidate(registration, priority.ordinal());
              })
          .filter(java.util.Objects::nonNull)
          .max(java.util.Comparator.comparingInt(ProviderCandidate::priority))
          .map(ProviderCandidate::registration)
          .orElse(null);
    }
    org.bukkit.plugin.RegisteredServiceProvider<Economy> fallback =
        servicesManager.getRegistration(Economy.class);
    if (fallback == null) {
      return null;
    }
    try {
      Economy provider = fallback.getProvider();
      return provider == null || isStarCoreProvider(provider) ? null : fallback;
    } catch (RuntimeException exception) {
      logProviderResolutionFailure(PROVIDER_FALLBACK_RESOLUTION_FAILURE_CODE, exception);
      return null;
    }
  }

  private boolean isStarCoreProvider(Economy economy) {
    return economy
        .getClass()
        .getName()
        .equals("dev.starcore.starcore.integration.vault.VaultEconomyProvider");
  }

  private String providerName(Economy economy) {
    try {
      String name = economy.getName();
      return name == null || name.isBlank() ? economy.getClass().getName() : name;
    } catch (RuntimeException exception) {
      return economy.getClass().getName();
    }
  }

  private void markProviderUnavailable(String message) {
    markProviderUnavailable(message, null);
  }

  private void markProviderUnavailable(String message, Throwable cause) {
    loggedProvider = null;
    loggedProviderName = null;
    if (!providerUnavailableLogged && logger != null) {
      providerUnavailableLogged = true;
      if (cause == null) {
        logger.warning(message);
      } else {
        logger.log(Level.WARNING, message, cause);
      }
    }
  }

  private OfflinePlayer getOfflinePlayer(UUID playerId) {
    if (playerId == null) {
      return null;
    }
    observedPlayerIds.add(playerId);
    try {
      return Bukkit.getOfflinePlayer(playerId);
    } catch (RuntimeException exception) {
      logOperationFailure(PLAYER_RESOLUTION_FAILURE_CODE, "getOfflinePlayer", playerId, exception);
      return null;
    }
  }

  private static boolean isSupportedAmount(BigDecimal amount, boolean allowZero) {
    if (amount == null || amount.signum() < 0 || (!allowZero && amount.signum() == 0)) {
      return false;
    }
    double vaultAmount = amount.doubleValue();
    if (!Double.isFinite(vaultAmount)) {
      return false;
    }
    return amount.signum() == 0 || vaultAmount > 0.0D;
  }

  @Override
  public BigDecimal getBalance(UUID playerId) {
    long startedAt = System.nanoTime();
    String metric = BALANCE_METRIC_FAILURE;
    try {
      Economy economy = getVaultEconomy();
      if (economy == null) {
        return ZERO;
      }
      OfflinePlayer player = getOfflinePlayer(playerId);
      if (player == null) {
        return ZERO;
      }
      try {
        BigDecimal balance = BigDecimal.valueOf(readBalance(economy, player));
        metric = BALANCE_METRIC_SUCCESS;
        return balance;
      } catch (ProviderTimeoutException e) {
        metric = BALANCE_METRIC_TIMEOUT;
        logOperationFailure(BALANCE_TIMEOUT_CODE, "getBalance", playerId, e);
        return ZERO;
      } catch (RuntimeException e) {
        logOperationFailure(BALANCE_READ_FAILURE_CODE, "getBalance", playerId, e);
        return ZERO;
      }
    } finally {
      recordBalanceMetric(metric, startedAt);
    }
  }

  private double readBalance(Economy economy, OfflinePlayer player) {
    if (providerTimeoutMillis <= 0L) {
      return economy.getBalance(player);
    }
    CompletableFuture<Double> request =
        CompletableFuture.supplyAsync(() -> economy.getBalance(player));
    try {
      return request.get(providerTimeoutMillis, TimeUnit.MILLISECONDS);
    } catch (TimeoutException exception) {
      request.cancel(true);
      throw new ProviderTimeoutException(exception);
    } catch (InterruptedException exception) {
      request.cancel(true);
      Thread.currentThread().interrupt();
      throw new ProviderTimeoutException(exception);
    } catch (ExecutionException exception) {
      Throwable cause = exception.getCause();
      if (cause instanceof RuntimeException runtimeException) {
        throw runtimeException;
      }
      throw new RuntimeException(cause);
    }
  }

  private void recordBalanceMetric(String metric, long startedAt) {
    if (performanceMetrics == null) {
      return;
    }
    try {
      performanceMetrics.recordOperation(
          metric, System.nanoTime() - startedAt);
    } catch (RuntimeException metricFailure) {
      if (logger != null) {
        logger.log(Level.FINE, "Vault balance metric recording failed", metricFailure);
      }
    }
  }

  private static final class ProviderTimeoutException extends RuntimeException {
    private ProviderTimeoutException(Throwable cause) {
      super(cause);
    }
  }

  @Override
  public boolean has(UUID playerId, BigDecimal amount) {
    if (!isSupportedAmount(amount, true)) {
      return false;
    }
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return false;
    }
    try {
      // audit B-012: 避免直接用 amount.doubleValue() 调用 Vault.has 而丢失大数精度；
      // 改为取出余额 BigDecimal 比较，避免 BigDecimal->double 转换误差
      BigDecimal current =
          BigDecimal.valueOf(economy.getBalance(player)).setScale(2, java.math.RoundingMode.DOWN);
      return current.compareTo(amount) >= 0;
    } catch (RuntimeException e) {
      logOperationFailure(BALANCE_CHECK_FAILURE_CODE, "has", playerId, e);
      return false;
    }
  }

  @Override
  public boolean deposit(UUID playerId, BigDecimal amount) {
    if (!isSupportedAmount(amount, false)) {
      return false;
    }
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return false;
    }
    try {
      EconomyResponse response = economy.depositPlayer(player, amount.doubleValue());
      return response.type == EconomyResponse.ResponseType.SUCCESS;
    } catch (RuntimeException e) {
      logOperationFailure(DEPOSIT_FAILURE_CODE, "deposit", playerId, amount, e);
      return false;
    }
  }

  @Override
  public boolean withdraw(UUID playerId, BigDecimal amount) {
    if (!isSupportedAmount(amount, false)) {
      return false;
    }
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return false;
    }
    try {
      EconomyResponse response = economy.withdrawPlayer(player, amount.doubleValue());
      return response.type == EconomyResponse.ResponseType.SUCCESS;
    } catch (RuntimeException e) {
      logOperationFailure(WITHDRAW_FAILURE_CODE, "withdraw", playerId, amount, e);
      return false;
    }
  }

  @Override
  public boolean setBalance(UUID playerId, BigDecimal amount) {
    // Vault Economy 不直接支持设置余额，需要通过差额计算
    if (!isSupportedAmount(amount, true)) {
      return false;
    }
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return false;
    }
    try {
      BigDecimal currentBalance = BigDecimal.valueOf(economy.getBalance(player));
      BigDecimal diff = amount.subtract(currentBalance);

      if (diff.signum() > 0) {
        // 需要存款
        double vaultAmount = diff.doubleValue();
        if (!Double.isFinite(vaultAmount) || vaultAmount <= 0.0D) {
          return false;
        }
        return successful(economy.depositPlayer(player, vaultAmount));
      } else if (diff.signum() < 0) {
        // 需要取款
        double vaultAmount = diff.abs().doubleValue();
        if (!Double.isFinite(vaultAmount) || vaultAmount <= 0.0D) {
          return false;
        }
        return successful(economy.withdrawPlayer(player, vaultAmount));
      }
      // 余额相同，无需操作
      return true;
    } catch (RuntimeException e) {
      logOperationFailure(SET_BALANCE_FAILURE_CODE, "setBalance", playerId, e);
      return false;
    }
  }

  @Override
  public synchronized boolean transfer(UUID from, UUID to, BigDecimal amount) {
    if (!isSupportedAmount(amount, false) || from == null || to == null) {
      return false;
    }
    if (from.equals(to)) {
      return false;
    }
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    double vaultAmount = amount.doubleValue();
    if (!Double.isFinite(vaultAmount) || vaultAmount <= 0.0D) {
      return false;
    }
    OfflinePlayer fromPlayer = getOfflinePlayer(from);
    OfflinePlayer toPlayer = getOfflinePlayer(to);
    if (fromPlayer == null || toPlayer == null) {
      return false;
    }

    final EconomyResponse withdrawResponse;
    try {
      withdrawResponse = economy.withdrawPlayer(fromPlayer, vaultAmount);
    } catch (RuntimeException exception) {
      logTransferFailure(
          TransferFailureCode.WITHDRAW_EXCEPTION,
          from,
          to,
          amount,
          exception.getMessage(),
          exception,
          txSeq.incrementAndGet());
      return false;
    }
    if (!successful(withdrawResponse)) {
      logTransferFailure(
          TransferFailureCode.WITHDRAW_FAILURE,
          from,
          to,
          amount,
          responseMessage(withdrawResponse),
          txSeq.incrementAndGet());
      return false;
    }

    try {
      EconomyResponse depositResponse = economy.depositPlayer(toPlayer, vaultAmount);
      if (successful(depositResponse)) {
        return true;
      }
      logTransferFailure(
          TransferFailureCode.RECIPIENT_DEPOSIT_FAILURE,
          from,
          to,
          amount,
          responseMessage(depositResponse),
          txSeq.incrementAndGet());
      rollbackTransferDebit(
          economy, fromPlayer, from, to, amount, vaultAmount, "recipient deposit returned failure");
      return false;
    } catch (RuntimeException exception) {
      logTransferFailure(
          TransferFailureCode.RECIPIENT_DEPOSIT_EXCEPTION,
          from,
          to,
          amount,
          exception.getMessage(),
          exception,
          txSeq.incrementAndGet());
      rollbackTransferDebit(
          economy, fromPlayer, from, to, amount, vaultAmount, "recipient deposit threw");
      return false;
    }
  }

  private boolean successful(EconomyResponse response) {
    return response != null && response.type == EconomyResponse.ResponseType.SUCCESS;
  }

  private String responseMessage(EconomyResponse response) {
    if (response == null) {
      return "null response";
    }
    return response.errorMessage == null ? String.valueOf(response.type) : response.errorMessage;
  }

  private void rollbackTransferDebit(
      Economy economy,
      OfflinePlayer fromPlayer,
      UUID from,
      UUID to,
      BigDecimal amount,
      double vaultAmount,
      String reason) {
    try {
      EconomyResponse rollbackResponse = economy.depositPlayer(fromPlayer, vaultAmount);
      if (successful(rollbackResponse)) {
        return;
      }
      logTransferFailure(
          TransferFailureCode.ROLLBACK_FAILURE,
          from,
          to,
          amount,
          reason + ": " + responseMessage(rollbackResponse),
          txSeq.incrementAndGet());
    } catch (RuntimeException exception) {
      logTransferFailure(
          TransferFailureCode.ROLLBACK_EXCEPTION,
          from,
          to,
          amount,
          reason + ": " + exception.getMessage(),
          exception,
          txSeq.incrementAndGet());
    }
    if (logger != null) {
      logger.severe(
          "[Economy] CRITICAL code=VAULT_TRANSFER_ROLLBACK_FAILURE: rollback failed after "
              + reason
              + ". from="
              + from
              + " to="
              + to
              + " amount="
              + amount
              + " txId="
              + txSeq.incrementAndGet()
              + "; payer may have lost funds and requires reconciliation.");
    }
  }

  private void logTransferFailure(
      TransferFailureCode code,
      UUID from,
      UUID to,
      BigDecimal amount,
      String detail,
      long transferId) {
    logTransferFailure(code, from, to, amount, detail, null, transferId);
  }

  private void logTransferFailure(
      TransferFailureCode code,
      UUID from,
      UUID to,
      BigDecimal amount,
      String detail,
      Throwable cause,
      long transferId) {
    if (logger != null) {
      String message =
          "Vault transfer failed. code="
              + code.value
              + ". op=transfer from="
              + from
              + " to="
              + to
              + " amount="
              + amount
              + " txId="
              + transferId
              + ": "
              + detail;
      if (cause == null) {
        logger.warning(message);
      } else {
        logger.log(Level.WARNING, message, cause);
      }
    }
  }

  private void logOperationFailure(
      String code, String op, UUID playerId, BigDecimal amount, RuntimeException failure) {
    if (logger != null) {
      logger.log(
          Level.WARNING,
          "Vault economy operation failed. code="
              + code
              + " op="
              + op
              + " player="
              + playerId
              + " amount="
              + amount
              + " txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + failure.getClass().getName(),
          failure);
    }
  }

  private void logOperationFailure(
      String code, String op, UUID playerId, RuntimeException failure) {
    logOperationFailure(code, op, playerId, null, failure);
  }

  private void logProviderResolutionFailure(String code, RuntimeException failure) {
    if (logger != null) {
      providerUnavailableLogged = true;
      logger.log(
          Level.WARNING,
          "Vault provider resolution failed. code="
              + code
              + " op=provider-resolution txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + failure.getClass().getName(),
          failure);
    }
  }

  @Override
  public Map<UUID, BigDecimal> getAllBalances() {
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return Map.of();
    }

    Map<UUID, OfflinePlayer> candidates = new LinkedHashMap<>();
    try {
      OfflinePlayer[] knownPlayers = Bukkit.getOfflinePlayers();
      if (knownPlayers != null) {
        for (OfflinePlayer player : knownPlayers) {
          try {
            if (player != null && player.getUniqueId() != null) {
              candidates.putIfAbsent(player.getUniqueId(), player);
            }
          } catch (RuntimeException exception) {
            logOperationFailure(
                SNAPSHOT_PLAYER_RESOLUTION_FAILURE_CODE, "snapshot-player", null, exception);
          }
        }
      }
    } catch (RuntimeException exception) {
      logOperationFailure(
          SNAPSHOT_ENUMERATION_FAILURE_CODE, "snapshot-enumeration", null, exception);
    }

    for (UUID playerId : observedPlayerIds) {
      if (candidates.containsKey(playerId)) {
        continue;
      }
      try {
        OfflinePlayer player = Bukkit.getOfflinePlayer(playerId);
        if (player != null) {
          candidates.put(playerId, player);
        }
      } catch (RuntimeException exception) {
        logOperationFailure(
            SNAPSHOT_PLAYER_RESOLUTION_FAILURE_CODE, "snapshot-player", playerId, exception);
      }
    }
    if (candidates.isEmpty()) {
      return Map.of();
    }

    Map<UUID, BigDecimal> balances = new LinkedHashMap<>();
    for (Map.Entry<UUID, OfflinePlayer> candidate : candidates.entrySet()) {
      UUID playerId = candidate.getKey();
      OfflinePlayer player = candidate.getValue();
      if (playerId == null || player == null) {
        continue;
      }
      try {
        if (economy.hasAccount(player)) {
          balances.put(playerId, BigDecimal.valueOf(economy.getBalance(player)));
        }
      } catch (RuntimeException exception) {
        logOperationFailure(
            SNAPSHOT_BALANCE_READ_FAILURE_CODE, "snapshot-balance-read", playerId, exception);
      }
    }
    return Map.copyOf(balances);
  }

  /** 检查此服务是否支持特定功能。 */
  public boolean isFeatureSupported(Feature feature) {
    Objects.requireNonNull(feature, "feature");
    return switch (feature) {
      case BATCH_BALANCE_QUERY, BALANCE_SET, TRANSFER -> true;
      case DAILY_LIMIT, TAX -> false;
    };
  }

  /** 经济服务支持的特性枚举 */
  public enum Feature {
    BATCH_BALANCE_QUERY, // getAllBalances()
    BALANCE_SET, // setBalance()
    TRANSFER, // transfer()
    DAILY_LIMIT, // 每日限额
    TAX // 税率
  }

  @Override
  public boolean hasAccount(UUID playerId) {
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return false;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return false;
    }
    try {
      return economy.hasAccount(player);
    } catch (RuntimeException e) {
      logOperationFailure(ACCOUNT_CHECK_FAILURE_CODE, "hasAccount", playerId, e);
      return false;
    }
  }

  @Override
  public void createAccount(UUID playerId) {
    Economy economy = getVaultEconomy();
    if (economy == null) {
      return;
    }
    OfflinePlayer player = getOfflinePlayer(playerId);
    if (player == null) {
      return;
    }
    try {
      economy.createPlayerAccount(player);
    } catch (RuntimeException e) {
      logOperationFailure(ACCOUNT_CREATE_FAILURE_CODE, "createAccount", playerId, e);
    }
  }
}
