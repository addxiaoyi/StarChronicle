package dev.starcore.starcore.foundation.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/** {@link ConfirmationMenu} 的点击监听器。 现代化版本 - 支持确认/取消/返回三种操作 */
public final class ConfirmationMenuListener implements Listener {

  private static final int SLOT_CONFIRM = 15;
  private static final int SLOT_CANCEL = 19;
  private static final int SLOT_BACK = 22;

  @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
  public void onClick(InventoryClickEvent event) {
    InventoryHolder holder = event.getInventory().getHolder();
    if (!(holder instanceof ConfirmationMenu menu)) return;

    event.setCancelled(true);

    if (!(event.getWhoClicked() instanceof Player player)) return;

    if (event.getClickedInventory() == null
        || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
      return;
    }

    int slot = event.getRawSlot();
    switch (slot) {
      case SLOT_CONFIRM -> {
        menu.handleConfirm(player);
        player.closeInventory();
      }
      case SLOT_CANCEL, SLOT_BACK -> {
        menu.handleCancel(player);
        player.closeInventory();
      }
    }
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof ConfirmationMenu) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onClose(InventoryCloseEvent event) {
    if (event.getInventory().getHolder() instanceof ConfirmationMenu menu) {
      if (event.getPlayer() instanceof Player player) {
        menu.handleCancel(player);
      }
    }
  }
}
