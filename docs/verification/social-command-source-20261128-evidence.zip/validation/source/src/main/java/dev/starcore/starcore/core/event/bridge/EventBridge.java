package dev.starcore.starcore.core.event.bridge;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/** 事件桥接器 连接不同的事件系统，实现跨模块事件传递 */
public class EventBridge {

  private static final Logger LOGGER = Logger.getLogger(EventBridge.class.getName());

  private final Map<String, BridgeEndpoint> endpoints = new ConcurrentHashMap<>();
  private final Map<String, List<BridgeMapping>> mappings = new ConcurrentHashMap<>();
  private final Map<String, Consumer<Object>> defaultHandlers = new ConcurrentHashMap<>();

  /** 注册端点 */
  public void registerEndpoint(String endpointId, BridgeEndpoint endpoint) {
    endpoints.put(Objects.requireNonNull(endpointId), Objects.requireNonNull(endpoint));
  }

  /** 注销端点 */
  public void unregisterEndpoint(String endpointId) {
    endpoints.remove(endpointId);
    mappings.remove(endpointId);
  }

  /** 创建事件映射 */
  public void mapEvents(
      String sourceEndpointId,
      String targetEndpointId,
      String eventType,
      EventTransformer transformer) {
    BridgeMapping mapping =
        new BridgeMapping(sourceEndpointId, targetEndpointId, eventType, transformer);

    mappings.computeIfAbsent(sourceEndpointId, k -> new ArrayList<>()).add(mapping);
  }

  /** 广播事件到所有注册的端点 */
  public void broadcastEvent(String eventType, Object event) {
    for (BridgeEndpoint endpoint : endpoints.values()) {
      try {
        if (endpoint.canHandle(eventType)) {
          endpoint.handle(eventType, event);
        }
      } catch (Exception e) {
        LOGGER.log(
            Level.SEVERE,
            "Error broadcasting event to endpoint. EventType: '"
                + eventType
                + "', EndpointId: '"
                + endpoint.getId()
                + "'",
            e);
      }
    }
  }

  /** 将事件路由到指定端点 */
  public boolean routeEvent(String targetEndpointId, String eventType, Object event) {
    BridgeEndpoint endpoint = endpoints.get(targetEndpointId);
    if (endpoint == null) {
      return false;
    }

    try {
      if (endpoint.canHandle(eventType)) {
        endpoint.handle(eventType, event);
        return true;
      }
    } catch (Exception e) {
      LOGGER.log(
          Level.SEVERE,
          "Error routing event to endpoint. EventType: '"
              + eventType
              + "', TargetEndpointId: '"
              + targetEndpointId
              + "'",
          e);
    }

    return false;
  }

  /** 将事件从源端点转发到目标端点 */
  @SuppressWarnings("unchecked")
  public void forwardEvent(String sourceEndpointId, String eventType, Object event) {
    List<BridgeMapping> mappings = this.mappings.get(sourceEndpointId);
    if (mappings == null) return;

    for (BridgeMapping mapping : mappings) {
      if (mapping.eventType().equals(eventType)) {
        // 应用转换器转换事件
        Object transformedEvent = event;
        if (mapping.transformer() != null) {
          try {
            transformedEvent = mapping.transformer().transform(event);
          } catch (Exception e) {
            LOGGER.log(
                Level.SEVERE,
                "Error transforming event in forwardEvent. EventType: '"
                    + eventType
                    + "', SourceEndpointId: '"
                    + sourceEndpointId
                    + "', TargetEndpointId: '"
                    + mapping.targetEndpointId()
                    + "', EventData: "
                    + (event != null ? event.getClass().getName() : "null"),
                e);
            continue; // 跳过此映射
          }
        }

        // 发送到目标端点
        BridgeEndpoint targetEndpoint = endpoints.get(mapping.targetEndpointId());
        if (targetEndpoint != null && targetEndpoint.canHandle(eventType)) {
          try {
            targetEndpoint.handle(eventType, transformedEvent);
          } catch (Exception e) {
            LOGGER.log(
                Level.SEVERE,
                "Error forwarding event to target endpoint. EventType: '"
                    + eventType
                    + "', SourceEndpointId: '"
                    + sourceEndpointId
                    + "', TargetEndpointId: '"
                    + mapping.targetEndpointId()
                    + "'",
                e);
          }
        }
      }
    }
  }

  /** 获取所有端点 */
  public Collection<BridgeEndpoint> getEndpoints() {
    return List.copyOf(endpoints.values());
  }

  /** 获取端点 */
  public Optional<BridgeEndpoint> getEndpoint(String endpointId) {
    return Optional.ofNullable(endpoints.get(endpointId));
  }

  /** 检查端点是否存在 */
  public boolean hasEndpoint(String endpointId) {
    return endpoints.containsKey(endpointId);
  }

  /** 获取所有映射 */
  public List<BridgeMapping> getMappings(String sourceEndpointId) {
    return mappings.getOrDefault(sourceEndpointId, Collections.emptyList());
  }

  /** 添加默认处理器 */
  public void addDefaultHandler(String eventType, Consumer<Object> handler) {
    defaultHandlers.put(eventType, handler);
  }

  /** 移除默认处理器 */
  public void removeDefaultHandler(String eventType) {
    defaultHandlers.remove(eventType);
  }

  /** 处理事件 */
  public void processEvent(String eventType, Object event) {
    Consumer<Object> handler = defaultHandlers.get(eventType);
    if (handler != null) {
      handler.accept(event);
    }
  }

  /** 清除所有端点和映射 */
  public void clear() {
    endpoints.clear();
    mappings.clear();
    defaultHandlers.clear();
  }

  /** 端点接口 表示一个可以接收和处理事件的系统 */
  public interface BridgeEndpoint {
    /** 获取端点ID */
    String getId();

    /** 检查是否可以处理指定类型的事件 */
    boolean canHandle(String eventType);

    /** 处理事件 */
    void handle(String eventType, Object event);
  }

  /** 事件转换器 用于在桥接时转换事件格式 */
  @FunctionalInterface
  public interface EventTransformer {
    Object transform(Object originalEvent);
  }

  /** 桥接映射 */
  public record BridgeMapping(
      String sourceEndpointId,
      String targetEndpointId,
      String eventType,
      EventTransformer transformer) {}
}
