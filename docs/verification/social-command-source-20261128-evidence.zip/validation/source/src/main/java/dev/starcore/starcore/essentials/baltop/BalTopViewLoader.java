package dev.starcore.starcore.essentials.baltop;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.logging.Level;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** Bounded name resolution and provider-specific reads for one original viewer session. */
public final class BalTopViewLoader {
  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final BooleanSupplier lifetime;
  private final BalTopService rankings;
  private final EconomyService economy;

  public BalTopViewLoader(
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      BooleanSupplier lifetime,
      BalTopService rankings,
      EconomyService economy) {
    this.plugin = Objects.requireNonNull(plugin);
    this.scheduler = Objects.requireNonNull(scheduler);
    this.lifetime = Objects.requireNonNull(lifetime);
    this.rankings = Objects.requireNonNull(rankings);
    this.economy = Objects.requireNonNull(economy);
  }

  /** Invoke on viewer's owner. current only reads detached request state on other executors. */
  public void load(
      Player viewer,
      int page,
      boolean refresh,
      BooleanSupplier current,
      Consumer<BalTopView> loaded,
      Consumer<String> failed) {
    load(viewer, page, refresh, current, loaded, failed, () -> {});
  }

  /** abandoned only releases detached request state; it may run on any executor. */
  public void load(
      Player viewer,
      int page,
      boolean refresh,
      BooleanSupplier current,
      Consumer<BalTopView> loaded,
      Consumer<String> failed,
      Runnable abandoned) {
    AtomicBoolean released = new AtomicBoolean();
    Runnable release =
        () -> {
          if (released.compareAndSet(false, true)) abandoned.run();
        };
    BooleanSupplier valid =
        () -> {
          if (lifetime.getAsBoolean() && plugin.isEnabled() && current.getAsBoolean()) return true;
          release.run();
          return false;
        };
    loadActive(viewer, page, refresh, valid, loaded, failed, release);
  }

  private void loadActive(
      Player viewer,
      int page,
      boolean refresh,
      BooleanSupplier current,
      Consumer<BalTopView> loaded,
      Consumer<String> failed,
      Runnable abandoned) {
    UUID viewerId = viewer.getUniqueId();
    AtomicBoolean finished = new AtomicBoolean();
    Consumer<String> fail =
        reason -> {
          if (finished.compareAndSet(false, true))
            owned(viewer, current, () -> failed.accept(reason), abandoned);
        };
    Consumer<BalTopView> finish =
        view -> {
          if (finished.compareAndSet(false, true))
            owned(viewer, current, () -> loaded.accept(view), abandoned);
        };
    if (!active(current)) return;
    if (!(economy instanceof InternalEconomyService) && scheduler.isFolia()) {
      fail.accept("当前经济服务暂不支持此排行榜查询");
      return;
    }
    AtomicBoolean admitted = new AtomicBoolean();
    Runnable gather =
        () -> {
          if (!admitted.compareAndSet(false, true) || !active(current)) return;
          try {
            if (refresh) {
              var balances = Map.copyOf(economy.getAllBalances());
              if (!active(current)) return;
              rankings.updateRankings(balances);
            }
            var entries = rankings.getTopPlayers(100);
            var balance = economy.getBalance(viewerId);
            if (!active(current)) return;
            BalTopView view = new BalTopView(viewerId, page, entries, balance, Map.of());
            resolveNames(view, current, finish);
          } catch (RuntimeException failure) {
            log(failure);
            fail.accept("暂时无法读取排行榜，请稍后重试");
          }
        };
    try {
      if (economy instanceof InternalEconomyService) scheduler.runAsync(gather);
      else scheduler.runGlobal(gather);
    } catch (RuntimeException failure) {
      if (admitted.compareAndSet(false, true)) fail.accept("暂时无法读取排行榜，请稍后重试");
      log(failure);
    }
  }

  private void resolveNames(BalTopView view, BooleanSupplier current, Consumer<BalTopView> finish) {
    Set<UUID> needed = view.neededNames();
    if (needed.isEmpty()) {
      finish.accept(view);
      return;
    }
    Map<UUID, String> names = new ConcurrentHashMap<>();
    AtomicInteger remaining = new AtomicInteger(needed.size());
    for (UUID id : needed) {
      AtomicBoolean resolved = new AtomicBoolean();
      Consumer<String> done =
          name -> {
            if (!resolved.compareAndSet(false, true)) return;
            names.put(id, name == null || name.isBlank() ? id.toString() : name);
            if (remaining.decrementAndGet() == 0 && active(current))
              finish.accept(
                  new BalTopView(
                      view.viewerId(), view.page(), view.entries(), view.viewerBalance(), names));
          };
      Consumer<Player> online =
          player ->
              owned(player, current, () -> done.accept(player.getName()), () -> done.accept(null));
      try {
        Player player = plugin.getServer().getPlayer(id);
        if (player != null) {
          online.accept(player);
          continue;
        }
        AtomicBoolean admitted = new AtomicBoolean();
        try {
          scheduler.runAsync(
              () -> {
                if (!admitted.compareAndSet(false, true) || !active(current)) return;
                try {
                  Player now = plugin.getServer().getPlayer(id);
                  if (now != null) {
                    online.accept(now);
                    return;
                  }
                  OfflinePlayer profile = plugin.getServer().getOfflinePlayer(id);
                  if (profile instanceof Player currentPlayer) online.accept(currentPlayer);
                  else done.accept(profile == null ? null : profile.getName());
                } catch (RuntimeException failure) {
                  log(failure);
                  done.accept(null);
                }
              });
        } catch (RuntimeException failure) {
          if (admitted.compareAndSet(false, true)) done.accept(null);
          log(failure);
        }
      } catch (RuntimeException failure) {
        log(failure);
        done.accept(null);
      }
    }
  }

  private boolean active(BooleanSupplier current) {
    return current.getAsBoolean();
  }

  private void owned(
      Player player, BooleanSupplier current, Runnable action, Runnable retiredAction) {
    if (!active(current)) return;
    AtomicBoolean admitted = new AtomicBoolean();
    Runnable retired =
        () -> {
          if (admitted.compareAndSet(false, true) && active(current)) retiredAction.run();
        };
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (!admitted.compareAndSet(false, true) || !active(current)) return;
            try {
              if (plugin.getServer().getPlayer(player.getUniqueId()) == player && player.isOnline())
                action.run();
              else retiredAction.run();
            } catch (RuntimeException failure) {
              log(failure);
              retiredAction.run();
            }
          },
          retired);
    } catch (RuntimeException failure) {
      retired.run();
      log(failure);
    }
  }

  private void log(RuntimeException failure) {
    plugin.getLogger().log(Level.FINE, "Ranking view unavailable", failure);
  }
}
