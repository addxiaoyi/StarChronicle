package dev.starcore.starcore.command.helstera;

import java.util.*;
import java.util.function.Consumer;

/** 命令执行器 提供统一的命令执行接口 */
public class CommandExecutor {

  private final Map<String, SubCommand> commands;
  private final List<String> aliases;

  public CommandExecutor() {
    this.commands = new HashMap<>();
    this.aliases = new ArrayList<>();
  }

  /** 注册子命令 */
  public void registerCommand(String name, SubCommand command) {
    commands.put(name.toLowerCase(), command);
  }

  /** 注册别名 */
  public void registerAlias(String alias, String target) {
    aliases.add(alias);
    commands.put(alias.toLowerCase(), commands.get(target.toLowerCase()));
  }

  /** 执行命令 */
  public void execute(String[] args, Consumer<String> sender) {
    if (args.length == 0) {
      showHelp(sender);
      return;
    }

    String commandName = args[0].toLowerCase();
    SubCommand command = commands.get(commandName);

    if (command == null) {
      sender.accept("未知命令: " + commandName);
      showHelp(sender);
      return;
    }

    try {
      command.execute(Arrays.copyOfRange(args, 1, args.length), sender);
    } catch (Exception e) {
      sender.accept("命令执行失败: " + e.getMessage());
    }
  }

  /** 显示帮助信息 */
  private void showHelp(Consumer<String> sender) {
    sender.accept("=== 可用命令 ===");
    for (SubCommand command : commands.values()) {
      sender.accept(String.format("/%s - %s", command.getName(), command.getDescription()));
    }
  }

  /** 获取所有命令 */
  public Collection<SubCommand> getCommands() {
    return List.copyOf(commands.values());
  }

  /** 子命令接口 */
  @FunctionalInterface
  public interface SubCommand {
    void execute(String[] args, Consumer<String> sender);

    default String getName() {
      return getClass().getSimpleName().toLowerCase();
    }

    default String getDescription() {
      return "";
    }
  }
}
