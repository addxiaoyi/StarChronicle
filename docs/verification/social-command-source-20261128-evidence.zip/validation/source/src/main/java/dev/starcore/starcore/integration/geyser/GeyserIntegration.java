package dev.starcore.starcore.integration.geyser;

import java.lang.reflect.Method;
import java.util.Objects;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** Geyser/Floodgate 集成管理器 支持基岩版(Bedrock)玩家识别和跨平台游戏 */
public class GeyserIntegration {

  private static GeyserIntegration instance;
  private final Plugin plugin;
  private boolean geyserAvailable = false;
  private boolean floodgateAvailable = false;

  // 反射获取Floodgate API
  private Object floodgateApi;
  private Method isBedrockMethod;
  private Method getPlayerTypeMethod;
  private Method getXuidMethod;

  public GeyserIntegration(Plugin plugin) {
    this.plugin = Objects.requireNonNull(plugin, "plugin");
    checkGeyserAvailability();
  }

  /** 检查Geyser/Floodgate是否可用 */
  private void checkGeyserAvailability() {
    // 检查Floodgate
    Plugin floodgate = plugin.getServer().getPluginManager().getPlugin("Floodgate");
    if (floodgate != null && floodgate.isEnabled()) {
      floodgateAvailable = true;
      plugin.getLogger().info("✓ Floodgate 已检测到 - 基岩版支持已启用");
      initFloodgateApiReflection();
    }

    // 检查Geyser
    Plugin geyser = plugin.getServer().getPluginManager().getPlugin("Geyser");
    if (geyser != null && geyser.isEnabled()) {
      geyserAvailable = true;
      plugin.getLogger().info("✓ Geyser 已检测到 - 跨平台支持已启用");
    }
  }

  /** 初始化Floodgate反射调用 */
  private void initFloodgateApiReflection() {
    if (initFloodgateApi("net.geysermc.geyserapi.FloodgateApi")) {
      plugin.getLogger().info("✓ Floodgate API 反射初始化成功");
      return;
    }

    if (initFloodgateApi("com.github.william278.floodgateapi.FloodgateApi")) {
      plugin.getLogger().info("✓ Floodgate API (旧版) 反射初始化成功");
      return;
    }

    plugin.getLogger().warning("⚠ Floodgate API 反射初始化失败");
  }

  private boolean initFloodgateApi(String className) {
    try {
      Class<?> apiClass = Class.forName(className);
      Object api = apiClass.getMethod("getInstance").invoke(null);
      Method bedrockMethod = apiClass.getMethod("isBedrockPlayer", UUID.class);

      floodgateApi = api;
      isBedrockMethod = bedrockMethod;
      getPlayerTypeMethod = optionalMethod(apiClass, "getPlayerType");
      getXuidMethod = optionalMethod(apiClass, "getXuid");
      return true;
    } catch (ReflectiveOperationException | LinkageError e) {
      return false;
    }
  }

  private Method optionalMethod(Class<?> apiClass, String methodName) {
    try {
      return apiClass.getMethod(methodName, UUID.class);
    } catch (NoSuchMethodException e) {
      return null;
    }
  }

  /** 检查玩家是否为基岩版玩家 */
  public boolean isBedrockPlayer(Player player) {
    if (player == null) {
      return false;
    }
    return isBedrockPlayer(player.getUniqueId());
  }

  /** 检查玩家是否为基岩版玩家 */
  public boolean isBedrockPlayer(UUID uuid) {
    if (!floodgateAvailable || floodgateApi == null || isBedrockMethod == null || uuid == null) {
      return false;
    }

    try {
      Object result = isBedrockMethod.invoke(floodgateApi, uuid);
      return Boolean.TRUE.equals(result);
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin.getLogger().fine("调用 Floodgate 基岩玩家检测失败: " + e.getMessage());
      return false;
    }
  }

  /** 获取玩家类型 (JAVA/BEDROCK) */
  public String getPlayerType(Player player) {
    if (player == null) {
      return "JAVA";
    }
    return getPlayerType(player.getUniqueId());
  }

  /** 获取玩家类型 */
  public String getPlayerType(UUID uuid) {
    if (!floodgateAvailable
        || floodgateApi == null
        || getPlayerTypeMethod == null
        || uuid == null) {
      return "JAVA";
    }

    try {
      Object result = getPlayerTypeMethod.invoke(floodgateApi, uuid);
      return result != null ? result.toString() : "JAVA";
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin.getLogger().fine("调用 Floodgate 玩家类型查询失败: " + e.getMessage());
      return "JAVA";
    }
  }

  /** 检查Geyser是否可用 */
  public boolean isGeyserAvailable() {
    return geyserAvailable;
  }

  /** 检查Floodgate是否可用 */
  public boolean isFloodgateAvailable() {
    return floodgateAvailable;
  }

  /** 获取基岩版玩家的Xbox ID */
  public String getXboxId(Player player) {
    if (player == null) {
      return null;
    }
    return getXboxId(player.getUniqueId());
  }

  /** 获取基岩版玩家的Xbox ID */
  public String getXboxId(UUID uuid) {
    if (!floodgateAvailable || floodgateApi == null || getXuidMethod == null || uuid == null) {
      return null;
    }

    try {
      Object xuid = getXuidMethod.invoke(floodgateApi, uuid);
      return xuid != null ? xuid.toString() : null;
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin.getLogger().fine("调用 Floodgate XUID 查询失败: " + e.getMessage());
    }
    return null;
  }

  /** 获取基岩版玩家的设备信息 */
  public String getDeviceInfo(Player player) {
    if (player == null) {
      return "Java版";
    }
    if (isBedrockPlayer(player)) {
      return "基岩版 (Bedrock)";
    }
    return "Java版";
  }

  /** 发送基岩版原生表单 (支持更多功能) */
  public void sendBedrockForm(Player player, Object form) {
    if (!geyserAvailable || player == null || form == null) return;

    try {
      // 通过Geyser发送表单
      Class<?> geyserClass = Class.forName("org.geysermc.geyser.GeyserImpl");
      java.lang.reflect.Method getInstance = geyserClass.getMethod("getInstance");
      Object geyser = getInstance.invoke(null);

      java.lang.reflect.Method getSession = geyserClass.getMethod("getSession", UUID.class);
      Object session = getSession.invoke(geyser, player.getUniqueId());

      if (session != null) {
        java.lang.reflect.Method sendForm =
            session.getClass().getMethod("sendForm", Class.forName("com.nimbusdeditor.form.Form"));
        sendForm.invoke(session, form);
      }
    } catch (ReflectiveOperationException | RuntimeException e) {
      plugin.getLogger().fine("发送 Geyser 表单失败: " + e.getMessage());
    }
  }

  /** 检查是否应该使用特殊处理 (基岩版限制) */
  public boolean needsSpecialHandling(Player player) {
    if (player == null) {
      return false;
    }
    return isBedrockPlayer(player);
  }
}
