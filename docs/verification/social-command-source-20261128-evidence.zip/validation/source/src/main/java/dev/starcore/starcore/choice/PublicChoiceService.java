package dev.starcore.starcore.choice;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/** 公共决策管理器 专门用于处理纪元阶段的决策事务，支持投票、计时结束自动选择等 */
public class PublicChoiceService {

  private static final long TERMINAL_SESSION_RETENTION_MS = 10 * 60 * 1000L;

  private final ChoiceManager choiceManager;
  private final Map<String, DecisionSession> activeSessions = new ConcurrentHashMap<>();
  private final Map<String, AtomicInteger> voteCounts = new ConcurrentHashMap<>();
  // instanceId -> (playerId -> optionId)，用于去重与查询
  private final Map<String, Map<String, String>> playerVotes = new ConcurrentHashMap<>();
  // 每个会话的锁，保证投票检查-记录的原子性
  private final Map<String, Lock> sessionLocks = new ConcurrentHashMap<>();
  private final Map<String, ScheduledFuture<?>> expiryTasks = new ConcurrentHashMap<>();
  private final Map<String, ScheduledFuture<?>> cleanupTasks = new ConcurrentHashMap<>();
  private final ScheduledExecutorService cleanupExecutor;
  private final Object lifecycleLock = new Object();

  public PublicChoiceService(ChoiceManager choiceManager) {
    this(
        choiceManager,
        Executors.newSingleThreadScheduledExecutor(new ChoiceCleanupThreadFactory()));
  }

  PublicChoiceService(ChoiceManager choiceManager, ScheduledExecutorService cleanupExecutor) {
    this.choiceManager = Objects.requireNonNull(choiceManager, "choiceManager");
    this.cleanupExecutor = Objects.requireNonNull(cleanupExecutor, "cleanupExecutor");
  }

  private static final class ChoiceCleanupThreadFactory implements ThreadFactory {

    @Override
    public Thread newThread(Runnable task) {
      Thread thread = new Thread(task, "starcore-choice-cleanup");
      thread.setDaemon(true);
      return thread;
    }
  }

  /**
   * Releases the cleanup scheduler and any pending cleanup tasks.
   *
   * <p>The service must not be used after this method returns. It is safe to call more than once.
   */
  public void close() {
    synchronized (lifecycleLock) {
      for (ScheduledFuture<?> task : cleanupTasks.values()) {
        task.cancel(false);
      }
      for (ScheduledFuture<?> task : expiryTasks.values()) {
        task.cancel(false);
      }
      activeSessions.clear();
      voteCounts.clear();
      playerVotes.clear();
      sessionLocks.clear();
      cleanupTasks.clear();
      expiryTasks.clear();
      cleanupExecutor.shutdownNow();
    }
  }

  private void ensureOpen() {
    if (cleanupExecutor.isShutdown()) {
      throw new IllegalStateException("Public choice service is closed");
    }
  }

  /** 开始一个公共决策会话 */
  public void startDecisionSession(String instanceId, long votingDurationMs) {
    if (instanceId == null || instanceId.isBlank()) {
      throw new IllegalArgumentException("instanceId must not be blank");
    }
    if (votingDurationMs < 0) {
      throw new IllegalArgumentException("votingDurationMs must not be negative");
    }
    ensureOpen();
    ScheduledFuture<?> previousCleanup = cleanupTasks.remove(instanceId);
    if (previousCleanup != null) {
      previousCleanup.cancel(false);
    }
    ScheduledFuture<?> previousExpiry = expiryTasks.remove(instanceId);
    if (previousExpiry != null) {
      previousExpiry.cancel(false);
    }

    long startTime = System.currentTimeMillis();
    DecisionSession session =
        new DecisionSession(instanceId, startTime, startTime + votingDurationMs, "active");
    activeSessions.put(instanceId, session);
    voteCounts.put(instanceId, new AtomicInteger(0));
    playerVotes.put(instanceId, new ConcurrentHashMap<>());
    sessionLocks.put(instanceId, new ReentrantLock());
    expiryTasks.put(
        instanceId,
        cleanupExecutor.schedule(
            () -> completeSession(instanceId, "timeout"), votingDurationMs, TimeUnit.MILLISECONDS));
  }

  /** 投票给选项 每位玩家每个会话只能投一票；重复投票返回 false */
  public boolean voteForOption(String instanceId, String playerId, String optionId) {
    if (playerId == null || optionId == null) return false;

    Lock lock = sessionLocks.get(instanceId);
    if (lock == null) return false;
    lock.lock();
    try {
      DecisionSession session = activeSessions.get(instanceId);
      if (session == null || !session.isActive()) return false;

      // 检查投票时间是否过期
      if (System.currentTimeMillis() > session.endTime()) {
        completeSession(instanceId, "timeout");
        return false;
      }

      ChoiceInstance instance = choiceManager.getChoiceInstance(instanceId).orElse(null);
      if (instance == null) return false;
      // 选项必须存在
      if (!instance.options().containsKey(optionId)) return false;

      // 同一玩家不可重复投票
      Map<String, String> votes = playerVotes.get(instanceId);
      if (votes == null || votes.containsKey(playerId)) return false;

      // 记录投票
      votes.put(playerId, optionId);
      choiceManager.recordVote(instanceId, playerId, optionId);
      // computeIfAbsent 防御：voteCounts 与 activeSessions 必须同生命周期，但若有人绕过
      // startDecisionSession 写入 session，此处仍能恢复计数而不抛 NPE
      voteCounts.computeIfAbsent(instanceId, ignored -> new AtomicInteger(0)).incrementAndGet();

      // 当总票数达到参与者数量的3倍上限保护（或全部选项各得至少3票）时自动完成
      int optionCount = Math.max(1, instance.options().size());
      if (voteCounts.get(instanceId).get() >= optionCount * 3) {
        completeSession(instanceId, "auto_complete");
      }

      return true;
    } finally {
      lock.unlock();
    }
  }

  /** 完成决策会话 */
  public void completeSession(String instanceId, String reason) {
    Lock lock = sessionLocks.get(instanceId);
    if (lock == null) return;
    lock.lock();
    try {
      DecisionSession session = activeSessions.get(instanceId);
      if (session == null || !session.isActive()) return;

      // 创建已完成的会话
      DecisionSession completedSession =
          new DecisionSession(
              instanceId,
              session.startTime(),
              session.endTime(),
              "completed",
              reason,
              System.currentTimeMillis());
      activeSessions.put(instanceId, completedSession);
      cancelExpiry(instanceId);

      // 触发决策完成事件
      choiceManager.completeDecision(instanceId);

      // 会话终态：延迟清理关联状态，防止 Map 无限增长
      scheduleSessionCleanup(instanceId, completedSession);
    } finally {
      lock.unlock();
    }
  }

  /** 会话进入终态后清理投票计数、投票记录与锁映射，避免长期运行内存泄漏 */
  private void scheduleSessionCleanup(String instanceId, DecisionSession expectedSession) {
    ScheduledFuture<?> task =
        cleanupExecutor.schedule(
            () -> cleanupSession(instanceId, expectedSession),
            TERMINAL_SESSION_RETENTION_MS,
            TimeUnit.MILLISECONDS);
    ScheduledFuture<?> previous = cleanupTasks.put(instanceId, task);
    if (previous != null) {
      previous.cancel(false);
    }
  }

  private void cleanupSession(String instanceId, DecisionSession expectedSession) {
    if (!activeSessions.remove(instanceId, expectedSession)) {
      return;
    }
    voteCounts.remove(instanceId);
    playerVotes.remove(instanceId);
    sessionLocks.remove(instanceId);
    cleanupTasks.remove(instanceId);
  }

  private void cancelExpiry(String instanceId) {
    ScheduledFuture<?> expiry = expiryTasks.remove(instanceId);
    if (expiry != null) {
      expiry.cancel(false);
    }
  }

  /** 取消决策会话 */
  public void cancelSession(String instanceId, String reason) {
    Lock lock = sessionLocks.get(instanceId);
    if (lock == null) return;
    lock.lock();
    try {
      DecisionSession session = activeSessions.get(instanceId);
      if (session == null || !session.isActive()) return;

      DecisionSession cancelledSession =
          new DecisionSession(
              instanceId,
              session.startTime(),
              session.endTime(),
              "cancelled",
              reason,
              System.currentTimeMillis());
      activeSessions.put(instanceId, cancelledSession);
      cancelExpiry(instanceId);
      scheduleSessionCleanup(instanceId, cancelledSession);
    } finally {
      lock.unlock();
    }
  }

  /** 检查并处理过期的决策 */
  public void checkExpiredSessions() {
    long now = System.currentTimeMillis();
    for (Map.Entry<String, DecisionSession> entry : activeSessions.entrySet()) {
      DecisionSession session = entry.getValue();
      if (session.isActive() && now > session.endTime()) {
        completeSession(entry.getKey(), "timeout");
      }
    }
  }

  /** 获取决策会话 */
  public Optional<DecisionSession> getSession(String instanceId) {
    return Optional.ofNullable(activeSessions.get(instanceId));
  }

  /** 获取所有活跃会话 */
  public Collection<DecisionSession> getActiveSessions() {
    return activeSessions.values().stream().filter(DecisionSession::isActive).toList();
  }

  /** 获取单个玩家在指定会话中的投票次数（0 或 1） */
  public int getPlayerVoteCount(String instanceId, String playerId) {
    Map<String, String> votes = playerVotes.get(instanceId);
    if (votes == null || playerId == null) return 0;
    return votes.containsKey(playerId) ? 1 : 0;
  }

  /** 获取指定会话中某选项的得票数 */
  public int getOptionVoteCount(String instanceId, String optionId) {
    Map<String, String> votes = playerVotes.get(instanceId);
    if (votes == null || optionId == null) return 0;
    return (int) votes.values().stream().filter(optionId::equals).count();
  }

  /** 决策会话记录 */
  public record DecisionSession(
      String instanceId,
      long startTime,
      long endTime,
      String status,
      String reason,
      Long completedAt) {
    public DecisionSession(String instanceId, long startTime, long endTime, String status) {
      this(instanceId, startTime, endTime, status, null, null);
    }

    public boolean isActive() {
      return "active".equals(status);
    }

    public boolean isCompleted() {
      return "completed".equals(status);
    }

    public boolean isCancelled() {
      return "cancelled".equals(status);
    }

    public boolean isTimedOut() {
      return "timeout".equals(reason);
    }
  }

  /** 获取活跃会话数量 */
  public int getActiveSessionCount() {
    return (int) activeSessions.values().stream().filter(DecisionSession::isActive).count();
  }

  /** 获取全部会话数量（含已完成） */
  public int getTotalSessionCount() {
    return activeSessions.size();
  }

  /** 获取全服总投票数 */
  public int getTotalVoteCount() {
    return voteCounts.values().stream()
        .mapToInt(java.util.concurrent.atomic.AtomicInteger::get)
        .sum();
  }
}
