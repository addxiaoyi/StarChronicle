package dev.starcore.starcore.essentials.listener;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.baltop.BalTopViewLoader;
import dev.starcore.starcore.essentials.command.TeleportGui;
import dev.starcore.starcore.essentials.gui.BalTopGui;
import dev.starcore.starcore.essentials.gui.HomeGui;
import dev.starcore.starcore.essentials.gui.WarpGui;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.teleport.TeleportService;
import dev.starcore.starcore.essentials.warp.WarpService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.gui.BookInputSupport;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

/** Essentials GUI 事件监听器 */
public final class EssentialsGuiListener implements Listener {
  private static final int HOME_FIRST_SLOT = 10;
  private static final int HOME_LAST_SLOT = 16;
  private static final int HOMES_PER_PAGE = 7;
  private final Plugin plugin;
  private final HomeService homeService;
  private final WarpService warpService;
  private final TeleportService teleportService;
  private final BalTopService balTopService;
  private final EconomyService economyService;
  private final FoliaCompatScheduler scheduler;
  private final BooleanSupplier lifetime;
  private final BalTopViewLoader rankingLoader;
  private volatile boolean closed;

  private record Opening(Player player, Inventory expectedInventory, Object nonce) {}

  private record GuiSession(Player player, Inventory inventory, String type, Object nonce) {}

  private record HomeSave(Player player, Object nonce) {}

  private record BookOpening(Player player, Object token, Object nonce) {}

  private final ConcurrentHashMap<UUID, Opening> pendingRankings = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, GuiSession> sessions = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, HomeSave> homeSaves = new ConcurrentHashMap<>();
  private final Object stateLock = new Object();

  // Compatibility state for the legacy synchronous constructor.
  private final ConcurrentHashMap<UUID, String> openGuis = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, Inventory> openInventories = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, BookOpening> pendingHomeNames = new ConcurrentHashMap<>();
  private static final String HOME_GUI = "home";
  private static final String WARP_GUI = "warp";
  private static final String BALTOP_GUI = "baltop";
  private static final String TELEPORT_GUI = "teleporter";

  public EssentialsGuiListener(
      Plugin plugin,
      HomeService homeService,
      WarpService warpService,
      TeleportService teleportService,
      BalTopService balTopService,
      EconomyService economyService) {
    this(
        plugin,
        homeService,
        warpService,
        teleportService,
        balTopService,
        economyService,
        null,
        () -> true);
  }

  public EssentialsGuiListener(
      Plugin plugin,
      HomeService homeService,
      WarpService warpService,
      TeleportService teleportService,
      BalTopService balTopService,
      EconomyService economyService,
      FoliaCompatScheduler scheduler,
      BooleanSupplier lifetime) {
    this.plugin = plugin;
    this.scheduler = scheduler;
    this.lifetime = Objects.requireNonNull(lifetime);
    this.rankingLoader =
        scheduler == null
            ? null
            : new BalTopViewLoader(plugin, scheduler, this::active, balTopService, economyService);
    this.homeService = homeService;
    this.warpService = warpService;
    this.teleportService = teleportService;
    this.balTopService = balTopService;
    this.economyService = economyService;
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getWhoClicked() instanceof Player player
        && ownsOpenInventory(player, event.getView().getTopInventory())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    GuiSession session = sessions.get(player.getUniqueId());
    String guiType =
        scheduler == null
            ? openGuis.get(player.getUniqueId())
            : session == null ? null : session.type();
    if (guiType == null || !ownsOpenInventory(player, event.getView().getTopInventory())) {
      return;
    }

    // 取消点击
    event.setCancelled(true);

    var top = event.getView().getTopInventory();
    if (event.getClickedInventory() != top
        || event.getRawSlot() < 0
        || event.getRawSlot() >= top.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)) {
      return;
    }

    int slot = event.getRawSlot();
    String title = event.getView().getTitle();

    boolean secondary = event.getClick() == ClickType.RIGHT;
    // Bukkit inventory transitions must occur after the click event has completed.
    owned(
        player,
        () -> {
          if (!ownsOpenInventory(player, top)
              || scheduler != null && sessions.get(player.getUniqueId()) != session
              || scheduler != null && player.getOpenInventory().getTopInventory() != top) return;
          if (HOME_GUI.equals(guiType) && slot == 22) {
            beginHomeNameInput(player);
            return;
          }
          switch (guiType) {
            case HOME_GUI -> handleHomeGuiClick(player, slot, title, secondary);
            case WARP_GUI -> handleWarpGuiClick(player, slot, title);
            case BALTOP_GUI -> handleBalTopGuiClick(player, slot, title);
            case TELEPORT_GUI -> handleTeleportGuiClick(player, slot);
          }
        });
  }

  @EventHandler
  public void onInventoryClose(InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }

    UUID playerId = player.getUniqueId();
    Inventory closed = event.getInventory();
    Opening opening = pendingRankings.get(playerId);
    if (opening != null && opening.player() == player && opening.expectedInventory() == closed)
      pendingRankings.remove(playerId, opening);
    if (scheduler != null) {
      GuiSession session = sessions.get(playerId);
      if (session != null && session.player() == player && session.inventory() == closed)
        sessions.remove(playerId, session);
    } else if (openInventories.remove(playerId, closed)) {
      openGuis.remove(playerId);
    }
  }

  @EventHandler
  public void onHomeNameBookEdit(PlayerEditBookEvent event) {
    Player player = event.getPlayer();
    if (!available(player)) return;
    UUID playerId = player.getUniqueId();
    BookOpening book = pendingHomeNames.get(playerId);
    if (book == null || book.player() != player || !pendingHomeNames.remove(playerId, book)) return;
    if (BookInputSupport.sessionToken(player) != book.token()) return;
    event.setCancelled(true);
    BookInputSupport.restore(event.getPlayer());
    String name = String.join("\n", event.getNewBookMeta().getPages());
    HomeSave request = new HomeSave(player, new Object());
    synchronized (stateLock) {
      if (!active()) return;
      homeSaves.put(playerId, request);
    }
    owned(
        player,
        () -> {
          if (!homeSaves.remove(playerId, request)) return;
          String invalidReason = HomeService.invalidHomeNameReason(name).orElse(null);
          if (invalidReason != null) {
            player.sendMessage(
                Component.text("Invalid home name: " + invalidReason, NamedTextColor.RED));
          } else {
            boolean saved = homeService.setHome(player, name);
            player.sendMessage(
                Component.text(
                    saved ? "Home saved." : "Unable to save home.",
                    saved ? NamedTextColor.GREEN : NamedTextColor.RED));
          }
          openHomeGui(player, 1);
        },
        () -> homeSaves.remove(playerId, request));
  }

  // ==================== 家园 GUI 处理 ====================

  private void beginHomeNameInput(Player player) {
    cancelPending(player);
    BookInputSupport.prepare(player, "Home name", "");
    Object token = BookInputSupport.sessionToken(player);
    synchronized (stateLock) {
      if (active()) {
        pendingHomeNames.put(player.getUniqueId(), new BookOpening(player, token, new Object()));
        return;
      }
    }
    BookInputSupport.restoreSession(player, token);
  }

  private void handleHomeGuiClick(Player player, int slot, String title, boolean secondaryClick) {
    HomeGui.HomeAction action = HomeGui.getActionFromSlot(slot);
    HomeGui displayed = homeView(player);
    int displayedPage = displayed == null ? extractPage(title) : displayed.getPage();
    if (secondaryClick && action == HomeGui.HomeAction.TELEPORT_HOME) {
      action = HomeGui.HomeAction.DELETE_HOME;
    }

    switch (action) {
      case CLOSE -> player.closeInventory();
      case SET_HOME -> {
        beginHomeNameInput(player);
        return;
      }
      case PREV_PAGE -> {
        int page = displayedPage;
        openHomeGui(player, page - 1);
      }
      case NEXT_PAGE -> {
        int page = displayedPage;
        openHomeGui(player, page + 1);
      }
      case TELEPORT_HOME -> {
        String homeName = homeNameFromSlot(player, displayedPage, slot);
        if (homeName != null) {
          player.closeInventory();
          teleportService.teleportToHome(player, homeName);
        }
      }
      case DELETE_HOME -> {
        int page = displayedPage;
        String homeName = homeNameFromSlot(player, page, slot);
        if (homeName != null) {
          homeService.deleteHome(player, homeName);
          refreshHomeGui(player, page);
        }
      }
      default -> {}
    }
  }

  private String homeNameFromSlot(Player player, int page, int slot) {
    HomeGui displayed = homeView(player);
    if (displayed != null) return displayed.getHomeNameFromSlot(slot);
    if (scheduler != null) return null;
    if (slot < HOME_FIRST_SLOT || slot > HOME_LAST_SLOT) {
      return null;
    }
    int index = (Math.max(1, page) - 1) * HOMES_PER_PAGE + slot - HOME_FIRST_SLOT;
    var homeNames = homeService.getHomeNames(player.getUniqueId());
    return index >= 0 && index < homeNames.size() ? homeNames.get(index) : null;
  }

  private void refreshHomeGui(Player player, int requestedPage) {
    int homeCount = homeService.getHomeNames(player.getUniqueId()).size();
    int totalPages = Math.max(1, (homeCount + 6) / 7);
    openHomeGui(player, Math.min(Math.max(1, requestedPage), totalPages));
  }

  // ==================== 传送点 GUI 处理 ====================

  private void handleWarpGuiClick(Player player, int slot, String title) {
    WarpGui.WarpAction action = WarpGui.getActionFromSlot(slot);
    WarpGui displayed = warpView(player);
    int displayedPage = displayed == null ? extractPage(title) : displayed.getPage();

    switch (action) {
      case CLOSE -> player.closeInventory();
      case PREV_PAGE -> {
        int page = displayedPage;
        openWarpGui(player, page - 1);
      }
      case NEXT_PAGE -> {
        int page = displayedPage;
        openWarpGui(player, page + 1);
      }
      case TELEPORT_WARP -> {
        WarpGui gui =
            displayed != null
                ? displayed
                : scheduler == null
                    ? new WarpGui(player, warpService, teleportService, displayedPage)
                    : null;
        String warpName = gui == null ? null : gui.getWarpNameFromSlot(slot);
        if (warpName != null) {
          player.closeInventory();
          teleportService.teleportToWarp(player, warpName);
        }
      }
      default -> {}
    }
  }

  // ==================== 财富排行榜 GUI 处理 ====================

  private void handleBalTopGuiClick(Player player, int slot, String title) {
    BalTopGui displayed = rankingView(player);
    if (displayed == null) return;
    int page = displayed.getPage();
    switch (BalTopGui.getActionFromSlot(slot)) {
      case CLOSE -> player.closeInventory();
      case REFRESH -> requestRanking(player, page, true);
      case PREV_PAGE -> openBalTopGui(player, page - 1);
      case NEXT_PAGE -> openBalTopGui(player, page + 1);
      case VIEW_PLAYER -> {
        var entry = displayed.getEntryFromSlot(slot);
        if (entry != null) {
          player.sendMessage(
              Component.text(
                  "玩家: " + displayed.getEntryName(entry.playerId()), NamedTextColor.GOLD));
          player.sendMessage(
              Component.text(
                  "余额: " + String.format("%.2f", entry.balance().doubleValue()),
                  NamedTextColor.GREEN));
        }
      }
      default -> {}
    }
  }

  // ==================== 综合传送 GUI 处理 ====================

  private void handleTeleportGuiClick(Player player, int slot) {
    TeleportGui.TeleportAction action = TeleportGui.getActionFromSlot(slot);

    switch (action) {
      case CLOSE -> player.closeInventory();
      case SPAWN -> {
        player.closeInventory();
        teleportService.teleportToSpawn(player);
      }
      case HOME_MENU -> {
        openHomeGui(player, 1);
      }
      case WARP_MENU -> {
        if (!teleportService.canUseWarp(player)) {
          player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
          return;
        }
        openWarpGui(player, 1);
      }
      case BACK -> {
        player.closeInventory();
        teleportService.teleportBack(player);
      }
      default -> {}
    }
  }

  // ==================== 辅助方法 ====================

  private int extractPage(String title) {
    // 从标题中提取页码，例如 "家园管理 (第2页)" -> 2
    try {
      int start = title.indexOf("(第");
      int end = title.indexOf("页)");
      if (start != -1 && end != -1) {
        String pageStr = title.substring(start + 2, end);
        return Integer.parseInt(pageStr.trim());
      }
    } catch (Exception e) {
      // 忽略
    }
    return 1;
  }

  public void openHomeGui(Player player, int page) {
    if (!available(player)) return;
    cancelPending(player);
    HomeGui gui = new HomeGui(player, homeService, teleportService, page);
    display(player, gui.getInventory(), HOME_GUI);
  }

  public void openWarpGui(Player player, int page) {
    if (!available(player)) return;
    if (!teleportService.canUseWarp(player)) {
      player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
      return;
    }
    cancelPending(player);
    WarpGui gui = new WarpGui(player, warpService, teleportService, page);
    display(player, gui.getInventory(), WARP_GUI);
  }

  public void openBalTopGui(Player player, int page) {
    requestRanking(player, page, false);
  }

  private void requestRanking(Player player, int page, boolean refresh) {
    if (!available(player)) return;
    cancelPending(player);
    if (rankingLoader == null) {
      if (refresh) balTopService.updateRankings(economyService.getAllBalances());
      display(
          player,
          new BalTopGui(player, balTopService, economyService, page).getInventory(),
          BALTOP_GUI);
      return;
    }
    UUID id = player.getUniqueId();
    Opening opening =
        new Opening(player, player.getOpenInventory().getTopInventory(), new Object());
    synchronized (stateLock) {
      if (!active()) return;
      pendingRankings.put(id, opening);
    }
    rankingLoader.load(
        player,
        page,
        refresh,
        () -> pendingRankings.get(id) == opening,
        view -> {
          if (!pendingRankings.remove(id, opening)
              || player.getOpenInventory().getTopInventory() != opening.expectedInventory()) return;
          BalTopGui gui = new BalTopGui(player, view);
          display(player, gui.getInventory(), BALTOP_GUI);
          if (refresh && trackedInventory(player) == gui.getInventory())
            player.sendMessage(Component.text("排行榜已刷新", NamedTextColor.GREEN));
        },
        reason -> {
          if (pendingRankings.remove(id, opening)
              && player.getOpenInventory().getTopInventory() == opening.expectedInventory())
            player.sendMessage(Component.text(reason, NamedTextColor.RED));
        },
        () -> pendingRankings.remove(id, opening));
  }

  public void openTeleporterGui(Player player) {
    if (!available(player)) return;
    cancelPending(player);
    TeleportGui gui = new TeleportGui(player, homeService, warpService, teleportService);
    display(player, gui.getInventory(), TELEPORT_GUI);
  }

  private void display(Player player, Inventory inventory, String type) {
    player.closeInventory();
    if (!available(player)) return;
    player.openInventory(inventory);
    if (scheduler != null
        && (plugin.getServer().getPlayer(player.getUniqueId()) != player
            || !player.isOnline()
            || player.getOpenInventory().getTopInventory() != inventory)) return;
    UUID id = player.getUniqueId();
    synchronized (stateLock) {
      if (active()) {
        sessions.put(id, new GuiSession(player, inventory, type, new Object()));
        if (scheduler == null) {
          openGuis.put(id, type);
          openInventories.put(id, inventory);
        }
        return;
      }
    }
    // Shutdown may have drained the state while openInventory was in progress.
    if (player.getOpenInventory().getTopInventory() == inventory) player.closeInventory();
  }

  private void cancelPending(Player player) {
    UUID id = player.getUniqueId();
    pendingRankings.remove(id);
    homeSaves.remove(id);
    BookOpening book = pendingHomeNames.get(id);
    if (book != null && book.player() == player && pendingHomeNames.remove(id, book))
      BookInputSupport.restoreSession(player, book.token());
  }

  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    Player player = event.getPlayer();
    UUID id = player.getUniqueId();
    Opening opening = pendingRankings.get(id);
    if (opening != null && opening.player() == player) pendingRankings.remove(id, opening);
    HomeSave save = homeSaves.get(id);
    if (save != null && save.player() == player) homeSaves.remove(id, save);
    BookOpening book = pendingHomeNames.get(id);
    if (book != null && book.player() == player && pendingHomeNames.remove(id, book))
      BookInputSupport.restoreSession(player, book.token());
    GuiSession session = sessions.get(id);
    if (session != null && session.player() == player) sessions.remove(id, session);
    if (scheduler == null) {
      openGuis.remove(id);
      openInventories.remove(id);
    }
  }

  public void close() {
    java.util.List<GuiSession> closingSessions;
    java.util.List<BookOpening> closingBooks;
    synchronized (stateLock) {
      closed = true;
      closingSessions = java.util.List.copyOf(sessions.values());
      closingBooks = java.util.List.copyOf(pendingHomeNames.values());
      pendingRankings.clear();
      homeSaves.clear();
      pendingHomeNames.clear();
      sessions.clear();
      openGuis.clear();
      openInventories.clear();
    }
    closingSessions.forEach(session -> cleanup(session.player(), session.inventory(), null));
    closingBooks.forEach(book -> cleanup(book.player(), null, book.token()));
  }

  private void cleanup(Player player, Inventory inventory, Object token) {
    UUID id = player.getUniqueId();
    Runnable cleanup =
        () -> {
          if (scheduler != null
              && (!plugin.isEnabled()
                  || plugin.getServer().getPlayer(id) != player
                  || !player.isOnline())) return;
          try {
            if (token != null) BookInputSupport.restoreSession(player, token);
          } finally {
            if (inventory != null && player.getOpenInventory().getTopInventory() == inventory)
              player.closeInventory();
          }
        };
    if (scheduler == null) {
      cleanup.run();
      return;
    }
    AtomicBoolean once = new AtomicBoolean();
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (once.compareAndSet(false, true)) cleanup.run();
          },
          () -> once.set(true));
    } catch (RuntimeException failure) {
      once.set(true);
      plugin.getLogger().log(Level.FINE, "GUI owner cleanup unavailable", failure);
    }
  }

  private boolean active() {
    return !closed && lifetime.getAsBoolean() && (scheduler == null || plugin.isEnabled());
  }

  private boolean available(Player player) {
    return active()
        && (scheduler == null
            || plugin.getServer().getPlayer(player.getUniqueId()) == player && player.isOnline());
  }

  private void owned(Player player, Runnable action) {
    owned(player, action, () -> {});
  }

  private void owned(Player player, Runnable action, Runnable abandoned) {
    if (!active()) {
      abandoned.run();
      return;
    }
    if (scheduler == null) {
      action.run();
      return;
    }
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable retire =
        () -> {
          if (claimed.compareAndSet(false, true)) abandoned.run();
        };
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (!claimed.compareAndSet(false, true)) return;
            if (available(player)) action.run();
            else abandoned.run();
          },
          retire);
    } catch (RuntimeException failure) {
      retire.run();
      plugin.getLogger().log(Level.FINE, "GUI owner callback unavailable", failure);
    }
  }

  private boolean ownsOpenInventory(Player player, Inventory inventory) {
    return player != null
        && inventory != null
        && available(player)
        && trackedInventory(player) == inventory;
  }

  private Inventory trackedInventory(Player player) {
    if (scheduler == null) return openInventories.get(player.getUniqueId());
    GuiSession session = sessions.get(player.getUniqueId());
    return session != null && session.player() == player ? session.inventory() : null;
  }

  private HomeGui homeView(Player player) {
    Inventory inventory = trackedInventory(player);
    return inventory != null
            && inventory.getHolder() instanceof HomeGui gui
            && gui.getPlayer() == player
        ? gui
        : null;
  }

  private WarpGui warpView(Player player) {
    Inventory inventory = trackedInventory(player);
    return inventory != null
            && inventory.getHolder() instanceof WarpGui gui
            && gui.getPlayer() == player
        ? gui
        : null;
  }

  private BalTopGui rankingView(Player player) {
    Inventory inventory = trackedInventory(player);
    return inventory != null
            && inventory.getHolder() instanceof BalTopGui gui
            && gui.getPlayer() == player
        ? gui
        : null;
  }
}
