package dev.starcore.starcore.core.guide;

import java.util.Map;
import java.util.Optional;

/** 玩家在指南中选择一个玩法后要打开的真实功能入口。 */
public enum GuideAction {
  MENU("menu", null, "打开导航中枢"),
  NATION("menu", "sc nation gui", "打开国家管理"),
  REGION("menu", "sc nation gui", "打开国家与领土管理"),
  TRADE("resourcegui", "resourcegui", "打开资源与交易市场"),
  ARMY("army", "army", "打开军队管理"),
  WAR("war", "war gui", "打开战争系统"),
  DIPLOMACY("diplomacy", "diplomacy", "打开外交系统"),
  ALLIANCE("alliance", "diplomacy", "打开外交与联盟管理"),
  TECHNOLOGY("tech", "tech gui", "打开科技研究"),
  GUILD("guild", "socialgui", "打开公会系统"),
  FRIEND("friend", "socialgui", "打开好友系统"),
  SOCIAL("socialgui", "socialgui", "打开社交面板"),
  QUEST("questgui", "questgui", "打开任务面板"),
  RANK("rank", "rank", "打开排行榜"),
  DUNGEON("dungeon", "dungeon", "打开副本大厅");

  private static final Map<String, GuideAction> ITEM_ACTIONS =
      Map.ofEntries(
          Map.entry("welcome", MENU),
          Map.entry("basic_commands", MENU),
          Map.entry("first_steps", NATION),
          Map.entry("create_nation", NATION),
          Map.entry("nation_governance", NATION),
          Map.entry("territory", REGION),
          Map.entry("members", NATION),
          Map.entry("taxation", NATION),
          Map.entry("treasury", NATION),
          Map.entry("trade", TRADE),
          Map.entry("army", ARMY),
          Map.entry("warfare", WAR),
          Map.entry("defense", REGION),
          Map.entry("diplomacy", DIPLOMACY),
          Map.entry("treaties", ALLIANCE),
          Map.entry("tech_tree", TECHNOLOGY),
          Map.entry("research", TECHNOLOGY),
          Map.entry("guild", GUILD),
          Map.entry("friends", FRIEND),
          Map.entry("chat", SOCIAL),
          Map.entry("rankings", RANK),
          Map.entry("dungeons", DUNGEON));

  private final String command;
  private final String navigationKey;
  private final String label;

  GuideAction(String command, String navigationKey, String label) {
    this.command = command;
    this.navigationKey = navigationKey;
    this.label = label;
  }

  public String command() {
    return command;
  }

  public String label() {
    return label;
  }

  public String navigationKey() {
    return navigationKey;
  }

  public static Optional<GuideAction> forItem(String itemId) {
    if (itemId == null || itemId.isBlank()) {
      return Optional.empty();
    }
    return Optional.ofNullable(ITEM_ACTIONS.get(itemId));
  }
}
