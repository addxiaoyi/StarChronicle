package dev.starcore.starcore.foundation.economy.insurance;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.PendingRefund;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRequest;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** File-backed player insurance with idempotent premium and payout transactions. */
public final class EconomyInsuranceService {
  private static final String VERSION = "1";
  private static final int MAX_DURATION_DAYS = 365;
  private final Path file;
  private final Logger logger;
  private final EconomyService economy;
  private final TransactionFabric transactions;
  private final RefundLedger refundLedger;
  private final Map<RefundOwner, InsuranceSettlementHandler> settlementHandlers =
      new EnumMap<>(RefundOwner.class);
  private final Map<UUID, InsurancePolicy> policies = new LinkedHashMap<>();

  public EconomyInsuranceService(
      Path file,
      Logger logger,
      EconomyService economy,
      TransactionFabric transactions,
      RefundLedger refundLedger) {
    this.file = Objects.requireNonNull(file, "file");
    this.logger = Objects.requireNonNull(logger, "logger");
    this.economy = Objects.requireNonNull(economy, "economy");
    this.transactions = Objects.requireNonNull(transactions, "transactions");
    this.refundLedger = Objects.requireNonNull(refundLedger, "refundLedger");
    load();
  }

  public synchronized InsuranceQuote quote(
      UUID playerId,
      InsuranceCoverage coverage,
      BigDecimal maxPayout,
      BigDecimal deductible,
      int durationDays) {
    validateQuote(playerId, coverage, maxPayout, deductible, durationDays);
    return new InsuranceQuote(
        coverage, maxPayout, deductible, coverage.premiumFor(maxPayout), durationDays, playerId);
  }

  public synchronized void registerSettlementHandler(
      RefundOwner owner, InsuranceSettlementHandler handler) {
    settlementHandlers.put(
        Objects.requireNonNull(owner, "owner"), Objects.requireNonNull(handler, "handler"));
  }

  public synchronized InsurancePolicy buy(InsuranceQuote quote) {
    Objects.requireNonNull(quote, "quote");
    validateQuote(
        quote.playerId(),
        quote.coverage(),
        quote.maxPayout(),
        quote.deductible(),
        quote.durationDays());
    UUID policyId = UUID.randomUUID();
    Instant now = Instant.now();
    TransactionRecord premium =
        transactions.begin(
            new TransactionRequest(
                quote.playerId(),
                quote.premium(),
                RefundOwner.SYSTEM,
                TransactionType.OTHER,
                "insurance-premium:" + policyId,
                "insurance-premium:" + policyId));
    ensureReserved(premium);
    if (!economy.withdraw(quote.playerId(), quote.premium())) {
      transactions.fail(premium.transactionId(), "insurance premium rejected");
      throw new IllegalStateException("Insurance premium could not be charged");
    }
    commit(premium.transactionId(), "insurance premium charged", "insurance policy stored");
    InsurancePolicy policy =
        new InsurancePolicy(
            policyId,
            quote.playerId(),
            quote.coverage(),
            quote.maxPayout(),
            quote.deductible(),
            quote.premium(),
            now,
            now.plus(quote.durationDays(), ChronoUnit.DAYS),
            InsurancePolicyState.ACTIVE,
            null,
            null,
            null);
    policies.put(policyId, policy);
    persist();
    return policy;
  }

  public synchronized List<InsurancePolicy> policies(UUID playerId, Instant now) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(now, "now");
    expirePolicies(now);
    return policies.values().stream()
        .filter(policy -> policy.playerId().equals(playerId))
        .sorted(Comparator.comparing(InsurancePolicy::expiresAt))
        .toList();
  }

  /** Returns policies that reference a transaction as a claim source or payout. */
  public synchronized List<InsurancePolicy> evidenceForTransaction(UUID transactionId) {
    Objects.requireNonNull(transactionId, "transactionId");
    return policies.values().stream()
        .filter(
            policy ->
                transactionId.equals(policy.claimSourceTransactionId())
                    || transactionId.equals(policy.payoutTransactionId()))
        .sorted(Comparator.comparing(InsurancePolicy::startsAt))
        .toList();
  }

  public synchronized Optional<InsuranceClaimReceipt> claim(
      UUID playerId, UUID sourceTransactionId, Instant now) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(sourceTransactionId, "sourceTransactionId");
    Objects.requireNonNull(now, "now");
    expirePolicies(now);
    TransactionRecord source =
        transactions
            .find(sourceTransactionId)
            .orElseThrow(() -> new IllegalArgumentException("Source transaction not found"));
    InsurancePolicy policy =
        findEligiblePolicy(playerId, source, now)
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "No active insurance policy covers this transaction"));
    if (source.state() == EconomyTransactionState.REFUND_PENDING) {
      transactions.markManualReview(
          source.transactionId(), "insurance claim replaces direct refund");
      source = transactions.find(source.transactionId()).orElseThrow();
    }
    InsuranceClaimReceipt receipt = settleClaim(policy, source);
    return Optional.of(receipt);
  }

  /** Retries payout delivery after a provider outage. Returns the number of completed claims. */
  public synchronized int retryPendingClaims(Instant now) {
    Objects.requireNonNull(now, "now");
    int completed = 0;
    for (InsurancePolicy policy : new ArrayList<>(policies.values())) {
      if (policy.state() != InsurancePolicyState.CLAIM_PENDING
          || policy.claimSourceTransactionId() == null) {
        continue;
      }
      TransactionRecord source = transactions.find(policy.claimSourceTransactionId()).orElse(null);
      if (source == null) continue;
      if (source.state() == EconomyTransactionState.REFUNDED
          && (policy.payoutTransactionId() == null
              || transactions.find(policy.payoutTransactionId()).isEmpty())) {
        cancelPendingClaim(policy, "source transaction was refunded");
        continue;
      }
      try {
        settleClaim(policy, source);
        completed++;
      } catch (RuntimeException failure) {
        logger.log(Level.WARNING, "Insurance claim retry failed: " + policy.policyId(), failure);
      }
    }
    return completed;
  }

  private InsuranceClaimReceipt settleClaim(InsurancePolicy policy, TransactionRecord source) {
    BigDecimal payout = policy.payoutFor(source.amount());
    if (payout.signum() <= 0) throw new IllegalStateException("Claim is below the deductible");
    UUID payoutTransactionId =
        policy.payoutTransactionId() == null ? null : policy.payoutTransactionId();
    if (payoutTransactionId == null) {
      payoutTransactionId =
          UUID.nameUUIDFromBytes(
              ("insurance-payout:" + policy.policyId() + ":" + source.transactionId())
                  .getBytes(StandardCharsets.UTF_8));
      policy = withPending(policy, source.transactionId(), payoutTransactionId, null);
      policies.put(policy.policyId(), policy);
      persist();
    }

    TransactionRecord payoutTransaction =
        transactions.begin(
            new TransactionRequest(
                policy.playerId(),
                payout,
                RefundOwner.SYSTEM,
                TransactionType.INSURANCE_PAYOUT,
                "insurance:" + policy.policyId() + ":" + source.transactionId(),
                "insurance-payout:" + policy.policyId() + ":" + source.transactionId()));
    preparePayout(payoutTransaction);
    try {
      if (payoutTransaction.state() != EconomyTransactionState.COMMITTED
          && !economy.deposit(policy.playerId(), payout)) {
        throw new IllegalStateException("insurance payout rejected");
      }
    } catch (RuntimeException failure) {
      markPayoutPending(policy, payoutTransaction, failure.getMessage());
      throw failure;
    }
    if (payoutTransaction.state() != EconomyTransactionState.COMMITTED) {
      commitPayout(payoutTransaction.transactionId());
    }
    InsuranceSettlementHandler handler = settlementHandlers.get(source.owner());
    if (handler != null && !handler.settle(policy, source)) {
      markPayoutPending(policy, payoutTransaction, "insurance domain settlement was not completed");
      throw new IllegalStateException("Insurance domain settlement is pending");
    }
    if (source.state() != EconomyTransactionState.REFUNDED) {
      transitionSourceToRefunded(source);
    }
    refundLedger.markDelivered(payoutTransaction.transactionId());
    refundLedger.markDeliveredByIdentity(
        source.reason(), source.accountId(), source.amount(), source.owner());
    InsurancePolicy claimed =
        new InsurancePolicy(
            policy.policyId(),
            policy.playerId(),
            policy.coverage(),
            policy.maxPayout(),
            policy.deductible(),
            policy.premium(),
            policy.startsAt(),
            policy.expiresAt(),
            InsurancePolicyState.CLAIMED,
            source.transactionId(),
            payoutTransaction.transactionId(),
            null);
    policies.put(claimed.policyId(), claimed);
    persist();
    return new InsuranceClaimReceipt(
        claimed.policyId(), source.transactionId(), payoutTransaction.transactionId(), payout);
  }

  private void preparePayout(TransactionRecord payoutTransaction) {
    if (payoutTransaction.state() == EconomyTransactionState.CREATED) {
      transactions.transition(
          payoutTransaction.transactionId(),
          EconomyTransactionState.RESERVED,
          "insurance payout reserved");
      return;
    }
    if (payoutTransaction.state() == EconomyTransactionState.DEBIT_FAILED
        || payoutTransaction.state() == EconomyTransactionState.REFUND_PENDING) {
      transactions.transition(
          payoutTransaction.transactionId(),
          EconomyTransactionState.CREATED,
          "retrying insurance payout");
      transactions.transition(
          payoutTransaction.transactionId(),
          EconomyTransactionState.RESERVED,
          "insurance payout reserved");
    }
  }

  private void commitPayout(UUID payoutTransactionId) {
    transactions.transition(
        payoutTransactionId, EconomyTransactionState.DEBITED, "insurance payout delivered");
    transactions.transition(
        payoutTransactionId, EconomyTransactionState.DELIVERED, "player balance credited");
    transactions.transition(
        payoutTransactionId, EconomyTransactionState.COMMITTED, "insurance claim committed");
  }

  private void transitionSourceToRefunded(TransactionRecord source) {
    TransactionRecord current = source;
    if (current.state() == EconomyTransactionState.DEBIT_FAILED
        || current.state() == EconomyTransactionState.DELIVERY_FAILED) {
      current =
          transactions.transition(
              current.transactionId(),
              EconomyTransactionState.REFUND_PENDING,
              "insurance payout pending");
    }
    if (current.state() == EconomyTransactionState.REFUND_PENDING
        || current.state() == EconomyTransactionState.MANUAL_REVIEW) {
      transactions.transition(
          current.transactionId(), EconomyTransactionState.REFUNDED, "insurance payout committed");
    }
  }

  private void markPayoutPending(
      InsurancePolicy policy, TransactionRecord payoutTransaction, String error) {
    TransactionRecord current =
        transactions.find(payoutTransaction.transactionId()).orElse(payoutTransaction);
    if (current.state() == EconomyTransactionState.RESERVED) {
      transactions.fail(current.transactionId(), error == null ? "insurance payout failed" : error);
      current = transactions.find(current.transactionId()).orElseThrow();
    }
    if (current.state() == EconomyTransactionState.DEBIT_FAILED
        || current.state() == EconomyTransactionState.DELIVERY_FAILED) {
      transactions.transition(
          current.transactionId(),
          EconomyTransactionState.REFUND_PENDING,
          "insurance payout pending");
    }
    refundLedger.record(
        new PendingRefund(
                current.transactionId(),
                policy.playerId(),
                policy.payoutFor(
                    transactions.find(policy.claimSourceTransactionId()).orElseThrow().amount()),
                "insurance:" + policy.policyId() + ":" + policy.claimSourceTransactionId(),
                0,
                RefundLedger.nextRetry(Instant.now(), 0),
                error == null ? "insurance payout failed" : error)
            .ownedBy(RefundOwner.SYSTEM));
    policies.put(
        policy.policyId(),
        withPending(policy, policy.claimSourceTransactionId(), current.transactionId(), error));
    persist();
  }

  private InsurancePolicy withPending(
      InsurancePolicy policy, UUID sourceTransactionId, UUID payoutTransactionId, String error) {
    return new InsurancePolicy(
        policy.policyId(),
        policy.playerId(),
        policy.coverage(),
        policy.maxPayout(),
        policy.deductible(),
        policy.premium(),
        policy.startsAt(),
        policy.expiresAt(),
        InsurancePolicyState.CLAIM_PENDING,
        sourceTransactionId,
        payoutTransactionId,
        error);
  }

  private void cancelPendingClaim(InsurancePolicy policy, String reason) {
    if (policy.payoutTransactionId() != null) {
      refundLedger.markDelivered(policy.payoutTransactionId());
      transactions
          .find(policy.payoutTransactionId())
          .ifPresent(
              transaction -> {
                if (transaction.state() == EconomyTransactionState.REFUND_PENDING) {
                  transactions.markManualReview(transaction.transactionId(), reason);
                }
              });
    }
    policies.put(
        policy.policyId(),
        new InsurancePolicy(
            policy.policyId(),
            policy.playerId(),
            policy.coverage(),
            policy.maxPayout(),
            policy.deductible(),
            policy.premium(),
            policy.startsAt(),
            policy.expiresAt(),
            InsurancePolicyState.CANCELLED,
            policy.claimSourceTransactionId(),
            policy.payoutTransactionId(),
            reason));
    persist();
  }

  private Optional<InsurancePolicy> findEligiblePolicy(
      UUID playerId, TransactionRecord source, Instant now) {
    return policies.values().stream()
        .filter(policy -> policy.playerId().equals(playerId))
        .filter(policy -> policy.activeAt(now))
        .filter(policy -> policy.coverage().owner() == source.owner())
        .filter(policy -> policy.coverage().type() == source.type())
        .filter(
            ignored ->
                source.state() == EconomyTransactionState.REFUND_PENDING
                    || source.state() == EconomyTransactionState.MANUAL_REVIEW
                    || source.state() == EconomyTransactionState.REFUNDED
                    || source.state() == EconomyTransactionState.DEBIT_FAILED
                    || source.state() == EconomyTransactionState.DELIVERY_FAILED)
        .filter(
            ignored ->
                (source.state() != EconomyTransactionState.REFUND_PENDING
                        && source.state() != EconomyTransactionState.REFUNDED)
                    || hasManualRefund(source))
        .sorted(Comparator.comparing(InsurancePolicy::expiresAt))
        .findFirst();
  }

  private boolean hasManualRefund(TransactionRecord source) {
    return refundLedger.snapshot().stream()
        .anyMatch(refund -> refund.reason().equals(source.reason()) && refund.manualReview());
  }

  private void expirePolicies(Instant now) {
    boolean changed = false;
    for (InsurancePolicy policy : new ArrayList<>(policies.values())) {
      if (policy.state() == InsurancePolicyState.ACTIVE && !now.isBefore(policy.expiresAt())) {
        policies.put(
            policy.policyId(),
            new InsurancePolicy(
                policy.policyId(),
                policy.playerId(),
                policy.coverage(),
                policy.maxPayout(),
                policy.deductible(),
                policy.premium(),
                policy.startsAt(),
                policy.expiresAt(),
                InsurancePolicyState.EXPIRED,
                policy.claimSourceTransactionId(),
                policy.payoutTransactionId(),
                "policy expired"));
        changed = true;
      }
    }
    if (changed) persist();
  }

  private static void validateQuote(
      UUID playerId,
      InsuranceCoverage coverage,
      BigDecimal maxPayout,
      BigDecimal deductible,
      int durationDays) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(coverage, "coverage");
    Objects.requireNonNull(maxPayout, "maxPayout");
    Objects.requireNonNull(deductible, "deductible");
    if (maxPayout.signum() <= 0) throw new IllegalArgumentException("maxPayout must be positive");
    if (deductible.signum() < 0 || deductible.compareTo(maxPayout) > 0) {
      throw new IllegalArgumentException("deductible must be within payout range");
    }
    if (durationDays < 1 || durationDays > MAX_DURATION_DAYS) {
      throw new IllegalArgumentException("durationDays must be between 1 and " + MAX_DURATION_DAYS);
    }
  }

  private void ensureReserved(TransactionRecord record) {
    if (record.state() == EconomyTransactionState.CREATED) {
      transactions.transition(
          record.transactionId(), EconomyTransactionState.RESERVED, "insurance premium reserved");
      return;
    }
    if (record.state() != EconomyTransactionState.RESERVED) {
      throw new IllegalStateException("Unexpected premium transaction state: " + record.state());
    }
  }

  private void commit(UUID transactionId, String debitMessage, String deliveryMessage) {
    transactions.transition(transactionId, EconomyTransactionState.DEBITED, debitMessage);
    transactions.transition(transactionId, EconomyTransactionState.DELIVERED, deliveryMessage);
    transactions.transition(
        transactionId, EconomyTransactionState.COMMITTED, "insurance premium committed");
  }

  private void load() {
    if (!Files.exists(file)) return;
    Properties properties = new Properties();
    try (InputStream input = Files.newInputStream(file)) {
      properties.load(input);
      for (String key : properties.stringPropertyNames()) {
        if (!key.startsWith("policy.") || !key.endsWith(".player")) continue;
        String idText = key.substring("policy.".length(), key.length() - ".player".length());
        try {
          UUID id = UUID.fromString(idText);
          String prefix = "policy." + id;
          policies.put(
              id,
              new InsurancePolicy(
                  id,
                  UUID.fromString(properties.getProperty(key)),
                  InsuranceCoverage.valueOf(properties.getProperty(prefix + ".coverage")),
                  new BigDecimal(properties.getProperty(prefix + ".max")),
                  new BigDecimal(properties.getProperty(prefix + ".deductible")),
                  new BigDecimal(properties.getProperty(prefix + ".premium")),
                  Instant.parse(properties.getProperty(prefix + ".starts")),
                  Instant.parse(properties.getProperty(prefix + ".expires")),
                  InsurancePolicyState.valueOf(properties.getProperty(prefix + ".state")),
                  parseUuid(properties.getProperty(prefix + ".source")),
                  parseUuid(properties.getProperty(prefix + ".payout")),
                  properties.getProperty(prefix + ".error")));
        } catch (RuntimeException invalid) {
          logger.log(Level.WARNING, "Skipping invalid insurance policy " + idText, invalid);
        }
      }
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to load insurance policies " + file, exception);
    }
  }

  private void persist() {
    try {
      Path parent = file.toAbsolutePath().getParent();
      if (parent != null) Files.createDirectories(parent);
      Properties properties = new Properties();
      properties.setProperty("version", VERSION);
      for (InsurancePolicy policy : policies.values()) {
        String prefix = "policy." + policy.policyId();
        properties.setProperty(prefix + ".player", policy.playerId().toString());
        properties.setProperty(prefix + ".coverage", policy.coverage().name());
        properties.setProperty(prefix + ".max", policy.maxPayout().toPlainString());
        properties.setProperty(prefix + ".deductible", policy.deductible().toPlainString());
        properties.setProperty(prefix + ".premium", policy.premium().toPlainString());
        properties.setProperty(prefix + ".starts", policy.startsAt().toString());
        properties.setProperty(prefix + ".expires", policy.expiresAt().toString());
        properties.setProperty(prefix + ".state", policy.state().name());
        if (policy.claimSourceTransactionId() != null)
          properties.setProperty(prefix + ".source", policy.claimSourceTransactionId().toString());
        if (policy.payoutTransactionId() != null)
          properties.setProperty(prefix + ".payout", policy.payoutTransactionId().toString());
        if (policy.lastError() != null)
          properties.setProperty(prefix + ".error", policy.lastError());
      }
      Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
      try (OutputStream output =
          Files.newOutputStream(
              temporary,
              StandardOpenOption.CREATE,
              StandardOpenOption.TRUNCATE_EXISTING,
              StandardOpenOption.WRITE)) {
        properties.store(
            new OutputStreamWriter(output, StandardCharsets.UTF_8), "STARCORE economy insurance");
      }
      try {
        Files.move(
            temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
        Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
      }
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to persist insurance policies " + file, exception);
    }
  }

  private static UUID parseUuid(String value) {
    if (value == null || value.isBlank()) return null;
    try {
      return UUID.fromString(value);
    } catch (IllegalArgumentException invalid) {
      return null;
    }
  }
}
