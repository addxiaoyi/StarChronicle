package dev.starcore.starcore.foundation.economy.transaction;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/** File-backed, idempotent transaction coordinator shared by economy modules. */
public final class TransactionFabric {
  private static final String VERSION = "1";
  private static final Pattern BASE64_URL_NO_PADDING = Pattern.compile("[A-Za-z0-9_-]*");
  private final Path file;
  private final Logger logger;
  private final ConcurrentHashMap<UUID, TransactionRecord> records = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, UUID> byIdempotencyKey = new ConcurrentHashMap<>();
  private volatile Consumer<TransactionRecord> auditSink = ignored -> {};
  private boolean persistencePending;
  private TransactionRecord pendingAudit;
  private final CopyOnWriteArrayList<Consumer<TransactionRecord>> observers =
      new CopyOnWriteArrayList<>();

  public TransactionFabric(Path file, Logger logger) {
    this.file = Objects.requireNonNull(file, "file");
    this.logger = Objects.requireNonNull(logger, "logger");
    load();
  }

  public void setAuditSink(Consumer<TransactionRecord> auditSink) {
    this.auditSink = Objects.requireNonNull(auditSink, "auditSink");
  }

  /** Registers a read-only observer for live transaction state changes. */
  public Runnable registerObserver(Consumer<TransactionRecord> observer) {
    Consumer<TransactionRecord> checked = Objects.requireNonNull(observer, "observer");
    observers.add(checked);
    return () -> observers.remove(checked);
  }

  private void publishAudit(TransactionRecord record) {
    try {
      auditSink.accept(record);
    } catch (RuntimeException failure) {
      logger.log(
          Level.WARNING, "Transaction audit sink failed for " + record.transactionId(), failure);
    }
    for (Consumer<TransactionRecord> observer : observers) {
      try {
        observer.accept(record);
      } catch (RuntimeException failure) {
        logger.log(
            Level.WARNING, "Transaction observer failed for " + record.transactionId(), failure);
      }
    }
  }

  public synchronized TransactionRecord begin(TransactionRequest request) {
    Objects.requireNonNull(request, "request");
    flushPending();
    UUID existingId = byIdempotencyKey.get(request.idempotencyKey());
    if (existingId != null) {
      TransactionRecord existing = require(existingId);
      ensureSameRequest(existing, request);
      return existing;
    }
    Instant now = Instant.now();
    UUID id = UUID.randomUUID();
    TransactionRecord created =
        new TransactionRecord(
            id,
            request.accountId(),
            request.amount(),
            request.owner(),
            request.type(),
            request.reason(),
            request.idempotencyKey(),
            request.metadata(),
            EconomyTransactionState.CREATED,
            0,
            now,
            now,
            null,
            List.of(new TransactionEvent(now, EconomyTransactionState.CREATED, "created")));
    records.put(id, created);
    byIdempotencyKey.put(request.idempotencyKey(), id);
    pendingAudit = created;
    persist();
    publishPendingAudit();
    return created;
  }

  public synchronized TransactionRecord transition(
      UUID transactionId, EconomyTransactionState next, String message) {
    flushPending();
    TransactionRecord current = require(transactionId);
    if (current.state() == next) return current;
    if (!current.state().canTransitionTo(next)) {
      throw new IllegalStateException(
          "Illegal transaction transition " + current.state() + " -> " + next);
    }
    TransactionRecord updated = current.transition(next, message, Instant.now());
    records.put(transactionId, updated);
    pendingAudit = updated;
    persist();
    publishPendingAudit();
    return updated;
  }

  public synchronized TransactionRecord fail(UUID transactionId, String message) {
    Objects.requireNonNull(message, "message");
    flushPending();
    TransactionRecord current = require(transactionId);
    if (current.state().isTerminal()) return current;
    TransactionRecord updated = current.failed(message, Instant.now());
    records.put(transactionId, updated);
    pendingAudit = updated;
    persist();
    publishPendingAudit();
    return updated;
  }

  public synchronized TransactionRecord markManualReview(UUID transactionId, String reason) {
    return transition(transactionId, EconomyTransactionState.MANUAL_REVIEW, reason);
  }

  public synchronized Optional<TransactionRecord> find(UUID transactionId) {
    flushPending();
    return Optional.ofNullable(records.get(Objects.requireNonNull(transactionId, "transactionId")));
  }

  public synchronized Optional<TransactionRecord> findByIdempotencyKey(String idempotencyKey) {
    flushPending();
    Objects.requireNonNull(idempotencyKey, "idempotencyKey");
    UUID transactionId = byIdempotencyKey.get(idempotencyKey);
    return transactionId == null ? Optional.empty() : find(transactionId);
  }

  public synchronized List<TransactionRecord> snapshot() {
    flushPending();
    return records.values().stream()
        .sorted(Comparator.comparing(TransactionRecord::updatedAt))
        .toList();
  }

  public synchronized List<TransactionEvent> timeline(UUID transactionId) {
    flushPending();
    return require(transactionId).events();
  }

  public synchronized TransactionSummary summarize() {
    flushPending();
    int active = 0;
    int manual = 0;
    int failed = 0;
    Instant oldest = null;
    EnumMap<RefundOwner, Integer> owners = new EnumMap<>(RefundOwner.class);
    EnumMap<TransactionType, Integer> types = new EnumMap<>(TransactionType.class);
    for (TransactionRecord record : records.values()) {
      owners.merge(record.owner(), 1, Integer::sum);
      types.merge(record.type(), 1, Integer::sum);
      boolean failedState =
          record.state() == EconomyTransactionState.DEBIT_FAILED
              || record.state() == EconomyTransactionState.DELIVERY_FAILED;
      if (!record.state().isTerminal() && !failedState) active++;
      if (record.state() == EconomyTransactionState.MANUAL_REVIEW) manual++;
      if (failedState) failed++;
      if (oldest == null || record.updatedAt().isBefore(oldest)) oldest = record.updatedAt();
    }
    return new TransactionSummary(
        records.size(), active, manual, failed, owners, types, Optional.ofNullable(oldest));
  }

  private TransactionRecord require(UUID transactionId) {
    TransactionRecord record = records.get(Objects.requireNonNull(transactionId, "transactionId"));
    if (record == null) throw new IllegalArgumentException("Unknown transaction: " + transactionId);
    return record;
  }

  private static void ensureSameRequest(TransactionRecord existing, TransactionRequest request) {
    if (!existing.accountId().equals(request.accountId())
        || existing.amount().compareTo(request.amount()) != 0
        || existing.owner() != request.owner()
        || existing.type() != request.type()
        || !existing.reason().equals(request.reason())
        || !existing.metadata().equals(request.metadata())) {
      throw new IllegalArgumentException("Idempotency key is already bound to another transaction");
    }
  }

  private void load() {
    if (!Files.exists(file)) return;
    Properties properties = new Properties();
    try (InputStream input = Files.newInputStream(file)) {
      properties.load(new InputStreamReader(input, StandardCharsets.UTF_8));
      String persistedVersion = properties.getProperty("version");
      if (!VERSION.equals(persistedVersion)) {
        throw new IllegalStateException(
            "TRANSACTION_FABRIC_UNSUPPORTED_VERSION: version="
                + (persistedVersion == null ? "<missing>" : persistedVersion));
      }
      TreeSet<String> transactionIds = new TreeSet<>();
      for (String key : properties.stringPropertyNames()) {
        if (!key.startsWith("tx.")) continue;
        int fieldSeparator = key.indexOf('.', 3);
        if (fieldSeparator < 0) {
          throw new IllegalStateException(
              "TRANSACTION_FABRIC_INVALID_RECORD: transaction=" + key.substring(3));
        }
        transactionIds.add(key.substring(3, fieldSeparator));
      }
      for (String idText : transactionIds) {
        TransactionRecord record;
        try {
          UUID id = UUID.fromString(idText);
          String prefix = "tx." + idText;
          record =
              new TransactionRecord(
                  id,
                  UUID.fromString(properties.getProperty(prefix + ".account")),
                  new BigDecimal(properties.getProperty(prefix + ".amount")),
                  RefundOwner.valueOf(properties.getProperty(prefix + ".owner")),
                  TransactionType.valueOf(properties.getProperty(prefix + ".type")),
                  properties.getProperty(prefix + ".reason", "unspecified"),
                  properties.getProperty(prefix + ".idempotency"),
                  decodeMetadata(properties.getProperty(prefix + ".metadata", "")),
                  EconomyTransactionState.valueOf(properties.getProperty(prefix + ".state")),
                  Integer.parseInt(properties.getProperty(prefix + ".attempts", "0")),
                  Instant.parse(properties.getProperty(prefix + ".created")),
                  Instant.parse(properties.getProperty(prefix + ".updated")),
                  properties.getProperty(prefix + ".error"),
                  loadEvents(properties, prefix));
        } catch (RuntimeException invalid) {
          throw new IllegalStateException(
              "TRANSACTION_FABRIC_INVALID_RECORD: transaction=" + idText, invalid);
        }

        if (records.containsKey(record.transactionId())) {
          throw new IllegalStateException(
              "TRANSACTION_FABRIC_DUPLICATE_TRANSACTION_ID: transaction=" + record.transactionId());
        }
        UUID duplicateId = byIdempotencyKey.get(record.idempotencyKey());
        if (duplicateId != null && !duplicateId.equals(record.transactionId())) {
          throw new IllegalStateException(
              "TRANSACTION_FABRIC_DUPLICATE_IDEMPOTENCY_KEY: transactions="
                  + duplicateId
                  + ","
                  + record.transactionId());
        }
        records.put(record.transactionId(), record);
        byIdempotencyKey.put(record.idempotencyKey(), record.transactionId());
      }
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to load transaction fabric " + file, exception);
    }
  }

  private static List<TransactionEvent> loadEvents(Properties properties, String prefix) {
    int count = Integer.parseInt(properties.getProperty(prefix + ".events.count", "0"));
    List<TransactionEvent> events = new ArrayList<>(count);
    for (int index = 0; index < count; index++) {
      String eventPrefix = prefix + ".events." + index;
      events.add(
          new TransactionEvent(
              Instant.parse(properties.getProperty(eventPrefix + ".at")),
              EconomyTransactionState.valueOf(properties.getProperty(eventPrefix + ".state")),
              properties.getProperty(eventPrefix + ".message", "")));
    }
    return events;
  }

  private void flushPending() {
    if (persistencePending) {
      persist();
      publishPendingAudit();
    }
  }

  private void publishPendingAudit() {
    TransactionRecord record = pendingAudit;
    pendingAudit = null;
    if (record != null) publishAudit(record);
  }

  private void persist() {
    persistencePending = true;
    try {
      Files.createDirectories(file.toAbsolutePath().getParent());
      Properties properties = new Properties();
      properties.setProperty("version", VERSION);
      for (TransactionRecord record : records.values()) {
        String prefix = "tx." + record.transactionId();
        properties.setProperty(prefix + ".account", record.accountId().toString());
        properties.setProperty(prefix + ".amount", record.amount().toPlainString());
        properties.setProperty(prefix + ".owner", record.owner().name());
        properties.setProperty(prefix + ".type", record.type().name());
        properties.setProperty(prefix + ".reason", record.reason());
        properties.setProperty(prefix + ".idempotency", record.idempotencyKey());
        properties.setProperty(prefix + ".metadata", encodeMetadata(record.metadata()));
        properties.setProperty(prefix + ".state", record.state().name());
        properties.setProperty(prefix + ".attempts", Integer.toString(record.attempts()));
        properties.setProperty(prefix + ".created", record.createdAt().toString());
        properties.setProperty(prefix + ".updated", record.updatedAt().toString());
        if (record.lastError() != null)
          properties.setProperty(prefix + ".error", record.lastError());
        properties.setProperty(prefix + ".events.count", Integer.toString(record.events().size()));
        for (int index = 0; index < record.events().size(); index++) {
          TransactionEvent event = record.events().get(index);
          String eventPrefix = prefix + ".events." + index;
          properties.setProperty(eventPrefix + ".at", event.at().toString());
          properties.setProperty(eventPrefix + ".state", event.state().name());
          properties.setProperty(eventPrefix + ".message", event.message());
        }
      }
      Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
      try (OutputStream output =
          Files.newOutputStream(
              temporary,
              StandardOpenOption.CREATE,
              StandardOpenOption.TRUNCATE_EXISTING,
              StandardOpenOption.WRITE)) {
        properties.store(
            new OutputStreamWriter(output, StandardCharsets.UTF_8), "STARCORE transaction fabric");
      }
      try {
        Files.move(
            temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
      } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
        Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
      }
      persistencePending = false;
    } catch (IOException exception) {
      throw new IllegalStateException("Unable to persist transaction fabric " + file, exception);
    }
  }

  private static String encodeMetadata(Map<String, String> metadata) {
    Base64.Encoder encoder = Base64.getUrlEncoder().withoutPadding();
    return metadata.entrySet().stream()
        .map(
            entry ->
                encoder.encodeToString(entry.getKey().getBytes(StandardCharsets.UTF_8))
                    + ":"
                    + encoder.encodeToString(entry.getValue().getBytes(StandardCharsets.UTF_8)))
        .sorted()
        .reduce((left, right) -> left + "," + right)
        .orElse("");
  }

  private static Map<String, String> decodeMetadata(String encoded) {
    if (encoded.isEmpty()) return Map.of();
    Base64.Decoder decoder = Base64.getUrlDecoder();
    Map<String, String> metadata = new HashMap<>();
    for (String item : encoded.split(",", -1)) {
      String[] parts = item.split(":", -1);
      if (parts.length != 2
          || !BASE64_URL_NO_PADDING.matcher(parts[0]).matches()
          || !BASE64_URL_NO_PADDING.matcher(parts[1]).matches()) {
        throw new IllegalArgumentException("Malformed transaction metadata entry");
      }
      String key = decodeUtf8(decoder.decode(parts[0]));
      String value = decodeUtf8(decoder.decode(parts[1]));
      if (metadata.putIfAbsent(key, value) != null) {
        throw new IllegalArgumentException("Duplicate transaction metadata key: " + key);
      }
    }
    return metadata;
  }

  private static String decodeUtf8(byte[] bytes) {
    try {
      return StandardCharsets.UTF_8
          .newDecoder()
          .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
          .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
          .decode(java.nio.ByteBuffer.wrap(bytes))
          .toString();
    } catch (java.nio.charset.CharacterCodingException invalid) {
      throw new IllegalArgumentException("Transaction metadata is not valid UTF-8", invalid);
    }
  }
}
