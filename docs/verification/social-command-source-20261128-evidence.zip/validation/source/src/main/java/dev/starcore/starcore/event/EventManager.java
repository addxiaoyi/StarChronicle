package dev.starcore.starcore.event;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/** 事件管理器 管理所有事件的定义、实例和状态转换 */
public class EventManager {

  private final Map<String, EventDefinition> eventDefinitions = new ConcurrentHashMap<>();
  private final Map<String, EventInstance> eventInstances = new ConcurrentHashMap<>();
  private final Map<String, List<EventInstance>> epochEventInstances = new ConcurrentHashMap<>();
  private final Map<String, List<EventInstance>> playerEventInstances = new ConcurrentHashMap<>();

  // 锁机制
  private final Lock eventResolutionLock = new ReentrantLock();
  private final Lock cycleLock = new ReentrantLock();

  // 事件监听器
  private final List<EventListener> listeners = new ArrayList<>();

  /** 事件监听器接口 */
  public interface EventListener {
    void onEventStarted(EventInstance instance);

    void onEventCompleted(EventInstance instance);

    void onEventFailed(EventInstance instance);

    void onEventStatusChanged(EventInstance instance, EventStatus oldStatus, EventStatus newStatus);
  }

  /** 注册事件定义 */
  public void registerEventDefinition(EventDefinition definition) {
    eventDefinitions.put(definition.eventId(), definition);
  }

  /** 卸载事件定义 */
  public void unregisterEventDefinition(String eventId) {
    eventDefinitions.remove(eventId);
  }

  /** 获取事件定义 */
  public Optional<EventDefinition> getEventDefinition(String eventId) {
    return Optional.ofNullable(eventDefinitions.get(eventId));
  }

  /** 获取所有事件定义 */
  public Collection<EventDefinition> getAllEventDefinitions() {
    return eventDefinitions.values();
  }

  /** 创建事件实例 */
  public EventInstance createEventInstance(String eventId, String epochRunId, String ownerId) {
    EventDefinition definition = eventDefinitions.get(eventId);
    if (definition == null) {
      throw new IllegalArgumentException("Event definition not found: " + eventId);
    }

    String instanceId = generateInstanceId();
    EventInstance instance =
        EventInstance.builder(instanceId, eventId, epochRunId)
            .ownerId(ownerId)
            .status(EventStatus.defined)
            .startedAt(System.currentTimeMillis())
            .build();

    eventInstances.put(instanceId, instance);
    epochEventInstances.computeIfAbsent(epochRunId, k -> new ArrayList<>()).add(instance);
    if (ownerId != null) {
      playerEventInstances.computeIfAbsent(ownerId, k -> new ArrayList<>()).add(instance);
    }

    notifyEventStarted(instance);
    return instance;
  }

  /** 启动事件实例 */
  public void startEventInstance(String instanceId) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.in_progress,
            instance.context(),
            instance.results(),
            instance.startedAt() != null ? instance.startedAt() : System.currentTimeMillis(),
            instance.completedAt(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            instance.errorMessage(),
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
  }

  /** 完成事件实例 */
  public void completeEventInstance(String instanceId, Map<String, Object> results) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.completed,
            instance.context(),
            results,
            instance.startedAt(),
            System.currentTimeMillis(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            instance.errorMessage(),
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
    notifyEventCompleted(newInstance);
  }

  /** 确认事件结论 */
  public void confirmEventInstance(String instanceId) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.confirmed,
            instance.context(),
            instance.results(),
            instance.startedAt(),
            instance.completedAt(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            instance.errorMessage(),
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
  }

  /** 归档事件实例 */
  public void archiveEventInstance(String instanceId) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.archived,
            instance.context(),
            instance.results(),
            instance.startedAt(),
            instance.completedAt(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            instance.errorMessage(),
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
  }

  /** 取消事件实例 */
  public void cancelEventInstance(String instanceId, String reason) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.cancelled,
            instance.context(),
            instance.results(),
            instance.startedAt(),
            System.currentTimeMillis(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            reason,
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
  }

  /** 事件失败 */
  public void failEventInstance(String instanceId, String errorMessage) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            EventStatus.failed,
            instance.context(),
            instance.results(),
            instance.startedAt(),
            System.currentTimeMillis(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            errorMessage,
            instance.retryCount() + 1,
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
    notifyEventFailed(newInstance);
  }

  /** 更新事件状态 */
  public void updateEventStatus(String instanceId, EventStatus newStatus) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventInstance newInstance =
        new EventInstance(
            instance.instanceId(),
            instance.eventId(),
            instance.epochRunId(),
            newStatus,
            instance.context(),
            instance.results(),
            instance.startedAt(),
            instance.completedAt(),
            instance.ownerId(),
            instance.participants(),
            instance.currentBranch(),
            instance.branchResults(),
            instance.errorMessage(),
            instance.retryCount(),
            instance.parentInstanceId());

    eventInstances.put(instanceId, newInstance);
    notifyStatusChanged(instance, newInstance);
  }

  /** 获取事件实例 */
  public Optional<EventInstance> getEventInstance(String instanceId) {
    return Optional.ofNullable(eventInstances.get(instanceId));
  }

  /** 获取纪元的所有事件实例 */
  public List<EventInstance> getEpochEventInstances(String epochRunId) {
    return epochEventInstances.getOrDefault(epochRunId, Collections.emptyList());
  }

  /** 获取玩家的所有事件实例 */
  public List<EventInstance> getPlayerEventInstances(String playerId) {
    return playerEventInstances.getOrDefault(playerId, Collections.emptyList());
  }

  /** 获取所有事件实例 */
  public Collection<EventInstance> getAllEventInstances() {
    return eventInstances.values();
  }

  /** 根据事件类型获取事件定义 */
  public List<EventDefinition> getEventDefinitionsByType(EventType type) {
    return eventDefinitions.values().stream().filter(d -> d.type() == type).toList();
  }

  /** 根据纪元获取事件定义 */
  public List<EventDefinition> getEventDefinitionsByEpoch(String epochId) {
    return eventDefinitions.values().stream().filter(d -> epochId.equals(d.epochId())).toList();
  }

  /** 检查事件是否可以启动 */
  public boolean canStartEvent(String eventId, String epochRunId) {
    EventDefinition definition = eventDefinitions.get(eventId);
    if (definition == null) return false;

    // 检查前置条件
    if (definition.hasPrerequisites()) {
      for (String prerequisite : definition.prerequisites()) {
        // 检查前置事件是否已完成
        boolean prerequisiteMet =
            eventInstances.values().stream()
                .anyMatch(e -> e.eventId().equals(prerequisite) && e.isSuccessful());
        if (!prerequisiteMet) return false;
      }
    }

    return true;
  }

  /** 处理分支逻辑 */
  public void processBranch(String instanceId, String branchId, Map<String, Object> branchResults) {
    EventInstance instance = eventInstances.get(instanceId);
    if (instance == null) return;

    EventDefinition definition = eventDefinitions.get(instance.eventId());
    if (definition == null) return;

    definition
        .getBranch(branchId)
        .ifPresent(
            branch -> {
              EventInstance newInstance =
                  new EventInstance(
                      instance.instanceId(),
                      instance.eventId(),
                      instance.epochRunId(),
                      instance.status(),
                      instance.context(),
                      instance.results(),
                      instance.startedAt(),
                      instance.completedAt(),
                      instance.ownerId(),
                      instance.participants(),
                      branchId,
                      branchResults,
                      instance.errorMessage(),
                      instance.retryCount(),
                      instance.parentInstanceId());

              eventInstances.put(instanceId, newInstance);
            });
  }

  /** 添加事件监听器 */
  public void addEventListener(EventListener listener) {
    listeners.add(listener);
  }

  /** 移除事件监听器 */
  public void removeEventListener(EventListener listener) {
    listeners.remove(listener);
  }

  /** 生成实例ID */
  private String generateInstanceId() {
    return "evt_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 通知事件开始 */
  private void notifyEventStarted(EventInstance instance) {
    for (EventListener listener : listeners) {
      listener.onEventStarted(instance);
    }
  }

  /** 通知事件完成 */
  private void notifyEventCompleted(EventInstance instance) {
    for (EventListener listener : listeners) {
      listener.onEventCompleted(instance);
    }
  }

  /** 通知事件失败 */
  private void notifyEventFailed(EventInstance instance) {
    for (EventListener listener : listeners) {
      listener.onEventFailed(instance);
    }
  }

  /** 通知状态变化 */
  private void notifyStatusChanged(EventInstance oldInstance, EventInstance newInstance) {
    if (oldInstance.status() != newInstance.status()) {
      for (EventListener listener : listeners) {
        listener.onEventStatusChanged(newInstance, oldInstance.status(), newInstance.status());
      }
    }
  }

  /** 清理所有事件 */
  public void clear() {
    eventDefinitions.clear();
    eventInstances.clear();
    epochEventInstances.clear();
    playerEventInstances.clear();
  }

  /** 获取事件解决锁 */
  public Lock getEventResolutionLock() {
    return eventResolutionLock;
  }

  /** 获取周期锁 */
  public Lock getCycleLock() {
    return cycleLock;
  }
}
