package dev.starcore.starcore.core.guide;

import java.util.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class GameplayGuideGui implements InventoryHolder {
  public static final int GUI_ROWS = 6;
  public static final int GUI_SIZE = GUI_ROWS * 9;
  private Inventory inventory;
  private GuideChapter currentChapter;
  private GuideContentProvider.GuideItem currentItem;
  private int currentPage;
  private ViewLevel viewLevel;
  private List<GuideSearchService.SearchResult> searchResults = List.of();
  private String searchQuery = "";

  public enum ViewLevel {
    DASHBOARD,
    CATEGORY_PAGE,
    ITEM_DETAIL,
    STATS,
    SEARCH_RESULTS
  }

  public static void openDashboard(Player player) {
    GameplayGuideGui gui = new GameplayGuideGui();
    gui.buildDashboard(player);
    player.openInventory(gui.getInventory());
  }

  public static void openCategoryPage(Player player, GuideChapter chapter, int page) {
    GameplayGuideGui gui = new GameplayGuideGui();
    gui.buildCategoryPage(player, chapter, page);
    player.openInventory(gui.getInventory());
  }

  public static void openItemDetail(
      Player player, GuideChapter chapter, GuideContentProvider.GuideItem item) {
    GameplayGuideGui gui = new GameplayGuideGui();
    gui.buildItemDetail(player, chapter, item);
    player.openInventory(gui.getInventory());
  }

  public static void openStats(Player player) {
    GameplayGuideGui gui = new GameplayGuideGui();
    gui.buildStats(player);
    player.openInventory(gui.getInventory());
  }

  public static void openSearchResults(
      Player player, String query, List<GuideSearchService.SearchResult> results) {
    GameplayGuideGui gui = new GameplayGuideGui();
    gui.buildSearchResults(player, query, results);
    player.openInventory(gui.getInventory());
  }

  public static void openMainMenu(Player player) {
    openDashboard(player);
  }

  public static void openChapter(Player player, GuideChapter chapter, int page) {
    openCategoryPage(player, chapter, page);
  }

  @Override
  public Inventory getInventory() {
    return inventory;
  }

  public ViewLevel getViewLevel() {
    return viewLevel;
  }

  public GuideChapter getCurrentChapter() {
    return currentChapter;
  }

  public GuideContentProvider.GuideItem getCurrentItem() {
    return currentItem;
  }

  public int getCurrentPage() {
    return currentPage;
  }

  public GuideSearchService.SearchResult getSearchResult(int index) {
    return index >= 0 && index < searchResults.size() ? searchResults.get(index) : null;
  }

  private void buildDashboard(Player player) {
    this.viewLevel = ViewLevel.DASHBOARD;
    String title =
        "§6§lSTARCORE §f指南 §7进度: §a"
            + GuideProgressService.getProgress(player).getTotalProgress()
            + "%";
    inventory =
        Bukkit.createInventory(
            this, GUI_SIZE, LegacyComponentSerializer.legacySection().deserialize(title));
    inventory.clear();
    inventory.setItem(4, createDashboardHeader(player));
    List<GuideChapter> chapters = Arrays.asList(GuideChapter.values());
    int[] positions = {10, 11, 12, 13, 15, 16, 19, 20};
    for (int i = 0; i < Math.min(chapters.size(), positions.length); i++) {
      inventory.setItem(positions[i], createChapterCard(player, chapters.get(i)));
    }
    inventory.setItem(39, createSearchButton());
    inventory.setItem(40, createStatsButton(player));
    inventory.setItem(44, createCloseButton());
  }

  private ItemStack createDashboardHeader(Player player) {
    ItemStack item = new ItemStack(Material.GOLDEN_APPLE);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§6§lSTARCORE 玩法指南"));
    List<Component> lore = new ArrayList<>();
    lore.add(LegacyComponentSerializer.legacySection().deserialize("§7欢迎, §e" + player.getName()));
    lore.add(
        LegacyComponentSerializer.legacySection()
            .deserialize(
                "§7总进度: §a" + GuideProgressService.getProgress(player).getTotalProgress() + "%"));
    lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
    lore.add(LegacyComponentSerializer.legacySection().deserialize("§7选择一个分类开始探索"));
    meta.lore(lore);
    item.setItemMeta(meta);
    item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
    return item;
  }

  private ItemStack createChapterCard(Player player, GuideChapter chapter) {
    boolean unlocked = GuideProgressService.isChapterUnlocked(player, chapter);
    int progress = GuideProgressService.getChapterProgress(player, chapter);
    int totalItems = GuideContentProvider.getItemCount(chapter);
    if (unlocked) {
      ItemStack item = new ItemStack(chapter.getTheme().getIcon());
      ItemMeta meta = item.getItemMeta();
      meta.setEnchantmentGlintOverride(true);
      meta.displayName(
          LegacyComponentSerializer.legacySection()
              .deserialize(chapter.getTheme().getColor() + "§l" + chapter.getTitle()));
      List<Component> lore = new ArrayList<>();
      lore.add(
          LegacyComponentSerializer.legacySection().deserialize("§7" + chapter.getDescription()));
      lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
      lore.add(
          LegacyComponentSerializer.legacySection()
              .deserialize("§7进度: §a" + progress + "% §7(§f" + totalItems + "§7项)"));
      lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§e§l点击查看"));
      meta.lore(lore);
      item.setItemMeta(meta);
      item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      return item;
    } else {
      ItemStack item = new ItemStack(Material.BARRIER);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(
          LegacyComponentSerializer.legacySection()
              .deserialize("§c§l" + chapter.getTitle() + " §c[未解锁]"));
      List<Component> lore = new ArrayList<>();
      lore.add(
          LegacyComponentSerializer.legacySection().deserialize("§7" + chapter.getDescription()));
      lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
      lore.add(
          LegacyComponentSerializer.legacySection()
              .deserialize("§c" + chapter.getUnlockCondition().getDisplayName()));
      lore.add(
          LegacyComponentSerializer.legacySection()
              .deserialize(
                  "§7需要总进度 §f" + chapter.getUnlockCondition().getProgressThreshold() + "%"));
      meta.lore(lore);
      item.setItemMeta(meta);
      item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      return item;
    }
  }

  private void buildCategoryPage(Player player, GuideChapter chapter, int page) {
    this.viewLevel = ViewLevel.CATEGORY_PAGE;
    this.currentChapter = chapter;
    this.currentPage = page;
    List<GuideContentProvider.GuideItem> itemsList = GuideContentProvider.getItems(chapter);
    int totalPages = Math.max(1, (int) Math.ceil((double) itemsList.size() / 7));
    page = Math.min(page, totalPages - 1);
    this.currentPage = page;
    String title =
        chapter.getTheme().getColor()
            + "§l"
            + chapter.getTitle()
            + " §7("
            + (page + 1)
            + "/"
            + totalPages
            + ")";
    inventory =
        Bukkit.createInventory(
            this, GUI_SIZE, LegacyComponentSerializer.legacySection().deserialize(title));
    inventory.clear();
    inventory.setItem(4, createCategoryHeader(player, chapter, page, totalPages));
    int startIndex = page * 7;
    int endIndex = Math.min(startIndex + 7, itemsList.size());
    int slot = 11;
    GuideProgressService.PlayerProgress progress = GuideProgressService.getProgress(player);
    for (int i = startIndex; i < endIndex; i++) {
      GuideContentProvider.GuideItem gi = itemsList.get(i);
      boolean itemUnlocked =
          progress.getUnlockedItems(chapter).contains(gi.id())
              || GuideProgressService.canAccessItem(player, chapter, gi);
      inventory.setItem(slot, createItemCard(gi, itemUnlocked));
      slot++;
      if (slot == 18) slot = 20;
      if (slot == 27) slot = 29;
    }
    if (page > 0) inventory.setItem(38, createPrevButton());
    if (page < totalPages - 1) inventory.setItem(42, createNextButton());
    inventory.setItem(40, createBackButton());
  }

  private ItemStack createCategoryHeader(
      Player player, GuideChapter chapter, int page, int totalPages) {
    int chapterProgress = GuideProgressService.getChapterProgress(player, chapter);
    ItemStack item = new ItemStack(chapter.getTheme().getIcon());
    ItemMeta meta = item.getItemMeta();
    meta.setEnchantmentGlintOverride(true);
    meta.displayName(
        LegacyComponentSerializer.legacySection()
            .deserialize(chapter.getTheme().getColor() + "§l" + chapter.getTitle()));
    List<Component> lore = new ArrayList<>();
    lore.add(
        LegacyComponentSerializer.legacySection().deserialize("§7" + chapter.getDescription()));
    lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
    lore.add(
        LegacyComponentSerializer.legacySection().deserialize("§7进度: §a" + chapterProgress + "%"));
    lore.add(
        LegacyComponentSerializer.legacySection()
            .deserialize("§7第 §f" + (page + 1) + "/" + totalPages + " §7页"));
    meta.lore(lore);
    item.setItemMeta(meta);
    item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
    return item;
  }

  private ItemStack createItemCard(GuideContentProvider.GuideItem gi, boolean unlocked) {
    if (unlocked) {
      ItemStack item = new ItemStack(gi.icon());
      ItemMeta meta = item.getItemMeta();
      meta.setEnchantmentGlintOverride(true);
      meta.displayName(
          LegacyComponentSerializer.legacySection()
              .deserialize(gi.tier().getColor() + "§l" + gi.title()));
      List<Component> lore = new ArrayList<>();
      lore.add(LegacyComponentSerializer.legacySection().deserialize(gi.subtitle()));
      lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
      lore.add(
          LegacyComponentSerializer.legacySection()
              .deserialize("§7等级: " + gi.tier().getDisplayName()));
      if (!gi.prerequisites().isEmpty())
        lore.add(
            LegacyComponentSerializer.legacySection()
                .deserialize("§7前置: §f" + gi.prerequisites().size() + " 项"));
      lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§e§l点击查看详情"));
      meta.lore(lore);
      item.setItemMeta(meta);
      item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      return item;
    } else {
      ItemStack item = new ItemStack(Material.BARRIER);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(
          LegacyComponentSerializer.legacySection().deserialize("§c§l" + gi.title() + " §c[未解锁]"));
      List<Component> lore = new ArrayList<>();
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§7完成前置条件解锁"));
      meta.lore(lore);
      item.setItemMeta(meta);
      item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      return item;
    }
  }

  private void buildItemDetail(
      Player player, GuideChapter chapter, GuideContentProvider.GuideItem gi) {
    this.viewLevel = ViewLevel.ITEM_DETAIL;
    this.currentChapter = chapter;
    this.currentItem = gi;
    boolean unlocked =
        GuideProgressService.getProgress(player).getUnlockedItems(chapter).contains(gi.id())
            || GuideProgressService.canAccessItem(player, chapter, gi);
    String title = chapter.getTheme().getColor() + "§l" + gi.title();
    inventory =
        Bukkit.createInventory(
            this, GUI_SIZE, LegacyComponentSerializer.legacySection().deserialize(title));
    inventory.clear();
    inventory.setItem(4, createItemDisplay(gi, unlocked));
    int loreSlot = 11;
    for (String line : gi.description()) {
      if (loreSlot > 25) break;
      inventory.setItem(loreSlot, createLoreItem(line, unlocked));
      loreSlot++;
      if (loreSlot == 15) loreSlot = 20;
      if (loreSlot == 24) loreSlot = 29;
    }
    if (!gi.prerequisites().isEmpty() && unlocked)
      inventory.setItem(30, createPrerequisiteItem(gi));
    inventory.setItem(39, createTierBadge(gi));
    inventory.setItem(40, createMarkLearnedButton(gi, unlocked));
    inventory.setItem(42, createActionButton(gi, unlocked));
    inventory.setItem(44, createBackButton());
  }

  private void buildStats(Player player) {
    this.viewLevel = ViewLevel.STATS;
    this.currentChapter = null;
    this.currentItem = null;
    inventory =
        Bukkit.createInventory(
            this, GUI_SIZE, LegacyComponentSerializer.legacySection().deserialize("§d§l我的指南进度"));
    inventory.clear();
    inventory.setItem(4, createDashboardHeader(player));

    int slot = 10;
    for (GuideChapter chapter : GuideChapter.values()) {
      inventory.setItem(slot, createStatsCard(player, chapter));
      slot++;
      if (slot == 17) slot = 19;
      if (slot == 26) slot = 28;
    }
    inventory.setItem(40, createBackButton());
  }

  private ItemStack createStatsCard(Player player, GuideChapter chapter) {
    ItemStack item = new ItemStack(chapter.getTheme().getIcon());
    ItemMeta meta = item.getItemMeta();
    int progress = GuideProgressService.getChapterProgress(player, chapter);
    boolean unlocked = GuideProgressService.isChapterUnlocked(player, chapter);
    meta.displayName(
        LegacyComponentSerializer.legacySection()
            .deserialize(chapter.getTheme().getColor() + "§l" + chapter.getTitle()));
    meta.lore(
        List.of(
            LegacyComponentSerializer.legacySection()
                .deserialize("§7状态: " + (unlocked ? "§a已解锁" : "§c未解锁")),
            LegacyComponentSerializer.legacySection().deserialize("§7章节进度: §a" + progress + "%"),
            LegacyComponentSerializer.legacySection()
                .deserialize("§7条目数: §f" + GuideContentProvider.getItemCount(chapter))));
    item.setItemMeta(meta);
    return item;
  }

  private void buildSearchResults(
      Player player, String query, List<GuideSearchService.SearchResult> results) {
    this.viewLevel = ViewLevel.SEARCH_RESULTS;
    this.currentChapter = null;
    this.currentItem = null;
    this.searchQuery = query == null ? "" : query.trim();
    this.searchResults = results == null ? List.of() : List.copyOf(results);
    String displayQuery = searchQuery.length() > 24 ? searchQuery.substring(0, 24) : searchQuery;
    inventory =
        Bukkit.createInventory(
            this,
            GUI_SIZE,
            LegacyComponentSerializer.legacySection().deserialize("§b§l指南搜索 §7" + displayQuery));
    inventory.clear();
    inventory.setItem(4, createSearchHeader());

    int[] slots = {
      10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34
    };
    for (int i = 0; i < Math.min(slots.length, searchResults.size()); i++) {
      inventory.setItem(slots[i], createSearchResultCard(searchResults.get(i)));
    }
    if (searchResults.isEmpty()) {
      ItemStack empty = new ItemStack(Material.BARRIER);
      ItemMeta meta = empty.getItemMeta();
      meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§c§l没有找到匹配内容"));
      meta.lore(List.of(LegacyComponentSerializer.legacySection().deserialize("§7换一个关键词再试一次")));
      empty.setItemMeta(meta);
      inventory.setItem(22, empty);
    }
    inventory.setItem(40, createBackButton());
  }

  private ItemStack createSearchHeader() {
    ItemStack item = new ItemStack(Material.COMPASS);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§b§l搜索结果"));
    meta.lore(
        List.of(
            LegacyComponentSerializer.legacySection().deserialize("§7关键词: §f" + searchQuery),
            LegacyComponentSerializer.legacySection()
                .deserialize("§7找到 §a" + searchResults.size() + " §7项，点击即可进入")));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createSearchResultCard(GuideSearchService.SearchResult result) {
    GuideContentProvider.GuideItem itemData = result.item();
    ItemStack item = new ItemStack(itemData.icon());
    ItemMeta meta = item.getItemMeta();
    meta.displayName(
        LegacyComponentSerializer.legacySection()
            .deserialize(itemData.tier().getColor() + "§l" + itemData.title()));
    meta.lore(
        List.of(
            LegacyComponentSerializer.legacySection()
                .deserialize("§7章节: §f" + result.chapter().getTitle()),
            LegacyComponentSerializer.legacySection().deserialize("§7" + itemData.subtitle()),
            LegacyComponentSerializer.legacySection().deserialize("§e点击查看并进入")));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createItemDisplay(GuideContentProvider.GuideItem gi, boolean unlocked) {
    ItemStack item = new ItemStack(unlocked ? gi.icon() : Material.BARRIER);
    ItemMeta meta = item.getItemMeta();
    if (unlocked) meta.setEnchantmentGlintOverride(true);
    meta.displayName(
        LegacyComponentSerializer.legacySection()
            .deserialize((unlocked ? gi.tier().getColor() : "§c") + "§l" + gi.title()));
    List<Component> lore = new ArrayList<>();
    lore.add(LegacyComponentSerializer.legacySection().deserialize(gi.subtitle()));
    lore.add(LegacyComponentSerializer.legacySection().deserialize(""));
    lore.add(
        LegacyComponentSerializer.legacySection()
            .deserialize("§7等级: " + gi.tier().getDisplayName()));
    lore.add(
        LegacyComponentSerializer.legacySection().deserialize(unlocked ? "§a✓ 已解锁" : "§c✗ 未解锁"));
    meta.lore(lore);
    item.setItemMeta(meta);
    item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
    return item;
  }

  private ItemStack createLoreItem(String line, boolean unlocked) {
    ItemStack item = new ItemStack(unlocked ? Material.PAPER : Material.GRAY_DYE);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize(line));
    item.setItemMeta(meta);
    item.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
    return item;
  }

  private ItemStack createPrerequisiteItem(GuideContentProvider.GuideItem gi) {
    ItemStack item = new ItemStack(Material.IRON_BARS);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§6§l前置条件"));
    List<Component> lore = new ArrayList<>();
    lore.add(LegacyComponentSerializer.legacySection().deserialize("§7需要完成以下内容:"));
    for (String prereq : gi.prerequisites())
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§a  • " + prereq));
    meta.lore(lore);
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createTierBadge(GuideContentProvider.GuideItem gi) {
    Map<GuideContentProvider.ItemTier, Material> tierMats =
        Map.of(
            GuideContentProvider.ItemTier.FOUNDATIONAL, Material.GREEN_GLAZED_TERRACOTTA,
            GuideContentProvider.ItemTier.INTERMEDIATE, Material.YELLOW_GLAZED_TERRACOTTA,
            GuideContentProvider.ItemTier.ADVANCED, Material.RED_GLAZED_TERRACOTTA);
    ItemStack item =
        new ItemStack(tierMats.getOrDefault(gi.tier(), Material.GRAY_GLAZED_TERRACOTTA));
    ItemMeta meta = item.getItemMeta();
    meta.displayName(
        LegacyComponentSerializer.legacySection()
            .deserialize(gi.tier().getColor() + "§l" + gi.tier().getDisplayName()));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createMarkLearnedButton(GuideContentProvider.GuideItem gi, boolean unlocked) {
    if (unlocked) {
      ItemStack item = new ItemStack(Material.KNOWLEDGE_BOOK);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§a§l标记为已学习"));
      List<Component> lore = new ArrayList<>();
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§7点击记录已学习此内容"));
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§7解锁后续进阶内容"));
      meta.lore(lore);
      item.setItemMeta(meta);
      return item;
    } else {
      ItemStack item = new ItemStack(Material.BARRIER);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§c§l需要先解锁"));
      List<Component> lore = new ArrayList<>();
      lore.add(LegacyComponentSerializer.legacySection().deserialize("§7完成前置条件后即可标记"));
      meta.lore(lore);
      item.setItemMeta(meta);
      return item;
    }
  }

  private ItemStack createActionButton(GuideContentProvider.GuideItem gi, boolean unlocked) {
    GuideAction action = GuideAction.forItem(gi.id()).orElse(null);
    if (!unlocked || action == null) {
      ItemStack item = new ItemStack(Material.BARRIER);
      ItemMeta meta = item.getItemMeta();
      meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§c§l暂不可操作"));
      meta.lore(List.of(LegacyComponentSerializer.legacySection().deserialize("§7完成解锁条件后使用")));
      item.setItemMeta(meta);
      return item;
    }

    ItemStack item = new ItemStack(Material.COMPASS);
    ItemMeta meta = item.getItemMeta();
    meta.setEnchantmentGlintOverride(true);
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§b§l开始这一步"));
    meta.lore(
        List.of(
            LegacyComponentSerializer.legacySection().deserialize("§7点击后直接打开：§f" + action.label()),
            LegacyComponentSerializer.legacySection().deserialize("§7权限、余额和参数仍由系统检查")));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createCloseButton() {
    ItemStack item = new ItemStack(Material.BARRIER);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§c§l关闭指南"));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createBackButton() {
    ItemStack item = new ItemStack(Material.ARROW);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§6§l返回"));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createPrevButton() {
    ItemStack item = new ItemStack(Material.ARROW);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§e上一页"));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createNextButton() {
    ItemStack item = new ItemStack(Material.ARROW);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§e下一页"));
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createSearchButton() {
    ItemStack item = new ItemStack(Material.COMPASS);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§b§l搜索指南"));
    List<Component> lore = new ArrayList<>();
    lore.add(LegacyComponentSerializer.legacySection().deserialize("§7输入关键字快速查找"));
    meta.lore(lore);
    item.setItemMeta(meta);
    return item;
  }

  private ItemStack createStatsButton(Player player) {
    ItemStack item = new ItemStack(Material.EXPERIENCE_BOTTLE);
    ItemMeta meta = item.getItemMeta();
    meta.displayName(LegacyComponentSerializer.legacySection().deserialize("§d§l我的进度"));
    List<Component> lore = new ArrayList<>();
    GuideProgressService.PlayerProgress progress = GuideProgressService.getProgress(player);
    lore.add(
        LegacyComponentSerializer.legacySection()
            .deserialize("§7总进度: §a" + progress.getTotalProgress() + "%"));
    for (GuideChapter ch : GuideChapter.values()) {
      int p = progress.getChapterProgress(ch);
      String symbol = GuideProgressService.isChapterUnlocked(player, ch) ? "§a✓" : "§c🔒";
      lore.add(
          LegacyComponentSerializer.legacySection()
              .deserialize(symbol + " " + ch.getTitle() + ": §f" + p + "%"));
    }
    meta.lore(lore);
    item.setItemMeta(meta);
    return item;
  }
}
