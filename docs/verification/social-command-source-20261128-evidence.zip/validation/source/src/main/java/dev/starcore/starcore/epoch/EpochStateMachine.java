package dev.starcore.starcore.epoch;

import dev.starcore.starcore.core.event.EventBridge;
import java.util.*;

/** 纪元状态机 管理纪元状态转换的规则和逻辑 */
public class EpochStateMachine {

  /** 状态转换规则定义 */
  public static class TransitionRule {
    private final EpochState from;
    private final EpochState to;
    private final String condition;
    private final String action;

    public TransitionRule(EpochState from, EpochState to, String condition, String action) {
      this.from = from;
      this.to = to;
      this.condition = condition;
      this.action = action;
    }

    public boolean canTransition(Epoch epoch) {
      return epoch.state() == from && checkCondition(epoch);
    }

    private boolean checkCondition(Epoch epoch) {
      // 根据条件字符串检查具体条件
      return true; // 简化实现，实际需要根据具体条件判断
    }

    public EpochState getFrom() {
      return from;
    }

    public EpochState getTo() {
      return to;
    }

    public String getCondition() {
      return condition;
    }

    public String getAction() {
      return action;
    }
  }

  private final Map<EpochState, List<TransitionRule>> transitionRules;
  private final Map<String, Epoch> epochs;
  private final Map<String, Milestone> milestones = new HashMap<>();
  private final Map<String, String> decisions = new HashMap<>();
  private final EpochEventBus eventBus;
  private final EventBridge eventBridge;

  public EpochStateMachine() {
    this.transitionRules = new HashMap<>();
    this.epochs = new HashMap<>();
    this.eventBus = new EpochEventBus();
    this.eventBridge = null;
    initializeRules();
  }

  public EpochStateMachine(EventBridge eventBridge) {
    this.transitionRules = new HashMap<>();
    this.epochs = new HashMap<>();
    this.eventBus = new EpochEventBus();
    this.eventBridge = eventBridge;
    initializeRules();
  }

  /** 获取事件总线 */
  public EpochEventBus getEventBus() {
    return eventBus;
  }

  /** 初始化状态转换规则 */
  private void initializeRules() {
    // 从锁定到准备
    addRule(EpochState.locked, EpochState.preparing, "pre_migration_complete", "start_preparation");

    // 从准备到就绪
    addRule(EpochState.preparing, EpochState.ready, "preparation_checks_passed", "mark_ready");

    // 从就绪到活跃
    addRule(EpochState.ready, EpochState.active, "operator_approved", "activate_epoch");

    // 从活跃到决策待定
    addRule(
        EpochState.active,
        EpochState.decision_pending,
        "public_choices_opened",
        "open_decision_phase");

    // 从决策待定到解决待定
    addRule(
        EpochState.decision_pending,
        EpochState.resolution_pending,
        "decision_selected",
        "lock_decision");

    // 从解决待定到迁移准备
    addRule(
        EpochState.resolution_pending,
        EpochState.migration_preparing,
        "resolution_complete",
        "start_migration_prep");

    // 从迁移准备到迁移中
    addRule(
        EpochState.migration_preparing,
        EpochState.migrating,
        "migration_package_ready",
        "start_migration");

    // 从迁移中到验证
    addRule(
        EpochState.migrating, EpochState.verification, "migration_complete", "start_verification");

    // 从验证到归档
    addRule(EpochState.verification, EpochState.archived, "verification_passed", "archive_epoch");

    // 暂停相关转换
    addRule(EpochState.active, EpochState.suspended, "operator_requested", "suspend_epoch");
    addRule(EpochState.suspended, EpochState.recovery, "operator_requested", "start_recovery");
    addRule(EpochState.recovery, EpochState.active, "recovery_complete", "resume_epoch");

    // 取消转换
    addRule(EpochState.preparing, EpochState.cancelled, "operator_requested", "cancel_epoch");
    addRule(EpochState.ready, EpochState.cancelled, "operator_requested", "cancel_epoch");
  }

  private void addRule(EpochState from, EpochState to, String condition, String action) {
    transitionRules
        .computeIfAbsent(from, k -> new ArrayList<>())
        .add(new TransitionRule(from, to, condition, action));
  }

  /** 注册纪元 */
  public void registerEpoch(Epoch epoch) {
    epochs.put(epoch.epochRunId(), epoch);
  }

  /** 卸载纪元 */
  public void unregisterEpoch(String epochRunId) {
    epochs.remove(epochRunId);
  }

  /** 获取纪元 */
  public Optional<Epoch> getEpoch(String epochRunId) {
    return Optional.ofNullable(epochs.get(epochRunId));
  }

  /** 获取所有纪元 */
  public Collection<Epoch> getAllEpochs() {
    return epochs.values();
  }

  /** 尝试状态转换 */
  public boolean tryTransition(String epochRunId, String condition, String action) {
    Epoch epoch = epochs.get(epochRunId);
    if (epoch == null) return false;

    List<TransitionRule> rules = transitionRules.get(epoch.state());
    if (rules == null) return false;

    for (TransitionRule rule : rules) {
      if (rule.getCondition().equals(condition)
          && rule.getAction().equals(action)
          && rule.canTransition(epoch)) {

        Epoch newEpoch =
            new Epoch(
                epoch.epochRunId(),
                epoch.cycleId(),
                epoch.epochNumber(),
                rule.getTo(),
                epoch.variantKey(),
                epoch.sourceMigrationId(),
                epoch.startedAt(),
                epoch.decisionRef(),
                epoch.milestoneRef(),
                epoch.targetMigrationId(),
                epoch.suspensionRef(),
                epoch.recoveryRef(),
                epoch.archivedAt(),
                epoch.name(),
                epoch.description());

        // 发布状态转换事件
        EpochEventType eventType = getEventTypeForTransition(epoch.state(), rule.getTo());
        eventBus.post(
            EpochEvent.builder(UUID.randomUUID().toString(), epochRunId, eventType)
                .name("纪元状态转换")
                .description(
                    "从 " + epoch.state().getDisplayName() + " 到 " + rule.getTo().getDisplayName())
                .addMetadata("from_state", epoch.state().name())
                .addMetadata("to_state", rule.getTo().name())
                .addMetadata("condition", condition)
                .addMetadata("action", action)
                .source(epoch.state().name())
                .targetState(rule.getTo().name())
                .build());

        epochs.put(epochRunId, newEpoch);

        // 发布到跨系统事件桥
        if (eventBridge != null) {
          if (rule.getTo() == EpochState.active) {
            eventBridge.publish(EventBridge.EventTypes.EPOCH_START, newEpoch);
          } else if (rule.getTo() == EpochState.archived || rule.getTo() == EpochState.cancelled) {
            eventBridge.publish(EventBridge.EventTypes.EPOCH_END, newEpoch);
          } else {
            eventBridge.publish(
                EventBridge.EventTypes.EPOCH_TRANSITION,
                Map.of(
                    "epoch", newEpoch,
                    "from", epoch.state().name(),
                    "to", rule.getTo().name()));
          }
        }
        return true;
      }
    }
    return false;
  }

  /** 获取可用的转换选项 */
  public List<TransitionRule> getAvailableTransitions(String epochRunId) {
    Epoch epoch = epochs.get(epochRunId);
    if (epoch == null) return Collections.emptyList();

    List<TransitionRule> rules = transitionRules.get(epoch.state());
    if (rules == null) return Collections.emptyList();

    List<TransitionRule> available = new ArrayList<>();
    for (TransitionRule rule : rules) {
      if (rule.canTransition(epoch)) {
        available.add(rule);
      }
    }
    return available;
  }

  /** 获取当前活跃的纪元 */
  public Optional<Epoch> getActiveEpoch() {
    return epochs.values().stream().filter(Epoch::isActive).findFirst();
  }

  /** 获取最新的归档纪元 */
  public Optional<Epoch> getLatestArchivedEpoch() {
    return epochs.values().stream()
        .filter(e -> e.isArchived())
        .max(Comparator.comparingLong(e -> e.archivedAt() != null ? e.archivedAt() : 0L));
  }

  /** 检查是否有纪元处于决策阶段 */
  public boolean hasEpochInDecisionPhase() {
    return epochs.values().stream().anyMatch(e -> e.state().isInDecisionPhase());
  }

  /** 检查是否有纪元处于解决阶段 */
  public boolean hasEpochInResolutionPhase() {
    return epochs.values().stream().anyMatch(e -> e.state().isInResolutionPhase());
  }

  /** 注册里程碑 */
  public void registerMilestone(Milestone milestone) {
    milestones.put(milestone.milestoneId(), milestone);
  }

  /** 卸载里程碑 */
  public void unregisterMilestone(String milestoneId) {
    milestones.remove(milestoneId);
  }

  /** 获取里程碑 */
  public Optional<Milestone> getMilestone(String milestoneId) {
    return Optional.ofNullable(milestones.get(milestoneId));
  }

  /** 获取所有里程碑 */
  public Collection<Milestone> getAllMilestones() {
    return milestones.values();
  }

  /** 记录决策 */
  public void recordDecision(String decisionId, String decisionValue) {
    decisions.put(decisionId, decisionValue);
  }

  /** 获取决策 */
  public Optional<String> getDecision(String decisionId) {
    return Optional.ofNullable(decisions.get(decisionId));
  }

  /** 检查里程碑是否已完成 */
  public boolean isMilestoneCompleted(String milestoneId) {
    Milestone milestone = milestones.get(milestoneId);
    return milestone != null && milestone.completed();
  }

  /** 标记里程碑为已完成 */
  public void completeMilestone(String milestoneId) {
    Milestone milestone = milestones.get(milestoneId);
    if (milestone != null && !milestone.completed()) {
      Milestone completed =
          new Milestone(
              milestone.milestoneId(),
              milestone.epochRunId(),
              milestone.name(),
              milestone.description(),
              milestone.condition(),
              true,
              System.currentTimeMillis(),
              milestone.dependencies());
      milestones.put(milestoneId, completed);

      // 发布里程碑完成事件
      if (eventBridge != null) {
        eventBridge.publish(
            EventBridge.EventTypes.EPOCH_MILESTONE,
            Map.of(
                "milestoneId", milestoneId,
                "epochRunId", completed.epochRunId(),
                "milestone", completed));
      }
    }
  }

  /** 检查所有里程碑依赖是否满足 */
  public boolean areMilestoneDependenciesSatisfied(String milestoneId) {
    Milestone milestone = milestones.get(milestoneId);
    if (milestone == null) return false;

    for (String dependencyId : milestone.dependencies()) {
      if (!isMilestoneCompleted(dependencyId)) {
        return false;
      }
    }
    return true;
  }

  /** 根据里程碑状态自动转换纪元状态 */
  public void checkMilestoneBasedTransitions() {
    for (Epoch epoch : epochs.values()) {
      if (epoch.milestoneRef() != null && !epoch.milestoneRef().isEmpty()) {
        String milestoneId = epoch.milestoneRef();
        if (isMilestoneCompleted(milestoneId)) {
          // 里程碑完成，尝试转换到下一个状态
          tryTransition(epoch.epochRunId(), "milestone_completed:" + milestoneId, "advance_epoch");
        }
      }
    }
  }

  /** 根据决策状态自动转换纪元状态 */
  public void checkDecisionBasedTransitions() {
    for (Epoch epoch : epochs.values()) {
      if (epoch.decisionRef() != null && !epoch.decisionRef().isEmpty()) {
        String decisionId = epoch.decisionRef();
        if (decisions.containsKey(decisionId)) {
          // 决策已做出，尝试转换到下一个状态
          tryTransition(epoch.epochRunId(), "decision_made:" + decisionId, "resolve_decision");
        }
      }
    }
  }

  /** 获取等待决策的纪元 */
  public List<Epoch> getEpochsAwaitingDecision() {
    return epochs.values().stream()
        .filter(
            e ->
                e.state().isInDecisionPhase()
                    && (e.decisionRef() == null || !e.decisionRef().isEmpty()))
        .toList();
  }

  /** 获取等待里程碑的纪元 */
  public List<Epoch> getEpochsAwaitingMilestone() {
    return epochs.values().stream()
        .filter(
            e ->
                e.milestoneRef() != null
                    && !e.milestoneRef().isEmpty()
                    && !milestones.get(e.milestoneRef()).completed())
        .toList();
  }

  /** 获取转换对应的事件类型 */
  private EpochEventType getEventTypeForTransition(EpochState from, EpochState to) {
    if (to == EpochState.active) return EpochEventType.EPOCH_ACTIVATE;
    if (to == EpochState.ready) return EpochEventType.EPOCH_READY;
    if (to == EpochState.preparing) return EpochEventType.EPOCH_PREPARE;
    if (to == EpochState.suspended) return EpochEventType.EPOCH_SUSPEND;
    if (to == EpochState.recovery) return EpochEventType.EPOCH_RESUME;
    if (to == EpochState.archived) return EpochEventType.EPOCH_ARCHIVE;
    if (to == EpochState.cancelled) return EpochEventType.EPOCH_CANCEL;
    if (to == EpochState.migration_preparing) return EpochEventType.MIGRATION_START;
    if (to == EpochState.migrating) return EpochEventType.MIGRATION_START;
    if (to == EpochState.verification) return EpochEventType.VERIFICATION_START;
    if (to == EpochState.decision_pending) return EpochEventType.DECISION_TRIGGER;
    if (to == EpochState.resolution_pending) return EpochEventType.DECISION_MADE;
    return EpochEventType.EVENT_OCCURRED;
  }

  /** 清理所有里程碑和决策 */
  public void clear() {
    epochs.clear();
    milestones.clear();
    decisions.clear();
  }
}
