package dev.starcore.starcore.boss;

import java.util.*;

/** 后期遭遇定义 定义战斗后期的特殊Boss遭遇，例如多Boss联合战、环境挑战战等 */
public record LateGameEncounter(
    String encounterId,
    String name,
    String description,
    EncounterType type,
    List<String> bossIds,
    Map<String, Object> encounterData,
    int minParticipants,
    long prepareTimeMs,
    long durationMs,
    Reward reward) {

  public enum EncounterType {
    MULTI_BOSS("多Boss联合战", "多个Boss同时出现的战斗"),
    ENVIRONMENTAL("环境挑战战", "带有环境威胁的战斗"),
    WAVE("波次战", "分波次出现的战斗"),
    BOSS_RUSH("Boss冲刺", "连续挑战多个Boss");

    private final String displayName;
    private final String description;

    EncounterType(String displayName, String description) {
      this.displayName = displayName;
      this.description = description;
    }

    public String getDisplayName() {
      return displayName;
    }

    public String getDescription() {
      return description;
    }
  }

  public static Builder builder(String encounterId, String name, EncounterType type) {
    return new Builder(encounterId, name, type);
  }

  public static class Builder {
    private final String encounterId;
    private final String name;
    private final EncounterType type;
    private String description = "";
    private List<String> bossIds = new ArrayList<>();
    private Map<String, Object> encounterData = new HashMap<>();
    private int minParticipants = 1;
    private long prepareTimeMs = 10000;
    private long durationMs = 300000;
    private Reward reward = null;

    public Builder(String encounterId, String name, EncounterType type) {
      this.encounterId = Objects.requireNonNull(encounterId);
      this.name = Objects.requireNonNull(name);
      this.type = Objects.requireNonNull(type);
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder addBossId(String bossId) {
      this.bossIds.add(bossId);
      return this;
    }

    public Builder bossIds(List<String> bossIds) {
      this.bossIds = new ArrayList<>(bossIds);
      return this;
    }

    public Builder encounterData(String key, Object value) {
      this.encounterData.put(key, value);
      return this;
    }

    public Builder minParticipants(int minParticipants) {
      this.minParticipants = minParticipants;
      return this;
    }

    public Builder prepareTimeMs(long prepareTimeMs) {
      this.prepareTimeMs = prepareTimeMs;
      return this;
    }

    public Builder durationMs(long durationMs) {
      this.durationMs = durationMs;
      return this;
    }

    public Builder reward(Reward reward) {
      this.reward = reward;
      return this;
    }

    public LateGameEncounter build() {
      return new LateGameEncounter(
          encounterId,
          name,
          description,
          type,
          List.copyOf(bossIds),
          Map.copyOf(encounterData),
          minParticipants,
          prepareTimeMs,
          durationMs,
          reward);
    }
  }
}
