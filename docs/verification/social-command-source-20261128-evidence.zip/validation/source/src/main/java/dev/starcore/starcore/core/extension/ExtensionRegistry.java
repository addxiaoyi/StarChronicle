package dev.starcore.starcore.core.extension;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Logger;

/** 扩展注册中心 管理所有扩展点和贡献者 */
public final class ExtensionRegistry {
  private static ExtensionRegistry instance;

  private final Logger logger;
  private final Map<String, ExtensionPoint<?, ?>> extensionPoints = new ConcurrentHashMap<>();
  private final Map<String, List<ExtensionContributor<?, ?>>> contributors =
      new ConcurrentHashMap<>();
  private final Map<String, ExtensionMetadata> metadata = new ConcurrentHashMap<>();

  private ExtensionRegistry(Logger logger) {
    this.logger = logger;
  }

  /** 获取单例实例 */
  public static synchronized ExtensionRegistry getInstance() {
    if (instance == null) {
      throw new IllegalStateException("ExtensionRegistry not initialized. Call init() first.");
    }
    return instance;
  }

  /** 初始化扩展注册中心 */
  public static synchronized void init(Logger logger) {
    if (instance == null) {
      instance = new ExtensionRegistry(logger);
    }
  }

  /** 注册扩展点 */
  public <T, R> void registerExtensionPoint(ExtensionPoint<T, R> extensionPoint) {
    String id = extensionPoint.getName();
    extensionPoints.put(id, extensionPoint);
    contributors.put(id, new CopyOnWriteArrayList<>());
    metadata.put(
        id,
        new ExtensionMetadata(
            id,
            extensionPoint.getName(),
            extensionPoint.getDescription(),
            System.currentTimeMillis()));
    logger.info("Registered extension point: " + id);
  }

  /** 注册贡献者到指定扩展点 */
  public <T, R> void registerContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor) {
    registerContributor(extensionPoint.getName(), contributor);
  }

  /** 注册贡献者到指定扩展点ID */
  @SuppressWarnings("unchecked")
  public <T, R> void registerContributor(
      String extensionPointId, ExtensionContributor<T, R> contributor) {
    List<ExtensionContributor<?, ?>> contributorList =
        contributors.computeIfAbsent(extensionPointId, k -> new CopyOnWriteArrayList<>());

    // 移除相同ID的旧贡献者
    contributorList.removeIf(c -> c.getId().equals(contributor.getId()));

    // 添加新贡献者
    contributorList.add(contributor);

    // 按优先级排序
    contributorList.sort(Comparator.comparingInt(ExtensionContributor::getPriority));

    logger.info(
        "Registered contributor '"
            + contributor.getId()
            + "' to extension point '"
            + extensionPointId
            + "'");
  }

  /** 注销贡献者 */
  public <T, R> void unregisterContributor(
      ExtensionPoint<T, R> extensionPoint, ExtensionContributor<T, R> contributor) {
    List<ExtensionContributor<?, ?>> contributorList = contributors.get(extensionPoint.getName());
    if (contributorList != null) {
      contributorList.remove(contributor);
    }
  }

  /** 注销指定扩展点的贡献者 */
  public void unregisterAllContributors() {
    for (List<ExtensionContributor<?, ?>> list : contributors.values()) {
      list.clear();
    }
  }

  /** 获取扩展点 */
  @SuppressWarnings("unchecked")
  public <T, R> ExtensionPoint<T, R> getExtensionPoint(String name) {
    return (ExtensionPoint<T, R>) extensionPoints.get(name);
  }

  /** 获取所有注册的扩展点 */
  public Collection<ExtensionPoint<?, ?>> getAllExtensionPoints() {
    return List.copyOf(extensionPoints.values());
  }

  /** 获取扩展点的贡献者列表 */
  public synchronized List<ExtensionContributor<?, ?>> getContributors(String extensionPointId) {
    return contributors.getOrDefault(extensionPointId, List.of());
  }

  /** 执行扩展点 */
  @SuppressWarnings("unchecked")
  public <T, R> T execute(String extensionPointId, R request) {
    ExtensionPoint<T, R> point = getExtensionPoint(extensionPointId);
    return point != null ? point.execute(request) : null;
  }

  /** 执行扩展点（只返回第一个结果） */
  @SuppressWarnings("unchecked")
  public <T, R> T executeFirst(String extensionPointId, R request) {
    ExtensionPoint<T, R> point = getExtensionPoint(extensionPointId);
    return point != null ? point.executeFirst(request) : null;
  }

  /** 检查扩展点是否存在 */
  public boolean hasExtensionPoint(String name) {
    return extensionPoints.containsKey(name);
  }

  /** 获取扩展点元数据 */
  public Optional<ExtensionMetadata> getExtensionMetadata(String name) {
    return Optional.ofNullable(metadata.get(name));
  }

  /** 获取所有扩展点的元数据 */
  public Collection<ExtensionMetadata> getAllExtensionMetadata() {
    return List.copyOf(metadata.values());
  }

  /** 清除指定扩展点的注册信息（用于模块卸载） */
  public void unregisterExtensionPoint(String extensionPointId) {
    extensionPoints.remove(extensionPointId);
    contributors.remove(extensionPointId);
    metadata.remove(extensionPointId);
    logger.info("Unregistered extension point: " + extensionPointId);
  }

  /** 清除所有注册信息（用于插件卸载） */
  public void clear() {
    extensionPoints.clear();
    contributors.clear();
    metadata.clear();
    logger.info("All extensions cleared");
  }

  /** 获取注册的贡献者总数 */
  public int getTotalContributorCount() {
    return contributors.values().stream().mapToInt(List::size).sum();
  }
}
