package dev.starcore.starcore.boss;

/** Boss路线枚举 定义Boss的两种性格/行为路线 */
public enum BossRoute {
  /** 索取型：索取回应，重视反应强度，在验证失败时更激进 */
  demanding("索取型", "索取回应，重视反应强度"),

  /** 清醒型：清醒型，重视回应质量，在验证失败时转向内部对话 */
  lucid("清醒型", "重视回应质量，转向内部对话");

  private final String displayName;
  private final String description;

  BossRoute(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }
}
