package dev.starcore.starcore.essentials.home;

import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/** 家园系统服务 支持多家园设置 */
public final class HomeService {
  private static final Logger LOGGER = Logger.getLogger(HomeService.class.getName());
  private final int maxHomes;

  // 玩家家园数据 UUID -> (家园名称 -> 位置)
  private final ConcurrentHashMap<UUID, Map<String, Location>> playerHomes =
      new ConcurrentHashMap<>();

  public HomeService(int maxHomes) {
    this.maxHomes = maxHomes;
  }

  /** 设置家园 */
  public boolean setHome(Player player, String name) {
    Optional<String> invalidReason = invalidHomeNameReason(name);
    if (invalidReason.isPresent()) {
      player.sendMessage("§c家园名称无效: " + invalidReason.get());
      return false;
    }

    UUID playerId = player.getUniqueId();
    Location location = player.getLocation();
    Location storedLocation = location == null ? null : location.clone();
    if (storedLocation == null) {
      return false;
    }

    Map<String, Location> homes =
        playerHomes.computeIfAbsent(playerId, k -> new ConcurrentHashMap<>());

    synchronized (homes) {
      // 检查数量限制
      if (!homes.containsKey(name) && homes.size() >= maxHomes) {
        player.sendMessage("§c你已达到家园数量上限（" + maxHomes + "个）");
        return false;
      }

      // 保存家园
      homes.put(name, storedLocation);
    }

    player.sendMessage("§a已设置家园: " + name);

    return true;
  }

  /** 删除家园 */
  public boolean deleteHome(Player player, String name) {
    UUID playerId = player.getUniqueId();
    Map<String, Location> homes = playerHomes.get(playerId);

    if (homes == null || name == null) {
      player.sendMessage("§c家园不存在: " + name);
      return false;
    }

    synchronized (homes) {
      if (!homes.containsKey(name)) {
        player.sendMessage("§c家园不存在: " + name);
        return false;
      }

      homes.remove(name);
    }

    player.sendMessage("§a已删除家园: " + name);
    return true;
  }

  /** Returns whether a name can safely be used as a persisted home key. */
  public static boolean isValidHomeName(String name) {
    return invalidHomeNameReason(name).isEmpty();
  }

  /** Returns a user-facing validation reason, or empty when the name is valid. */
  public static Optional<String> invalidHomeNameReason(String name) {
    if (name == null || name.isEmpty()) {
      return Optional.of("不能为空");
    }
    int codePointCount = name.codePointCount(0, name.length());
    if (codePointCount > 32) {
      return Optional.of("长度不能超过 32 个字符");
    }
    if (name.codePoints().anyMatch(codePoint -> !isAllowedHomeNameCodePoint(codePoint))) {
      return Optional.of("只能包含字母、数字、下划线或短横线");
    }
    return Optional.empty();
  }

  private static boolean isAllowedHomeNameCodePoint(int codePoint) {
    return Character.isLetterOrDigit(codePoint) || codePoint == '_' || codePoint == '-';
  }

  /** 获取家园位置 */
  public Optional<Location> getHome(UUID playerId, String name) {
    Map<String, Location> homes = playerHomes.get(playerId);

    if (homes == null || name == null) {
      return Optional.empty();
    }

    Location location = homes.get(name);
    return location == null ? Optional.empty() : Optional.of(location.clone());
  }

  /** 获取所有家园 */
  public List<String> getHomeNames(UUID playerId) {
    Map<String, Location> homes = playerHomes.get(playerId);

    if (homes == null || homes.isEmpty()) {
      return List.of();
    }

    return homes.keySet().stream().sorted().toList();
  }

  /** 传送到家园 */
  public boolean teleportToHome(Player player, String name) {
    Optional<Location> homeOpt = getHome(player.getUniqueId(), name);

    if (homeOpt.isEmpty()) {
      player.sendMessage("§c家园不存在: " + name);
      return false;
    }

    Location destination = homeOpt.get();
    if (destination.getWorld() == null) {
      LOGGER.warning("code=ESSENTIALS_HOME_DESTINATION_UNAVAILABLE player=" + player.getUniqueId());
      player.sendMessage("§c传送失败：目标世界不可用");
      return false;
    }

    boolean teleported;
    try {
      teleported = player.teleport(destination);
    } catch (RuntimeException failure) {
      LOGGER.log(
          Level.WARNING,
          "code=ESSENTIALS_HOME_TELEPORT_FAILED player=" + player.getUniqueId(),
          failure);
      player.sendMessage("§c传送失败：服务器无法完成该操作");
      return false;
    }
    if (!teleported) {
      LOGGER.warning("code=ESSENTIALS_HOME_TELEPORT_REJECTED player=" + player.getUniqueId());
      player.sendMessage("§c传送失败：目标位置拒绝传送");
      return false;
    }

    player.sendMessage("§a已传送到家园: " + name);

    return true;
  }

  /** 列出所有家园 */
  public void listHomes(Player player) {
    List<String> homes = getHomeNames(player.getUniqueId());

    if (homes.isEmpty()) {
      player.sendMessage("§c你还没有设置任何家园");
      player.sendMessage("§7使用 /sethome <名称> 来设置家园");
      return;
    }

    player.sendMessage("§a你的家园列表:");
    for (String name : homes) {
      player.sendMessage("§7 - " + name);
    }
    player.sendMessage("§7使用 /home <名称> 来传送");
  }

  /** 加载玩家数据 */
  public void loadPlayerData(UUID playerId, Map<String, Location> homes) {
    Map<String, Location> sanitized = new ConcurrentHashMap<>();
    if (homes != null) {
      homes.forEach(
          (name, location) -> {
            if (name != null && location != null) {
              Location copy = location.clone();
              if (copy != null) {
                sanitized.put(name, copy);
              }
            }
          });
    }
    playerHomes.put(playerId, sanitized);
  }

  /** 保存玩家数据 */
  public Map<String, Location> getPlayerData(UUID playerId) {
    Map<String, Location> homes = playerHomes.get(playerId);
    if (homes == null || homes.isEmpty()) {
      return Map.of();
    }

    Map<String, Location> snapshot = new LinkedHashMap<>();
    synchronized (homes) {
      homes.forEach(
          (name, location) -> {
            Location copy = location.clone();
            if (copy != null) {
              snapshot.put(name, copy);
            }
          });
    }
    return Map.copyOf(snapshot);
  }

  /** Returns every player whose home state is currently loaded, including offline players. */
  public Set<UUID> getKnownPlayerIds() {
    return Set.copyOf(playerHomes.keySet());
  }

  /** 清理玩家数据 */
  public void cleanup(UUID playerId) {
    playerHomes.remove(playerId);
  }
}
