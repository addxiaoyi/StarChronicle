package dev.starcore.starcore.achievement;

import dev.starcore.starcore.achievement.gui.AchievementGui;
import dev.starcore.starcore.achievement.gui.AchievementGuiListener;
import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** 成就模块 管理所有成就相关功能 */
public final class AchievementModule extends AbstractAchievementService
    implements StarCoreModule, Listener {

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "achievement",
          "成就系统",
          ModuleLayer.MODULE,
          List.of(),
          List.of(AchievementService.class),
          "Player achievement and progression tracking system");

  private final Plugin plugin;
  private final Map<UUID, AchievementProgress> playerProgress = new ConcurrentHashMap<>();
  private AchievementStorage storage;
  private AchievementGui gui;
  private AchievementGuiListener guiListener;
  private BukkitTask placeholderRegistrationTask;
  private AchievementPlaceholder placeholderExpansion;
  private volatile boolean enabled;
  private java.util.logging.Logger logger;

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  public AchievementModule(Plugin plugin) {
    super(plugin);
    this.plugin = plugin;
  }

  @Override
  public void enable(StarCoreContext context) {
    this.enabled = true;
    this.logger = context.plugin().getLogger();

    // 初始化存储
    this.storage =
        new AchievementStorage(
            metadata().id(), context.databaseService(), context.persistenceService(), logger);

    // 注册服务
    context.serviceRegistry().register(AchievementService.class, this);
    context.serviceRegistry().register(AchievementModule.class, this);

    // D-081: 注入内部经济服务，使成就的"金币奖励"类型真正落账
    setEconomyService(context.economyService());

    // 注册默认成就
    DefaultAchievements.registerAll(plugin, this);

    // 注册 GUI
    this.gui = new AchievementGui(plugin, this);
    this.guiListener = new AchievementGuiListener(gui);

    // 注册事件监听器
    context.plugin().getServer().getPluginManager().registerEvents(this, context.plugin());
    context.plugin().getServer().getPluginManager().registerEvents(guiListener, context.plugin());

    // 注册 PlaceholderAPI 扩展
    registerPlaceholderAPI(context);

    logger.info("成就模块已启用，共注册 " + achievements.size() + " 个成就");
  }

  @Override
  public void disable(StarCoreContext context) {
    enabled = false;
    if (placeholderRegistrationTask != null) {
      placeholderRegistrationTask.cancel();
      placeholderRegistrationTask = null;
    }
    if (placeholderExpansion != null) {
      placeholderExpansion.unregister();
      placeholderExpansion = null;
    }
    HandlerList.unregisterAll(this);
    if (guiListener != null) {
      HandlerList.unregisterAll(guiListener);
      guiListener = null;
    }
    if (storage != null) {
      // 保存所有玩家进度，记录失败的条目
      List<UUID> failedSaves = new ArrayList<>();
      for (Map.Entry<UUID, AchievementProgress> entry : playerProgress.entrySet()) {
        try {
          storage.saveProgress(entry.getValue());
        } catch (Exception e) {
          failedSaves.add(entry.getKey());
          logger.severe("保存玩家成就进度失败，玩家UUID: " + entry.getKey() + ", 错误: " + e.getMessage());
          logger.log(java.util.logging.Level.SEVERE, "成就进度保存异常", e);
        }
      }

      // 如果有失败的保存，在关闭前再尝试一次
      if (!failedSaves.isEmpty()) {
        logger.warning("正在重试保存 " + failedSaves.size() + " 个失败的玩家成就数据...");
        for (UUID playerId : failedSaves) {
          try {
            AchievementProgress progress = playerProgress.get(playerId);
            if (progress != null) {
              storage.saveProgress(progress);
              logger.info("重试成功，玩家UUID: " + playerId);
            }
          } catch (Exception e) {
            logger.severe("重试失败，玩家UUID: " + playerId + " 的成就数据可能丢失！");
          }
        }
      }

      storage.shutdown();
      storage = null;
    }
    gui = null;
    logger.info("成就模块已禁用");
  }

  /** 注册 PlaceholderAPI 占位符 */
  private void registerPlaceholderAPI(StarCoreContext context) {
    if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
      placeholderRegistrationTask =
          Bukkit.getScheduler()
              .runTask(
                  plugin,
                  () -> {
                    placeholderRegistrationTask = null;
                    if (!enabled) {
                      return;
                    }
                    try {
                      AchievementPlaceholder expansion = new AchievementPlaceholder(plugin, this);
                      if (expansion.register()) {
                        placeholderExpansion = expansion;
                        logger.info("成就系统 PlaceholderAPI 扩展已注册");
                      } else {
                        logger.warning("成就系统 PlaceholderAPI 扩展注册被拒绝");
                      }
                    } catch (Exception e) {
                      logger.warning("注册成就 PlaceholderAPI 扩展失败: " + e.getMessage());
                    }
                  });
    }
  }

  // ==================== AchievementService 实现 ====================

  @Override
  public void registerAchievement(Achievement achievement) {
    if (achievements.put(achievement.getKey(), achievement) != null) {
      logger.warning("Achievement key '" + achievement.getKey() + "' is being overwritten");
    }
  }

  @Override
  public void registerAchievements(Achievement... achievements) {
    for (Achievement achievement : achievements) {
      registerAchievement(achievement);
    }
  }

  @Override
  public Optional<Achievement> getAchievement(NamespacedKey key) {
    return Optional.ofNullable(achievements.get(key));
  }

  @Override
  public Collection<Achievement> getAllAchievements() {
    return List.copyOf(achievements.values());
  }

  @Override
  public Collection<Achievement> getAchievementsByCategory(AchievementCategory category) {
    return achievements.values().stream()
        .filter(a -> getAchievementCategory(a.getKey()) == category)
        .toList();
  }

  @Override
  public boolean hasAchievement(UUID playerId, NamespacedKey key) {
    AchievementProgress progress = getOrCreateProgress(playerId);
    return progress.isCompleted(key);
  }

  @Override
  public boolean grantAchievement(Player player, NamespacedKey key) {
    Achievement achievement = achievements.get(key);
    if (achievement == null) {
      return false;
    }

    AchievementProgress progress = getOrCreateProgress(player.getUniqueId());

    // 检查是否已完成
    if (progress.isCompleted(key)) {
      return false;
    }

    // 检查父成就
    if (!rewardsAreValid(achievement)) {
      return false;
    }

    if (achievement.hasParent() && !progress.isParentCompleted(achievement.getParent())) {
      return false;
    }

    // 标记完成
    if (!progress.markCompletedIfAbsent(key)) {
      return false;
    }
    if (!achievement.getRewards().isEmpty()) {
      progress.markRewardPending(key);
    }
    if (storage != null) {
      storage.recordAchievementCompletion(player.getUniqueId(), key);
    }

    displayAchievement(player, achievement);
    boolean rewardsDelivered = giveRewards(player, achievement);
    if (!rewardsDelivered) {
      player.sendMessage("§e成就已解锁，但奖励发放失败，将在下次登录时重试。");
      if (storage != null) {
        storage.saveProgress(progress);
      }
      return true;
    }
    progress.clearRewardPending(key);
    if (storage != null) {
      storage.saveProgress(progress);
    }
    return true;
  }

  @Override
  public Set<NamespacedKey> getPlayerAchievements(UUID playerId) {
    return getOrCreateProgress(playerId).getCompletedAchievements();
  }

  @Override
  public int getPlayerProgress(UUID playerId) {
    return getOrCreateProgress(playerId).getCompletedAchievements().size();
  }

  @Override
  public int getTotalAchievements() {
    return achievements.size();
  }

  @Override
  public void loadPlayerData(UUID playerId, Set<NamespacedKey> achievements) {
    AchievementProgress progress =
        storage != null ? storage.loadProgress(playerId) : new AchievementProgress(playerId);
    if (achievements != null) {
      achievements.forEach(progress::markCompleted);
    }
    playerProgress.put(playerId, progress);
  }

  @Override
  public Set<NamespacedKey> savePlayerData(UUID playerId) {
    AchievementProgress progress = playerProgress.get(playerId);
    if (progress != null && storage != null) {
      storage.saveProgress(progress);
    }
    return progress != null ? progress.getCompletedAchievements() : Set.of();
  }

  @Override
  public AchievementProgress getOrCreateProgress(UUID playerId) {
    return playerProgress.computeIfAbsent(
        playerId, k -> storage != null ? storage.loadProgress(k) : new AchievementProgress(k));
  }

  @Override
  public void incrementTrigger(UUID playerId, AchievementTrigger.TriggerType type, int amount) {
    if (playerId == null || type == null || amount <= 0) {
      return;
    }
    AchievementProgress progress = getOrCreateProgress(playerId);
    String triggerKey = type.name();
    int newCount = progress.incrementTriggerCount(triggerKey, amount);

    // 检查并触发相关成就
    checkTriggerAchievements(playerId, type, newCount);

    // The progress object is already incremented above; persist that same snapshot once.
    if (storage != null) {
      storage.saveProgress(progress);
    }
  }

  /** 检查基于触发器的成就 */
  private void checkTriggerAchievements(
      UUID playerId, AchievementTrigger.TriggerType type, int currentCount) {
    Player player = Bukkit.getPlayer(playerId);
    if (player == null) {
      return;
    }

    for (Achievement achievement : achievements.values()) {
      AchievementTrigger trigger = achievement.getTrigger();
      if (trigger == null || trigger.getType() != type) {
        continue;
      }

      // 检查是否满足条件
      Map<String, Object> conditions = trigger.getConditions();
      int required = (int) conditions.getOrDefault("kill_count", 1);

      if (currentCount >= required && !hasAchievement(playerId, achievement.getKey())) {
        grantAchievement(player, achievement.getKey());
      }
    }
  }

  /** 打开成就 GUI */
  public void openGui(Player player) {
    if (gui != null) {
      gui.openMainMenu(player);
    }
  }

  /** 打开分类成就 GUI */
  public void openCategoryGui(Player player, AchievementCategory category) {
    if (gui != null) {
      gui.openCategoryMenu(player, category);
    }
  }

  /** 获取成就分类 */
  public AchievementCategory getAchievementCategory(NamespacedKey key) {
    String keyStr = key.getKey().toLowerCase();
    if (keyStr.contains("combat")
        || keyStr.contains("kill")
        || keyStr.contains("pvp")
        || keyStr.contains("duel")) {
      return AchievementCategory.COMBAT;
    }
    if (keyStr.contains("gather")
        || keyStr.contains("mine")
        || keyStr.contains("wood")
        || keyStr.contains("stone")) {
      return AchievementCategory.GATHERING;
    }
    if (keyStr.contains("farm") || keyStr.contains("breed") || keyStr.contains("plant")) {
      return AchievementCategory.FARMING;
    }
    if (keyStr.contains("social") || keyStr.contains("friend") || keyStr.contains("guild")) {
      return AchievementCategory.SOCIAL;
    }
    if (keyStr.contains("nation") || keyStr.contains("city")) {
      return AchievementCategory.NATION;
    }
    if (keyStr.contains("tech") || keyStr.contains("craft") || keyStr.contains("recipe")) {
      return AchievementCategory.TECH;
    }
    if (keyStr.contains("nether") || keyStr.contains("end") || keyStr.contains("explore")) {
      return AchievementCategory.EXPLORATION;
    }
    if (keyStr.contains("money") || keyStr.contains("trade") || keyStr.contains("economy")) {
      return AchievementCategory.ECONOMY;
    }
    return AchievementCategory.ADVENTURE;
  }

  // ==================== 事件监听 ====================

  private void retryPendingRewards(Player player, AchievementProgress progress) {
    for (NamespacedKey key : progress.getPendingRewards()) {
      Achievement achievement = achievements.get(key);
      if (achievement == null || !rewardsAreValid(achievement)) {
        continue;
      }
      if (giveRewards(player, achievement)) {
        progress.clearRewardPending(key);
        if (storage != null) {
          storage.saveProgress(progress);
        }
      }
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onPlayerJoin(PlayerJoinEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    // 加载玩家进度
    AchievementProgress progress = getOrCreateProgress(playerId);
    retryPendingRewards(event.getPlayer(), progress);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onBlockBreak(BlockBreakEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    String blockKey = event.getBlock().getType().name();

    // 触发挖掘相关成就
    incrementTrigger(playerId, AchievementTrigger.TriggerType.BREAK_BLOCK, 1);

    // 检查物品相关成就
    if (isOre(event.getBlock().getType())) {
      incrementTrigger(playerId, AchievementTrigger.TriggerType.INVENTORY_CHANGED, 1);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onBlockPlace(BlockPlaceEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    incrementTrigger(playerId, AchievementTrigger.TriggerType.PLACED_BLOCK, 1);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onPlayerKill(PlayerDeathEvent event) {
    if (event.getEntity().getKiller() != null) {
      Player killer = event.getEntity().getKiller();
      UUID playerId = killer.getUniqueId();

      // 检查是否是玩家击杀
      if (event.getEntity() instanceof org.bukkit.entity.Player) {
        incrementTrigger(playerId, AchievementTrigger.TriggerType.CUSTOM_KILL_STREAK, 1);
      }

      // 怪物击杀
      incrementTrigger(playerId, AchievementTrigger.TriggerType.PLAYER_KILLED_ENTITY, 1);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onEntityDeath(EntityDeathEvent event) {
    if (event.getEntity().getKiller() != null) {
      UUID playerId = event.getEntity().getKiller().getUniqueId();
      incrementTrigger(playerId, AchievementTrigger.TriggerType.PLAYER_KILLED_ENTITY, 1);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onCraft(CraftItemEvent event) {
    if (event.getWhoClicked() instanceof Player player) {
      UUID playerId = player.getUniqueId();
      ItemStack result = event.getInventory().getResult();
      if (result != null) {
        incrementTrigger(playerId, AchievementTrigger.TriggerType.RECIPE_CRAFTED, 1);
      }
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onItemConsume(PlayerItemConsumeEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    incrementTrigger(playerId, AchievementTrigger.TriggerType.CONSUME_ITEM, 1);
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onPlayerInteract(PlayerInteractEvent event) {
    if (event.getAction().isRightClick() && event.hasBlock()) {
      UUID playerId = event.getPlayer().getUniqueId();
      incrementTrigger(playerId, AchievementTrigger.TriggerType.ITEM_USED_ON_BLOCK, 1);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onPlayerHit(EntityDamageByEntityEvent event) {
    if (event.getDamager() instanceof Player player) {
      UUID playerId = player.getUniqueId();
      incrementTrigger(playerId, AchievementTrigger.TriggerType.PLAYER_HURT_ENTITY, 1);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
  public void onWorldChange(PlayerChangedWorldEvent event) {
    Player player = event.getPlayer();
    UUID playerId = player.getUniqueId();
    String worldName = player.getWorld().getName();

    incrementTrigger(playerId, AchievementTrigger.TriggerType.CHANGED_DIMENSION, 1);

    if (worldName.contains("nether")) {
      incrementTrigger(playerId, AchievementTrigger.TriggerType.NETHER_TRAVEL, 1);
    }
  }

  private boolean isOre(org.bukkit.Material material) {
    return material == org.bukkit.Material.COAL_ORE
        || material == org.bukkit.Material.IRON_ORE
        || material == org.bukkit.Material.COPPER_ORE
        || material == org.bukkit.Material.GOLD_ORE
        || material == org.bukkit.Material.DIAMOND_ORE
        || material == org.bukkit.Material.EMERALD_ORE
        || material == org.bukkit.Material.NETHER_GOLD_ORE
        || material == org.bukkit.Material.NETHER_QUARTZ_ORE
        || material == org.bukkit.Material.DEEPSLATE_COAL_ORE
        || material == org.bukkit.Material.DEEPSLATE_IRON_ORE
        || material == org.bukkit.Material.DEEPSLATE_COPPER_ORE
        || material == org.bukkit.Material.DEEPSLATE_GOLD_ORE
        || material == org.bukkit.Material.DEEPSLATE_DIAMOND_ORE
        || material == org.bukkit.Material.DEEPSLATE_EMERALD_ORE;
  }

  // PlaceholderAPI 支持
  public static class AchievementPlaceholder
      extends me.clip.placeholderapi.expansion.PlaceholderExpansion {
    private final Plugin plugin;
    private final AchievementModule module;

    public AchievementPlaceholder(Plugin plugin, AchievementModule module) {
      this.plugin = plugin;
      this.module = module;
    }

    @Override
    public String getIdentifier() {
      return "starcore_achievement";
    }

    @Override
    public String getAuthor() {
      return String.join(", ", plugin.getPluginMeta().getAuthors());
    }

    @Override
    public String getVersion() {
      return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
      return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
      if (player == null) {
        return "";
      }

      return switch (params) {
        case "completed" -> String.valueOf(module.getPlayerProgress(player.getUniqueId()));
        case "total" -> String.valueOf(module.getTotalAchievements());
        case "percentage" -> {
          int completed = module.getPlayerProgress(player.getUniqueId());
          int total = module.getTotalAchievements();
          yield total > 0 ? String.format("%.1f", (completed * 100.0) / total) : "0";
        }
        default -> null;
      };
    }
  }

  /** 获取成就总数 */
  public int totalAchievementCount() {
    return achievements.size();
  }

  /** 获取已解锁成就的玩家总数 */
  public int getPlayerWithAchievementCount() {
    return playerAchievements.size();
  }
}
