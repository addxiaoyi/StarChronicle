package dev.starcore.starcore.choice;

/** 公共选择状态枚举 定义公共选择的生命周期状态 */
public enum ChoiceStatus {
  /** 草案：选择正在草拟中 */
  drafting("草案", "选择正在草拟中"),

  /** 举证开放：开放证据期间 */
  evidence_open("举证开放", "开放证据"),

  /** 方案冻结：方案版本冻结，不可更改 */
  proposal_frozen("方案冻结", "方案版本冻结"),

  /** 参与开放：允许参与投票期间 */
  participation_open("参与开放", "允许投票"),

  /** 参与关闭：投票结束 */
  participation_closed("参与关闭", "投票结束"),

  /** 验证中：正在验证投票结果 */
  validation("验证中", "验证结果"),

  /** 已选定：选择已被正式采纳 */
  selected("已选定", "选择完成"),

  /** 正在实施：正在执行所选方案 */
  implementation("正在实施", "执行方案"),

  /** 复核中：正在复核实施结果 */
  review("复核中", "复核结果"),

  /** 已完成：实施完全完成，结果正式记录 */
  finalized("已完成", "结果正式记录"),

  /** 临时缺省：未完成时使用的临时方案 */
  provisional("临时缺省", "临时方案"),

  /** 有争议：出现争议但尚未解决 */
  contested("有争议", "争议待解决");

  private final String displayName;
  private final String description;

  ChoiceStatus(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 检查是否为终止状态 */
  public boolean isTerminal() {
    return this == selected || this == finalized;
  }

  /** 检查是否为投票阶段 */
  public boolean isInVotingPhase() {
    return this == participation_open || this == participation_closed;
  }

  /** 检查是否为争议状态 */
  public boolean isContested() {
    return this == contested || this == provisional;
  }
}
