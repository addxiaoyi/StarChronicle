package dev.starcore.starcore.foundation.gui;

import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** 现代化 GUI 视觉组件库 提供统一的视觉语言和可复用的 UI 组件 */
public final class VisualComponent {

  private VisualComponent() {}

  // ==================== 色彩系统 ====================
  public static final TextColor COLOR_GOLD = NamedTextColor.GOLD;
  public static final TextColor COLOR_SUCCESS = NamedTextColor.GREEN;
  public static final TextColor COLOR_WARNING = NamedTextColor.YELLOW;
  public static final TextColor COLOR_DANGER = NamedTextColor.RED;
  public static final TextColor COLOR_INFO = NamedTextColor.AQUA;
  public static final TextColor COLOR_FEATURED = NamedTextColor.LIGHT_PURPLE;
  public static final TextColor COLOR_NEUTRAL = NamedTextColor.DARK_GRAY;
  public static final TextColor COLOR_PRIMARY = TextColor.color(0xFFD700);

  // ==================== 字体样式 ====================
  public static Component title(String text) {
    return Component.text(text, COLOR_GOLD).decorate(TextDecoration.BOLD);
  }

  public static Component subtitle(String text) {
    return Component.text(text, NamedTextColor.AQUA).decorate(TextDecoration.BOLD);
  }

  public static Component body(String text) {
    return Component.text(text, NamedTextColor.WHITE);
  }

  public static Component caption(String text) {
    return Component.text(text, COLOR_NEUTRAL);
  }

  public static Component accent(String text) {
    return Component.text(text, COLOR_PRIMARY).decorate(TextDecoration.BOLD);
  }

  public static Component success(String text) {
    return Component.text(text, COLOR_SUCCESS);
  }

  public static Component warning(String text) {
    return Component.text(text, COLOR_WARNING);
  }

  public static Component danger(String text) {
    return Component.text(text, COLOR_DANGER);
  }

  // ==================== 物品构建器 ====================
  public static ItemStack button(Material material, Component name, List<Component> lore) {
    ItemStack item = new ItemStack(material);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(cleanButtonName(name));
      meta.lore(
          lore == null
              ? List.of()
              : lore.stream()
                  .map(line -> line.decoration(TextDecoration.ITALIC, false))
                  .toList());
      item.setItemMeta(meta);
    }
    return normalize(item);
  }

  /** Applies the shared low-noise item flags used by every menu surface. */
  public static ItemStack normalize(ItemStack item) {
    if (item == null || item.getType() == Material.AIR) return item;
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      if (meta.displayName() != null) {
        meta.displayName(cleanButtonName(meta.displayName()));
      }
      if (meta.lore() != null) {
        meta.lore(meta.lore().stream()
            .map(line -> line.decoration(TextDecoration.ITALIC, false))
            .toList());
      }
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_DESTROYS, ItemFlag.HIDE_PLACED_ON);
      item.setItemMeta(meta);
    }
    return item;
  }

  static Component cleanButtonName(Component name) {
    Component safeName = name == null ? Component.empty() : name;
    String text = PlainTextComponentSerializer.plainText().serialize(safeName);
    String compact =
        text.replaceAll("(?i)§[0-9A-FK-OR]", "")
            .replaceFirst("^\\[[^\\]]{1,10}\\]\\s*", "")
            .replaceFirst("^[\\p{So}\\p{Sm}\\p{Sk}\\s]+", "")
            .trim();
    if (!compact.equals(text)) {
      Component cleaned = Component.text(compact).decoration(TextDecoration.ITALIC, false);
      if (safeName.color() != null) cleaned = cleaned.color(safeName.color());
      if (safeName.decoration(TextDecoration.BOLD) == TextDecoration.State.TRUE) {
        cleaned = cleaned.decorate(TextDecoration.BOLD);
      }
      return cleaned;
    }
    return safeName.decoration(TextDecoration.ITALIC, false);
  }

  public static ItemStack button(Material material, String name, String... lore) {
    List<Component> loreComp =
        Arrays.stream(lore).map(VisualComponent::body).collect(Collectors.toList());
    return button(material, Component.text(name, NamedTextColor.WHITE), loreComp);
  }

  public static ItemStack header(Material material, String title) {
    return button(
        material, Component.text(title, COLOR_GOLD).decorate(TextDecoration.BOLD), List.of());
  }

  public static ItemStack divider() {
    return new ItemStack(Material.AIR);
  }

  public static ItemStack spacer() {
    return new ItemStack(Material.AIR);
  }

  public static ItemStack background(Material material) {
    ItemStack item = new ItemStack(material);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.empty());
      meta.lore(List.of());
      item.setItemMeta(meta);
    }
    return item;
  }

  // ==================== 统计卡片 ====================
  public static ItemStack statCard(Material icon, String label, String value, String hint) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    lore.add(Component.text("§7" + label, COLOR_NEUTRAL));
    lore.add(Component.text("§f" + value, COLOR_PRIMARY).decorate(TextDecoration.BOLD));
    if (hint != null && !hint.isEmpty()) {
      lore.add(Component.empty());
      lore.add(Component.text("§7" + hint, COLOR_NEUTRAL));
    }
    return button(
        icon, Component.text("§6◆ " + label, COLOR_GOLD).decorate(TextDecoration.BOLD), lore);
  }

  public static ItemStack statCard(Material icon, String title, Map<String, String> stats) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    for (Map.Entry<String, String> e : stats.entrySet()) {
      lore.add(Component.text("§7" + e.getKey() + ": §f" + e.getValue(), NamedTextColor.WHITE));
    }
    return button(
        icon, Component.text("§6◆ " + title, COLOR_GOLD).decorate(TextDecoration.BOLD), lore);
  }

  // ==================== 状态组件 ====================
  public static ItemStack activeButton(Material material, String name, List<String> description) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    for (String desc : description) lore.add(Component.text("§f" + desc, NamedTextColor.WHITE));
    lore.add(Component.empty());
    lore.add(Component.text("§a▶ 点击交互", COLOR_SUCCESS));
    return button(
        material,
        Component.text("§f" + name, NamedTextColor.WHITE).decorate(TextDecoration.BOLD),
        lore);
  }

  public static ItemStack disabledButton(Material material, String name, String reason) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    lore.add(Component.text("§c✗ " + reason, COLOR_DANGER));
    lore.add(Component.empty());
    lore.add(Component.text("§7此功能当前不可用", COLOR_NEUTRAL));
    ItemStack item = button(material, Component.text("§c✗ " + name, COLOR_DANGER), lore);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      item.setItemMeta(meta);
    }
    return item;
  }

  public static ItemStack hoverButton(Material material, String name, List<String> hoverText) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    for (String text : hoverText) lore.add(Component.text("§7" + text, COLOR_NEUTRAL));
    lore.add(Component.empty());
    lore.add(Component.text("§e▶ 点击进入", COLOR_WARNING));
    return button(material, Component.text("§f" + name, NamedTextColor.WHITE), lore);
  }

  public static ItemStack selectedButton(Material material, String name, List<String> description) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    for (String desc : description) lore.add(Component.text("§f" + desc, NamedTextColor.WHITE));
    lore.add(Component.empty());
    lore.add(Component.text("§6◆ 当前选中", COLOR_GOLD));
    return button(
        material, Component.text("§6◆ " + name, COLOR_GOLD).decorate(TextDecoration.BOLD), lore);
  }

  // ==================== 进度条 ====================
  private static final ThreadLocal<DecimalFormat> PCT_FMT_TL =
      ThreadLocal.withInitial(() -> new DecimalFormat("0.0"));

  public static ItemStack progressBar(double current, double max, int length) {
    int safeLength = Math.max(0, length);
    double ratio = max > 0 && Double.isFinite(current) ? current / max : 0;
    int filled = (int) Math.round(Math.max(0, Math.min(1, ratio)) * safeLength);
    int empty = safeLength - filled;
    StringBuilder bar = new StringBuilder(length + 4);
    bar.append("§a");
    for (int i = 0; i < filled; i++) bar.append('▓');
    bar.append("§7");
    for (int i = 0; i < empty; i++) bar.append('▒');
    double percent = max > 0 && Double.isFinite(current)
        ? Math.max(0, Math.min(100, current / max * 100))
        : 0;
    List<Component> lore =
        List.of(
            Component.empty(),
            Component.text("进度", COLOR_NEUTRAL),
            Component.text(bar.toString(), NamedTextColor.WHITE),
            Component.text(PCT_FMT_TL.get().format(percent) + "%", COLOR_PRIMARY),
            Component.empty());
    return button(Material.EXPERIENCE_BOTTLE, Component.text("§8进度面板", COLOR_NEUTRAL), lore);
  }

  public static ItemStack ringProgress(double percent, String label) {
    int segments = 10;
    double safePercent = Double.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : 0;
    int filled = (int) Math.round((safePercent / 100.0) * segments);
    StringBuilder ring = new StringBuilder();
    for (int i = 0; i < segments; i++) ring.append(i < filled ? "§a█" : "§8░");
    List<Component> lore =
        List.of(
            Component.empty(),
            Component.text(label, COLOR_NEUTRAL),
            Component.text(ring + " §f" + Math.round(percent) + "%", COLOR_PRIMARY),
            Component.empty());
    return button(Material.CLOCK, Component.text("§8状态指示", COLOR_NEUTRAL), lore);
  }

  // ==================== 空状态 ====================
  public static ItemStack emptyState(Material icon, String title, String hint) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    lore.add(Component.text("§7" + title, COLOR_NEUTRAL));
    if (hint != null && !hint.isEmpty()) {
      lore.add(Component.empty());
      lore.add(Component.text("§8" + hint, COLOR_NEUTRAL));
    }
    lore.add(Component.empty());
    lore.add(Component.text("§e▶ 暂无数据", COLOR_WARNING));
    return button(icon, Component.text("§8" + title, COLOR_NEUTRAL), lore);
  }

  // ==================== 稀有度 ====================
  public enum Rarity {
    COMMON(NamedTextColor.GRAY, "普通", Material.WHITE_DYE),
    UNCOMMON(NamedTextColor.GREEN, "优秀", Material.GREEN_DYE),
    RARE(NamedTextColor.BLUE, "稀有", Material.BLUE_DYE),
    EPIC(NamedTextColor.LIGHT_PURPLE, "史诗", Material.PURPLE_DYE),
    LEGENDARY(NamedTextColor.GOLD, "传奇", Material.YELLOW_DYE),
    MYTHIC(NamedTextColor.RED, "神话", Material.RED_DYE);

    private final NamedTextColor color;
    private final String label;
    private final Material material;

    Rarity(NamedTextColor color, String label, Material material) {
      this.color = color;
      this.label = label;
      this.material = material;
    }

    public NamedTextColor getColor() {
      return color;
    }

    public String getLabel() {
      return label;
    }

    public ItemStack createItem(String name, List<String> lore) {
      List<Component> loreComp = new ArrayList<>();
      loreComp.add(Component.empty());
      loreComp.add(Component.text("§7稀有度: §f" + label, color));
      loreComp.add(Component.empty());
      for (String l : lore) loreComp.add(Component.text("§f" + l, NamedTextColor.WHITE));
      loreComp.add(Component.empty());
      loreComp.add(Component.text("§6◆ 点击交互", COLOR_GOLD));
      return VisualComponent.button(
          material, Component.text(name, color).decorate(TextDecoration.BOLD), loreComp);
    }
  }

  // ==================== 标签页 ====================
  public static ItemStack tab(Material icon, String label, boolean active) {
    if (active) {
      return button(
          icon,
          Component.text("§6" + label, COLOR_GOLD).decorate(TextDecoration.BOLD),
          List.of(Component.empty(), Component.text("§6◆ 当前页面", COLOR_GOLD), Component.empty()));
    }
    return button(
        icon,
        Component.text("§f" + label, NamedTextColor.WHITE),
        List.of(Component.empty(), Component.text("§7点击切换到此页面", COLOR_NEUTRAL), Component.empty()));
  }

  // ==================== 装饰 ====================
  public static ItemStack titleBanner(String title, String subtitle) {
    List<Component> lore = new ArrayList<>();
    if (subtitle != null && !subtitle.isBlank()) {
      lore.add(Component.text("§7" + subtitle, COLOR_NEUTRAL));
    }
    return button(
        Material.NETHER_STAR,
        Component.text("§6§l" + title, COLOR_GOLD).decoration(TextDecoration.ITALIC, false),
        lore);
  }

  public static ItemStack tutorialHint(String title, String... tips) {
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    lore.add(Component.text("§e📖 " + title, COLOR_WARNING).decorate(TextDecoration.BOLD));
    lore.add(Component.empty());
    for (String tip : tips) lore.add(Component.text("§7  • " + tip, COLOR_NEUTRAL));
    lore.add(Component.empty());
    return button(Material.BOOK, Component.text("§e📖 新手指南", COLOR_WARNING), lore);
  }

  // ==================== 工具 ====================
  public static void addLore(ItemStack item, Component... additions) {
    if (item == null || additions == null) return;
    ItemMeta meta = item.getItemMeta();
    if (meta == null) return;
    List<Component> existing = meta.lore();
    List<Component> newLore = new ArrayList<>();
    if (existing != null) newLore.addAll(existing);
    newLore.addAll(Arrays.asList(additions));
    meta.lore(newLore);
    item.setItemMeta(meta);
  }

  public static void addLoreText(ItemStack item, String... additions) {
    Component[] comps = Arrays.stream(additions).map(Component::text).toArray(Component[]::new);
    addLore(item, comps);
  }

  public static ItemStack hideAttributes(ItemStack item) {
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.addItemFlags(
          ItemFlag.HIDE_ATTRIBUTES,
          ItemFlag.HIDE_ENCHANTS,
          ItemFlag.HIDE_DESTROYS,
          ItemFlag.HIDE_PLACED_ON,
          ItemFlag.HIDE_UNBREAKABLE);
      item.setItemMeta(meta);
    }
    return item;
  }

  public static ItemStack glowing(Material material, String name) {
    ItemStack item = new ItemStack(material);
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      meta.displayName(Component.text(name, COLOR_GOLD).decorate(TextDecoration.BOLD));
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      item.setItemMeta(meta);
    }
    return item;
  }

  public static Component clickHint() {
    return Component.text("§e▶ 点击交互", COLOR_WARNING);
  }

  public static Component backHint() {
    return Component.text("§7⟵ 返回上一级", COLOR_NEUTRAL);
  }

  public static Component pageHint(int current, int total) {
    return Component.text(String.format("§7第 %d/%d 页", current, total), COLOR_NEUTRAL);
  }
}
