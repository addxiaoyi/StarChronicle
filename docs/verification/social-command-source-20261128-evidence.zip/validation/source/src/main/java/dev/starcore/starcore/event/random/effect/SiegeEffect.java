package dev.starcore.starcore.event.random.effect;

import dev.starcore.starcore.event.random.EventEffect;
import dev.starcore.starcore.event.random.RandomEventRuntime;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

/** A temporary siege, executed globally and bound to its exact plugin lifecycle and attempt. */
public class SiegeEffect implements EventEffect {
  public enum Action {
    START,
    CANCEL,
    DAMAGE,
    ESCALATE
  }

  private final JavaPlugin plugin;
  private final EffectTaskScope scope;
  private volatile NationService nationService;
  private volatile TreasuryService treasuryService;
  private final Action action;
  private final double damagePerMinute;
  private final double moraleDrain;
  private final int duration;
  private static final Map<UUID, SiegeState> activeSieges = new ConcurrentHashMap<>();

  public SiegeEffect(
      JavaPlugin plugin,
      NationService nationService,
      Action action,
      double damagePerMinute,
      double moraleDrain,
      int duration) {
    this.plugin = plugin;
    this.scope = EffectTaskScope.of(plugin);
    this.nationService = nationService;
    this.action = action;
    this.damagePerMinute = damagePerMinute;
    this.moraleDrain = moraleDrain;
    this.duration = duration;
  }

  public void setNationService(NationService service) {
    nationService = service;
  }

  public void setTreasuryService(TreasuryService service) {
    treasuryService = service;
  }

  @Override
  public boolean apply(Player player, Location location) {
    if (player == null
        || !scope.active()
        || !Bukkit.isGlobalTickThread()
        || !Bukkit.isOwnedByCurrentRegion(player)
        || nationService == null) return false;
    return nationService
        .nationOf(player.getUniqueId())
        .map(nation -> applyToNation(nation.id().value()))
        .orElse(false);
  }

  @Override
  public CompletableFuture<Boolean> applyAsync(
      Player player, Location location, RandomEventRuntime runtime) {
    if (player == null || nationService == null) return CompletableFuture.completedFuture(false);
    return runtime
        .player(player, player::getUniqueId)
        .thenCompose(
            id ->
                runtime.global(
                    () -> {
                      if (!scope.active()) return false;
                      return nationService
                          .nationOf(id)
                          .map(nation -> applyToNation(nation.id().value()))
                          .orElse(false);
                    }));
  }

  public boolean applyToNation(UUID nationId) {
    if (nationId == null
        || nationService == null
        || action == null
        || !scope.active()
        || !Bukkit.isGlobalTickThread()) return false;
    Optional<Nation> nation = nationService.nationById(NationId.of(nationId));
    if (nation.isEmpty()) return false;
    return switch (action) {
      case START -> startSiege(nation.get());
      case CANCEL -> finish(current(nationId), true);
      case DAMAGE -> damageSafely(nation.get(), current(nationId));
      case ESCALATE -> escalate(nation.get(), current(nationId));
    };
  }

  private SiegeState current(UUID id) {
    SiegeState state = activeSieges.get(id);
    return state != null && state.owner == scope ? state : null;
  }

  private boolean startSiege(Nation nation) {
    if (duration <= 0
        || !Double.isFinite(damagePerMinute)
        || damagePerMinute < 0
        || damagePerMinute > 100
        || !Double.isFinite(moraleDrain)
        || moraleDrain < 0
        || moraleDrain > 100
        || (damagePerMinute > 0 && treasuryService == null)) return false;
    SiegeState state =
        new SiegeState(
            nation.id().value(),
            damagePerMinute,
            moraleDrain,
            System.currentTimeMillis() + duration * 1000L);
    state.owner = scope;
    state.remainingTicks = duration * 20L;
    SiegeState previous = activeSieges.put(state.nationId, state);
    if (previous != null && previous.timer != null) previous.timer.cancel();
    try {
      state.timer =
          scope.repeat(
              timer -> {
                if (activeSieges.get(state.nationId) != state) {
                  timer.cancel();
                  return;
                }
                state.remainingTicks -= 20L;
                if (state.remainingTicks <= 0 || System.currentTimeMillis() >= state.expireTime) {
                  finish(state, true);
                  timer.cancel();
                  return;
                }
                state.elapsedTicks += 20L;
                if (state.elapsedTicks % 1200L != 0) return;
                try {
                  Optional<Nation> current = nationService.nationById(NationId.of(state.nationId));
                  if (current.isEmpty() || !damage(current.get(), state)) finish(state, false);
                } catch (RuntimeException failure) {
                  // The provider may have committed. Never retry this attempt blindly.
                  finish(state, false);
                  plugin
                      .getLogger()
                      .log(java.util.logging.Level.WARNING, "围城扣款结果不明，已停止该轮围城；请核对国库记录", failure);
                }
              },
              20L,
              20L);
      if (!scope.active() || state.timer.isCancelled()) {
        finish(state, false);
        return false;
      }
    } catch (RuntimeException failure) {
      finish(state, false);
      throw failure;
    }
    scope.broadcast(
        nation,
        "§c⚔ 【围城开始】"
            + nation.name()
            + "：每分钟国库 -"
            + damagePerMinute
            + "%、士气 -"
            + moraleDrain
            + "，持续 "
            + duration
            + " 秒");
    return true;
  }

  private boolean finish(SiegeState state, boolean announce) {
    if (state == null || state.owner != scope || !activeSieges.remove(state.nationId, state))
      return false;
    if (state.timer != null) state.timer.cancel();
    if (announce && scope.active())
      nationService
          .nationById(NationId.of(state.nationId))
          .ifPresent(nation -> scope.broadcast(nation, "§a⚔ 【围城解除】蛮族撤退了！危机解除！"));
    return true;
  }

  private boolean damage(Nation nation, SiegeState state) {
    if (state == null || activeSieges.get(state.nationId) != state || !scope.active()) return false;
    if (System.currentTimeMillis() >= state.expireTime) {
      finish(state, true);
      return false;
    }
    if (state.damageRate > 0) {
      TreasuryService treasury = treasuryService;
      if (treasury == null) return false;
      BigDecimal balance = treasury.balance(nation.id());
      if (balance == null || balance.signum() < 0) return false;
      BigDecimal loss = balance.multiply(BigDecimal.valueOf(state.damageRate)).movePointLeft(2);
      if (loss.signum() > 0 && !treasury.withdraw(nation.id(), loss)) return false;
    }
    state.morale = Math.max(0, state.morale - state.moraleDrain);
    return true;
  }

  private boolean damageSafely(Nation nation, SiegeState state) {
    try {
      boolean success = damage(nation, state);
      if (!success) finish(state, false);
      return success;
    } catch (RuntimeException failure) {
      finish(state, false);
      throw failure;
    }
  }

  private boolean escalate(Nation nation, SiegeState state) {
    if (state == null || System.currentTimeMillis() >= state.expireTime) return false;
    state.damageRate = Math.min(100, state.damageRate * 1.5);
    state.moraleDrain = Math.min(100, state.moraleDrain * 1.3);
    scope.broadcast(nation, "§c⚔ 【紧急】围城升级！" + nation.name() + " 遭受更强攻势！");
    return true;
  }

  public static void shutdown(Plugin plugin) {
    EffectTaskScope.shutdown(plugin);
    activeSieges
        .entrySet()
        .removeIf(
            entry -> {
              SiegeState state = entry.getValue();
              if (state.owner.plugin != plugin) return false;
              if (state.timer != null) state.timer.cancel();
              return true;
            });
  }

  public static void shutdownAll() {
    EffectTaskScope.shutdownAll();
    activeSieges
        .values()
        .forEach(
            state -> {
              if (state.timer != null) state.timer.cancel();
            });
    activeSieges.clear();
    NationEffect.shutdownAll();
  }

  /** Detached snapshots: callers cannot change a running attempt through public legacy fields. */
  public static Map<UUID, SiegeState> getActiveSieges() {
    Map<UUID, SiegeState> result = new HashMap<>();
    activeSieges.forEach(
        (id, state) -> {
          if (visible(state)) result.put(id, state.copy());
        });
    return Map.copyOf(result);
  }

  private static boolean visible(SiegeState state) {
    return state != null && state.owner.active() && System.currentTimeMillis() < state.expireTime;
  }

  public static boolean isUnderSiege(UUID id) {
    return id != null && visible(activeSieges.get(id));
  }

  public static double getSiegeMorale(UUID id) {
    SiegeState state = id == null ? null : activeSieges.get(id);
    return visible(state) ? state.morale : 100;
  }

  public static class SiegeState {
    public final UUID nationId;
    public volatile double damageRate;
    public volatile double moraleDrain;
    public final long startTime;
    public volatile long expireTime;
    private EffectTaskScope owner;
    private volatile EffectTaskScope.Timer timer;
    private volatile double morale = 100;
    private long remainingTicks;
    private long elapsedTicks;

    public SiegeState(UUID nationId, double damageRate, double moraleDrain, long expireTime) {
      this(nationId, damageRate, moraleDrain, System.currentTimeMillis(), expireTime);
    }

    private SiegeState(
        UUID nationId, double damageRate, double moraleDrain, long startTime, long expireTime) {
      this.nationId = nationId;
      this.damageRate = damageRate;
      this.moraleDrain = moraleDrain;
      this.startTime = startTime;
      this.expireTime = expireTime;
    }

    private SiegeState copy() {
      return new SiegeState(nationId, damageRate, moraleDrain, startTime, expireTime);
    }

    public int getRemainingSeconds() {
      return (int)
          Math.max(
              0, Math.min(Integer.MAX_VALUE, (expireTime - System.currentTimeMillis()) / 1000));
    }
  }

  @Override
  public String toString() {
    return String.format(
        "SiegeEffect{action=%s, damage=%.1f/min, morale=%.1f, duration=%ds}",
        action, damagePerMinute, moraleDrain, duration);
  }

  @Override
  public String getType() {
    return "siege";
  }

  @Override
  public String getDescription() {
    return String.format(
        "围城效果 [行动=%s, 国库=%.1f%%/分, 士气=%.1f/分, 持续=%ds]",
        action, damagePerMinute, moraleDrain, duration);
  }
}
