package dev.starcore.starcore.event.random.effect;

import dev.starcore.starcore.event.random.EventEffect;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;

/** 生成效果 生成生物或实体 */
public class SpawnEffect implements EventEffect {

  private static final Logger LOGGER = Logger.getLogger(SpawnEffect.class.getName());
  private final EntityType entityType;
  private final int amount;
  private final int radius;
  private final boolean hostile;
  private final double healthMultiplier;
  private final int duration;

  public SpawnEffect(
      EntityType entityType,
      int amount,
      int radius,
      boolean hostile,
      double healthMultiplier,
      int duration) {
    this.entityType = entityType;
    this.amount = amount;
    this.radius = radius;
    this.hostile = hostile;
    this.healthMultiplier = healthMultiplier;
    this.duration = duration;
  }

  @Override
  public java.util.concurrent.CompletableFuture<Boolean> applyAsync(
      Player player,
      Location location,
      dev.starcore.starcore.event.random.RandomEventRuntime runtime) {
    if (entityType == null
        || !entityType.isAlive()
        || amount < 1
        || amount > 128
        || duration < 0
        || radius < 0
        || radius > RegionBlockEffects.MAX_RADIUS
        || !Double.isFinite(healthMultiplier)
        || healthMultiplier <= 0)
      return java.util.concurrent.CompletableFuture.completedFuture(false);
    return runtime
        .location(player, location)
        .thenCompose(
            center -> {
              if (!RegionBlockEffects.valid(center, radius))
                return java.util.concurrent.CompletableFuture.completedFuture(false);
              var result = java.util.concurrent.CompletableFuture.completedFuture(false);
              for (int i = 0; i < amount; i++) {
                double angle = ThreadLocalRandom.current().nextDouble() * 2 * Math.PI;
                double distance = ThreadLocalRandom.current().nextDouble() * radius;
                Location destination =
                    center.clone().add(distance * Math.cos(angle), 0, distance * Math.sin(angle));
                result =
                    result.thenCompose(
                        spawned ->
                            runtime.regionLater(
                                destination,
                                owned -> {
                                  owned.setY(
                                      owned
                                              .getWorld()
                                              .getHighestBlockYAt(
                                                  owned.getBlockX(), owned.getBlockZ())
                                          + 1);
                                  if (!isSafeSpawnLocation(owned)) return spawned;
                                  var raw = owned.getWorld().spawnEntity(owned, entityType);
                                  if (!(raw instanceof LivingEntity entity)) return spawned;
                                  try {
                                    configureEntity(entity, player);
                                  } catch (RuntimeException failure) {
                                    entity.remove();
                                    throw failure;
                                  }
                                  if (duration > 0) {
                                    var expiry =
                                        runtime.entityLater(
                                            entity,
                                            duration * 20L,
                                            () -> {
                                              entity.remove();
                                              return null;
                                            });
                                    if (expiry.isCompletedExceptionally()) {
                                      entity.remove();
                                      return spawned;
                                    }
                                    expiry.exceptionally(
                                        failure -> {
                                          if (!dev.starcore.starcore.event.random.RandomEventRuntime
                                              .cancelled(failure))
                                            LOGGER.log(
                                                Level.WARNING,
                                                "Failed to expire event entity",
                                                failure);
                                          return null;
                                        });
                                  }
                                  return true;
                                }));
              }
              return result;
            });
  }

  @Override
  public boolean apply(Player player, Location location) {
    // Timed entities require the scoped asynchronous API to retain their removal task.
    if (duration != 0) return false;
    if (player != null && !org.bukkit.Bukkit.isOwnedByCurrentRegion(player)) return false;
    Location spawnLocation =
        location != null ? location : (player != null ? player.getLocation() : null);

    if (!RegionBlockEffects.valid(spawnLocation, radius)
        || amount < 1
        || amount > 128
        || entityType == null
        || !entityType.isAlive()
        || !Double.isFinite(healthMultiplier)
        || healthMultiplier <= 0) {
      return false;
    }
    // The synchronous API cannot move to another owner or load a foreign region.
    for (int cx = (spawnLocation.getBlockX() - radius) >> 4;
        cx <= (spawnLocation.getBlockX() + radius) >> 4;
        cx++)
      for (int cz = (spawnLocation.getBlockZ() - radius) >> 4;
          cz <= (spawnLocation.getBlockZ() + radius) >> 4;
          cz++)
        if (!org.bukkit.Bukkit.isOwnedByCurrentRegion(
            new Location(spawnLocation.getWorld(), cx * 16, spawnLocation.getY(), cz * 16)))
          return false;

    try {
      int spawned = 0;

      for (int i = 0; i < amount; i++) {
        // 在半径内随机位置生成
        Location randomLoc = getRandomLocation(spawnLocation, radius);

        // 确保生成位置安全
        if (!isSafeSpawnLocation(randomLoc)) {
          continue;
        }

        // 生成实体
        var world = randomLoc.getWorld();
        if (world == null) {
          continue;
        }
        LivingEntity entity = (LivingEntity) world.spawnEntity(randomLoc, entityType);

        if (entity != null) {
          // 设置生物属性
          try {
            configureEntity(entity, player);
          } catch (RuntimeException failure) {
            entity.remove();
            throw failure;
          }
          spawned++;
        }
      }

      return spawned > 0;
    } catch (Exception e) {
      LOGGER.log(Level.WARNING, "Failed to apply spawn effect", e);
      return false;
    }
  }

  /**
   * 获取半径内的随机位置
   *
   * @param center 中心位置
   * @param radius 半径
   * @return 随机位置
   */
  private Location getRandomLocation(Location center, int radius) {
    double angle = ThreadLocalRandom.current().nextDouble() * 2 * Math.PI;
    double distance = ThreadLocalRandom.current().nextDouble() * radius;

    double x = center.getX() + distance * Math.cos(angle);
    double z = center.getZ() + distance * Math.sin(angle);
    double y = center.getWorld().getHighestBlockYAt((int) Math.floor(x), (int) Math.floor(z)) + 1;

    return new Location(center.getWorld(), x, y, z);
  }

  /**
   * 检查位置是否安全生成
   *
   * @param location 位置
   * @return 如果安全返回true
   */
  private boolean isSafeSpawnLocation(Location location) {
    if (location.getWorld() == null) {
      return false;
    }

    // 检查是否在空气中且下方有固体方块
    return location.getBlock().isEmpty() && location.clone().add(0, -1, 0).getBlock().isSolid();
  }

  /**
   * 配置生成的实体
   *
   * @param entity 实体
   * @param player 相关玩家
   */
  private void configureEntity(LivingEntity entity, Player player) {
    // 设置生命值倍数
    if (healthMultiplier != 1.0) {
      var maxHealthAttr = entity.getAttribute(Attribute.MAX_HEALTH);
      if (maxHealthAttr != null) {
        double maxHealth = maxHealthAttr.getValue();
        if (!Double.isFinite(maxHealth) || maxHealth <= 0)
          throw new IllegalStateException("Invalid native entity max health");
        double newMaxHealth =
            healthMultiplier >= 1024.0 / maxHealth
                ? 1024.0
                : Math.max(1.0, maxHealth * healthMultiplier);
        maxHealthAttr.setBaseValue(newMaxHealth);
        entity.setHealth(Math.min(newMaxHealth, maxHealthAttr.getValue()));
      }
    }

    // 设置敌对状态
    if (hostile
        && player != null
        && org.bukkit.Bukkit.isOwnedByCurrentRegion(player)
        && player.isOnline()
        && player.getWorld() == entity.getWorld()
        && entity instanceof Mob mob) {
      mob.setTarget(player);
    }

    // 设置持久性（不会自然消失）
    entity.setRemoveWhenFarAway(duration > 0);
    // Timed event entities must not become permanent after a normal server restart.
    if (duration > 0) entity.setPersistent(false);

    // 可以添加自定义名称
    entity.setCustomName(String.format("§c事件生物 [%s]", entityType.name()));
    entity.setCustomNameVisible(true);
  }

  @Override
  public String getType() {
    return "SPAWN";
  }

  @Override
  public String getDescription() {
    return String.format("生成效果 [实体=%s, 数量=%d, 半径=%d, 敌对=%s]", entityType, amount, radius, hostile);
  }
}
