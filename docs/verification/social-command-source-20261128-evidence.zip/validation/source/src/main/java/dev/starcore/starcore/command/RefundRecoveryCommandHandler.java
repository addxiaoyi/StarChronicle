package dev.starcore.starcore.command;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.PendingRefund;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerSummary;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.CommandSender;

/** Administrative recovery surface for refunds that cannot be settled automatically. */
final class RefundRecoveryCommandHandler {
  private final StarCoreContext context;
  private final RefundLedger ledger;
  private final EconomyService economy;

  RefundRecoveryCommandHandler(StarCoreContext context) {
    this.context = context;
    this.ledger = context.serviceRegistry().require(RefundLedgerService.class).ledger();
    this.economy = context.economyService();
  }

  RefundRecoveryCommandHandler(RefundLedger ledger, EconomyService economy) {
    this.context = null;
    this.ledger = java.util.Objects.requireNonNull(ledger, "ledger");
    this.economy = java.util.Objects.requireNonNull(economy, "economy");
  }

  void handle(CommandSender sender, String[] args) {
    if (!sender.hasPermission("starcore.admin")) {
      sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
      return;
    }
    if (args.length < 3) {
      sender.sendMessage(
          Component.text(
              "Usage: /starcore economy recovery "
                  + "<list|summary|retry|review|owner|resolve|requeue>"
                  + " [transactionId] [reason]",
              NamedTextColor.YELLOW));
      return;
    }
    switch (args[2].toLowerCase()) {
      case "list" -> list(sender);
      case "summary", "health" -> summary(sender);
      case "retry" -> retry(sender, args);
      case "review" -> review(sender, args);
      case "owner" -> owner(sender, args);
      case "resolve" -> resolve(sender, args);
      case "requeue" -> requeue(sender, args);
      default -> sender.sendMessage(Component.text("Unknown recovery action.", NamedTextColor.RED));
    }
  }

  private void list(CommandSender sender) {
    List<PendingRefund> refunds =
        ledger.snapshot().stream()
            .sorted((a, b) -> a.nextAttemptAt().compareTo(b.nextAttemptAt()))
            .toList();
    if (refunds.isEmpty()) {
      sender.sendMessage(Component.text("No pending refunds.", NamedTextColor.GREEN));
      return;
    }
    sender.sendMessage(Component.text("Pending refunds: " + refunds.size(), NamedTextColor.GOLD));
    for (PendingRefund refund : refunds) {
      sender.sendMessage(
          Component.text(
              refund.transactionId()
                  + " owner="
                  + refund.owner()
                  + " reason="
                  + refund.reason()
                  + " account="
                  + refund.accountId()
                  + " amount="
                  + refund.amount().toPlainString()
                  + (refund.owner() == RefundOwner.UNKNOWN
                      ? " candidates=" + RefundLedger.legacyOwnerCandidates(refund)
                      : "")
                  + " attempts="
                  + refund.attempts()
                  + " manualReview="
                  + refund.manualReview(),
              NamedTextColor.GRAY));
    }
  }

  private void summary(CommandSender sender) {
    RefundLedgerSummary summary = ledger.summarize(Instant.now());
    sender.sendMessage(
        Component.text(
            "Refund ledger health: total="
                + summary.totalEntries()
                + " due="
                + summary.dueEntries()
                + " manualReview="
                + summary.manualReviewEntries()
                + " unknownOwner="
                + summary.unknownOwnerEntries(),
            NamedTextColor.GOLD));
    sender.sendMessage(
        Component.text(
            "Owners: DONATION="
                + summary.ownerCount(
                    dev.starcore.starcore.foundation.economy.transaction.RefundOwner.DONATION)
                + " DUNGEON="
                + summary.ownerCount(
                    dev.starcore.starcore.foundation.economy.transaction.RefundOwner.DUNGEON)
                + " TRADE="
                + summary.ownerCount(
                    dev.starcore.starcore.foundation.economy.transaction.RefundOwner.TRADE)
                + " SHOP="
                + summary.ownerCount(
                    dev.starcore.starcore.foundation.economy.transaction.RefundOwner.SHOP)
                + " NATION="
                + summary.ownerCount(
                    dev.starcore.starcore.foundation.economy.transaction.RefundOwner.NATION),
            NamedTextColor.GRAY));
    summary
        .oldestNextAttemptAt()
        .ifPresent(
            oldest ->
                sender.sendMessage(
                    Component.text("Oldest next attempt: " + oldest, NamedTextColor.GRAY)));
  }

  private void retry(CommandSender sender, String[] args) {
    PendingRefund refund = find(sender, args);
    if (refund == null) return;
    if (refund.manualReview()) {
      sender.sendMessage(
          Component.text(
              "Refund is marked for manual review; verify its balance before requeueing.",
              NamedTextColor.YELLOW));
      return;
    }

    try {
      if (!ledger.beginDeliveryAttempt(
          refund.transactionId(),
          "administrator retry in progress; reconcile after interruption")) {
        sender.sendMessage(
            Component.text("Refund was claimed or changed before retry.", NamedTextColor.YELLOW));
        return;
      }
    } catch (RuntimeException failure) {
      sender.sendMessage(
          Component.text(
              "Could not persist retry protection; no refund was attempted.", NamedTextColor.RED));
      logRecoveryFailure("REFUND_ADMIN_RETRY_MARKER_FAILURE", refund, sender, failure);
      return;
    }

    try {
      boolean delivered;
      try {
        delivered = economy.deposit(refund.accountId(), refund.amount());
      } catch (RuntimeException failure) {
        sender.sendMessage(
            Component.text(
                "Refund outcome is uncertain and requires manual review.", NamedTextColor.YELLOW));
        logRecoveryFailure("REFUND_ADMIN_RETRY_UNCERTAIN", refund, sender, failure);
        return;
      }

      if (delivered) {
        try {
          ledger.markDelivered(refund.transactionId());
          sender.sendMessage(Component.text("Refund delivered.", NamedTextColor.GREEN));
          logRecoveryAudit("REFUND_ADMIN_RETRY_DELIVERED", refund, sender, "operator retry");
        } catch (RuntimeException failure) {
          sender.sendMessage(
              Component.text(
                  "Refund was delivered; its ledger record needs manual review.",
                  NamedTextColor.YELLOW));
          logRecoveryFailure("REFUND_ADMIN_RETRY_LEDGER_FAILURE", refund, sender, failure);
        }
      } else {
        try {
          ledger.markFailed(
              refund,
              "administrator retry was rejected",
              RefundLedger.nextRetry(Instant.now(), refund.attempts() + 1));
          sender.sendMessage(
              Component.text("Refund retry failed and remains queued.", NamedTextColor.RED));
          logRecoveryAudit(
              "REFUND_ADMIN_RETRY_REJECTED", refund, sender, "provider rejected delivery");
        } catch (RuntimeException failure) {
          sender.sendMessage(
              Component.text(
                  "Refund was rejected; its retry state requires manual review.",
                  NamedTextColor.YELLOW));
          logRecoveryFailure("REFUND_ADMIN_RETRY_LEDGER_FAILURE", refund, sender, failure);
        }
      }
    } finally {
      ledger.finishDeliveryAttempt(refund.transactionId());
    }
  }

  private void requeue(CommandSender sender, String[] args) {
    PendingRefund refund = find(sender, args);
    if (refund == null) return;
    if (args.length < 5) {
      sender.sendMessage(
          Component.text(
              "Usage: ... recovery requeue <transactionId> <balance verification and reason>",
              NamedTextColor.YELLOW));
      return;
    }
    if (!refund.manualReview()) {
      sender.sendMessage(
          Component.text("Only manually reviewed refunds can be requeued.", NamedTextColor.RED));
      return;
    }
    if (refund.owner() == RefundOwner.UNKNOWN) {
      sender.sendMessage(
          Component.text("Assign a verified refund owner before requeueing.", NamedTextColor.RED));
      return;
    }
    String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length)).trim();
    try {
      if (ledger.authorizeRetry(refund.transactionId(), reason, Instant.now())) {
        sender.sendMessage(
            Component.text(
                "Refund requeued. Verify the player balance before authorization.",
                NamedTextColor.YELLOW));
        logRecoveryAudit("REFUND_RETRY_AUTHORIZED", refund, sender, reason);
      } else {
        sender.sendMessage(
            Component.text("Refund changed before it could be requeued.", NamedTextColor.RED));
      }
    } catch (RuntimeException failure) {
      sender.sendMessage(
          Component.text("Could not persist the refund requeue.", NamedTextColor.RED));
      logRecoveryFailure("REFUND_REQUEUE_FAILURE", refund, sender, failure);
    }
  }

  private void review(CommandSender sender, String[] args) {
    PendingRefund refund = find(sender, args);
    if (refund == null) return;
    String reason =
        args.length > 3
            ? String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length))
            : "manual review";
    ledger.markManualReview(refund.transactionId(), reason);
    sender.sendMessage(Component.text("Refund marked for manual review.", NamedTextColor.YELLOW));
  }

  private void owner(CommandSender sender, String[] args) {
    PendingRefund refund = find(sender, args);
    if (refund == null) return;
    if (args.length < 5) {
      sender.sendMessage(
          Component.text(
              "Usage: ... recovery owner <transactionId> "
                  + "<DONATION|DUNGEON|TRADE|SHOP|NATION> <reason>",
              NamedTextColor.YELLOW));
      return;
    }
    try {
      RefundOwner owner = RefundOwner.valueOf(args[4].toUpperCase(java.util.Locale.ROOT));
      if (owner == RefundOwner.UNKNOWN) {
        sender.sendMessage(
            Component.text(
                "UNKNOWN is reserved for unassigned legacy refunds.", NamedTextColor.RED));
        return;
      }
      String reason =
          args.length > 5
              ? String.join(" ", java.util.Arrays.copyOfRange(args, 5, args.length))
              : "operator owner assignment";
      if (ledger.assignOwner(refund.transactionId(), owner, reason)) {
        sender.sendMessage(Component.text("Refund owner assigned: " + owner, NamedTextColor.GREEN));
      } else {
        sender.sendMessage(
            Component.text(
                "Owner assignment requires an existing UNKNOWN refund.", NamedTextColor.RED));
      }
    } catch (IllegalArgumentException invalid) {
      sender.sendMessage(
          Component.text("Invalid refund owner or migration reason.", NamedTextColor.RED));
    }
  }

  private void resolve(CommandSender sender, String[] args) {
    PendingRefund refund = find(sender, args);
    if (refund == null) return;
    if (args.length < 5) {
      sender.sendMessage(
          Component.text(
              "Usage: ... recovery resolve <transactionId> <settlement verification and reason>",
              NamedTextColor.YELLOW));
      return;
    }
    if (!refund.manualReview()) {
      sender.sendMessage(
          Component.text("Only manually reviewed refunds can be resolved.", NamedTextColor.RED));
      return;
    }
    if (ledger.isDeliveryAttemptActive(refund.transactionId())) {
      sender.sendMessage(
          Component.text(
              "Refund delivery is still active; resolution was not changed.",
              NamedTextColor.YELLOW));
      return;
    }
    String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length)).trim();
    if (reason.isBlank()) {
      sender.sendMessage(Component.text("A settlement reason is required.", NamedTextColor.YELLOW));
      return;
    }
    try {
      ledger.markDelivered(refund.transactionId());
      sender.sendMessage(Component.text("Refund record resolved.", NamedTextColor.GREEN));
      logRecoveryAudit("REFUND_MANUAL_RESOLVED", refund, sender, reason);
    } catch (RuntimeException failure) {
      sender.sendMessage(
          Component.text("Could not persist refund resolution.", NamedTextColor.RED));
      logRecoveryFailure("REFUND_RESOLUTION_FAILURE", refund, sender, failure);
    }
  }

  private void logRecoveryAudit(
      String code, PendingRefund refund, CommandSender sender, String reason) {
    recoveryLogger()
        .log(
            Level.INFO,
            "code="
                + code
                + " transactionId="
                + refund.transactionId()
                + " owner="
                + refund.owner()
                + " account="
                + refund.accountId()
                + " amount="
                + refund.amount().toPlainString()
                + " operator="
                + auditField(sender.getName())
                + " reason="
                + auditField(reason));
  }

  private void logRecoveryFailure(
      String code, PendingRefund refund, CommandSender sender, RuntimeException failure) {
    recoveryLogger()
        .log(
            Level.SEVERE,
            "code="
                + code
                + " transactionId="
                + refund.transactionId()
                + " owner="
                + refund.owner()
                + " account="
                + refund.accountId()
                + " amount="
                + refund.amount().toPlainString()
                + " operator="
                + auditField(sender.getName()),
            failure);
  }

  private static String auditField(String value) {
    return value == null
        ? "unknown"
        : value.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
  }

  private Logger recoveryLogger() {
    return context == null
        ? Logger.getLogger(RefundRecoveryCommandHandler.class.getName())
        : context.plugin().getLogger();
  }

  private PendingRefund find(CommandSender sender, String[] args) {
    if (args.length < 4) {
      sender.sendMessage(Component.text("A transactionId is required.", NamedTextColor.YELLOW));
      return null;
    }
    try {
      UUID id = UUID.fromString(args[3]);
      return ledger.snapshot().stream()
          .filter(refund -> refund.transactionId().equals(id))
          .findFirst()
          .orElseGet(
              () -> {
                sender.sendMessage(
                    Component.text("Refund transaction not found.", NamedTextColor.RED));
                return null;
              });
    } catch (IllegalArgumentException invalid) {
      sender.sendMessage(Component.text("Invalid transactionId.", NamedTextColor.RED));
      return null;
    }
  }
}
