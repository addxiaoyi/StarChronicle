package dev.starcore.starcore.api.v1.auth;

import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import org.bukkit.command.CommandSender;

public final class ApiKeyAdminCommand {
    private final ApiAuthService auth;

    public ApiKeyAdminCommand(ApiAuthService auth) {
        this.auth = Objects.requireNonNull(auth, "auth");
    }

    public boolean execute(CommandSender sender, String[] args) {
        Objects.requireNonNull(sender, "sender");
        if (!sender.hasPermission("starcore.admin")) {
            sender.sendMessage("No permission.");
            return true;
        }
        if (args == null || args.length == 0) {
            sender.sendMessage("Usage: /starcore apikey <create|rotate|revoke>");
            return true;
        }
        try {
            return switch (args[0].toLowerCase(Locale.ROOT)) {
                case "create" -> create(sender, args);
                case "rotate" -> rotate(sender, args);
                case "revoke" -> revoke(sender, args);
                default -> {
                    sender.sendMessage("Unknown API key action.");
                    yield true;
                }
            };
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(exception.getMessage());
            return true;
        }
    }

    private boolean create(CommandSender sender, String[] args) {
        if (args.length != 4) {
            throw new IllegalArgumentException(
                "Usage: /starcore apikey create <owner-uuid> <name> <permissions>");
        }
        UUID owner = UUID.fromString(args[1]);
        ApiAuthService.ApiKeyPermission[] permissions = Arrays.stream(args[3].split(","))
            .map(String::trim)
            .filter(value -> !value.isEmpty())
            .map(value -> ApiAuthService.ApiKeyPermission.valueOf(
                value.toUpperCase(Locale.ROOT)))
            .toArray(ApiAuthService.ApiKeyPermission[]::new);
        if (permissions.length == 0) {
            throw new IllegalArgumentException("At least one permission is required.");
        }
        String key = auth.generateApiKey(owner, args[2], permissions);
        sender.sendMessage("API key created: " + key);
        return true;
    }

    private boolean rotate(CommandSender sender, String[] args) {
        if (args.length != 2) {
            throw new IllegalArgumentException(
                "Usage: /starcore apikey rotate <key>");
        }
        sender.sendMessage("API key rotated: " + auth.rotateApiKey(args[1]));
        return true;
    }

    private boolean revoke(CommandSender sender, String[] args) {
        if (args.length != 2) {
            throw new IllegalArgumentException(
                "Usage: /starcore apikey revoke <key>");
        }
        sender.sendMessage(auth.revokeApiKey(args[1])
            ? "API key revoked."
            : "API key not found.");
        return true;
    }
}
