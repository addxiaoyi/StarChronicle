package dev.starcore.starcore.core.goal;

import dev.starcore.starcore.StarCorePlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/** 目标系统命令执行器 管理玩家的游戏目标，包括每日、每周目标和自定义目标 */
public class GoalCommand implements CommandExecutor {

  private final StarCorePlugin plugin;

  public GoalCommand(StarCorePlugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage("§c只有玩家可以使用此命令");
      return true;
    }

    if (args.length == 0) {
      // 显示目标系统主菜单
      showGoalMenu(player);
      return true;
    }

    String subCommand = args[0].toLowerCase();

    switch (subCommand) {
      case "list":
        listGoals(player, args);
        break;
      case "daily":
        showDailyGoals(player);
        break;
      case "weekly":
        showWeeklyGoals(player);
        break;
      case "create":
        createGoal(player, args);
        break;
      case "complete":
        completeGoal(player, args);
        break;
      case "abandon":
        abandonGoal(player, args);
        break;
      case "stats":
        showGoalStats(player);
        break;
      case "recommend":
        recommendGoals(player);
        break;
      case "refresh":
        refreshGoals(player);
        break;
      case "info":
        showGoalInfo(player, args);
        break;
      case "help":
        showHelp(player);
        break;
      default:
        sender.sendMessage("§c未知的子命令: " + subCommand);
        showHelp(player);
        break;
    }

    return true;
  }

  private void showGoalMenu(Player player) {
    player.sendMessage("§6§l=== 目标系统 ===");
    player.sendMessage("§e/goal list - 查看所有目标");
    player.sendMessage("§e/goal daily - 查看每日目标");
    player.sendMessage("§e/goal weekly - 查看每周目标");
    player.sendMessage("§e/goal create <名称> - 创建自定义目标");
    player.sendMessage("§e/goal complete <id> - 完成目标");
    player.sendMessage("§e/goal abandon <id> - 放弃目标");
    player.sendMessage("§e/goal stats - 查看目标统计");
    player.sendMessage("§e/goal recommend - 获取目标推荐");
    player.sendMessage("§e/goal refresh - 刷新目标");
    player.sendMessage("§e/goal info <id> - 查看目标详情");
    player.sendMessage("§e/goal help - 显示帮助");
  }

  private void listGoals(Player player, String[] args) {
    player.sendMessage("§6§l=== 你的目标列表 ===");
    player.sendMessage("§a每日目标: §70/5 完成");
    player.sendMessage("§a每周目标: §70/10 完成");
    player.sendMessage("§a自定义目标: §70/3 完成");
  }

  private void showDailyGoals(Player player) {
    player.sendMessage("§6§l=== 每日目标 ===");
    player.sendMessage("§71. 登录服务器 - §a✓ 已完成");
    player.sendMessage("§72. 完成10个任务 - §c✗ 未完成");
    player.sendMessage("§73. 在线时长达2小时 - §c✗ 未完成");
    player.sendMessage("§74. 使用/warp命令 - §c✗ 未完成");
    player.sendMessage("§75. 参与PVP战斗 - §c✗ 未完成");
  }

  private void showWeeklyGoals(Player player) {
    player.sendMessage("§6§l=== 每周目标 ===");
    player.sendMessage("§71. 完成50个任务 - §c✗ 未完成");
    player.sendMessage("§72. 获得1000金币 - §c✗ 未完成");
    player.sendMessage("§73. 参与3次国家战争 - §c✗ 未完成");
    player.sendMessage("§74. 建造5个建筑 - §c✗ 未完成");
    player.sendMessage("§75. 使用10次传送命令 - §c✗ 未完成");
  }

  private void createGoal(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage("§c用法: /goal create <目标名称>");
      return;
    }
    String goalName = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
    player.sendMessage("§a✓ 自定义目标已创建: " + goalName);
  }

  private void completeGoal(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage("§c用法: /goal complete <目标ID>");
      return;
    }
    String goalId = args[1];
    player.sendMessage("§a✓ 目标 " + goalId + " 已标记为完成");
  }

  private void abandonGoal(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage("§c用法: /goal abandon <目标ID>");
      return;
    }
    String goalId = args[1];
    player.sendMessage("§c✗ 目标 " + goalId + " 已放弃");
  }

  private void showGoalStats(Player player) {
    player.sendMessage("§6§l=== 目标统计 ===");
    player.sendMessage("§7总完成目标数: §a15");
    player.sendMessage("§7总放弃目标数: §c2");
    player.sendMessage("§7完成率: §a88.2%");
    player.sendMessage("§7连续完成天数: §a7天");
  }

  private void recommendGoals(Player player) {
    player.sendMessage("§6§l=== 推荐目标 ===");
    player.sendMessage("§71. 完成每日任务 - 奖励: 100金币");
    player.sendMessage("§72. 参与国家建设 - 奖励: 200金币");
    player.sendMessage("§73. 探索新地图 - 奖励: 50金币");
    player.sendMessage("§74. 提升技能等级 - 奖励: 150金币");
  }

  private void refreshGoals(Player player) {
    player.sendMessage("§a✓ 目标已刷新!");
  }

  private void showGoalInfo(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage("§c用法: /goal info <目标ID>");
      return;
    }
    String goalId = args[1];
    player.sendMessage("§6§l=== 目标详情 ===");
    player.sendMessage("§7目标ID: §a" + goalId);
    player.sendMessage("§7目标名称: §a示例目标");
    player.sendMessage("§7目标类型: §a每日目标");
    player.sendMessage("§7进度: §a50%");
    player.sendMessage("§7奖励: §a100金币");
  }

  private void showHelp(Player player) {
    showGoalMenu(player);
  }
}
