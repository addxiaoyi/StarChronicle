package dev.starcore.starcore.core.monitoring;

/** Supplies an additional Prometheus exposition fragment to the monitoring service. */
@FunctionalInterface
public interface PrometheusMetricsSource {
  /**
   * Exports a valid Prometheus text exposition fragment.
   *
   * @return the fragment, or an empty string when the source has no metrics
   * @throws Exception when the source cannot produce its snapshot
   */
  String export() throws Exception;
}
