package dev.starcore.starcore.achievement;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

final class AchievementVaultBridge {
    private AchievementVaultBridge() {
    }

    static boolean deposit(Player player, double amount) {
        var registration = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (registration == null) {
            return false;
        }
        registration.getProvider().depositPlayer(player, amount);
        return true;
    }
}
