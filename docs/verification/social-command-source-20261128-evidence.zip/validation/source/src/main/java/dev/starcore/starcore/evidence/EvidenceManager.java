package dev.starcore.starcore.evidence;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/** 证据管理器 管理所有证据的获取、使用和存档 */
public class EvidenceManager {

  private final Map<String, Evidence> evidenceInstances = new ConcurrentHashMap<>();
  private final Map<String, Set<String>> playerEvidence = new ConcurrentHashMap<>();

  /** 创建证据 */
  public Evidence createEvidence(String playerId, EvidenceType type, String sourceId) {
    String evidenceId = generateEvidenceId();
    Evidence evidence = Evidence.builder(evidenceId, playerId, type).sourceId(sourceId).build();

    evidenceInstances.put(evidenceId, evidence);
    playerEvidence.computeIfAbsent(playerId, k -> new HashSet<>()).add(evidenceId);

    return evidence;
  }

  /** 获取玩家的所有证据 */
  public Set<Evidence> getPlayerEvidence(String playerId) {
    Set<String> ids = playerEvidence.get(playerId);
    if (ids == null) return Set.of();

    Set<Evidence> result = new HashSet<>();
    for (String id : ids) {
      Evidence evidence = evidenceInstances.get(id);
      if (evidence != null && evidence.isValid()) {
        result.add(evidence);
      }
    }
    return result;
  }

  /** 获取指定类型证据 */
  public Set<Evidence> getEvidenceByType(EvidenceType type) {
    Set<Evidence> result = new HashSet<>();
    for (Evidence evidence : evidenceInstances.values()) {
      if (evidence.type() == type && evidence.isValid()) {
        result.add(evidence);
      }
    }
    return result;
  }

  /** 获取指定来源证据 */
  public Set<Evidence> getEvidenceBySource(String sourceId) {
    Set<Evidence> result = new HashSet<>();
    for (Evidence evidence : evidenceInstances.values()) {
      if (sourceId.equals(evidence.sourceId()) && evidence.isValid()) {
        result.add(evidence);
      }
    }
    return result;
  }

  /** 使用证据 */
  public boolean useEvidence(String evidenceId, String playerId) {
    Evidence evidence = evidenceInstances.get(evidenceId);
    if (evidence == null || !evidence.playerId().equals(playerId) || !evidence.isValid()) {
      return false;
    }

    Evidence usedEvidence =
        new Evidence(
            evidence.evidenceId(),
            evidence.playerId(),
            evidence.type(),
            evidence.sourceId(),
            evidence.metadata(),
            evidence.obtainedAt(),
            evidence.expiresAt(),
            true);

    evidenceInstances.put(evidenceId, usedEvidence);
    return true;
  }

  /** 获取证据 */
  public Optional<Evidence> getEvidence(String evidenceId) {
    Evidence evidence = evidenceInstances.get(evidenceId);
    if (evidence == null || !evidence.isValid()) {
      return Optional.empty();
    }
    return Optional.of(evidence);
  }

  /** 检查玩家是否拥有指定类型的证据 */
  public boolean playerHasEvidence(String playerId, EvidenceType type) {
    return getPlayerEvidence(playerId).stream().anyMatch(e -> e.type() == type);
  }

  /** 检查玩家是否拥有来自指定来源的证据 */
  public boolean playerHasEvidenceFrom(String playerId, String sourceId) {
    return getPlayerEvidence(playerId).stream().anyMatch(e -> sourceId.equals(e.sourceId()));
  }

  /** 生成证据ID */
  private String generateEvidenceId() {
    return "evidence_"
        + System.currentTimeMillis()
        + "_"
        + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 获取玩家证据数量 */
  public int getPlayerEvidenceCount(String playerId) {
    return playerEvidence.getOrDefault(playerId, Set.of()).size();
  }

  /** 获取所有有效证据数量 */
  public int getValidEvidenceCount() {
    return (int) evidenceInstances.values().stream().filter(Evidence::isValid).count();
  }

  /** 清理过期证据 */
  public int cleanupExpiredEvidence() {
    List<String> toRemove = new ArrayList<>();
    for (Map.Entry<String, Evidence> entry : evidenceInstances.entrySet()) {
      if (entry.getValue().isExpired() || entry.getValue().used()) {
        toRemove.add(entry.getKey());
      }
    }

    for (String id : toRemove) {
      Evidence evidence = evidenceInstances.remove(id);
      if (evidence != null) {
        Set<String> playerIds = playerEvidence.get(evidence.playerId());
        if (playerIds != null) {
          playerIds.remove(id);
        }
      }
    }

    return toRemove.size();
  }

  /** 清理所有证据 */
  public void clear() {
    evidenceInstances.clear();
    playerEvidence.clear();
  }

  // ==================== 证据提交与验证 ====================

  /**
   * 提交证据给案件
   *
   * @return 提交到的案件ID（如果成功），或null（如果失败）
   */
  public Optional<String> submitEvidence(
      String evidenceId, String playerId, String caseId, String submissionType) {
    Evidence evidence = evidenceInstances.get(evidenceId);
    if (evidence == null || !evidence.playerId().equals(playerId)) {
      return Optional.empty();
    }

    // 标记为提交状态
    Map<String, Object> metadata = new HashMap<>(evidence.metadata());
    metadata.put("submission_case_id", caseId);
    metadata.put("submission_type", submissionType);
    metadata.put("submitted_at", Instant.now().toEpochMilli());
    metadata.put("status", "submitted");

    Evidence submittedEvidence =
        new Evidence(
            evidence.evidenceId(),
            evidence.playerId(),
            evidence.type(),
            evidence.sourceId(),
            metadata,
            evidence.obtainedAt(),
            evidence.expiresAt(),
            false // not used, just submitted
            );

    evidenceInstances.put(evidenceId, submittedEvidence);
    return Optional.of(caseId);
  }

  /** 验证证据 */
  public ValidationResult validateEvidence(
      String evidenceId, String validatorId, boolean accepted, String notes) {
    Evidence evidence = evidenceInstances.get(evidenceId);
    if (evidence == null) {
      return new ValidationResult(evidenceId, validatorId, false, "证据不存在");
    }

    Map<String, Object> metadata = new HashMap<>(evidence.metadata());
    metadata.put("last_validation_at", Instant.now().toEpochMilli());
    metadata.put("last_validator", validatorId);
    metadata.put("accepted", accepted);
    if (accepted) {
      metadata.put("status", "validated_accepted");
    } else {
      metadata.put("status", "validated_rejected");
    }

    if (notes != null && !notes.isEmpty()) {
      metadata.put("validation_notes", notes);
    }

    Evidence validatedEvidence =
        new Evidence(
            evidence.evidenceId(),
            evidence.playerId(),
            evidence.type(),
            evidence.sourceId(),
            metadata,
            evidence.obtainedAt(),
            evidence.expiresAt(),
            accepted // use if accepted
            );

    evidenceInstances.put(evidenceId, validatedEvidence);

    return new ValidationResult(
        evidenceId, validatorId, accepted, accepted ? "证据验证通过" : "证据验证拒绝: " + notes);
  }

  /** 获取提交给指定案件的证据 */
  public List<Evidence> getSubmittedEvidenceForCase(String caseId) {
    List<Evidence> result = new ArrayList<>();
    for (Evidence evidence : evidenceInstances.values()) {
      Object status = evidence.metadata().get("status");
      if ("submitted".equals(status) || "validated_accepted".equals(status)) {
        Object submissionCaseId = evidence.metadata().get("submission_case_id");
        if (caseId.equals(submissionCaseId)) {
          result.add(evidence);
        }
      }
    }
    return result;
  }

  /** 获取待审核的证据 */
  public List<Evidence> getUnvalidatedEvidence() {
    List<Evidence> result = new ArrayList<>();
    for (Evidence evidence : evidenceInstances.values()) {
      Object status = evidence.metadata().get("status");
      if ("submitted".equals(status)) {
        result.add(evidence);
      }
    }
    return result;
  }

  /** 获取玩家提交给指定案件的证据 */
  public List<Evidence> getPlayerSubmittedEvidenceForCase(String playerId, String caseId) {
    List<Evidence> result = new ArrayList<>();
    Set<String> ids = playerEvidence.get(playerId);
    if (ids == null) return result;

    for (String id : ids) {
      Evidence evidence = evidenceInstances.get(id);
      if (evidence != null) {
        Object status = evidence.metadata().get("status");
        Object submissionCaseId = evidence.metadata().get("submission_case_id");
        if (("submitted".equals(status) || "validated_rejected".equals(status))
            && caseId.equals(submissionCaseId)) {
          result.add(evidence);
        }
      }
    }
    return result;
  }

  /** 批量验证证据 */
  public ValidationSummary validateEvidenceBatch(
      String validatorId, List<String> evidenceIds, boolean accepted) {
    int passed = 0;
    int failed = 0;
    List<ValidationResult> results = new ArrayList<>();
    List<String> failures = new ArrayList<>();

    for (String evidenceId : evidenceIds) {
      ValidationResult result = validateEvidence(evidenceId, validatorId, accepted, null);
      results.add(result);
      if (result.accepted()) {
        passed++;
      } else {
        failed++;
        failures.add(result.message());
      }
    }

    return new ValidationSummary(
        results,
        passed,
        failed,
        failures.isEmpty() ? "批量验证完成" : "部分验证失败: " + String.join(", ", failures));
  }

  /** 证据过滤器 */
  public List<Evidence> filterEvidence(Predicate<Evidence> filter) {
    List<Evidence> result = new ArrayList<>();
    for (Evidence evidence : evidenceInstances.values()) {
      if (filter.test(evidence)) {
        result.add(evidence);
      }
    }
    return result;
  }

  /** 证据存档 */
  public void archiveEvidence(String evidenceId) {
    Evidence evidence = evidenceInstances.get(evidenceId);
    if (evidence == null) return;

    Map<String, Object> metadata = new HashMap<>(evidence.metadata());
    metadata.put("archived_at", Instant.now().toEpochMilli());
    metadata.put("status", "archived");

    Evidence archivedEvidence =
        new Evidence(
            evidence.evidenceId(),
            evidence.playerId(),
            evidence.type(),
            evidence.sourceId(),
            metadata,
            evidence.obtainedAt(),
            evidence.expiresAt(),
            evidence.used());

    evidenceInstances.put(evidenceId, archivedEvidence);
  }

  /** 批量存档证据 */
  public int archiveEvidenceBatch(List<String> evidenceIds) {
    int archived = 0;
    for (String evidenceId : evidenceIds) {
      archiveEvidence(evidenceId);
      archived++;
    }
    return archived;
  }

  // ==================== 辅助记录 ====================

  /** 验证结果 */
  public record ValidationResult(
      String evidenceId, String validatorId, boolean accepted, String message) {}

  /** 验证摘要 */
  public record ValidationSummary(
      List<ValidationResult> results, int passed, int failed, String summary) {}
}
