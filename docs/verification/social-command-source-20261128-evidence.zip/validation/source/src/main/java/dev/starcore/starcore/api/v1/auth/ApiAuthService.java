package dev.starcore.starcore.api.v1.auth;

import dev.starcore.starcore.core.database.DatabaseService;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.sql.SQLException;
import java.time.Clock;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/** API 认证服务 提供 API Key 和签名认证机制 */
public final class ApiAuthService {
  private static final String API_KEY_TABLE = "rest_api_keys";
  private static final String API_KEY_LOAD_FAILURE_CODE = "code=API_KEY_LOAD_FAILURE";
  private static final String API_KEY_RECORD_INVALID_CODE = "code=API_KEY_RECORD_INVALID";
  private static final String API_KEY_REVOKE_FAILURE_CODE = "code=API_KEY_REVOKE_FAILURE";

  public static final String HEADER_API_KEY = "X-API-Key"; // mimosa-disable-line: CWE-798
  public static final String HEADER_SIGNATURE = "X-Signature";
  public static final String HEADER_TIMESTAMP = "X-Timestamp";
  public static final String HEADER_NONCE = "X-Nonce";

  private static final String SIGNATURE_ALGORITHM = "HmacSHA256";
  private static final Duration SIGNATURE_TTL = Duration.ofMinutes(5);
  private static final Duration DEFAULT_API_KEY_TTL = Duration.ofHours(24);
  private static final int MAX_NONCE_CACHE_SIZE = 10000;

  private final String signingSecret;
  private final Duration apiKeyTtl;
  private final Clock clock;
  private final DatabaseService database;
  private final Map<String, ApiKeyInfo> apiKeys = new ConcurrentHashMap<>();
  private final Map<String, Long> nonceCache = new ConcurrentHashMap<>();
  private static final AtomicLong txSeq = new AtomicLong();

  public ApiAuthService(String signingSecret) {
    this(signingSecret, DEFAULT_API_KEY_TTL, Clock.systemUTC(), null);
  }

  public ApiAuthService(String signingSecret, Duration apiKeyTtl) {
    this(signingSecret, apiKeyTtl, Clock.systemUTC(), null);
  }

  public ApiAuthService(String signingSecret, Duration apiKeyTtl, DatabaseService database) {
    this(signingSecret, apiKeyTtl, Clock.systemUTC(), database);
  }

  public ApiAuthService(String signingSecret, Duration apiKeyTtl, Clock clock) {
    this(signingSecret, apiKeyTtl, clock, null);
  }

  public ApiAuthService(
      String signingSecret, Duration apiKeyTtl, Clock clock, DatabaseService database) {
    this.signingSecret = signingSecret != null ? signingSecret : generateFallbackSecret();
    this.apiKeyTtl = Objects.requireNonNull(apiKeyTtl, "apiKeyTtl");
    this.clock = Objects.requireNonNull(clock, "clock");
    this.database = database;
    if (apiKeyTtl.isZero() || apiKeyTtl.isNegative()) {
      throw new IllegalArgumentException("API key TTL must be positive");
    }
    if (database != null) {
      initializeApiKeyTable();
    }
  }

  /** 生成 API Key */
  public String generateApiKey(UUID playerId, String playerName, ApiKeyPermission... permissions) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(permissions, "permissions");
    String key = generateRandomKey();
    Instant now = clock.instant();
    ApiKeyInfo info =
        new ApiKeyInfo(
            key,
            playerId,
            playerName,
            now,
            now.plus(apiKeyTtl),
            java.util.Arrays.asList(permissions));
    if (database != null) {
      persistApiKey(info);
    }
    apiKeys.put(key, info);
    return key;
  }

  /** 验证 API Key */
  public Optional<ApiKeyInfo> validateApiKey(String apiKey) {
    if (apiKey == null || apiKey.isBlank()) {
      return Optional.empty();
    }
    ApiKeyInfo info = apiKeys.get(apiKey);
    if (info == null && database != null) {
      try {
        info = loadApiKey(apiKey);
      } catch (RuntimeException failure) {
        logLoadFailure(apiKey, failure);
        return Optional.empty();
      }
      if (info != null) {
        apiKeys.put(apiKey, info);
      }
    }
    if (info == null) {
      return Optional.empty();
    }
    if (clock.instant().isAfter(info.expiresAt())) {
      revokeApiKey(apiKey);
      return Optional.empty();
    }
    return Optional.of(info);
  }

  /** 撤销 API Key */
  public boolean revokeApiKey(String apiKey) {
    if (apiKey == null || apiKey.isBlank()) {
      return false;
    }
    ApiKeyInfo removed = apiKeys.remove(apiKey);
    if (database != null) {
      try {
        boolean deleted =
            database.update("DELETE FROM " + API_KEY_TABLE + " WHERE key_hash = ?", hashKey(apiKey))
                > 0;
        if (!deleted && removed != null) {
          apiKeys.put(apiKey, removed);
        }
        return deleted;
      } catch (RuntimeException exception) {
        if (removed != null) {
          apiKeys.put(apiKey, removed);
        }
        String masked =
            apiKey != null && apiKey.length() > 8
                ? apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4)
                : "unknown";
        String message =
            "ApiAuthService code=API_KEY_REVOKE_FAILURE op=revoke apiKey="
                + masked
                + " txId="
                + txSeq.incrementAndGet();
        System.getLogger(ApiAuthService.class.getName())
            .log(System.Logger.Level.WARNING, message, exception);
        throw exception;
      }
    }
    return removed != null;
  }

  /**
   * Replaces an active key while preserving its owner and permissions. The new key is persisted
   * before the old key is revoked.
   */
  public synchronized String rotateApiKey(String apiKey) {
    ApiKeyInfo current =
        validateApiKey(apiKey)
            .orElseThrow(() -> new IllegalArgumentException("API key is unknown or expired"));
    String replacement =
        generateApiKey(
            current.playerId(),
            current.playerName(),
            current.permissions().toArray(ApiKeyPermission[]::new));
    try {
      if (!revokeApiKey(apiKey)) {
        throw new IllegalStateException("Previous API key could not be revoked");
      }
      return replacement;
    } catch (RuntimeException failure) {
      boolean replacementRollback = rollbackReplacement(replacement, failure);
      throw new IllegalStateException(
          "code=API_KEY_ROTATION_FAILURE replacement-rollback=" + replacementRollback, failure);
    }
  }

  private boolean rollbackReplacement(String replacement, RuntimeException primaryFailure) {
    try {
      if (revokeApiKey(replacement)) {
        return true;
      }
      primaryFailure.addSuppressed(
          new IllegalStateException("Replacement API key could not be revoked"));
    } catch (RuntimeException rollbackFailure) {
      primaryFailure.addSuppressed(rollbackFailure);
    }
    return false;
  }

  /** 验证请求签名 */
  public SignatureValidationResult validateSignature(
      String method,
      String path,
      String queryString,
      String timestamp,
      String nonce,
      String signature) {
    if (!hasRequestTarget(method, path)) {
      return SignatureValidationResult.invalid("Invalid request target");
    }
    if (timestamp == null || nonce == null || signature == null) {
      return SignatureValidationResult.missing("Missing signature headers");
    }
    if (nonce.isBlank()) {
      return SignatureValidationResult.invalid("Invalid nonce");
    }

    return validateSignature(
        timestamp, nonce, signature, computeSignature(method, path, queryString, timestamp, nonce));
  }

  public SignatureValidationResult validateSignature(
      String method,
      String path,
      String queryString,
      String timestamp,
      String nonce,
      byte[] body,
      String signature) {
    if (!hasRequestTarget(method, path)) {
      return SignatureValidationResult.invalid("Invalid request target");
    }
    if (timestamp == null || nonce == null || signature == null) {
      return SignatureValidationResult.missing("Missing signature headers");
    }
    if (nonce.isBlank()) {
      return SignatureValidationResult.invalid("Invalid nonce");
    }
    return validateSignature(
        timestamp,
        nonce,
        signature,
        computeSignature(method, path, queryString, timestamp, nonce, body));
  }

  private SignatureValidationResult validateSignature(
      String timestamp, String nonce, String signature, String expectedSignature) {

    // 验证时间戳
    long ts;
    try {
      ts = Long.parseLong(timestamp);
    } catch (NumberFormatException e) {
      return SignatureValidationResult.invalid("Invalid timestamp format");
    }

    Instant requestTime;
    try {
      requestTime = Instant.ofEpochSecond(ts);
    } catch (DateTimeException exception) {
      return SignatureValidationResult.invalid("Invalid timestamp value");
    }
    Instant now = clock.instant();

    if (Duration.between(requestTime, now).abs().compareTo(SIGNATURE_TTL) > 0) {
      return SignatureValidationResult.expired("Request timestamp expired");
    }

    // 验证签名
    if (!MessageDigest.isEqual(
        expectedSignature.getBytes(StandardCharsets.UTF_8),
        signature.getBytes(StandardCharsets.UTF_8))) {
      return SignatureValidationResult.invalid("Invalid signature");
    }

    // 只登记已验真的请求，避免伪造签名抢占合法 nonce。
    if (!validateNonce(nonce)) {
      return SignatureValidationResult.rejected("Nonce already used");
    }

    return SignatureValidationResult.valid();
  }

  /** 计算请求签名 */
  public String computeSignature(
      String method, String path, String queryString, String timestamp, String nonce) {
    requireRequestTarget(method, path);
    requireNonce(nonce);
    String payload =
        method.toUpperCase(Locale.ROOT)
            + "\n"
            + path
            + "\n"
            + (queryString != null ? queryString : "")
            + "\n"
            + timestamp
            + "\n"
            + nonce;
    return hmacSha256Hex(payload, signingSecret);
  }

  public String computeSignature(
      String method, String path, String queryString, String timestamp, String nonce, byte[] body) {
    requireRequestTarget(method, path);
    requireNonce(nonce);
    Objects.requireNonNull(body, "body");
    String payload =
        method.toUpperCase(Locale.ROOT)
            + "\n"
            + path
            + "\n"
            + (queryString != null ? queryString : "")
            + "\n"
            + timestamp
            + "\n"
            + nonce
            + "\n"
            + sha256Hex(body);
    return hmacSha256Hex(payload, signingSecret);
  }

  private boolean hasRequestTarget(String method, String path) {
    return method != null && !method.isBlank() && path != null && !path.isBlank();
  }

  private void requireRequestTarget(String method, String path) {
    if (!hasRequestTarget(method, path)) {
      throw new IllegalArgumentException("method and path must not be blank");
    }
  }

  private void requireNonce(String nonce) {
    if (nonce == null || nonce.isBlank()) {
      throw new IllegalArgumentException("nonce must not be blank");
    }
  }

  /** 生成签名所需的请求头 */
  public SignatureHeaders generateSignatureHeaders(String method, String path, String queryString) {
    String timestamp = String.valueOf(clock.instant().getEpochSecond());
    String nonce = generateNonce();
    String signature = computeSignature(method, path, queryString, timestamp, nonce);
    return new SignatureHeaders(timestamp, nonce, signature);
  }

  private boolean validateNonce(String nonce) {
    if (nonce == null || nonce.isBlank()) {
      return false;
    }
    synchronized (nonceCache) {
      if (nonceCache.containsKey(nonce)) {
        return false;
      }
      // 检查缓存大小，如果超过限制则清理
      if (nonceCache.size() >= MAX_NONCE_CACHE_SIZE) {
        long cutoff = clock.millis() - SIGNATURE_TTL.toMillis() * 2;
        nonceCache.entrySet().removeIf(e -> e.getValue() < cutoff);
        // 如果清理后仍然超过限制，移除最旧的条目
        if (nonceCache.size() >= MAX_NONCE_CACHE_SIZE) {
          nonceCache.entrySet().stream()
              .sorted(Map.Entry.comparingByValue())
              .limit(nonceCache.size() - MAX_NONCE_CACHE_SIZE / 2)
              .map(Map.Entry::getKey)
              .toList()
              .forEach(nonceCache::remove);
        }
      }
      nonceCache.put(nonce, clock.millis());
      // 定期清理过期 nonce
      if (nonceCache.size() % 100 == 0) {
        long cutoff = clock.millis() - SIGNATURE_TTL.toMillis() * 2;
        nonceCache.entrySet().removeIf(e -> e.getValue() < cutoff);
      }
    }
    return true;
  }

  private void initializeApiKeyTable() {
    database.execute(
        """
        CREATE TABLE IF NOT EXISTS rest_api_keys (
            key_hash VARCHAR(64) PRIMARY KEY,
            player_id VARCHAR(36) NOT NULL,
            player_name VARCHAR(255),
            created_at VARCHAR(40) NOT NULL,
            expires_at VARCHAR(40) NOT NULL,
            permissions VARCHAR(512) NOT NULL
        )
        """);
  }

  private void persistApiKey(ApiKeyInfo info) {
    String permissions =
        info.permissions().stream()
            .map(ApiKeyPermission::name)
            .collect(java.util.stream.Collectors.joining(","));
    database.update(
        "INSERT INTO "
            + API_KEY_TABLE
            + " (key_hash, player_id, player_name, "
            + "created_at, expires_at, permissions) VALUES (?, ?, ?, ?, ?, ?)",
        hashKey(info.key()),
        info.playerId().toString(),
        info.playerName(),
        info.createdAt().toString(),
        info.expiresAt().toString(),
        permissions);
  }

  private ApiKeyInfo loadApiKey(String apiKey) {
    return database.query(
        "SELECT player_id, player_name, created_at, expires_at, permissions FROM "
            + API_KEY_TABLE
            + " WHERE key_hash = ?",
        rows -> {
          try {
            if (!rows.next()) {
              return null;
            }
            return new ApiKeyInfo(
                apiKey,
                UUID.fromString(rows.getString("player_id")),
                rows.getString("player_name"),
                Instant.parse(rows.getString("created_at")),
                Instant.parse(rows.getString("expires_at")),
                parsePermissions(rows.getString("permissions")));
          } catch (SQLException exception) {
            throw new InvalidApiKeyRecordException(exception);
          } catch (RuntimeException exception) {
            throw new InvalidApiKeyRecordException(exception);
          }
        },
        hashKey(apiKey));
  }

  private void logLoadFailure(String apiKey, RuntimeException failure) {
    String code =
        containsInvalidRecord(failure)
            ? "code=API_KEY_RECORD_INVALID"
            : "code=API_KEY_LOAD_FAILURE";
    String masked =
        apiKey != null && apiKey.length() > 8
            ? apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4)
            : "unknown";
    String message =
        "ApiAuthService " + code + " op=load apiKey=" + masked + " txId=" + txSeq.incrementAndGet();
    System.getLogger(ApiAuthService.class.getName())
        .log(System.Logger.Level.WARNING, message, failure);
  }

  private boolean containsInvalidRecord(Throwable failure) {
    for (Throwable current = failure; current != null; current = current.getCause()) {
      if (current instanceof InvalidApiKeyRecordException) {
        return true;
      }
    }
    return false;
  }

  private static final class InvalidApiKeyRecordException extends IllegalStateException {
    private InvalidApiKeyRecordException(Throwable cause) {
      super(API_KEY_RECORD_INVALID_CODE, cause);
    }
  }

  private java.util.List<ApiKeyPermission> parsePermissions(String stored) {
    if (stored == null || stored.isBlank()) {
      return java.util.List.of();
    }
    return java.util.Arrays.stream(stored.split(","))
        .filter(value -> !value.isBlank())
        .map(ApiKeyPermission::valueOf)
        .toList();
  }

  private String hashKey(String apiKey) {
    try {
      byte[] hash =
          MessageDigest.getInstance("SHA-256").digest(apiKey.getBytes(StandardCharsets.UTF_8));
      return toHex(hash);
    } catch (GeneralSecurityException exception) {
      throw new IllegalStateException("SHA-256 unavailable", exception);
    }
  }

  private String sha256Hex(byte[] value) {
    try {
      return toHex(MessageDigest.getInstance("SHA-256").digest(value));
    } catch (GeneralSecurityException exception) {
      throw new IllegalStateException("SHA-256 unavailable", exception);
    }
  }

  private String hmacSha256Hex(String value, String secret) {
    try {
      Mac mac = Mac.getInstance(SIGNATURE_ALGORITHM);
      mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), SIGNATURE_ALGORITHM));
      byte[] hash = mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
      return toHex(hash);
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException("HMAC-SHA256 unavailable", e);
    }
  }

  private String toHex(byte[] bytes) {
    StringBuilder builder = new StringBuilder(bytes.length * 2);
    for (byte value : bytes) {
      builder.append(String.format("%02x", value));
    }
    return builder.toString();
  }

  private String generateRandomKey() {
    return UUID.randomUUID().toString().replace("-", "")
        + UUID.randomUUID().toString().replace("-", "");
  }

  private String generateNonce() {
    return UUID.randomUUID().toString();
  }

  private String generateFallbackSecret() {
    return UUID.randomUUID().toString() + UUID.randomUUID().toString();
  }

  /** API Key 信息 */
  public record ApiKeyInfo(
      String key,
      UUID playerId,
      String playerName,
      Instant createdAt,
      Instant expiresAt,
      java.util.List<ApiKeyPermission> permissions) {
    public boolean hasPermission(ApiKeyPermission permission) {
      return permissions.contains(permission);
    }
  }

  /** API Key 权限 */
  public enum ApiKeyPermission {
    READ_NATIONS,
    WRITE_NATIONS,
    READ_PLAYERS,
    READ_TERRITORIES,
    READ_STATS,
    READ_FINANCE,
    WRITE_FINANCE,
    WRITE_MAP_MARKERS,
    ADMIN
  }

  /** 签名验证结果 */
  public record SignatureValidationResult(boolean isValid, String error) {
    public static SignatureValidationResult valid() {
      return new SignatureValidationResult(true, null);
    }

    public static SignatureValidationResult missing(String error) {
      return new SignatureValidationResult(false, error);
    }

    public static SignatureValidationResult invalid(String error) {
      return new SignatureValidationResult(false, error);
    }

    public static SignatureValidationResult expired(String error) {
      return new SignatureValidationResult(false, error);
    }

    public static SignatureValidationResult rejected(String error) {
      return new SignatureValidationResult(false, error);
    }
  }

  /** 签名请求头 */
  public record SignatureHeaders(String timestamp, String nonce, String signature) {}
}
