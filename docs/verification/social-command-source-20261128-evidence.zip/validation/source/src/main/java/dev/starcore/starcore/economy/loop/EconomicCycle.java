package dev.starcore.starcore.economy.loop;

import dev.starcore.starcore.economy.Currency;
import dev.starcore.starcore.economy.EconomyManager;
import dev.starcore.starcore.economy.ResourceType;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/** 经济周期系统 管理和预测经济的周期性波动 */
public class EconomicCycle {

  private final EconomyManager economyManager;
  private final MarketDynamics marketDynamics;
  private final InflationAdjuster inflationAdjuster;

  private final Map<EconomicPhase, PhaseData> phaseDataMap = new ConcurrentHashMap<>();
  private final List<Consumer<EconomicPhaseChangeEvent>> phaseChangeListeners = new ArrayList<>();

  private EconomicPhase currentPhase = EconomicPhase.EXPANSION;
  private long phaseStartTime = System.currentTimeMillis();
  private double cycleIntensity = 1.0;
  private double cycleSpeed = 1.0;

  // 周期参数
  private long expansionDuration = 30 * 60 * 1000; // 30分钟
  private long peakDuration = 10 * 60 * 1000; // 10分钟
  private long contractionDuration = 20 * 60 * 1000; // 20分钟
  private long troughDuration = 10 * 60 * 1000; // 10分钟

  public EconomicCycle(
      EconomyManager economyManager,
      MarketDynamics marketDynamics,
      InflationAdjuster inflationAdjuster) {
    this.economyManager = Objects.requireNonNull(economyManager);
    this.marketDynamics = Objects.requireNonNull(marketDynamics);
    this.inflationAdjuster = Objects.requireNonNull(inflationAdjuster);

    initializePhaseData();
  }

  /** 初始化阶段数据 */
  private void initializePhaseData() {
    for (EconomicPhase phase : EconomicPhase.values()) {
      phaseDataMap.put(phase, new PhaseData(phase));
    }
  }

  /** 更新经济周期 */
  public void updateCycle(long currentTime) {
    EconomicPhase nextPhase = determineNextPhase(currentTime);

    if (nextPhase != currentPhase) {
      transitionToPhase(nextPhase, currentTime);
    }

    // 更新当前阶段数据
    PhaseData currentData = phaseDataMap.get(currentPhase);
    if (currentData != null) {
      currentData.update(currentTime);
    }

    // 应用周期效应
    applyCycleEffects();
  }

  /** 确定下一个阶段 */
  private EconomicPhase determineNextPhase(long currentTime) {
    long phaseDuration = getCurrentPhaseDuration();
    long elapsed = currentTime - phaseStartTime;

    if (elapsed >= phaseDuration) {
      return getNextPhase(currentPhase);
    }

    return currentPhase;
  }

  /** 获取当前阶段的持续时间 */
  private long getCurrentPhaseDuration() {
    return switch (currentPhase) {
      case EXPANSION -> (long) (expansionDuration / cycleSpeed);
      case PEAK -> (long) (peakDuration / cycleSpeed);
      case CONTRACTION -> (long) (contractionDuration / cycleSpeed);
      case TROUGH -> (long) (troughDuration / cycleSpeed);
    };
  }

  /** 获取下一个阶段 */
  private EconomicPhase getNextPhase(EconomicPhase current) {
    return switch (current) {
      case EXPANSION -> EconomicPhase.PEAK;
      case PEAK -> EconomicPhase.CONTRACTION;
      case CONTRACTION -> EconomicPhase.TROUGH;
      case TROUGH -> EconomicPhase.EXPANSION;
    };
  }

  /** 过渡到新阶段 */
  private void transitionToPhase(EconomicPhase newPhase, long currentTime) {
    EconomicPhase oldPhase = this.currentPhase;
    this.currentPhase = newPhase;
    this.phaseStartTime = currentTime;

    // 记录阶段变化
    PhaseData oldData = phaseDataMap.get(oldPhase);
    if (oldData != null) {
      oldData.endPhase(currentTime);
    }

    PhaseData newData = phaseDataMap.get(newPhase);
    if (newData != null) {
      newData.startPhase(currentTime);
    }

    // 触发阶段变化事件
    EconomicPhaseChangeEvent event = new EconomicPhaseChangeEvent(oldPhase, newPhase, currentTime);

    notifyPhaseChangeListeners(event);
  }

  /** 应用周期效应 */
  private void applyCycleEffects() {
    double phaseMultiplier = getPhaseMultiplier();

    // 应用到市场动态
    for (ResourceType type : ResourceType.values()) {
      double currentMultiplier = marketDynamics.getPriceMultiplier(type);
      double newMultiplier = currentMultiplier * (1 + (phaseMultiplier - 1) * cycleIntensity);
      marketDynamics.setPriceMultiplier(type, newMultiplier);
    }

    // 应用到通胀调整
    for (Currency currency : Currency.values()) {
      double currentMultiplier = inflationAdjuster.getAdjustmentMultiplier(currency);
      double newMultiplier = currentMultiplier * (1 + (phaseMultiplier - 1) * cycleIntensity * 0.5);
      // 这里需要通过InflationAdjuster的方法来设置乘数
      // 由于InflationAdjuster的乘数是内部管理的，我们可能需要添加一个方法来调整它
    }
  }

  /** 获取当前阶段的乘数 */
  private double getPhaseMultiplier() {
    return switch (currentPhase) {
      case EXPANSION -> 1.15; // 扩张期：价格上涨
      case PEAK -> 1.30; // 顶峰期：价格最高
      case CONTRACTION -> 0.85; // 收缩期：价格下降
      case TROUGH -> 0.70; // 萧条期：价格最低
    };
  }

  /** 获取当前经济阶段 */
  public EconomicPhase getCurrentPhase() {
    return currentPhase;
  }

  /** 获取当前阶段的持续时间 */
  public long getPhaseDuration() {
    return getCurrentPhaseDuration();
  }

  /** 获取阶段开始时间 */
  public long getPhaseStartTime() {
    return phaseStartTime;
  }

  /** 获取阶段数据 */
  public PhaseData getPhaseData(EconomicPhase phase) {
    return phaseDataMap.get(phase);
  }

  /** 获取所有阶段数据 */
  public Collection<PhaseData> getAllPhaseData() {
    return phaseDataMap.values();
  }

  /** 设置周期强度 */
  public void setCycleIntensity(double intensity) {
    this.cycleIntensity = Math.max(0, Math.min(2.0, intensity));
  }

  /** 设置周期速度 */
  public void setCycleSpeed(double speed) {
    this.cycleSpeed = Math.max(0.1, Math.min(5.0, speed));
  }

  /** 设置扩张期持续时间 */
  public void setExpansionDuration(long duration) {
    this.expansionDuration = Math.max(1000, duration);
  }

  /** 设置顶峰期持续时间 */
  public void setPeakDuration(long duration) {
    this.peakDuration = Math.max(1000, duration);
  }

  /** 设置收缩期持续时间 */
  public void setContractionDuration(long duration) {
    this.contractionDuration = Math.max(1000, duration);
  }

  /** 设置萧条期持续时间 */
  public void setTroughDuration(long duration) {
    this.troughDuration = Math.max(1000, duration);
  }

  /** 注册阶段变化监听器 */
  public void addPhaseChangeListener(Consumer<EconomicPhaseChangeEvent> listener) {
    phaseChangeListeners.add(Objects.requireNonNull(listener));
  }

  /** 移除阶段变化监听器 */
  public void removePhaseChangeListener(Consumer<EconomicPhaseChangeEvent> listener) {
    phaseChangeListeners.remove(listener);
  }

  /** 通知所有阶段变化监听器 */
  private void notifyPhaseChangeListeners(EconomicPhaseChangeEvent event) {
    for (Consumer<EconomicPhaseChangeEvent> listener : phaseChangeListeners) {
      try {
        listener.accept(event);
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(EconomicCycle.class.getName())
            .warning("Error in phase change listener: " + e.getMessage());
      }
    }
  }

  /** 经济阶段 */
  public enum EconomicPhase {
    EXPANSION, // 扩张期
    PEAK, // 顶峰期
    CONTRACTION, // 收缩期
    TROUGH // 萧条期
  }

  /** 阶段数据 */
  public static class PhaseData {
    private final EconomicPhase phase;
    private long startTime = 0;
    private long endTime = 0;
    private long duration = 0;
    private int transitionCount = 0;

    public PhaseData(EconomicPhase phase) {
      this.phase = Objects.requireNonNull(phase);
    }

    public void startPhase(long time) {
      this.startTime = time;
      this.transitionCount++;
    }

    public void endPhase(long time) {
      this.endTime = time;
      this.duration = time - startTime;
    }

    public void update(long currentTime) {
      if (startTime > 0 && endTime == 0) {
        this.duration = currentTime - startTime;
      }
    }

    public EconomicPhase getPhase() {
      return phase;
    }

    public long getStartTime() {
      return startTime;
    }

    public long getEndTime() {
      return endTime;
    }

    public long getDuration() {
      return duration;
    }

    public int getTransitionCount() {
      return transitionCount;
    }
  }

  /** 经济阶段变化事件 */
  public static class EconomicPhaseChangeEvent {
    private final EconomicPhase oldPhase;
    private final EconomicPhase newPhase;
    private final long timestamp;

    public EconomicPhaseChangeEvent(
        EconomicPhase oldPhase, EconomicPhase newPhase, long timestamp) {
      this.oldPhase = Objects.requireNonNull(oldPhase);
      this.newPhase = Objects.requireNonNull(newPhase);
      this.timestamp = timestamp;
    }

    public EconomicPhase getOldPhase() {
      return oldPhase;
    }

    public EconomicPhase getNewPhase() {
      return newPhase;
    }

    public long getTimestamp() {
      return timestamp;
    }

    @Override
    public String toString() {
      return String.format(
          "EconomicPhaseChangeEvent{oldPhase=%s, newPhase=%s, timestamp=%d}",
          oldPhase, newPhase, timestamp);
    }
  }
}
