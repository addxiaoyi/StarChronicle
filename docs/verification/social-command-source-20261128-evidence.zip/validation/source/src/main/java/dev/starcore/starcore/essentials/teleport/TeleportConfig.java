package dev.starcore.starcore.essentials.teleport;

import java.time.Duration;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

/** 传送系统配置 */
public record TeleportConfig(
    Location spawnLocation,
    Duration spawnCooldown,
    Duration homeCooldown,
    Duration warpCooldown,
    Duration tpaCooldown,
    Duration backCooldown,
    int maxHomes,
    boolean cancelOnMove,
    boolean cancelOnDamage) {
  public static TeleportConfig defaults() {
    return new TeleportConfig(
        null, // 需要设置
        Duration.ofSeconds(3), // spawn 冷却
        Duration.ofSeconds(3), // home 冷却
        Duration.ofSeconds(3), // warp 冷却
        Duration.ofSeconds(5), // tpa 冷却
        Duration.ofSeconds(3), // back 冷却
        5, // 最多5个家
        true, // 移动取消
        true // 受伤取消
        );
  }

  /** Loads the supported Essentials teleport settings from the main config. */
  public static TeleportConfig from(FileConfiguration config) {
    TeleportConfig defaults = defaults();
    if (config == null) {
      return defaults;
    }

    return new TeleportConfig(
        defaults.spawnLocation(),
        seconds(config, "essentials.teleport.spawn-delay-seconds", defaults.spawnDelay()),
        seconds(config, "essentials.teleport.home-delay-seconds", defaults.homeDelay()),
        seconds(config, "essentials.teleport.warp-delay-seconds", defaults.warpDelay()),
        seconds(config, "essentials.teleport.tpa-delay-seconds", defaults.tpaDelay()),
        seconds(config, "essentials.teleport.back-delay-seconds", defaults.backDelay()),
        Math.clamp(config.getInt("essentials.home.max-homes", defaults.maxHomes()), 1, 100),
        config.getBoolean("essentials.teleport.cancel-on-move", defaults.cancelOnMove()),
        config.getBoolean("essentials.teleport.cancel-on-damage", defaults.cancelOnDamage()));
  }

  private static Duration seconds(FileConfiguration config, String path, long fallback) {
    return Duration.ofSeconds(Math.clamp(config.getLong(path, fallback), 0L, 3600L));
  }

  /** 获取spawn传送延迟（秒） */
  public long spawnDelay() {
    return spawnCooldown.getSeconds();
  }

  /** 获取home传送延迟（秒） */
  public long homeDelay() {
    return homeCooldown.getSeconds();
  }

  /** 获取warp传送延迟（秒） */
  public long warpDelay() {
    return warpCooldown.getSeconds();
  }

  /** 获取tpa传送延迟（秒） */
  public long tpaDelay() {
    return tpaCooldown.getSeconds();
  }

  /** 获取back传送延迟（秒） */
  public long backDelay() {
    return backCooldown.getSeconds();
  }
}
