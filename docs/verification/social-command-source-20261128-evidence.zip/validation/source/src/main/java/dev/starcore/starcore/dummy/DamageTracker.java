package dev.starcore.starcore.dummy;

/** 单玩家伤害统计累加器 记录总伤害、命中数、暴击数、最大单次伤害与时间窗口，用于计算 DPS */
public final class DamageTracker {

  private double totalDamage;
  private int hitCount;
  private int critCount;
  private double maxHit;
  private long firstHitTime;
  private long lastHitTime;

  /** 记录一次命中 */
  public void record(double damage, boolean crit) {
    long now = System.currentTimeMillis();
    if (hitCount == 0) {
      firstHitTime = now;
    }

    lastHitTime = now;
    totalDamage += damage;
    hitCount++;
    if (crit) {
      critCount++;
    }
    if (damage > maxHit) {
      maxHit = damage;
    }
  }

  public double getTotalDamage() {
    return totalDamage;
  }

  public int getHitCount() {
    return hitCount;
  }

  public int getCritCount() {
    return critCount;
  }

  public double getMaxHit() {
    return maxHit;
  }

  public long getFirstHitTime() {
    return firstHitTime;
  }

  public long getLastHitTime() {
    return lastHitTime;
  }

  public boolean isEmpty() {
    return hitCount == 0;
  }

  public double getAverageDamage() {
    return hitCount > 0 ? totalDamage / hitCount : 0;
  }

  public double getCritRate() {
    return hitCount > 0 ? (critCount * 100.0) / hitCount : 0;
  }

  /** 单次命中视为 1 秒窗口，避免除零 */
  private static long window(long elapsed) {
    return elapsed > 0 ? elapsed : 1000L;
  }

  /** 以最后一次命中为终点的 DPS */
  public double getDps() {
    if (hitCount == 0) {
      return 0;
    }
    return totalDamage / (window(lastHitTime - firstHitTime) / 1000.0);
  }

  /** 以给定时间戳为终点的实时 DPS（用于 HUD 持续刷新） */
  public double getDps(long now) {
    if (hitCount == 0) {
      return 0;
    }
    return totalDamage / (window(now - firstHitTime) / 1000.0);
  }

  /** 统计窗口时长（毫秒） */
  public long getDurationMillis(long now) {
    return hitCount == 0 ? 0 : now - firstHitTime;
  }

  public void reset() {
    totalDamage = 0;
    hitCount = 0;
    critCount = 0;
    maxHit = 0;
    firstHitTime = 0;
    lastHitTime = 0;
  }
}
