package dev.starcore.starcore.achievement;

import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.NamespacedKey;

/** 成就进度追踪器 追踪玩家对每个成就的完成进度 */
public final class AchievementProgress {
  private final UUID playerId;

  // 已完成的成就
  private final Set<NamespacedKey> completedAchievements = ConcurrentHashMap.newKeySet();
  private final Set<NamespacedKey> pendingRewards = ConcurrentHashMap.newKeySet();
  private final Set<String> deliveredRewards = ConcurrentHashMap.newKeySet();

  // 进行中的成就及其进度
  private final Map<NamespacedKey, ProgressData> inProgressAchievements = new ConcurrentHashMap<>();

  // 每个触发类型的当前计数
  private final Map<String, Integer> triggerCounts = new ConcurrentHashMap<>();

  public AchievementProgress(UUID playerId) {
    this.playerId = java.util.Objects.requireNonNull(playerId, "playerId");
  }

  public UUID getPlayerId() {
    return playerId;
  }

  /** 检查成就是否已完成 */
  public boolean isCompleted(NamespacedKey key) {
    return completedAchievements.contains(key);
  }

  /** 标记成就为完成 */
  public void markCompleted(NamespacedKey key) {
    markCompletedIfAbsent(key);
  }

  /** Atomically marks an achievement completed and reports whether this call won the race. */
  public boolean markCompletedIfAbsent(NamespacedKey key) {
    if (key == null || !completedAchievements.add(key)) {
      return false;
    }
    inProgressAchievements.remove(key);
    return true;
  }

  public boolean isRewardPending(NamespacedKey key) {
    return key != null && pendingRewards.contains(key);
  }

  public void markRewardPending(NamespacedKey key) {
    if (key != null) pendingRewards.add(key);
  }

  public void clearRewardPending(NamespacedKey key) {
    if (key != null) pendingRewards.remove(key);
  }

  public Set<NamespacedKey> getPendingRewards() {
    return Collections.unmodifiableSet(pendingRewards);
  }

  public boolean isRewardDelivered(NamespacedKey key, int rewardIndex) {
    return key != null && deliveredRewards.contains(rewardToken(key, rewardIndex));
  }

  public void markRewardDelivered(NamespacedKey key, int rewardIndex) {
    if (key != null && rewardIndex >= 0) deliveredRewards.add(rewardToken(key, rewardIndex));
  }

  public Set<String> getDeliveredRewards() {
    return Collections.unmodifiableSet(deliveredRewards);
  }

  public void markDeliveredRewardToken(String token) {
    if (token != null && !token.isBlank()) deliveredRewards.add(token);
  }

  private static String rewardToken(NamespacedKey key, int rewardIndex) {
    return key + "#" + rewardIndex;
  }

  /** 获取已完成的成就集合 */
  public Set<NamespacedKey> getCompletedAchievements() {
    return Collections.unmodifiableSet(completedAchievements);
  }

  /** 增加触发器计数 */
  public int incrementTriggerCount(String triggerKey) {
    return incrementTriggerCount(triggerKey, 1);
  }

  /** 增加触发器计数 */
  public int incrementTriggerCount(String triggerKey, int amount) {
    if (triggerKey == null || triggerKey.isBlank() || amount <= 0) {
      return triggerKey == null ? 0 : triggerCounts.getOrDefault(triggerKey, 0);
    }
    return triggerCounts.merge(
        triggerKey,
        amount,
        (current, delta) -> {
          long next = (long) current + delta;
          return (int) Math.min(Integer.MAX_VALUE, next);
        });
  }

  /** 获取触发器计数 */
  public int getTriggerCount(String triggerKey) {
    return triggerCounts.getOrDefault(triggerKey, 0);
  }

  /** 设置触发器计数 */
  public void setTriggerCount(String triggerKey, int count) {
    if (triggerKey == null || triggerKey.isBlank() || count < 0) {
      return;
    }
    triggerCounts.put(triggerKey, count);
  }

  /** 获取所有触发器计数 */
  public Map<String, Integer> getAllTriggerCounts() {
    return Map.copyOf(triggerCounts);
  }

  /** 更新成就进度 */
  public void updateProgress(NamespacedKey achievementKey, int current, int target) {
    inProgressAchievements.put(
        achievementKey, new ProgressData(current, target, System.currentTimeMillis()));
  }

  /** 获取成就进度 */
  public Optional<ProgressData> getProgress(NamespacedKey achievementKey) {
    return Optional.ofNullable(inProgressAchievements.get(achievementKey));
  }

  /** 获取进行中的成就 */
  public Collection<ProgressData> getInProgressAchievements() {
    return List.copyOf(inProgressAchievements.values());
  }

  /** 检查父成就是否完成 */
  public boolean isParentCompleted(NamespacedKey parentKey) {
    if (parentKey == null) {
      return true;
    }
    return completedAchievements.contains(parentKey);
  }

  /** 获取完成进度百分比 */
  public double getCompletionPercentage() {
    int trackedCount = completedAchievements.size() + inProgressAchievements.size();
    if (trackedCount == 0) {
      return 0.0;
    }
    double completedTotal = completedAchievements.size() * 100.0;
    double inProgressTotal =
        inProgressAchievements.values().stream().mapToDouble(ProgressData::getPercentage).sum();
    return Math.min(100.0, (completedTotal + inProgressTotal) / trackedCount);
  }

  /** 序列化数据 */
  public Map<String, Object> serialize() {
    Map<String, Object> data = new HashMap<>();
    data.put("playerId", playerId.toString());
    data.put(
        "completed",
        new ArrayList<>(completedAchievements.stream().map(Object::toString).toList()));
    data.put(
        "pendingRewards", new ArrayList<>(pendingRewards.stream().map(Object::toString).toList()));
    data.put("deliveredRewards", new ArrayList<>(deliveredRewards));
    data.put("triggerCounts", new HashMap<>(triggerCounts));
    return data;
  }

  /** 反序列化数据 */
  public static AchievementProgress deserialize(UUID playerId, Map<String, Object> data) {
    AchievementProgress progress = new AchievementProgress(playerId);
    if (data == null) {
      return progress;
    }

    Object completedValue = data.get("completed");
    if (completedValue instanceof Iterable<?> completed) {
      for (Object rawKey : completed) {
        if (!(rawKey instanceof String key)) {
          continue;
        }
        String[] parts = key.split(":", 2);
        if (parts.length != 2 || parts[0].isBlank() || parts[1].isBlank()) {
          continue;
        }
        try {
          progress.completedAchievements.add(new NamespacedKey(parts[0], parts[1]));
        } catch (IllegalArgumentException ignored) {
          // Ignore corrupt persisted keys and preserve the rest of the player's progress.
        }
      }
    }

    Object pendingValue = data.get("pendingRewards");
    if (pendingValue instanceof Iterable<?> pending) {
      for (Object rawKey : pending) {
        if (rawKey instanceof String key) {
          String[] parts = key.split(":", 2);
          if (parts.length == 2 && !parts[0].isBlank() && !parts[1].isBlank()) {
            try {
              progress.pendingRewards.add(new NamespacedKey(parts[0], parts[1]));
            } catch (IllegalArgumentException ignored) {
              // Ignore corrupt reward ledger entries.
            }
          }
        }
      }
    }

    Object deliveredValue = data.get("deliveredRewards");
    if (deliveredValue instanceof Iterable<?> delivered) {
      for (Object rawToken : delivered) {
        if (rawToken instanceof String token && !token.isBlank()) {
          progress.deliveredRewards.add(token);
        }
      }
    }

    Object countsValue = data.get("triggerCounts");
    if (countsValue instanceof Map<?, ?> counts) {
      for (Map.Entry<?, ?> entry : counts.entrySet()) {
        if (!(entry.getKey() instanceof String key)) {
          continue;
        }
        Integer count = parseCount(entry.getValue());
        if (count != null && count >= 0) {
          progress.triggerCounts.putIfAbsent(key, count);
        }
      }
    }

    return progress;
  }

  private static Integer parseCount(Object value) {
    if (value instanceof Number number) {
      double decimal = number.doubleValue();
      if (Double.isFinite(decimal)
          && decimal == Math.rint(decimal)
          && decimal >= Integer.MIN_VALUE
          && decimal <= Integer.MAX_VALUE) {
        return number.intValue();
      }
      return null;
    }
    if (value instanceof String text) {
      try {
        return Integer.valueOf(text);
      } catch (NumberFormatException ignored) {
        return null;
      }
    }
    return null;
  }

  public record ProgressData(int current, int target, long lastUpdated) {
    public double getPercentage() {
      if (target <= 0) return 0;
      return Math.min(100.0, (current * 100.0) / target);
    }

    public boolean isComplete() {
      return current >= target;
    }

    public ProgressData withIncrementedCurrent() {
      return new ProgressData(current + 1, target, System.currentTimeMillis());
    }
  }
}
