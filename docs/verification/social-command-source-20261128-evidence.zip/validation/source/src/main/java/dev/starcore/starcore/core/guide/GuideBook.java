package dev.starcore.starcore.core.guide;

import dev.starcore.starcore.foundation.gui.GuiText;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GuideBook {
  public static final String GUIDE_BOOK_KEY = "starcore_guide_book";

  private GuideBook() {}

  public static ItemStack createGuideBook() {
    return createGuideBook(null);
  }

  public static ItemStack createGuideBook(Player player) {
    ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
    ItemMeta meta = book.getItemMeta();
    Component title =
        Component.text(
                GuiText.get(player, "guide.book_title", "STARCORE Guide"), NamedTextColor.GOLD)
            .decorate(TextDecoration.BOLD)
            .decoration(TextDecoration.ITALIC, false);
    meta.displayName(title);
    List<Component> lore =
        List.of(
            Component.text("§7§m-------------------"),
            Component.text(GuiText.get(player, "guide.book_header", "STARCORE Guide")),
            Component.empty(),
            Component.text(GuiText.get(player, "guide.book_open", "Right-click to open the main guide")),
            Component.text(GuiText.get(player, "guide.book_systems", "Learn the core systems")),
            Component.text(GuiText.get(player, "guide.book_learn", "Explore every feature step by step")),
            Component.empty(),
            Component.text(GuiText.get(player, "guide.book_item", "[Guide Item]")),
            Component.text("§7§m-------------------"));
    meta.lore(lore.stream().map(line -> line.decoration(TextDecoration.ITALIC, false)).toList());
    meta.setEnchantmentGlintOverride(true);
    meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
    meta.getPersistentDataContainer()
        .set(new org.bukkit.NamespacedKey("starcore", GUIDE_BOOK_KEY), PersistentDataType.BOOLEAN, true);
    book.setItemMeta(meta);
    return book;
  }

  public static boolean isGuideBook(ItemStack item) {
    if (item == null || item.getType() != Material.WRITTEN_BOOK || !item.hasItemMeta()) return false;
    return Boolean.TRUE.equals(
        item.getItemMeta().getPersistentDataContainer()
            .get(new org.bukkit.NamespacedKey("starcore", GUIDE_BOOK_KEY), PersistentDataType.BOOLEAN));
  }
}
