package dev.starcore.starcore.boss;

/** Boss状态枚举 定义Boss实例的生命周期状态 */
public enum BossStatus {
  /** 待机：Boss等待出现，等待触发条件 */
  standby("待机", "等待触发条件"),

  /** 出现：Boss已出现，玩家可与之交互 */
  spawned("出现", "玩家可交互"),

  /** 进行中：Boss正在战斗或行为检查 */
  in_progress("进行中", "正在进行中"),

  /** 已击败：Boss被击败，掉落证据 */
  defeated("已击败", "获得证据"),

  /** 失败：玩家失败，Boss继续存在 */
  failed("失败", "玩家失败"),

  /** 已归档：Boss结果已写入正史 */
  archived("已归档", "结果归档"),

  /** 已取消：Boss战斗被取消 */
  cancelled("已取消", "战斗取消");

  private final String displayName;
  private final String description;

  BossStatus(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 检查是否为激活状态 */
  public boolean isActive() {
    return this == spawned || this == in_progress;
  }

  /** 检查是否为终止状态 */
  public boolean isTerminal() {
    return this == defeated || this == failed || this == archived || this == cancelled;
  }
}
