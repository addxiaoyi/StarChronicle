package dev.starcore.starcore.foundation.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import dev.starcore.starcore.module.government.gui.GovernmentMenu;
import dev.starcore.starcore.foundation.gui.StarCoreMenuHolder;

public final class GuiHubNavigationListener implements Listener {
  private final Plugin plugin;

  public GuiHubNavigationListener(Plugin plugin) {
    this.plugin = plugin;
  }

  @EventHandler
  public void onOpen(InventoryOpenEvent event) {
    Inventory top = event.getView().getTopInventory();
    InventoryHolder holder = top.getHolder();
    if (holder == null
        || !holder.getClass().getPackageName().startsWith("dev.starcore.starcore")
        || holder instanceof NavigationHubMenu) {
      return;
    }

    boolean hasHubButton = false;
    for (int slot = 0; slot < top.getSize(); slot++) {
      ItemStack item = top.getItem(slot);
      if (ButtonFactory.isHubButton(item, plugin)) {
        hasHubButton = true;
        continue;
      }
      VisualComponent.normalize(item);
    }
    if (hasHubButton || top.getSize() < 9) return;

    for (int slot : navigationSlots(top.getSize())) {
      if (top.getItem(slot) == null || isBlankPane(top.getItem(slot))) {
        top.setItem(
            slot,
            event.getPlayer() instanceof Player player
                ? ButtonFactory.createHubButton(player)
                : ButtonFactory.createHubButton());
        return;
      }
    }
  }

  private static int[] navigationSlots(int size) {
    int lastRow = size - 9;
    return new int[] {
      Math.min(52, size - 1), Math.min(51, size - 1), 0, 8, 1, 7, 2, 6,
      lastRow, lastRow + 1, lastRow + 2, lastRow + 3, lastRow + 4,
      lastRow + 5, lastRow + 6, lastRow + 7, lastRow + 8
    };
  }

  private static boolean isBlankPane(ItemStack item) {
    if (item == null
        || (item.getType() != Material.GLASS_PANE
            && !item.getType().name().endsWith("_STAINED_GLASS_PANE"))
        || !item.hasItemMeta()) {
      return false;
    }
    var meta = item.getItemMeta();
    String name =
        meta.displayName() == null
            ? ""
            : net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(meta.displayName());
    return name.isBlank() && (meta.lore() == null || meta.lore().isEmpty());
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void onDrag(InventoryDragEvent event) {
    if (isStarCoreInventory(event.getView().getTopInventory())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void onClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    Inventory top = event.getView().getTopInventory();
    if (isStarCoreInventory(top)) {
      event.setCancelled(true);
    }
    if (event.getClickedInventory() != top) return;
    if (event.getView().getTopInventory().getHolder() instanceof GovernmentMenu governmentMenu) {
      event.setCancelled(true);
      if (event.getRawSlot() == 18) {
        NavigationHubMenu.openHub(plugin, player);
      } else if (event.getRawSlot() == 22) {
        player.closeInventory();
      } else {
        governmentMenu.handleClick(player, event.getRawSlot(), event.getCurrentItem());
      }
      return;
    }
    if (!ButtonFactory.isHubButton(event.getCurrentItem(), plugin)) return;
    event.setCancelled(true);
    NavigationHubMenu.openHub(plugin, player);
  }

  private boolean isStarCoreInventory(Inventory inventory) {
    if (inventory == null) return false;
    if (inventory.getHolder() instanceof StarCoreMenuHolder) return true;
    if (inventory.getHolder() == null) return false;
    String packageName = inventory.getHolder().getClass().getPackageName();
    return packageName.startsWith("dev.starcore.starcore");
  }
}
