package dev.starcore.starcore.event.random.trigger;

import dev.starcore.starcore.event.random.EventTrigger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/** 玩家数量触发器 根据在线玩家数量触发事件 */
public class PlayerCountTrigger implements EventTrigger {

  private final int minPlayers;
  private final int maxPlayers;
  private final CountType countType;
  private final String worldName;
  private final double radius;

  /**
   * 创建玩家数量触发器
   *
   * @param minPlayers 最少玩家数
   * @param maxPlayers 最多玩家数
   * @param countType 计数类型
   * @param worldName 世界名称（仅用于WORLD类型）
   * @param radius 半径（仅用于NEARBY类型）
   */
  public PlayerCountTrigger(
      int minPlayers, int maxPlayers, CountType countType, String worldName, double radius) {
    this.minPlayers = minPlayers;
    this.maxPlayers = maxPlayers;
    this.countType = countType;
    this.worldName = worldName;
    this.radius = radius;
  }

  @Override
  public boolean check(Player player, Location location) {
    int playerCount;

    switch (countType) {
      case GLOBAL:
        // 全局在线玩家数
        playerCount = Bukkit.getOnlinePlayers().size();
        break;

      case WORLD:
        // 指定世界的玩家数
        if (worldName == null || Bukkit.getWorld(worldName) == null) {
          return false;
        }
        playerCount =
            (int)
                Bukkit.getOnlinePlayers().stream()
                    .filter(p -> p.getWorld().getName().equals(worldName))
                    .count();
        break;

      case NEARBY:
        // 附近玩家数
        Location checkLocation =
            location != null ? location : (player != null ? player.getLocation() : null);
        if (checkLocation == null) {
          return false;
        }

        // 关键优化：distance() → distanceSquared() 避免 sqrt
        double radiusSq = radius * radius;
        org.bukkit.World checkWorld = checkLocation.getWorld();
        playerCount =
            (int)
                Bukkit.getOnlinePlayers().stream()
                    .filter(p -> p.getWorld().equals(checkWorld))
                    .filter(p -> p.getLocation().distanceSquared(checkLocation) <= radiusSq)
                    .count();
        break;

      default:
        return false;
    }

    return playerCount >= minPlayers && playerCount <= maxPlayers;
  }

  @Override
  public String getType() {
    return "PLAYER_COUNT";
  }

  @Override
  public java.util.concurrent.CompletableFuture<Boolean> checkAsync(
      Player player,
      Location location,
      dev.starcore.starcore.event.random.RandomEventRuntime runtime) {
    if (countType == CountType.GLOBAL)
      return runtime.global(() -> inRange(Bukkit.getOnlinePlayers().size()));
    if (countType == CountType.WORLD && worldName == null)
      return java.util.concurrent.CompletableFuture.completedFuture(false);
    if (countType == CountType.NEARBY && (!Double.isFinite(radius) || radius < 0))
      return java.util.concurrent.CompletableFuture.completedFuture(false);
    java.util.concurrent.CompletableFuture<Location> center =
        countType == CountType.NEARBY
            ? runtime.location(player, location)
            : java.util.concurrent.CompletableFuture.completedFuture(null);
    return center.thenCompose(
        origin ->
            runtime
                .global(
                    () -> {
                      if (countType == CountType.WORLD && Bukkit.getWorld(worldName) == null)
                        return null;
                      if (countType == CountType.NEARBY
                          && (origin == null || origin.getWorld() == null)) return null;
                      return java.util.List.copyOf(Bukkit.getOnlinePlayers());
                    })
                .thenCompose(
                    players -> {
                      if (players == null)
                        return java.util.concurrent.CompletableFuture.completedFuture(false);
                      var count = java.util.concurrent.CompletableFuture.completedFuture(0);
                      for (Player candidate : players) {
                        count =
                            count.thenCompose(
                                total ->
                                    runtime
                                        .player(
                                            candidate,
                                            () -> {
                                              boolean matches =
                                                  countType == CountType.WORLD
                                                      ? candidate
                                                          .getWorld()
                                                          .getName()
                                                          .equals(worldName)
                                                      : origin != null
                                                          && origin.getWorld() != null
                                                          && candidate.getWorld()
                                                              == origin.getWorld()
                                                          && candidate
                                                                  .getLocation()
                                                                  .distanceSquared(origin)
                                                              <= radius * radius;
                                              return matches ? total + 1 : total;
                                            })
                                        .exceptionally(
                                            failure -> {
                                              if (!dev.starcore.starcore.event.random
                                                  .RandomEventRuntime.cancelled(failure))
                                                throw new java.util.concurrent.CompletionException(
                                                    failure);
                                              return total;
                                            }));
                      }
                      return count.thenApply(this::inRange);
                    }));
  }

  private boolean inRange(int count) {
    return count >= minPlayers && count <= maxPlayers;
  }

  @Override
  public String getDescription() {
    return String.format("玩家数量触发器 [类型=%s, 范围=%d-%d]", countType, minPlayers, maxPlayers);
  }

  public enum CountType {
    GLOBAL, // 全局
    WORLD, // 指定世界
    NEARBY // 附近区域
  }
}
