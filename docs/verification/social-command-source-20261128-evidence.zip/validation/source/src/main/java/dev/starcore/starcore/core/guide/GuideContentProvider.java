package dev.starcore.starcore.core.guide;

import java.util.*;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

public final class GuideContentProvider {

  private static final Map<GuideChapter, List<GuideItem>> items = new EnumMap<>(GuideChapter.class);

  static {
    initializeContent();
  }

  private GuideContentProvider() {}

  public static List<GuideItem> getItems(GuideChapter chapter) {
    return items.getOrDefault(chapter, Collections.emptyList());
  }

  public static int getItemCount(GuideChapter chapter) {
    return getItems(chapter).size();
  }

  public static GuideItem getItem(GuideChapter chapter, String itemId) {
    return getItems(chapter).stream()
        .filter(item -> item.id().equals(itemId))
        .findFirst()
        .orElse(null);
  }

  public static List<GuideChapter> getAllChapters() {
    return Arrays.asList(GuideChapter.values());
  }

  private static void initializeContent() {
    items.put(
        GuideChapter.GETTING_STARTED,
        List.of(
            new GuideItem(
                "welcome",
                "欢迎来到 STARCORE",
                Material.GOLDEN_APPLE,
                "§e§l欢迎来到 STARCORE 服务器！",
                List.of("§7本游戏是一款国家建设模拟游戏", "§7你可以创建或加入国家", "§7管理经济军事与外交战争", "§7研究科技、探索世界"),
                List.of(),
                ItemTier.FOUNDATIONAL),
            new GuideItem(
                "basic_commands",
                "快速入口",
                Material.COMMAND_BLOCK,
                "§6§l从这里开始操作",
                List.of(
                    "§7点击下方入口，直接打开国家、任务或商店功能", "§7指南会为你调用正确入口，不需要记忆命令", "§7遇到权限或条件不足时，系统会明确告诉你原因"),
                List.of("welcome"),
                ItemTier.FOUNDATIONAL),
            new GuideItem(
                "first_steps",
                "新手引导",
                Material.IRON_BOOTS,
                "§a§l迈出第一步",
                List.of(
                    "§71. 从指南打开国家入口", "§72. 选择创建国家或加入现有国家", "§73. 按界面提示填写信息并确认", "§74. 返回指南继续下一步"),
                List.of("basic_commands"),
                ItemTier.FOUNDATIONAL)));
    items.put(
        GuideChapter.NATION_BUILDING,
        List.of(
            new GuideItem(
                "create_nation",
                "创建国家",
                Material.COBBLESTONE,
                "§6§l创建新国家",
                List.of(
                    "§71. 点击下方入口打开国家管理",
                    "§72. 选择创建国家",
                    "§73. 输入国家名称并选择政体",
                    "§74. 确认费用后完成创建",
                    "§c注意: 每个玩家只能创建一个国家！"),
                List.of("first_steps"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "nation_governance",
                "国家政体",
                Material.WHITE_BANNER,
                "§6§l政体类型影响国家发展",
                List.of(
                    "§a民主制 §7- 成员可提出决议",
                    "§c集权制 §7- 领导者拥有绝对权力",
                    "§e议会制 §7- 议会共同决策",
                    "§7不同政体有不同的加成和限制"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "territory",
                "领土扩张",
                Material.DIAMOND_BLOCK,
                "§6§l购买和管理领土",
                List.of(
                    "§71. 确保你是国家管理员",
                    "§72. 点击下方入口打开领土管理",
                    "§73. 选择当前区块并确认购买",
                    "§74. 支付购买费用",
                    "§c保护新购买的领土免受侵犯！"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "members",
                "成员管理",
                Material.PLAYER_HEAD,
                "§6§l邀请和管理国家成员",
                List.of("§7• 邀请玩家加入国家", "§7• 设置成员权限等级", "§7• 分配职位和责任", "§7• 管理成员贡献度"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE)));
    items.put(
        GuideChapter.ECONOMY_SYSTEM,
        List.of(
            new GuideItem(
                "taxation",
                "税收系统",
                Material.GOLD_INGOT,
                "§6§l国家税收管理",
                List.of(
                    "§7管理员可以设置税率 (0%-50%)",
                    "§a  • 低税率: 吸引更多成员", "§c  • 高税率: 增加国库收入", "§e点击国家菜单中的税率调整来设置"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "treasury",
                "国库管理",
                Material.CHEST,
                "§6§l国库功能",
                List.of("§a  • 接收税收收入", "§a  • 支付军饷和费用", "§a  • 购买领土和科技", "§7确保国库有足够余额维持国家运转！"),
                List.of("taxation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "trade",
                "贸易系统",
                Material.EMERALD,
                "§6§l国家间贸易",
                List.of("§7• 与其他国家签订贸易协定", "§7• 进出口资源和商品", "§7• 利用市场波动获利", "§7• 贸易需要外交官处理"),
                List.of("treasury"),
                ItemTier.ADVANCED)));
    items.put(
        GuideChapter.MILITARY_SYSTEM,
        List.of(
            new GuideItem(
                "army",
                "军队组建",
                Material.IRON_SWORD,
                "§6§l组建和指挥军队",
                List.of("§7每个国家可以组建多支军队:", "§a  • 陆军 - 进攻和防御", "§b  • 海军 - 控制海域", "§7军队需要足够的资金和资源"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "warfare",
                "发动战争",
                Material.TNT,
                "§6§l宣战与作战",
                List.of(
                    "§71. 点击下方入口打开战争系统",
                    "§72. 选择宣战目标",
                    "§73. 确认宣战",
                    "§c注意: 战争会消耗大量资源！",
                    "§c战败可能导致领土丢失！"),
                List.of("army"),
                ItemTier.ADVANCED),
            new GuideItem(
                "defense",
                "防御工事",
                Material.OBSIDIAN,
                "§6§l建造防御设施",
                List.of("§7• 建造城墙和堡垒", "§7• 设置陷阱和预警系统", "§7• 训练守卫NPC", "§7• 部署防御工事"),
                List.of("army"),
                ItemTier.INTERMEDIATE)));
    items.put(
        GuideChapter.DIPLOMACY,
        List.of(
            new GuideItem(
                "diplomacy",
                "外交关系",
                Material.PAPER,
                "§6§l外交关系类型",
                List.of("§a同盟 §7- 共同防御和进攻", "§e友好 §7- 减少敌对行为", "§c敌对 §7- 准备战争状态", "§7外交关系影响贸易和军事"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "treaties",
                "条约系统",
                Material.WRITABLE_BOOK,
                "§6§l签订条约",
                List.of("§7• 贸易条约 - 降低关税", "§7• 军事条约 - 互助防御", "§7• 文化条约 - 交流加成", "§7• 条约需要双方同意"),
                List.of("diplomacy"),
                ItemTier.ADVANCED)));
    items.put(
        GuideChapter.TECHNOLOGY,
        List.of(
            new GuideItem(
                "tech_tree",
                "科技树",
                Material.CRAFTING_TABLE,
                "§6§l科技研究体系",
                List.of(
                    "§7科技系统分为多个时代:",
                    "§a  • 古代 - 基础科技",
                    "§e  • 中世纪 - 军事和经济",
                    "§c  • 近代 - 工业和政治",
                    "§7研究科技需要科技点和资源"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "research",
                "研究流程",
                Material.EXPERIENCE_BOTTLE,
                "§6§l如何研究科技",
                List.of(
                    "§71. 点击下方入口打开科技研究",
                    "§72. 选择要研究的科技分支",
                    "§73. 投入科技点和资源",
                    "§74. 等待研究完成",
                    "§7某些科技需要前置科技"),
                List.of("tech_tree"),
                ItemTier.INTERMEDIATE)));
    items.put(
        GuideChapter.SOCIAL_LIFE,
        List.of(
            new GuideItem(
                "guild",
                "公会系统",
                Material.NAME_TAG,
                "§6§l加入公会",
                List.of(
                    "§7点击下方入口打开公会系统:", "§a  • 组队副本", "§a  • 公会战争", "§a  • 公会任务", "§7所有操作都从打开的界面完成"),
                List.of("welcome"),
                ItemTier.FOUNDATIONAL),
            new GuideItem(
                "friends",
                "好友系统",
                Material.PLAYER_HEAD,
                "§6§l添加和管理好友",
                List.of("§7• 从下方入口打开好友系统并选择玩家", "§7• 查看好友在线状态", "§7• 好友组队获得加成", "§7• 好友间快捷传送"),
                List.of("welcome"),
                ItemTier.FOUNDATIONAL),
            new GuideItem(
                "chat",
                "聊天系统",
                Material.NAME_TAG,
                "§6§l聊天频道",
                List.of(
                    "§7• 世界频道 - 全服聊天",
                    "§7• 国家频道 - 国内交流",
                    "§7• 公会频道 - 公会内部",
                    "§7• 私聊 - 1对1对话",
                    "§7从社交面板选择频道"),
                List.of("friends"),
                ItemTier.FOUNDATIONAL)));
    items.put(
        GuideChapter.SPECIAL_FEATURES,
        List.of(
            new GuideItem(
                "events",
                "随机事件",
                Material.DISPENSER,
                "§6§l游戏中的随机事件",
                List.of(
                    "§7游戏中会发生各种随机事件:",
                    "§a  • 丰收 - 国家获得额外资源",
                    "§c  • 灾害 - 国家遭受损失",
                    "§e  • 发现 - 探索获得宝物",
                    "§7积极应对事件，获取最大收益！"),
                List.of("create_nation"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "rankings",
                "排行榜",
                Material.NETHER_STAR,
                "§6§l排行榜系统",
                List.of("§7多种排行榜:", "§a  • 国家实力榜", "§b  • 个人贡献榜", "§c  • 财富榜", "§7每周更新，保持竞争！"),
                List.of("events"),
                ItemTier.INTERMEDIATE),
            new GuideItem(
                "dungeons",
                "副本系统",
                Material.SPAWNER,
                "§6§l挑战副本",
                List.of("§7• 多种难度副本", "§7• 组队挑战获得奖励", "§7• 每日限次挑战", "§7• 稀有掉落物品"),
                List.of("guild"),
                ItemTier.ADVANCED)));
  }

  public record GuideItem(
      String id,
      String title,
      Material icon,
      String subtitle,
      List<String> description,
      List<String> prerequisites,
      ItemTier tier) {}

  public enum ItemTier {
    FOUNDATIONAL("§a基础", NamedTextColor.GREEN),
    INTERMEDIATE("§e进阶", NamedTextColor.YELLOW),
    ADVANCED("§c高级", NamedTextColor.RED);

    private final String displayName;
    private final NamedTextColor color;

    ItemTier(String displayName, NamedTextColor color) {
      this.displayName = displayName;
      this.color = color;
    }

    public String getDisplayName() {
      return displayName;
    }

    public NamedTextColor getColor() {
      return color;
    }
  }
}
