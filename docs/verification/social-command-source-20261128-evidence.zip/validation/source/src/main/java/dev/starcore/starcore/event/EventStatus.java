package dev.starcore.starcore.event;

/** 事件状态枚举 定义事件在生命周期中的各个阶段 */
public enum EventStatus {
  /** 已定义：事件模板已加载，等待触发条件 */
  defined("已定义", "等待触发条件"),

  /** 等待中：触发条件已满足，等待前置事件完成 */
  pending("等待中", "等待前置事件完成"),

  /** 就绪：所有前置条件满足，可以开始 */
  ready("就绪", "可以开始"),

  /** 进行中：事件正在运行 */
  in_progress("进行中", "事件正在运行"),

  /** 暂停中：主动暂停，等待恢复 */
  suspended("暂停中", "等待恢复"),

  /** 已完成：事件已完成，等待结论确认 */
  completed("已完成", "等待结论确认"),

  /** 结论待定：事件已完成，等待正式结论 */
  conclusion_pending("结论待定", "等待正式结论"),

  /** 已确认：结论已确认，写入正史 */
  confirmed("已确认", "写入正史"),

  /** 已归档：事件已归档 */
  archived("已归档", "事件已归档"),

  /** 已取消：事件被取消 */
  cancelled("已取消", "事件被取消"),

  /** 失败：事件执行失败 */
  failed("失败", "事件执行失败");

  private final String displayName;
  private final String description;

  EventStatus(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 是否为活跃状态 */
  public boolean isActive() {
    return this == in_progress || this == suspended;
  }

  /** 是否为终止状态 */
  public boolean isTerminal() {
    return this == confirmed || this == archived || this == cancelled || this == failed;
  }

  /** 是否为可恢复状态 */
  public boolean isRecoverable() {
    return this == suspended || this == failed;
  }

  /** 是否为等待状态 */
  public boolean isWaiting() {
    return this == defined || this == pending || this == ready || this == conclusion_pending;
  }
}
