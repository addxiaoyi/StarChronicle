package dev.starcore.starcore.foundation.economy.transaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Durable retry item for a refund that could not be delivered during a failed transaction. */
public record PendingRefund(
    UUID transactionId,
    UUID accountId,
    BigDecimal amount,
    String reason,
    int attempts,
    Instant nextAttemptAt,
    String lastError,
    boolean manualReview,
    RefundOwner owner) {
  public PendingRefund(
      UUID transactionId,
      UUID accountId,
      BigDecimal amount,
      String reason,
      int attempts,
      Instant nextAttemptAt,
      String lastError) {
    this(
        transactionId,
        accountId,
        amount,
        reason,
        attempts,
        nextAttemptAt,
        lastError,
        false,
        RefundOwner.UNKNOWN);
  }

  public PendingRefund(
      UUID transactionId,
      UUID accountId,
      BigDecimal amount,
      String reason,
      int attempts,
      Instant nextAttemptAt,
      String lastError,
      boolean manualReview) {
    this(
        transactionId,
        accountId,
        amount,
        reason,
        attempts,
        nextAttemptAt,
        lastError,
        manualReview,
        RefundOwner.UNKNOWN);
  }

  public PendingRefund {
    Objects.requireNonNull(transactionId, "transactionId");
    Objects.requireNonNull(accountId, "accountId");
    Objects.requireNonNull(amount, "amount");
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(nextAttemptAt, "nextAttemptAt");
    owner = owner == null ? RefundOwner.UNKNOWN : owner;
    if (amount.signum() <= 0) throw new IllegalArgumentException("amount must be positive");
    if (attempts < 0) throw new IllegalArgumentException("attempts must be non-negative");
  }

  public PendingRefund failed(String error, Instant retryAt) {
    return new PendingRefund(
        transactionId,
        accountId,
        amount,
        reason,
        attempts + 1,
        retryAt,
        error,
        manualReview,
        owner);
  }

  public PendingRefund ownedBy(RefundOwner subsystem) {
    return new PendingRefund(
        transactionId,
        accountId,
        amount,
        reason,
        attempts,
        nextAttemptAt,
        lastError,
        manualReview,
        subsystem);
  }
}
