package dev.starcore.starcore.choice.gui;

import dev.starcore.starcore.choice.ChoiceDefinition;
import dev.starcore.starcore.choice.ChoiceInstance;
import dev.starcore.starcore.choice.ChoiceManager;
import dev.starcore.starcore.choice.PublicChoiceService;
import dev.starcore.starcore.choice.PublicChoiceService.DecisionSession;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * 公共选择（全服投票）GUI。
 *
 * <p>列出活跃会话并逐选项展示实时票数与占比；玩家点击投票走 {@link PublicChoiceService#voteForOption}， 重复投票/过期由服务拒绝并如实反馈。
 */
public final class PublicChoiceGui implements InventoryHolder {

  private static final String TITLE = "§b§l公共决策投票";

  private final Player player;
  private final PublicChoiceService choiceService;
  private final ChoiceManager choiceManager;
  private final Inventory inventory;
  private final Map<Integer, VoteTarget> voteSlots = new java.util.HashMap<>();

  /** 投票目标：会话内实例 + 选项 */
  private record VoteTarget(String instanceId, String optionId) {}

  PublicChoiceGui(Player player, PublicChoiceService choiceService, ChoiceManager choiceManager) {
    this.player = player;
    this.choiceService = choiceService;
    this.choiceManager = choiceManager;
    this.inventory = Bukkit.createInventory(this, 54, TITLE);
  }

  public void open() {
    populate();
    player.openInventory(inventory);
  }

  private void populate() {
    inventory.clear();
    voteSlots.clear();

    List<DecisionSession> sessions = List.copyOf(choiceService.getActiveSessions());
    UUID playerId = player.getUniqueId();

    inventory.setItem(
        4,
        item(
            Material.BEACON,
            "§b§l公共决策 (" + sessions.size() + " 场进行中)",
            List.of("§7点击选项投出你的一票", "§7每人每场限投一票")));

    if (sessions.isEmpty()) {
      inventory.setItem(22, item(Material.GRAY_DYE, "§7当前没有进行中的公共决策", List.of("§7等待新提案开启投票")));
      inventory.setItem(49, closeItem());
      return;
    }

    int slot = 9;
    for (DecisionSession session : sessions) {
      if (slot > 44) break;
      ChoiceInstance instance = choiceManager.getChoiceInstance(session.instanceId()).orElse(null);
      if (instance == null) continue;

      boolean voted =
          choiceService.getPlayerVoteCount(session.instanceId(), playerId.toString()) > 0;
      long remainingMs = session.endTime() - System.currentTimeMillis();
      String remaining = remainingMs > 0 ? formatDuration(remainingMs) : "即将结束";

      // 会话分隔卡
      inventory.setItem(
          slot,
          item(
              Material.PAPER,
              "§e决策 #"
                  + session.instanceId().substring(0, Math.min(8, session.instanceId().length())),
              List.of("§7状态: §f" + session.status(), "§7剩余: §f" + remaining),
              false));
      slot = advance(slot);

      // 选项卡
      Map<String, Integer> counts = instance.getVoteCounts();
      int totalVotes = counts.values().stream().mapToInt(Integer::intValue).sum();
      for (Map.Entry<String, ChoiceDefinition.Option> optionEntry : instance.options().entrySet()) {
        if (slot > 44) break;
        String optionId = optionEntry.getKey();
        ChoiceDefinition.Option option = optionEntry.getValue();
        int votes = counts.getOrDefault(optionId, 0);
        double share = totalVotes > 0 ? (double) votes / totalVotes : 0.0;
        boolean alreadyVotedThisOption = voted && optionEntry.getValue().supporters() != null;

        voteSlots.put(slot, new VoteTarget(session.instanceId(), optionId));
        inventory.setItem(
            slot,
            item(
                voted ? Material.LIME_DYE : Material.GREEN_WOOL,
                "§a" + option.description(),
                List.of(
                    "§7票数: §f" + votes,
                    "§7占比: §f" + progressBar(share) + " " + String.format("%.0f%%", share * 100),
                    voted ? "§a你已参与本场投票" : "§e点击投票"),
                voted));
        slot = advance(slot);
      }
    }

    inventory.setItem(49, closeItem());
  }

  /** 处理点击：票格投票，49 关闭 */
  public void handleClick(int slot) {
    VoteTarget target = voteSlots.get(slot);
    if (target != null) {
      UUID playerId = player.getUniqueId();
      boolean success =
          choiceService.voteForOption(target.instanceId(), playerId.toString(), target.optionId());
      if (success) {
        player.sendMessage("§a投票成功！");
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
      } else {
        player.sendMessage("§c投票失败：可能已投过票、会话已结束或选项无效");
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.8f, 1.0f);
      }
      populate();
      return;
    }
    if (slot == 49) {
      player.closeInventory();
    }
  }

  private int advance(int current) {
    int next = current + 1;
    if (next == 17 || next == 18) {
      next = 19;
    }
    if (next == 26 || next == 27) {
      next = 28;
    }
    if (next == 35 || next == 36) {
      next = 37;
    }
    return next;
  }

  private String progressBar(double share) {
    int filled = (int) Math.round(share * 10);
    return "▮".repeat(filled) + "▯".repeat(10 - filled);
  }

  private String formatDuration(long ms) {
    long seconds = ms / 1000;
    long minutes = seconds / 60;
    if (minutes >= 60) {
      return (minutes / 60) + "小时" + (minutes % 60) + "分";
    }
    if (minutes >= 1) {
      return minutes + "分" + (seconds % 60) + "秒";
    }
    return seconds + "秒";
  }

  private ItemStack item(Material material, String name, List<String> lore) {
    return item(material, name, lore, false);
  }

  private ItemStack item(Material material, String name, List<String> lore, boolean glow) {
    ItemStack stack = new ItemStack(material);
    ItemMeta meta = stack.getItemMeta();
    if (meta != null) {
      meta.setDisplayName(name);
      meta.setLore(lore);
      meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
      if (glow) {
        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
      }
      stack.setItemMeta(meta);
    }
    return stack;
  }

  private ItemStack closeItem() {
    return item(Material.BARRIER, "§c§l关闭", List.of("§7点击关闭此界面"), false);
  }

  @Override
  public Inventory getInventory() {
    return inventory;
  }
}
