package dev.starcore.starcore.integration.mobstack;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

/**
 * 生物堆叠集成 支持 StackMob、MobStacker、RoseStacker
 *
 * <p>目标：减少实体数量，提升服务器性能
 */
public final class MobStackIntegration {
  private static final Logger FAILURE_LOGGER =
      Logger.getLogger(MobStackIntegration.class.getName());
  private static final AtomicLong txSeq = new AtomicLong();
  private static final Pattern NON_DIGIT_PATTERN = Pattern.compile("[^0-9]");

  private final Plugin plugin;

  private boolean stackMobAvailable = false;
  private boolean mobStackerAvailable = false;
  private boolean roseStackerAvailable = false;

  private MobStackProvider provider;

  public MobStackIntegration(Plugin plugin) {
    this.plugin = plugin;
  }

  /** 初始化并检测可用的堆叠插件 */
  public boolean init() {
    stackMobAvailable = false;
    mobStackerAvailable = false;
    roseStackerAvailable = false;
    provider = null;

    PluginManager pm = plugin.getServer().getPluginManager();

    // 检测 StackMob（优先）
    if (pm.getPlugin("StackMob") != null && pm.isPluginEnabled("StackMob")) {
      stackMobAvailable = true;
      provider = new StackMobProvider();
      plugin.getLogger().info("✅ 生物堆叠: StackMob 集成已启用");
      return true;
    }

    // 检测 MobStacker
    if (pm.getPlugin("MobStacker") != null && pm.isPluginEnabled("MobStacker")) {
      mobStackerAvailable = true;
      provider = new MobStackerProvider();
      plugin.getLogger().info("✅ 生物堆叠: MobStacker 集成已启用");
      return true;
    }

    // 检测 RoseStacker
    if (pm.getPlugin("RoseStacker") != null && pm.isPluginEnabled("RoseStacker")) {
      roseStackerAvailable = true;
      provider = new RoseStackerProvider();
      plugin.getLogger().info("✅ 生物堆叠: RoseStacker 集成已启用");
      return true;
    }

    plugin.getLogger().info("⚠ 未检测到生物堆叠插件（推荐安装 StackMob）");
    return false;
  }

  /** 检查实体是否被堆叠 */
  public boolean isStacked(Entity entity) {
    if (provider == null || entity == null) {
      return false;
    }
    return provider.isStacked(entity);
  }

  /** 获取堆叠数量 */
  public int getStackSize(Entity entity) {
    if (provider == null || entity == null) {
      return 1;
    }
    return provider.getStackSize(entity);
  }

  /** 设置堆叠数量 */
  public boolean setStackSize(Entity entity, int size) {
    if (provider == null || entity == null) {
      return false;
    }
    return provider.setStackSize(entity, size);
  }

  /** 分离一个实体 */
  public Optional<Entity> splitStack(Entity entity, int amount) {
    if (provider == null || entity == null) {
      return Optional.empty();
    }
    return provider.splitStack(entity, amount);
  }

  /** 是否启用了生物堆叠 */
  public boolean isEnabled() {
    return provider != null;
  }

  /** 获取当前使用的插件名称 */
  public String getProviderName() {
    if (stackMobAvailable) return "StackMob";
    if (mobStackerAvailable) return "MobStacker";
    if (roseStackerAvailable) return "RoseStacker";
    return "None";
  }

  /** 生物堆叠提供者接口 */
  interface MobStackProvider {
    boolean isStacked(Entity entity);

    int getStackSize(Entity entity);

    boolean setStackSize(Entity entity, int size);

    Optional<Entity> splitStack(Entity entity, int amount);
  }

  private static void logFailure(
      String code, String op, Entity entity, String context, Throwable cause) {
    String message =
        "MobStack operation failed code="
            + code
            + " op="
            + op
            + " "
            + entityContext(entity)
            + " "
            + context
            + " txId="
            + txSeq.incrementAndGet();
    if (cause == null) {
      FAILURE_LOGGER.warning(message);
    } else {
      FAILURE_LOGGER.log(Level.WARNING, message, cause);
    }
  }

  private static String entityContext(Entity entity) {
    if (entity == null) {
      return "entityId=null entityType=null";
    }
    return "entityId=" + entity.getUniqueId() + " entityType=" + entity.getType();
  }

  private static boolean restoreOriginal(
      MobStackProvider provider, Entity entity, int originalSize, int amount) {
    try {
      if (provider.setStackSize(entity, originalSize)) {
        return true;
      }
    } catch (RuntimeException exception) {
      logFailure(
          "MOBSTACK_SPLIT_RESTORE_FAILURE",
          "restore-original",
          entity,
          "amount=" + amount + " originalSize=" + originalSize,
          exception);
      return false;
    }

    logFailure(
        "MOBSTACK_SPLIT_RESTORE_FAILURE",
        "restore-original",
        entity,
        "amount=" + amount + " originalSize=" + originalSize,
        null);
    return false;
  }

  private static void removeSpawnedEntity(Entity entity, int amount) {
    try {
      entity.remove();
    } catch (RuntimeException exception) {
      logFailure(
          "MOBSTACK_SPLIT_REMOVE_FAILURE", "remove-spawned", entity, "amount=" + amount, exception);
    }
  }

  /** StackMob 实现 */
  static class StackMobProvider implements MobStackProvider {
    @Override
    public boolean isStacked(Entity entity) {
      // 通过 NBT 或 API 检查
      return entity.hasMetadata("StackMob") || entity.hasMetadata("stackSize");
    }

    @Override
    public int getStackSize(Entity entity) {
      // 优先检查 StackMob metadata
      if (entity.hasMetadata("stackSize")) {
        return entity.getMetadata("stackSize").get(0).asInt();
      }

      if (entity.hasMetadata("StackMob")) {
        return entity.getMetadata("StackMob").get(0).asInt();
      }

      // 尝试从 CustomName 读取（某些版本）
      String customName = entity.getCustomName();
      if (customName != null && customName.contains("x")) {
        try {
          String[] parts = customName.split("x");
          if (parts.length > 0) {
            return Integer.parseInt(parts[0].trim());
          }
        } catch (NumberFormatException ignored) {
        }
      }

      return 1;
    }

    @Override
    public boolean setStackSize(Entity entity, int size) {
      if (size <= 0) return false;

      try {
        // 设置 metadata
        entity.setMetadata(
            "stackSize",
            new org.bukkit.metadata.FixedMetadataValue(
                org.bukkit.Bukkit.getPluginManager().getPlugin("STARCORE"), size));

        // 更新 CustomName 显示
        if (size > 1) {
          entity.setCustomName("§e" + size + "x §f" + entity.getType().name());
          entity.setCustomNameVisible(true);
        } else {
          entity.setCustomName(null);
          entity.setCustomNameVisible(false);
        }

        return true;
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SET_SIZE_FAILURE",
            "set-stack-size",
            entity,
            "provider=StackMob size=" + size,
            e);
        return false;
      }
    }

    @Override
    public Optional<Entity> splitStack(Entity entity, int amount) {
      int currentSize = getStackSize(entity);

      if (amount <= 0 || amount >= currentSize) {
        return Optional.empty();
      }

      // 先确认原堆叠已缩减，避免缩减失败时额外生成实体。
      if (!setStackSize(entity, currentSize - amount)) {
        logFailure(
            "MOBSTACK_SPLIT_REDUCE_FAILURE",
            "split-stack",
            entity,
            "provider=StackMob amount=" + amount + " currentSize=" + currentSize,
            null);
        return Optional.empty();
      }

      // 生成新实体
      Entity newEntity;
      try {
        newEntity =
            entity
                .getWorld()
                .spawnEntity(entity.getLocation().clone().add(1, 0, 1), entity.getType());
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SPLIT_SPAWN_FAILURE",
            "split-stack",
            entity,
            "provider=StackMob amount=" + amount + " currentSize=" + currentSize,
            e);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }

      if (!setStackSize(newEntity, amount)) {
        logFailure(
            "MOBSTACK_SPLIT_CHILD_SET_FAILURE",
            "split-stack",
            newEntity,
            "provider=StackMob amount=" + amount,
            null);
        removeSpawnedEntity(newEntity, amount);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }
      return Optional.of(newEntity);
    }
  }

  /** MobStacker 实现 */
  static class MobStackerProvider implements MobStackProvider {
    @Override
    public boolean isStacked(Entity entity) {
      return entity.hasMetadata("MobStacker") || entity.hasMetadata("MobStacker_stackSize");
    }

    @Override
    public int getStackSize(Entity entity) {
      // 检查 MobStacker metadata
      if (entity.hasMetadata("MobStacker_stackSize")) {
        return entity.getMetadata("MobStacker_stackSize").get(0).asInt();
      }

      if (entity.hasMetadata("MobStacker")) {
        return entity.getMetadata("MobStacker").get(0).asInt();
      }

      // 尝试从 CustomName 解析
      String customName = entity.getCustomName();
      if (customName != null && customName.contains("x")) {
        try {
          // MobStacker 格式: "5x Zombie"
          String[] parts = customName.split("x");
          if (parts.length > 0) {
            String numStr = NON_DIGIT_PATTERN.matcher(parts[0]).replaceAll("");
            return Integer.parseInt(numStr);
          }
        } catch (NumberFormatException ignored) {
        }
      }

      return 1;
    }

    @Override
    public boolean setStackSize(Entity entity, int size) {
      if (size <= 0) return false;

      try {
        entity.setMetadata(
            "MobStacker_stackSize",
            new org.bukkit.metadata.FixedMetadataValue(
                org.bukkit.Bukkit.getPluginManager().getPlugin("STARCORE"), size));

        // 更新显示名称
        if (size > 1) {
          entity.setCustomName("§6" + size + "x §e" + entity.getType().name());
          entity.setCustomNameVisible(true);
        } else {
          entity.setCustomName(null);
          entity.setCustomNameVisible(false);
        }

        return true;
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SET_SIZE_FAILURE",
            "set-stack-size",
            entity,
            "provider=MobStacker size=" + size,
            e);
        return false;
      }
    }

    @Override
    public Optional<Entity> splitStack(Entity entity, int amount) {
      int currentSize = getStackSize(entity);

      if (amount <= 0 || amount >= currentSize) {
        return Optional.empty();
      }

      if (!setStackSize(entity, currentSize - amount)) {
        logFailure(
            "MOBSTACK_SPLIT_REDUCE_FAILURE",
            "split-stack",
            entity,
            "provider=MobStacker amount=" + amount + " currentSize=" + currentSize,
            null);
        return Optional.empty();
      }

      Entity newEntity;
      try {
        newEntity =
            entity
                .getWorld()
                .spawnEntity(entity.getLocation().clone().add(1, 0, 1), entity.getType());
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SPLIT_SPAWN_FAILURE",
            "split-stack",
            entity,
            "provider=MobStacker amount=" + amount + " currentSize=" + currentSize,
            e);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }

      if (!setStackSize(newEntity, amount)) {
        logFailure(
            "MOBSTACK_SPLIT_CHILD_SET_FAILURE",
            "split-stack",
            newEntity,
            "provider=MobStacker amount=" + amount,
            null);
        removeSpawnedEntity(newEntity, amount);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }
      return Optional.of(newEntity);
    }
  }

  /** RoseStacker 实现 */
  static class RoseStackerProvider implements MobStackProvider {
    @Override
    public boolean isStacked(Entity entity) {
      return entity.hasMetadata("RoseStacker") || entity.hasMetadata("RoseStacker_StackSize");
    }

    @Override
    public int getStackSize(Entity entity) {
      // RoseStacker 的标准 metadata
      if (entity.hasMetadata("RoseStacker_StackSize")) {
        return entity.getMetadata("RoseStacker_StackSize").get(0).asInt();
      }

      if (entity.hasMetadata("RoseStacker")) {
        return entity.getMetadata("RoseStacker").get(0).asInt();
      }

      // 尝试从 CustomName 解析
      String customName = entity.getCustomName();
      if (customName != null) {
        // RoseStacker 格式: "§6§lx5§r §eZombie"
        try {
          if (customName.contains("x")) {
            String[] parts = customName.split("x");
            if (parts.length > 1) {
              String numStr = NON_DIGIT_PATTERN.matcher(parts[1].split("§")[0]).replaceAll("");
              if (!numStr.isEmpty()) {
                return Integer.parseInt(numStr);
              }
            }
          }
        } catch (NumberFormatException ignored) {
        }
      }

      return 1;
    }

    @Override
    public boolean setStackSize(Entity entity, int size) {
      if (size <= 0) return false;

      try {
        entity.setMetadata(
            "RoseStacker_StackSize",
            new org.bukkit.metadata.FixedMetadataValue(
                org.bukkit.Bukkit.getPluginManager().getPlugin("STARCORE"), size));

        // 更新显示名称（RoseStacker 风格）
        if (size > 1) {
          entity.setCustomName("§6§lx" + size + "§r §e" + entity.getType().name());
          entity.setCustomNameVisible(true);
        } else {
          entity.setCustomName(null);
          entity.setCustomNameVisible(false);
        }

        return true;
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SET_SIZE_FAILURE",
            "set-stack-size",
            entity,
            "provider=RoseStacker size=" + size,
            e);
        return false;
      }
    }

    @Override
    public Optional<Entity> splitStack(Entity entity, int amount) {
      int currentSize = getStackSize(entity);

      if (amount <= 0 || amount >= currentSize) {
        return Optional.empty();
      }

      if (!setStackSize(entity, currentSize - amount)) {
        logFailure(
            "MOBSTACK_SPLIT_REDUCE_FAILURE",
            "split-stack",
            entity,
            "provider=RoseStacker amount=" + amount + " currentSize=" + currentSize,
            null);
        return Optional.empty();
      }

      Entity newEntity;
      try {
        newEntity =
            entity
                .getWorld()
                .spawnEntity(entity.getLocation().clone().add(1, 0, 1), entity.getType());
      } catch (Exception e) {
        logFailure(
            "MOBSTACK_SPLIT_SPAWN_FAILURE",
            "split-stack",
            entity,
            "provider=RoseStacker amount=" + amount + " currentSize=" + currentSize,
            e);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }

      if (!setStackSize(newEntity, amount)) {
        logFailure(
            "MOBSTACK_SPLIT_CHILD_SET_FAILURE",
            "split-stack",
            newEntity,
            "provider=RoseStacker amount=" + amount,
            null);
        removeSpawnedEntity(newEntity, amount);
        restoreOriginal(this, entity, currentSize, amount);
        return Optional.empty();
      }
      return Optional.of(newEntity);
    }
  }
}
