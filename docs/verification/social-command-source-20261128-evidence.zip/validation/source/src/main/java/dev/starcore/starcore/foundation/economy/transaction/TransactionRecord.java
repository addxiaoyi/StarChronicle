package dev.starcore.starcore.foundation.economy.transaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Durable transaction state plus its replayable transition timeline. */
public record TransactionRecord(
    UUID transactionId,
    UUID accountId,
    BigDecimal amount,
    RefundOwner owner,
    TransactionType type,
    String reason,
    String idempotencyKey,
    Map<String, String> metadata,
    EconomyTransactionState state,
    int attempts,
    Instant createdAt,
    Instant updatedAt,
    String lastError,
    List<TransactionEvent> events) {
  public TransactionRecord {
    Objects.requireNonNull(transactionId, "transactionId");
    Objects.requireNonNull(accountId, "accountId");
    Objects.requireNonNull(amount, "amount");
    Objects.requireNonNull(owner, "owner");
    Objects.requireNonNull(type, "type");
    Objects.requireNonNull(reason, "reason");
    Objects.requireNonNull(idempotencyKey, "idempotencyKey");
    Objects.requireNonNull(metadata, "metadata");
    Objects.requireNonNull(state, "state");
    Objects.requireNonNull(createdAt, "createdAt");
    Objects.requireNonNull(updatedAt, "updatedAt");
    Objects.requireNonNull(events, "events");
    if (amount.signum() <= 0) throw new IllegalArgumentException("amount must be positive");
    if (attempts < 0) throw new IllegalArgumentException("attempts must be non-negative");
    metadata = Map.copyOf(metadata);
    events = List.copyOf(events);
    if (events.isEmpty() || events.getFirst().state() != EconomyTransactionState.CREATED) {
      throw new IllegalArgumentException("events must start with CREATED");
    }
    if (!createdAt.equals(events.getFirst().at())
        || !updatedAt.equals(events.getLast().at())
        || state != events.getLast().state()) {
      throw new IllegalArgumentException("transaction state and timestamps must match events");
    }
    long expectedAttempts =
        events.stream()
            .filter(event -> event.state() == EconomyTransactionState.REFUND_PENDING)
            .count();
    if (attempts != expectedAttempts) {
      throw new IllegalArgumentException("attempts must match REFUND_PENDING events");
    }
    for (int index = 1; index < events.size(); index++) {
      EconomyTransactionState previous = events.get(index - 1).state();
      EconomyTransactionState next = events.get(index).state();
      if (previous == next || !previous.canTransitionTo(next)) {
        throw new IllegalArgumentException(
            "events contain illegal transaction transition " + previous + " -> " + next);
      }
    }
  }

  public TransactionRecord transition(EconomyTransactionState next, String message, Instant now) {
    Objects.requireNonNull(next, "next");
    Objects.requireNonNull(message, "message");
    Objects.requireNonNull(now, "now");
    List<TransactionEvent> nextEvents = new java.util.ArrayList<>(events);
    nextEvents.add(new TransactionEvent(now, next, message));
    int nextAttempts = next == EconomyTransactionState.REFUND_PENDING ? attempts + 1 : attempts;
    return new TransactionRecord(
        transactionId,
        accountId,
        amount,
        owner,
        type,
        reason,
        idempotencyKey,
        metadata,
        next,
        nextAttempts,
        createdAt,
        now,
        next == EconomyTransactionState.MANUAL_REVIEW ? message : lastError,
        nextEvents);
  }

  public TransactionRecord failed(String message, Instant now) {
    EconomyTransactionState failureState =
        state == EconomyTransactionState.CREATED || state == EconomyTransactionState.RESERVED
            ? EconomyTransactionState.DEBIT_FAILED
            : EconomyTransactionState.DELIVERY_FAILED;
    return transition(failureState, message, now);
  }
}
