package dev.starcore.starcore.economy.loop;

import dev.starcore.starcore.economy.Currency;
import dev.starcore.starcore.economy.EconomyManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/** 通货膨胀调整器 监控和调整货币通胀率 */
public class InflationAdjuster {

  private static final String STATE_KEY_PREFIX = "inflation.";

  private final EconomyManager economyManager;
  private final Map<Currency, InflationData> inflationDataMap = new ConcurrentHashMap<>();
  private final Map<String, Long> playerCurrencyVelocity = new ConcurrentHashMap<>();
  private final Map<Currency, AtomicReference<Double>> adjustmentMultipliers =
      new ConcurrentHashMap<>();

  // 通胀控制参数
  private double targetInflationRate = 0.03; // 3% 目标通胀率
  private double inflationTolerance = 0.02; // 2% 容忍范围
  private double maxAdjustmentStrength = 0.1; // 最大调整幅度

  public InflationAdjuster(EconomyManager economyManager) {
    this.economyManager = Objects.requireNonNull(economyManager);
    initializeInflationData();
  }

  /** 初始化通胀数据 */
  private void initializeInflationData() {
    for (Currency currency : Currency.values()) {
      inflationDataMap.put(currency, new InflationData(currency));
      adjustmentMultipliers.put(currency, new AtomicReference<>(1.0));
    }
  }

  /** 记录交易数据 */
  public void recordTransaction(String playerId, Currency currency, long amount) {
    // 更新通胀数据
    InflationData inflationData =
        inflationDataMap.computeIfAbsent(currency, c -> new InflationData(c));
    inflationData.recordTransaction(amount);

    // 更新玩家货币流速
    playerCurrencyVelocity.merge(playerId + ":" + currency.name(), Math.abs(amount), Long::sum);
  }

  /** 更新通胀调整 */
  public void updateInflationAdjustments(long currentTime) {
    for (Currency currency : Currency.values()) {
      InflationData inflationData = inflationDataMap.get(currency);
      if (inflationData == null) continue;

      // 计算当前通胀率
      double currentInflationRate = inflationData.calculateInflationRate(currentTime);

      // 根据当前通胀率进行调整
      double adjustment = calculateAdjustment(currentInflationRate);
      double currentMultiplier = adjustmentMultipliers.get(currency).get();
      double newMultiplier = currentMultiplier * (1 + adjustment);

      // 限制调整范围
      newMultiplier = Math.max(0.5, Math.min(2.0, newMultiplier));
      adjustmentMultipliers.get(currency).set(newMultiplier);

      // 记录调整历史
      inflationData.recordAdjustment(adjustment, newMultiplier, currentInflationRate);
    }
  }

  /** 计算调整幅度 */
  private double calculateAdjustment(double currentInflationRate) {
    double deviation = currentInflationRate - targetInflationRate;

    if (Math.abs(deviation) <= inflationTolerance) {
      // 通胀率在容忍范围内，不做调整
      return 0.0;
    }

    // 根据偏差大小调整
    double adjustment;
    if (deviation > 0) {
      // 通胀过高，应收缩货币供应
      adjustment =
          -maxAdjustmentStrength * (deviation / (targetInflationRate + inflationTolerance));
      adjustment = Math.max(-maxAdjustmentStrength, adjustment);
    } else {
      // 通胀过低（可能是通缩），应增加货币供应
      // 防御：targetInflationRate 可能被置为 0，用非零下限避免除零
      double denominator = Math.max(targetInflationRate, 0.001);
      adjustment = maxAdjustmentStrength * (Math.abs(deviation) / denominator);
      adjustment = Math.min(maxAdjustmentStrength, adjustment);
    }

    return adjustment;
  }

  /** 获取货币的调整乘数 */
  public double getAdjustmentMultiplier(Currency currency) {
    return adjustmentMultipliers.getOrDefault(currency, new AtomicReference<>(1.0)).get();
  }

  /** 获取货币的通胀率 */
  public double getInflationRate(Currency currency) {
    InflationData data = inflationDataMap.get(currency);
    return data != null ? data.calculateInflationRate(System.currentTimeMillis()) : 0.0;
  }

  /** 获取通胀数据 */
  public InflationData getInflationData(Currency currency) {
    return inflationDataMap.get(currency);
  }

  /** 获取所有通胀数据 */
  public Collection<InflationData> getAllInflationData() {
    return inflationDataMap.values();
  }

  /** 设置目标通胀率 */
  public void setTargetInflationRate(double rate) {
    this.targetInflationRate = Math.max(0, Math.min(1.0, rate));
  }

  /** 设置容忍范围 */
  public void setInflationTolerance(double tolerance) {
    this.inflationTolerance = Math.max(0, tolerance);
  }

  /** 设置最大调整强度 */
  public void setMaxAdjustmentStrength(double strength) {
    this.maxAdjustmentStrength = Math.max(0, Math.min(1.0, strength));
  }

  /** 定时更新入口 */
  public void update() {
    updateInflationAdjustments(System.currentTimeMillis());
  }

  /** 保存调整乘数到文件（与既有内容合并，保留其他前缀的键） */
  public void saveState(File file) {
    Objects.requireNonNull(file);
    Properties properties = new Properties();
    if (file.exists() && file.isFile()) {
      try (InputStream in = new FileInputStream(file)) {
        properties.load(in);
      } catch (Exception e) {
        java.util.logging.Logger.getLogger(InflationAdjuster.class.getName())
            .warning("Failed to read existing inflation state, overwriting: " + e.getMessage());
      }
    }
    for (Map.Entry<Currency, AtomicReference<Double>> entry : adjustmentMultipliers.entrySet()) {
      properties.setProperty(
          STATE_KEY_PREFIX + entry.getKey().name(), String.valueOf(entry.getValue().get()));
    }
    File parent = file.getAbsoluteFile().getParentFile();
    if (parent != null && !parent.exists() && !parent.mkdirs()) {
      java.util.logging.Logger.getLogger(InflationAdjuster.class.getName())
          .warning("Failed to create directory for inflation state: " + parent);
      return;
    }
    try (OutputStream out = new FileOutputStream(file)) {
      properties.store(out, "InflationAdjuster adjustment multipliers");
    } catch (Exception e) {
      java.util.logging.Logger.getLogger(InflationAdjuster.class.getName())
          .warning("Failed to save inflation state: " + e.getMessage());
    }
  }

  /** 从文件加载调整乘数，缺失类型保持 1.0 */
  public void loadState(File file) {
    Objects.requireNonNull(file);
    if (!file.exists() || !file.isFile()) {
      return;
    }
    Properties properties = new Properties();
    try (InputStream in = new FileInputStream(file)) {
      properties.load(in);
    } catch (Exception e) {
      java.util.logging.Logger.getLogger(InflationAdjuster.class.getName())
          .warning("Failed to load inflation state: " + e.getMessage());
      return;
    }
    for (Currency currency : Currency.values()) {
      String raw = properties.getProperty(STATE_KEY_PREFIX + currency.name());
      if (raw == null) {
        continue;
      }
      try {
        double multiplier = Double.parseDouble(raw.trim());
        adjustmentMultipliers
            .getOrDefault(currency, new AtomicReference<>(1.0))
            .set(Math.max(0.5, Math.min(2.0, multiplier)));
      } catch (NumberFormatException e) {
        java.util.logging.Logger.getLogger(InflationAdjuster.class.getName())
            .warning("Invalid inflation multiplier for " + currency.name() + ": " + raw);
      }
    }
  }

  /** 重置通胀调整 */
  public void resetAdjustments() {
    for (AtomicReference<Double> ref : adjustmentMultipliers.values()) {
      ref.set(1.0);
    }
  }

  /** 通胀数据 */
  public static class InflationData {
    private final Currency currency;
    private final List<TransactionRecord> transactionHistory = new ArrayList<>();
    private final List<AdjustmentRecord> adjustmentHistory = new ArrayList<>();

    private long totalMoneySupply = 0;
    private long totalMoneyRemoved = 0;
    private long lastUpdateTime = System.currentTimeMillis();

    public InflationData(Currency currency) {
      this.currency = Objects.requireNonNull(currency);
    }

    public void recordTransaction(long amount) {
      transactionHistory.add(new TransactionRecord(System.currentTimeMillis(), amount));

      if (amount > 0) {
        totalMoneySupply += amount;
      } else {
        totalMoneyRemoved += Math.abs(amount);
      }

      lastUpdateTime = System.currentTimeMillis();
    }

    public void recordAdjustment(double adjustment, double multiplier, double inflationRate) {
      adjustmentHistory.add(
          new AdjustmentRecord(System.currentTimeMillis(), adjustment, multiplier, inflationRate));
    }

    public double calculateInflationRate(long currentTime) {
      long timeWindow = 60_000; // 1分钟窗口
      long cutoff = currentTime - timeWindow;

      long recentSupply = 0;
      long recentRemoved = 0;

      for (TransactionRecord record : transactionHistory) {
        if (record.timestamp() >= cutoff) {
          if (record.amount() > 0) {
            recentSupply += record.amount();
          } else {
            recentRemoved += Math.abs(record.amount());
          }
        }
      }

      if (recentSupply == 0) return 0.0;

      // 简化的通胀率计算
      return (double) (recentSupply - recentRemoved) / recentSupply;
    }

    public Currency getCurrency() {
      return currency;
    }

    public long getTotalMoneySupply() {
      return totalMoneySupply;
    }

    public long getTotalMoneyRemoved() {
      return totalMoneyRemoved;
    }

    public long getNetSupply() {
      return totalMoneySupply - totalMoneyRemoved;
    }

    public List<TransactionRecord> getTransactionHistory() {
      return List.copyOf(transactionHistory);
    }

    public List<AdjustmentRecord> getAdjustmentHistory() {
      return List.copyOf(adjustmentHistory);
    }

    public long getLastUpdateTime() {
      return lastUpdateTime;
    }
  }

  /** 交易记录 */
  public static record TransactionRecord(long timestamp, long amount) {}

  /** 调整记录 */
  public static record AdjustmentRecord(
      long timestamp, double adjustment, double multiplier, double inflationRate) {}
}
