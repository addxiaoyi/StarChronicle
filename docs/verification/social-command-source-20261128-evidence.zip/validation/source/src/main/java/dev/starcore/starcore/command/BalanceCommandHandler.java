package dev.starcore.starcore.command;

import dev.starcore.starcore.balance.BalanceFinding;
import dev.starcore.starcore.balance.BalanceHealthReport;
import dev.starcore.starcore.balance.BalanceHealthService;
import dev.starcore.starcore.balance.BalanceSeverity;
import dev.starcore.starcore.balance.BalanceSnapshot;
import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleDescriptor;
import dev.starcore.starcore.foundation.message.StarMessages;
import java.util.Collection;
import java.util.Objects;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.CommandSender;

final class BalanceCommandHandler {
  private final StarCoreContext context;
  private final BalanceHealthService service;

  BalanceCommandHandler(StarCoreContext context) {
    this(context, new BalanceHealthService());
  }

  BalanceCommandHandler(StarCoreContext context, BalanceHealthService service) {
    this.context = Objects.requireNonNull(context, "context");
    this.service = Objects.requireNonNull(service, "service");
  }

  void handle(CommandSender sender) {
    if (!sender.hasPermission("starcore.admin") && !sender.hasPermission("starcore.admin.debug")) {
      StarMessages.error(sender, "你没有权限使用此命令。");
      return;
    }

    Collection<ModuleDescriptor> modules = context.moduleManager().descriptors();
    BalanceSnapshot snapshot = BalanceSnapshot.capture(context.configuration(), modules);
    BalanceHealthReport report = service.analyze(snapshot, modules);

    StarMessages.header(sender, "平衡与模块健康诊断");
    sender.sendMessage(
        Component.text("启用模块: ", NamedTextColor.GRAY)
            .append(Component.text(String.valueOf(snapshot.enabledModules()), NamedTextColor.WHITE))
            .append(Component.text(" | 高风险: ", NamedTextColor.GRAY))
            .append(Component.text(String.valueOf(report.highCount()), NamedTextColor.RED))
            .append(Component.text(" | 警告: ", NamedTextColor.GRAY))
            .append(Component.text(String.valueOf(report.warningCount()), NamedTextColor.YELLOW)));
    sender.sendMessage(
        Component.text("资源区基准单轮收入: ", NamedTextColor.GRAY)
            .append(
                Component.text(
                    snapshot.resourceIncomePerDistrictCycle().toPlainString(),
                    NamedTextColor.WHITE))
            .append(Component.text(" | 成熟国家基准资源收入: ", NamedTextColor.GRAY))
            .append(
                Component.text(
                    snapshot.hasUnlimitedResourceDistricts()
                        ? "无限制"
                        : snapshot.maximumResourceIncomePerCycle().toPlainString(),
                    NamedTextColor.WHITE)));
    sender.sendMessage(
        Component.text("最高领地容量: ", NamedTextColor.GRAY)
            .append(
                Component.text(
                    snapshot.hasUnlimitedClaimCapacity()
                        ? "无限制"
                        : String.valueOf(snapshot.maximumClaimCapacity()),
                    NamedTextColor.WHITE)));

    if (report.findings().isEmpty()) {
      sender.sendMessage(Component.text("未发现当前规则覆盖的高风险配置。", NamedTextColor.GREEN));
      return;
    }
    for (BalanceFinding finding : report.findings()) {
      sender.sendMessage(
          Component.text(
              "[" + severityLabel(finding.severity()) + "] " + finding.summary(),
              colorFor(finding.severity())));
      sender.sendMessage(Component.text("  建议: " + finding.recommendation(), NamedTextColor.GRAY));
    }
  }

  private static String severityLabel(BalanceSeverity severity) {
    return switch (severity) {
      case INFO -> "信息";
      case WARNING -> "警告";
      case HIGH -> "高风险";
    };
  }

  private static NamedTextColor colorFor(BalanceSeverity severity) {
    return switch (severity) {
      case INFO -> NamedTextColor.AQUA;
      case WARNING -> NamedTextColor.YELLOW;
      case HIGH -> NamedTextColor.RED;
    };
  }
}
