package dev.starcore.starcore.cooking;

import java.util.*;

/** 烹调结果模型 */
public record CookingResult(
    String sessionId, // 会话ID
    String recipeId, // 食谱ID
    String playerId, // 玩家ID
    double quality, // 质量（0.0-1.0）
    boolean isPerfect, // 是否完美
    boolean isUnlocked, // 是否解锁食谱
    long completedAt, // 完成时间
    String resultItem, // 结果物品
    int resultAmount // 结果数量
    ) {

  /** 创建烹调结果构建器 */
  public static Builder builder(String sessionId, String recipeId) {
    return new Builder(sessionId, recipeId);
  }

  /** 获取质量等级 */
  public String getQualityGrade() {
    if (isPerfect) return "完美";
    if (quality >= 0.8) return "优秀";
    if (quality >= 0.6) return "良好";
    if (quality >= 0.4) return "普通";
    return "失败";
  }

  /** 烹调结果构建器 */
  public static class Builder {
    private final String sessionId;
    private final String recipeId;
    private String playerId;
    private double quality = 0.5;
    private boolean isPerfect = false;
    private boolean isUnlocked = false;
    private long completedAt = System.currentTimeMillis();
    private String resultItem = "";
    private int resultAmount = 1;

    private Builder(String sessionId, String recipeId) {
      this.sessionId = Objects.requireNonNull(sessionId);
      this.recipeId = Objects.requireNonNull(recipeId);
    }

    public Builder playerId(String playerId) {
      this.playerId = playerId;
      return this;
    }

    public Builder quality(double quality) {
      this.quality = Math.max(0.0, Math.min(1.0, quality));
      return this;
    }

    public Builder isPerfect(boolean isPerfect) {
      this.isPerfect = isPerfect;
      return this;
    }

    public Builder isUnlocked(boolean isUnlocked) {
      this.isUnlocked = isUnlocked;
      return this;
    }

    public Builder completedAt(long completedAt) {
      this.completedAt = completedAt;
      return this;
    }

    public Builder resultItem(String resultItem) {
      this.resultItem = resultItem;
      return this;
    }

    public Builder resultAmount(int resultAmount) {
      this.resultAmount = Math.max(0, resultAmount);
      return this;
    }

    public CookingResult build() {
      return new CookingResult(
          sessionId,
          recipeId,
          playerId,
          quality,
          isPerfect,
          isUnlocked,
          completedAt,
          resultItem,
          resultAmount);
    }
  }
}
