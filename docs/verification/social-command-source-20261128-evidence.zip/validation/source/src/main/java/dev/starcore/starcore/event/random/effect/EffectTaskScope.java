package dev.starcore.starcore.event.random.effect;

import dev.starcore.starcore.event.random.RandomEventRuntime;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/** One lifecycle per plugin, shared by configured instances of the same effect family. */
final class EffectTaskScope {
  private static final Map<Plugin, EffectTaskScope> SCOPES = new IdentityHashMap<>();
  final Plugin plugin;
  final RandomEventRuntime runtime;
  private final Set<Timer> timers = ConcurrentHashMap.newKeySet();
  private final AtomicBoolean closed = new AtomicBoolean();

  private EffectTaskScope(Plugin plugin) {
    this.plugin = plugin;
    runtime = new RandomEventRuntime(plugin);
  }

  static synchronized EffectTaskScope of(Plugin plugin) {
    return SCOPES.computeIfAbsent(plugin, EffectTaskScope::new);
  }

  boolean active() {
    return !closed.get() && plugin.isEnabled();
  }

  void broadcast(dev.starcore.starcore.module.nation.model.Nation nation, String message) {
    Set<UUID> members = new HashSet<>();
    nation.members().forEach(member -> members.add(member.playerId()));
    UUID founder = nation.founderId();
    runtime
        .forPlayers(
            player -> {
              UUID id = player.getUniqueId();
              if (id.equals(founder)) player.sendMessage("§6[创始人] " + message);
              else if (members.contains(id)) player.sendMessage(message);
            })
        .exceptionally(
            failure -> {
              if (!RandomEventRuntime.cancelled(failure))
                plugin.getLogger().log(java.util.logging.Level.WARNING, "国家效果通知失败", failure);
              return null;
            });
  }

  Timer repeat(Consumer<Timer> action, long delay, long period) {
    Timer timer = new Timer(action);
    timers.add(timer);
    if (!active()) {
      timer.cancel();
      return timer;
    }
    try {
      timer.attach(
          plugin
              .getServer()
              .getGlobalRegionScheduler()
              .runAtFixedRate(plugin, ignored -> timer.run(), Math.max(1, delay), period));
      if (!active()) timer.cancel();
      return timer;
    } catch (RuntimeException | Error failure) {
      timer.cancel();
      throw failure;
    }
  }

  static void shutdown(Plugin plugin) {
    EffectTaskScope scope;
    synchronized (EffectTaskScope.class) {
      scope = SCOPES.remove(plugin);
    }
    if (scope != null) scope.close();
  }

  static void shutdownAll() {
    List<EffectTaskScope> scopes;
    synchronized (EffectTaskScope.class) {
      scopes = List.copyOf(SCOPES.values());
      SCOPES.clear();
    }
    scopes.forEach(EffectTaskScope::close);
  }

  private void close() {
    if (!closed.compareAndSet(false, true)) return;
    runtime.shutdown();
    List.copyOf(timers).forEach(Timer::cancel);
  }

  final class Timer {
    final Consumer<Timer> action;
    private final AtomicBoolean cancelled = new AtomicBoolean();
    private ScheduledTask task;
    private boolean backendCancelled;

    Timer(Consumer<Timer> action) {
      this.action = action;
    }

    synchronized void attach(ScheduledTask task) {
      this.task = task;
      if (task == null) cancel();
      if (cancelled.get()) cancelBackend();
    }

    void run() {
      if (cancelled.get()) return;
      if (!active() || !Bukkit.isGlobalTickThread()) {
        cancel();
        return;
      }
      try {
        action.accept(this);
      } catch (RuntimeException | Error failure) {
        cancel();
        throw failure;
      }
    }

    boolean isCancelled() {
      return cancelled.get();
    }

    void cancel() {
      cancelled.set(true);
      timers.remove(this);
      cancelBackend();
    }

    private synchronized void cancelBackend() {
      if (task == null || backendCancelled) return;
      backendCancelled = true;
      try {
        task.cancel();
      } catch (IllegalStateException ignored) {
      }
    }
  }
}
