package dev.starcore.starcore.core.module;

public enum ModuleStatus {
  REGISTERED,
  STARTING,
  ENABLED,
  DISABLED,
  FAILED
}
