package dev.starcore.starcore.choice;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/** 公共选择管理器 管理所有公共选择的定义、实例和状态转换 */
public class ChoiceManager {

  private final Map<String, ChoiceDefinition> choiceDefinitions = new ConcurrentHashMap<>();
  private final Map<String, ChoiceInstance> choiceInstances = new ConcurrentHashMap<>();

  // 锁机制
  private final Lock choiceLock = new ReentrantLock();

  /** 注册选择定义 */
  public void registerChoiceDefinition(ChoiceDefinition definition) {
    choiceDefinitions.put(definition.choiceId(), definition);
  }

  /** 卸载选择定义 */
  public void unregisterChoiceDefinition(String choiceId) {
    choiceDefinitions.remove(choiceId);
  }

  /** 获取选择定义 */
  public Optional<ChoiceDefinition> getChoiceDefinition(String choiceId) {
    return Optional.ofNullable(choiceDefinitions.get(choiceId));
  }

  /** 获取所有选择定义 */
  public Collection<ChoiceDefinition> getAllChoiceDefinitions() {
    return choiceDefinitions.values();
  }

  /** 创建选择实例 */
  public ChoiceInstance createChoiceInstance(String choiceId, String epochRunId) {
    ChoiceDefinition definition = choiceDefinitions.get(choiceId);
    if (definition == null) {
      throw new IllegalArgumentException("Choice definition not found: " + choiceId);
    }

    String instanceId = generateInstanceId();
    ChoiceInstance instance =
        ChoiceInstance.builder(instanceId, choiceId)
            .status(ChoiceStatus.drafting)
            .epochRunId(epochRunId)
            .options(definition.options())
            .createdAt(System.currentTimeMillis())
            .build();

    choiceInstances.put(instanceId, instance);
    return instance;
  }

  /** 获取选择实例 */
  public Optional<ChoiceInstance> getChoiceInstance(String instanceId) {
    return Optional.ofNullable(choiceInstances.get(instanceId));
  }

  /** 获取指定选择的所有实例 */
  public List<ChoiceInstance> getInstancesByChoiceId(String choiceId) {
    if (choiceId == null) return List.of();
    return choiceInstances.values().stream().filter(i -> choiceId.equals(i.choiceId())).toList();
  }

  /** 获取指定纪元的所有选择实例 */
  public List<ChoiceInstance> getInstancesByEpoch(String epochRunId) {
    if (epochRunId == null) return List.of();
    return choiceInstances.values().stream()
        .filter(i -> epochRunId.equals(i.epochRunId()))
        .toList();
  }

  /** 获取活跃的选择实例 */
  public List<ChoiceInstance> getActiveInstances() {
    return choiceInstances.values().stream()
        .filter(
            i ->
                i.status().isInVotingPhase()
                    || i.status() == ChoiceStatus.implementation
                    || i.status() == ChoiceStatus.review)
        .toList();
  }

  /** 开始举证阶段 */
  public void openEvidence(String instanceId) {
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              ChoiceStatus.evidence_open,
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              instance.selectedOption(),
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              instance.votes());

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 关闭举证阶段，打开投票 */
  public void closeEvidenceAndOpenVote(String instanceId) {
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              ChoiceStatus.participation_open,
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              instance.selectedOption(),
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              instance.votes());

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 记录玩家投票 */
  public void recordVote(String instanceId, String playerId, String optionId) {
    if (playerId == null || optionId == null) return;
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;
      if (!instance.options().containsKey(optionId)) return;

      Map<String, String> newVotes = new HashMap<>(instance.votes());
      newVotes.put(playerId, optionId);

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              instance.status(),
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              instance.selectedOption(),
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              newVotes);

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 选择选项 仅当选项存在且实例尚未选定时有意义；无效输入静默忽略 */
  public void selectOption(String instanceId, String optionId) {
    if (optionId == null) return;
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;
      // 选项必须存在于定义中，且实例不能重复选定
      if (!instance.options().containsKey(optionId) || instance.isSelected()) return;

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              ChoiceStatus.selected,
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              optionId,
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              instance.votes());

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 标记为临时缺省 仅当选项存在且实例尚未选定时有意义；无效输入静默忽略 */
  public void markProvisional(String instanceId, String optionId) {
    if (optionId == null) return;
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;
      // 选项必须存在于定义中，且实例不能重复选定
      if (!instance.options().containsKey(optionId) || instance.isSelected()) return;

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              ChoiceStatus.provisional,
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              optionId,
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              instance.votes());

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 完成决策（由PublicChoiceService调用） 若尚无选中选项，则根据投票统计自动选定获票最多的选项 */
  public void completeDecision(String instanceId) {
    choiceLock.lock();
    try {
      ChoiceInstance instance = choiceInstances.get(instanceId);
      if (instance == null) return;

      // 状态机校验：已在终结状态（selected/finalized/provisional）的决策不允许再次"完成"
      if (instance.status().isTerminal() || instance.status() == ChoiceStatus.provisional) {
        return;
      }

      String resolvedOption = instance.selectedOption();
      if (resolvedOption == null) {
        Map<String, Integer> voteCounts = instance.getVoteCounts();
        resolvedOption =
            voteCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
      }

      // 没有任何可解析的选项时，标记为 provisional（临时缺省，已知非终结但需后续处理）
      // 而不是保留旧状态让调用方误以为已完成
      ChoiceStatus newStatus =
          resolvedOption != null ? ChoiceStatus.selected : ChoiceStatus.provisional;

      ChoiceInstance newInstance =
          new ChoiceInstance(
              instance.instanceId(),
              instance.choiceId(),
              instance.epochRunId(),
              newStatus,
              instance.options(),
              instance.participants(),
              instance.minorityOpinions(),
              resolvedOption,
              instance.proposalVersion(),
              instance.createdAt(),
              System.currentTimeMillis(),
              instance.votes());

      choiceInstances.put(instanceId, newInstance);
    } finally {
      choiceLock.unlock();
    }
  }

  /** 生成实例ID */
  private String generateInstanceId() {
    return "choice_"
        + System.currentTimeMillis()
        + "_"
        + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 获取选择解决锁 */
  public Lock getChoiceLock() {
    return choiceLock;
  }

  /** 清理所有选择 */
  public void clear() {
    choiceDefinitions.clear();
    choiceInstances.clear();
  }
}
