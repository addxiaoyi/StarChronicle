package dev.starcore.starcore.cooking;

import dev.starcore.starcore.core.event.EventBridge;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/** 烹调管理器 管理食谱的注册、烹调任务和成果 */
public class CookingManager {

  private final Map<String, Recipe> recipes = new ConcurrentHashMap<>();
  private final Map<String, CookingSession> sessions = new ConcurrentHashMap<>();
  private final Map<String, Set<String>> playerRecipes = new ConcurrentHashMap<>();

  private final EventBridge eventBridge;

  public CookingManager() {
    this(null);
  }

  public CookingManager(EventBridge eventBridge) {
    this.eventBridge = eventBridge;
  }

  /** 注册食谱 */
  public void registerRecipe(Recipe recipe) {
    if (recipe == null || recipe.recipeId() == null) {
      throw new IllegalArgumentException("Recipe and its ID cannot be null");
    }
    recipes.put(recipe.recipeId(), recipe);
  }

  /** 卸载食谱 */
  public void unregisterRecipe(String recipeId) {
    recipes.remove(recipeId);
  }

  /** 获取食谱 */
  public Optional<Recipe> getRecipe(String recipeId) {
    return Optional.ofNullable(recipes.get(recipeId));
  }

  /** 获取所有食谱（返回不可变副本） */
  public Collection<Recipe> getAllRecipes() {
    return recipes.values().stream().toList();
  }

  /** 获取指定烹调站的食谱 */
  public Set<Recipe> getRecipesByStation(CookingStation station) {
    Set<Recipe> result = new HashSet<>();
    for (Recipe recipe : recipes.values()) {
      if (recipe.station() == station) {
        result.add(recipe);
      }
    }
    return result;
  }

  /** 开始烹调会话 */
  public CookingSession startCooking(
      String playerId, String recipeId, Map<String, Integer> ingredients) {
    if (playerId == null || recipeId == null || ingredients == null) {
      throw new IllegalArgumentException("Player ID, recipe ID, and ingredients cannot be null");
    }
    Recipe recipe = recipes.get(recipeId);
    if (recipe == null) {
      throw new IllegalArgumentException("Recipe not found: " + recipeId);
    }

    // 检查是否有足够食材
    if (!recipe.canCook(ingredients)) {
      throw new IllegalArgumentException("Not enough ingredients for recipe: " + recipeId);
    }

    String sessionId = generateSessionId();
    // 防御性拷贝，防止调用者修改原始Map影响会话
    Map<String, Integer> ingredientsCopy = new HashMap<>(ingredients);
    CookingSession session =
        CookingSession.builder(sessionId, playerId, recipeId)
            .startedAt(System.currentTimeMillis())
            .estimatedCompletion(System.currentTimeMillis() + recipe.cookingTime() * 1000L)
            .ingredients(ingredientsCopy)
            .build();

    sessions.put(sessionId, session);
    publishEvent(EventBridge.EventTypes.COOKING_START, session);
    return session;
  }

  /** 完成烹调 */
  public Optional<CookingResult> completeCooking(String sessionId, String playerId) {
    if (sessionId == null || playerId == null) return Optional.empty();

    CookingSession session = sessions.get(sessionId);
    if (session == null) return Optional.empty();
    // IDOR防护：只有会话创建者可以完成烹调
    if (!playerId.equals(session.playerId())) return Optional.empty();

    // 防止重复完成：先移除会话再处理，或使用CAS风格检查
    CookingSession removedSession = sessions.remove(sessionId);
    if (removedSession == null) return Optional.empty();

    Recipe recipe = recipes.get(session.recipeId());
    if (recipe == null) return Optional.empty();

    // 计算质量
    double quality = calculateQuality(session, recipe);
    boolean perfect = quality >= 0.9;
    boolean unlocked = quality >= 0.7;

    // 结果数量至少为1，防止负数/零值奖励
    int resultAmount = Math.max(1, (int) Math.round(recipe.resultAmount() * quality));

    CookingResult result =
        CookingResult.builder(sessionId, session.recipeId())
            .playerId(session.playerId())
            .quality(quality)
            .isPerfect(perfect)
            .isUnlocked(unlocked)
            .completedAt(System.currentTimeMillis())
            .resultItem(recipe.resultItem())
            .resultAmount(resultAmount)
            .build();

    // 标记玩家解锁食谱
    if (unlocked) {
      playerRecipes
          .computeIfAbsent(session.playerId(), k -> new HashSet<>())
          .add(session.recipeId());
      publishEvent(
          EventBridge.EventTypes.RECIPE_UNLOCK,
          Map.of(
              "playerId", session.playerId(),
              "recipeId", session.recipeId(),
              "recipe", recipe));
    }

    publishEvent(
        EventBridge.EventTypes.COOKING_COMPLETE,
        Map.of(
            "sessionId", sessionId,
            "playerId", session.playerId(),
            "recipeId", session.recipeId(),
            "quality", quality,
            "result", result));
    return Optional.of(result);
  }

  /** 计算烹调质量 */
  private double calculateQuality(CookingSession session, Recipe recipe) {
    // 简化的质量计算
    double base = 0.5;
    double ingredientBonus = Math.min(0.5, session.ingredients().size() * 0.1);
    // 防止除零：当烹调时间为0时不加时间因素
    long recipeTimeMs = recipe.cookingTime() * 1000L;
    double timeFactor = recipeTimeMs > 0 ? session.getElapsedTime() / (double) recipeTimeMs : 1.0;

    // 时间因素: 提前完成和超时都会降低质量
    if (timeFactor < 1.0) {
      // 提前完成获得加成
      base += 0.1;
    } else if (timeFactor > 2.0) {
      // 超时惩罚
      base -= 0.2;
    }

    return Math.max(0.0, Math.min(1.0, base + ingredientBonus));
  }

  /** 获取烹调会话 */
  public Optional<CookingSession> getCookingSession(String sessionId) {
    return Optional.ofNullable(sessions.get(sessionId));
  }

  /** 获取玩家已解锁的食谱（返回不可变副本） */
  public Set<Recipe> getPlayerUnlockedRecipes(String playerId) {
    if (playerId == null) return Set.of();
    Set<String> recipeIds = playerRecipes.getOrDefault(playerId, Set.of());
    if (recipeIds.isEmpty()) return Set.of();

    Set<Recipe> result = new HashSet<>();
    for (String id : recipeIds) {
      Recipe recipe = recipes.get(id);
      if (recipe != null) {
        result.add(recipe);
      }
    }
    return Set.copyOf(result);
  }

  /** 生成会话ID */
  private String generateSessionId() {
    return "cooking_"
        + System.currentTimeMillis()
        + "_"
        + UUID.randomUUID().toString().substring(0, 8);
  }

  /** 清理所有烹调数据 */
  public void clear() {
    recipes.clear();
    sessions.clear();
    playerRecipes.clear();
  }

  // ==================== 食谱发现与验证 ====================

  /** 发现食谱：通过尝试食材组合来发现新食谱 */
  public Optional<String> discoverRecipe(
      String playerId,
      String name,
      CookingStation station,
      Map<String, Integer> ingredients,
      Map<String, Integer> results) {
    if (playerId == null
        || name == null
        || station == null
        || ingredients == null
        || results == null) {
      return Optional.empty();
    }

    // 验证食材和结果合理性
    if (!validateIngredients(ingredients)) {
      return Optional.empty();
    }
    if (!validateResults(results)) {
      return Optional.empty();
    }

    String recipeId = generateRecipeId();

    // 计算难度
    int difficulty = calculateDifficulty(ingredients);

    Recipe.Builder builder = Recipe.builder(recipeId, name, station);
    // 防御性拷贝
    for (Map.Entry<String, Integer> ingredient : new HashMap<>(ingredients).entrySet()) {
      builder.addIngredient(ingredient.getKey(), ingredient.getValue());
    }

    Recipe recipe =
        builder
            .cookingTime(60 + difficulty * 10) // 基于难度计算时间
            .difficulty(difficulty)
            .result(
                results.entrySet().stream().findFirst().map(Map.Entry::getKey).orElse(""),
                results.entrySet().stream().findFirst().map(Map.Entry::getValue).orElse(1))
            .build();

    recipes.put(recipeId, recipe);

    // 记录玩家发现
    playerRecipes.computeIfAbsent(playerId, k -> new HashSet<>()).add(recipeId);

    return Optional.of(recipeId);
  }

  /** 验证食材组合是否合法 */
  private boolean validateIngredients(Map<String, Integer> ingredients) {
    if (ingredients == null || ingredients.isEmpty()) {
      return false;
    }

    // 检查是否有负数或过大的数量
    for (Map.Entry<String, Integer> entry : ingredients.entrySet()) {
      if (entry.getValue() == null || entry.getValue() <= 0 || entry.getValue() > 999) {
        return false;
      }
    }

    // 检查食材数量是否合理（最多10种食材）
    return ingredients.size() <= 10;
  }

  /** 验证结果是否合理 */
  private boolean validateResults(Map<String, Integer> results) {
    if (results == null || results.isEmpty()) {
      return false;
    }

    // 检查结果物品是否为正数
    for (Map.Entry<String, Integer> entry : results.entrySet()) {
      if (entry.getValue() == null || entry.getValue() <= 0 || entry.getValue() > 99) {
        return false;
      }
    }

    // 检查结果数量是否合理（最多5种结果）
    return results.size() <= 5;
  }

  /** 计算食谱难度 */
  private int calculateDifficulty(Map<String, Integer> ingredients) {
    int difficulty = 1;

    // 食材数量越多，难度越高
    difficulty += ingredients.size() - 1;

    // 稀有食材增加难度
    for (String ingredient : ingredients.keySet()) {
      if (ingredient.contains("rare") || ingredient.contains("legendary")) {
        difficulty += 2;
      } else if (ingredient.contains("uncommon")) {
        difficulty += 1;
      }
    }

    return Math.min(10, Math.max(1, difficulty));
  }

  /** 检查玩家是否可以制作指定食谱 */
  public boolean canPlayerCraft(String playerId, String recipeId) {
    Set<String> unlockedRecipes = playerRecipes.getOrDefault(playerId, Set.of());
    return unlockedRecipes.contains(recipeId);
  }

  /** 获取玩家可制作的食谱 */
  public Set<Recipe> getPlayerAvailableRecipes(String playerId) {
    Set<String> unlockedIds = playerRecipes.getOrDefault(playerId, Set.of());
    if (unlockedIds.isEmpty()) return Set.of();

    Set<Recipe> result = new HashSet<>();
    for (String id : unlockedIds) {
      Recipe recipe = recipes.get(id);
      if (recipe != null) {
        result.add(recipe);
      }
    }
    return result;
  }

  /** 验证食谱组合 */
  public RecipeValidationResult validateRecipe(
      String recipeId, Map<String, Integer> availableIngredients) {
    Recipe recipe = recipes.get(recipeId);
    if (recipe == null) {
      return new RecipeValidationResult(
          false, "食谱不存在", Collections.emptyList(), Collections.emptyList());
    }

    List<String> missing = new ArrayList<>();
    List<String> insufficient = new ArrayList<>();

    for (Map.Entry<String, Integer> required : recipe.ingredientAmounts().entrySet()) {
      String ingredient = required.getKey();
      int requiredAmount = required.getValue();
      int available = availableIngredients.getOrDefault(ingredient, 0);

      if (available == 0) {
        missing.add(ingredient);
      } else if (available < requiredAmount) {
        insufficient.add(ingredient + " (需要: " + requiredAmount + ", 拥有: " + available + ")");
      }
    }

    boolean valid = missing.isEmpty() && insufficient.isEmpty();
    String message;
    if (missing.isEmpty() && !insufficient.isEmpty()) {
      message = "部分食材不足: " + String.join(", ", insufficient);
    } else if (!missing.isEmpty()) {
      message = "缺少食材: " + String.join(", ", missing);
    } else {
      message = "食材充足";
    }

    return new RecipeValidationResult(valid, message, missing, insufficient);
  }

  /** 获取食谱筛选器结果 */
  public List<Recipe> filterRecipes(Predicate<Recipe> filter) {
    List<Recipe> result = new ArrayList<>();
    for (Recipe recipe : recipes.values()) {
      if (filter.test(recipe)) {
        result.add(recipe);
      }
    }
    return result;
  }

  /** 根据难度范围获取食谱 */
  public List<Recipe> getRecipesByDifficulty(int minDifficulty, int maxDifficulty) {
    return filterRecipes(r -> r.difficulty() >= minDifficulty && r.difficulty() <= maxDifficulty);
  }

  /** 根据食谱站获取食谱 */
  public List<Recipe> getRecipesByStationType(CookingStation station) {
    return filterRecipes(r -> r.station() == station);
  }

  /** 生成食谱ID */
  private String generateRecipeId() {
    return "recipe_"
        + System.currentTimeMillis()
        + "_"
        + UUID.randomUUID().toString().substring(0, 8);
  }

  // ==================== 辅助记录 ====================

  /** 食谱验证结果 */
  public record RecipeValidationResult(
      boolean valid,
      String message,
      List<String> missingIngredients,
      List<String> insufficientIngredients) {}

  /** 发布事件 */
  private void publishEvent(String eventType, Object eventData) {
    if (eventBridge != null) {
      eventBridge.publish(eventType, eventData);
    }
  }

  /** 获取已注册食谱总数 */
  public int getRecipeCount() {
    return getAllRecipes().size();
  }

  /** 获取活跃烹饪会话数 */
  public int getActiveSessionCount() {
    return sessions.size();
  }

  /** 获取指定玩家已解锁的食谱数量 */
  public int getPlayerUnlockedRecipeCount(String playerId) {
    return getPlayerUnlockedRecipes(playerId).size();
  }
}
