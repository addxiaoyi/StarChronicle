package dev.starcore.starcore.core.database;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.CoreErrorCode;
import org.flywaydb.core.api.MigrationInfo;
import org.flywaydb.core.api.configuration.FluentConfiguration;

/**
 * 增强的数据库迁移服务
 *
 * <p>功能： - Flyway 迁移执行 - 迁移状态追踪 - 完整迁移日志 - 备份管理
 *
 * <p>支持的数据库：SQLite, MySQL
 */
public class DatabaseMigrationService {

  private static final int MIGRATION_LOG_RETENTION_DAYS = 30;
  private static final String LEGACY_V9_CHECKSUM = "1913042039";
  private static final int CURRENT_V9_CHECKSUM = 1194694866;

  private final Logger logger;
  private final DataSource dataSource;
  private final String databaseType;
  private final Path logDirectory;
  private final Path backupDirectory;

  // 迁移日志缓存
  private final List<MigrationRecord> migrationHistory = new CopyOnWriteArrayList<>();

  public DatabaseMigrationService(DataSource dataSource, String databaseType, Logger logger) {
    this.dataSource = dataSource;
    this.databaseType = databaseType;
    this.logger = logger;
    this.logDirectory = this.determineLogDirectory();
    this.backupDirectory = this.determineBackupDirectory();
    this.ensureDirectoriesExist();
    this.removeExpiredMigrationLogs();
  }

  private Path determineLogDirectory() {
    String pluginDir = System.getProperty("starcore.plugin.dir");
    if (pluginDir != null) {
      return Paths.get(pluginDir, "logs", "migration");
    }
    return Paths.get(System.getProperty("user.dir"), "logs", "migration");
  }

  private Path determineBackupDirectory() {
    String pluginDir = System.getProperty("starcore.plugin.dir");
    if (pluginDir != null) {
      return Paths.get(pluginDir, "backups", "migration");
    }
    return Paths.get(System.getProperty("user.dir"), "backups", "migration");
  }

  private void ensureDirectoriesExist() {
    try {
      Files.createDirectories(logDirectory);
      Files.createDirectories(backupDirectory);
    } catch (IOException e) {
      logger.warning("无法创建迁移日志目录: " + e.getMessage());
    }
  }

  /**
   * 执行数据库迁移
   *
   * @return 迁移结果信息
   */
  public MigrationResult migrate() {
    return migrate(null, false);
  }

  public MigrationResult migrate(boolean allowKnownLegacyChecksumRepair) {
    return migrate(null, allowKnownLegacyChecksumRepair);
  }

  /**
   * 执行数据库迁移到指定版本
   *
   * @param targetVersion 目标版本，为空则迁移到最新
   * @return 迁移结果信息
   */
  public MigrationResult migrate(String targetVersion) {
    return migrate(targetVersion, false);
  }

  private MigrationResult migrate(String targetVersion, boolean allowKnownLegacyChecksumRepair) {
    long startTime = System.currentTimeMillis();
    MigrationRecord record = new MigrationRecord();
    record.type = MigrationType.MIGRATE;
    record.startTime = startTime;
    Flyway flyway = null;

    try {
      logger.info("开始数据库迁移检查...");

      FluentConfiguration config = baseConfiguration();

      if (targetVersion != null && !targetVersion.isEmpty()) {
        config.target(targetVersion);
      }

      flyway = config.load();
      var migrateResult = flyway.migrate();

      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = true;
      record.migrationsExecuted = migrateResult.migrationsExecuted;

      // 获取版本信息 - 通过查询数据库表
      record.targetVersion = getCurrentVersionFromDb();

      if (record.success) {
        if (record.migrationsExecuted > 0) {
          logger.info(
              String.format(
                  "数据库迁移完成: 执行了 %d 个迁移脚本 (目标版本: %s)",
                  record.migrationsExecuted, record.targetVersion));
        } else {
          logger.info("数据库已是最新版本，无需迁移");
        }
      } else {
        logger.warning("数据库迁移失败");
        record.errorMessage = "迁移执行失败";
      }

      logMigrationRecord(record);
      return buildResult(record);

    } catch (Exception e) {
      if (allowKnownLegacyChecksumRepair && isKnownLegacyChecksumMismatch(flyway)) {
        logger.warning("检测到已知历史 V9 校验和，仅更新 V9 后重试迁移");
        if (repairKnownV9Checksum()) {
          return migrate(targetVersion, false);
        }
      }
      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = false;
      record.errorMessage = e.getMessage();
      logMigrationRecord(record);

      logger.severe("数据库迁移失败: " + e.getMessage());
      return buildResult(record);
    }
  }

  private boolean repairKnownV9Checksum() {
    try (Connection connection = dataSource.getConnection();
        PreparedStatement statement =
            connection.prepareStatement(
                "UPDATE starcore_schema_history SET checksum = ? "
                    + "WHERE version = '9' AND success = 1 AND checksum = ?")) {
      statement.setInt(1, CURRENT_V9_CHECKSUM);
      statement.setInt(2, Integer.parseInt(LEGACY_V9_CHECKSUM));
      return statement.executeUpdate() == 1;
    } catch (SQLException exception) {
      logger.warning("无法更新已知 V9 校验和: " + exception.getMessage());
      return false;
    }
  }

  private boolean isKnownLegacyChecksumMismatch(Flyway flyway) {
    if (flyway == null) {
      return false;
    }
    try {
      Flyway validationFlyway =
          Flyway.configure(DatabaseMigrationService.class.getClassLoader())
              .configuration(flyway.getConfiguration())
              .ignoreMigrationPatterns("*:future", "*:pending")
              .load();
      var validation = validationFlyway.validateWithResult();
      if (validation.validationSuccessful || validation.invalidMigrations.size() != 1) {
        return false;
      }
      var invalid = validation.invalidMigrations.get(0);
      if (!"9".equals(invalid.version)
          || invalid.errorDetails == null
          || invalid.errorDetails.errorCode != CoreErrorCode.CHECKSUM_MISMATCH) {
        return false;
      }
      var matches =
          Arrays.stream(flyway.info().all())
              .filter(
                  info -> info.getVersion() != null && "9".equals(info.getVersion().getVersion()))
              .toList();
      return matches.size() == 1
          && Objects.equals(
              matches.get(0).getAppliedChecksum(), Integer.valueOf(LEGACY_V9_CHECKSUM))
          && Objects.equals(matches.get(0).getResolvedChecksum(), CURRENT_V9_CHECKSUM);
    } catch (RuntimeException exception) {
      logger.warning("无法验证已知 V9 校验和: " + exception.getMessage());
      return false;
    }
  }

  /** 从数据库直接获取当前版本 */
  String getCurrentVersionFromDb() {
    String query =
        "SELECT version FROM starcore_schema_history WHERE success = 1 "
            + "ORDER BY installed_rank DESC LIMIT 1";
    try (Connection connection = dataSource.getConnection();
        Statement statement = connection.createStatement()) {
      try (ResultSet result = statement.executeQuery(query)) {
        if (result.next()) {
          String version = result.getString(1);
          return version == null || version.isBlank() ? "baseline" : version;
        }
      }
      return "baseline";
    } catch (SQLException exception) {
      if ("42S02".equals(exception.getSQLState()) || exception.getErrorCode() == 1146) {
        return "baseline";
      }
      logger.fine("Failed to read database version: " + exception.getMessage());
      return "unknown";
    } catch (RuntimeException exception) {
      logger.fine("Failed to read database version: " + exception.getMessage());
      return "unknown";
    }
  }

  /**
   * 验证数据库状态
   *
   * @return true 如果数据库与迁移脚本匹配
   */
  public boolean validate() {
    try {
      Flyway flyway = baseConfiguration().load();
      flyway.validate();
      logger.info("数据库状态验证通过");
      return true;

    } catch (Exception e) {
      logger.warning("数据库状态验证失败: " + e.getMessage());
      return false;
    }
  }

  /**
   * 修复数据库状态（用于修复损坏的迁移历史）
   *
   * @param baselineVersion 基准版本
   * @return 修复结果
   */
  public MigrationResult repair(String baselineVersion) {
    long startTime = System.currentTimeMillis();
    MigrationRecord record = new MigrationRecord();
    record.type = MigrationType.REPAIR;
    record.startTime = startTime;

    try {
      logger.info("开始修复数据库状态 (baseline: " + baselineVersion + ")...");

      Flyway flyway =
          baseConfiguration().baselineVersion(baselineVersion).baselineOnMigrate(true).load();

      flyway.repair();

      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = true;
      record.targetVersion = getCurrentVersionFromDb();

      logger.info("数据库状态修复完成");

      logMigrationRecord(record);
      return buildResult(record);

    } catch (Exception e) {
      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = false;
      record.errorMessage = e.getMessage();
      logMigrationRecord(record);

      logger.severe("数据库修复失败: " + e.getMessage());
      return buildResult(record);
    }
  }

  /**
   * 回滚迁移
   *
   * @param count 回滚的迁移数量
   * @return 迁移结果
   */
  public MigrationResult undo(int count) {
    long startTime = System.currentTimeMillis();
    MigrationRecord record = new MigrationRecord();
    record.type = MigrationType.MIGRATE;
    record.startTime = startTime;

    try {
      logger.info("开始回滚迁移 (数量: " + count + ")...");

      Flyway flyway = baseConfiguration().load();
      // Flyway Basic 不支持 undo，需要使用 Flyway Teams
      // 这里模拟回滚操作，输出信息
      logger.info("Flyway Community 版本不支持回滚功能，请使用 Flyway Teams 版本");

      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = true;
      record.migrationsExecuted = 0;
      record.targetVersion = getCurrentVersionFromDb();

      logMigrationRecord(record);
      return buildResult(record);

    } catch (Exception e) {
      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = false;
      record.errorMessage = e.getMessage();
      logMigrationRecord(record);

      logger.severe("回滚迁移失败: " + e.getMessage());
      return buildResult(record);
    }
  }

  /**
   * 重做迁移 - 重新执行最近一次迁移
   *
   * @return 迁移结果
   */
  public MigrationResult redo() {
    long startTime = System.currentTimeMillis();
    MigrationRecord record = new MigrationRecord();
    record.type = MigrationType.MIGRATE;
    record.startTime = startTime;

    try {
      logger.info("开始重做迁移...");

      // 获取最近一次成功的迁移版本
      String lastVersion = null;
      try (Connection conn = dataSource.getConnection();
          Statement stmt = conn.createStatement();
          ResultSet rs =
              stmt.executeQuery(
                  "SELECT version FROM starcore_schema_history WHERE success = 1 ORDER BY"
                      + " installed_rank DESC LIMIT 1")) {
        if (rs.next()) {
          lastVersion = rs.getString("version");
        }
      }

      if (lastVersion == null || "baseline".equals(lastVersion)) {
        logger.info("没有可重做的迁移");
        record.executionTimeMs = System.currentTimeMillis() - startTime;
        record.success = true;
        record.migrationsExecuted = 0;
        logMigrationRecord(record);
        return buildResult(record);
      }

      // 删除最近一次迁移的记录（这样 Flyway 会认为需要重新执行）
      try (Connection conn = dataSource.getConnection();
          PreparedStatement stmt =
              conn.prepareStatement("DELETE FROM starcore_schema_history WHERE version = ?")) {
        stmt.setString(1, lastVersion);
        stmt.executeUpdate();
        logger.info("已删除迁移记录: " + lastVersion);
      }

      // 重新执行迁移
      Flyway flyway = baseConfiguration().load();
      var migrateResult = flyway.migrate();

      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = true;
      record.migrationsExecuted = migrateResult.migrationsExecuted;
      record.targetVersion = getCurrentVersionFromDb();

      logger.info("重做迁移完成");
      logMigrationRecord(record);
      return buildResult(record);

    } catch (Exception e) {
      record.executionTimeMs = System.currentTimeMillis() - startTime;
      record.success = false;
      record.errorMessage = e.getMessage();
      logMigrationRecord(record);

      logger.severe("重做迁移失败: " + e.getMessage());
      return buildResult(record);
    }
  }

  /**
   * 获取当前数据库版本
   *
   * @return 版本字符串，如果获取失败返回 null
   */
  public String getCurrentVersion() {
    return getCurrentVersionFromDb();
  }

  /**
   * 获取所有迁移信息
   *
   * @return 迁移信息列表
   */
  public List<MigrationInfoEntry> getAllMigrations() {
    List<MigrationInfoEntry> entries = new ArrayList<>();
    String query =
        "SELECT version, description, type, installed_on, execution_time "
            + "FROM starcore_schema_history WHERE success = 1 ORDER BY installed_on ASC";
    try (Connection connection = dataSource.getConnection();
        Statement statement = connection.createStatement();
        ResultSet result = statement.executeQuery(query)) {
      while (result.next()) {
        entries.add(
            new MigrationInfoEntry(
                result.getString("version") != null ? result.getString("version") : "baseline",
                result.getString("description") != null ? result.getString("description") : "",
                result.getString("type") != null ? result.getString("type") : "SQL",
                result.getTimestamp("installed_on") != null
                    ? result.getTimestamp("installed_on").getTime()
                    : 0,
                "SUCCESS",
                result.getInt("execution_time")));
      }
    } catch (SQLException exception) {
      if (!"42S02".equals(exception.getSQLState()) && exception.getErrorCode() != 1146) {
        logger.warning("Failed to read migration history: " + exception.getMessage());
      }
    } catch (RuntimeException exception) {
      logger.warning("Failed to read migration history: " + exception.getMessage());
    }
    return entries;
  }

  /**
   * 获取迁移历史记录
   *
   * @return 迁移历史列表
   */
  public List<MigrationRecord> getMigrationHistory() {
    return List.copyOf(migrationHistory);
  }

  /**
   * 导出迁移历史到文件
   *
   * @param filePath 输出文件路径
   * @return 是否成功
   */
  public boolean exportHistory(Path filePath) {
    try (PrintWriter writer =
        new PrintWriter(
            new OutputStreamWriter(Files.newOutputStream(filePath), StandardCharsets.UTF_8))) {

      writer.println("# StarCore 数据库迁移历史");
      writer.println("# 导出时间: " + Instant.now());
      writer.println("# 数据库类型: " + databaseType);
      writer.println();
      writer.println("| 版本 | 类型 | 开始时间 | 耗时(ms) | 状态 | 错误信息 |");
      writer.println("|------|------|----------|----------|------|----------|");

      for (MigrationRecord record : migrationHistory) {
        writer.printf(
            "| %s | %s | %s | %d | %s | %s |%n",
            record.targetVersion != null ? record.targetVersion : "N/A",
            record.type.name(),
            Instant.ofEpochMilli(record.startTime).toString(),
            record.executionTimeMs,
            record.success ? "成功" : "失败",
            record.errorMessage != null ? record.errorMessage : "");
      }

      return true;

    } catch (IOException e) {
      logger.warning("导出迁移历史失败: " + e.getMessage());
      return false;
    }
  }

  /**
   * 创建数据库备份
   *
   * @param prefix 备份文件前缀
   * @return 是否成功
   */
  public boolean createBackup(String prefix) {
    try {
      String backupFileName =
          String.format("%s_%s_%d.sql", prefix, databaseType, System.currentTimeMillis());
      Path backupPath = backupDirectory.resolve(backupFileName);

      // 根据数据库类型执行不同的备份逻辑
      if ("MYSQL".equalsIgnoreCase(databaseType)) {
        return backupMySQL(backupPath);
      } else {
        return backupSQLite(backupPath);
      }

    } catch (Exception e) {
      logger.warning("创建备份失败: " + e.getMessage());
      return false;
    }
  }

  private boolean backupMySQL(Path backupPath) throws SQLException {
    logger.warning("MySQL 备份未执行：未配置外部 mysqldump 工具，未创建备份文件");
    return false;
  }

  private boolean backupSQLite(Path backupPath) throws SQLException {
    try (Connection conn = dataSource.getConnection();
        Statement stmt = conn.createStatement()) {

      // 使用 SQLite 的 .backup 命令
      ResultSet rs =
          stmt.executeQuery("SELECT file FROM pragma_database_list() WHERE name = 'main'");
      if (rs.next()) {
        Path dbPath = Paths.get(rs.getString("file"));
        Files.copy(dbPath, backupPath, StandardCopyOption.REPLACE_EXISTING);
        logger.info("SQLite 备份已创建: " + backupPath);
        return true;
      }

    } catch (IOException e) {
      logger.warning("SQLite 备份失败: " + e.getMessage());
    }
    return false;
  }

  /**
   * 获取迁移状态摘要
   *
   * @return 状态摘要
   */
  public MigrationSummary getSummary() {
    try {
      List<MigrationInfoEntry> allMigrations = getAllMigrations();
      List<MigrationInfoEntry> pendingMigrations = getPendingMigrations();

      return new MigrationSummary(
          getCurrentVersionFromDb(),
          allMigrations.size(),
          pendingMigrations.size(),
          allMigrations.size() + pendingMigrations.size(),
          calculateAverageExecutionTime());

    } catch (Exception e) {
      logger.warning("获取迁移摘要失败: " + e.getMessage());
      return new MigrationSummary("unknown", 0, 0, 0, 0);
    }
  }

  private List<MigrationInfoEntry> getPendingMigrations() {
    try {
      MigrationInfo[] pendingMigrations = baseConfiguration().load().info().pending();
      List<MigrationInfoEntry> entries = new ArrayList<>(pendingMigrations.length);
      for (MigrationInfo migration : pendingMigrations) {
        entries.add(
            new MigrationInfoEntry(
                migration.getVersion() != null ? migration.getVersion().getVersion() : "repeatable",
                migration.getDescription() != null ? migration.getDescription() : "",
                migration.getType() != null ? migration.getType().name() : "SQL",
                migration.getInstalledOn() != null ? migration.getInstalledOn().getTime() : 0,
                migration.getState() != null ? migration.getState().getDisplayName() : "PENDING",
                migration.getExecutionTime() != null ? migration.getExecutionTime() : 0));
      }
      return entries;
    } catch (RuntimeException exception) {
      logger.warning("获取待执行迁移失败: " + exception.getMessage());
      return List.of();
    }
  }

  private void removeExpiredMigrationLogs() {
    Instant cutoff = Instant.now().minus(MIGRATION_LOG_RETENTION_DAYS, ChronoUnit.DAYS);
    try (DirectoryStream<Path> logs = Files.newDirectoryStream(logDirectory, "migration_*.log")) {
      for (Path log : logs) {
        if (!Files.isRegularFile(log, LinkOption.NOFOLLOW_LINKS)) {
          continue;
        }
        if (Files.getLastModifiedTime(log, LinkOption.NOFOLLOW_LINKS)
            .toInstant()
            .isBefore(cutoff)) {
          Files.delete(log);
        }
      }
    } catch (IOException e) {
      logger.warning("无法清理过期迁移日志 " + logDirectory + ": " + e.getMessage());
    }
  }

  private long calculateAverageExecutionTime() {
    if (migrationHistory.isEmpty()) {
      return 0;
    }
    long total =
        migrationHistory.stream().filter(r -> r.success).mapToLong(r -> r.executionTimeMs).sum();
    return total / migrationHistory.size();
  }

  private FluentConfiguration baseConfiguration() {
    return Flyway.configure(DatabaseMigrationService.class.getClassLoader())
        .dataSource(dataSource)
        .locations("classpath:db/migration")
        .table("starcore_schema_history")
        .baselineOnMigrate(true)
        .baselineVersion("0")
        .validateOnMigrate(true)
        .outOfOrder(false)
        .encoding(StandardCharsets.UTF_8);
  }

  private void logMigrationRecord(MigrationRecord record) {
    migrationHistory.add(record);

    // 写入日志文件
    try {
      Path logFile = logDirectory.resolve("migration_" + getDateString() + ".log");
      String logLine =
          String.format(
              "[%s] %s | %s | %dms | %s | %s%n",
              Instant.ofEpochMilli(record.startTime),
              record.type.name(),
              record.targetVersion != null ? record.targetVersion : "N/A",
              record.executionTimeMs,
              record.success ? "SUCCESS" : "FAILURE",
              record.errorMessage != null ? record.errorMessage : "");

      Files.writeString(logFile, logLine, StandardOpenOption.CREATE, StandardOpenOption.APPEND);

    } catch (IOException e) {
      logger.warning("写入迁移日志失败: " + e.getMessage());
    }

    // 写入数据库迁移日志表
    writeMigrationLogToDb(record);
  }

  private void writeMigrationLogToDb(MigrationRecord record) {
    String insertSql =
        """
        INSERT INTO starcore_migration_log
        (migration_version, migration_name, migration_type, executed_at,
         execution_time_ms, success, error_message)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

    try (Connection connection = dataSource.getConnection();
        PreparedStatement statement = connection.prepareStatement(insertSql)) {
      statement.setString(1, record.targetVersion != null ? record.targetVersion : "N/A");
      statement.setString(2, "Flyway " + record.type.name());
      statement.setString(3, record.type.name());
      statement.setLong(4, record.startTime);
      statement.setLong(5, record.executionTimeMs);
      statement.setBoolean(6, record.success);
      statement.setString(7, record.errorMessage);
      statement.executeUpdate();
    } catch (SQLException exception) {
      if (!"42S02".equals(exception.getSQLState()) && exception.getErrorCode() != 1146) {
        logger.fine("Failed to write migration audit row: " + exception.getMessage());
      }
    } catch (RuntimeException exception) {
      logger.fine("Failed to write migration audit row: " + exception.getMessage());
    }
  }

  private String getDateString() {
    return java.time.LocalDate.now().toString();
  }

  private MigrationResult buildResult(MigrationRecord record) {
    return new MigrationResult(
        record.success,
        record.migrationsExecuted,
        record.targetVersion,
        record.executionTimeMs,
        record.errorMessage);
  }

  // ========== 内部类 ==========

  /** 迁移类型枚举 */
  public enum MigrationType {
    MIGRATE, // 执行迁移
    REPAIR, // 修复
    VALIDATE, // 验证
    BASELINE // 基线
  }

  /** 迁移记录 */
  public static class MigrationRecord {
    public MigrationType type;
    public long startTime;
    public long executionTimeMs;
    public boolean success;
    public int migrationsExecuted;
    public String targetVersion;
    public String errorMessage;
  }

  /** 迁移信息条目 */
  public static class MigrationInfoEntry {
    public final String version;
    public final String description;
    public final String type;
    public final long installedOn;
    public final String state;
    public final long executionTime;

    public MigrationInfoEntry(
        String version,
        String description,
        String type,
        long installedOn,
        String state,
        long executionTime) {
      this.version = version;
      this.description = description;
      this.type = type;
      this.installedOn = installedOn;
      this.state = state;
      this.executionTime = executionTime;
    }
  }

  /** 迁移摘要 */
  public static class MigrationSummary {
    public final String currentVersion;
    public final int appliedCount;
    public final int pendingCount;
    public final int totalCount;
    public final long averageExecutionTimeMs;

    public MigrationSummary(
        String currentVersion,
        int appliedCount,
        int pendingCount,
        int totalCount,
        long averageExecutionTimeMs) {
      this.currentVersion = currentVersion;
      this.appliedCount = appliedCount;
      this.pendingCount = pendingCount;
      this.totalCount = totalCount;
      this.averageExecutionTimeMs = averageExecutionTimeMs;
    }
  }

  /** 迁移结果（扩展版） */
  public static class MigrationResult {
    public final boolean success;
    public final int migrationsExecuted;
    public final String targetVersion;
    public final long executionTimeMs;
    public final String errorMessage;

    public MigrationResult(boolean success, int migrationsExecuted, String targetVersion) {
      this(success, migrationsExecuted, targetVersion, 0, null);
    }

    public MigrationResult(
        boolean success,
        int migrationsExecuted,
        String targetVersion,
        long executionTimeMs,
        String errorMessage) {
      this.success = success;
      this.migrationsExecuted = migrationsExecuted;
      this.targetVersion = targetVersion;
      this.executionTimeMs = executionTimeMs;
      this.errorMessage = errorMessage;
    }

    public boolean hasError() {
      return errorMessage != null;
    }

    @Override
    public String toString() {
      return String.format(
          "MigrationResult[success=%s, migrations=%d, version=%s, time=%dms]",
          success, migrationsExecuted, targetVersion, executionTimeMs);
    }
  }
}
