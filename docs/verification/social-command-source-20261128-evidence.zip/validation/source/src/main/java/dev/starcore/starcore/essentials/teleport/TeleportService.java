package dev.starcore.starcore.essentials.teleport;

import dev.starcore.starcore.core.extension.ExtensionRegistry;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.CancelContext;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.CancelResult;
import dev.starcore.starcore.essentials.teleport.extension.TeleportCancelExtensionPoint.TeleportType;
import dev.starcore.starcore.essentials.warp.WarpService;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Teleport entry points require the initiating player owner; cross-player work is scheduled
 * separately.
 */
public final class TeleportService {
  private static final long TPA_REQUEST_TIMEOUT_MILLIS = 60_000L;
  private static final long TPA_REQUEST_TIMEOUT_TICKS = 60L * 20L;

  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final TeleportConfig config;
  private final EssentialsPermissions permissions;

  // 引用 HomeService（用于获取家园数据）
  private HomeService homeService;

  // 引用 WarpService（用于获取星港数据）
  private WarpService warpService;

  // 主城传送点（星核）
  private volatile Location spawnLocation;
  private volatile boolean closed;

  // 传送请求（带去重）
  private final Map<UUID, TeleportRequest> teleportRequests = new ConcurrentHashMap<>();

  // 最后一次传送位置（用于 /back）
  private final Map<UUID, Location> lastLocations = new ConcurrentHashMap<>();

  // 待执行的延迟传送；用于按配置响应移动、受伤和退出
  private final Map<UUID, PendingTeleport> pendingTeleports = new ConcurrentHashMap<>();

  // TPA 请求冷却（防止刷屏）
  private final Map<UUID, Long> tpaCooldowns = new ConcurrentHashMap<>();

  // 设置主城的权限节点（可配置）
  private String setSpawnPermission = "starcore.setspawn";

  public TeleportService(Plugin plugin, FoliaCompatScheduler scheduler, TeleportConfig config) {
    this(plugin, scheduler, config, EssentialsPermissions.defaults());
  }

  public TeleportService(
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      TeleportConfig config,
      EssentialsPermissions permissions) {
    this.plugin = plugin;
    this.scheduler = scheduler;
    this.config = config;
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
    this.setSpawnPermission = this.permissions.setSpawn();
  }

  /** 设置设置主城的权限节点 */
  public void setSetSpawnPermission(String permission) {
    this.setSpawnPermission = permission;
  }

  /** 获取设置主城的权限节点 */
  public String getSetSpawnPermission() {
    return setSpawnPermission;
  }

  /** 检查玩家是否有设置主城的权限 */
  public boolean canSetSpawn(Player player) {
    return EssentialsPermissions.permits(player, setSpawnPermission);
  }

  /** 设置 HomeService 引用 */
  public void setHomeService(HomeService homeService) {
    this.homeService = homeService;
  }

  /** 设置 WarpService 引用 */
  public void setWarpService(WarpService warpService) {
    this.warpService = warpService;
  }

  /** 记录玩家最后位置（传送前调用） */
  public void recordLastLocation(Player player) {
    if (!isCurrentPlayer(player)) return;
    Location location = player.getLocation();
    if (location == null) {
      return;
    }
    Location snapshot = location.clone();
    if (snapshot != null) {
      lastLocations.put(player.getUniqueId(), snapshot);
    }
  }

  /** 传送到主城（星核）- 带延迟 */
  public void teleportToSpawn(Player player) {
    if (!isCurrentPlayer(player)) return;
    Location destination = getSpawnLocation();
    if (destination == null) {
      player.sendMessage(Component.text("主城传送点未设置", NamedTextColor.RED));
      return;
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text("将在 " + config.spawnDelay() + " 秒后传送到主城...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        pending ->
            performTeleport(
                player, pending, destination, "欢迎来到主城！", "传送到主城失败：目标世界不可用或传送被取消", "spawn"),
        config.spawnDelay() * 20L,
        "传送到主城失败：服务器无法完成该操作",
        "spawn");
  }

  /** 传送到家园（锚点）- 带延迟 */
  public void teleportToHome(Player player, String homeName) {
    if (!isCurrentPlayer(player)) return;
    if (homeService == null) {
      player.sendMessage(Component.text("家园系统未初始化", NamedTextColor.RED));
      return;
    }

    // 获取家园位置
    Optional<Location> homeOpt = homeService.getHome(player.getUniqueId(), homeName);
    if (homeOpt.isEmpty()) {
      player.sendMessage(Component.text("家园 '" + homeName + "' 不存在", NamedTextColor.RED));
      return;
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text(
            "将在 " + config.homeDelay() + " 秒后传送到家园: " + homeName + "...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        pending ->
            performTeleport(
                player,
                pending,
                homeOpt.get(),
                "已传送到家园: " + homeName,
                "传送到家园失败：目标世界不可用或传送被取消",
                "home"),
        config.homeDelay() * 20L,
        "传送到家园失败：服务器无法完成该操作",
        "home");
  }

  /** 传送到星港 - 带延迟和权限检查 */
  public void teleportToWarp(Player player, String warpName) {
    if (!isCurrentPlayer(player)) return;
    if (!canUseWarp(player)) {
      player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
      return;
    }

    if (warpService == null) {
      player.sendMessage(Component.text("星港系统未初始化", NamedTextColor.RED));
      return;
    }

    // 获取星港位置
    Optional<Location> warpOpt = warpService.getWarp(warpName);
    if (warpOpt.isEmpty()) {
      player.sendMessage(Component.text("星港 '" + warpName + "' 不存在", NamedTextColor.RED));
      return;
    }

    Location[] warpLocations = {warpOpt.get()};
    // 扩展点拦截传送取消
    try {
      ExtensionRegistry registry = ExtensionRegistry.getInstance();
      CancelContext ctx = new CancelContext(player, warpLocations[0], TeleportType.WARP);
      CancelResult extResult = registry.execute("teleport_cancel", ctx);
      if (extResult.cancelled()) {
        player.sendMessage(Component.text("传送被取消: " + extResult.reason(), NamedTextColor.RED));
        return;
      }
      if (extResult.decoratedDestination() != null) {
        warpLocations[0] = extResult.decoratedDestination();
      }
    } catch (Exception e) {
      // 扩展点失败时继续原逻辑
    }

    // 记录当前位置用于 /back
    recordLastLocation(player);

    player.sendMessage(
        Component.text(
            "将在 " + config.warpDelay() + " 秒后传送到星港: " + warpName + "...", NamedTextColor.YELLOW));

    Location finalDestination = warpLocations[0];
    scheduleDelayedTeleport(
        player,
        pending ->
            performTeleport(
                player,
                pending,
                finalDestination,
                "已传送到星港: " + warpName,
                "传送到星港失败：目标世界不可用或传送被取消",
                "warp"),
        config.warpDelay() * 20L,
        "传送到星港失败：服务器无法完成该操作",
        "warp");
  }

  /** Whether the player may use a warp, including the configured empty-node policy. */
  public boolean canUseWarp(Player player) {
    return EssentialsPermissions.permits(player, permissions.warpUse());
  }

  /** Whether the player may use the spawn teleport command. */
  public boolean canUseSpawn(Player player) {
    return EssentialsPermissions.permits(player, permissions.spawnUse());
  }

  /** 玩家传送请求 - 带去重和冷却 */
  /** 获取 TPA 冷却剩余秒数，0 表示无冷却 */
  public long getRemainingCooldownSeconds(UUID requesterId) {
    Long last = tpaCooldowns.get(requesterId);
    if (last == null) return 0;
    long remainingMillis = remainingCooldownMillis(last, System.currentTimeMillis());
    return remainingMillis == 0 ? 0 : (remainingMillis + 999) / 1000;
  }

  /** 获取当前待处理传送请求数 */
  public int pendingRequestCount() {
    long now = System.currentTimeMillis();
    return (int)
        teleportRequests.values().stream()
            .filter(request -> !isRequestExpired(request, now))
            .count();
  }

  public void sendTeleportRequest(Player requester, Player target) {
    sendRequest(requester, target, false);
  }

  /** The recipient can only consume the request addressed to this exact player session. */
  public void acceptTeleportRequest(Player target) {
    if (!isCurrentPlayer(target)) return;
    TeleportRequest request = takeRequest(target);
    if (request == null) {
      target.sendMessage(Component.text("没有待处理的传送请求", NamedTextColor.RED));
      return;
    }
    if (isRequestExpired(request, System.currentTimeMillis())) {
      notifyRequestExpired(target, request);
      return;
    }
    String targetName = target.getName();
    target.sendMessage(Component.text("已接受传送请求", NamedTextColor.GREEN));
    runOnPlayer(
        request.sender(),
        () -> {
          request
              .sender()
              .sendMessage(Component.text(targetName + " 接受了你的传送请求", NamedTextColor.GREEN));
          if (request.teleporterId().equals(request.senderId())) {
            startAcceptedTeleport(request.sender(), target);
          } else {
            runOnPlayer(target, () -> startAcceptedTeleport(target, request.sender()), () -> {});
          }
        },
        () -> {});
  }

  private TeleportRequest takeRequest(Player target) {
    UUID id = target.getUniqueId();
    TeleportRequest request = teleportRequests.get(id);
    return request != null && request.recipient() == target && teleportRequests.remove(id, request)
        ? request
        : null;
  }

  private void startAcceptedTeleport(Player teleporter, Player destinationPlayer) {
    if (!isCurrentPlayer(teleporter)) return;
    recordLastLocation(teleporter);
    scheduleDelayedTeleport(
        teleporter,
        pending -> {
          Runnable retire = () -> pendingTeleports.remove(pending.playerId, pending);
          runOnPlayer(
              destinationPlayer,
              () -> {
                if (!isPending(pending)) return;
                Location location = destinationPlayer.getLocation();
                Location snapshot = location == null ? null : location.clone();
                runOnPlayer(
                    teleporter,
                    () ->
                        performTeleport(
                            teleporter, pending, snapshot, "传送成功！", "传送失败：目标世界不可用或传送被取消", "tpa"),
                    retire);
              },
              retire);
        },
        config.tpaDelay() * 20L,
        "传送失败：服务器无法完成该操作",
        "tpa",
        destinationPlayer.getUniqueId());
  }

  public void denyTeleportRequest(Player target) {
    if (!isCurrentPlayer(target)) return;
    TeleportRequest request = takeRequest(target);
    if (request == null) {
      target.sendMessage(Component.text("没有待处理的传送请求", NamedTextColor.RED));
      return;
    }
    if (isRequestExpired(request, System.currentTimeMillis())) {
      notifyRequestExpired(target, request);
      return;
    }
    messageOnPlayer(
        request.sender(), Component.text(target.getName() + " 拒绝了你的传送请求", NamedTextColor.RED));
    target.sendMessage(Component.text("已拒绝传送请求", NamedTextColor.YELLOW));
  }

  /** 返回上一个位置（/back 命令） */
  public void teleportBack(Player player) {
    if (!isCurrentPlayer(player)) return;
    Location lastLoc = lastLocations.remove(player.getUniqueId());

    if (lastLoc == null) {
      player.sendMessage(Component.text("没有可返回的位置", NamedTextColor.RED));
      player.sendMessage(Component.text("提示: 传送后会自动记录你的位置", NamedTextColor.GRAY));
      return;
    }

    // 检查世界是否存在
    if (lastLoc.getWorld() == null) {
      player.sendMessage(Component.text("之前的位置世界已不存在", NamedTextColor.RED));
      return;
    }

    // 记录当前位置
    recordLastLocation(player);

    player.sendMessage(
        Component.text("将在 " + config.backDelay() + " 秒后返回上一个位置...", NamedTextColor.YELLOW));

    scheduleDelayedTeleport(
        player,
        pending ->
            performTeleport(player, pending, lastLoc, "已返回上一个位置", "返回失败：目标世界不可用或传送被取消", "back"),
        config.backDelay() * 20L,
        "返回失败：服务器无法完成该操作",
        "back");
  }

  /** 设置主城传送点 */
  public void setSpawnLocation(Location location) {
    this.spawnLocation = location == null ? null : location.clone();
  }

  public Location getSpawnLocation() {
    Location location = spawnLocation;
    return location == null ? null : location.clone();
  }

  /** Removes incoming/outgoing requests and pending teleports involving this player. */
  public void cleanup(UUID playerId) {
    synchronized (teleportRequests) {
      teleportRequests
          .entrySet()
          .removeIf(
              e ->
                  e.getValue().senderId().equals(playerId)
                      || e.getValue().recipientId().equals(playerId));
      pendingTeleports
          .entrySet()
          .removeIf(
              e ->
                  e.getKey().equals(playerId) || playerId.equals(e.getValue().destinationPlayerId));
      lastLocations.remove(playerId);
      tpaCooldowns.remove(playerId);
    }
  }

  /** Invalidates queued work; an async teleport already submitted is not rolled back. */
  public void shutdown() {
    synchronized (teleportRequests) {
      closed = true;
      teleportRequests.clear();
      pendingTeleports.clear();
      lastLocations.clear();
      tpaCooldowns.clear();
    }
  }

  /** Cancels a delayed teleport when the player changes block, if configured. */
  public boolean cancelPendingTeleportOnMove(Player player, Location destination) {
    if (!isCurrentPlayer(player)) return false;
    if (!config.cancelOnMove()) {
      return false;
    }

    UUID playerId = player.getUniqueId();
    PendingTeleport pending = pendingTeleports.get(playerId);
    if (pending == null
        || pending.startLocation() == null
        || destination == null
        || !hasMoved(pending.startLocation(), destination)) {
      return false;
    }

    if (!pendingTeleports.remove(playerId, pending)) {
      return false;
    }
    player.sendMessage(Component.text("传送已取消（你移动了）", NamedTextColor.RED));
    return true;
  }

  /** Cancels a delayed teleport when the player takes damage, if configured. */
  public boolean cancelPendingTeleportOnDamage(Player player) {
    if (!isCurrentPlayer(player)) return false;
    if (!config.cancelOnDamage()) {
      return false;
    }

    PendingTeleport pending = pendingTeleports.remove(player.getUniqueId());
    if (pending == null) {
      return false;
    }
    player.sendMessage(Component.text("传送已取消（你受到了伤害）", NamedTextColor.RED));
    return true;
  }

  /**
   * Nonce prevents an old timeout from matching a later request created in the same millisecond.
   */
  private record TeleportRequest(
      UUID senderId,
      UUID recipientId,
      UUID teleporterId,
      long timestamp,
      UUID nonce,
      Player sender,
      Player recipient) {}

  public void sendTeleportHereRequest(Player requester, Player target) {
    sendRequest(requester, target, true);
  }

  private void sendRequest(Player requester, Player target, boolean here) {
    if (!isCurrentPlayer(requester)) return;
    UUID senderId = requester.getUniqueId(), targetId = target.getUniqueId();
    if (senderId.equals(targetId)) return;
    String senderName = requester.getName();
    long now = System.currentTimeMillis();
    TeleportRequest request =
        new TeleportRequest(
            senderId,
            targetId,
            here ? targetId : senderId,
            now,
            UUID.randomUUID(),
            requester,
            target);
    String rejection = null;
    synchronized (teleportRequests) {
      if (closed) return;
      long remaining = remainingCooldownMillis(tpaCooldowns.get(senderId), now);
      if (remaining > 0) {
        rejection = "请等待 " + ((remaining + 999) / 1000) + " 秒后再发送请求";
      } else if (teleportRequests.values().stream()
          .anyMatch(r -> r.senderId().equals(senderId) && !isRequestExpired(r, now))) {
        rejection = "你已有待处理的传送请求，请等待当前请求被处理后再试";
      } else {
        TeleportRequest previous = teleportRequests.get(targetId);
        if (previous != null && !isRequestExpired(previous, now)) rejection = "目标玩家有待处理的传送请求";
      }
      if (rejection == null) {
        teleportRequests.put(targetId, request);
        tpaCooldowns.put(senderId, now);
      }
    }
    if (rejection != null) {
      requester.sendMessage(Component.text(rejection, NamedTextColor.RED));
      return;
    }
    if (!scheduleRequestExpiration(targetId, request, requester, here ? "拉人请求已过期" : "传送请求已过期"))
      return;
    runOnPlayer(
        target,
        () -> {
          if (teleportRequests.get(targetId) != request) return;
          String targetName = target.getName();
          target.sendMessage(
              Component.text(
                  senderName + (here ? " 想让你传送到他那里" : " 请求传送到你的位置"), NamedTextColor.YELLOW));
          target.sendMessage(Component.text("使用 /tpaccept 接受 或 /tpdeny 拒绝", NamedTextColor.GRAY));
          runOnPlayer(
              requester,
              () -> {
                if (teleportRequests.get(targetId) == request)
                  requester.sendMessage(
                      Component.text(
                          "已向 " + targetName + (here ? " 发送拉人请求" : " 发送传送请求"),
                          NamedTextColor.GREEN));
              },
              () -> releaseRequest(request));
        },
        () -> releaseRequest(request));
  }

  private void releaseRequest(TeleportRequest request) {
    synchronized (teleportRequests) {
      if (teleportRequests.remove(request.recipientId(), request)) {
        tpaCooldowns.remove(request.senderId(), request.timestamp());
      }
    }
  }

  private long remainingCooldownMillis(Long lastRequest, long nowMillis) {
    if (lastRequest == null) return 0;
    long elapsed = Math.max(0, nowMillis - lastRequest);
    return Math.max(0, config.tpaCooldown().toMillis() - elapsed);
  }

  private boolean scheduleRequestExpiration(
      UUID targetId,
      TeleportRequest request,
      Player notificationRecipient,
      String expirationMessage) {
    try {
      scheduler.runDelayed(
          () -> {
            if (teleportRequests.remove(targetId, request)) {
              messageOnPlayer(
                  notificationRecipient, Component.text(expirationMessage, NamedTextColor.RED));
            }
          },
          TPA_REQUEST_TIMEOUT_TICKS);
      return true;
    } catch (RuntimeException failure) {
      releaseRequest(request);
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "ESSENTIALS_TPA_TIMEOUT_SCHEDULE_FAILED requester="
                  + request.senderId()
                  + " target="
                  + targetId,
              failure);
      notificationRecipient.sendMessage(Component.text("传送请求发送失败：服务器无法完成该操作", NamedTextColor.RED));
      return false;
    }
  }

  private void notifyRequestExpired(Player target, TeleportRequest request) {
    target.sendMessage(Component.text("传送请求已过期", NamedTextColor.RED));
    messageOnPlayer(request.sender(), Component.text("传送请求已过期", NamedTextColor.RED));
  }

  private boolean isCurrentPlayer(Player player) {
    if (closed || !player.isOnline()) return false;
    var server = player.getServer();
    return server != null && server.getPlayer(player.getUniqueId()) == player;
  }

  private void runOnPlayer(Player player, Runnable operation, Runnable retired) {
    if (closed) {
      retired.run();
      return;
    }
    UUID id = player.getUniqueId();
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (isCurrentPlayer(player)) operation.run();
            else retired.run();
          },
          retired);
    } catch (RuntimeException failure) {
      retired.run();
      plugin
          .getLogger()
          .log(Level.WARNING, "ESSENTIALS_PLAYER_TASK_REJECTED player=" + id, failure);
    }
  }

  private void messageOnPlayer(Player player, Component message) {
    runOnPlayer(player, () -> player.sendMessage(message), () -> {});
  }

  private static boolean isRequestExpired(TeleportRequest request, long nowMillis) {
    return nowMillis - request.timestamp() >= TPA_REQUEST_TIMEOUT_MILLIS;
  }

  private void scheduleDelayedTeleport(
      Player player,
      Consumer<PendingTeleport> task,
      long delayTicks,
      String failureMessage,
      String teleportType) {
    scheduleDelayedTeleport(player, task, delayTicks, failureMessage, teleportType, null);
  }

  private void scheduleDelayedTeleport(
      Player player,
      Consumer<PendingTeleport> task,
      long delayTicks,
      String failureMessage,
      String teleportType,
      UUID destinationPlayerId) {
    UUID id = player.getUniqueId();
    Location location = player.getLocation();
    PendingTeleport pending =
        new PendingTeleport(id, destinationPlayerId, location == null ? null : location.clone());
    synchronized (teleportRequests) {
      if (closed) return;
      pendingTeleports.put(id, pending);
    }
    Runnable retire = () -> pendingTeleports.remove(id, pending);
    try {
      if (delayTicks < 0) throw new IllegalArgumentException("Negative teleport delay");
      scheduler.runEntityDelayed(
          player,
          () -> {
            if (!isCurrentPlayer(player)) {
              retire.run();
              return;
            }
            if (!isPending(pending)) return;
            try {
              task.accept(pending);
            } catch (RuntimeException failure) {
              retire.run();
              plugin
                  .getLogger()
                  .log(
                      Level.WARNING,
                      "ESSENTIALS_DELAYED_TELEPORT_FAILED type=" + teleportType + " player=" + id,
                      failure);
              player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
            }
          },
          retire,
          Math.max(1L, delayTicks));
    } catch (RuntimeException failure) {
      retire.run();
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "ESSENTIALS_TELEPORT_SCHEDULE_FAILED type=" + teleportType + " player=" + id,
              failure);
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
    }
  }

  private boolean isPending(PendingTeleport pending) {
    return !closed && pendingTeleports.get(pending.playerId) == pending;
  }

  private void performTeleport(
      Player player,
      PendingTeleport pending,
      Location destination,
      String successMessage,
      String failureMessage,
      String teleportType) {
    if (!isCurrentPlayer(player) || !pendingTeleports.remove(pending.playerId, pending)) return;
    if (destination == null || destination.getWorld() == null) {
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
      return;
    }
    UUID id = pending.playerId;
    try {
      // Never block an owner thread waiting for chunks or a cross-region teleport.
      Objects.requireNonNull(player.teleportAsync(destination.clone()), "teleportAsync result")
          .whenComplete(
              (success, failure) -> {
                if (failure != null)
                  plugin
                      .getLogger()
                      .log(
                          Level.WARNING,
                          "ESSENTIALS_TELEPORT_FAILED type=" + teleportType + " player=" + id,
                          failure);
                boolean applied = failure == null && Boolean.TRUE.equals(success);
                messageOnPlayer(
                    player,
                    Component.text(
                        applied ? successMessage : failureMessage,
                        applied ? NamedTextColor.GREEN : NamedTextColor.RED));
              });
    } catch (RuntimeException failure) {
      plugin
          .getLogger()
          .log(
              Level.WARNING,
              "ESSENTIALS_TELEPORT_FAILED type=" + teleportType + " player=" + id,
              failure);
      player.sendMessage(Component.text(failureMessage, NamedTextColor.RED));
    }
  }

  private boolean hasMoved(Location start, Location current) {
    return start.getWorld() != current.getWorld()
        || start.getBlockX() != current.getBlockX()
        || start.getBlockY() != current.getBlockY()
        || start.getBlockZ() != current.getBlockZ();
  }

  /** Identity, rather than equal locations, separates successive attempts. */
  private static final class PendingTeleport {
    private final UUID playerId;
    private final UUID destinationPlayerId;
    private final Location startLocation;

    private PendingTeleport(UUID playerId, UUID destinationPlayerId, Location startLocation) {
      this.playerId = playerId;
      this.destinationPlayerId = destinationPlayerId;
      this.startLocation = startLocation;
    }

    private Location startLocation() {
      return startLocation;
    }
  }
}
