package dev.starcore.starcore.api.v1.handler;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializer;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.auth.ApiAuthService.ApiKeyPermission;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** HTTP 请求处理器基类 提供统一的请求处理、认证、响应等基础功能 */
public abstract class BaseHttpHandler {

  private static final Logger LOGGER = Logger.getLogger(BaseHttpHandler.class.getName());
  private static final int MAX_REQUEST_BODY_BYTES = 1_048_576;
  private static final String REQUEST_BODY_ATTRIBUTE = BaseHttpHandler.class.getName() + ".body";
  private static final String REQUEST_ID_ATTRIBUTE = BaseHttpHandler.class.getName() + ".requestId";
  private static final ThreadLocal<String> requestIdHolder = new ThreadLocal<>();
  protected static final String CONTENT_TYPE_JSON = "application/json; charset=utf-8";
  protected static final String CONTENT_TYPE_HTML = "text/html; charset=utf-8";
  protected static final String CONTENT_TYPE_PLAIN = "text/plain; charset=utf-8";

  protected final Gson gson;
  protected final ApiAuthService authService;
  private final RestApiConfig.CorsConfig corsConfig;
  private final boolean requiresAuth;
  private final ApiKeyPermission requiredPermission;

  protected BaseHttpHandler(Gson gson, ApiAuthService authService) {
    this(gson, authService, RestApiConfig.CorsConfig.DEFAULT, false);
  }

  protected BaseHttpHandler(
      Gson gson,
      ApiAuthService authService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth) {
    this(gson, authService, corsConfig, requiresAuth, null);
  }

  protected BaseHttpHandler(
      Gson gson,
      ApiAuthService authService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth,
      ApiKeyPermission requiredPermission) {
    this.gson = gson != null ? gson : createDefaultGson();
    this.authService = authService;
    this.corsConfig = corsConfig != null ? corsConfig : RestApiConfig.CorsConfig.DEFAULT;
    this.requiresAuth = requiresAuth;
    this.requiredPermission = requiredPermission;
  }

  protected BaseHttpHandler() {
    this(null, null);
  }

  /** 创建默认 Gson 实例 */
  public static Gson createDefaultGson() {
    return new GsonBuilder()
        .serializeNulls()
        .setPrettyPrinting()
        .registerTypeAdapter(
            Instant.class,
            (JsonSerializer<Instant>) (value, type, context) -> new JsonPrimitive(value.toString()))
        .create();
  }

  /** 处理请求（由子类实现） */
  protected abstract void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException;

  /** 处理请求（带错误处理包装） */
  public void handle(HttpExchange exchange) throws IOException {
    // 处理 CORS 预检请求
    if (handleCorsPreflight(exchange)) {
      return;
    }

    // 复用客户端传入的 X-Request-Id，缺失则生成，保证一次请求内响应头与 body 一致
    ensureRequestId(exchange);
    try {
      if (requestMayHaveBody(exchange)) {
        byte[] body = exchange.getRequestBody().readNBytes(MAX_REQUEST_BODY_BYTES + 1);
        if (body.length > MAX_REQUEST_BODY_BYTES) {
          sendError(exchange, 413, "PAYLOAD_TOO_LARGE", "Request body exceeds 1 MiB");
          return;
        }
        exchange.setAttribute(REQUEST_BODY_ATTRIBUTE, body);
      }

      // 获取认证上下文
      ApiAuthContext authContext = resolveAuthContext(exchange);

      if (requiresAuth && !authContext.authenticated()) {
        sendUnauthorized(exchange, "Authentication required");
        return;
      }

      if (requiresAuth
          && requiredPermission != null
          && !authContext.hasPermission(requiredPermission)) {
        sendForbidden(exchange, "API key does not grant access to this endpoint");
        return;
      }

      try {
        handleRequest(exchange, authContext);
      } catch (Exception e) {
        handleException(exchange, e);
      }
    } finally {
      requestIdHolder.remove();
    }
  }

  /** 解析认证上下文 */
  protected ApiAuthContext resolveAuthContext(HttpExchange exchange) {
    if (authService == null) {
      return ApiAuthContext.anonymous();
    }

    // 从 X-API-Key 头获取 API Key
    String apiKey = getHeader(exchange, ApiAuthService.HEADER_API_KEY);
    if (apiKey != null && !apiKey.isBlank()) {
      Optional<ApiAuthService.ApiKeyInfo> keyInfo = authService.validateApiKey(apiKey);
      if (keyInfo.isPresent()) {
        ApiAuthService.ApiKeyInfo info = keyInfo.get();
        return ApiAuthContext.of(info.playerId(), info.playerName(), info.permissions());
      }
    }

    String timestamp = getHeader(exchange, ApiAuthService.HEADER_TIMESTAMP);
    String nonce = getHeader(exchange, ApiAuthService.HEADER_NONCE);
    String signature = getHeader(exchange, ApiAuthService.HEADER_SIGNATURE);
    if (timestamp != null || nonce != null || signature != null) {
      byte[] body = (byte[]) exchange.getAttribute(REQUEST_BODY_ATTRIBUTE);
      ApiAuthService.SignatureValidationResult validation =
          body == null
              ? authService.validateSignature(
                  exchange.getRequestMethod(),
                  exchange.getRequestURI().getPath(),
                  exchange.getRequestURI().getRawQuery(),
                  timestamp,
                  nonce,
                  signature)
              : authService.validateSignature(
                  exchange.getRequestMethod(),
                  exchange.getRequestURI().getPath(),
                  exchange.getRequestURI().getRawQuery(),
                  timestamp,
                  nonce,
                  body,
                  signature);
      if (validation.isValid()) {
        return ApiAuthContext.signed();
      }
    }

    return ApiAuthContext.anonymous();
  }

  /** 处理 CORS 预检请求 */
  protected boolean handleCorsPreflight(HttpExchange exchange) throws IOException {
    return RestApiCors.handlePreflight(exchange, corsConfig);
  }

  /** 设置 CORS 头 */
  protected void setCorsHeaders(HttpExchange exchange) {
    RestApiCors.applyHeaders(exchange, corsConfig);
  }

  /** 处理异常 */
  protected void handleException(HttpExchange exchange, Exception e) throws IOException {
    LOGGER.log(Level.SEVERE, "HTTP request handling failed", e);
    sendError(exchange, 500, "INTERNAL_ERROR", "An internal error occurred: " + e.getMessage());
  }

  /** 发送成功响应 */
  protected <T> void sendJson(HttpExchange exchange, int statusCode, T data) throws IOException {
    setCorsHeaders(exchange);
    Headers headers = exchange.getResponseHeaders();
    headers.set("Content-Type", CONTENT_TYPE_JSON);
    headers.set("X-Request-Id", generateRequestId());
    headers.set("Cache-Control", "no-store");
    byte[] body = gson.toJson(data).getBytes(StandardCharsets.UTF_8);
    exchange.sendResponseHeaders(statusCode, body.length);
    try (var os = exchange.getResponseBody()) {
      os.write(body);
    }
  }

  /** 发送成功响应（使用 ApiResponse 包装） */
  protected <T> void sendSuccess(HttpExchange exchange, T data) throws IOException {
    sendJson(exchange, 200, ApiResponse.success(data));
  }

  /** 发送成功响应（带分页） */
  protected <T> void sendSuccess(HttpExchange exchange, T data, ApiResponse.ResponseMeta meta)
      throws IOException {
    sendJson(exchange, 200, ApiResponse.success(data, meta));
  }

  /** 发送错误响应 */
  protected void sendError(HttpExchange exchange, int statusCode, String code, String message)
      throws IOException {
    setCorsHeaders(exchange);
    Headers headers = exchange.getResponseHeaders();
    headers.set("Content-Type", CONTENT_TYPE_JSON);
    headers.set("X-Request-Id", generateRequestId());
    headers.set("Cache-Control", "no-store");
    byte[] body = gson.toJson(ApiResponse.error(code, message)).getBytes(StandardCharsets.UTF_8);
    exchange.sendResponseHeaders(statusCode, body.length);
    try (var os = exchange.getResponseBody()) {
      os.write(body);
    }
  }

  /** 发送验证错误响应 */
  protected void sendValidationError(HttpExchange exchange, List<String> errors)
      throws IOException {
    sendJson(exchange, 400, ApiResponse.validationError(errors));
  }

  /** 发送未授权响应 */
  protected void sendUnauthorized(HttpExchange exchange, String message) throws IOException {
    sendError(exchange, 401, "UNAUTHORIZED", message != null ? message : "Authentication required");
  }

  /** 发送禁止访问响应 */
  protected void sendForbidden(HttpExchange exchange, String message) throws IOException {
    sendError(exchange, 403, "FORBIDDEN", message != null ? message : "Access denied");
  }

  /** 发送未找到响应 */
  protected void sendNotFound(HttpExchange exchange, String resource) throws IOException {
    sendError(exchange, 404, "NOT_FOUND", resource + " not found");
  }

  /** 发送方法不允许响应 */
  protected void sendMethodNotAllowed(HttpExchange exchange) throws IOException {
    sendError(
        exchange, 405, "METHOD_NOT_ALLOWED", "This HTTP method is not allowed for this endpoint");
  }

  /** 获取请求体 */
  protected <T> T parseBody(HttpExchange exchange, Class<T> clazz) throws IOException {
    byte[] cached = (byte[]) exchange.getAttribute(REQUEST_BODY_ATTRIBUTE);
    var input = cached == null ? exchange.getRequestBody() : new ByteArrayInputStream(cached);
    try (var reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
      return gson.fromJson(reader, clazz);
    }
  }

  private boolean requestMayHaveBody(HttpExchange exchange) {
    String method = exchange.getRequestMethod();
    return !"GET".equalsIgnoreCase(method)
        && !"HEAD".equalsIgnoreCase(method)
        && !"OPTIONS".equalsIgnoreCase(method);
  }

  /** 解析查询参数 */
  protected Map<String, String> parseQueryParams(HttpExchange exchange) {
    String query = exchange.getRequestURI().getQuery();
    if (query == null || query.isBlank()) {
      return Map.of();
    }
    return java.util.Arrays.stream(query.split("&"))
        .map(
            s -> {
              int idx = s.indexOf('=');
              if (idx < 0) {
                return Map.entry(s, "");
              }
              try {
                return Map.entry(
                    java.net.URLDecoder.decode(s.substring(0, idx), StandardCharsets.UTF_8),
                    java.net.URLDecoder.decode(s.substring(idx + 1), StandardCharsets.UTF_8));
              } catch (Exception e) {
                return Map.entry(s.substring(0, idx), s.substring(idx + 1));
              }
            })
        .collect(
            java.util.stream.Collectors.toMap(
                java.util.Map.Entry::getKey, java.util.Map.Entry::getValue, (a, b) -> a));
  }

  /** 获取请求头 */
  protected String getHeader(HttpExchange exchange, String name) {
    List<String> values = exchange.getRequestHeaders().get(name);
    if (values != null && !values.isEmpty()) {
      return values.get(0);
    }
    return null;
  }

  /** 检查请求方法 */
  protected boolean isMethod(HttpExchange exchange, String... methods) {
    String method = exchange.getRequestMethod().toUpperCase();
    for (String m : methods) {
      if (m.equalsIgnoreCase(method)) {
        return true;
      }
    }
    return false;
  }

  /** 获取请求路径 */
  protected String getPath(HttpExchange exchange) {
    String path = exchange.getRequestURI().getPath();
    return path != null ? path : "";
  }

  /** 获取路径参数 */
  protected String[] getPathSegments(HttpExchange exchange) {
    String path = getPath(exchange);
    return path.split("/");
  }

  /** 确保一次请求拥有 requestId：优先复用客户端传入的 X-Request-Id（便于端到端追踪），缺失则生成并缓存。 */
  private void ensureRequestId(HttpExchange exchange) {
    String clientId = exchange.getRequestHeaders().getFirst("X-Request-Id");
    String id =
        (clientId != null && !clientId.isBlank())
            ? clientId
            : UUID.randomUUID().toString().substring(0, 8);
    requestIdHolder.set(id);
    exchange.setAttribute(REQUEST_ID_ATTRIBUTE, id);
  }

  /** 生成请求 ID：从本次请求上下文中获取已缓存的 ID，避免在同一次请求中多次生成不一致的值。 */
  protected String generateRequestId() {
    String id = requestIdHolder.get();
    if (id == null) {
      id = UUID.randomUUID().toString().substring(0, 8);
      requestIdHolder.set(id);
    }
    return id;
  }
}
