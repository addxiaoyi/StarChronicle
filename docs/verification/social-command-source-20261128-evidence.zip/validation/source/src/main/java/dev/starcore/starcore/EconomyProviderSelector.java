package dev.starcore.starcore;

import dev.starcore.starcore.foundation.economy.EconomyService;
import java.util.Locale;
import java.util.Objects;

/** Pure policy for resolving the configured business economy provider. */
final class EconomyProviderSelector {
  private EconomyProviderSelector() {}

  static Selection select(
      String configured, boolean vaultEnabled, EconomyService internal, EconomyService vault) {
    Objects.requireNonNull(internal, "internal");
    Objects.requireNonNull(vault, "vault");
    String mode = configured == null ? "internal" : configured.trim().toLowerCase(Locale.ROOT);
    return switch (mode) {
      case "vault" -> new Selection(vault, "vault", !vaultEnabled);
      case "auto" ->
          vaultEnabled
              ? new Selection(vault, "vault", false)
              : new Selection(internal, "internal", false);
      case "internal" -> new Selection(internal, "internal", false);
      default -> new Selection(internal, "internal", false);
    };
  }

  record Selection(EconomyService service, String resolvedMode, boolean unavailableDependency) {}
}
