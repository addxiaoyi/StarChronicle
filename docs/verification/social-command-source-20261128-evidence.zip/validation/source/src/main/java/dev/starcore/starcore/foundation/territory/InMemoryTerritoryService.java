package dev.starcore.starcore.foundation.territory;

import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.foundation.territory.model.ChunkCoordinate;
import dev.starcore.starcore.foundation.territory.model.TerritoryClaim;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public final class InMemoryTerritoryService implements TerritoryService {
  private static final String NAMESPACE = "territory";
  private static final String FILE_NAME = "claims.properties";

  private final PersistenceService persistenceService;
  private volatile Map<ChunkCoordinate, TerritoryClaim> claims = Map.of();

  public InMemoryTerritoryService(PersistenceService persistenceService) {
    this.persistenceService = persistenceService;
    load();
  }

  @Override
  public Optional<TerritoryClaim> claimAt(ChunkCoordinate coordinate) {
    return Optional.ofNullable(claims.get(coordinate));
  }

  @Override
  public boolean isClaimed(ChunkCoordinate coordinate) {
    return claims.containsKey(coordinate);
  }

  @Override
  public synchronized boolean claim(String ownerId, ChunkCoordinate coordinate) {
    if (claims.containsKey(coordinate)) {
      return false;
    }
    Map<ChunkCoordinate, TerritoryClaim> next = new HashMap<>(claims);
    next.put(coordinate, new TerritoryClaim(ownerId, coordinate));
    claims = Map.copyOf(next);
    saveAsync(claims.values());
    return true;
  }

  @Override
  public synchronized boolean unclaim(String ownerId, ChunkCoordinate coordinate) {
    TerritoryClaim current = claims.get(coordinate);
    if (current == null || !current.ownerId().equals(ownerId)) {
      return false;
    }
    Map<ChunkCoordinate, TerritoryClaim> next = new HashMap<>(claims);
    if (!next.remove(coordinate, current)) {
      return false;
    }
    claims = Map.copyOf(next);
    saveAsync(claims.values());
    return true;
  }

  @Override
  public synchronized boolean unclaimDurably(String ownerId, ChunkCoordinate coordinate) {
    return unclaimClaimsDurably(List.of(new TerritoryClaim(ownerId, coordinate)));
  }

  @Override
  public synchronized boolean unclaimClaimsDurably(Collection<TerritoryClaim> expectedClaims) {
    List<TerritoryClaim> requested = List.copyOf(expectedClaims);
    Set<ChunkCoordinate> coordinates = new HashSet<>();
    Map<ChunkCoordinate, TerritoryClaim> next = new HashMap<>(claims);
    for (TerritoryClaim expected : requested) {
      if (!coordinates.add(expected.coordinate())) {
        throw new IllegalArgumentException("Durable unclaim contains duplicate coordinates");
      }
      TerritoryClaim current = next.get(expected.coordinate());
      if (current == null) {
        continue;
      }
      if (!current.ownerId().equals(expected.ownerId())) {
        return false;
      }
      next.remove(expected.coordinate(), current);
    }
    if (requested.isEmpty()) {
      return true;
    }
    persistenceService.saveProperties(
        NAMESPACE, FILE_NAME, TerritoryStateCodec.toProperties(next.values()));
    claims = Map.copyOf(next);
    return true;
  }

  @Override
  public synchronized boolean transferClaims(
      String sourceOwnerId, String targetOwnerId, Collection<ChunkCoordinate> coordinates) {
    ClaimTransfer transfer = ClaimTransfer.of(sourceOwnerId, targetOwnerId, coordinates);
    boolean ownsEveryClaim =
        transfer.coordinates().stream()
            .allMatch(coordinate -> isOwnedBy(transfer.sourceOwnerId(), coordinate));
    if (!ownsEveryClaim) {
      return false;
    }

    Map<ChunkCoordinate, TerritoryClaim> next = new HashMap<>(claims);
    for (ChunkCoordinate coordinate : transfer.coordinates()) {
      next.put(coordinate, new TerritoryClaim(transfer.targetOwnerId(), coordinate));
    }
    try {
      persistenceService.saveProperties(
          NAMESPACE, FILE_NAME, TerritoryStateCodec.toProperties(next.values()));
    } catch (RuntimeException exception) {
      throw new IllegalStateException("Unable to persist atomic territory transfer", exception);
    }
    claims = Map.copyOf(next);
    return true;
  }

  @Override
  public int claimedChunkCount() {
    return claims.size();
  }

  @Override
  public Collection<TerritoryClaim> claimsByOwner(String ownerId) {
    return List.copyOf(
        claims.values().stream().filter(claim -> claim.ownerId().equals(ownerId)).toList());
  }

  public void save() {
    persistenceService.saveProperties(
        NAMESPACE, FILE_NAME, TerritoryStateCodec.toProperties(claims.values()));
  }

  private boolean isOwnedBy(String ownerId, ChunkCoordinate coordinate) {
    TerritoryClaim claim = claims.get(coordinate);
    return claim != null && claim.ownerId().equals(ownerId);
  }

  private void saveAsync(Collection<TerritoryClaim> snapshot) {
    persistenceService.savePropertiesAsync(
        NAMESPACE, FILE_NAME, TerritoryStateCodec.toProperties(snapshot));
  }

  private void load() {
    claims =
        Map.copyOf(
            TerritoryStateCodec.fromProperties(
                persistenceService.loadProperties(NAMESPACE, FILE_NAME)));
  }
}
