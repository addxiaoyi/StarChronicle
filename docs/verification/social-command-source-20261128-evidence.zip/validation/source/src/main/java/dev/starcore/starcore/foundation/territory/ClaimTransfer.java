package dev.starcore.starcore.foundation.territory;

import dev.starcore.starcore.foundation.territory.model.ChunkCoordinate;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

record ClaimTransfer(String sourceOwnerId, String targetOwnerId, List<ChunkCoordinate> coordinates) {
    static ClaimTransfer of(
        String sourceOwnerId,
        String targetOwnerId,
        Collection<ChunkCoordinate> coordinates
    ) {
        Objects.requireNonNull(sourceOwnerId, "sourceOwnerId");
        Objects.requireNonNull(targetOwnerId, "targetOwnerId");
        Objects.requireNonNull(coordinates, "coordinates");
        if (sourceOwnerId.isBlank() || targetOwnerId.isBlank()) {
            throw new IllegalArgumentException("Territory transfer owners must not be blank");
        }
        if (sourceOwnerId.equals(targetOwnerId)) {
            throw new IllegalArgumentException("Territory transfer owners must be different");
        }
        if (coordinates.isEmpty()) {
            throw new IllegalArgumentException("Territory transfer coordinates must not be empty");
        }

        List<ChunkCoordinate> snapshot = List.copyOf(coordinates);
        if (new HashSet<>(snapshot).size() != snapshot.size()) {
            throw new IllegalArgumentException("Territory transfer contains duplicate coordinates");
        }
        return new ClaimTransfer(sourceOwnerId, targetOwnerId, snapshot);
    }
}
