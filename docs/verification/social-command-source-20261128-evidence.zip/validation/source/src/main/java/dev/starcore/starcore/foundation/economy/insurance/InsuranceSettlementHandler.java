package dev.starcore.starcore.foundation.economy.insurance;

import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;

/** Domain cleanup hook invoked after an insurance payout is delivered. */
@FunctionalInterface
public interface InsuranceSettlementHandler {
  boolean settle(InsurancePolicy policy, TransactionRecord sourceTransaction);
}
