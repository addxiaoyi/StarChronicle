package dev.starcore.starcore.core.extension.army;

import dev.starcore.starcore.core.extension.AbstractExtensionPoint;
import dev.starcore.starcore.module.army.model.ArmyUnit;
import java.util.List;

/**
 * 军队作战伤害计算扩展点 允许其他模块/插件自定义战斗伤害计算逻辑
 *
 * <p>用于 BattleCalculator 和 ArmyService 中的战斗计算，支持： - terrain effects - weather modifiers - custom
 * unit types - additional damage sources (divine buffs, special abilities, etc.)
 */
public class ArmyCombatExtensionPoint
    extends AbstractExtensionPoint<
        ArmyCombatExtensionPoint.CombatResult, ArmyCombatExtensionPoint.CombatContext> {

  public ArmyCombatExtensionPoint() {
    super("army_combat", "军队作战伤害计算扩展点 - 允许修改战斗伤害计算结果");
  }

  @Override
  protected CombatResult aggregateResults(List<CombatResult> results, CombatContext request) {
    if (results.isEmpty()) {
      return getDefaultResult(request);
    }

    // 聚合所有贡献者的结果（取最高伤害的）
    CombatResult best = results.get(0);
    for (CombatResult result : results) {
      if (result.damage() > best.damage()) {
        best = result;
      }
    }
    return best;
  }

  @Override
  protected CombatResult getDefaultResult(CombatContext request) {
    return new CombatResult(request.baseDamage(), "default", List.of());
  }

  /** 战斗上下文 包含战斗双方的简化信息 */
  public record CombatContext(
      String attackerId,
      String defenderId,
      String attackerType,
      String defenderType,
      double baseDamage,
      int attackerSoldiers,
      int defenderSoldiers) {}

  /** 战斗请求上下文 包含战斗双方及基础计算数据 */
  public record CombatRequest(
      ArmyUnit attacker,
      ArmyUnit defender,
      double baseAttackerDamage,
      double baseDefenderDamage,
      double terrainModifier,
      double moraleFactor,
      double weatherModifier) {}

  /** 战斗结果 包含修改后的伤害值和来源信息 */
  public record CombatResult(double damage, String source, List<String> appliedModifiers) {}
}
