package dev.starcore.starcore.balance;

import dev.starcore.starcore.core.config.ConfigurationService;
import dev.starcore.starcore.core.module.ModuleDescriptor;
import dev.starcore.starcore.core.module.ModuleStatus;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

public record BalanceSnapshot(
    int enabledModules,
    int failedModules,
    int fallbackMaxClaims,
    int maxMembersPerNation,
    boolean levelClaimLimitEnabled,
    int maxLevel,
    int claimsAtLevelOne,
    int claimsPerLevel,
    int hardMaxClaims,
    BigDecimal nationCreateCost,
    BigDecimal claimCost,
    boolean dailyIncomeAutoEnabled,
    BigDecimal dailyIncomeBase,
    BigDecimal dailyIncomePerMember,
    BigDecimal dailyIncomePerClaim,
    boolean resourceTreasuryIncomeEnabled,
    BigDecimal resourceTreasuryBaseIncome,
    BigDecimal resourceTreasuryIncomePerBlock,
    int resourceBlocksPerCycle,
    int resourceDistrictMaxLimit) {
  public BalanceSnapshot {
    nationCreateCost = nonNegative(nationCreateCost, "nationCreateCost");
    claimCost = nonNegative(claimCost, "claimCost");
    dailyIncomeBase = nonNegative(dailyIncomeBase, "dailyIncomeBase");
    dailyIncomePerMember = nonNegative(dailyIncomePerMember, "dailyIncomePerMember");
    dailyIncomePerClaim = nonNegative(dailyIncomePerClaim, "dailyIncomePerClaim");
    resourceTreasuryBaseIncome =
        nonNegative(resourceTreasuryBaseIncome, "resourceTreasuryBaseIncome");
    resourceTreasuryIncomePerBlock =
        nonNegative(resourceTreasuryIncomePerBlock, "resourceTreasuryIncomePerBlock");
  }

  public static BalanceSnapshot capture(
      ConfigurationService configuration, Collection<ModuleDescriptor> modules) {
    Objects.requireNonNull(configuration, "configuration");
    Objects.requireNonNull(modules, "modules");
    int enabled =
        (int) modules.stream().filter(module -> module.status() == ModuleStatus.ENABLED).count();
    int failed =
        (int) modules.stream().filter(module -> module.status() == ModuleStatus.FAILED).count();
    return new BalanceSnapshot(
        enabled,
        failed,
        configuration.maxClaimsPerNation(),
        configuration.maxMembersPerNation(),
        configuration.nationResourceLevelClaimLimitEnabled(),
        configuration.nationResourceMaxLevel(),
        configuration.nationResourceClaimsAtLevelOne(),
        configuration.nationResourceClaimsPerLevel(),
        configuration.nationResourceHardMaxClaimsPerNation(),
        configuration.nationCreateCost(),
        configuration.claimCost(),
        configuration.nationDailyIncomeAutoEnabled(),
        configuration.nationDailyIncomeBaseAmount(),
        configuration.nationDailyIncomePerMember(),
        configuration.nationDailyIncomePerClaim(),
        configuration.nationResourceRefreshTreasuryIncomeEnabled(),
        configuration.nationResourceRefreshTreasuryBaseIncome(),
        configuration.nationResourceRefreshTreasuryIncomePerBlock(),
        configuration.nationResourceRefreshBaseAmount(),
        configuration.nationResourceDistrictMaxLimit());
  }

  public long maximumClaimCapacity() {
    if (!levelClaimLimitEnabled) {
      return fallbackMaxClaims;
    }
    long calculated =
        Math.addExact(
            claimsAtLevelOne, Math.multiplyExact((long) Math.max(0, maxLevel - 1), claimsPerLevel));
    if (hardMaxClaims >= 0) {
      return Math.min(calculated, hardMaxClaims);
    }
    return calculated;
  }

  public BigDecimal resourceIncomePerDistrictCycle() {
    if (!resourceTreasuryIncomeEnabled) {
      return BigDecimal.ZERO;
    }
    return resourceTreasuryBaseIncome.add(
        resourceTreasuryIncomePerBlock.multiply(BigDecimal.valueOf(resourceBlocksPerCycle)));
  }

  public boolean hasUnlimitedClaimCapacity() {
    return !levelClaimLimitEnabled && fallbackMaxClaims < 0;
  }

  public boolean hasUnlimitedResourceDistricts() {
    return resourceDistrictMaxLimit < 0;
  }

  public BigDecimal maximumResourceIncomePerCycle() {
    if (hasUnlimitedResourceDistricts()) {
      return BigDecimal.ZERO;
    }
    return resourceIncomePerDistrictCycle().multiply(BigDecimal.valueOf(resourceDistrictMaxLimit));
  }

  private static BigDecimal nonNegative(BigDecimal value, String name) {
    Objects.requireNonNull(value, name);
    if (value.signum() < 0) {
      throw new IllegalArgumentException(name + " must not be negative");
    }
    return value;
  }
}
