package dev.starcore.starcore.foundation.economy.transaction;

import java.util.List;
import java.util.UUID;

/** Supplies bounded, read-only domain journal evidence for incident exports. */
@FunctionalInterface
public interface IncidentArtifactProvider {
    List<IncidentArtifact> export(UUID transactionId, TransactionRecord transaction);
}
