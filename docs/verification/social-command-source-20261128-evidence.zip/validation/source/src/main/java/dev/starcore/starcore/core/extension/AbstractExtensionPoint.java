package dev.starcore.starcore.core.extension;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * 抽象扩展点实现 提供扩展点的基础实现
 *
 * @param <T> 返回值类型
 * @param <R> 请求/输入参数类型
 */
public abstract class AbstractExtensionPoint<T, R> implements ExtensionPoint<T, R> {

  private final String name;
  private final String description;
  private final ExtensionRegistry registry;

  protected AbstractExtensionPoint(String name, String description) {
    this(name, description, ExtensionRegistry.getInstance());
  }

  protected AbstractExtensionPoint(String name, String description, ExtensionRegistry registry) {
    this.name = Objects.requireNonNull(name, "name");
    this.description = Objects.requireNonNull(description, "description");
    this.registry = Objects.requireNonNull(registry, "registry");

    // 自动注册到注册中心
    registry.registerExtensionPoint(this);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public String getDescription() {
    return description;
  }

  @Override
  public boolean hasContributions() {
    return !registry.getContributors(name).isEmpty();
  }

  @Override
  public List<ExtensionContributor<T, R>> getContributors() {
    @SuppressWarnings("unchecked")
    List<ExtensionContributor<T, R>> contributors =
        (List<ExtensionContributor<T, R>>) (List<?>) registry.getContributors(name);
    return contributors;
  }

  @Override
  public T execute(R request) {
    List<ExtensionContributor<T, R>> contributors = getContributors();
    if (contributors.isEmpty()) {
      return getDefaultResult(request);
    }

    List<T> results = new ArrayList<>();
    for (ExtensionContributor<T, R> contributor : contributors) {
      if (contributor.isApplicable(request)) {
        T result = contributor.contribute(request);
        if (result != null) {
          results.add(result);
        }
      }
    }

    return aggregateResults(results, request);
  }

  @Override
  public T executeFirst(R request) {
    List<ExtensionContributor<T, R>> contributors = getContributors();
    for (ExtensionContributor<T, R> contributor : contributors) {
      if (contributor.isApplicable(request)) {
        T result = contributor.contribute(request);
        if (result != null) {
          return result;
        }
      }
    }
    return getDefaultResult(request);
  }

  /** 获取默认结果（当没有贡献者时） */
  protected T getDefaultResult(R request) {
    return null;
  }

  /** 聚合多个贡献者的结果 */
  protected T aggregateResults(List<T> results, R request) {
    if (results.isEmpty()) {
      return getDefaultResult(request);
    }
    if (results.size() == 1) {
      return results.get(0);
    }
    return aggregateMultipleResults(results, request);
  }

  /** 聚合多个结果（子类可重写） */
  protected T aggregateMultipleResults(List<T> results, R request) {
    // 默认实现：返回第一个结果
    return results.get(0);
  }

  /** 按优先级排序贡献者 */
  protected List<ExtensionContributor<T, R>> sortContributors(
      List<ExtensionContributor<T, R>> contributors) {
    return contributors.stream()
        .sorted(Comparator.comparingInt(ExtensionContributor::getPriority))
        .collect(Collectors.toList());
  }

  /** 过滤贡献者 */
  protected List<ExtensionContributor<T, R>> filterContributors(
      List<ExtensionContributor<T, R>> contributors,
      Predicate<ExtensionContributor<T, R>> predicate) {
    return contributors.stream().filter(predicate).collect(Collectors.toList());
  }
}
