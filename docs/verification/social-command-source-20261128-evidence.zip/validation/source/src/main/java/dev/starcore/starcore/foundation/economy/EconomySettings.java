package dev.starcore.starcore.foundation.economy;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

/**
 * economy.yml 的强类型视图。所有上限/利率参数集中在此，运行时只读。
 *
 * <p>参数语义对齐既有实现：税率上限取 TaxationServiceImpl.MAX_PERCENT_RATE 的语义（0..100）， 债券年利率与
 * WarEconomyService.WarEconomyConfig 同为小数（0.15 = 15%）。
 */
public final class EconomySettings {
  public static final String FILE_NAME = "economy.yml";

  private static final String PATH_CURRENCY = "currency";
  private static final String PATH_TAX = "tax";
  private static final String PATH_TREASURY = "treasury";
  private static final String PATH_BOND = "bond";
  private static final String PATH_WAR_FUND = "war-fund";
  private static final String PATH_DISPLAY = "display";

  private final String currencyName;
  private final String currencySymbol;
  private final BigDecimal maxTaxPercentRate;
  private final BigDecimal treasuryBalanceCap;
  private final BigDecimal minBondFaceValue;
  private final BigDecimal maxBondInterestRate;
  private final int maxBondTermMonths;
  private final int bondTermDecayMonths;
  private final BigDecimal interestDecayPerInterval;
  private final BigDecimal minWarFundContribution;
  private final String balanceLabel;

  private EconomySettings(Builder builder) {
    this.currencyName = builder.currencyName;
    this.currencySymbol = builder.currencySymbol;
    this.maxTaxPercentRate = builder.maxTaxPercentRate;
    this.treasuryBalanceCap = builder.treasuryBalanceCap;
    this.minBondFaceValue = builder.minBondFaceValue;
    this.maxBondInterestRate = builder.maxBondInterestRate;
    this.maxBondTermMonths = builder.maxBondTermMonths;
    this.bondTermDecayMonths = builder.bondTermDecayMonths;
    this.interestDecayPerInterval = builder.interestDecayPerInterval;
    this.minWarFundContribution = builder.minWarFundContribution;
    this.balanceLabel = builder.balanceLabel;
  }

  public static EconomySettings defaults() {
    return builder().build();
  }

  /** 读取数据目录下的 economy.yml；文件缺失时落盘默认配置再读取。 */
  public static EconomySettings load(Plugin plugin) {
    Objects.requireNonNull(plugin, "plugin");
    File file = new File(plugin.getDataFolder(), FILE_NAME);
    if (!file.exists()) {
      plugin.saveResource(FILE_NAME, false);
    }
    return from(YamlConfiguration.loadConfiguration(file));
  }

  public static EconomySettings from(FileConfiguration config) {
    Objects.requireNonNull(config, "config");
    Builder builder = builder();
    builder.currencyName(config.getString(PATH_CURRENCY + ".name", "星尘"));
    builder.currencySymbol(config.getString(PATH_CURRENCY + ".symbol", "✦"));
    builder.balanceLabel(config.getString(PATH_DISPLAY + ".balance-label", "余额"));
    builder.maxTaxPercentRate(decimal(config, PATH_TAX + ".max-percent-rate", "100.00"));
    builder.treasuryBalanceCap(
        decimal(config, PATH_TREASURY + ".balance-cap", "1000000000000000.00"));
    builder.minBondFaceValue(decimal(config, PATH_BOND + ".min-face-value", "100.00"));
    builder.maxBondInterestRate(decimal(config, PATH_BOND + ".max-interest-rate", "0.15"));
    builder.maxBondTermMonths(config.getInt(PATH_BOND + ".max-term-months", 60));
    builder.bondTermDecayMonths(config.getInt(PATH_BOND + ".term-decay-months", 12));
    builder.interestDecayPerInterval(
        decimal(config, PATH_BOND + ".interest-decay-per-interval", "0.01"));
    builder.minWarFundContribution(decimal(config, PATH_WAR_FUND + ".min-contribution", "1.00"));
    return builder.build();
  }

  public static Builder builder() {
    return new Builder();
  }

  private static BigDecimal decimal(FileConfiguration config, String path, String fallback) {
    String raw = config.getString(path, fallback);
    try {
      return new BigDecimal(raw.trim()).setScale(2, RoundingMode.DOWN);
    } catch (NumberFormatException malformed) {
      throw new IllegalStateException("economy.yml 数值字段非法: " + path + "=" + raw, malformed);
    }
  }

  public String currencyName() {
    return currencyName;
  }

  public String currencySymbol() {
    return currencySymbol;
  }

  public BigDecimal maxTaxPercentRate() {
    return maxTaxPercentRate;
  }

  public BigDecimal treasuryBalanceCap() {
    return treasuryBalanceCap;
  }

  public BigDecimal minBondFaceValue() {
    return minBondFaceValue;
  }

  public BigDecimal maxBondInterestRate() {
    return maxBondInterestRate;
  }

  public int maxBondTermMonths() {
    return maxBondTermMonths;
  }

  public int bondTermDecayMonths() {
    return bondTermDecayMonths;
  }

  public BigDecimal interestDecayPerInterval() {
    return interestDecayPerInterval;
  }

  public BigDecimal minWarFundContribution() {
    return minWarFundContribution;
  }

  public String balanceLabel() {
    return balanceLabel;
  }

  /** 期限越长利率越低的分段衰减：每 {@code bondTermDecayMonths} 个月下降一档。 */
  public BigDecimal decayedInterestRate(int termMonths, BigDecimal requestedRate) {
    Objects.requireNonNull(requestedRate, "requestedRate");
    if (bondTermDecayMonths <= 0) {
      return requestedRate.min(maxBondInterestRate);
    }
    int intervals = Math.max(0, termMonths) / bondTermDecayMonths;
    BigDecimal decayed =
        requestedRate.subtract(interestDecayPerInterval.multiply(BigDecimal.valueOf(intervals)));
    if (decayed.signum() < 0) {
      return BigDecimal.ZERO.setScale(2, RoundingMode.DOWN);
    }
    return decayed.min(maxBondInterestRate);
  }

  public BigDecimal taxPercentRate(BigDecimal requestedPercentRate) {
    Objects.requireNonNull(requestedPercentRate, "requestedPercentRate");
    if (requestedPercentRate.signum() < 0) {
      return BigDecimal.ZERO.setScale(2, RoundingMode.DOWN);
    }
    return requestedPercentRate.min(maxTaxPercentRate);
  }

  public static final class Builder {
    private String currencyName = "星尘";
    private String currencySymbol = "✦";
    private BigDecimal maxTaxPercentRate = new BigDecimal("100.00");
    private BigDecimal treasuryBalanceCap = new BigDecimal("1000000000000000.00");
    private BigDecimal minBondFaceValue = new BigDecimal("100.00");
    private BigDecimal maxBondInterestRate = new BigDecimal("0.15");
    private int maxBondTermMonths = 60;
    private int bondTermDecayMonths = 12;
    private BigDecimal interestDecayPerInterval = new BigDecimal("0.01");
    private BigDecimal minWarFundContribution = new BigDecimal("1.00");
    private String balanceLabel = "余额";

    public Builder currencyName(String currencyName) {
      this.currencyName = requireText(currencyName, "currency.name");
      return this;
    }

    public Builder currencySymbol(String currencySymbol) {
      this.currencySymbol = requireText(currencySymbol, "currency.symbol");
      return this;
    }

    public Builder balanceLabel(String balanceLabel) {
      this.balanceLabel = requireText(balanceLabel, "display.balance-label");
      return this;
    }

    public Builder maxTaxPercentRate(BigDecimal maxTaxPercentRate) {
      this.maxTaxPercentRate = requireNonNegative(maxTaxPercentRate, "tax.max-percent-rate");
      return this;
    }

    public Builder treasuryBalanceCap(BigDecimal treasuryBalanceCap) {
      this.treasuryBalanceCap = requirePositive(treasuryBalanceCap, "treasury.balance-cap");
      return this;
    }

    public Builder minBondFaceValue(BigDecimal minBondFaceValue) {
      this.minBondFaceValue = requirePositive(minBondFaceValue, "bond.min-face-value");
      return this;
    }

    public Builder maxBondInterestRate(BigDecimal maxBondInterestRate) {
      if (maxBondInterestRate == null
          || maxBondInterestRate.signum() < 0
          || maxBondInterestRate.compareTo(BigDecimal.ONE) > 0) {
        throw new IllegalArgumentException("bond.max-interest-rate must be within 0..1");
      }
      this.maxBondInterestRate = maxBondInterestRate;
      return this;
    }

    public Builder maxBondTermMonths(int maxBondTermMonths) {
      if (maxBondTermMonths <= 0) {
        throw new IllegalArgumentException("bond.max-term-months must be positive");
      }
      this.maxBondTermMonths = maxBondTermMonths;
      return this;
    }

    public Builder bondTermDecayMonths(int bondTermDecayMonths) {
      if (bondTermDecayMonths < 0) {
        throw new IllegalArgumentException("bond.term-decay-months must not be negative");
      }
      this.bondTermDecayMonths = bondTermDecayMonths;
      return this;
    }

    public Builder interestDecayPerInterval(BigDecimal interestDecayPerInterval) {
      this.interestDecayPerInterval =
          requireNonNegative(interestDecayPerInterval, "bond.interest-decay-per-interval");
      return this;
    }

    public Builder minWarFundContribution(BigDecimal minWarFundContribution) {
      this.minWarFundContribution =
          requirePositive(minWarFundContribution, "war-fund.min-contribution");
      return this;
    }

    public EconomySettings build() {
      return new EconomySettings(this);
    }

    private static String requireText(String value, String field) {
      if (value == null || value.isBlank()) {
        throw new IllegalArgumentException(field + " must not be blank");
      }
      return value;
    }

    private static BigDecimal requireNonNegative(BigDecimal value, String field) {
      if (value == null || value.signum() < 0) {
        throw new IllegalArgumentException(field + " must not be negative");
      }
      return value;
    }

    private static BigDecimal requirePositive(BigDecimal value, String field) {
      if (value == null || value.signum() <= 0) {
        throw new IllegalArgumentException(field + " must be positive");
      }
      return value;
    }
  }

  /** 便于 /eco 等管理命令展示的扁平摘要行。 */
  public List<String> describe() {
    List<String> lines = new ArrayList<>();
    lines.add("货币: " + currencyName + " (" + currencySymbol + ")");
    lines.add("税率上限: " + maxTaxPercentRate.toPlainString() + "%");
    lines.add("国库余额上限: " + treasuryBalanceCap.toPlainString());
    lines.add(
        "债券: 最低面值 "
            + minBondFaceValue.toPlainString()
            + " / 最高利率 "
            + maxBondInterestRate.toPlainString()
            + " / 最长期限 "
            + maxBondTermMonths
            + " 月");
    lines.add(
        "债券区间衰减: 每 " + bondTermDecayMonths + " 月 -" + interestDecayPerInterval.toPlainString());
    return List.copyOf(lines);
  }
}
