package dev.starcore.starcore.foundation.economy.transaction;

/** Canonical lifecycle shared by money/resource delivery workflows. */
public enum EconomyTransactionState {
  CREATED,
  RESERVED,
  DEBITED,
  DELIVERED,
  COMMITTED,
  DEBIT_FAILED,
  DELIVERY_FAILED,
  REFUND_PENDING,
  MANUAL_REVIEW,
  REFUNDED,
  CANCELLED;

  public boolean isTerminal() {
    return this == COMMITTED || this == MANUAL_REVIEW || this == REFUNDED || this == CANCELLED;
  }

  public boolean canTransitionTo(EconomyTransactionState next) {
    if (next == null) return false;
    if (next == this) return true;
    return switch (this) {
      case CREATED ->
          next == RESERVED || next == DEBIT_FAILED || next == MANUAL_REVIEW || next == CANCELLED;
      case RESERVED ->
          next == DEBITED || next == DEBIT_FAILED || next == MANUAL_REVIEW || next == CANCELLED;
      case DEBITED ->
          next == DELIVERED
              || next == DELIVERY_FAILED
              || next == REFUND_PENDING
              || next == MANUAL_REVIEW;
      case DELIVERED ->
          next == COMMITTED
              || next == DELIVERY_FAILED
              || next == REFUND_PENDING
              || next == MANUAL_REVIEW;
      case DEBIT_FAILED ->
          next == REFUND_PENDING || next == MANUAL_REVIEW || next == CREATED || next == CANCELLED;
      case DELIVERY_FAILED -> next == REFUND_PENDING || next == MANUAL_REVIEW || next == CREATED;
      case REFUND_PENDING -> next == CREATED || next == REFUNDED || next == MANUAL_REVIEW;
      case COMMITTED -> next == REFUND_PENDING;
      case MANUAL_REVIEW -> next == REFUNDED;
      case REFUNDED, CANCELLED -> false;
    };
  }
}
