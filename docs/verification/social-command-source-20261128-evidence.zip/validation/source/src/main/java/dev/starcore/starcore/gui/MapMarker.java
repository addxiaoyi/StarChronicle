package dev.starcore.starcore.gui;

import java.util.*;
import java.util.Objects;

/** 地图标记 表示地图上的一个标记点 */
public record MapMarker(
    String id, // 标记ID
    String name, // 标记名称
    String description, // 标记描述
    double x, // X坐标
    double y, // Y坐标
    double zIndex, // Z层级
    String playerId, // 关联玩家ID
    MapMarkerType type, // 标记类型
    Map<String, Object> metadata // 元数据
    ) implements MapElement {

  @Override
  public String getId() {
    return id;
  }

  /** 检查坐标是否在标记范围内 */
  public boolean contains(double checkX, double checkY) {
    double size = 0.1; // 默认大小
    double halfSize = size / 2.0;
    return checkX >= x - halfSize
        && checkX <= x + halfSize
        && checkY >= y - halfSize
        && checkY <= y + halfSize;
  }

  /** 获取名称 */
  public String getName() {
    return name;
  }

  /** 获取描述 */
  public String getDescription() {
    return description;
  }

  /** 获取X坐标 */
  public double getX() {
    return x;
  }

  /** 获取Y坐标 */
  public double getY() {
    return y;
  }

  /** 获取Z层级 */
  public double getZIndex() {
    return zIndex;
  }

  /** 获取标记类型 */
  public MapMarkerType getType() {
    return type;
  }

  /** 地图标记构建器 */
  public static Builder builder(String id, String name, MapMarkerType type) {
    return new Builder(id, name, type);
  }

  public static class Builder {
    private final String id;
    private final String name;
    private final MapMarkerType type;
    private double x = 0.0;
    private double y = 0.0;
    private double zIndex = 0.0;
    private String playerId;
    private String description = "";
    private final Map<String, Object> metadata = new HashMap<>();

    private Builder(String id, String name, MapMarkerType type) {
      this.id = Objects.requireNonNull(id);
      this.name = Objects.requireNonNull(name);
      this.type = Objects.requireNonNull(type);
    }

    public Builder position(double x, double y) {
      this.x = x;
      this.y = y;
      return this;
    }

    public Builder playerId(String playerId) {
      this.playerId = playerId;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public MapMarker build() {
      return new MapMarker(id, name, description, x, y, zIndex, playerId, type, metadata);
    }
  }
}
