package dev.starcore.starcore.foundation.economy.transaction;

/** Identifies the subsystem that owns a durable economic transaction. */
public enum RefundOwner {
  UNKNOWN,
  DONATION,
  DUNGEON,
  TRADE,
  SHOP,
  NATION,
  WAR,
  REPARATIONS,
  RENT,
  MERCENARY,
  SYSTEM
}
