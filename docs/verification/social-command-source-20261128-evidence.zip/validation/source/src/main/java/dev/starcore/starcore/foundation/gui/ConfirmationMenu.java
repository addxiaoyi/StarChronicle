package dev.starcore.starcore.foundation.gui;

import java.util.List;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** 现代化确认对话框 用于需要玩家确认的操作（删除、支付、重要决定等） */
public final class ConfirmationMenu implements InventoryHolder {

  private static final int SIZE = 27;

  private final Inventory inventory;
  private final String title;
  private final String message;
  private final String confirmText;
  private final String cancelText;
  private final Consumer<Player> onConfirm;
  private final Consumer<Player> onCancel;

  public ConfirmationMenu(
      String title, String message, Consumer<Player> onConfirm, Consumer<Player> onCancel) {
    this(title, message, "确认", "取消", onConfirm, onCancel);
  }

  public ConfirmationMenu(
      String title,
      String message,
      String confirmText,
      String cancelText,
      Consumer<Player> onConfirm,
      Consumer<Player> onCancel) {
    this.title = title;
    this.message = message;
    this.confirmText = confirmText;
    this.cancelText = cancelText;
    this.onConfirm = onConfirm;
    this.onCancel = onCancel;

    String titleStr =
        net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
            .serialize(Component.text("§6◆ " + title));
    this.inventory = Bukkit.createInventory(this, SIZE, titleStr);
    build();
  }

  private void build() {
    // Keep the dialog focused: the empty slots are intentional negative space.
    inventory.clear();

    // 标题横幅
    inventory.setItem(13, VisualComponent.titleBanner(title, null));

    // 消息显示
    List<Component> msgLore =
        List.of(
            Component.empty(),
            Component.text("§f" + message, NamedTextColor.WHITE),
            Component.empty(),
            Component.text("§7请确认此操作", NamedTextColor.GRAY),
            Component.empty());
    inventory.setItem(
        11,
        VisualComponent.button(
            Material.PAPER, Component.text("§7操作详情", NamedTextColor.GRAY), msgLore));

    // 确认按钮
    List<Component> confirmLore =
        List.of(
            Component.empty(),
            Component.text("§f" + message, NamedTextColor.WHITE),
            Component.empty(),
            Component.text("§a▶ 点击确认执行", NamedTextColor.GREEN));
    inventory.setItem(
        15,
        VisualComponent.button(
            Material.LIME_STAINED_GLASS_PANE,
            Component.text("§a✓ " + confirmText, NamedTextColor.GREEN)
                .decorate(TextDecoration.BOLD),
            confirmLore));

    // 取消按钮
    List<Component> cancelLore =
        List.of(
            Component.empty(), Component.text("§7点击取消返回", NamedTextColor.GRAY), Component.empty());
    inventory.setItem(
        19,
        VisualComponent.button(
            Material.RED_STAINED_GLASS_PANE,
            Component.text("§c✕ " + cancelText, NamedTextColor.RED),
            cancelLore));

    // 返回按钮
    inventory.setItem(
        22,
        VisualComponent.button(
            Material.BARRIER,
            Component.text("§7⟵ 返回", NamedTextColor.GRAY),
            List.of(Component.empty(), Component.text("§7点击返回上一级", NamedTextColor.GRAY))));
  }

  @Override
  public Inventory getInventory() {
    return inventory;
  }

  public void open(Player player) {
    player.openInventory(inventory);
  }

  public void handleConfirm(Player player) {
    if (onConfirm != null) onConfirm.accept(player);
  }

  public void handleCancel(Player player) {
    if (onCancel != null) onCancel.accept(player);
  }
}
