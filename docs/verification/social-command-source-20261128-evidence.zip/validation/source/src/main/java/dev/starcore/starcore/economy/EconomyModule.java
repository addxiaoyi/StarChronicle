package dev.starcore.starcore.economy;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.economy.loop.InflationAdjuster;
import dev.starcore.starcore.economy.loop.MarketDynamics;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.BudgetService;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import dev.starcore.starcore.war.WarBond;
import dev.starcore.starcore.war.WarEconomyService;
import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.scheduler.BukkitTask;

/**
 * 经济业务聚合模块。
 *
 * <p>不新增任何经济状态，只把已有服务（玩家余额、国库、税收、债务、预算、战争债券）收敛到 统一入口 {@link EconomyService}。所有转发都以 {@code
 * find(...)} 可选解析，缺失的子系统以 0 / false / 100 / empty 表达，绝不伪造数据。
 */
public final class EconomyModule implements StarCoreModule, EconomyService {

  private static final int SCALE = 2;
  private static final int DEFAULT_DEBT_HEALTH = 100;
  private static final long ECONOMY_LOOP_INTERVAL_TICKS = 6000L;
  private static final String STATE_FILE_NAME = "market_state.properties";

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "economy",
          "经济业务聚合",
          ModuleLayer.MODULE,
          List.of(),
          List.of(EconomyService.class),
          "Read/write aggregation entry point over player balances, treasury, and war finance.");

  private StarCoreContext context;
  private InternalEconomyService balances;
  private TreasuryService treasury;
  private WarEconomyService warEconomy;
  private MarketDynamics marketDynamics;
  private InflationAdjuster inflationAdjuster;
  private BukkitTask economyLoopTask;

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  @Override
  public void enable(StarCoreContext context) {
    this.context = context;
    this.balances = context.economyService();
    EconomyManager manager = new EconomyManager();
    this.marketDynamics = new MarketDynamics(manager);
    this.inflationAdjuster = new InflationAdjuster(manager);
    context.serviceRegistry().register(MarketDynamics.class, marketDynamics);
    context.serviceRegistry().register(InflationAdjuster.class, inflationAdjuster);
    File stateFile = new File(context.plugin().getDataFolder(), STATE_FILE_NAME);
    marketDynamics.loadState(stateFile);
    inflationAdjuster.loadState(stateFile);
    economyLoopTask =
        context
            .plugin()
            .getServer()
            .getScheduler()
            .runTaskTimer(
                context.plugin(),
                this::runEconomyLoop,
                ECONOMY_LOOP_INTERVAL_TICKS,
                ECONOMY_LOOP_INTERVAL_TICKS);
    context.plugin().getLogger().info("STARCORE Economy module enabled (aggregation entry point).");
  }

  private void runEconomyLoop() {
    if (marketDynamics == null || inflationAdjuster == null) {
      return;
    }
    marketDynamics.updateMarketDynamics(System.currentTimeMillis());
    inflationAdjuster.update();
  }

  @Override
  public void disable(StarCoreContext context) {
    if (economyLoopTask != null) {
      economyLoopTask.cancel();
      economyLoopTask = null;
    }
    if (this.marketDynamics != null && this.inflationAdjuster != null && context != null) {
      marketDynamics.saveState(new File(context.plugin().getDataFolder(), STATE_FILE_NAME));
      inflationAdjuster.saveState(new File(context.plugin().getDataFolder(), STATE_FILE_NAME));
    }
    if (this.marketDynamics != null) {
      context.serviceRegistry().unregister(MarketDynamics.class);
    }
    if (this.inflationAdjuster != null) {
      context.serviceRegistry().unregister(InflationAdjuster.class);
    }
    this.marketDynamics = null;
    this.inflationAdjuster = null;
    this.context = null;
    this.treasury = null;
    this.warEconomy = null;
  }

  /** 延迟解析底层服务：treasury/war 可能在本模块之后才 enable， 因此在每次调用时补齐缺失引用，避免启用顺序导致的永久空绑定。 */
  private TreasuryService treasury() {
    if (treasury == null && context != null) {
      treasury = context.serviceRegistry().find(TreasuryService.class).orElse(null);
    }
    return treasury;
  }

  private WarEconomyService warEconomy() {
    if (warEconomy == null && context != null) {
      warEconomy = context.serviceRegistry().find(WarEconomyService.class).orElse(null);
    }
    return warEconomy;
  }

  // ==================== 玩家账户 ====================

  @Override
  public BigDecimal getPlayerBalance(UUID playerId) {
    if (playerId == null) {
      return zero();
    }
    return balances.getBalance(playerId);
  }

  @Override
  public boolean depositPlayer(UUID playerId, BigDecimal amount) {
    if (playerId == null || amount == null) {
      return false;
    }
    return balances.deposit(playerId, amount);
  }

  @Override
  public boolean withdrawPlayer(UUID playerId, BigDecimal amount) {
    if (playerId == null || amount == null) {
      return false;
    }
    return balances.withdraw(playerId, amount);
  }

  @Override
  public boolean transferPlayer(UUID from, UUID to, BigDecimal amount) {
    if (from == null || to == null || amount == null) {
      return false;
    }
    return balances.transfer(from, to, amount);
  }

  // ==================== 国家国库 ====================

  @Override
  public BigDecimal getNationBalance(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return zero();
    }
    return service.balance(nationId);
  }

  @Override
  public BigDecimal getNationTotalDebt(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return zero();
    }
    return service.getTotalDebt(nationId);
  }

  @Override
  public BigDecimal getNationMaxBorrowable(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return zero();
    }
    return service.getMaxBorrowableAmount(nationId);
  }

  @Override
  public int getNationDebtHealth(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return DEFAULT_DEBT_HEALTH;
    }
    return service.getDebtHealthScore(nationId);
  }

  @Override
  public boolean isNationBankrupt(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return false;
    }
    return service.isBankrupt(nationId);
  }

  @Override
  public BigDecimal getNationTodayIncome(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return zero();
    }
    return service.getTodayIncome(nationId);
  }

  @Override
  public BigDecimal getNationTodayExpense(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return zero();
    }
    return service.getTodayExpense(nationId);
  }

  @Override
  public Map<TaxationService.TaxType, TaxationService.TaxConfig> getNationTaxConfigs(
      NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return Map.of();
    }
    return service.getTaxConfigs(nationId);
  }

  @Override
  public Optional<BudgetService.BudgetBill> getNationCurrentBudget(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return Optional.empty();
    }
    return service.getCurrentBudget(nationId);
  }

  @Override
  public Optional<TreasuryService.FinanceHealthReport> getNationFinanceHealth(NationId nationId) {
    TreasuryService service = treasury();
    if (nationId == null || service == null) {
      return Optional.empty();
    }
    return Optional.of(service.getFinanceHealthReport(nationId));
  }

  // ==================== 战争财政 ====================

  @Override
  public List<WarBond> getWarBondsOf(NationId nationId) {
    WarEconomyService service = warEconomy();
    if (nationId == null || service == null) {
      return List.of();
    }
    return service.getWarBondsOfNation(nationId);
  }

  @Override
  public Optional<WarBond> getWarBond(UUID bondId) {
    WarEconomyService service = warEconomy();
    if (bondId == null || service == null) {
      return Optional.empty();
    }
    return service.getWarBond(bondId);
  }

  // ==================== 底层服务句柄 ====================

  @Override
  public Optional<TreasuryService> getTreasuryService() {
    return Optional.ofNullable(treasury());
  }

  @Override
  public Optional<WarEconomyService> getWarEconomyService() {
    return Optional.ofNullable(warEconomy());
  }

  @Override
  public String summary() {
    return String.format(
        "EconomyModule[treasury=%s, warEconomy=%s]",
        treasury() != null ? "available" : "absent", warEconomy() != null ? "available" : "absent");
  }

  private static BigDecimal zero() {
    return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
  }
}
