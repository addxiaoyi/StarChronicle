package dev.starcore.starcore.core.module;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class ModuleManager {
  private final Logger logger;
  private final ServiceRegistry serviceRegistry;
  private final Map<String, StarCoreModule> modules = new LinkedHashMap<>();
  private final Map<String, ModuleDescriptor> descriptors = new LinkedHashMap<>();
  private final Map<String, Map<Class<?>, ServiceBinding>> ownedServices = new HashMap<>();

  public ModuleManager(Logger logger, ServiceRegistry serviceRegistry) {
    this.logger = Objects.requireNonNull(logger, "logger");
    this.serviceRegistry = Objects.requireNonNull(serviceRegistry, "serviceRegistry");
  }

  public void register(StarCoreModule module) {
    Objects.requireNonNull(module, "module");
    ModuleMetadata metadata = module.metadata();
    if (modules.containsKey(metadata.id())) {
      throw new ModuleException("Duplicate module id: " + metadata.id());
    }
    modules.put(metadata.id(), module);
    descriptors.put(
        metadata.id(),
        new ModuleDescriptor(
            metadata, ModuleStatus.REGISTERED, Instant.now(), Instant.now(), null));
  }

  public Collection<StarCoreModule> modules() {
    return Collections.unmodifiableCollection(modules.values());
  }

  public Collection<ModuleDescriptor> descriptors() {
    return Collections.unmodifiableCollection(descriptors.values());
  }

  public ServiceRegistry serviceRegistry() {
    return serviceRegistry;
  }

  public void enableAll(StarCoreContext context) {
    for (StarCoreModule module : sortedModules()) {
      enableModule(module, context);
    }
  }

  public void disableAll(StarCoreContext context) {
    List<StarCoreModule> sorted = sortedModules();
    for (int index = sorted.size() - 1; index >= 0; index--) {
      StarCoreModule module = sorted.get(index);
      ModuleDescriptor descriptor = descriptors.get(module.metadata().id());
      if (descriptor == null
          || (descriptor.status() != ModuleStatus.ENABLED
              && descriptor.status() != ModuleStatus.STARTING)) {
        AbstractModuleStateStorage.shutdownNamespace(module.metadata().id());
        releaseOwnedServices(module.metadata().id());
        continue;
      }
      try {
        module.disable(context);
        updateStatus(module.metadata().id(), ModuleStatus.DISABLED, null);
        logger.info(
            "Disabled STARCORE module: "
                + module.metadata().displayName()
                + " ("
                + module.metadata().id()
                + ")");
      } catch (RuntimeException exception) {
        updateStatus(module.metadata().id(), ModuleStatus.FAILED, exception.getMessage());
        logger.log(
            Level.WARNING,
            "Failed to disable STARCORE module: " + module.metadata().id(),
            exception);
      } finally {
        AbstractModuleStateStorage.shutdownNamespace(module.metadata().id());
        releaseOwnedServices(module.metadata().id());
      }
    }
  }

  public boolean markModuleStarting(String moduleId) {
    ModuleDescriptor descriptor = descriptors.get(moduleId);
    if (descriptor == null || descriptor.status() != ModuleStatus.REGISTERED) {
      return false;
    }
    updateStatus(moduleId, ModuleStatus.STARTING, null);
    logger.info("Starting STARCORE module: " + moduleId);
    return true;
  }

  public boolean markDeferredModuleEnabled(String moduleId) {
    ModuleDescriptor descriptor = descriptors.get(moduleId);
    if (descriptor == null || descriptor.status() != ModuleStatus.STARTING) {
      return false;
    }
    updateStatus(moduleId, ModuleStatus.ENABLED, null);
    logger.info("Enabled STARCORE module after deferred startup: " + moduleId);
    return true;
  }

  /** Marks a starting module as failed after deferred startup work completes. */
  public void failEnabledModule(
      String moduleId, StarCoreContext context, RuntimeException failure) {
    Objects.requireNonNull(moduleId, "moduleId");
    Objects.requireNonNull(failure, "failure");
    ModuleDescriptor descriptor = descriptors.get(moduleId);
    if (descriptor == null
        || (descriptor.status() != ModuleStatus.ENABLED
            && descriptor.status() != ModuleStatus.STARTING)) {
      return;
    }

    StarCoreModule module = modules.get(moduleId);
    if (module != null) {
      try {
        module.disable(context);
      } catch (RuntimeException cleanupFailure) {
        failure.addSuppressed(cleanupFailure);
        logger.log(
            Level.WARNING,
            "Failed to clean up module after deferred startup failure: " + moduleId,
            cleanupFailure);
      }
    }
    AbstractModuleStateStorage.shutdownNamespace(moduleId);
    releaseOwnedServices(moduleId);
    updateStatus(moduleId, ModuleStatus.FAILED, failure.getMessage());
    logger.log(Level.SEVERE, "Deferred startup failed for STARCORE module: " + moduleId, failure);
  }

  private void enableModule(StarCoreModule module, StarCoreContext context) {
    ModuleMetadata metadata = module.metadata();
    Map<Class<?>, Object> servicesBeforeEnable = serviceRegistry.snapshot();
    boolean enableStarted = false;
    try {
      for (String dependency : metadata.dependencies()) {
        ModuleDescriptor dependencyDescriptor = descriptors.get(dependency);
        if (dependencyDescriptor == null) {
          throw new ModuleException(
              "Module '" + metadata.id() + "' depends on missing module '" + dependency + "'");
        }
        if (dependencyDescriptor.status() != ModuleStatus.ENABLED) {
          throw new ModuleException(
              "Module '"
                  + metadata.id()
                  + "' depends on module '"
                  + dependency
                  + "' which is not enabled");
        }
      }
      enableStarted = true;
      module.enable(context);
      registerProvidedServices(metadata, module);
      captureOwnedServices(metadata, servicesBeforeEnable);
      ModuleDescriptor afterEnable = descriptors.get(metadata.id());
      if (afterEnable.status() == ModuleStatus.STARTING) {
        logger.info("Started deferred STARCORE module: " + metadata.id());
      } else {
        updateStatus(metadata.id(), ModuleStatus.ENABLED, null);
        logger.info(
            "Enabled STARCORE module: " + metadata.displayName() + " (" + metadata.id() + ")");
      }
    } catch (RuntimeException exception) {
      if (enableStarted) {
        cleanupFailedEnable(module, context, exception);
      }
      AbstractModuleStateStorage.shutdownNamespace(metadata.id());
      restoreProvidedServices(metadata, servicesBeforeEnable);
      ownedServices.remove(metadata.id());
      updateStatus(metadata.id(), ModuleStatus.FAILED, exception.getMessage());
      logger.log(Level.SEVERE, "Failed to enable STARCORE module: " + metadata.id(), exception);
    }
  }

  private void cleanupFailedEnable(
      StarCoreModule module, StarCoreContext context, RuntimeException enableFailure) {
    try {
      module.disable(context);
    } catch (RuntimeException cleanupFailure) {
      enableFailure.addSuppressed(cleanupFailure);
      logger.log(
          Level.WARNING,
          "Failed to clean up partially enabled STARCORE module: " + module.metadata().id(),
          cleanupFailure);
    }
  }

  @SuppressWarnings("unchecked")
  private void registerProvidedServices(ModuleMetadata metadata, StarCoreModule module) {
    for (Class<?> serviceType : metadata.providedServices()) {
      if (!serviceType.isInstance(module)) {
        if (serviceRegistry.find(serviceType).isPresent()) {
          continue;
        }
        logger.warning(
            "STARCORE module '"
                + metadata.id()
                + "' declares service "
                + serviceType.getName()
                + " but the module instance does not implement it; expecting module to register a"
                + " concrete service explicitly.");
        continue;
      }
      serviceRegistry.register((Class<Object>) serviceType, module);
    }
  }

  private void captureOwnedServices(
      ModuleMetadata metadata, Map<Class<?>, Object> servicesBeforeEnable) {
    Map<Class<?>, ServiceBinding> bindings = new HashMap<>();
    for (Class<?> serviceType : metadata.providedServices()) {
      Object previous = servicesBeforeEnable.get(serviceType);
      Object current = findRaw(serviceType);
      if (current != null && current != previous) {
        bindings.put(serviceType, new ServiceBinding(previous, current));
      }
    }
    if (bindings.isEmpty()) {
      ownedServices.remove(metadata.id());
    } else {
      ownedServices.put(metadata.id(), Map.copyOf(bindings));
    }
  }

  private void restoreProvidedServices(
      ModuleMetadata metadata, Map<Class<?>, Object> servicesBeforeEnable) {
    for (Class<?> serviceType : metadata.providedServices()) {
      Object previous = servicesBeforeEnable.get(serviceType);
      Object current = findRaw(serviceType);
      if (current == previous) {
        continue;
      }
      if (previous != null) {
        registerRaw(serviceType, previous);
      } else if (current != null) {
        unregisterRaw(serviceType, current);
      }
    }
  }

  private void releaseOwnedServices(String moduleId) {
    Map<Class<?>, ServiceBinding> bindings = ownedServices.remove(moduleId);
    if (bindings == null) {
      return;
    }
    bindings.forEach(
        (serviceType, binding) -> {
          Object current = findRaw(serviceType);
          if (current == binding.implementation()) {
            if (binding.previous() != null) {
              registerRaw(serviceType, binding.previous());
            } else {
              unregisterRaw(serviceType, binding.implementation());
            }
          } else if (current == null && binding.previous() != null) {
            registerRaw(serviceType, binding.previous());
          }
        });
  }

  @SuppressWarnings("unchecked")
  private Object findRaw(Class<?> serviceType) {
    return serviceRegistry.find((Class<Object>) serviceType).orElse(null);
  }

  @SuppressWarnings("unchecked")
  private void registerRaw(Class<?> serviceType, Object implementation) {
    serviceRegistry.register((Class<Object>) serviceType, implementation);
  }

  @SuppressWarnings("unchecked")
  private void unregisterRaw(Class<?> serviceType, Object implementation) {
    serviceRegistry.unregister((Class<Object>) serviceType, implementation);
  }

  private void updateStatus(String id, ModuleStatus status, String failureReason) {
    ModuleDescriptor previous = descriptors.get(id);
    descriptors.put(
        id,
        new ModuleDescriptor(
            previous.metadata(), status, previous.registeredAt(), Instant.now(), failureReason));
  }

  private record ServiceBinding(Object previous, Object implementation) {}

  private List<StarCoreModule> sortedModules() {
    Map<String, StarCoreModule> remaining = new HashMap<>(modules);
    List<StarCoreModule> sorted = new ArrayList<>();

    while (!remaining.isEmpty()) {
      List<String> enabledIds = sorted.stream().map(module -> module.metadata().id()).toList();
      List<StarCoreModule> ready =
          remaining.values().stream()
              .filter(
                  module ->
                      module.metadata().dependencies().stream()
                          .filter(modules::containsKey)
                          .allMatch(enabledIds::contains))
              .sorted(
                  Comparator.comparing((StarCoreModule module) -> module.metadata().layer())
                      .thenComparing(module -> module.metadata().id()))
              .toList();

      if (ready.isEmpty()) {
        throw new ModuleException(
            "Cyclic or unresolved STARCORE module dependencies: " + remaining.keySet());
      }

      for (StarCoreModule module : ready) {
        sorted.add(module);
        remaining.remove(module.metadata().id());
      }
    }

    return sorted;
  }
}
