package dev.starcore.starcore.gui;

import java.util.*;

/** 地图导航UI 提供地图导航和交互功能 */
public class MapNavigationUI {

  private final String uiId;
  private final String title;
  private final Map<String, MapIcon> icons = new HashMap<>();
  private final List<MapLayer> layers = new ArrayList<>();
  private final Map<String, MapMarker> markers = new HashMap<>();
  private final Map<String, MapRegion> regions = new HashMap<>();

  private int width = 800;
  private int height = 600;
  private double zoomLevel = 1.0;
  private double centerX = 0.5;
  private double centerY = 0.5;
  private boolean isVisible = true;
  private boolean showGrid = true;
  private boolean showIcons = true;
  private boolean showMarkers = true;
  private boolean showRegions = true;

  public MapNavigationUI(String uiId, String title) {
    this.uiId = uiId;
    this.title = title;
  }

  /** 添加地图图标 */
  public void addIcon(MapIcon icon) {
    icons.put(icon.getId(), icon);
  }

  /** 移除地图图标 */
  public void removeIcon(String iconId) {
    icons.remove(iconId);
  }

  /** 获取地图图标 */
  public Optional<MapIcon> getIcon(String iconId) {
    return Optional.ofNullable(icons.get(iconId));
  }

  /** 添加地图图层 */
  public void addLayer(MapLayer layer) {
    layers.add(layer);
    // 按层级排序
    layers.sort(Comparator.comparingDouble(MapLayer::getZIndex));
  }

  /** 移除地图图层 */
  public void removeLayer(String layerId) {
    layers.removeIf(layer -> layer.getId().equals(layerId));
  }

  /** 获取地图图层 */
  public Optional<MapLayer> getLayer(String layerId) {
    return layers.stream().filter(layer -> layer.getId().equals(layerId)).findFirst();
  }

  /** 添加地图标记 */
  public void addMarker(MapMarker marker) {
    markers.put(marker.getId(), marker);
  }

  /** 移除地图标记 */
  public void removeMarker(String markerId) {
    markers.remove(markerId);
  }

  /** 获取地图标记 */
  public Optional<MapMarker> getMarker(String markerId) {
    return Optional.ofNullable(markers.get(markerId));
  }

  /** 添加地图区域 */
  public void addRegion(MapRegion region) {
    regions.put(region.getId(), region);
  }

  /** 移除地图区域 */
  public void removeRegion(String regionId) {
    regions.remove(regionId);
  }

  /** 获取地图区域 */
  public Optional<MapRegion> getRegion(String regionId) {
    return Optional.ofNullable(regions.get(regionId));
  }

  /** 设置缩放级别 */
  public void setZoomLevel(double zoomLevel) {
    this.zoomLevel = Math.max(0.1, Math.min(10.0, zoomLevel));
  }

  /** 缩放地图 */
  public void zoomIn() {
    setZoomLevel(zoomLevel * 1.2);
  }

  /** 缩小地图 */
  public void zoomOut() {
    setZoomLevel(zoomLevel / 1.2);
  }

  /** 重置缩放 */
  public void resetZoom() {
    setZoomLevel(1.0);
  }

  /** 设置中心点 */
  public void setCenter(double x, double y) {
    this.centerX = Math.max(0, Math.min(1, x));
    this.centerY = Math.max(0, Math.min(1, y));
  }

  /** 平移地图 */
  public void pan(double dx, double dy) {
    setCenter(centerX + dx, centerY + dy);
  }

  /** 显示/隐藏UI */
  public void setVisible(boolean visible) {
    this.isVisible = visible;
  }

  /** 切换网格显示 */
  public void toggleGrid() {
    this.showGrid = !showGrid;
  }

  /** 切换图标显示 */
  public void toggleIcons() {
    this.showIcons = !showIcons;
  }

  /** 切换标记显示 */
  public void toggleMarkers() {
    this.showMarkers = !showMarkers;
  }

  /** 切换区域显示 */
  public void toggleRegions() {
    this.showRegions = !showRegions;
  }

  /** 设置地图尺寸 */
  public void setSize(int width, int height) {
    this.width = Math.max(100, width);
    this.height = Math.max(100, height);
  }

  /** 获取UI ID */
  public String getUiId() {
    return uiId;
  }

  /** 获取标题 */
  public String getTitle() {
    return title;
  }

  /** 获取所有图标 */
  public Collection<MapIcon> getIcons() {
    return icons.values();
  }

  /** 获取所有图层 */
  public List<MapLayer> getLayers() {
    return List.copyOf(layers);
  }

  /** 获取所有标记 */
  public Collection<MapMarker> getMarkers() {
    return markers.values();
  }

  /** 获取所有区域 */
  public Collection<MapRegion> getRegions() {
    return regions.values();
  }

  /** 获取缩放级别 */
  public double getZoomLevel() {
    return zoomLevel;
  }

  /** 获取中心点X坐标 */
  public double getCenterX() {
    return centerX;
  }

  /** 获取中心点Y坐标 */
  public double getCenterY() {
    return centerY;
  }

  /** 是否可见 */
  public boolean isVisible() {
    return isVisible;
  }

  /** 是否显示网格 */
  public boolean isShowGrid() {
    return showGrid;
  }

  /** 是否显示图标 */
  public boolean isShowIcons() {
    return showIcons;
  }

  /** 是否显示标记 */
  public boolean isShowMarkers() {
    return showMarkers;
  }

  /** 是否显示区域 */
  public boolean isShowRegions() {
    return showRegions;
  }

  /** 获取宽度 */
  public int getWidth() {
    return width;
  }

  /** 获取高度 */
  public int getHeight() {
    return height;
  }

  /** 清理所有元素 */
  public void clear() {
    icons.clear();
    layers.clear();
    markers.clear();
    regions.clear();
  }

  /** 刷新UI */
  public void refresh() {
    // 重新排序图层
    layers.sort(Comparator.comparingDouble(MapLayer::getZIndex));
  }

  /** 获取在指定位置的元素 */
  public List<MapElement> getElementsAt(double x, double y) {
    List<MapElement> result = new ArrayList<>();

    // 检查标记
    for (MapMarker marker : markers.values()) {
      if (marker.contains(x, y)) {
        result.add(marker);
      }
    }

    // 检查图标
    for (MapIcon icon : icons.values()) {
      if (icon.contains(x, y)) {
        result.add(icon);
      }
    }

    // 检查区域
    for (MapRegion region : regions.values()) {
      if (region.contains(x, y)) {
        result.add(region);
      }
    }

    // 检查图层
    for (MapLayer layer : layers) {
      if (layer.contains(x, y)) {
        result.add(layer);
      }
    }

    // 按层级排序
    result.sort(Comparator.comparingDouble(MapElement::getZIndex));

    return result;
  }

  /** 搜索元素 */
  public List<MapElement> searchElements(String query) {
    List<MapElement> result = new ArrayList<>();
    String lowerQuery = query.toLowerCase();

    // 搜索图标
    for (MapIcon icon : icons.values()) {
      if (icon.getName().toLowerCase().contains(lowerQuery)
          || icon.getDescription().toLowerCase().contains(lowerQuery)) {
        result.add(icon);
      }
    }

    // 搜索标记
    for (MapMarker marker : markers.values()) {
      if (marker.getName().toLowerCase().contains(lowerQuery)
          || marker.getDescription().toLowerCase().contains(lowerQuery)) {
        result.add(marker);
      }
    }

    // 搜索区域
    for (MapRegion region : regions.values()) {
      if (region.getName().toLowerCase().contains(lowerQuery)
          || region.getDescription().toLowerCase().contains(lowerQuery)) {
        result.add(region);
      }
    }

    return result;
  }

  /** 导航到指定位置 */
  public void navigateTo(double x, double y, double zoom) {
    setCenter(x, y);
    setZoomLevel(zoom);
  }

  /** 导航到元素 */
  public void navigateTo(MapElement element) {
    navigateTo(element.getX(), element.getY(), 2.0);
  }

  /** 导航到元素（按ID） */
  public void navigateTo(String elementId) {
    // 尝试查找标记
    getMarker(elementId).ifPresent(this::navigateTo);
    // 尝试查找图标
    getIcon(elementId).ifPresent(this::navigateTo);
    // 尝试查找区域
    getRegion(elementId).ifPresent(this::navigateTo);
  }
}
