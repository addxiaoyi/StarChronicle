package dev.starcore.starcore.achievement;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseUtils;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.NamespacedKey;

/** 成就数据持久化存储 */
public final class AchievementStorage {

  private final String namespace;
  private final DatabaseService databaseService;
  private final PersistenceService persistenceService;
  private final Logger logger;

  // 内存缓存
  private final Map<UUID, AchievementProgress> progressCache =
      new java.util.concurrent.ConcurrentHashMap<>();
  private final Object saveLock = new Object();
  private final ExecutorService saveExecutor;
  private final AtomicBoolean closed = new AtomicBoolean(false);
  private CompletableFuture<Void> pendingSave = CompletableFuture.completedFuture(null);

  public AchievementStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    this.namespace = namespace;
    this.databaseService = databaseService;
    this.persistenceService = persistenceService;
    this.logger = logger;
    this.saveExecutor =
        Executors.newSingleThreadExecutor(
            runnable -> {
              Thread thread = new Thread(runnable, "starcore-achievement-save");
              thread.setDaemon(true);
              return thread;
            });
    initDatabase();
  }

  /** 初始化数据库表 */
  private void initDatabase() {
    if (!databaseService.isRunning()) {
      return;
    }

    try (Connection conn = databaseService.getConnection();
        Statement stmt = conn.createStatement()) {
      String idColumn =
          DatabaseUtils.autoIncrementPrimaryKey(DatabaseUtils.detectDatabaseType(conn));

      // 玩家成就完成记录表
      stmt.execute(
              """
                  CREATE TABLE IF NOT EXISTS starcore_achievements (
                      id %s,
                      player_uuid VARCHAR(36) NOT NULL,
                      achievement_key VARCHAR(128) NOT NULL,
                      namespace VARCHAR(64) NOT NULL,
                      completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                      UNIQUE(player_uuid, achievement_key, namespace)
                  )
              """
              .formatted(idColumn));

      // 玩家成就进度统计表
      stmt.execute(
          """
              CREATE TABLE IF NOT EXISTS starcore_achievement_stats (
                  player_uuid VARCHAR(36) NOT NULL,
                  trigger_type VARCHAR(64) NOT NULL,
                  count_value INT DEFAULT 0,
                  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  PRIMARY KEY(player_uuid, trigger_type)
              )
          """);

      stmt.execute(
          """
              CREATE TABLE IF NOT EXISTS starcore_achievement_reward_pending (
                  player_uuid VARCHAR(36) NOT NULL,
                  achievement_key VARCHAR(128) NOT NULL,
                  namespace VARCHAR(64) NOT NULL,
                  PRIMARY KEY(player_uuid, achievement_key, namespace)
              )
          """);

      stmt.execute(
          """
              CREATE TABLE IF NOT EXISTS starcore_achievement_reward_delivered (
                  player_uuid VARCHAR(36) NOT NULL,
                  reward_token VARCHAR(256) NOT NULL,
                  PRIMARY KEY(player_uuid, reward_token)
              )
          """);

      logger.info("成就数据库表初始化完成");

    } catch (Exception e) {
      logger.warning("初始化成就数据库表失败: " + e.getMessage());
    }
  }

  /** 加载玩家成就进度 */
  public AchievementProgress loadProgress(UUID playerId) {
    // Check the cache first so callers share one canonical progress object.
    AchievementProgress cached = progressCache.get(playerId);
    if (cached != null) {
      return cached;
    }

    AchievementProgress progress = new AchievementProgress(playerId);
    boolean databaseLoaded = false;
    if (databaseService.isRunning()) {
      AchievementProgress databaseProgress = new AchievementProgress(playerId);
      databaseLoaded = loadFromDatabase(playerId, databaseProgress);
      if (databaseLoaded) {
        progress = databaseProgress;
      }
    }

    // Properties is a recovery source, not a second authority that can resurrect stale rows.
    if (!databaseLoaded) {
      loadFromProperties(playerId, progress);
    }

    progressCache.put(playerId, progress);
    return progress;
  }

  /** Load persisted database state. */
  private boolean loadFromDatabase(UUID playerId, AchievementProgress progress) {
    if (!databaseService.isRunning()) {
      return false;
    }

    String sql =
        "SELECT achievement_key, namespace FROM starcore_achievements WHERE player_uuid = ?";

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {

      pstmt.setString(1, playerId.toString());
      ResultSet rs = pstmt.executeQuery();

      while (rs.next()) {
        String key = rs.getString("achievement_key");
        String ns = rs.getString("namespace");
        try {
          progress.markCompleted(new NamespacedKey(ns, key));
        } catch (IllegalArgumentException invalidKey) {
          logger.warning("Invalid achievement record ignored: " + ns + ":" + key);
        }
      }

      String statsSql =
          "SELECT trigger_type, count_value FROM starcore_achievement_stats WHERE player_uuid = ?";
      try (PreparedStatement statsStmt = conn.prepareStatement(statsSql)) {
        statsStmt.setString(1, playerId.toString());
        ResultSet statsRs = statsStmt.executeQuery();
        while (statsRs.next()) {
          String triggerType = statsRs.getString("trigger_type");
          int count = statsRs.getInt("count_value");
          if (count >= 0 && triggerType != null && !triggerType.isBlank()) {
            progress.setTriggerCount(triggerType, count);
          }
        }
      }

      String pendingSql =
          "SELECT achievement_key, namespace FROM starcore_achievement_reward_pending WHERE"
              + " player_uuid = ?";
      try (PreparedStatement pendingStmt = conn.prepareStatement(pendingSql)) {
        pendingStmt.setString(1, playerId.toString());
        try (ResultSet pendingRs = pendingStmt.executeQuery()) {
          while (pendingRs.next()) {
            try {
              progress.markRewardPending(
                  new NamespacedKey(
                      pendingRs.getString("namespace"), pendingRs.getString("achievement_key")));
            } catch (IllegalArgumentException invalidKey) {
              logger.warning("Invalid pending reward record ignored");
            }
          }
        }
      }

      String deliveredSql =
          "SELECT reward_token FROM starcore_achievement_reward_delivered WHERE player_uuid = ?";
      try (PreparedStatement deliveredStmt = conn.prepareStatement(deliveredSql)) {
        deliveredStmt.setString(1, playerId.toString());
        try (ResultSet deliveredRs = deliveredStmt.executeQuery()) {
          while (deliveredRs.next()) {
            String token = deliveredRs.getString("reward_token");
            if (token != null && !token.isBlank()) {
              progress.markDeliveredRewardToken(token);
            }
          }
        }
      }
      return true;
    } catch (Exception e) {
      logger.warning("Failed to load achievement progress: " + e.getMessage());
      return false;
    }
  }

  /** 从 Properties 文件加载 */
  private void loadFromProperties(UUID playerId, AchievementProgress progress) {
    try {
      String fileName = "achievements_" + playerId.toString() + ".properties";
      Properties props = persistenceService.loadProperties(namespace, fileName);

      if (props != null && !props.isEmpty()) {
        // 加载已完成的成就
        String completedList = props.getProperty("completed", "");
        if (!completedList.isEmpty()) {
          for (String key : completedList.split(",")) {
            String[] parts = key.trim().split(":", 2);
            if (parts.length == 2 && !parts[0].isBlank() && !parts[1].isBlank()) {
              try {
                progress.markCompleted(new NamespacedKey(parts[0], parts[1]));
              } catch (IllegalArgumentException invalidKey) {
                logger.warning("Properties achievement key ignored: " + key);
              }
            }
          }
        }

        // 加载触发器计数
        String pendingRewards = props.getProperty("pendingRewards", "");
        for (String raw : pendingRewards.split(",")) {
          String[] parts = raw.trim().split(":", 2);
          if (parts.length == 2 && !parts[0].isBlank() && !parts[1].isBlank()) {
            try {
              progress.markRewardPending(new NamespacedKey(parts[0], parts[1]));
            } catch (IllegalArgumentException ignored) {
              logger.warning("Invalid pending reward key ignored");
            }
          }
        }

        String deliveredRewards = props.getProperty("deliveredRewards", "");
        for (String token : deliveredRewards.split(",")) {
          if (!token.isBlank()) progress.markDeliveredRewardToken(token.trim());
        }

        for (String name : props.stringPropertyNames()) {
          if (name.startsWith("trigger.")) {
            String triggerKey = name.substring(8);
            try {
              int count = Integer.parseInt(props.getProperty(name, "0"));
              if (count >= 0 && !triggerKey.isBlank()) {
                progress.setTriggerCount(triggerKey, count);
              }
            } catch (NumberFormatException invalidCount) {
              logger.warning("Properties �ļ��д�������ͳ��: " + name);
            }
          }
        }
      }
    } catch (Exception e) {
      logger.warning("从 Properties 加载玩家成就数据失败: " + e.getMessage());
    }
  }

  /** 保存玩家成就进度 */
  public void saveProgress(AchievementProgress progress) {
    ensureOpen();
    Objects.requireNonNull(progress, "progress");
    progressCache.put(progress.getPlayerId(), progress);
    AchievementSnapshot snapshot = AchievementSnapshot.from(progress);

    if (databaseService.isRunning()) {
      saveToDatabaseAsync(snapshot);
    } else {
      saveToProperties(snapshot);
    }
  }

  /** 异步保存到数据库 */
  private void saveToDatabaseAsync(AchievementSnapshot snapshot) {
    if (!databaseService.isRunning()) {
      return;
    }

    synchronized (saveLock) {
      ensureOpen();
      pendingSave =
          pendingSave
              .handle((ignored, failure) -> null)
              .thenRunAsync(() -> saveToDatabase(snapshot), saveExecutor);
    }
  }

  private void saveToDatabase(AchievementSnapshot snapshot) {
    Connection conn = null;
    try {
      conn = databaseService.getConnection();
      conn.setAutoCommit(false);
      boolean sqlite = "SQLite".equalsIgnoreCase(conn.getMetaData().getDatabaseProductName());

      // 保存完成的成就
      String insertSql =
          sqlite
              ? "INSERT OR IGNORE INTO starcore_achievements (player_uuid, achievement_key,"
                  + " namespace) VALUES (?, ?, ?)"
              : "INSERT IGNORE INTO starcore_achievements (player_uuid, achievement_key, namespace)"
                  + " VALUES (?, ?, ?)";
      try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
        for (NamespacedKey key : snapshot.completedAchievements()) {
          pstmt.setString(1, snapshot.playerId().toString());
          pstmt.setString(2, key.getKey());
          pstmt.setString(3, key.getNamespace());
          pstmt.addBatch();
        }
        pstmt.executeBatch();
      }

      // 保存触发器计数
      String upsertSql =
          sqlite
              ?
              """
INSERT INTO starcore_achievement_stats (player_uuid, trigger_type, count_value)
VALUES (?, ?, ?)
ON CONFLICT(player_uuid, trigger_type) DO UPDATE SET count_value = excluded.count_value
"""
              :
              """
              INSERT INTO starcore_achievement_stats (player_uuid, trigger_type, count_value)
              VALUES (?, ?, ?)
              ON DUPLICATE KEY UPDATE count_value = VALUES(count_value)
              """;
      try (PreparedStatement pstmt = conn.prepareStatement(upsertSql)) {
        for (Map.Entry<String, Integer> entry : snapshot.triggerCounts().entrySet()) {
          pstmt.setString(1, snapshot.playerId().toString());
          pstmt.setString(2, entry.getKey());
          pstmt.setInt(3, entry.getValue());
          pstmt.addBatch();
        }
        pstmt.executeBatch();
      }

      try (PreparedStatement clearPending =
          conn.prepareStatement(
              "DELETE FROM starcore_achievement_reward_pending WHERE player_uuid = ?")) {
        clearPending.setString(1, snapshot.playerId().toString());
        clearPending.executeUpdate();
      }
      try (PreparedStatement pendingStmt =
          conn.prepareStatement(
              "INSERT INTO starcore_achievement_reward_pending (player_uuid, achievement_key,"
                  + " namespace) VALUES (?, ?, ?)")) {
        for (NamespacedKey key : snapshot.pendingRewards()) {
          pendingStmt.setString(1, snapshot.playerId().toString());
          pendingStmt.setString(2, key.getKey());
          pendingStmt.setString(3, key.getNamespace());
          pendingStmt.addBatch();
        }
        pendingStmt.executeBatch();
      }

      try (PreparedStatement clearDelivered =
          conn.prepareStatement(
              "DELETE FROM starcore_achievement_reward_delivered WHERE player_uuid = ?")) {
        clearDelivered.setString(1, snapshot.playerId().toString());
        clearDelivered.executeUpdate();
      }
      try (PreparedStatement deliveredStmt =
          conn.prepareStatement(
              "INSERT INTO starcore_achievement_reward_delivered (player_uuid, reward_token) VALUES"
                  + " (?, ?)")) {
        for (String token : snapshot.deliveredRewards()) {
          deliveredStmt.setString(1, snapshot.playerId().toString());
          deliveredStmt.setString(2, token);
          deliveredStmt.addBatch();
        }
        deliveredStmt.executeBatch();
      }

      conn.commit();
    } catch (Exception e) {
      logger.warning("保存玩家成就数据失败 (UUID: " + snapshot.playerId() + "): " + e.getMessage());
      if (conn != null) {
        try {
          conn.rollback();
          logger.info("已回滚事务，玩家UUID: " + snapshot.playerId());
        } catch (SQLException rollbackEx) {
          logger.severe(
              "回滚事务失败，玩家UUID: " + snapshot.playerId() + ", 错误: " + rollbackEx.getMessage());
        }
      }
      // 回退到 Properties 文件作为备份
      try {
        saveToProperties(snapshot);
        logger.info("已使用 Properties 文件作为备份保存，玩家UUID: " + snapshot.playerId());
      } catch (Exception propEx) {
        logger.severe(
            "Properties 备份保存也失败了，玩家UUID: " + snapshot.playerId() + ", 错误: " + propEx.getMessage());
      }
    } finally {
      if (conn != null) {
        try {
          conn.close();
        } catch (SQLException closeEx) {
          logger.warning("关闭数据库连接失败: " + closeEx.getMessage());
        }
      }
    }
  }

  /** 保存到 Properties 文件（带容错机制） */
  private void saveToProperties(AchievementSnapshot snapshot) {
    String fileName = "achievements_" + snapshot.playerId() + ".properties";

    try {
      java.nio.file.Path namespacePath = persistenceService.namespacePath(namespace);
      java.nio.file.Path file = namespacePath.resolve(fileName);
      java.nio.file.Path tempFile = namespacePath.resolve(fileName + ".tmp");
      java.nio.file.Path backupFile = namespacePath.resolve(fileName + ".bak");

      Properties props = new Properties();

      // 保存已完成的成就
      StringBuilder completed = new StringBuilder();
      for (NamespacedKey key : snapshot.completedAchievements()) {
        if (completed.length() > 0) {
          completed.append(",");
        }
        completed.append(key.getNamespace()).append(":").append(key.getKey());
      }
      props.setProperty("completed", completed.toString());

      // 保存触发器计数
      StringBuilder pending = new StringBuilder();
      for (NamespacedKey key : snapshot.pendingRewards()) {
        if (pending.length() > 0) pending.append(",");
        pending.append(key.getNamespace()).append(":").append(key.getKey());
      }
      props.setProperty("pendingRewards", pending.toString());

      props.setProperty("deliveredRewards", String.join(",", snapshot.deliveredRewards()));

      for (Map.Entry<String, Integer> entry : snapshot.triggerCounts().entrySet()) {
        props.setProperty("trigger." + entry.getKey(), String.valueOf(entry.getValue()));
      }

      // 先写入临时文件
      try (java.io.OutputStream out = java.nio.file.Files.newOutputStream(tempFile)) {
        props.store(out, "Achievement data for player " + snapshot.playerId());
      }

      // 如果原文件存在，先备份
      if (java.nio.file.Files.exists(file)) {
        // 删除旧备份
        if (java.nio.file.Files.exists(backupFile)) {
          java.nio.file.Files.delete(backupFile);
        }
        // 重命名当前文件为备份
        try {
          java.nio.file.Files.move(file, backupFile);
        } catch (Exception e) {
          logger.warning("无法创建成就数据备份: " + fileName);
        }
      }

      // 将临时文件重命名为正式文件（原子操作）
      try {
        java.nio.file.Files.move(tempFile, file, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
      } catch (Exception e) {
        logger.severe("无法完成成就数据保存，临时文件: " + tempFile.toAbsolutePath());
        // 如果重命名失败，尝试恢复备份
        if (java.nio.file.Files.exists(backupFile) && !java.nio.file.Files.exists(file)) {
          try {
            java.nio.file.Files.move(backupFile, file);
            logger.warning("已从备份恢复成就数据: " + fileName);
          } catch (Exception restoreError) {
            logger.severe("恢复备份失败: " + restoreError.getMessage());
            logger.log(Level.SEVERE, "成就数据备份恢复异常", restoreError);
          }
        }
        throw e;
      }
    } catch (Exception e) {
      logger.severe("保存成就数据到文件失败: " + e.getMessage());
      logger.log(Level.SEVERE, "成就数据保存异常", e);
    }
  }

  /** 记录成就完成 */
  public void recordAchievementCompletion(UUID playerId, NamespacedKey achievementKey) {
    Objects.requireNonNull(playerId, "playerId");
    Objects.requireNonNull(achievementKey, "achievementKey");
    AchievementProgress progress =
        progressCache.computeIfAbsent(playerId, k -> new AchievementProgress(k));
    progress.markCompleted(achievementKey);
    saveProgress(progress);
  }

  /** 增加触发器计数并保存 */
  public void incrementAndSaveTriggerCount(UUID playerId, String triggerType, int amount) {
    Objects.requireNonNull(playerId, "playerId");
    if (triggerType == null || triggerType.isBlank() || amount <= 0) {
      return;
    }
    AchievementProgress progress =
        progressCache.computeIfAbsent(playerId, k -> new AchievementProgress(k));
    progress.incrementTriggerCount(triggerType, amount);
    saveProgress(progress);
  }

  /** 获取玩家成就完成数量 */
  public int getCompletedCount(UUID playerId) {
    AchievementProgress progress = progressCache.get(playerId);
    if (progress == null) {
      progress = loadProgress(playerId);
    }
    return progress.getCompletedAchievements().size();
  }

  public void shutdown() {
    if (!closed.compareAndSet(false, true)) {
      return;
    }
    CompletableFuture<Void> pending;
    synchronized (saveLock) {
      pending = pendingSave;
    }
    try {
      pending.join();
    } finally {
      saveExecutor.shutdown();
    }
    try {
      if (!saveExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
        saveExecutor.shutdownNow();
        logger.warning("等待成就保存队列关闭超时");
      }
    } catch (InterruptedException interrupted) {
      saveExecutor.shutdownNow();
      Thread.currentThread().interrupt();
    }
  }

  private void ensureOpen() {
    if (closed.get()) {
      throw new IllegalStateException("Achievement storage is already closed");
    }
  }

  private record AchievementSnapshot(
      UUID playerId,
      Set<NamespacedKey> completedAchievements,
      Set<NamespacedKey> pendingRewards,
      Set<String> deliveredRewards,
      Map<String, Integer> triggerCounts) {
    private static AchievementSnapshot from(AchievementProgress progress) {
      return new AchievementSnapshot(
          progress.getPlayerId(),
          Set.copyOf(progress.getCompletedAchievements()),
          Set.copyOf(progress.getPendingRewards()),
          Set.copyOf(progress.getDeliveredRewards()),
          Map.copyOf(progress.getAllTriggerCounts()));
    }
  }

  /** 清理缓存 */
  public void clearCache() {
    progressCache.clear();
  }

  /** 清理特定玩家缓存 */
  public void clearCache(UUID playerId) {
    progressCache.remove(playerId);
  }
}
