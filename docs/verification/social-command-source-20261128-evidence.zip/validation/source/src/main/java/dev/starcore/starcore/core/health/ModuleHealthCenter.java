package dev.starcore.starcore.core.health;

import dev.starcore.starcore.core.metrics.PerformanceMetricsService;
import dev.starcore.starcore.core.metrics.PerformanceSnapshot;
import dev.starcore.starcore.core.module.ModuleDescriptor;
import dev.starcore.starcore.core.module.ModuleManager;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerSummary;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionSummary;
import java.time.Instant;
import java.util.List;
import java.util.Objects;

/** Aggregates lifecycle, transaction, refund, and performance health in one read model. */
public final class ModuleHealthCenter {
  private final ModuleManager moduleManager;
  private final ServiceRegistry services;

  public ModuleHealthCenter(ModuleManager moduleManager, ServiceRegistry services) {
    this.moduleManager = Objects.requireNonNull(moduleManager, "moduleManager");
    this.services = Objects.requireNonNull(services, "services");
  }

  public ModuleHealthSnapshot snapshot() {
    List<ModuleHealthEntry> modules =
        moduleManager.descriptors().stream()
            .map(ModuleHealthCenter::toEntry)
            .sorted(java.util.Comparator.comparing(ModuleHealthEntry::id))
            .toList();
    TransactionSummary transactions =
        services
            .find(TransactionFabric.class)
            .map(TransactionFabric::summarize)
            .orElseGet(
                () ->
                    new TransactionSummary(
                        0,
                        0,
                        0,
                        0,
                        java.util.Map.of(),
                        java.util.Map.of(),
                        java.util.Optional.empty()));
    RefundLedgerSummary refunds =
        services
            .find(RefundLedgerService.class)
            .map(RefundLedgerService::ledger)
            .map(ledger -> ledger.summarize(Instant.now()))
            .orElseGet(
                () ->
                    new RefundLedgerSummary(
                        0, 0, 0, 0, java.util.Map.of(), java.util.Optional.empty()));
    PerformanceSnapshot performance =
        services
            .find(PerformanceMetricsService.class)
            .map(PerformanceMetricsService::snapshot)
            .orElseGet(
                () ->
                    new PerformanceSnapshot(
                        Instant.now(),
                        java.time.Duration.ZERO,
                        java.util.Map.of(),
                        java.util.Map.of()));
    return new ModuleHealthSnapshot(Instant.now(), modules, transactions, refunds, performance);
  }

  private static ModuleHealthEntry toEntry(ModuleDescriptor descriptor) {
    return new ModuleHealthEntry(
        descriptor.metadata().id(),
        descriptor.metadata().displayName(),
        descriptor.metadata().layer(),
        descriptor.status(),
        descriptor.lastChangedAt(),
        descriptor.failureReason(),
        descriptor.metadata().dependencies());
  }
}
