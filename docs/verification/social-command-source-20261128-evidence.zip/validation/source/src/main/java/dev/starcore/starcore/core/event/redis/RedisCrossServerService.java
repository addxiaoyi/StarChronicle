package dev.starcore.starcore.core.event.redis;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.exceptions.JedisConnectionException;

/** Optional Redis Pub/Sub transport for cross-server notifications. */
public final class RedisCrossServerService implements AutoCloseable {
  private static final int MAX_MESSAGE_BYTES = 1_048_576;
  private static final int MAX_RECENT_MESSAGE_IDS = 10_000;
  private static final int MAX_PUBLISH_CONNECTION_ATTEMPTS = 2;
  private static final long MAX_RECONNECT_DELAY_MILLIS = 30_000;
  private static final Gson GSON = new Gson();

  public enum State {
    DISABLED,
    CONNECTING,
    CONNECTED,
    DEGRADED,
    CLOSED
  }

  public record Settings(
      boolean enabled,
      String host,
      int port,
      String password,
      int database,
      String channel,
      boolean tls) {
    public Settings(
        boolean enabled, String host, int port, String password, int database, String channel) {
      this(enabled, host, port, password, database, channel, false);
    }

    public Settings {
      host = host == null ? "" : host.trim();
      password = password == null ? "" : password;
      channel = channel == null ? "" : channel.trim();
    }
  }

  public record Message(
      String id, String originServerId, String type, long publishedAtMillis, JsonElement payload) {
    public Message {
      payload = payload == null ? null : payload.deepCopy();
    }
  }

  /** Immutable transport counters and health details for operators and acceptance harnesses. */
  public record Diagnostics(
      State state,
      boolean running,
      String serverId,
      String endpoint,
      String channel,
      long connectionAttempts,
      long connectionSuccesses,
      long connectionFailures,
      long publishAttempts,
      long publishSuccesses,
      long publishFailures,
      long receivedMessages,
      long deliveredMessages,
      long duplicateMessages,
      long selfMessages,
      long rejectedMessages,
      long unhandledMessages,
      long dispatchFailures,
      long handlerFailures,
      long lastConnectedAtMillis,
      long lastFailureAtMillis,
      String lastFailure) {}

  private final Settings settings;
  private final Logger logger;
  private final Consumer<Runnable> mainThreadDispatcher;
  private final String serverId = UUID.randomUUID().toString();
  private final AtomicBoolean running = new AtomicBoolean();
  private final AtomicReference<State> state = new AtomicReference<>(State.DISABLED);
  private final Map<String, List<Consumer<Message>>> listeners =
      new java.util.concurrent.ConcurrentHashMap<>();
  private final Map<String, Boolean> recentMessageIds =
      java.util.Collections.synchronizedMap(
          new LinkedHashMap<>(MAX_RECENT_MESSAGE_IDS, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
              return size() > MAX_RECENT_MESSAGE_IDS;
            }
          });
  private final ExecutorService subscriberExecutor;
  private final ExecutorService publisherExecutor;
  private final AtomicLong connectionAttempts = new AtomicLong();
  private final AtomicLong connectionSuccesses = new AtomicLong();
  private final AtomicLong connectionFailures = new AtomicLong();
  private final AtomicLong publishAttempts = new AtomicLong();
  private final AtomicLong publishSuccesses = new AtomicLong();
  private final AtomicLong publishFailures = new AtomicLong();
  private final AtomicLong receivedMessages = new AtomicLong();
  private final AtomicLong deliveredMessages = new AtomicLong();
  private final AtomicLong duplicateMessages = new AtomicLong();
  private final AtomicLong selfMessages = new AtomicLong();
  private final AtomicLong rejectedMessages = new AtomicLong();
  private final AtomicLong unhandledMessages = new AtomicLong();
  private final AtomicLong dispatchFailures = new AtomicLong();
  private final AtomicLong handlerFailures = new AtomicLong();
  private final AtomicLong lastConnectedAtMillis = new AtomicLong();
  private final AtomicLong lastFailureAtMillis = new AtomicLong();
  private final HostAndPort endpoint;
  private final DefaultJedisClientConfig clientConfig;
  private volatile JedisPool pool;
  private volatile JedisPubSub activeSubscription;
  private volatile String lastFailure = "";

  public RedisCrossServerService(
      Settings settings, Logger logger, Consumer<Runnable> mainThreadDispatcher) {
    this.settings = settings;
    this.logger = logger;
    this.mainThreadDispatcher = mainThreadDispatcher;
    this.subscriberExecutor =
        java.util.concurrent.Executors.newSingleThreadExecutor(
            namedDaemon("StarCore-Redis-Subscriber"));
    this.publisherExecutor =
        new ThreadPoolExecutor(
            1,
            1,
            0,
            TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(256),
            namedDaemon("StarCore-Redis-Publisher"),
            new ThreadPoolExecutor.AbortPolicy());
    if (!settings.enabled()) {
      this.endpoint = null;
      this.clientConfig = null;
      state.set(State.DISABLED);
      return;
    }
    validateSettings(settings);
    this.endpoint = new HostAndPort(settings.host(), settings.port());
    this.clientConfig = clientConfig(settings, false);
    JedisPoolConfig poolConfig = new JedisPoolConfig();
    poolConfig.setMaxTotal(4);
    poolConfig.setMaxIdle(2);
    poolConfig.setMinIdle(0);
    poolConfig.setBlockWhenExhausted(true);
    poolConfig.setMaxWait(DurationHolder.POOL_WAIT);
    this.pool = new JedisPool(poolConfig, endpoint, clientConfig);
  }

  public synchronized void start() {
    if (!settings.enabled() || state.get() == State.CLOSED || !running.compareAndSet(false, true))
      return;
    state.set(State.CONNECTING);
    subscriberExecutor.execute(this::subscribeLoop);
  }

  public State state() {
    return state.get();
  }

  public String serverId() {
    return serverId;
  }

  public String lastFailure() {
    return lastFailure;
  }

  /** Returns a point-in-time snapshot without exposing the configured Redis password. */
  public Diagnostics diagnostics() {
    return new Diagnostics(
        state.get(),
        running.get(),
        serverId,
        endpoint == null ? "" : endpoint.toString(),
        settings.channel(),
        connectionAttempts.get(),
        connectionSuccesses.get(),
        connectionFailures.get(),
        publishAttempts.get(),
        publishSuccesses.get(),
        publishFailures.get(),
        receivedMessages.get(),
        deliveredMessages.get(),
        duplicateMessages.get(),
        selfMessages.get(),
        rejectedMessages.get(),
        unhandledMessages.get(),
        dispatchFailures.get(),
        handlerFailures.get(),
        lastConnectedAtMillis.get(),
        lastFailureAtMillis.get(),
        lastFailure);
  }

  /** Exports the current Redis transport diagnostics as Prometheus text metrics. */
  public String exportPrometheusMetrics() {
    Diagnostics diagnostics = diagnostics();
    StringBuilder metrics = new StringBuilder();

    appendMetric(
        metrics,
        "starcore_redis_transport_up",
        "gauge",
        "Redis transport connection health (1 when connected)",
        diagnostics.state() == State.CONNECTED ? 1 : 0);
    appendMetric(
        metrics,
        "starcore_redis_transport_running",
        "gauge",
        "Redis transport lifecycle state (1 when running)",
        diagnostics.running() ? 1 : 0);
    appendMetricWithLabel(
        metrics,
        "starcore_redis_transport_state",
        "gauge",
        "Redis transport state",
        "state",
        diagnostics.state().name(),
        1);
    appendMetricWithLabels(
        metrics,
        "starcore_redis_transport_info",
        "gauge",
        "Redis transport identity and endpoint",
        "server_id",
        diagnostics.serverId(),
        "endpoint",
        diagnostics.endpoint(),
        "channel",
        diagnostics.channel(),
        1);

    appendMetric(
        metrics,
        "starcore_redis_connection_attempts_total",
        "counter",
        "Redis connection attempts",
        diagnostics.connectionAttempts());
    appendMetric(
        metrics,
        "starcore_redis_connection_successes_total",
        "counter",
        "Redis connection successes",
        diagnostics.connectionSuccesses());
    appendMetric(
        metrics,
        "starcore_redis_connection_failures_total",
        "counter",
        "Redis connection failures",
        diagnostics.connectionFailures());
    appendMetric(
        metrics,
        "starcore_redis_publish_attempts_total",
        "counter",
        "Redis publish attempts",
        diagnostics.publishAttempts());
    appendMetric(
        metrics,
        "starcore_redis_publish_successes_total",
        "counter",
        "Redis publish successes",
        diagnostics.publishSuccesses());
    appendMetric(
        metrics,
        "starcore_redis_publish_failures_total",
        "counter",
        "Redis publish failures",
        diagnostics.publishFailures());
    appendMetric(
        metrics,
        "starcore_redis_received_messages_total",
        "counter",
        "Redis messages received",
        diagnostics.receivedMessages());
    appendMetric(
        metrics,
        "starcore_redis_delivered_messages_total",
        "counter",
        "Redis messages delivered",
        diagnostics.deliveredMessages());
    appendMetric(
        metrics,
        "starcore_redis_duplicate_messages_total",
        "counter",
        "Redis duplicate messages",
        diagnostics.duplicateMessages());
    appendMetric(
        metrics,
        "starcore_redis_self_messages_total",
        "counter",
        "Redis self messages ignored",
        diagnostics.selfMessages());
    appendMetric(
        metrics,
        "starcore_redis_rejected_messages_total",
        "counter",
        "Redis rejected messages",
        diagnostics.rejectedMessages());
    appendMetric(
        metrics,
        "starcore_redis_unhandled_messages_total",
        "counter",
        "Redis unhandled messages",
        diagnostics.unhandledMessages());
    appendMetric(
        metrics,
        "starcore_redis_dispatch_failures_total",
        "counter",
        "Redis dispatch failures",
        diagnostics.dispatchFailures());
    appendMetric(
        metrics,
        "starcore_redis_handler_failures_total",
        "counter",
        "Redis handler failures",
        diagnostics.handlerFailures());
    appendMetric(
        metrics,
        "starcore_redis_last_connected_at_seconds",
        "gauge",
        "Unix time of the last successful Redis connection",
        epochSeconds(diagnostics.lastConnectedAtMillis()));
    appendMetric(
        metrics,
        "starcore_redis_last_failure_at_seconds",
        "gauge",
        "Unix time of the last Redis failure",
        epochSeconds(diagnostics.lastFailureAtMillis()));
    appendMetric(
        metrics,
        "starcore_redis_last_failure_present",
        "gauge",
        "Whether a Redis failure message is available",
        diagnostics.lastFailure().isBlank() ? 0 : 1);

    return metrics.toString();
  }

  private static void appendMetric(
      StringBuilder metrics, String name, String type, String help, long value) {
    metrics.append("# HELP ").append(name).append(' ').append(help).append('\n');
    metrics.append("# TYPE ").append(name).append(' ').append(type).append('\n');
    metrics.append(name).append(' ').append(value).append("\n\n");
  }

  private static void appendMetricWithLabel(
      StringBuilder metrics,
      String name,
      String type,
      String help,
      String labelKey,
      String labelValue,
      long value) {
    metrics.append("# HELP ").append(name).append(' ').append(help).append('\n');
    metrics.append("# TYPE ").append(name).append(' ').append(type).append('\n');
    metrics
        .append(name)
        .append('{')
        .append(labelKey)
        .append("=\"")
        .append(escapeLabel(labelValue))
        .append("\"} ")
        .append(value)
        .append("\n\n");
  }

  private static void appendMetricWithLabels(
      StringBuilder metrics,
      String name,
      String type,
      String help,
      String label1Key,
      String label1Value,
      String label2Key,
      String label2Value,
      String label3Key,
      String label3Value,
      long value) {
    metrics.append("# HELP ").append(name).append(' ').append(help).append('\n');
    metrics.append("# TYPE ").append(name).append(' ').append(type).append('\n');
    metrics
        .append(name)
        .append('{')
        .append(label1Key)
        .append("=\"")
        .append(escapeLabel(label1Value))
        .append("\",")
        .append(label2Key)
        .append("=\"")
        .append(escapeLabel(label2Value))
        .append("\",")
        .append(label3Key)
        .append("=\"")
        .append(escapeLabel(label3Value))
        .append("\"} ")
        .append(value)
        .append("\n\n");
  }

  private static long epochSeconds(long epochMillis) {
    return epochMillis <= 0 ? 0 : epochMillis / 1_000;
  }

  private static String escapeLabel(String value) {
    return value.replace("\\", "\\\\").replace("\n", "\\n").replace("\"", "\\\"");
  }

  public synchronized AutoCloseable subscribe(String type, Consumer<Message> listener) {
    validateType(type);
    if (listener == null) throw new IllegalArgumentException("listener must not be null");
    if (state.get() == State.CLOSED) {
      throw new IllegalStateException("Redis transport is closed");
    }
    List<Consumer<Message>> handlers =
        listeners.computeIfAbsent(type, ignored -> new CopyOnWriteArrayList<>());
    handlers.add(listener);
    return () -> {
      handlers.remove(listener);
      if (handlers.isEmpty()) listeners.remove(type, handlers);
    };
  }

  public CompletableFuture<Long> publishAsync(String type, JsonElement payload) {
    validateType(type);
    if (payload == null || payload.isJsonNull()) {
      return CompletableFuture.failedFuture(
          new IllegalArgumentException("payload must be JSON data"));
    }
    Message message =
        new Message(
            UUID.randomUUID().toString(), serverId, type, System.currentTimeMillis(), payload);
    String serialized = GSON.toJson(message);
    if (serialized.getBytes(StandardCharsets.UTF_8).length > MAX_MESSAGE_BYTES) {
      return CompletableFuture.failedFuture(
          new IllegalArgumentException("Redis message exceeds the 1 MiB payload limit"));
    }
    if (!settings.enabled() || !running.get()) {
      return CompletableFuture.failedFuture(
          new IllegalStateException("Redis transport is not running"));
    }
    publishAttempts.incrementAndGet();
    CompletableFuture<Long> result = new CompletableFuture<>();
    try {
      publisherExecutor.execute(
          () -> {
            try {
              long recipients = publishWithConnectionRetry(serialized);
              publishSuccesses.incrementAndGet();
              result.complete(recipients);
            } catch (RuntimeException exception) {
              recordFailure(exception);
              state.compareAndSet(State.CONNECTED, State.DEGRADED);
              publishFailures.incrementAndGet();
              result.completeExceptionally(exception);
            }
          });
    } catch (RuntimeException exception) {
      recordFailure(exception);
      publishFailures.incrementAndGet();
      result.completeExceptionally(exception);
    }
    return result;
  }

  private long publishWithConnectionRetry(String serialized) {
    for (int attempt = 1; attempt <= MAX_PUBLISH_CONNECTION_ATTEMPTS; attempt++) {
      try (Jedis jedis = requirePool().getResource()) {
        return jedis.publish(settings.channel(), serialized);
      } catch (JedisConnectionException exception) {
        recordFailure(exception);
        if (attempt == MAX_PUBLISH_CONNECTION_ATTEMPTS) throw exception;
      }
    }
    throw new IllegalStateException("Redis publish attempts exhausted");
  }

  private void subscribeLoop() {
    long reconnectDelay = 1_000;
    while (running.get()) {
      JedisPubSub subscription =
          new JedisPubSub() {
            @Override
            public void onSubscribe(String channel, int subscribedChannels) {
              if (!running.get()) {
                unsubscribe();
                return;
              }
              state.set(State.CONNECTED);
              connectionSuccesses.incrementAndGet();
              lastConnectedAtMillis.set(System.currentTimeMillis());
              lastFailure = "";
              logger.info("Redis subscription connected on channel " + channel);
            }

            @Override
            public void onMessage(String channel, String rawMessage) {
              receive(rawMessage);
            }
          };
      synchronized (this) {
        if (!running.get()) break;
        activeSubscription = subscription;
      }
      connectionAttempts.incrementAndGet();
      try (Jedis jedis = new Jedis(endpoint, clientConfig(settings, true))) {
        jedis.subscribe(subscription, settings.channel());
        reconnectDelay = 1_000;
      } catch (RuntimeException exception) {
        if (!running.get()) break;
        recordFailure(exception);
        connectionFailures.incrementAndGet();
        state.set(State.DEGRADED);
        logger.warning("Redis subscription disconnected; retrying: " + safeFailure(exception));
      } finally {
        if (activeSubscription == subscription) activeSubscription = null;
      }
      if (running.get()) {
        state.set(State.CONNECTING);
        try {
          Thread.sleep(reconnectDelay);
        } catch (InterruptedException exception) {
          Thread.currentThread().interrupt();
          break;
        }
        reconnectDelay = Math.min(reconnectDelay * 2, MAX_RECONNECT_DELAY_MILLIS);
      }
    }
  }

  private void receive(String rawMessage) {
    receivedMessages.incrementAndGet();
    try {
      if (rawMessage == null
          || rawMessage.getBytes(StandardCharsets.UTF_8).length > MAX_MESSAGE_BYTES) {
        rejectedMessages.incrementAndGet();
        return;
      }
      Message message = GSON.fromJson(rawMessage, Message.class);
      if (!validMessage(message)) {
        rejectedMessages.incrementAndGet();
        return;
      }
      if (serverId.equals(message.originServerId())) {
        selfMessages.incrementAndGet();
        return;
      }
      if (recentMessageIds.putIfAbsent(message.id(), Boolean.TRUE) != null) {
        duplicateMessages.incrementAndGet();
        return;
      }
      List<Consumer<Message>> handlers = listeners.get(message.type());
      if (handlers == null) {
        unhandledMessages.incrementAndGet();
        return;
      }
      Message immutableMessage =
          new Message(
              message.id(),
              message.originServerId(),
              message.type(),
              message.publishedAtMillis(),
              message.payload());
      deliveredMessages.incrementAndGet();
      try {
        mainThreadDispatcher.accept(
            () -> {
              for (Consumer<Message> handler : handlers) {
                try {
                  handler.accept(immutableMessage);
                } catch (RuntimeException exception) {
                  handlerFailures.incrementAndGet();
                  logger.log(
                      Level.WARNING,
                      "Redis message handler failed for type " + message.type(),
                      exception);
                }
              }
            });
      } catch (RuntimeException exception) {
        dispatchFailures.incrementAndGet();
        logger.log(Level.WARNING, "Could not dispatch Redis message to the main thread", exception);
      }
    } catch (JsonParseException | IllegalStateException exception) {
      rejectedMessages.incrementAndGet();
      logger.log(Level.WARNING, "Rejected malformed Redis message", exception);
    } catch (RuntimeException exception) {
      dispatchFailures.incrementAndGet();
      logger.log(Level.WARNING, "Could not dispatch Redis message", exception);
    }
  }

  private static boolean validMessage(Message message) {
    return message != null
        && message.id() != null
        && !message.id().isBlank()
        && message.id().length() <= 64
        && message.originServerId() != null
        && !message.originServerId().isBlank()
        && message.originServerId().length() <= 64
        && message.type() != null
        && message.type().matches("[a-zA-Z0-9._-]{1,128}")
        && message.publishedAtMillis() > 0
        && message.payload() != null
        && !message.payload().isJsonNull();
  }

  private JedisPool requirePool() {
    JedisPool current = pool;
    if (current == null || current.isClosed())
      throw new IllegalStateException("Redis pool is closed");
    return current;
  }

  private static void validateSettings(Settings settings) {
    if (settings.host().isBlank())
      throw new IllegalArgumentException("redis.host must not be blank");
    if (settings.port() < 1 || settings.port() > 65_535) {
      throw new IllegalArgumentException("redis.port must be between 1 and 65535");
    }
    if (settings.database() < 0 || settings.database() > 15) {
      throw new IllegalArgumentException("redis.database must be between 0 and 15");
    }
    if (!settings.channel().matches("[a-zA-Z0-9:_-]{1,128}")) {
      throw new IllegalArgumentException("redis.channel contains unsupported characters");
    }
  }

  static DefaultJedisClientConfig clientConfig(Settings settings, boolean subscriber) {
    DefaultJedisClientConfig.Builder builder =
        DefaultJedisClientConfig.builder()
            .connectionTimeoutMillis(DurationHolder.CONNECT_TIMEOUT_MILLIS)
            .socketTimeoutMillis(DurationHolder.SOCKET_TIMEOUT_MILLIS)
            .blockingSocketTimeoutMillis(
                subscriber
                    ? DurationHolder.BLOCKING_SOCKET_TIMEOUT_MILLIS
                    : DurationHolder.SOCKET_TIMEOUT_MILLIS)
            .database(settings.database())
            .ssl(settings.tls());
    if (!settings.password().isEmpty()) {
      builder.password(settings.password());
    }
    return builder.build();
  }

  private static void validateType(String type) {
    if (type == null || !type.matches("[a-zA-Z0-9._-]{1,128}")) {
      throw new IllegalArgumentException(
          "message type must use letters, numbers, dot, underscore, or dash");
    }
  }

  private void recordFailure(RuntimeException exception) {
    lastFailure = safeFailure(exception);
    lastFailureAtMillis.set(System.currentTimeMillis());
  }

  private String safeFailure(RuntimeException exception) {
    String message = exception.getMessage();
    if (message == null || message.isBlank()) return exception.getClass().getSimpleName();
    if (!settings.password().isEmpty()) {
      message = message.replace(settings.password(), "<redacted>");
    }
    return message.length() > 256 ? message.substring(0, 256) : message;
  }

  private static ThreadFactory namedDaemon(String name) {
    return runnable -> {
      Thread thread = new Thread(runnable, name);
      thread.setDaemon(true);
      return thread;
    };
  }

  @Override
  public synchronized void close() {
    if (!running.getAndSet(false) && state.get() == State.CLOSED) return;
    JedisPubSub subscription = activeSubscription;
    if (subscription != null && subscription.isSubscribed()) {
      try {
        subscription.unsubscribe();
      } catch (RuntimeException exception) {
        logger.log(Level.FINE, "Redis subscription disconnected during shutdown", exception);
      }
    }
    subscriberExecutor.shutdownNow();
    publisherExecutor.shutdown();
    try {
      if (!publisherExecutor.awaitTermination(2, TimeUnit.SECONDS)) publisherExecutor.shutdownNow();
      subscriberExecutor.awaitTermination(2, TimeUnit.SECONDS);
    } catch (InterruptedException exception) {
      Thread.currentThread().interrupt();
      publisherExecutor.shutdownNow();
    }
    JedisPool current = pool;
    if (current != null) current.close();
    listeners.values().forEach(List::clear);
    listeners.clear();
    recentMessageIds.clear();
    state.set(State.CLOSED);
  }

  private static final class DurationHolder {
    private static final int CONNECT_TIMEOUT_MILLIS = 2_000;
    private static final int SOCKET_TIMEOUT_MILLIS = 2_000;
    private static final int BLOCKING_SOCKET_TIMEOUT_MILLIS = 0;
    private static final java.time.Duration POOL_WAIT = java.time.Duration.ofSeconds(2);
  }
}
