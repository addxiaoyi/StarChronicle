package dev.starcore.starcore.foundation.economy.transaction;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/** Read-only transaction evidence joined with the current refund retry state. */
public record EvidenceReplaySnapshot(
    TransactionRecord transaction,
    List<TransactionEvent> timeline,
    Optional<PendingRefund> pendingRefund,
    EvidenceReplayCorrelation correlation) {
  public EvidenceReplaySnapshot {
    Objects.requireNonNull(transaction, "transaction");
    timeline = List.copyOf(timeline);
    pendingRefund = Objects.requireNonNull(pendingRefund, "pendingRefund");
    Objects.requireNonNull(correlation, "correlation");
  }

  /** Stable field map for future REST/export adapters without exposing mutable records. */
  public Map<String, Object> export() {
    Map<String, Object> fields = new LinkedHashMap<>();
    fields.put("transactionId", transaction.transactionId().toString());
    fields.put("accountId", transaction.accountId().toString());
    fields.put("owner", transaction.owner().name());
    fields.put("type", transaction.type().name());
    fields.put("amount", transaction.amount().toPlainString());
    fields.put("reason", transaction.reason());
    fields.put("state", transaction.state().name());
    fields.put("attempts", transaction.attempts());
    fields.put("correlation", correlation.name());
    fields.put("timeline", timeline);
    fields.put("pendingRefund", pendingRefund.orElse(null));
    return Collections.unmodifiableMap(fields);
  }
}
