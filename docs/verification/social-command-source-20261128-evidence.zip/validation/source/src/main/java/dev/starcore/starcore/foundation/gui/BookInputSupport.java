package dev.starcore.starcore.foundation.gui;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

/** Paper-compatible lifecycle for writable-book input without using Player.openBook. */
public final class BookInputSupport {
  private static final int INPUT_SLOT = 0;
  private static final Map<UUID, BookSession> PREVIOUS_HANDS = new ConcurrentHashMap<>();

  private record BookSession(
      Player owner,
      int selectedSlot,
      ItemStack selectedItem,
      ItemStack inputSlotItem,
      Object nonce) {}

  private BookInputSupport() {}

  public static void prepare(Player player, String title, String initialPage) {
    // Retire an interrupted input attempt before replacing its temporary book.
    restore(player);
    int selectedSlot = player.getInventory().getHeldItemSlot();
    ItemStack selectedItem = cloneItem(player.getInventory().getItem(selectedSlot));
    ItemStack inputSlotItem = cloneItem(player.getInventory().getItem(INPUT_SLOT));
    PREVIOUS_HANDS.put(
        player.getUniqueId(),
        new BookSession(player, selectedSlot, selectedItem, inputSlotItem, new Object()));
    ItemStack book = new ItemStack(Material.WRITABLE_BOOK);
    BookMeta meta = (BookMeta) book.getItemMeta();
    if (meta != null) {
      meta.setTitle(title);
      meta.setAuthor("StarCore");
      meta.addPage(initialPage == null ? "" : initialPage);
      book.setItemMeta(meta);
    }
    player.closeInventory();
    player.getInventory().setHeldItemSlot(INPUT_SLOT);
    player.getInventory().setItemInMainHand(book);
    player.updateInventory();
    player.sendActionBar(Component.text("右键打开输入书本，填写内容后签名确认。", NamedTextColor.YELLOW));
  }

  public static void restore(Player player) {
    restoreSession(player, sessionToken(player));
  }

  /** Opaque identity for delayed owner cleanup; an old callback cannot consume a new input. */
  public static Object sessionToken(Player player) {
    BookSession previous = PREVIOUS_HANDS.get(player.getUniqueId());
    return previous != null && previous.owner() == player ? previous : null;
  }

  public static void restoreSession(Player player, Object token) {
    if (token instanceof BookSession previous
        && previous.owner() == player
        && PREVIOUS_HANDS.remove(player.getUniqueId(), previous)) {
      player.getInventory().setItem(INPUT_SLOT, previous.inputSlotItem());
      if (previous.selectedSlot() != INPUT_SLOT) {
        player.getInventory().setItem(previous.selectedSlot(), previous.selectedItem());
        player.getInventory().setHeldItemSlot(previous.selectedSlot());
      }
      player.updateInventory();
    }
  }

  public static void clear(Player player) {
    // Quit handlers call clear before Bukkit persists the departing player's inventory.
    restore(player);
  }

  private static ItemStack cloneItem(ItemStack item) {
    return item == null ? null : item.clone();
  }
}
