package dev.starcore.starcore.foundation.economy.insurance;

import java.math.BigDecimal;
import java.util.UUID;

/** Result of a successful claim settlement. */
public record InsuranceClaimReceipt(
    UUID policyId, UUID sourceTransactionId, UUID payoutTransactionId, BigDecimal payout) {}
