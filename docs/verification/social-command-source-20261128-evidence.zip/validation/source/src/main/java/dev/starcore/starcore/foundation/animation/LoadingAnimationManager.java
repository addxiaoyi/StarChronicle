package dev.starcore.starcore.foundation.animation;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** Finite loading callbacks run once, on their original player and lifecycle. */
public final class LoadingAnimationManager {
  private final AnimationTaskTracker tasks;
  private final SoundFeedbackManager soundManager;
  private final Map<UUID, LoadingState> activeLoaders = new ConcurrentHashMap<>();

  public enum LoadingType {
    SPINNER,
    PROGRESS,
    DOTS,
    PULSE,
    COMPUTING,
    SKELETON,
    WORDS
  }

  private static final class LoadingState {
    final Player player;
    final Consumer<Void> complete;
    BukkitTask task;
    long tick;

    LoadingState(Player player, Consumer<Void> complete) {
      this.player = player;
      this.complete = complete;
    }
  }

  public LoadingAnimationManager(
      Plugin plugin, GuiAnimationManager animationManager, SoundFeedbackManager soundManager) {
    tasks = new AnimationTaskTracker(plugin);
    this.soundManager = soundManager;
  }

  private void start(
      Player player, Consumer<Void> complete, long period, Consumer<LoadingState> frame) {
    tasks.execute(
        player,
        () -> {
          cancelLoader(player);
          LoadingState state = new LoadingState(player, complete);
          activeLoaders.put(player.getUniqueId(), state);
          state.task =
              tasks.runTaskTimer(
                  player,
                  task -> {
                    if (activeLoaders.get(player.getUniqueId()) != state) {
                      task.cancel();
                      return;
                    }
                    // Available even if the scheduler invokes its callback before returning the
                    // handle.
                    state.task = task;
                    frame.accept(state);
                  },
                  1,
                  period);
          tasks.onRetired(state.task, () -> activeLoaders.remove(player.getUniqueId(), state));
        });
  }

  private boolean current(LoadingState state) {
    return activeLoaders.get(state.player.getUniqueId()) == state
        && state.task != null
        && !state.task.isCancelled();
  }

  private void complete(LoadingState state) {
    if (!current(state)) return;
    activeLoaders.remove(state.player.getUniqueId(), state);
    state.task.cancel();
    if (state.complete != null) state.complete.accept(null);
  }

  public void startSpinner(Player player, String message, Consumer<Void> complete) {
    startSpinner(player, message, -1, null, complete);
  }

  /** maxDuration retains its historical meaning: number of two-tick spinner frames. */
  public void startSpinner(
      Player player,
      String message,
      int maxDuration,
      Consumer<Integer> step,
      Consumer<Void> complete) {
    String[] spinner = {"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"};
    start(
        player,
        complete,
        2,
        state -> {
          long tick = state.tick++;
          if (maxDuration > 0 && tick >= maxDuration) {
            complete(state);
            return;
          }
          if (step != null) step.accept((int) Math.min(Integer.MAX_VALUE, tick));
          if (current(state))
            player.sendActionBar(
                Component.text(
                    spinner[(int) (tick % spinner.length)] + " " + message, NamedTextColor.YELLOW));
        });
  }

  public void startProgress(
      Player player,
      String message,
      int totalSteps,
      Consumer<Integer> step,
      Consumer<Void> complete) {
    if (totalSteps < 0) throw new IllegalArgumentException("Steps must be nonnegative");
    start(
        player,
        complete,
        3,
        state -> {
          long index = state.tick++;
          if (index >= totalSteps) {
            player.sendActionBar(Component.text("✓ " + message + " 完成!", NamedTextColor.GREEN));
            soundManager.playSuccess(player);
            complete(state);
            return;
          }
          if (step != null) step.accept((int) index);
          if (current(state))
            player.sendActionBar(
                Component.text(
                    message
                        + " "
                        + progress(index, totalSteps, 20)
                        + " "
                        + (index * 100 / totalSteps)
                        + "%",
                    NamedTextColor.GOLD));
        });
  }

  public void startDots(Player player, String message, int seconds, Consumer<Void> complete) {
    timed(player, message, seconds, complete, false);
  }

  public void startPulse(Player player, String message, int seconds, Consumer<Void> complete) {
    timed(player, message, seconds, complete, true);
  }

  private void timed(
      Player player, String message, int seconds, Consumer<Void> complete, boolean pulse) {
    long duration = Math.max(0L, (long) seconds * 20);
    start(
        player,
        complete,
        1,
        state -> {
          long tick = state.tick++;
          if (tick >= duration) {
            complete(state);
            return;
          }
          String suffix =
              pulse
                  ? " " + "▌".repeat((int) ((tick / 8) % 4) + 1)
                  : ".".repeat((int) ((tick / 5) % 4));
          player.sendActionBar(Component.text(message + suffix, NamedTextColor.YELLOW));
        });
  }

  public void startWords(
      Player player, String[] words, int intervalTicks, int maxTicks, Consumer<Void> complete) {
    if (words.length == 0 || intervalTicks < 1 || maxTicks < 0)
      throw new IllegalArgumentException("Invalid word animation");
    String[] snapshot = words.clone();
    start(
        player,
        complete,
        1,
        state -> {
          long tick = state.tick++;
          if (tick >= maxTicks) {
            complete(state);
            return;
          }
          player.sendActionBar(
              Component.text(
                  "⟳ " + snapshot[(int) ((tick / intervalTicks) % snapshot.length)],
                  NamedTextColor.YELLOW));
        });
  }

  public void startComputing(Player player, Consumer<Void> complete) {
    startWords(player, new String[] {"计算中", "处理中", "分析中", "加载中", "更新中"}, 10, 200, complete);
  }

  public void startMultiStep(
      Player player, List<String> steps, Consumer<Integer> step, Consumer<Void> complete) {
    List<String> snapshot = List.copyOf(steps);
    start(
        player,
        complete,
        15,
        state -> {
          long index = state.tick++;
          if (index >= snapshot.size()) {
            player.sendActionBar(Component.text("✓ 全部完成!", NamedTextColor.GREEN));
            soundManager.playSuccess(player);
            complete(state);
            return;
          }
          player.sendActionBar(
              Component.text(
                  "["
                      + (index + 1)
                      + "/"
                      + snapshot.size()
                      + "] "
                      + snapshot.get((int) index)
                      + " "
                      + progress(index, snapshot.size(), 15),
                  NamedTextColor.GOLD));
          if (step != null) step.accept((int) index);
        });
  }

  /** This is a visual sequence, not a database progress or success signal. */
  public void startDataLoading(
      Player player, String dataType, int approximateDuration, Consumer<Void> complete) {
    startMultiStep(
        player, List.of("正在加载 " + dataType + "...", "请稍候...", "准备界面..."), null, complete);
  }

  public void cancelLoader(Player player) {
    LoadingState state = activeLoaders.get(player.getUniqueId());
    if (state != null
        && state.player == player
        && activeLoaders.remove(player.getUniqueId(), state)) {
      if (state.task != null) state.task.cancel();
    }
  }

  public void cancelAll() {
    tasks.cancelAll();
    activeLoaders.clear();
  }

  public void shutdown() {
    tasks.shutdown();
    activeLoaders.clear();
  }

  public boolean hasActiveLoader(Player player) {
    LoadingState state = activeLoaders.get(player.getUniqueId());
    return state != null && state.player == player && current(state);
  }

  private String progress(long current, long max, int length) {
    int filled = max <= 0 ? 0 : (int) Math.min(length, current * length / max);
    return "[" + "█".repeat(filled) + "░".repeat(length - filled) + "]";
  }
}
