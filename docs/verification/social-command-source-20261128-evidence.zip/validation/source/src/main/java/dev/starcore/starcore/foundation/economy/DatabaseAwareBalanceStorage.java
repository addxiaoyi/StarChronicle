package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;
import java.util.function.Function;
import java.util.logging.Logger;

final class DatabaseAwareBalanceStorage implements InternalEconomyService.BalanceStorage {
  private final DatabaseService databaseService;
  private final InternalEconomyService.PersistenceBalanceStorage fileStorage;
  private final InternalEconomyService.BalanceStorage sqlStorage;
  private final Object storageSelectionLock = new Object();
  private Properties latestFileSnapshot;
  private volatile boolean sqlPreferred;
  private final Logger logger;

  DatabaseAwareBalanceStorage(
      DatabaseService databaseService, PersistenceService persistenceService, Logger logger) {
    this(databaseService, persistenceService, logger, ForkJoinPool.commonPool());
  }

  DatabaseAwareBalanceStorage(
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger,
      Executor ioExecutor) {
    this.databaseService = Objects.requireNonNull(databaseService, "databaseService");
    this.fileStorage = new InternalEconomyService.PersistenceBalanceStorage(persistenceService);
    this.sqlStorage =
        new SqlBalanceStorage(databaseService, persistenceService, logger, ioExecutor);
    this.sqlPreferred = databaseService.isRunning();
    this.logger = logger;
  }

  @Override
  public Properties load() {
    return withActiveStorage(InternalEconomyService.BalanceStorage::load);
  }

  @Override
  public void save(Properties properties) {
    Properties snapshot = copy(properties);
    withActiveStorage(
        storage -> {
          storage.save(snapshot);
          if (storage == fileStorage) {
            latestFileSnapshot = null;
          }
          return null;
        });
  }

  @Override
  public boolean saveAccount(java.util.UUID accountId, java.math.BigDecimal balance) {
    return withActiveStorage(storage -> storage.saveAccount(accountId, balance));
  }

  @Override
  public boolean saveAccounts(java.util.Map<java.util.UUID, java.math.BigDecimal> balances) {
    return withActiveStorage(storage -> storage.saveAccounts(balances));
  }

  @Override
  public void saveAsync(Properties properties) {
    Properties snapshot = copy(properties);
    withActiveStorage(
        storage -> {
          if (storage == fileStorage) {
            // The asynchronous write may not reach disk before the database starts. Preserve its
            // latest complete snapshot so the SQL transition can import it directly.
            Properties queuedSnapshot = copy(snapshot);
            latestFileSnapshot = queuedSnapshot;
            CompletableFuture<Void> save = fileStorage.saveAsyncFuture(queuedSnapshot);
            save.whenComplete(
                (ignored, failure) -> {
                  if (failure == null) {
                    synchronized (storageSelectionLock) {
                      if (latestFileSnapshot == queuedSnapshot) {
                        latestFileSnapshot = null;
                      }
                    }
                  }
                });
          } else {
            storage.saveAsync(snapshot);
          }
          return null;
        });
  }

  private <T> T withActiveStorage(Function<InternalEconomyService.BalanceStorage, T> operation) {
    if (sqlPreferred) {
      return operation.apply(sqlStorage);
    }
    synchronized (storageSelectionLock) {
      if (sqlPreferred) {
        return operation.apply(sqlStorage);
      }
      if (!databaseService.isRunning()) {
        // Keep file-backed reads and writes inside the selection lock. If the database becomes
        // available concurrently, its migration must wait until this operation is reflected in
        // the legacy file snapshot.
        return operation.apply(fileStorage);
      }
      // E-027 修复: 首次切换到 SQL 存储时，把 fileStorage 中的所有余额一次性迁移到 SQL，
      // 避免玩家余额在切换后丢失。
      migrateToSql();
      try {
        return operation.apply(sqlStorage);
      } finally {
        // Publish the storage switch only after migration and its initiating operation finish.
        // Other operations must not write to SQL while an older file snapshot is being imported.
        sqlPreferred = true;
      }
    }
  }

  /** E-027 修复: 将 fileStorage 的全部余额迁移到 sqlStorage，仅执行一次。 */
  private void migrateToSql() {
    Properties fileProps =
        latestFileSnapshot == null ? fileStorage.load() : copy(latestFileSnapshot);
    if (!fileProps.isEmpty()) {
      sqlStorage.save(fileProps);
      logger.info("Migrated " + fileProps.size() + " player balances from file storage to SQL.");
    }
    latestFileSnapshot = null;
  }

  private static Properties copy(Properties source) {
    Properties copy = new Properties();
    copy.putAll(Objects.requireNonNull(source, "properties"));
    return copy;
  }
}
