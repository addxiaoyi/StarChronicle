package dev.starcore.starcore.foundation.economy.transaction;

import java.util.List;
import java.util.UUID;

/** Supplies durable domain evidence for one transaction without moving money. */
@FunctionalInterface
public interface EvidenceReplayProvider {
  List<EvidenceReplayEvent> replay(UUID transactionId, TransactionRecord transaction);
}
