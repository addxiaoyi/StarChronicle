package dev.starcore.starcore.essentials.command;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.nickname.NicknameService;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** 昵称命令 /nick, /realname */
public final class NicknameCommand implements CommandExecutor, TabCompleter {
  private final NicknameService nicknameService;
  private final EssentialsPermissions permissions;
  private final Plugin plugin;
  private final FoliaCompatScheduler scheduler;
  private final BooleanSupplier lifetime;

  public NicknameCommand(NicknameService nicknameService) {
    this(nicknameService, EssentialsPermissions.defaults());
  }

  /** Legacy synchronous entry: the caller must own all accessed players and permit profile IO. */
  public NicknameCommand(NicknameService nicknameService, EssentialsPermissions permissions) {
    this.nicknameService = Objects.requireNonNull(nicknameService);
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
    this.plugin = null;
    this.scheduler = null;
    this.lifetime = () -> true;
  }

  public NicknameCommand(
      NicknameService nicknameService,
      EssentialsPermissions permissions,
      Plugin plugin,
      FoliaCompatScheduler scheduler,
      BooleanSupplier lifetime) {
    this.nicknameService = Objects.requireNonNull(nicknameService);
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
    this.plugin = Objects.requireNonNull(plugin);
    this.scheduler = Objects.requireNonNull(scheduler);
    this.lifetime = Objects.requireNonNull(lifetime);
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (!active()) return true;
    if (plugin != null
        && sender instanceof Player player
        && (!sameSession(player) || !player.isOnline())) return true;
    String commandName = command.getName().toLowerCase(Locale.ROOT);

    if (commandName.equals("nick")) {
      handleNick(sender, args);
    } else if (commandName.equals("realname")) {
      handleRealName(sender, args);
    }

    return true;
  }

  /** 设置昵称 */
  private void handleNick(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage(Component.text("只有玩家可以使用此命令", NamedTextColor.RED));
      return;
    }

    if (!EssentialsPermissions.permits(player, permissions.nickname())) {
      player.sendMessage(Component.text("你没有权限设置昵称", NamedTextColor.RED));
      return;
    }

    if (args.length < 1) {
      sender.sendMessage(Component.text("用法: /nick <昵称> 或 /nick off", NamedTextColor.YELLOW));
      return;
    }

    // 移除昵称
    if (args[0].equalsIgnoreCase("off") || args[0].equalsIgnoreCase("reset")) {
      boolean success = nicknameService.removeNickname(player);

      if (success) {
        player.sendMessage(Component.text("已移除昵称", NamedTextColor.GREEN));
      } else {
        player.sendMessage(Component.text("你没有设置昵称", NamedTextColor.YELLOW));
      }
      return;
    }

    // 组合昵称（支持空格）
    StringBuilder nickname = new StringBuilder();
    for (int i = 0; i < args.length; i++) {
      if (i > 0) nickname.append(" ");
      nickname.append(args[i]);
    }

    String finalNickname = nickname.toString();

    // 颜色代码权限检查
    if (finalNickname.contains("§")
        && !EssentialsPermissions.permits(player, permissions.nicknameColor())) {
      player.sendMessage(Component.text("你没有权限使用颜色代码", NamedTextColor.RED));
      return;
    }

    // 设置昵称
    boolean success = nicknameService.setNickname(player, finalNickname);

    if (success) {
      player.sendMessage(
          Component.text("已设置昵称为: ", NamedTextColor.GREEN).append(Component.text(finalNickname)));
    } else {
      player.sendMessage(Component.text("设置昵称失败（可能已被使用或格式无效）", NamedTextColor.RED));
      player.sendMessage(Component.text("昵称要求: 2-16个字符，仅字母数字下划线", NamedTextColor.GRAY));
    }
  }

  /** 查询真实名称 */
  private void handleRealName(CommandSender sender, String[] args) {
    if (args.length < 1) {
      sender.sendMessage(Component.text("用法: /realname <昵称>", NamedTextColor.YELLOW));
      return;
    }

    String nickname = String.join(" ", args);
    UUID playerId = nicknameService.getPlayerByNickname(nickname).orElse(null);

    if (playerId == null) {
      sender.sendMessage(Component.text("找不到使用此昵称的玩家: " + nickname, NamedTextColor.RED));
      return;
    }

    if (plugin != null) {
      Audience audience =
          new Audience(
              sender,
              sender instanceof BlockCommandSender block
                  ? block.getBlock().getLocation().clone()
                  : null);
      resolveName(audience, nickname, playerId);
      return;
    }

    Player player = Bukkit.getPlayer(playerId);
    String realName = player != null ? player.getName() : offlinePlayerName(playerId);
    if (realName == null || realName.isBlank()) {
      sender.sendMessage(Component.text("无法获取该玩家的真实名称", NamedTextColor.YELLOW));
      return;
    }

    sender.sendMessage(
        Component.text("昵称 ", NamedTextColor.GRAY)
            .append(Component.text(nickname))
            .append(Component.text(" 的真实名称是: ", NamedTextColor.GRAY))
            .append(Component.text(realName, NamedTextColor.GREEN)));
  }

  private String offlinePlayerName(UUID playerId) {
    OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerId);
    return offlinePlayer == null ? null : offlinePlayer.getName();
  }

  private record Audience(CommandSender sender, Location region) {}

  private boolean active() {
    return lifetime.getAsBoolean() && (plugin == null || plugin.isEnabled());
  }

  private boolean sameSession(Player player) {
    return plugin == null || plugin.getServer().getPlayer(player.getUniqueId()) == player;
  }

  private boolean available(Audience audience) {
    return active() && (!(audience.sender() instanceof Player player) || sameSession(player));
  }

  private void resolveName(Audience audience, String nickname, UUID playerId) {
    AtomicBoolean completed = new AtomicBoolean();
    Consumer<String> finish =
        name -> {
          if (!completed.compareAndSet(false, true) || !available(audience)) return;
          reply(
              audience,
              () -> {
                if (!nicknameService
                    .getPlayerByNickname(nickname)
                    .filter(playerId::equals)
                    .isPresent()) {
                  audience
                      .sender()
                      .sendMessage(Component.text("昵称已变更，请重新查询", NamedTextColor.YELLOW));
                } else if (name == null || name.isBlank()) {
                  audience
                      .sender()
                      .sendMessage(Component.text("无法获取该玩家的真实名称", NamedTextColor.YELLOW));
                } else {
                  audience
                      .sender()
                      .sendMessage(
                          Component.text("昵称 ", NamedTextColor.GRAY)
                              .append(Component.text(nickname))
                              .append(Component.text(" 的真实名称是: ", NamedTextColor.GRAY))
                              .append(Component.text(name, NamedTextColor.GREEN)));
                }
              });
        };
    Consumer<Player> online =
        player ->
            owned(
                player,
                () -> {
                  if (available(audience)) finish.accept(player.getName());
                },
                () -> finish.accept(null));
    Player target = plugin.getServer().getPlayer(playerId);
    if (target != null) {
      online.accept(target);
      return;
    }
    AtomicBoolean claimed = new AtomicBoolean();
    try {
      scheduler.runAsync(
          () -> {
            if (!claimed.compareAndSet(false, true) || !available(audience)) return;
            try {
              Player current = plugin.getServer().getPlayer(playerId);
              if (current != null) {
                online.accept(current);
                return;
              }
              OfflinePlayer profile = plugin.getServer().getOfflinePlayer(playerId);
              // Paper may return an online Player if the account joined during the lookup.
              if (profile instanceof Player player) online.accept(player);
              else finish.accept(profile == null ? null : profile.getName());
            } catch (RuntimeException failure) {
              log(failure);
              finish.accept(null);
            }
          });
    } catch (RuntimeException failure) {
      if (claimed.compareAndSet(false, true)) finish.accept(null);
      log(failure);
    }
  }

  private void owned(Player player, Runnable action, Runnable unavailable) {
    if (!active()) return;
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable retired =
        () -> {
          if (claimed.compareAndSet(false, true) && active()) unavailable.run();
        };
    try {
      scheduler.runAtEntity(
          player,
          ignored -> {
            if (!claimed.compareAndSet(false, true) || !active()) return;
            try {
              if (sameSession(player) && player.isOnline()) action.run();
              else unavailable.run();
            } catch (RuntimeException failure) {
              log(failure);
              if (active()) unavailable.run();
            }
          },
          retired);
    } catch (RuntimeException failure) {
      retired.run();
      log(failure);
    }
  }

  private void reply(Audience audience, Runnable action) {
    if (!available(audience)) return;
    if (audience.sender() instanceof Player player) {
      owned(player, action, () -> {});
      return;
    }
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable guarded =
        () -> {
          if (claimed.compareAndSet(false, true) && available(audience)) action.run();
        };
    try {
      if (audience.region() != null)
        scheduler.runAtLocation(audience.region(), ignored -> guarded.run());
      else scheduler.runGlobal(guarded);
    } catch (RuntimeException failure) {
      claimed.set(true);
      log(failure);
    }
  }

  private void log(RuntimeException failure) {
    plugin.getLogger().log(Level.FINE, "Nickname query callback unavailable", failure);
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (!active() || plugin != null && sender instanceof Player player && !sameSession(player))
      return List.of();
    if (command.getName().equalsIgnoreCase("nick") && args.length == 1) {
      return List.of("off", "reset", "<昵称>");
    }

    if (command.getName().equalsIgnoreCase("realname") && args.length == 1) {
      String prefix = args[0].toLowerCase(Locale.ROOT);
      List<String> nicknames = new ArrayList<>();
      for (String nickname : nicknameService.getAllNicknames().values()) {
        if (nickname.toLowerCase(Locale.ROOT).startsWith(prefix)) {
          nicknames.add(nickname);
        }
      }
      nicknames.sort(String.CASE_INSENSITIVE_ORDER);
      return nicknames;
    }

    return List.of();
  }
}
