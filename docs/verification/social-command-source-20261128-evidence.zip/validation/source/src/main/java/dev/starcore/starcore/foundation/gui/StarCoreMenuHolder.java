package dev.starcore.starcore.foundation.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Identifies plugin menus independently of localized or legacy inventory titles. */
public final class StarCoreMenuHolder implements InventoryHolder {
  @Override
  public Inventory getInventory() {
    return null;
  }
}
