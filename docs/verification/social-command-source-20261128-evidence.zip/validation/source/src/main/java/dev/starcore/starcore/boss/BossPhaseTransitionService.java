package dev.starcore.starcore.boss;

import java.util.*;
import java.util.function.*;

/** Boss阶段转换服务 管理Boss战斗中的阶段转换逻辑 */
public class BossPhaseTransitionService {

  private final BossManager bossManager;
  private final Map<String, BossPhase> phaseRegistry = new HashMap<>();
  private final Map<String, PhaseTransitionHandler> transitionHandlers = new HashMap<>();

  public BossPhaseTransitionService(BossManager bossManager) {
    this.bossManager = bossManager;
    registerDefaultHandlers();
  }

  /** 注册阶段定义 */
  public void registerPhase(BossPhase phase) {
    phaseRegistry.put(phase.phaseId(), phase);
  }

  /** 注销阶段定义 */
  public void unregisterPhase(String phaseId) {
    phaseRegistry.remove(phaseId);
  }

  /** 获取阶段定义 */
  public Optional<BossPhase> getPhase(String phaseId) {
    return Optional.ofNullable(phaseRegistry.get(phaseId));
  }

  /** 注册默认的阶段转换处理器 */
  private void registerDefaultHandlers() {
    registerHandler("health_percentage", this::handleHealthPercentageTransition);
    registerHandler("time_elapsed", this::handleTimeElapsedTransition);
    registerHandler("participant_count", this::handleParticipantCountTransition);
    registerHandler("route_completed", this::handleRouteCompletedTransition);
  }

  /** 注册自定义阶段转换处理器 */
  public void registerHandler(String conditionType, PhaseTransitionHandler handler) {
    transitionHandlers.put(conditionType, handler);
  }

  /** 注销阶段转换处理器 */
  public void unregisterHandler(String conditionType) {
    transitionHandlers.remove(conditionType);
  }

  /** 检查并处理阶段转换 */
  public void checkPhaseTransitions(BossInstance instance) {
    BossDefinition definition = bossManager.getBossDefinition(instance.bossId()).orElse(null);

    if (definition == null) return;

    String currentPhaseId = instance.currentPhase();
    if (currentPhaseId == null) {
      startInitialPhase(instance, definition);
      return;
    }

    BossPhase currentPhase = phaseRegistry.get(currentPhaseId);
    if (currentPhase == null) return;

    String triggerCondition = currentPhase.triggerCondition();
    if (triggerCondition != null && !triggerCondition.isEmpty()) {
      PhaseTransitionHandler handler = getHandlerForCondition(triggerCondition);
      if (handler != null && handler.shouldTransition(instance, currentPhase, definition)) {
        performPhaseTransition(instance, currentPhase, definition);
      }
    }
  }

  /** 开始初始阶段 */
  private void startInitialPhase(BossInstance instance, BossDefinition definition) {
    if (definition.phases().isEmpty()) return;

    // 获取第一个阶段ID并查找对应阶段定义
    String firstPhaseId = definition.phases().stream().findFirst().orElse(null);
    if (firstPhaseId != null && phaseRegistry.containsKey(firstPhaseId)) {
      BossInstance newInstance =
          BossInstance.builder(instance.instanceId(), instance.bossId(), instance.riftInstanceId())
              .status(instance.status())
              .currentRoute(instance.currentRoute())
              .healthData(instance.healthData())
              .stateData(instance.stateData())
              .defeatedRoutes(instance.defeatedRoutes())
              .currentPhase(firstPhaseId)
              .spawnedAt(instance.spawnedAt())
              .defeatedAt(instance.defeatedAt())
              .winnerId(instance.winnerId())
              .participants(instance.participants())
              .metadata(instance.metadata())
              .errorMessage(instance.errorMessage())
              .retryCount(instance.retryCount())
              .build();

      bossManager.getBossInstances().put(instance.instanceId(), newInstance);
    }
  }

  /** 执行阶段转换 */
  private void performPhaseTransition(
      BossInstance instance, BossPhase currentPhase, BossDefinition definition) {
    String nextPhaseId = currentPhase.nextPhaseId();
    if (nextPhaseId == null || nextPhaseId.isEmpty()) {
      return;
    }

    BossPhase nextPhase = phaseRegistry.get(nextPhaseId);
    if (nextPhase == null) return;

    Map<String, Object> newHealthData =
        applyPhaseModifiers(instance.healthData(), currentPhase, nextPhase);

    BossInstance newInstance =
        BossInstance.builder(instance.instanceId(), instance.bossId(), instance.riftInstanceId())
            .status(instance.status())
            .currentRoute(instance.currentRoute())
            .healthData(newHealthData)
            .stateData(instance.stateData())
            .defeatedRoutes(instance.defeatedRoutes())
            .currentPhase(nextPhaseId)
            .spawnedAt(instance.spawnedAt())
            .defeatedAt(instance.defeatedAt())
            .winnerId(instance.winnerId())
            .participants(instance.participants())
            .metadata(instance.metadata())
            .errorMessage(instance.errorMessage())
            .retryCount(instance.retryCount())
            .build();

    bossManager.getBossInstances().put(instance.instanceId(), newInstance);
    onPhaseTransition(instance, currentPhase, nextPhase);
  }

  /** 应用阶段修改器 */
  private Map<String, Object> applyPhaseModifiers(
      Map<String, Object> currentHealthData, BossPhase currentPhase, BossPhase nextPhase) {

    Map<String, Object> newHealthData = new HashMap<>(currentHealthData);

    if (nextPhase.healthMultiplier() != 1.0) {
      Object currentHealth = newHealthData.get("health");
      if (currentHealth instanceof Number) {
        double newHealth = ((Number) currentHealth).doubleValue() * nextPhase.healthMultiplier();
        newHealthData.put("health", newHealth);
        newHealthData.put("maxHealth", newHealth);
      }
    }

    newHealthData.put("phaseStartTime", System.currentTimeMillis());
    return newHealthData;
  }

  /** 阶段转换事件回调 */
  private void onPhaseTransition(BossInstance instance, BossPhase fromPhase, BossPhase toPhase) {
    java.util.logging.Logger.getLogger(BossPhaseTransitionService.class.getName())
        .info(
            "Boss "
                + instance.bossId()
                + " transitioned from phase "
                + fromPhase.phaseId()
                + " to "
                + toPhase.phaseId());
  }

  /** 获取条件对应的处理器 */
  private PhaseTransitionHandler getHandlerForCondition(String condition) {
    String[] parts = condition.split(":", 2);
    if (parts.length < 2) return null;
    String conditionType = parts[0].trim().toLowerCase();
    return transitionHandlers.get(conditionType);
  }

  // ==================== 默认处理器实现 ====================

  private boolean handleHealthPercentageTransition(
      BossInstance instance, BossPhase phase, BossDefinition definition) {

    String condition = phase.triggerCondition();
    if (!condition.startsWith("health_percentage:")) return false;

    try {
      double threshold = Double.parseDouble(condition.substring("health_percentage:".length()));
      Object currentHealth = instance.healthData().get("health");
      Object maxHealth = instance.healthData().get("maxHealth");

      if (currentHealth instanceof Number && maxHealth instanceof Number) {
        double healthPercent =
            ((Number) currentHealth).doubleValue() / ((Number) maxHealth).doubleValue() * 100;
        return healthPercent <= threshold;
      }
    } catch (NumberFormatException e) {
      // 解析失败
    }
    return false;
  }

  private boolean handleTimeElapsedTransition(
      BossInstance instance, BossPhase phase, BossDefinition definition) {

    String condition = phase.triggerCondition();
    if (!condition.startsWith("time_elapsed:")) return false;

    try {
      long durationMs = Long.parseLong(condition.substring("time_elapsed:".length()));
      Object phaseStartTime = instance.healthData().get("phaseStartTime");
      if (phaseStartTime instanceof Number) {
        long elapsed = System.currentTimeMillis() - ((Number) phaseStartTime).longValue();
        return elapsed >= durationMs;
      }
    } catch (NumberFormatException e) {
      // 解析失败
    }
    return false;
  }

  private boolean handleParticipantCountTransition(
      BossInstance instance, BossPhase phase, BossDefinition definition) {

    String condition = phase.triggerCondition();
    if (!condition.startsWith("participant_count:")) return false;

    try {
      int requiredCount = Integer.parseInt(condition.substring("participant_count:".length()));
      int currentCount = instance.participants().size();
      return currentCount >= requiredCount;
    } catch (NumberFormatException e) {
      // 解析失败
    }
    return false;
  }

  private boolean handleRouteCompletedTransition(
      BossInstance instance, BossPhase phase, BossDefinition definition) {

    String condition = phase.triggerCondition();
    if (!condition.startsWith("route_completed:")) return false;

    String routeId = condition.substring("route_completed:".length());
    return instance.defeatedRoutes().contains(routeId);
  }

  // ==================== 处理器接口 ====================

  @FunctionalInterface
  public interface PhaseTransitionHandler {
    boolean shouldTransition(
        BossInstance instance, BossPhase currentPhase, BossDefinition definition);
  }

  // ==================== 工具方法 ====================

  public BossManager getBossManager() {
    return bossManager;
  }

  public Set<String> getRegisteredHandlerTypes() {
    return Set.copyOf(transitionHandlers.keySet());
  }

  public Collection<BossPhase> getAllPhases() {
    return List.copyOf(phaseRegistry.values());
  }
}
