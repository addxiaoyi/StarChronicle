package dev.starcore.starcore.boss;

import java.util.*;

/** Boss阶段定义 每个Boss可以有多个阶段，每个阶段有不同的属性和行为 */
public record BossPhase(
    String phaseId,
    String name,
    String description,
    int phaseOrder,
    double healthMultiplier,
    double damageMultiplier,
    double defenseMultiplier,
    Set<String> abilities,
    Set<String> immunities,
    Map<String, Object> phaseData,
    long durationMs,
    String nextPhaseId,
    String triggerCondition) {

  public static Builder builder(String phaseId, String name, int phaseOrder) {
    return new Builder(phaseId, name, phaseOrder);
  }

  public static class Builder {
    private final String phaseId;
    private final String name;
    private final int phaseOrder;
    private String description = "";
    private double healthMultiplier = 1.0;
    private double damageMultiplier = 1.0;
    private double defenseMultiplier = 1.0;
    private Set<String> abilities = new HashSet<>();
    private Set<String> immunities = new HashSet<>();
    private Map<String, Object> phaseData = new HashMap<>();
    private long durationMs = 0;
    private String nextPhaseId = null;
    private String triggerCondition = null;

    public Builder(String phaseId, String name, int phaseOrder) {
      this.phaseId = Objects.requireNonNull(phaseId);
      this.name = Objects.requireNonNull(name);
      this.phaseOrder = phaseOrder;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder healthMultiplier(double healthMultiplier) {
      this.healthMultiplier = healthMultiplier;
      return this;
    }

    public Builder damageMultiplier(double damageMultiplier) {
      this.damageMultiplier = damageMultiplier;
      return this;
    }

    public Builder defenseMultiplier(double defenseMultiplier) {
      this.defenseMultiplier = defenseMultiplier;
      return this;
    }

    public Builder addAbility(String ability) {
      this.abilities.add(ability);
      return this;
    }

    public Builder addAbilities(Set<String> abilities) {
      this.abilities.addAll(abilities);
      return this;
    }

    public Builder addImmunity(String immunity) {
      this.immunities.add(immunity);
      return this;
    }

    public Builder addImmunities(Set<String> immunities) {
      this.immunities.addAll(immunities);
      return this;
    }

    public Builder phaseData(String key, Object value) {
      this.phaseData.put(key, value);
      return this;
    }

    public Builder phaseData(Map<String, Object> phaseData) {
      this.phaseData.putAll(phaseData);
      return this;
    }

    public Builder durationMs(long durationMs) {
      this.durationMs = durationMs;
      return this;
    }

    public Builder nextPhaseId(String nextPhaseId) {
      this.nextPhaseId = nextPhaseId;
      return this;
    }

    public Builder triggerCondition(String triggerCondition) {
      this.triggerCondition = triggerCondition;
      return this;
    }

    public BossPhase build() {
      return new BossPhase(
          phaseId,
          name,
          description,
          phaseOrder,
          healthMultiplier,
          damageMultiplier,
          defenseMultiplier,
          Set.copyOf(abilities),
          Set.copyOf(immunities),
          Map.copyOf(phaseData),
          durationMs,
          nextPhaseId,
          triggerCondition);
    }
  }
}
