package dev.starcore.starcore.core.extension.example;

import dev.starcore.starcore.core.extension.AbstractExtensionPoint;
import java.util.List;

/** 伤害计算扩展点示例 允许其他模块/插件扩展伤害计算逻辑 */
public class DamageCalculationExtensionPoint
    extends AbstractExtensionPoint<
        DamageCalculationExtensionPoint.DamageResult,
        DamageCalculationExtensionPoint.DamageContext> {

  public DamageCalculationExtensionPoint() {
    super("damage_calculation", "伤害计算扩展点 - 允许其他插件修改伤害计算结果");
  }

  @Override
  protected DamageResult aggregateResults(List<DamageResult> results, DamageContext request) {
    if (results.isEmpty()) {
      return getDefaultResult(request);
    }

    // 聚合所有贡献者的结果（取最大值）
    DamageResult best = results.get(0);
    for (DamageResult result : results) {
      if (result.finalDamage() > best.finalDamage()) {
        best = result;
      }
    }
    return best;
  }

  @Override
  protected DamageResult getDefaultResult(DamageContext request) {
    return new DamageResult(request.baseDamage(), request.baseDamage(), "default");
  }

  /** 伤害上下文 */
  public record DamageContext(
      double baseDamage,
      String attackerId,
      String defenderId,
      String weaponType,
      String[] modifiers) {}

  /** 伤害结果 */
  public record DamageResult(double finalDamage, double originalDamage, String source) {}
}
