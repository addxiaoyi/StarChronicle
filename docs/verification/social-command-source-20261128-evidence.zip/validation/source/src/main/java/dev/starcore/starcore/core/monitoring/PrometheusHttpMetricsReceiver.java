package dev.starcore.starcore.core.monitoring;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Sends Prometheus text exposition to an HTTP receiver.
 *
 * <p>The receiver is deliberately opt-in. It performs one bounded request per publish call and
 * treats every non-2xx response as a delivery failure. The deadline includes receiving the whole
 * response body. A 2xx response confirms HTTP acceptance; receiver-side storage must be verified
 * separately by deployment acceptance.
 */
public final class PrometheusHttpMetricsReceiver implements MetricsReceiver {
  private static final String CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8";

  private final HttpClient client;
  private final URI endpoint;
  private final Duration requestTimeout;
  private final String bearerToken;
  private final Set<CompletableFuture<HttpResponse<Void>>> inFlight = ConcurrentHashMap.newKeySet();
  private final AtomicBoolean closed = new AtomicBoolean();

  public PrometheusHttpMetricsReceiver(URI endpoint, Duration requestTimeout) {
    this(endpoint, requestTimeout, "");
  }

  public PrometheusHttpMetricsReceiver(URI endpoint, Duration requestTimeout, String bearerToken) {
    this(
        HttpClient.newBuilder()
            .connectTimeout(requirePositive(requestTimeout, "requestTimeout"))
            .build(),
        endpoint,
        requestTimeout,
        bearerToken);
  }

  PrometheusHttpMetricsReceiver(HttpClient client, URI endpoint, Duration requestTimeout) {
    this(client, endpoint, requestTimeout, "");
  }

  PrometheusHttpMetricsReceiver(
      HttpClient client, URI endpoint, Duration requestTimeout, String bearerToken) {
    this.client = Objects.requireNonNull(client, "client");
    this.endpoint = validateEndpoint(endpoint);
    this.requestTimeout = requirePositive(requestTimeout, "requestTimeout");
    this.bearerToken = validateBearerToken(bearerToken);
  }

  @Override
  public void publish(String prometheusPayload) throws IOException, InterruptedException {
    Objects.requireNonNull(prometheusPayload, "prometheusPayload");
    long started = System.nanoTime();
    if (closed.get()) {
      throw new IOException("METRICS_RECEIVER_CLOSED");
    }
    HttpRequest.Builder requestBuilder =
        HttpRequest.newBuilder(endpoint)
            .timeout(requestTimeout)
            .header("Content-Type", CONTENT_TYPE);
    if (!bearerToken.isBlank()) {
      requestBuilder.header("Authorization", "Bearer " + bearerToken);
    }
    HttpRequest request =
        requestBuilder
            .POST(HttpRequest.BodyPublishers.ofString(prometheusPayload, StandardCharsets.UTF_8))
            .build();
    CompletableFuture<HttpResponse<Void>> requestFuture;
    try {
      requestFuture = client.sendAsync(request, HttpResponse.BodyHandlers.discarding());
    } catch (RuntimeException failure) {
      if (closed.get()) {
        throw new IOException("METRICS_RECEIVER_CLOSED");
      }
      throw failure;
    }
    inFlight.add(requestFuture);
    HttpResponse<Void> response;
    try {
      // close() may have visited inFlight before sendAsync returned. A second
      // check after registration closes that gap without locking around I/O.
      if (closed.get()) {
        requestFuture.cancel(true);
        throw new IOException("METRICS_RECEIVER_CLOSED");
      }
      long remainingNanos = requestTimeout.toNanos() - (System.nanoTime() - started);
      if (remainingNanos <= 0) {
        throw new TimeoutException();
      }
      // HttpRequest.timeout can expire only while waiting for headers. A
      // discarding body subscriber can still wait forever for the final byte.
      response = requestFuture.get(remainingNanos, TimeUnit.NANOSECONDS);
      if (closed.get()) {
        throw new IOException("METRICS_RECEIVER_CLOSED");
      }
    } catch (TimeoutException timedOut) {
      requestFuture.cancel(true);
      throw new HttpTimeoutException("METRICS_RECEIVER_TIMEOUT");
    } catch (CancellationException cancelled) {
      throw new IOException(
          closed.get() ? "METRICS_RECEIVER_CLOSED" : "METRICS_RECEIVER_CANCELLED");
    } catch (ExecutionException failure) {
      if (closed.get()) {
        throw new IOException("METRICS_RECEIVER_CLOSED");
      }
      Throwable cause = failure.getCause();
      if (cause instanceof IOException ioException) {
        throw ioException;
      }
      if (cause instanceof RuntimeException runtimeException) {
        throw runtimeException;
      }
      throw new IOException("METRICS_RECEIVER_REQUEST_FAILED", cause);
    } catch (InterruptedException interrupted) {
      requestFuture.cancel(true);
      Thread.currentThread().interrupt();
      throw interrupted;
    } finally {
      inFlight.remove(requestFuture);
    }
    if (response.statusCode() < 200 || response.statusCode() >= 300) {
      throw new IOException("METRICS_RECEIVER_HTTP_STATUS: " + response.statusCode());
    }
  }

  @Override
  public void close() {
    if (!closed.compareAndSet(false, true)) {
      return;
    }
    inFlight.forEach(request -> request.cancel(true));
    client.shutdownNow();
  }

  private static URI validateEndpoint(URI endpoint) {
    URI value = Objects.requireNonNull(endpoint, "endpoint");
    String scheme = value.getScheme();
    if (!("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) {
      throw new IllegalArgumentException("endpoint must use http or https");
    }
    if (value.getHost() == null || value.getHost().isBlank()) {
      throw new IllegalArgumentException("endpoint must include a host");
    }
    if (value.getUserInfo() != null || value.getFragment() != null) {
      throw new IllegalArgumentException(
          "endpoint must not include user information or a fragment");
    }
    return value;
  }

  private static String validateBearerToken(String bearerToken) {
    String value = Objects.requireNonNull(bearerToken, "bearerToken");
    if (value.indexOf('\r') >= 0 || value.indexOf('\n') >= 0) {
      throw new IllegalArgumentException("bearerToken must not contain line breaks");
    }
    return value;
  }

  private static Duration requirePositive(Duration value, String name) {
    Duration duration = Objects.requireNonNull(value, name);
    if (duration.isZero() || duration.isNegative()) {
      throw new IllegalArgumentException(name + " must be positive");
    }
    try {
      duration.toNanos();
    } catch (ArithmeticException overflow) {
      throw new IllegalArgumentException(name + " exceeds the supported nanosecond range");
    }
    return duration;
  }
}
