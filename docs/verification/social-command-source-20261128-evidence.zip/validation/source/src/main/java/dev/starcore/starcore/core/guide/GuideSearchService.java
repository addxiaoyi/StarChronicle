package dev.starcore.starcore.core.guide;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 在指南内容中查找可以直接进入的玩法条目。 */
public final class GuideSearchService {

  private GuideSearchService() {}

  public static List<SearchResult> search(String query) {
    if (query == null || query.isBlank()) {
      return List.of();
    }

    String needle = query.trim().toLowerCase(Locale.ROOT);
    List<SearchResult> matches = new ArrayList<>();
    for (GuideChapter chapter : GuideChapter.values()) {
      for (GuideContentProvider.GuideItem item : GuideContentProvider.getItems(chapter)) {
        if (matches(item, needle)) {
          matches.add(new SearchResult(chapter, item));
        }
      }
    }
    return List.copyOf(matches);
  }

  private static boolean matches(GuideContentProvider.GuideItem item, String needle) {
    if (contains(item.id(), needle)
        || contains(item.title(), needle)
        || contains(item.subtitle(), needle)) {
      return true;
    }
    return item.description().stream().anyMatch(line -> contains(line, needle));
  }

  private static boolean contains(String value, String needle) {
    return value != null && value.toLowerCase(Locale.ROOT).contains(needle);
  }

  public record SearchResult(GuideChapter chapter, GuideContentProvider.GuideItem item) {}
}
