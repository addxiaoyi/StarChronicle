package dev.starcore.starcore.foundation.economy.extension;

import dev.starcore.starcore.core.extension.AbstractExtensionPoint;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 经济交易扩展点
 *
 * <p>允许拦截和修改经济交易（存款、取款、转账）。 典型用途：交易税、限额、黑名单、折扣等。
 */
public class EconomyTransactionExtensionPoint
    extends AbstractExtensionPoint<
        EconomyTransactionExtensionPoint.TransactionResult,
        EconomyTransactionExtensionPoint.TransactionContext> {

  public EconomyTransactionExtensionPoint() {
    super("economy_transaction", "经济交易扩展点");
  }

  @Override
  protected TransactionResult aggregateResults(
      List<TransactionResult> results, TransactionContext request) {
    if (results.isEmpty()) {
      return getDefaultResult(request);
    }
    // 所有结果必须都通过才能继续，取最小修改金额
    TransactionResult result = getDefaultResult(request);
    BigDecimal minAmount = request.amount;

    for (TransactionResult r : results) {
      if (!r.approved) {
        return new TransactionResult(false, request.amount, "rejected", Map.of("reason", r.reason));
      }
      if (r.modifiedAmount != null && r.modifiedAmount.compareTo(minAmount) < 0) {
        minAmount = r.modifiedAmount;
      }
    }
    return new TransactionResult(true, minAmount, "approved", Map.of("approvals", results.size()));
  }

  @Override
  protected TransactionResult getDefaultResult(TransactionContext request) {
    return new TransactionResult(true, request.amount, "default", Map.of());
  }

  /** 交易上下文 */
  public record TransactionContext(
      UUID playerId,
      UUID targetId,
      BigDecimal amount,
      TransactionType type,
      BigDecimal balanceBefore,
      String source) {
    public TransactionContext {
      if (amount == null) {
        amount = BigDecimal.ZERO;
      }
      if (balanceBefore == null) {
        balanceBefore = BigDecimal.ZERO;
      }
    }
  }

  /** 交易结果 */
  public record TransactionResult(
      boolean approved, BigDecimal modifiedAmount, String reason, Map<String, Object> metadata)
      implements Serializable {}

  public enum TransactionType {
    DEPOSIT,
    WITHDRAW,
    TRANSFER
  }
}
