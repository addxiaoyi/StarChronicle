package dev.starcore.starcore.epoch;

import java.util.*;

/** 纪元事件定义 表示纪元生命周期中的重要事件 */
public record EpochEvent(
    String eventId,
    String epochRunId,
    EpochEventType type,
    String name,
    String description,
    Long timestamp,
    Map<String, Object> metadata,
    String source,
    String targetState) {

  public static Builder builder(String eventId, String epochRunId, EpochEventType type) {
    return new Builder(eventId, epochRunId, type);
  }

  public static class Builder {
    private final String eventId;
    private final String epochRunId;
    private final EpochEventType type;
    private String name = "";
    private String description = "";
    private Long timestamp = System.currentTimeMillis();
    private Map<String, Object> metadata = new HashMap<>();
    private String source = "";
    private String targetState = "";

    public Builder(String eventId, String epochRunId, EpochEventType type) {
      this.eventId = Objects.requireNonNull(eventId);
      this.epochRunId = Objects.requireNonNull(epochRunId);
      this.type = Objects.requireNonNull(type);
    }

    public Builder name(String name) {
      this.name = name;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder timestamp(Long timestamp) {
      this.timestamp = timestamp;
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata = new HashMap<>(metadata);
      return this;
    }

    public Builder addMetadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder source(String source) {
      this.source = source;
      return this;
    }

    public Builder targetState(String targetState) {
      this.targetState = targetState;
      return this;
    }

    public EpochEvent build() {
      return new EpochEvent(
          eventId,
          epochRunId,
          type,
          name,
          description,
          timestamp,
          Map.copyOf(metadata),
          source,
          targetState);
    }
  }
}
