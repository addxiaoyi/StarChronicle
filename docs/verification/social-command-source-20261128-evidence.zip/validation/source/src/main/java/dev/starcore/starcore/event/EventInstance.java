package dev.starcore.starcore.event;

import java.util.*;

/** 事件实例模型 表示一个正在运行的事件实例 */
public record EventInstance(
    String instanceId, // 实例ID
    String eventId, // 事件定义ID
    String epochRunId, // 纪元运行ID
    EventStatus status, // 当前状态
    Map<String, Object> context, // 事件上下文
    Map<String, Object> results, // 事件结果
    Long startedAt, // 开始时间
    Long completedAt, // 完成时间
    String ownerId, // 所有者ID
    Set<String> participants, // 参与者集合
    String currentBranch, // 当前分支
    Map<String, Object> branchResults, // 分支结果
    String errorMessage, // 错误消息
    int retryCount, // 重试次数
    String parentInstanceId // 父实例ID
    ) {

  /** 创建事件实例构建器 */
  public static Builder builder(String instanceId, String eventId, String epochRunId) {
    return new Builder(instanceId, eventId, epochRunId);
  }

  /** 检查事件是否已完成 */
  public boolean isCompleted() {
    return status == EventStatus.completed
        || status == EventStatus.confirmed
        || status == EventStatus.archived;
  }

  /** 检查事件是否成功 */
  public boolean isSuccessful() {
    return status == EventStatus.completed
        || status == EventStatus.confirmed
        || status == EventStatus.archived;
  }

  /** 检查事件是否失败 */
  public boolean isFailed() {
    return status == EventStatus.failed || status == EventStatus.cancelled;
  }

  /** 获取事件持续时间 */
  public long getDuration() {
    if (startedAt == null) return 0;
    Long endTime = completedAt != null ? completedAt : System.currentTimeMillis();
    return endTime - startedAt;
  }

  /** 事件实例构建器 */
  public static class Builder {
    private final String instanceId;
    private final String eventId;
    private final String epochRunId;
    private EventStatus status = EventStatus.defined;
    private Map<String, Object> context = new HashMap<>();
    private Map<String, Object> results = new HashMap<>();
    private Long startedAt;
    private Long completedAt;
    private String ownerId;
    private Set<String> participants = new HashSet<>();
    private String currentBranch;
    private Map<String, Object> branchResults = new HashMap<>();
    private String errorMessage;
    private int retryCount = 0;
    private String parentInstanceId;

    private Builder(String instanceId, String eventId, String epochRunId) {
      this.instanceId = Objects.requireNonNull(instanceId);
      this.eventId = Objects.requireNonNull(eventId);
      this.epochRunId = Objects.requireNonNull(epochRunId);
    }

    public Builder status(EventStatus status) {
      this.status = status;
      return this;
    }

    public Builder context(String key, Object value) {
      this.context.put(key, value);
      return this;
    }

    public Builder context(Map<String, Object> context) {
      this.context.putAll(context);
      return this;
    }

    public Builder results(String key, Object value) {
      this.results.put(key, value);
      return this;
    }

    public Builder results(Map<String, Object> results) {
      this.results.putAll(results);
      return this;
    }

    public Builder startedAt(Long startedAt) {
      this.startedAt = startedAt;
      return this;
    }

    public Builder completedAt(Long completedAt) {
      this.completedAt = completedAt;
      return this;
    }

    public Builder ownerId(String ownerId) {
      this.ownerId = ownerId;
      return this;
    }

    public Builder addParticipant(String participant) {
      this.participants.add(participant);
      return this;
    }

    public Builder participants(Set<String> participants) {
      this.participants = new HashSet<>(participants);
      return this;
    }

    public Builder currentBranch(String currentBranch) {
      this.currentBranch = currentBranch;
      return this;
    }

    public Builder branchResults(String key, Object value) {
      this.branchResults.put(key, value);
      return this;
    }

    public Builder branchResults(Map<String, Object> branchResults) {
      this.branchResults.putAll(branchResults);
      return this;
    }

    public Builder errorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
      return this;
    }

    public Builder retryCount(int retryCount) {
      this.retryCount = retryCount;
      return this;
    }

    public Builder parentInstanceId(String parentInstanceId) {
      this.parentInstanceId = parentInstanceId;
      return this;
    }

    public EventInstance build() {
      return new EventInstance(
          instanceId,
          eventId,
          epochRunId,
          status,
          Map.copyOf(context),
          Map.copyOf(results),
          startedAt,
          completedAt,
          ownerId,
          Set.copyOf(participants),
          currentBranch,
          Map.copyOf(branchResults),
          errorMessage,
          retryCount,
          parentInstanceId);
    }
  }
}
