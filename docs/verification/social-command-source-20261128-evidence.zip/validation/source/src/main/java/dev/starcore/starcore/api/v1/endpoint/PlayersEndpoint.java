package dev.starcore.starcore.api.v1.endpoint;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.PageRequest;
import dev.starcore.starcore.api.v1.PageResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.dto.PlayerDto;
import dev.starcore.starcore.api.v1.handler.BaseHttpHandler;
import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.foundation.player.PlayerProfileService;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.ranking.RankPeriod;
import dev.starcore.starcore.ranking.RankingService;
import dev.starcore.starcore.social.simulation.RelationshipNetwork;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

/** 玩家 REST API 端点 */
public final class PlayersEndpoint extends BaseHttpHandler {

  private final OnlinePlayerDirectory onlinePlayerDirectory;
  private final PlayerProfileService playerProfileService;
  private final NationService nationService;
  private final RelationshipNetwork relationshipNetwork;
  private final RankingService rankingService;

  public PlayersEndpoint(
      Gson gson,
      ApiAuthService authService,
      OnlinePlayerDirectory onlinePlayerDirectory,
      PlayerProfileService playerProfileService,
      NationService nationService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth) {
    this(
        gson,
        authService,
        onlinePlayerDirectory,
        playerProfileService,
        nationService,
        corsConfig,
        requiresAuth,
        null,
        null);
  }

  public PlayersEndpoint(
      Gson gson,
      ApiAuthService authService,
      OnlinePlayerDirectory onlinePlayerDirectory,
      PlayerProfileService playerProfileService,
      NationService nationService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth,
      RelationshipNetwork relationshipNetwork) {
    this(
        gson,
        authService,
        onlinePlayerDirectory,
        playerProfileService,
        nationService,
        corsConfig,
        requiresAuth,
        relationshipNetwork,
        null);
  }

  public PlayersEndpoint(
      Gson gson,
      ApiAuthService authService,
      OnlinePlayerDirectory onlinePlayerDirectory,
      PlayerProfileService playerProfileService,
      NationService nationService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth,
      RelationshipNetwork relationshipNetwork,
      RankingService rankingService) {
    super(
        gson, authService, corsConfig, requiresAuth, ApiAuthService.ApiKeyPermission.READ_PLAYERS);
    this.onlinePlayerDirectory = onlinePlayerDirectory;
    this.playerProfileService = playerProfileService;
    this.nationService = nationService;
    this.relationshipNetwork = relationshipNetwork;
    this.rankingService = rankingService;
  }

  public PlayersEndpoint(
      Gson gson,
      ApiAuthService authService,
      OnlinePlayerDirectory onlinePlayerDirectory,
      PlayerProfileService playerProfileService,
      NationService nationService) {
    this(
        gson,
        authService,
        onlinePlayerDirectory,
        playerProfileService,
        nationService,
        RestApiConfig.CorsConfig.DEFAULT,
        false,
        null,
        null);
  }

  public PlayersEndpoint(
      Gson gson,
      ApiAuthService authService,
      OnlinePlayerDirectory onlinePlayerDirectory,
      PlayerProfileService playerProfileService,
      NationService nationService,
      RelationshipNetwork relationshipNetwork) {
    this(
        gson,
        authService,
        onlinePlayerDirectory,
        playerProfileService,
        nationService,
        RestApiConfig.CorsConfig.DEFAULT,
        false,
        relationshipNetwork,
        null);
  }

  @Override
  protected void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    String path = getPath(exchange);

    if (path.equals("/api/v1/players")) {
      if (isMethod(exchange, "GET")) {
        handleListPlayers(exchange, authContext);
      } else {
        sendMethodNotAllowed(exchange);
      }
    } else if (path.startsWith("/api/v1/players/")) {
      String idPart = path.substring("/api/v1/players/".length());
      if (idPart.isEmpty() || idPart.endsWith("/")) {
        sendNotFound(exchange, "Player");
      } else {
        handlePlayerById(exchange, authContext, idPart.split("/")[0]);
      }
    } else {
      sendNotFound(exchange, "Endpoint");
    }
  }

  private void handleListPlayers(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    Map<String, String> params = parseQueryParams(exchange);
    PageRequest pageRequest = PageRequest.of(params.get("page"), params.get("pageSize"));

    Set<UUID> allPlayerIds = new HashSet<>();

    // 添加在线玩家
    if (onlinePlayerDirectory != null) {
      onlinePlayerDirectory
          .onlinePlayers()
          .forEach(player -> allPlayerIds.add(player.getUniqueId()));
    }

    // 添加离线玩家（从 profile service）
    if (playerProfileService != null) {
      playerProfileService.snapshot().keySet().forEach(allPlayerIds::add);
    }

    long total = allPlayerIds.size();

    // Sort UUIDs before slicing so page membership is stable across requests.
    List<UUID> playerIdsList = allPlayerIds.stream().sorted().toList();
    int fromIndex = (int) Math.min(pageRequest.offset(), playerIdsList.size());
    int toIndex =
        (int) Math.min(pageRequest.offset() + pageRequest.pageSize(), playerIdsList.size());
    List<UUID> pagePlayerIds =
        fromIndex < toIndex ? playerIdsList.subList(fromIndex, toIndex) : List.of();

    List<PlayerDto> dtos =
        pagePlayerIds.stream()
            .map(playerId -> toPlayerDto(playerId, authContext))
            .filter(Optional::isPresent)
            .map(Optional::get)
            .collect(Collectors.toList());

    PageResponse<PlayerDto> response =
        PageResponse.of(dtos, pageRequest.page(), pageRequest.pageSize(), total);

    sendSuccess(
        exchange,
        response,
        ApiResponse.ResponseMeta.of(
            pageRequest.page(), pageRequest.pageSize(), total, generateRequestId()));
  }

  private void handlePlayerById(HttpExchange exchange, ApiAuthContext authContext, String id)
      throws IOException {
    if (!isMethod(exchange, "GET")) {
      sendMethodNotAllowed(exchange);
      return;
    }

    UUID uuid;
    try {
      uuid = UUID.fromString(id);
    } catch (IllegalArgumentException e) {
      sendError(exchange, 400, "INVALID_ID", "Invalid player ID format");
      return;
    }

    Optional<PlayerDto> playerOpt = toPlayerDto(uuid, authContext);

    if (playerOpt.isEmpty()) {
      sendNotFound(exchange, "Player");
      return;
    }

    sendSuccess(exchange, playerOpt.get());
  }

  private Optional<PlayerDto> toPlayerDto(UUID playerId, ApiAuthContext authContext) {
    Player onlinePlayer =
        onlinePlayerDirectory == null
            ? null
            : onlinePlayerDirectory.findPlayerById(playerId).orElse(null);
    boolean isOnline = onlinePlayer != null && onlinePlayer.isOnline();

    // 获取玩家名称
    String playerName = null;
    if (isOnline) {
      playerName = onlinePlayer.getName();
    } else {
      if (playerProfileService != null) {
        Optional<String> nameOpt = playerProfileService.lastKnownName(playerId);
        if (nameOpt.isPresent()) {
          playerName = nameOpt.get();
        }
      }
    }

    if (playerName == null || playerName.isBlank()) {
      playerName = playerId.toString().substring(0, 8);
    }

    // 获取国家信息
    String nationId = null;
    String nationName = null;
    String rank = null;

    if (nationService != null) {
      Optional<Nation> nationOpt = nationService.nationOf(playerId);
      if (nationOpt.isPresent()) {
        Nation nation = nationOpt.get();
        NationId nid = nation.id();
        nationId = nid.toString();
        nationName = nation.name();
      }
    }

    // 获取位置信息
    PlayerDto.LocationDto location = null;
    if (isOnline && onlinePlayer != null) {
      location =
          new PlayerDto.LocationDto(
              onlinePlayer.getWorld().getName(),
              onlinePlayer.getLocation().getBlockX(),
              onlinePlayer.getLocation().getBlockY(),
              onlinePlayer.getLocation().getBlockZ());
    }

    String relation = relationFor(authContext, playerId);

    PlayerDto.KdaDto kda = kdaFor(playerId);

    // 最后在线时间
    long lastSeen = 0L;
    if (!isOnline) {
      OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerId);
      lastSeen = offlinePlayer.getLastPlayed();
    }

    return Optional.of(
        new PlayerDto(
            playerId.toString(),
            playerName,
            nationId,
            nationName,
            rank,
            isOnline,
            lastSeen,
            location,
            relation,
            kda));
  }

  String relationFor(ApiAuthContext authContext, UUID targetId) {
    UUID viewerId = authContext == null ? null : authContext.playerId();
    if (viewerId == null) return "NEUTRAL";
    if (viewerId.equals(targetId)) return "OWN";
    if (relationshipNetwork == null) return "NEUTRAL";
    try {
      RelationshipNetwork.Relationship relationship =
          relationshipNetwork.getRelationship(viewerId, targetId);
      if (relationship == null) return "NEUTRAL";
      return switch (relationship.type()) {
        case FRIEND, CLOSE_FRIEND, BEST_FRIEND, LOVER -> "ALLY";
        case RIVAL, ENEMY, NEMESIS -> "ENEMY";
        default -> "NEUTRAL";
      };
    } catch (RuntimeException ignored) {
      // A missing social row must not make a player read fail.
      return "NEUTRAL";
    }
  }

  PlayerDto.KdaDto kdaFor(UUID playerId) {
    if (rankingService == null) return null;
    try {
      int kills = Math.toIntExact(rankingService.getKillCount(playerId, RankPeriod.ALLTIME).join());
      int deaths =
          Math.toIntExact(rankingService.getDeathCount(playerId, RankPeriod.ALLTIME).join());
      int assists =
          Math.toIntExact(rankingService.getAssistCount(playerId, RankPeriod.ALLTIME).join());
      double ratio = deaths > 0 ? (double) (kills + assists) / deaths : kills + assists;
      return new PlayerDto.KdaDto(kills, deaths, assists, ratio);
    } catch (RuntimeException ignored) {
      return null;
    }
  }
}
