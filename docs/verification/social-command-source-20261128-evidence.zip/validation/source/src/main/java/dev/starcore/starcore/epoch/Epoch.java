package dev.starcore.starcore.epoch;

/** 纪元模型 表示一个纪元实例及其状态 */
public record Epoch(
    String epochRunId, // 纪元运行ID
    String cycleId, // 叙事周期ID
    int epochNumber, // 纪元编号
    EpochState state, // 当前状态
    String variantKey, // 变体键
    String sourceMigrationId, // 源迁移ID
    Long startedAt, // 开始时间
    String decisionRef, // 决策引用
    String milestoneRef, // 里程碑引用
    String targetMigrationId, // 目标迁移ID
    String suspensionRef, // 暂停引用
    String recoveryRef, // 恢复引用
    Long archivedAt, // 归档时间
    String name, // 纪元名称
    String description // 纪元描述
    ) {
  /** 创建具有指定参数的纪元 */
  public static Epoch create(String epochRunId, int epochNumber, String cycleId) {
    return new Epoch(
        epochRunId,
        cycleId,
        epochNumber,
        EpochState.locked,
        "default",
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null);
  }

  /** 创建活跃状态的纪元 */
  public static Epoch active(String epochRunId, int epochNumber, String cycleId) {
    return new Epoch(
        epochRunId,
        cycleId,
        epochNumber,
        EpochState.active,
        "default",
        null,
        System.currentTimeMillis(),
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null);
  }

  /** 检查纪元是否可以进行迁移 */
  public boolean canMigrate() {
    return state == EpochState.archived || state == EpochState.suspended;
  }

  /** 检查纪元是否激活 */
  public boolean isActive() {
    return state.isActive();
  }

  /** 检查纪元是否已归档 */
  public boolean isArchived() {
    return state == EpochState.archived;
  }
}
