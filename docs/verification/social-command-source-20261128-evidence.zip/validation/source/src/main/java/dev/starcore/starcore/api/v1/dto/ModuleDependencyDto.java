package dev.starcore.starcore.api.v1.dto;

import com.google.gson.annotations.SerializedName;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleStatus;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 模块依赖关系 DTO */
public record ModuleDependencyDto(
    @SerializedName("nodes") Map<String, NodeDto> nodes,
    @SerializedName("cycles") List<CycleDto> cycles,
    @SerializedName("unmetDependencies") List<String> unmetDependencies,
    @SerializedName("health") HealthDto health) {
  public record NodeDto(
      @SerializedName("id") String id,
      @SerializedName("displayName") String displayName,
      @SerializedName("layer") LayerDto layer,
      @SerializedName("dependencies") List<String> dependencies,
      @SerializedName("providedServices") List<String> providedServices,
      @SerializedName("ownedServices") Set<String> ownedServices,
      @SerializedName("status") String status,
      @SerializedName("failureReason") String failureReason) {}

  public record CycleDto(
      @SerializedName("modules") List<String> modules,
      @SerializedName("description") String description) {}

  public record HealthDto(
      @SerializedName("totalModules") int totalModules,
      @SerializedName("enabledModules") int enabledModules,
      @SerializedName("failedModules") int failedModules,
      @SerializedName("hasCycles") boolean hasCycles,
      @SerializedName("hasUnmetDependencies") boolean hasUnmetDependencies) {}

  public record LayerDto(
      @SerializedName("name") String name, @SerializedName("ordinal") int ordinal) {}

  public static LayerDto fromLayer(ModuleLayer layer) {
    return new LayerDto(layer.name(), layer.ordinal());
  }

  public static String statusToString(ModuleStatus status) {
    return status.name();
  }
}
