package dev.starcore.starcore.identity;

/** 身份状态枚举 定义玩家在十二节点观测中的身份状态 */
public enum IdentityStatus {
  /** 新觉醒者：刚刚苏醒的玩家 */
  awakened("新觉醒者", "刚苏醒的玩家"),

  /** 观察者：参与观察活动的玩家 */
  observer("观察者", "参与观察活动"),

  /** 证人：拥有证据并参与公共选择的玩家 */
  witness("证人", "拥有证据并参与选择"),

  /** 审议员：参与审议和决策的玩家 */
  arbiter("审议员", "参与审议和决策"),

  /** 执政者：拥有治理权的玩家 */
  governor("执政者", "拥有治理权"),

  /** 归还者：帮助重建世界的玩家 */
  returner("归还者", "帮助重建世界"),

  /** 第十三席：获得反向举证和共同决策权的玩家 */
  thirteenth_seat("第十三席", "拥有反向举证权");

  private final String displayName;
  private final String description;

  IdentityStatus(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 获取级别（用于排序） */
  public int getLevel() {
    return ordinal();
  }

  /** 检查是否达到指定级别 */
  public boolean isAtLeast(IdentityStatus other) {
    return this.ordinal() >= other.ordinal();
  }

  /** 获取下一级别 */
  public IdentityStatus getNext() {
    int next = ordinal() + 1;
    if (next >= values().length) return this;
    return values()[next];
  }
}
