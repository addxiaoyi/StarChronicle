package dev.starcore.starcore.choice.gui;

import dev.starcore.starcore.choice.ChoiceManager;
import dev.starcore.starcore.choice.PublicChoiceService;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.plugin.Plugin;

/** 公共决策投票 GUI 点击监听 */
public final class PublicChoiceGuiListener implements Listener {

  private final PublicChoiceService choiceService;
  private final ChoiceManager choiceManager;

  public PublicChoiceGuiListener(
      Plugin plugin, PublicChoiceService choiceService, ChoiceManager choiceManager) {
    this.choiceService = choiceService;
    this.choiceManager = choiceManager;
  }

  /** 打开投票面板 */
  public void open(Player player) {
    new PublicChoiceGui(player, choiceService, choiceManager).open();
  }

  @EventHandler
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof PublicChoiceGui) {
      event.setCancelled(true);
    }
  }

  @EventHandler
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getInventory().getHolder() instanceof PublicChoiceGui gui)) {
      return;
    }
    event.setCancelled(true);
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    if (event.getClickedInventory() != event.getInventory()) {
      return;
    }
    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.0f);
    gui.handleClick(event.getSlot());
  }
}
