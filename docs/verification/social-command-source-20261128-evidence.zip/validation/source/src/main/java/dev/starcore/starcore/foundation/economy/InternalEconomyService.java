package dev.starcore.starcore.foundation.economy;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.extension.ExtensionRegistry;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.foundation.economy.event.EconomyEvent;
import dev.starcore.starcore.foundation.economy.extension.EconomyTransactionExtensionPoint;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class InternalEconomyService implements EconomyService {
  private static final int SCALE = 2;
  private static final String NAMESPACE = "economy";
  private static final String FILE_NAME = "player-balances.properties";
  private static final String DEPOSIT_PERSISTENCE_FAILURE_CODE =
      "ECONOMY_DEPOSIT_PERSISTENCE_FAILURE";
  private static final String DEPOSIT_VALIDATION_FAILURE_CODE =
      "ECONOMY_DEPOSIT_VALIDATION_FAILURE";
  private static final String SET_BALANCE_PERSISTENCE_FAILURE_CODE =
      "ECONOMY_SET_BALANCE_PERSISTENCE_FAILURE";
  private static final String SET_BALANCE_VALIDATION_FAILURE_CODE =
      "ECONOMY_SET_BALANCE_VALIDATION_FAILURE";
  private static final String WITHDRAW_PERSISTENCE_FAILURE_CODE =
      "ECONOMY_WITHDRAW_PERSISTENCE_FAILURE";
  private static final String WITHDRAW_VALIDATION_FAILURE_CODE =
      "ECONOMY_WITHDRAW_VALIDATION_FAILURE";
  private static final String ACCOUNT_CREATE_PERSISTENCE_FAILURE_CODE =
      "ECONOMY_ACCOUNT_CREATE_PERSISTENCE_FAILURE";
  private static final String TRANSFER_PERSISTENCE_FAILURE_CODE =
      "ECONOMY_TRANSFER_PERSISTENCE_FAILURE";
  private static final String TRANSFER_VALIDATION_FAILURE_CODE =
      "ECONOMY_TRANSFER_VALIDATION_FAILURE";
  private static final String WITHDRAW_EXTENSION_FAILURE_CODE =
      "ECONOMY_WITHDRAW_EXTENSION_FAILURE";
  private static final String TRANSFER_EXTENSION_FAILURE_CODE =
      "ECONOMY_TRANSFER_EXTENSION_FAILURE";

  private final BalanceStorage storage;
  private final ConcurrentMap<UUID, BigDecimal> balances = new ConcurrentHashMap<>();

  /** Coordinates balance mutations with full snapshots and persistence rollbacks. */
  private final Object flushLock = new Object();

  /** Serializes balance mutation with its persistence rollback for one account. */
  private final ConcurrentMap<UUID, Object> accountLocks = new ConcurrentHashMap<>();

  private final Logger logger;

  /** E-114 修复: 记录 UUID 解析/余额解析失败次数，供运维 metric 采集。 */
  private int parseFailureCount = 0;

  private final AtomicLong txSeq = new AtomicLong();
  private StarCoreEventBus eventBus;
  private volatile boolean eventsEnabled = false;

  public InternalEconomyService(PersistenceService persistenceService) {
    this(new PersistenceBalanceStorage(persistenceService), null);
  }

  public InternalEconomyService(
      DatabaseService databaseService, PersistenceService persistenceService, Logger logger) {
    this(databaseService, persistenceService, logger, ForkJoinPool.commonPool());
  }

  public InternalEconomyService(
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger,
      Executor ioExecutor) {
    this(
        new DatabaseAwareBalanceStorage(databaseService, persistenceService, logger, ioExecutor),
        logger);
  }

  InternalEconomyService(BalanceStorage storage) {
    this(storage, null);
  }

  InternalEconomyService(BalanceStorage storage, Logger logger) {
    this.storage = Objects.requireNonNull(storage, "storage");
    this.logger = logger;
  }

  /** 设置事件总线用于发布经济事件 */
  public void setEventBus(StarCoreEventBus eventBus) {
    this.eventBus = eventBus;
    this.eventsEnabled = eventBus != null;
  }

  /**
   * 订阅经济事件
   *
   * @param listener 事件监听器
   * @return 取消订阅的 Runnable
   */
  public Runnable subscribeToEvents(Consumer<EconomyEvent> listener) {
    if (eventBus != null) {
      return eventBus.subscribe(EconomyEvent.class, listener);
    }
    return () -> {};
  }

  /** 发布经济事件 */
  private void publishEvent(EconomyEvent event) {
    if (!eventsEnabled || eventBus == null) {
      return;
    }
    try {
      if (!eventBus.publish(event)) {
        logWarning(
            "Economy event listener reported failure [ECONOMY_EVENT_PUBLISH]: type="
                + event.eventType()
                + ", account="
                + event.playerId());
      }
    } catch (RuntimeException exception) {
      logWarning(
          "Economy event publication failed [ECONOMY_EVENT_PUBLISH]: type="
              + event.eventType()
              + ", account="
              + event.playerId(),
          exception);
    }
  }

  public void start() {
    Properties properties = storage.load();
    balances.clear();
    for (String key : properties.stringPropertyNames()) {
      try {
        UUID accountId = UUID.fromString(key);
        BigDecimal balance = normalize(new BigDecimal(properties.getProperty(key)));
        // audit B-005/B-006: 保留 0 余额账户，让 hasAccount 在重启后仍为 true；
        // balances contain zero entries as 存在性标记，余额查询时仍返回 0。
        balances.put(accountId, balance);
      } catch (RuntimeException e) {
        parseFailureCount++;
        logWarning("Failed to parse balance for account: " + key + " - " + e.getMessage());
      }
    }
  }

  public void stop() {
    flushNow();
    // E-026 修复: stop 时强制 await 最后一次 flush 完成，避免关服时余额未持久化。
    if (storage instanceof SqlBalanceStorage sbs) {
      sbs.shutdown();
    }
  }

  public BigDecimal balance(UUID accountId) {
    if (accountId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    return balances.getOrDefault(accountId, BigDecimal.ZERO).setScale(SCALE, RoundingMode.DOWN);
  }

  @Override
  public BigDecimal getBalance(UUID playerId) {
    return balance(playerId);
  }

  @Override
  public boolean has(UUID playerId, BigDecimal amount) {
    if (playerId == null || amount == null || amount.signum() < 0) {
      return false;
    }
    return balance(playerId).compareTo(amount) >= 0;
  }

  @Override
  public boolean deposit(UUID playerId, BigDecimal amount) {
    // The interface reports a committed result. Background rewards must opt in
    // to the explicit syncWrite=false overload so enqueueing an SQL write is
    // never mistaken for a durable balance change.
    return deposit(playerId, amount, true);
  }

  /**
   * 存款 - 支持同步/异步持久化
   *
   * @param playerId 玩家ID
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘（关键交易使用true）
   * @return 是否成功
   */
  public boolean deposit(UUID playerId, BigDecimal amount, boolean syncWrite) {
    return deposit(playerId, amount, syncWrite, true);
  }

  /**
   * 存款 - 完整参数版本
   *
   * @param playerId 玩家ID
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘
   * @param publishEvent 是否发布事件
   * @return 是否成功
   */
  public boolean deposit(
      UUID playerId, BigDecimal amount, boolean syncWrite, boolean publishEvent) {
    return deposit(playerId, amount, syncWrite, publishEvent, "deposit");
  }

  /**
   * 存款 - 带业务来源标识的完整参数版本。
   *
   * <p>来源会传递给经济交易扩展点，使奖励等关键流程能够被 Provider 精确拦截和观测， 而不会把所有普通存款混为同一种操作。
   */
  public boolean deposit(
      UUID playerId, BigDecimal amount, boolean syncWrite, boolean publishEvent, String source) {
    if (playerId == null) {
      return false;
    }
    String transactionSource = source == null || source.isBlank() ? "deposit" : source;
    try {
      requirePositive(amount);
      // audit B-004: 拒绝金额小于 0.01 的微额（避免 normalize 后被截断为 0 导致凭空吞钱）
      BigDecimal normalized = normalize(amount);
      if (normalized.signum() == 0) {
        logWarning(
            "code="
                + DEPOSIT_VALIDATION_FAILURE_CODE
                + " account="
                + playerId
                + " op=deposit"
                + " txId="
                + txSeq.incrementAndGet()
                + " reason=below_scale",
            new IllegalArgumentException("amount is below the supported scale"));
        return false;
      }
      try {
        EconomyTransactionExtensionPoint.TransactionResult extResult =
            ExtensionRegistry.getInstance()
                .execute(
                    "economy_transaction",
                    new EconomyTransactionExtensionPoint.TransactionContext(
                        playerId,
                        null,
                        amount,
                        EconomyTransactionExtensionPoint.TransactionType.DEPOSIT,
                        balance(playerId),
                        transactionSource));
        if (extResult != null && !extResult.approved()) {
          return false;
        }
      } catch (RuntimeException extensionFailure) {
        logWarning("code=ECONOMY_DEPOSIT_EXTENSION_FAILURE account=" + playerId, extensionFailure);
      }
      synchronized (lockForAccount(playerId)) {
        return depositLocked(playerId, amount, normalized, syncWrite, publishEvent);
      }
    } catch (IllegalArgumentException | NullPointerException e) {
      logWarning(
          "code="
              + DEPOSIT_VALIDATION_FAILURE_CODE
              + " account="
              + playerId
              + " op=deposit"
              + " txId="
              + txSeq.incrementAndGet(),
          e);
      return false;
    } catch (RuntimeException e) {
      logWarning(
          "code=ECONOMY_DEPOSIT_OPERATION_FAILURE"
              + " account="
              + playerId
              + " op=deposit"
              + " txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + e.getClass().getName(),
          e);
      return false;
    }
  }

  private boolean depositLocked(
      UUID playerId,
      BigDecimal amount,
      BigDecimal normalized,
      boolean syncWrite,
      boolean publishEvent) {
    BigDecimal newBalance;
    long flushLockWaitStarted = System.nanoTime();
    synchronized (flushLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
          System.nanoTime() - flushLockWaitStarted);
      boolean hadPreviousBalance = balances.containsKey(playerId);
      BigDecimal previousBalance = balances.getOrDefault(playerId, BigDecimal.ZERO);
      // E-116 修复: balances.merge 在 getOrDefault + merge 之间非原子，
      // 多线程同时 deposit 同一玩家时可能丢失更新。
      BigDecimal[] computed = {null};
      balances.compute(
          playerId,
          (ignored, current) -> {
            BigDecimal balance = current == null ? BigDecimal.ZERO : current;
            BigDecimal next = balance.add(normalized);
            computed[0] = next;
            return next;
          });
      newBalance = computed[0];
      try {
        if (syncWrite) {
          flushAccount(playerId);
        } else {
          flushAsync();
        }
      } catch (RuntimeException persistenceFailure) {
        balances.compute(
            playerId, (ignored, current) -> hadPreviousBalance ? previousBalance : null);
        logWarning(
            "code="
                + DEPOSIT_PERSISTENCE_FAILURE_CODE
                + " account="
                + playerId
                + " op=deposit"
                + " txId="
                + txSeq.incrementAndGet()
                + " rollback=true",
            persistenceFailure);
        return false;
      }
    }

    if (publishEvent) {
      publishEvent(
          new EconomyEvent.Deposit(playerId, amount, newBalance, System.currentTimeMillis()));
    }
    return true;
  }

  private Object lockForAccount(UUID id) {
    return accountLocks.computeIfAbsent(id, ignored -> new Object());
  }

  @Override
  public boolean setBalance(UUID playerId, BigDecimal amount) {
    return setBalance(playerId, amount, true);
  }

  /**
   * 设置余额
   *
   * @param playerId 玩家ID
   * @param amount 金额
   * @param publishEvent 是否发布事件
   * @return 是否成功
   */
  public boolean setBalance(UUID playerId, BigDecimal amount, boolean publishEvent) {
    if (playerId == null) {
      return false;
    }
    try {
      if (amount == null || amount.signum() < 0) {
        logWarning(
            "code="
                + SET_BALANCE_VALIDATION_FAILURE_CODE
                + " account="
                + playerId
                + " op=setBalance"
                + " txId="
                + txSeq.incrementAndGet(),
            new IllegalArgumentException("amount must be zero or positive"));
        return false;
      }
      synchronized (lockForAccount(playerId)) {
        BigDecimal previousBalance = balance(playerId);
        BigDecimal normalized = normalize(amount);
        long flushLockWaitStarted = System.nanoTime();
        synchronized (flushLock) {
          EconomyOperationTimingProbe.record(
              EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
              System.nanoTime() - flushLockWaitStarted);
          boolean hadPreviousBalance = balances.containsKey(playerId);
          // audit B-005/B-006: 保留 0 余额条目以维持 hasAccount 语义；不再 remove
          balances.put(playerId, normalized);
          try {
            // setBalance has no asynchronous result channel; report success only
            // after the new value is durable.
            flushAccount(playerId);
          } catch (RuntimeException persistenceFailure) {
            if (hadPreviousBalance) {
              balances.put(playerId, previousBalance);
            } else {
              balances.remove(playerId);
            }
            logWarning(
                "code="
                    + SET_BALANCE_PERSISTENCE_FAILURE_CODE
                    + " account="
                    + playerId
                    + " op=setBalance"
                    + " txId="
                    + txSeq.incrementAndGet()
                    + " rollback=true",
                persistenceFailure);
            return false;
          }
        }

        if (publishEvent) {
          publishEvent(
              new EconomyEvent.BalanceSet(
                  playerId, previousBalance, normalized, System.currentTimeMillis()));
        }
        return true;
      }
    } catch (RuntimeException e) {
      logWarning(
          "code=ECONOMY_SET_BALANCE_OPERATION_FAILURE"
              + " account="
              + playerId
              + " op=setBalance"
              + " txId="
              + txSeq.incrementAndGet()
              + " errorType="
              + e.getClass().getName(),
          e);
      return false;
    }
  }

  public boolean withdraw(UUID accountId, BigDecimal amount) {
    return withdraw(accountId, amount, true);
  }

  /**
   * 取款 - 支持同步/异步持久化
   *
   * @param accountId 账户ID
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘（关键交易使用true）
   * @return 是否成功
   */
  public boolean withdraw(UUID accountId, BigDecimal amount, boolean syncWrite) {
    return withdraw(accountId, amount, syncWrite, true);
  }

  /**
   * 取款 - 完整参数版本
   *
   * @param accountId 账户ID
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘
   * @param publishEvent 是否发布事件
   * @return 是否成功
   */
  public boolean withdraw(
      UUID accountId, BigDecimal amount, boolean syncWrite, boolean publishEvent) {
    if (accountId == null) {
      return false;
    }
    try {
      requirePositive(amount);
    } catch (IllegalArgumentException | NullPointerException validationFailure) {
      logWarning(
          "code="
              + WITHDRAW_VALIDATION_FAILURE_CODE
              + " account="
              + accountId
              + " op=withdraw"
              + " txId="
              + txSeq.incrementAndGet(),
          validationFailure);
      return false;
    }
    // 扩展点拦截取款
    BigDecimal normalized = normalize(amount);
    try {
      ExtensionRegistry registry = ExtensionRegistry.getInstance();
      EconomyTransactionExtensionPoint.TransactionContext ctx =
          new EconomyTransactionExtensionPoint.TransactionContext(
              accountId,
              null,
              amount,
              EconomyTransactionExtensionPoint.TransactionType.WITHDRAW,
              balance(accountId),
              "withdraw");
      EconomyTransactionExtensionPoint.TransactionResult extResult =
          registry.execute("economy_transaction", ctx);
      if (extResult != null && !extResult.approved()) {
        return false;
      }
    } catch (Exception e) {
      logWarning(
          "code="
              + WITHDRAW_EXTENSION_FAILURE_CODE
              + " account="
              + accountId
              + " op=withdraw"
              + " txId="
              + txSeq.incrementAndGet()
              + " continue=true"
              + " errorType="
              + e.getClass().getName(),
          e);
    }

    BigDecimal amountForWithdraw = normalized;
    synchronized (lockForAccount(accountId)) {
      AtomicBoolean withdrawn = new AtomicBoolean(false);
      BigDecimal[] balanceBefore = {BigDecimal.ZERO};
      BigDecimal[] balanceAfter = {BigDecimal.ZERO};
      long flushLockWaitStarted = System.nanoTime();
      synchronized (flushLock) {
        EconomyOperationTimingProbe.record(
            EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
            System.nanoTime() - flushLockWaitStarted);
        balances.compute(
            accountId,
            (ignored, current) -> {
              BigDecimal balance = current == null ? BigDecimal.ZERO : current;
              balanceBefore[0] = balance;
              if (balance.compareTo(normalized) < 0) {
                return balance;
              }
              withdrawn.set(true);
              balanceAfter[0] = balance.subtract(normalized);
              return balanceAfter[0];
            });
        if (withdrawn.get()) {
          try {
            if (syncWrite) {
              flushAccount(accountId);
            } else {
              flushAsync();
            }
          } catch (RuntimeException persistenceFailure) {
            balances.put(accountId, balanceBefore[0]);
            logWarning(
                "code="
                    + WITHDRAW_PERSISTENCE_FAILURE_CODE
                    + " account="
                    + accountId
                    + " op=withdraw"
                    + " txId="
                    + txSeq.incrementAndGet()
                    + " mode="
                    + (syncWrite ? "sync" : "async")
                    + " rollback=true",
                persistenceFailure);
            return false;
          }
        }
      }
      if (withdrawn.get() && publishEvent) {
        publishEvent(
            new EconomyEvent.Withdraw(
                accountId, amount, balanceAfter[0], System.currentTimeMillis()));
      }
      return withdrawn.get();
    }
  }

  public Map<UUID, BigDecimal> snapshot() {
    return Map.copyOf(balances);
  }

  @Override
  public Map<UUID, BigDecimal> getAllBalances() {
    return snapshot();
  }

  @Override
  public boolean hasAccount(UUID playerId) {
    if (playerId == null) {
      return false;
    }
    return balances.containsKey(playerId);
  }

  @Override
  public void createAccount(UUID playerId) {
    createAccount(playerId, true);
  }

  /**
   * 创建账户
   *
   * @param playerId 玩家ID
   * @param publishEvent 是否发布事件
   */
  public void createAccount(UUID playerId, boolean publishEvent) {
    if (playerId == null) {
      return;
    }
    synchronized (lockForAccount(playerId)) {
      long flushLockWaitStarted = System.nanoTime();
      synchronized (flushLock) {
        EconomyOperationTimingProbe.record(
            EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
            System.nanoTime() - flushLockWaitStarted);
        if (hasAccount(playerId)) {
          return;
        }
        balances.put(playerId, BigDecimal.ZERO);
        try {
          // Account creation is part of the synchronous EconomyService contract.
          flushAccount(playerId);
        } catch (RuntimeException persistenceFailure) {
          balances.remove(playerId);
          logWarning(
              "code="
                  + ACCOUNT_CREATE_PERSISTENCE_FAILURE_CODE
                  + " account="
                  + playerId
                  + " op=createAccount"
                  + " txId="
                  + txSeq.incrementAndGet()
                  + " rollback=true",
              persistenceFailure);
          return;
        }
      }

      if (publishEvent) {
        publishEvent(
            new EconomyEvent.AccountCreated(playerId, BigDecimal.ZERO, System.currentTimeMillis()));
      }
    }
  }

  @Override
  public boolean transfer(UUID from, UUID to, BigDecimal amount) {
    return transfer(from, to, amount, true);
  }

  /**
   * 转账 - 支持同步/异步持久化
   *
   * @param from 源账户
   * @param to 目标账户
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘（转账建议使用true防止数据丢失）
   * @return 是否成功
   */
  public boolean transfer(UUID from, UUID to, BigDecimal amount, boolean syncWrite) {
    return transfer(from, to, amount, syncWrite, true);
  }

  /**
   * 转账 - 完整参数版本
   *
   * @param from 源账户
   * @param to 目标账户
   * @param amount 金额
   * @param syncWrite 是否同步写入磁盘
   * @param publishEvent 是否发布事件
   * @return 是否成功
   */
  public boolean transfer(
      UUID from, UUID to, BigDecimal amount, boolean syncWrite, boolean publishEvent) {
    if (from == null || to == null) {
      return false;
    }
    // audit B-001/B-002: 原子化转账，避免先withdraw后deposit在中间崩溃造成凭空销毁玩家金钱；
    // 改为单次 compute 同时校验并扣减双方余额，保证 check-then-act 竞态不可达。
    // 注意：deposit 失败回滚由 compute 内部一致性保证；外部仅一次 flush。
    try {
      requirePositive(amount);
    } catch (IllegalArgumentException | NullPointerException validationFailure) {
      logWarning(
          "code="
              + TRANSFER_VALIDATION_FAILURE_CODE
              + " from="
              + from
              + " to="
              + to
              + " op=transfer"
              + " txId="
              + txSeq.incrementAndGet(),
          validationFailure);
      return false;
    }
    if (from.equals(to)) {
      return false;
    }

    // 扩展点拦截转账
    try {
      ExtensionRegistry registry = ExtensionRegistry.getInstance();
      EconomyTransactionExtensionPoint.TransactionContext ctx =
          new EconomyTransactionExtensionPoint.TransactionContext(
              from,
              to,
              amount,
              EconomyTransactionExtensionPoint.TransactionType.TRANSFER,
              balance(from),
              "transfer");
      EconomyTransactionExtensionPoint.TransactionResult extResult =
          registry.execute("economy_transaction", ctx);
      if (extResult != null && !extResult.approved()) {
        return false;
      }
    } catch (Exception e) {
      logWarning(
          "code="
              + TRANSFER_EXTENSION_FAILURE_CODE
              + " from="
              + from
              + " to="
              + to
              + " op=transfer"
              + " txId="
              + txSeq.incrementAndGet()
              + " continue=true"
              + " errorType="
              + e.getClass().getName(),
          e);
    }

    final BigDecimal normalized = normalize(amount);
    // Always acquire account locks in UUID order so opposite transfers cannot deadlock.
    final UUID firstId;
    final UUID secondId;
    if (from.compareTo(to) <= 0) {
      firstId = from;
      secondId = to;
    } else {
      firstId = to;
      secondId = from;
    }

    synchronized (lockForAccount(firstId)) {
      synchronized (lockForAccount(secondId)) {
        long flushLockWaitStarted = System.nanoTime();
        synchronized (flushLock) {
          EconomyOperationTimingProbe.record(
              EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
              System.nanoTime() - flushLockWaitStarted);
          BigDecimal fromBalance = balances.getOrDefault(from, BigDecimal.ZERO);
          BigDecimal toBalance = balances.getOrDefault(to, BigDecimal.ZERO);
          boolean fromHadAccount = balances.containsKey(from);
          boolean toHadAccount = balances.containsKey(to);
          if (fromBalance.compareTo(normalized) < 0) {
            return false;
          }
          balances.put(from, fromBalance.subtract(normalized));
          balances.put(to, toBalance.add(normalized));
          // Keep asynchronous snapshots from observing an uncommitted transfer or its rollback.
          try {
            flushAccounts(from, to);
          } catch (RuntimeException e) {
            restoreAccount(from, fromBalance, fromHadAccount);
            restoreAccount(to, toBalance, toHadAccount);
            logWarning(
                "code="
                    + TRANSFER_PERSISTENCE_FAILURE_CODE
                    + " from="
                    + from
                    + " to="
                    + to
                    + " op=transfer"
                    + " txId="
                    + txSeq.incrementAndGet()
                    + " rollback=true"
                    + " errorType="
                    + e.getClass().getName(),
                e);
            return false;
          }
        }
      }
    }

    // 发布转账事件
    if (publishEvent) {
      publishEvent(
          new EconomyEvent.Transfer(
              from, to, amount, balance(from), balance(to), System.currentTimeMillis()));
    }
    return true;
  }

  private void restoreAccount(UUID accountId, BigDecimal balance, boolean existed) {
    if (existed) {
      balances.put(accountId, balance);
    } else {
      balances.remove(accountId);
    }
  }

  public void flushNow() {
    // audit B-007: 加同步锁避免并发 flushNow/flushAsync 写入旧快照覆盖新快照导致回档
    long flushLockWaitStarted = System.nanoTime();
    synchronized (flushLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
          System.nanoTime() - flushLockWaitStarted);
      storage.save(toProperties(snapshot()));
    }
  }

  private void flushAccount(UUID accountId) {
    long flushLockWaitStarted = System.nanoTime();
    synchronized (flushLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
          System.nanoTime() - flushLockWaitStarted);
      BigDecimal currentBalance = balances.getOrDefault(accountId, BigDecimal.ZERO);
      if (!storage.saveAccount(accountId, normalize(currentBalance))) {
        storage.save(toProperties(snapshot()));
      }
    }
  }

  private void flushAccounts(UUID firstAccountId, UUID secondAccountId) {
    long flushLockWaitStarted = System.nanoTime();
    synchronized (flushLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
          System.nanoTime() - flushLockWaitStarted);
      Map<UUID, BigDecimal> accountBalances =
          Map.of(
              firstAccountId,
              normalize(balances.getOrDefault(firstAccountId, BigDecimal.ZERO)),
              secondAccountId,
              normalize(balances.getOrDefault(secondAccountId, BigDecimal.ZERO)));
      if (!storage.saveAccounts(accountBalances)) {
        storage.save(toProperties(snapshot()));
      }
    }
  }

  private void flushAsync() {
    // audit B-007: 加同步锁避免与 flushNow 互相覆盖
    long flushLockWaitStarted = System.nanoTime();
    synchronized (flushLock) {
      EconomyOperationTimingProbe.record(
          EconomyOperationTimingProbe.Phase.ECONOMY_FLUSH_LOCK_WAIT,
          System.nanoTime() - flushLockWaitStarted);
      storage.saveAsync(toProperties(snapshot()));
    }
  }

  private static Properties toProperties(Map<UUID, BigDecimal> balances) {
    Properties properties = new Properties();
    balances.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .forEach(
            entry -> {
              BigDecimal value = normalize(entry.getValue());
              // audit B-005/B-006: 持久化 0 余额账户，保证 hasAccount 重启后仍可识别账户存在性
              properties.setProperty(entry.getKey().toString(), value.toPlainString());
            });
    return properties;
  }

  private static BigDecimal normalize(BigDecimal amount) {
    // audit B-004: 对 deposit 已在入口拒绝 <0.01 的微额；这里保持 DOWN 截断到 2 位小数，与原精度语义一致
    return amount.setScale(SCALE, RoundingMode.DOWN);
  }

  private static void requirePositive(BigDecimal amount) {
    if (amount == null || amount.signum() <= 0) {
      throw new IllegalArgumentException("amount must be positive");
    }
  }

  // ==================== 日志辅助 ====================

  private void logWarning(String message) {
    if (logger != null) {
      logger.warning("[EconomyService] " + message);
    }
  }

  private void logWarning(String message, Throwable cause) {
    if (logger != null) {
      logger.log(Level.WARNING, "[EconomyService] " + message, cause);
    }
  }

  interface BalanceStorage {
    Properties load();

    void save(Properties properties);

    /** Persist one account directly when supported; return false to request a full snapshot. */
    default boolean saveAccount(UUID accountId, BigDecimal balance) {
      return false;
    }

    default boolean saveAccounts(Map<UUID, BigDecimal> accountBalances) {
      return false;
    }

    default void saveAsync(Properties properties) {
      save(properties);
    }
  }

  static final class PersistenceBalanceStorage implements BalanceStorage {
    private final PersistenceService persistenceService;

    PersistenceBalanceStorage(PersistenceService persistenceService) {
      this.persistenceService = Objects.requireNonNull(persistenceService, "persistenceService");
    }

    @Override
    public Properties load() {
      return persistenceService.loadProperties(NAMESPACE, FILE_NAME);
    }

    @Override
    public void save(Properties properties) {
      persistenceService.saveProperties(NAMESPACE, FILE_NAME, properties);
    }

    @Override
    public void saveAsync(Properties properties) {
      saveAsyncFuture(properties);
    }

    CompletableFuture<Void> saveAsyncFuture(Properties properties) {
      return persistenceService.savePropertiesAsync(NAMESPACE, FILE_NAME, properties);
    }
  }
}
