package dev.starcore.starcore.identity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 身份管理器 管理玩家身份、信任系统和代理令牌 */
public class IdentityManager {

  private final Map<String, PlayerIdentity> playerIdentities = new ConcurrentHashMap<>();
  private final Map<String, ProxyToken> proxyTokens = new ConcurrentHashMap<>();
  private final Map<String, Set<String>> playerProxyTokens = new ConcurrentHashMap<>();

  /** 注册玩家身份 */
  public void registerIdentity(PlayerIdentity identity) {
    playerIdentities.put(identity.playerId(), identity);
  }

  /** 卸载玩家身份 */
  public void unregisterIdentity(String playerId) {
    playerIdentities.remove(playerId);
    playerProxyTokens.remove(playerId);
  }

  /** 获取玩家身份 */
  public Optional<PlayerIdentity> getIdentity(String playerId) {
    return Optional.ofNullable(playerIdentities.get(playerId));
  }

  /** 获取所有玩家身份 */
  public Collection<PlayerIdentity> getAllIdentities() {
    return playerIdentities.values();
  }

  /** 更新玩家身份 */
  public void updateIdentity(PlayerIdentity identity) {
    playerIdentities.put(identity.playerId(), identity);
  }

  /** 获取指定状态的玩家 */
  public Set<String> getPlayersByStatus(IdentityStatus status) {
    Set<String> result = new HashSet<>();
    for (PlayerIdentity identity : playerIdentities.values()) {
      if (identity.status() == status) {
        result.add(identity.playerId());
      }
    }
    return result;
  }

  /** 获取信任值大于等于指定值的玩家 */
  public Set<String> getPlayersByTrust(double minTrust) {
    Set<String> result = new HashSet<>();
    for (PlayerIdentity identity : playerIdentities.values()) {
      if (identity.trustValue() >= minTrust) {
        result.add(identity.playerId());
      }
    }
    return result;
  }

  /** 创建代理令牌 */
  public ProxyToken createProxyToken(
      String tokenId, String grantorId, String granteeId, String scope) {
    ProxyToken token = ProxyToken.builder(tokenId, grantorId, granteeId).scope(scope).build();

    proxyTokens.put(tokenId, token);
    playerProxyTokens.computeIfAbsent(grantorId, k -> ConcurrentHashMap.newKeySet()).add(tokenId);
    playerProxyTokens.computeIfAbsent(granteeId, k -> ConcurrentHashMap.newKeySet()).add(tokenId);

    // 更新授予者的身份
    getIdentity(grantorId)
        .ifPresent(
            identity -> {
              Set<String> tokens = new HashSet<>(identity.proxyTokens());
              tokens.add(tokenId);
              updateIdentity(identity.withProxyToken(tokenId));
            });

    return token;
  }

  /** 获取代理令牌 */
  public Optional<ProxyToken> getProxyToken(String tokenId) {
    return Optional.ofNullable(proxyTokens.get(tokenId));
  }

  /** 获取玩家的所有代理令牌 */
  public Set<ProxyToken> getPlayerProxyTokens(String playerId) {
    Set<ProxyToken> result = new HashSet<>();
    Set<String> tokenIds = playerProxyTokens.getOrDefault(playerId, Set.of());
    for (String tokenId : tokenIds) {
      Optional.ofNullable(proxyTokens.get(tokenId)).ifPresent(result::add);
    }
    return result;
  }

  /** 检查玩家是否可以代理其他玩家 */
  public boolean canProxy(String proxyId, String targetId, String action) {
    // 检查代理令牌
    Set<ProxyToken> tokens = getPlayerProxyTokens(proxyId);
    for (ProxyToken token : tokens) {
      if (token.granteeId().equals(proxyId)
          && token.grantorId().equals(targetId)
          && token.isValid()
          && token.isInScope(action)) {
        return true;
      }
    }
    return false;
  }

  /** 取消代理令牌 */
  public void revokeProxyToken(String tokenId) {
    ProxyToken token = proxyTokens.remove(tokenId);
    if (token != null) {
      playerProxyTokens.getOrDefault(token.grantorId(), Set.of()).remove(tokenId);
      playerProxyTokens.getOrDefault(token.granteeId(), Set.of()).remove(tokenId);

      // 更新相关玩家的身份
      getIdentity(token.grantorId())
          .ifPresent(
              identity -> {
                Set<String> tokens = new HashSet<>(identity.proxyTokens());
                tokens.remove(tokenId);
                PlayerIdentity newIdentity =
                    new PlayerIdentity(
                        identity.playerId(),
                        identity.playerName(),
                        identity.status(),
                        identity.trustValue(),
                        identity.unlockedNodes(),
                        identity.nodeProgress(),
                        identity.witnessedEvents(),
                        tokens,
                        System.currentTimeMillis(),
                        identity.isVerified(),
                        identity.metadata());
                updateIdentity(newIdentity);
              });
    }
  }

  /** 增加玩家信任值 */
  public void addTrust(String playerId, double amount) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              updateIdentity(identity.withAddedTrust(amount));
            });
  }

  /** 设置玩家信任值 */
  public void setTrust(String playerId, double trustValue) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              PlayerIdentity newIdentity =
                  new PlayerIdentity(
                      identity.playerId(),
                      identity.playerName(),
                      identity.status(),
                      Math.max(0, trustValue),
                      identity.unlockedNodes(),
                      identity.nodeProgress(),
                      identity.witnessedEvents(),
                      identity.proxyTokens(),
                      System.currentTimeMillis(),
                      identity.isVerified(),
                      identity.metadata());
              updateIdentity(newIdentity);
            });
  }

  /** 更新玩家身份状态 */
  public void setIdentityStatus(String playerId, IdentityStatus status) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              updateIdentity(identity.withStatus(status));
            });
  }

  /** 解锁玩家节点 */
  public void unlockNode(String playerId, String nodeId) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              if (!identity.hasNodeUnlocked(nodeId)) {
                updateIdentity(identity.withNode(nodeId));
              }
            });
  }

  /** 记录玩家见证的事件 */
  public void recordWitnessedEvent(String playerId, String eventId) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              if (!identity.hasWitnessedEvent(eventId)) {
                updateIdentity(identity.withWitnessedEvent(eventId));
              }
            });
  }

  /** 更新玩家节点进度 */
  public void updateNodeProgress(String playerId, String nodeId, long progress) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              updateIdentity(identity.withNodeProgress(nodeId, progress));
            });
  }

  /** 验证玩家身份 */
  public void verifyIdentity(String playerId) {
    getIdentity(playerId)
        .ifPresent(
            identity -> {
              PlayerIdentity newIdentity =
                  new PlayerIdentity(
                      identity.playerId(),
                      identity.playerName(),
                      identity.status(),
                      identity.trustValue(),
                      identity.unlockedNodes(),
                      identity.nodeProgress(),
                      identity.witnessedEvents(),
                      identity.proxyTokens(),
                      System.currentTimeMillis(),
                      true,
                      identity.metadata());
              updateIdentity(newIdentity);
            });
  }

  /** 检查玩家是否已验证 */
  public boolean isVerified(String playerId) {
    return getIdentity(playerId).map(PlayerIdentity::isVerified).orElse(false);
  }

  /** 检查玩家是否解锁了指定节点 */
  public boolean hasNodeUnlocked(String playerId, String nodeId) {
    return getIdentity(playerId).map(identity -> identity.hasNodeUnlocked(nodeId)).orElse(false);
  }

  /** 检查玩家是否见证了指定事件 */
  public boolean hasWitnessedEvent(String playerId, String eventId) {
    return getIdentity(playerId).map(identity -> identity.hasWitnessedEvent(eventId)).orElse(false);
  }

  /** 获取玩家的信任值 */
  public double getTrustValue(String playerId) {
    return getIdentity(playerId).map(PlayerIdentity::trustValue).orElse(0.0);
  }

  /** 获取玩家的身份状态 */
  public IdentityStatus getIdentityStatus(String playerId) {
    return getIdentity(playerId).map(PlayerIdentity::status).orElse(IdentityStatus.awakened);
  }

  /** 清理玩家数据 */
  public void clearPlayerData(String playerId) {
    playerIdentities.remove(playerId);
    playerProxyTokens.remove(playerId);
  }

  /** 清理所有身份数据 */
  public void clear() {
    playerIdentities.clear();
    proxyTokens.clear();
    playerProxyTokens.clear();
  }

  /** 获取统计信息 */
  public Map<IdentityStatus, Integer> getStatusStatistics() {
    Map<IdentityStatus, Integer> stats = new EnumMap<>(IdentityStatus.class);
    for (IdentityStatus status : IdentityStatus.values()) {
      stats.put(status, 0);
    }

    for (PlayerIdentity identity : playerIdentities.values()) {
      stats.merge(identity.status(), 1, Integer::sum);
    }

    return stats;
  }

  /** 获取总玩家数量 */
  public int getTotalPlayers() {
    return playerIdentities.size();
  }

  /** 获取活跃代理令牌数量 */
  public int getActiveProxyTokens() {
    return (int) proxyTokens.values().stream().filter(ProxyToken::isValid).count();
  }
}
