package dev.starcore.starcore.foundation.animation;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** 动画播放器 - SSS级用户体验 提供各种炫酷的动画效果和过渡 */
public final class AnimationPlayer {
  private final AnimationTaskTracker tasks;

  public AnimationPlayer(Plugin plugin) {
    this.tasks = new AnimationTaskTracker(plugin);
  }

  /** 播放进度动画 */
  public void playProgressAnimation(
      Player player, String message, int durationSeconds, Runnable onComplete) {
    tasks.execute(
        player, () -> playProgressAnimationOwned(player, message, durationSeconds, onComplete));
  }

  private void playProgressAnimationOwned(
      Player player, String message, int durationSeconds, Runnable onComplete) {
    AtomicInteger countdown = new AtomicInteger(durationSeconds);
    tasks.runTaskTimer(
        player,
        task -> {
          int remaining = countdown.getAndDecrement();

          if (remaining <= 0) {
            task.cancel();
            onComplete.run();
            return;
          }

          // 显示进度条
          String progressBar =
              createProgressBar((durationSeconds - remaining), durationSeconds, 20);

          player.sendActionBar(
              Component.text(
                  message + " " + progressBar + " " + remaining + "s", NamedTextColor.YELLOW));
        },
        0L,
        20L);
  }

  /** 播放成功动画 */
  public void playSuccessAnimation(Player player, String message) {
    tasks.execute(player, () -> playSuccessAnimationOwned(player, message));
  }

  private void playSuccessAnimationOwned(Player player, String message) {
    if (tasks.isClosed()) return;
    // Title 动画
    player.showTitle(
        Title.title(
            Component.text("✓", NamedTextColor.GREEN).decorate(TextDecoration.BOLD),
            Component.text(message, NamedTextColor.GREEN),
            Title.Times.times(
                Duration.ofMillis(500), Duration.ofSeconds(2), Duration.ofMillis(500))));

    // 粒子效果
    Location loc = player.getLocation().add(0, 1, 0);
    player.spawnParticle(
        org.bukkit.Particle.HAPPY_VILLAGER, // Updated from VILLAGER_HAPPY
        loc,
        30,
        0.5,
        0.5,
        0.5,
        0.1);

    // 音效
    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
  }

  /** 播放失败动画 */
  public void playFailureAnimation(Player player, String message) {
    tasks.execute(player, () -> playFailureAnimationOwned(player, message));
  }

  private void playFailureAnimationOwned(Player player, String message) {
    if (tasks.isClosed()) return;
    // Title 动画
    player.showTitle(
        Title.title(
            Component.text("✗", NamedTextColor.RED).decorate(TextDecoration.BOLD),
            Component.text(message, NamedTextColor.RED),
            Title.Times.times(
                Duration.ofMillis(500), Duration.ofSeconds(2), Duration.ofMillis(500))));

    // 粒子效果
    Location loc = player.getLocation().add(0, 1, 0);
    player.spawnParticle(
        org.bukkit.Particle.LARGE_SMOKE, // Updated from SMOKE_LARGE
        loc,
        20,
        0.3,
        0.3,
        0.3,
        0.05);

    // 音效
    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 0.8f);
  }

  /** 播放传送动画 */
  public void playTeleportAnimation(Player player, Location from, Location to) {
    Location origin = from.clone();
    Location destination = to.clone();
    tasks.execute(player, () -> playTeleportAnimationOwned(player, origin, destination));
  }

  private void playTeleportAnimationOwned(Player player, Location from, Location to) {
    if (tasks.isClosed()) return;
    // 起点粒子
    player.spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 50, 0.5, 1.0, 0.5, 0.5);

    // 传送音效
    player.playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);

    // 延迟显示终点粒子
    tasks.runTaskLater(
        player,
        () -> {
          player.spawnParticle(Particle.PORTAL, to.clone().add(0, 1, 0), 50, 0.5, 1.0, 0.5, 0.5);

          player.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
        },
        2L);
  }

  /** 播放战斗动画 */
  public void playBattleAnimation(Location location) {
    tasks.atLocation(location, this::playBattleAnimationOwned);
  }

  private void playBattleAnimationOwned(Location location) {
    if (tasks.isClosed()) return;
    // 爆炸粒子
    location
        .getWorld()
        .spawnParticle(
            org.bukkit.Particle.EXPLOSION, // Updated from EXPLOSION_LARGE
            location,
            3,
            1.0,
            0.5,
            1.0,
            0);

    // 火焰粒子
    location.getWorld().spawnParticle(Particle.FLAME, location, 30, 1.0, 0.5, 1.0, 0.1);

    // 战斗音效
    location.getWorld().playSound(location, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
  }

  /** 播放国策激活动画 */
  public void playPolicyActivationAnimation(Player player, String policyName) {
    tasks.execute(player, () -> playPolicyActivationAnimationOwned(player, policyName));
  }

  private void playPolicyActivationAnimationOwned(Player player, String policyName) {
    if (tasks.isClosed()) return;
    // 华丽的 Title
    player.showTitle(
        Title.title(
            Component.text("⚡ 国策激活 ⚡", NamedTextColor.GOLD).decorate(TextDecoration.BOLD),
            Component.text(policyName, NamedTextColor.YELLOW),
            Title.Times.times(
                Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))));

    // 发光粒子
    Location loc = player.getLocation().add(0, 2, 0);
    player.spawnParticle(
        org.bukkit.Particle.TOTEM_OF_UNDYING, // Updated from TOTEM
        loc,
        50,
        0.5,
        0.5,
        0.5,
        0.2);

    // 激活音效
    player.playSound(player.getLocation(), Sound.BLOCK_BELL_USE, 1.0f, 1.5f);
  }

  /** 创建进度条 */
  private String createProgressBar(int current, int max, int length) {
    int filled = (int) ((double) current / max * length);
    StringBuilder bar = new StringBuilder("[");

    for (int i = 0; i < length; i++) {
      if (i < filled) {
        bar.append("█");
      } else {
        bar.append("░");
      }
    }

    bar.append("]");
    return bar.toString();
  }

  /** 播放数字滚动动画 */
  public void playNumberCountAnimation(
      Player player, int from, int to, Duration duration, String prefix) {
    tasks.execute(player, () -> playNumberCountAnimationOwned(player, from, to, duration, prefix));
  }

  private void playNumberCountAnimationOwned(
      Player player, int from, int to, Duration duration, String prefix) {
    if (tasks.isClosed()) return;
    long durationMillis = Math.max(0L, duration.toMillis());
    if (durationMillis == 0L || from == to) {
      player.sendActionBar(Component.text(prefix + to, NamedTextColor.GOLD));
      return;
    }
    long steps = durationMillis / 50L + (durationMillis % 50L == 0L ? 0L : 1L);
    AtomicLong currentStep = new AtomicLong();

    tasks.runTaskTimer(
        player,
        task -> {
          long step = Math.min(steps, currentStep.incrementAndGet());
          if (step >= steps) {
            task.cancel();
            player.sendActionBar(Component.text(prefix + to, NamedTextColor.GOLD));
            return;
          }

          int value = (int) Math.round(from + ((double) to - from) * ((double) step / steps));
          player.sendActionBar(Component.text(prefix + value, NamedTextColor.YELLOW));
        },
        0L,
        1L);
  }

  /** Cancels delayed and repeating animations owned by this player. */
  public void shutdown() {
    tasks.shutdown();
  }
}
