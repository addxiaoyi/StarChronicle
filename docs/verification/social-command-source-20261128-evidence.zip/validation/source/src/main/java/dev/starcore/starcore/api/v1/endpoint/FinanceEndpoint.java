package dev.starcore.starcore.api.v1.endpoint;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.PageRequest;
import dev.starcore.starcore.api.v1.PageResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.dto.TreasuryDto;
import dev.starcore.starcore.api.v1.handler.BaseHttpHandler;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class FinanceEndpoint extends BaseHttpHandler {
    private static final String PATH = "/api/v1/finance";

    private final NationService nationService;
    private final TreasuryService treasuryService;

    public FinanceEndpoint(
        Gson gson,
        ApiAuthService authService,
        NationService nationService,
        TreasuryService treasuryService,
        RestApiConfig.CorsConfig corsConfig,
        boolean requiresAuth
    ) {
        super(
            gson,
            authService,
            corsConfig,
            requiresAuth,
            ApiAuthService.ApiKeyPermission.READ_FINANCE
        );
        this.nationService = nationService;
        this.treasuryService = treasuryService;
    }

    @Override
    protected void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
        throws IOException {
        if (treasuryService == null) {
            sendError(
                exchange,
                503,
                "SERVICE_UNAVAILABLE",
                "Treasury service is unavailable"
            );
            return;
        }
        if (!isMethod(exchange, "GET")) {
            sendMethodNotAllowed(exchange);
            return;
        }

        String path = getPath(exchange);
        if (PATH.equals(path)) {
            listFinances(exchange);
            return;
        }
        if (path.startsWith(PATH + "/")) {
            financeByNation(exchange, path.substring((PATH + "/").length()));
            return;
        }
        sendNotFound(exchange, "Endpoint");
    }

    private void listFinances(HttpExchange exchange) throws IOException {
        Map<String, String> params = parseQueryParams(exchange);
        PageRequest page = PageRequest.of(params.get("page"), params.get("pageSize"));
        List<Nation> nations = nationService == null
            ? List.of()
            : new ArrayList<>(nationService.nations());
        int from = (int) Math.min(page.offset(), nations.size());
        int to = (int) Math.min(page.offset() + page.pageSize(), nations.size());
        List<TreasuryDto> entries = from < to
            ? nations.subList(from, to).stream().map(this::toDto).toList()
            : List.of();

        sendSuccess(
            exchange,
            PageResponse.of(entries, page.page(), page.pageSize(), nations.size()),
            ApiResponse.ResponseMeta.of(
                page.page(), page.pageSize(), nations.size(), generateRequestId())
        );
    }

    private void financeByNation(HttpExchange exchange, String id) throws IOException {
        if (id.isBlank() || id.contains("/")) {
            sendNotFound(exchange, "Nation finance");
            return;
        }
        NationId nationId;
        try {
            nationId = NationId.of(UUID.fromString(id));
        } catch (IllegalArgumentException exception) {
            sendError(exchange, 400, "INVALID_ID", "Invalid nation ID format");
            return;
        }
        Optional<Nation> nation = nationService == null
            ? Optional.empty()
            : nationService.nationById(nationId);
        if (nation.isEmpty()) {
            sendNotFound(exchange, "Nation finance");
            return;
        }
        sendSuccess(exchange, toDto(nation.get()));
    }

    private TreasuryDto toDto(Nation nation) {
        return new TreasuryDto(
            nation.id().toString(),
            nation.name(),
            treasuryService.balance(nation.id()),
            System.currentTimeMillis(),
            List.of()
        );
    }
}
