package dev.starcore.starcore.api.v1.endpoint;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import dev.starcore.starcore.api.v1.ApiResponse;
import dev.starcore.starcore.api.v1.PageRequest;
import dev.starcore.starcore.api.v1.PageResponse;
import dev.starcore.starcore.api.v1.auth.ApiAuthContext;
import dev.starcore.starcore.api.v1.auth.ApiAuthService;
import dev.starcore.starcore.api.v1.config.RestApiConfig;
import dev.starcore.starcore.api.v1.dto.WarDto;
import dev.starcore.starcore.api.v1.handler.BaseHttpHandler;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.war.WarService;
import dev.starcore.starcore.war.War;
import dev.starcore.starcore.war.WarServiceImpl;
import dev.starcore.starcore.war.WarStatus;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/** 战争 REST API 端点 */
public final class WarsEndpoint extends BaseHttpHandler {

  private final WarService warService;
  private final WarServiceImpl warServiceImpl;
  private final NationService nationService;

  public WarsEndpoint(
      Gson gson,
      ApiAuthService authService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      NationService nationService,
      RestApiConfig.CorsConfig corsConfig,
      boolean requiresAuth) {
    super(
        gson, authService, corsConfig, requiresAuth, ApiAuthService.ApiKeyPermission.READ_NATIONS);
    this.warService = warService;
    this.warServiceImpl = warServiceImpl;
    this.nationService = nationService;
  }

  public WarsEndpoint(
      Gson gson,
      ApiAuthService authService,
      WarService warService,
      WarServiceImpl warServiceImpl,
      NationService nationService) {
    this(
        gson,
        authService,
        warService,
        warServiceImpl,
        nationService,
        RestApiConfig.CorsConfig.DEFAULT,
        false);
  }

  @Override
  protected void handleRequest(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    String path = getPath(exchange);

    if (path.equals("/api/v1/wars")) {
      if (isMethod(exchange, "GET")) {
        handleListWars(exchange, authContext);
      } else {
        sendMethodNotAllowed(exchange);
      }
    } else if (path.startsWith("/api/v1/wars/")) {
      String idPart = path.substring("/api/v1/wars/".length());
      if (idPart.isEmpty() || idPart.endsWith("/")) {
        sendNotFound(exchange, "War");
      } else {
        handleWarById(exchange, authContext, idPart.split("/")[0]);
      }
    } else {
      sendNotFound(exchange, "Endpoint");
    }
  }

  private void handleListWars(HttpExchange exchange, ApiAuthContext authContext)
      throws IOException {
    Map<String, String> params = parseQueryParams(exchange);
    PageRequest pageRequest = PageRequest.of(params.get("page"), params.get("pageSize"));

    List<dev.starcore.starcore.war.War> allWars = new ArrayList<>();
    if (warService != null) {
      allWars.addAll(
          warService.allWars().stream()
              .map(s -> warServiceImpl != null ? warServiceImpl.getWar(s.id()).orElse(null) : null)
              .filter(Objects::nonNull)
              .toList());
    }

    // 也添加已结束的历史战争
    List<War> allWarsWithHistory = new ArrayList<>(allWars);

    long total = allWarsWithHistory.size();

    int fromIndex = (int) Math.min(pageRequest.offset(), allWarsWithHistory.size());
    int toIndex =
        (int) Math.min(pageRequest.offset() + pageRequest.pageSize(), allWarsWithHistory.size());
    List<War> pageWars =
        fromIndex < toIndex ? allWarsWithHistory.subList(fromIndex, toIndex) : List.of();

    List<WarDto> dtos = pageWars.stream().map(this::toWarDto).collect(Collectors.toList());

    PageResponse<WarDto> response =
        PageResponse.of(dtos, pageRequest.page(), pageRequest.pageSize(), total);

    sendSuccess(
        exchange,
        response,
        ApiResponse.ResponseMeta.of(
            pageRequest.page(), pageRequest.pageSize(), total, generateRequestId()));
  }

  private void handleWarById(HttpExchange exchange, ApiAuthContext authContext, String id)
      throws IOException {
    if (!isMethod(exchange, "GET")) {
      sendMethodNotAllowed(exchange);
      return;
    }

    UUID uuid;
    try {
      uuid = UUID.fromString(id);
    } catch (IllegalArgumentException e) {
      sendError(exchange, 400, "INVALID_ID", "Invalid war ID format");
      return;
    }

    Optional<War> warOpt =
        warService != null && warServiceImpl != null ? warService.getWar(uuid) : Optional.empty();

    if (warOpt.isEmpty()) {
      sendNotFound(exchange, "War");
      return;
    }

    WarDto dto = toWarDto(warOpt.get());
    sendSuccess(exchange, dto);
  }

  private WarDto toWarDto(War war) {
    String attackerName = getNationName(war.aggressor());
    String defenderName = getNationName(war.defender());
    String status = war.status() != null ? war.status().name() : WarStatus.PREPARATION.name();
    String winner = determineWinner(war);

    return new WarDto(
        war.id().toString(),
        war.aggressor().toString(),
        attackerName,
        war.defender().toString(),
        defenderName,
        status,
        war.declaredAt() != null ? war.declaredAt().toEpochMilli() : 0L,
        war.endedAt() != null ? war.endedAt().toEpochMilli() : 0L,
        calculatePreparationEndsAt(war),
        null,
        winner,
        war.aggressorWarScore(),
        war.defenderWarScore(),
        0.0,
        getAllyParticipants(war));
  }

  private String determineWinner(War war) {
    if (!war.isEnded()) {
      return null;
    }
    if (war.aggressorWarScore() > war.defenderWarScore()) {
      return war.aggressor().toString();
    } else if (war.defenderWarScore() > war.aggressorWarScore()) {
      return war.defender().toString();
    }
    return "DRAW";
  }

  private long calculatePreparationEndsAt(War war) {
    if (war.status() == WarStatus.PREPARATION && war.declaredAt() != null) {
      return war.declaredAt().toEpochMilli() + 86400000L;
    }
    return 0L;
  }

  private List<String> getAllyParticipants(War war) {
    List<String> allies = new ArrayList<>();
    allies.addAll(war.aggressorAllies().stream().map(Object::toString).toList());
    allies.addAll(war.defenderAllies().stream().map(Object::toString).toList());
    return allies;
  }

  private String getNationName(NationId nationId) {
    if (nationService == null || nationId == null) {
      return "Unknown";
    }
    return nationService.nationById(nationId).map(nation -> nation.name()).orElse("Unknown");
  }
}
