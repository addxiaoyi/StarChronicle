package dev.starcore.starcore.identity;

import java.util.*;

/** 玩家身份模型 表示玩家在十二节点观测体系中的身份状态 */
public record PlayerIdentity(
    String playerId, // 玩家ID
    String playerName, // 玩家名称
    IdentityStatus status, // 身份状态
    double trustValue, // 信任值
    Set<String> unlockedNodes, // 已解锁的节点
    Map<String, Long> nodeProgress, // 节点进度
    Set<String> witnessedEvents, // 目击的事件
    Set<String> proxyTokens, // 代理令牌集合
    long lastUpdateTime, // 最后更新时间
    boolean isVerified, // 是否已验证
    Map<String, Object> metadata // 元数据
    ) {

  /** 创建玩家身份构建器 */
  public static Builder builder(String playerId, String playerName) {
    return new Builder(playerId, playerName);
  }

  /** 检查玩家是否解锁了指定节点 */
  public boolean hasNodeUnlocked(String nodeId) {
    return unlockedNodes.contains(nodeId);
  }

  /** 检查玩家是否拥有代理令牌 */
  public boolean hasProxyToken(String tokenId) {
    return proxyTokens.contains(tokenId);
  }

  /** 检查玩家是否见证了指定事件 */
  public boolean hasWitnessedEvent(String eventId) {
    return witnessedEvents.contains(eventId);
  }

  /** 更新身份状态 */
  public PlayerIdentity withStatus(IdentityStatus newStatus) {
    return new PlayerIdentity(
        playerId,
        playerName,
        newStatus,
        trustValue,
        unlockedNodes,
        nodeProgress,
        witnessedEvents,
        proxyTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 添加解锁的节点 */
  public PlayerIdentity withNode(String nodeId) {
    Set<String> newNodes = new HashSet<>(unlockedNodes);
    newNodes.add(nodeId);
    return new PlayerIdentity(
        playerId,
        playerName,
        status,
        trustValue,
        newNodes,
        nodeProgress,
        witnessedEvents,
        proxyTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 添加代理令牌 */
  public PlayerIdentity withProxyToken(String tokenId) {
    Set<String> newTokens = new HashSet<>(proxyTokens);
    newTokens.add(tokenId);
    return new PlayerIdentity(
        playerId,
        playerName,
        status,
        trustValue,
        unlockedNodes,
        nodeProgress,
        witnessedEvents,
        newTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 添加见证事件 */
  public PlayerIdentity withWitnessedEvent(String eventId) {
    Set<String> newEvents = new HashSet<>(witnessedEvents);
    newEvents.add(eventId);
    return new PlayerIdentity(
        playerId,
        playerName,
        status,
        trustValue,
        unlockedNodes,
        nodeProgress,
        newEvents,
        proxyTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 增加信任值 */
  public PlayerIdentity withAddedTrust(double amount) {
    return new PlayerIdentity(
        playerId,
        playerName,
        status,
        Math.max(0, trustValue + amount),
        unlockedNodes,
        nodeProgress,
        witnessedEvents,
        proxyTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 更新节点进度 */
  public PlayerIdentity withNodeProgress(String nodeId, long progress) {
    Map<String, Long> newNodeProgress = new HashMap<>(nodeProgress);
    newNodeProgress.put(nodeId, progress);
    return new PlayerIdentity(
        playerId,
        playerName,
        status,
        trustValue,
        unlockedNodes,
        newNodeProgress,
        witnessedEvents,
        proxyTokens,
        System.currentTimeMillis(),
        isVerified,
        metadata);
  }

  /** 玩家身份构建器 */
  public static class Builder {
    private final String playerId;
    private final String playerName;
    private IdentityStatus status = IdentityStatus.awakened;
    private double trustValue = 0.0;
    private Set<String> unlockedNodes = new HashSet<>();
    private Map<String, Long> nodeProgress = new HashMap<>();
    private Set<String> witnessedEvents = new HashSet<>();
    private Set<String> proxyTokens = new HashSet<>();
    private long lastUpdateTime = System.currentTimeMillis();
    private boolean isVerified = false;
    private Map<String, Object> metadata = new HashMap<>();

    private Builder(String playerId, String playerName) {
      this.playerId = Objects.requireNonNull(playerId);
      this.playerName = Objects.requireNonNull(playerName);
    }

    public Builder status(IdentityStatus status) {
      this.status = status;
      return this;
    }

    public Builder trustValue(double trustValue) {
      this.trustValue = Math.max(0, trustValue);
      return this;
    }

    public Builder addUnlockedNode(String nodeId) {
      this.unlockedNodes.add(nodeId);
      return this;
    }

    public Builder unlockedNodes(Set<String> nodes) {
      this.unlockedNodes = new HashSet<>(nodes);
      return this;
    }

    public Builder nodeProgress(String nodeId, long progress) {
      this.nodeProgress.put(nodeId, progress);
      return this;
    }

    public Builder addWitnessedEvent(String eventId) {
      this.witnessedEvents.add(eventId);
      return this;
    }

    public Builder witnessEvents(Set<String> events) {
      this.witnessedEvents = new HashSet<>(events);
      return this;
    }

    public Builder addProxyToken(String tokenId) {
      this.proxyTokens.add(tokenId);
      return this;
    }

    public Builder proxyTokens(Set<String> tokens) {
      this.proxyTokens = new HashSet<>(tokens);
      return this;
    }

    public Builder lastUpdateTime(long lastUpdateTime) {
      this.lastUpdateTime = lastUpdateTime;
      return this;
    }

    public Builder verified(boolean verified) {
      this.isVerified = verified;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public PlayerIdentity build() {
      return new PlayerIdentity(
          playerId,
          playerName,
          status,
          trustValue,
          Set.copyOf(unlockedNodes),
          Map.copyOf(nodeProgress),
          Set.copyOf(witnessedEvents),
          Set.copyOf(proxyTokens),
          lastUpdateTime,
          isVerified,
          Map.copyOf(metadata));
    }
  }
}
