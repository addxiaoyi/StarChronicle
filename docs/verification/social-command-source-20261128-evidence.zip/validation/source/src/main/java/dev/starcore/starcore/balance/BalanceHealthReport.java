package dev.starcore.starcore.balance;

import java.util.List;
import java.util.Objects;

public record BalanceHealthReport(BalanceSnapshot snapshot, List<BalanceFinding> findings) {
  public BalanceHealthReport {
    snapshot = Objects.requireNonNull(snapshot, "snapshot");
    findings = List.copyOf(findings);
  }

  public long highCount() {
    return findings.stream().filter(finding -> finding.severity() == BalanceSeverity.HIGH).count();
  }

  public long warningCount() {
    return findings.stream()
        .filter(finding -> finding.severity() == BalanceSeverity.WARNING)
        .count();
  }
}
