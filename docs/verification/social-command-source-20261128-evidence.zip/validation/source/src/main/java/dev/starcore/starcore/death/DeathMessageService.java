package dev.starcore.starcore.death;

import dev.starcore.starcore.foundation.util.RandomProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public final class DeathMessageService {

  private static final String CONFIG_NAME = "death-messages.yml";
  private static final String FALLBACK_TEMPLATE = "&7%player% &8· &7%cause%";
  private static final LegacyComponentSerializer LEGACY =
      LegacyComponentSerializer.legacyAmpersand();

  private final JavaPlugin plugin;
  private final Logger logger;
  private final File configFile;
  private final Map<DeathCause, DeathCauseConfig> causeConfigs = new ConcurrentHashMap<>();
  private final Map<String, String> causeNames = new ConcurrentHashMap<>();
  private final Set<String> warnedTypes = ConcurrentHashMap.newKeySet();
  private final Map<java.util.UUID, DeathCause> pendingCauses = new ConcurrentHashMap<>();

  private boolean enabled = true;
  private boolean broadcastEnabled = true;
  private String broadcastPrefix = "§6[死亡] §r";
  private String unknownKillerText = "未知来源";
  private String unknownAmountText = "1";

  public DeathMessageService() {
    this(null, null);
  }

  public DeathMessageService(JavaPlugin plugin) {
    this(plugin, plugin == null ? null : new File(plugin.getDataFolder(), CONFIG_NAME));
  }

  private DeathMessageService(JavaPlugin plugin, File configFile) {
    this.plugin = plugin;
    this.logger =
        plugin == null ? Logger.getLogger(DeathMessageService.class.getName()) : plugin.getLogger();
    this.configFile = configFile;
    if (configFile != null && !configFile.exists() && plugin != null) {
      plugin.saveResource(CONFIG_NAME, false);
    }
    loadConfig();
  }

  public void loadConfig() {
    causeNames.clear();
    causeConfigs.clear();

    if (configFile == null) {
      loadBuiltInDefaults();
      return;
    }

    YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
    this.enabled = config.getBoolean("enabled", true);
    this.broadcastEnabled = config.getBoolean("settings.broadcast", true);
    this.broadcastPrefix = config.getString("settings.broadcast-prefix", "§6[死亡] §r");
    this.unknownKillerText = config.getString("unknowns.killer", "未知来源");
    this.unknownAmountText = config.getString("unknowns.amount", "1");

    ConfigurationSection names = config.getConfigurationSection("cause-names");
    if (names != null) {
      for (String key : names.getKeys(false)) {
        String value = names.getString(key);
        if (value != null && !value.isBlank()) {
          causeNames.put(normalizeKey(key), value);
        }
      }
    }

    ConfigurationSection causes = config.getConfigurationSection("causes");
    if (causes == null) {
      log("death-messages.yml 缺少 causes 节点，已回退到 default 与内置文案", Level.WARNING);
      loadBuiltInDefaults();
      return;
    }

    DeathCauseConfig fallback = null;
    for (String key : causes.getKeys(false)) {
      ConfigurationSection section = causes.getConfigurationSection(key);
      if (section == null) {
        continue;
      }
      DeathCause cause = DeathCause.byConfigKey(key);
      if (cause == null) {
        log("未知的死亡类型 '" + key + "'，已忽略该配置节", Level.WARNING);
        continue;
      }
      DeathCauseConfig parsed = parseConfig(section);
      if (cause == DeathCause.DEFAULT) {
        fallback = parsed;
      }
      causeConfigs.put(cause, parsed);
    }

    if (fallback == null) {
      log("death-messages.yml 未定义 default 配置节，缺失类型将使用内置文案", Level.WARNING);
    }
    fillMissingCauses(fallback);
    log("死亡消息配置已加载，支持 " + causeConfigs.size() + " 种类型", Level.INFO);
  }

  private DeathCauseConfig parseConfig(ConfigurationSection section) {
    List<String> messages = section.getStringList("messages");
    if (messages.isEmpty()) {
      messages = List.of(FALLBACK_TEMPLATE);
    }
    return new DeathCauseConfig(
        section.getBoolean("broadcast", true),
        section.getBoolean("show-location", false),
        section.getBoolean("show-item", false),
        section.getBoolean("death-screen", true),
        List.copyOf(messages));
  }

  private void fillMissingCauses(DeathCauseConfig fallback) {
    for (DeathCause cause : DeathCause.values()) {
      if (causeConfigs.containsKey(cause)) {
        continue;
      }
      causeConfigs.put(
          cause,
          fallback != null
              ? fallback
              : new DeathCauseConfig(true, false, false, true, List.of(FALLBACK_TEMPLATE)));
    }
  }

  private void loadBuiltInDefaults() {
    for (DeathCause cause : DeathCause.values()) {
      causeConfigs.put(
          cause,
          new DeathCauseConfig(
              true, false, false, true, List.of("&7%player% &8· &7" + builtinCauseName(cause))));
    }
  }

  private String builtinCauseName(DeathCause cause) {
    return cause == DeathCause.DEFAULT ? "不明原因" : cause.configKey;
  }

  public boolean reload() {
    try {
      warnedTypes.clear();
      loadConfig();
      return true;
    } catch (RuntimeException e) {
      log("重载死亡消息配置失败：" + e.getMessage(), Level.SEVERE);
      return false;
    }
  }

  public void addMessage(DeathCause cause, String message) {
    if (cause == null || message == null || message.isBlank()) {
      return;
    }
    DeathCauseConfig current = causeConfigs.get(cause);
    List<String> merged = new ArrayList<>(current == null ? List.of() : current.messages());
    merged.add(message);
    causeConfigs.put(cause, withMessages(current, merged));
  }

  public void addMessages(DeathCause cause, List<String> messages) {
    if (cause == null || messages == null) {
      return;
    }
    causeConfigs.put(cause, withMessages(causeConfigs.get(cause), new ArrayList<>(messages)));
  }

  public void loadFromConfig(Map<String, List<String>> rawMessages) {
    Map<DeathCause, List<String>> parsed = new EnumMap<>(DeathCause.class);
    if (rawMessages != null) {
      rawMessages.forEach(
          (key, messages) -> {
            DeathCause cause = DeathCause.byConfigKey(key);
            if (cause == null) {
              log("未知的死亡类型 '" + key + "'，已忽略", Level.WARNING);
              return;
            }
            if (messages != null && !messages.isEmpty()) {
              parsed.put(cause, List.copyOf(messages));
            }
          });
    }
    for (DeathCause cause : DeathCause.values()) {
      DeathCauseConfig current = causeConfigs.get(cause);
      DeathCauseConfig updated = withMessages(current, parsed.get(cause));
      causeConfigs.put(cause, updated);
    }
  }

  private DeathCauseConfig withMessages(DeathCauseConfig base, List<String> messages) {
    List<String> safe =
        messages == null || messages.isEmpty() ? List.of(FALLBACK_TEMPLATE) : List.copyOf(messages);
    if (base == null) {
      return new DeathCauseConfig(true, false, false, true, safe);
    }
    return new DeathCauseConfig(
        base.broadcast(), base.showLocation(), base.showItem(), base.deathScreen(), safe);
  }

  public Map<DeathCause, List<String>> getAllMessages() {
    Map<DeathCause, List<String>> snapshot = new EnumMap<>(DeathCause.class);
    causeConfigs.forEach((cause, cfg) -> snapshot.put(cause, cfg.messages()));
    return snapshot;
  }

  public Map<DeathCause, DeathCauseConfig> getAllConfigs() {
    return new HashMap<>(causeConfigs);
  }

  public DeathCauseConfig getConfig(DeathCause cause) {
    DeathCauseConfig cfg = causeConfigs.get(cause);
    if (cfg != null) {
      return cfg;
    }
    return causeConfigs.get(DeathCause.DEFAULT);
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setUnknownKillerText(String text) {
    this.unknownKillerText = text;
  }

  public void setUnknownAmountText(String text) {
    this.unknownAmountText = text;
  }

  public void setPendingCause(Player player, DeathCause cause) {
    if (player == null || player.getUniqueId() == null || cause == null) {
      return;
    }
    pendingCauses.put(player.getUniqueId(), cause);
  }

  public DeathCause takePendingCause(Player player) {
    if (player == null || player.getUniqueId() == null) {
      return null;
    }
    return pendingCauses.remove(player.getUniqueId());
  }

  public Component handleDeath(PlayerDeathEvent event) {
    if (event == null) {
      return null;
    }
    Player victim = event.getEntity();
    if (!enabled || victim == null) {
      return event.deathMessage();
    }

    DeathCause cause = resolveCause(event, victim);
    DeathCauseConfig cfg = getConfig(cause);
    if (cfg == null || cfg.messages().isEmpty()) {
      log("死亡类型 '" + cause.configKey + "' 缺少消息模板，已回退到 default", Level.WARNING);
      cfg = getConfig(DeathCause.DEFAULT);
    }
    if (cfg == null || cfg.messages().isEmpty()) {
      log("default 死亡消息模板缺失，无法渲染死亡消息", Level.SEVERE);
      return event.deathMessage();
    }

    String rendered =
        render(RandomProvider.randomElement(cfg.messages()), victim, event, cause, cfg);
    Component component = LEGACY.deserialize(rendered);

    if (broadcastEnabled && cfg.broadcast() && plugin != null) {
      plugin
          .getServer()
          .broadcast(
              Component.join(
                  Component.join(Component.text(broadcastPrefix, NamedTextColor.GOLD), component),
                  Component.empty()));
    }

    return cfg.deathScreen() ? component : event.deathMessage();
  }

  private String render(
      String template,
      Player victim,
      PlayerDeathEvent event,
      DeathCause cause,
      DeathCauseConfig cfg) {
    Entity killer = resolveKiller(event, victim);
    Location location = victim.getLocation();
    String world =
        location != null && location.getWorld() != null ? location.getWorld().getName() : "";
    String killerName = killer != null ? killer.getName() : unknownKillerText;
    String causeName =
        causeNames.getOrDefault(normalizeKey(cause.configKey), builtinCauseName(cause));
    String item = cfg.showItem() ? resolveItem(killer, location) : "";
    String amount = item.isEmpty() ? unknownAmountText : "1";
    String coords =
        cfg.showLocation() && location != null
            ? String.format(
                "%d, %d, %d", location.getBlockX(), location.getBlockY(), location.getBlockZ())
            : "";

    return substitute(
        template, victim.getName(), killerName, causeName, coords, world, item, amount);
  }

  private String substitute(
      String template,
      String player,
      String killer,
      String cause,
      String location,
      String world,
      String item,
      String amount) {
    String out = template;
    out = replace(out, "player", player);
    out = replace(out, "victim", player);
    out = replace(out, "killer", killer);
    out = replace(out, "cause", cause);
    out = replace(out, "location", location);
    out = replace(out, "world", world);
    out = replace(out, "item", item);
    out = replace(out, "amount", amount);
    return out;
  }

  private String replace(String template, String key, String value) {
    return template.replace("%" + key + "%", value).replace("{" + key + "}", value);
  }

  private Entity resolveKiller(PlayerDeathEvent event, Player victim) {
    EntityDamageEvent last = victim.getLastDamageCause();
    if (last instanceof EntityDamageByEntityEvent byEntity) {
      return resolveSource(byEntity.getDamager());
    }
    return null;
  }

  private DeathCause resolveCause(PlayerDeathEvent event, Player victim) {
    DeathCause specified = takePendingCause(victim);
    if (specified != null) {
      if (!causeConfigs.containsKey(specified)) {
        log("外部指定的死亡类型 '" + specified.configKey + "' 未在配置中定义，已回退到 default", Level.WARNING);
        return DeathCause.DEFAULT;
      }
      return specified;
    }

    Entity killer = resolveKiller(event, victim);
    if (killer instanceof Player) {
      return DeathCause.PVP;
    }
    if (killer instanceof Tameable tameable
        && tameable.isTamed()
        && tameable.getOwner() instanceof Player) {
      return DeathCause.TAMED;
    }
    if (killer instanceof Entity entity && isHostileMob(entity)) {
      return DeathCause.ENTITY;
    }

    EntityDamageEvent last = victim.getLastDamageCause();
    if (last == null) {
      return warnUnknown("无伤害记录", DeathCause.DEFAULT);
    }
    return classify(last, victim);
  }

  private DeathCause classify(EntityDamageEvent event, Player victim) {
    return switch (event.getCause()) {
      case FALL -> DeathCause.FALL;
      case DROWNING, DRYOUT -> DeathCause.DROWNING;
      case LAVA -> DeathCause.LAVA;
      case FIRE, FIRE_TICK, MELTING, HOT_FLOOR, CAMPFIRE -> DeathCause.FIRE;
      case BLOCK_EXPLOSION -> isCreeperSource(event) ? DeathCause.CREEPER : DeathCause.EXPLOSION;
      case ENTITY_EXPLOSION -> DeathCause.EXPLOSION;
      case VOID -> DeathCause.VOID;
      case STARVATION -> DeathCause.STARVATION;
      case SUFFOCATION -> DeathCause.SUFFOCATION;
      case LIGHTNING -> DeathCause.LIGHTNING;
      case MAGIC -> DeathCause.MAGIC;
      case POISON -> DeathCause.POISON;
      case WITHER -> DeathCause.WITHER;
      case DRAGON_BREATH -> DeathCause.DRAGON_BREATH;
      case FREEZE -> DeathCause.FREEZE;
      case CRAMMING -> DeathCause.TRAMPLING;
      case CONTACT -> isCactus(victim) ? DeathCause.CACTUS : DeathCause.FALL_PLACES;
      case FALLING_BLOCK -> isAnvil(victim) ? DeathCause.ANVIL : DeathCause.FALL_PLACES;
      case PROJECTILE -> isArrow(event) ? DeathCause.ARROW : DeathCause.PROJECTILE;
      case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK -> DeathCause.ENTITY;
      case CUSTOM -> DeathCause.CUSTOM;
      default -> warnUnknown(event.getCause().name(), DeathCause.FALL_PLACES);
    };
  }

  private DeathCause warnUnknown(String detail, DeathCause fallback) {
    if (warnedTypes.add("runtime:" + detail)) {
      log("未识别的死亡原因 '" + detail + "'，已回退到 '" + fallback.configKey + "'", Level.WARNING);
    }
    return fallback;
  }

  private boolean isCreeperSource(EntityDamageEvent event) {
    if (!(event instanceof EntityDamageByEntityEvent byEntity)) {
      return false;
    }
    Entity source = resolveSource(byEntity.getDamager());
    return source != null && source.getType().name().equals("CREEPER");
  }

  /** 投射物归因到发射者，其余伤害源就是 damager 本身。 */
  private Entity resolveSource(Entity damager) {
    if (damager instanceof Projectile projectile
        && projectile.getShooter() instanceof Entity shooter) {
      return shooter;
    }
    return damager;
  }

  private boolean isArrow(EntityDamageEvent event) {
    if (!(event instanceof EntityDamageByEntityEvent byEntity)) {
      return false;
    }
    return byEntity.getDamager() instanceof org.bukkit.entity.Arrow;
  }

  private boolean isHostileMob(Entity entity) {
    return entity instanceof org.bukkit.entity.Monster;
  }

  private boolean isCactus(Player victim) {
    Location loc = victim.getLocation();
    return loc != null && materialAt(loc) == Material.CACTUS;
  }

  private boolean isAnvil(Player victim) {
    Location loc = victim.getLocation();
    if (loc == null) {
      return false;
    }
    Material type = materialAt(loc);
    return type == Material.ANVIL
        || type == Material.CHIPPED_ANVIL
        || type == Material.DAMAGED_ANVIL;
  }

  private Material materialAt(Location loc) {
    if (loc.getWorld() == null) {
      return Material.AIR;
    }
    Block block = loc.getBlock();
    return block == null ? Material.AIR : block.getType();
  }

  private String resolveItem(Entity killer, Location location) {
    if (killer instanceof Player player) {
      ItemStack hand = player.getInventory().getItemInMainHand();
      if (hand != null && hand.getType() != Material.AIR) {
        return prettify(hand.getType());
      }
    }
    Material blockType = location == null ? Material.AIR : materialAt(location);
    return blockType == Material.AIR ? "" : prettify(blockType);
  }

  private String prettify(Material material) {
    String name = material.name().replace('_', ' ').toLowerCase(Locale.ROOT);
    return name.isBlank() ? "" : name;
  }

  private static String normalizeKey(String key) {
    return key == null ? "" : key.trim().toLowerCase(Locale.ROOT).replace('_', '-');
  }

  private void log(String message, Level level) {
    logger.log(level, "[DeathMessage] " + message);
  }

  public enum DeathCause {
    DEFAULT("default"),
    PVP("pvp"),
    FALL("fall"),
    DROWNING("drowning"),
    LAVA("lava"),
    FIRE("fire"),
    FIRE_TICK("fire-tick"),
    EXPLOSION("explosion"),
    CREEPER("creeper"),
    VOID("void"),
    STARVATION("starvation"),
    SUFFOCATION("suffocation"),
    CACTUS("cactus"),
    ENDERMAN("enderman"),
    WITHER("wither"),
    POISON("poison"),
    MAGIC("magic"),
    ANVIL("anvil"),
    DRAGON_BREATH("dragon-breath"),
    LIGHTNING("lightning"),
    FREEZE("freeze"),
    TAMED("tamed"),
    PLUGIN("plugin"),
    CUSTOM("custom"),
    PROJECTILE("projectile"),
    ARROW("arrow"),
    FIREBALL("fireball"),
    ENTITY("entity"),
    TRAMPLING("trampling"),
    FALL_PLACES("fall-places"),
    WITHER_SPAWN("wither-spawn");

    private final String configKey;

    DeathCause(String configKey) {
      this.configKey = configKey;
    }

    public String toConfigKey() {
      return configKey;
    }

    public static DeathCause byConfigKey(String key) {
      String normalized = normalizeKey(key);
      for (DeathCause cause : values()) {
        if (cause.configKey.equals(normalized)
            || cause.name().toLowerCase(Locale.ROOT).equals(normalized)) {
          return cause;
        }
      }
      return null;
    }
  }

  public record DeathCauseConfig(
      boolean broadcast,
      boolean showLocation,
      boolean showItem,
      boolean deathScreen,
      List<String> messages) {}
}
