package dev.starcore.starcore.gui;

import java.util.*;
import java.util.Objects;

/** 地图图标 表示地图上的一个图标元素 */
public record MapIcon(
    String id, // 图标ID
    String name, // 图标名称
    String description, // 图标描述
    double x, // X坐标
    double y, // Y坐标
    double zIndex, // Z层级
    MapIconType type, // 图标类型
    Map<String, Object> metadata // 元数据
    ) implements MapElement {

  /** 获取图标ID */
  public String getId() {
    return id;
  }

  /** 检查坐标是否在图标范围内 */
  public boolean contains(double checkX, double checkY) {
    // 简化处理：将图标视为以中心点为中心的正方形
    double size = 0.1; // 默认大小
    double halfSize = size / 2.0;
    return checkX >= x - halfSize
        && checkX <= x + halfSize
        && checkY >= y - halfSize
        && checkY <= y + halfSize;
  }

  /** 获取名称 */
  public String getName() {
    return name;
  }

  /** 获取描述 */
  public String getDescription() {
    return description;
  }

  /** 获取X坐标 */
  public double getX() {
    return x;
  }

  /** 获取Y坐标 */
  public double getY() {
    return y;
  }

  /** 获取Z层级 */
  public double getZIndex() {
    return zIndex;
  }

  /** 获取图标类型 */
  public MapIconType getType() {
    return type;
  }

  /** 获取元数据 */
  public Map<String, Object> getMetadata() {
    return metadata;
  }

  /** 地图图标构建器 */
  public static Builder builder(String id, String name, MapIconType type) {
    return new Builder(id, name, type);
  }

  public static class Builder {
    private final String id;
    private final String name;
    private final MapIconType type;
    private double x = 0.0;
    private double y = 0.0;
    private double zIndex = 0.0;
    private String description = "";
    private final Map<String, Object> metadata = new HashMap<>();

    private Builder(String id, String name, MapIconType type) {
      this.id = Objects.requireNonNull(id);
      this.name = Objects.requireNonNull(name);
      this.type = Objects.requireNonNull(type);
    }

    public Builder position(double x, double y) {
      this.x = x;
      this.y = y;
      return this;
    }

    public Builder description(String description) {
      this.description = description;
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(key, value);
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      this.metadata.putAll(metadata);
      return this;
    }

    public MapIcon build() {
      return new MapIcon(id, name, description, x, y, zIndex, type, metadata);
    }
  }
}
