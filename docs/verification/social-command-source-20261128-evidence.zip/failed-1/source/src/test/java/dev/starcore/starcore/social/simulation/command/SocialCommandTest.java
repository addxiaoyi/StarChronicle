package dev.starcore.starcore.social.simulation.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.social.simulation.*;
import dev.starcore.starcore.social.simulation.ReputationService.*;
import java.util.*;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;

class SocialCommandTest {
  private static final class Fixture implements AutoCloseable {
    final SocialSimCommandTest.Fixture owners = new SocialSimCommandTest.Fixture();
    final SocialInfluenceService influence = mock(SocialInfluenceService.class);
    final NewsPropagationService news = mock(NewsPropagationService.class);
    final SocialEventScheduler events = mock(SocialEventScheduler.class);
    final SocialCommand command =
        new SocialCommand(
            owners.tasks, owners.reputation, owners.relations, influence, news, events);

    Player player(long id, String name) {
      return owners.player(new UUID(0, id), name);
    }

    void invoke(Player player, String... args) {
      command.onCommand(player, null, "social", args);
    }

    void drain() {
      for (int i = 0; i < 20; i++) {
        owners.drainOwners();
        while (!owners.io.isEmpty()) owners.io.remove().run();
        if (owners.owners.isEmpty() && owners.io.isEmpty()) return;
      }
      fail("Tasks failed to finish");
    }

    @Override
    public void close() {
      command.shutdown();
      owners.close();
    }
  }

  private static ReputationProfile profile(UUID id, int value) {
    Map<ReputationDimension, Integer> values = new EnumMap<>(ReputationDimension.class);
    for (var dimension : ReputationDimension.values()) values.put(dimension, value);
    return new ReputationProfile(
        id, value * 4, values, ReputationLevel.fromReputation(value * 4), 1);
  }

  private static RelationshipNetwork.Relationship relation(UUID viewer, UUID other, int strength) {
    return new RelationshipNetwork.Relationship(
        viewer,
        other,
        strength < 0
            ? RelationshipNetwork.RelationshipType.ENEMY
            : RelationshipNetwork.RelationshipType.FRIEND,
        strength,
        1,
        1,
        List.of());
  }

  @Test
  void rankingUsesIoOriginalPlayerNamesAndCopiedArguments() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      var first = f.player(2, "First");
      var second = f.player(3, "Second");
      var profiles = List.of(profile(first.getUniqueId(), 50), profile(second.getUniqueId(), 30));
      when(f.owners.reputation.getTopProfiles(any(), eq(2)))
          .thenAnswer(
              ignored -> {
                assertNull(f.owners.owner);
                return profiles;
              });
      String[] args = {"rep", "top", "2"};
      f.invoke(viewer, args);
      args[2] = "bad";
      f.owners.drainOwners();
      verifyNoInteractions(f.owners.reputation);
      f.drain();
      verify(first).getName();
      verify(second).getName();
      verify(viewer, times(4)).sendMessage(contains("1. First"));
      verify(viewer, times(4)).sendMessage(contains("2. Second"));
    }
  }

  @Test
  void invalidLimitsDepthsAndPagesNeverReachTheServices() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      for (String value : List.of("0", "21", "bad", "2147483648"))
        f.invoke(viewer, "rep", "top", value);
      f.invoke(viewer, "inf", "sphere", "0");
      f.invoke(viewer, "inf", "sphere", "6");
      f.invoke(viewer, "rel", "-1");
      f.drain();
      verifyNoInteractions(f.owners.reputation, f.owners.relations, f.influence);
      verify(viewer, times(7)).sendMessage(contains("须为"));
    }
  }

  @Test
  void profileQueriesHistoryOnIoAndPreservesEqualTimestamps() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      when(f.owners.reputation.getProfile(id)).thenReturn(profile(id, 0));
      var first =
          new ReputationChange(
              1000, ReputationDimension.MORAL, 3, 3, ReputationReason.HELP_PLAYER, "first", null);
      var second =
          new ReputationChange(
              1000, ReputationDimension.MORAL, 4, 7, ReputationReason.HELP_PLAYER, "second", null);
      when(f.owners.reputation.getHistoryEntries(id, 5))
          .thenAnswer(
              ignored -> {
                assertNull(f.owners.owner);
                return List.of(first, second);
              });
      f.invoke(viewer, "rep");
      f.owners.drainOwners();
      verify(viewer, never()).sendMessage(anyString());
      f.drain();
      verify(viewer).sendMessage(contains("+3"));
      verify(viewer).sendMessage(contains("+4"));
    }
  }

  @Test
  void relationPagesUseStableOrderAndOnlyResolveDisplayedPlayers() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      var first = f.player(2, "First");
      var last = f.player(22, "Last");
      Map<UUID, RelationshipNetwork.Relationship> all = new LinkedHashMap<>();
      for (int i = 22; i >= 2; i--) {
        var other = new UUID(0, i);
        all.put(other, relation(id, other, 50));
      }
      when(f.owners.relations.getAllRelationships(id)).thenReturn(all);
      f.invoke(viewer, "rel", "2");
      f.drain();
      verify(last).getName();
      verify(first, never()).getName();
      verify(viewer).sendMessage(contains("21 个关系，第 2/2 页"));
      verify(viewer).sendMessage(contains("Last"));
      f.invoke(viewer, "rel", "2147483647");
      f.drain();
      verify(viewer).sendMessage("§c页码超出范围，共 2 页");
    }
  }

  @Test
  void influenceSphereBoundsDepthAndResolvesOnlyItsPage() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      var first = f.player(2, "First");
      var last = f.player(24, "Last");
      Set<UUID> sphere = new HashSet<>();
      for (int i = 2; i <= 24; i++) sphere.add(new UUID(0, i));
      when(f.influence.getInfluenceSphere(id, 2)).thenReturn(sphere);
      when(f.influence.getStatus(id)).thenReturn(SocialInfluenceService.SocialStatus.KNOWN);
      f.invoke(viewer, "inf", "sphere", "2", "2");
      f.drain();
      verify(first, never()).getName();
      verify(last).getName();
      verify(viewer).sendMessage(contains("23 §7位玩家"));
      verify(viewer).sendMessage("§7第 2/2 页");
    }
  }

  @Test
  void statusResolvesBestFriendAndEnemyOnTheirOwnOwners() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      var friend = f.player(2, "Friend");
      var enemy = f.player(3, "Enemy");
      UUID friendId = friend.getUniqueId(), enemyId = enemy.getUniqueId();
      when(f.owners.relations.getBestFriend(id)).thenReturn(Optional.of(friendId));
      when(f.owners.relations.getWorstEnemy(id)).thenReturn(Optional.of(enemyId));
      when(f.owners.relations.getRelationship(id, friendId)).thenReturn(relation(id, friendId, 50));
      when(f.owners.relations.getRelationship(id, enemyId)).thenReturn(relation(id, enemyId, -50));
      when(f.owners.reputation.getProfile(id)).thenReturn(profile(id, 0));
      when(f.influence.getStatus(id)).thenReturn(SocialInfluenceService.SocialStatus.KNOWN);
      f.invoke(viewer, "status");
      f.drain();
      verify(viewer).sendMessage(contains("挚友: §fFriend"));
      verify(viewer).sendMessage(contains("宿敌: §fEnemy"));
    }
  }

  @Test
  void newsMarksOnlySuccessfullyDisplayedPageAndContinuesWithUnreadItems() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      List<NewsPropagationService.NewsItem> unread = new ArrayList<>();
      for (int i = 1; i <= 21; i++)
        unread.add(
            new NewsPropagationService.NewsItem(
                "news-" + i,
                "headline-" + i,
                "content-" + i,
                id,
                NewsPropagationService.NewsCategory.SOCIAL,
                1,
                .5,
                Set.of(id)));
      when(f.news.getUnreadNews(id)).thenAnswer(ignored -> List.copyOf(unread));
      doAnswer(
              inv -> {
                assertSame(viewer, f.owners.owner);
                String key = inv.getArgument(1);
                unread.removeIf(item -> item.id().equals(key));
                return null;
              })
          .when(f.news)
          .markAsRead(eq(id), anyString());
      f.invoke(viewer, "news");
      f.drain();
      verify(f.news, times(20)).markAsRead(eq(id), anyString());
      assertEquals("news-21", unread.getFirst().id());
      verify(viewer, never()).sendMessage("§7content-21");
      f.invoke(viewer, "news");
      f.drain();
      verify(viewer).sendMessage("§7content-21");
      assertTrue(unread.isEmpty());
    }
  }

  @Test
  void readFailureRepliesOnOriginalOwnerAndCloseRejectsQueuedQueries() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      when(f.owners.reputation.getProfile(id))
          .thenThrow(new IllegalStateException("store rejected"));
      f.invoke(viewer, "rep");
      f.drain();
      verify(viewer).sendMessage(contains("未能确认操作结果"));
      clearInvocations(f.owners.reputation, viewer);
      f.invoke(viewer, "rep");
      f.owners.drainOwners();
      f.command.shutdown();
      f.drain();
      verifyNoInteractions(f.owners.reputation);
      verify(viewer, never()).sendMessage(anyString());
      assertTrue(f.command.onTabComplete(viewer, null, "social", new String[] {"r"}).isEmpty());
    }
  }

  @Test
  void delayedReadNeverRepliesToReconnectedViewerAndCompletesPrefixes() {
    try (var f = new Fixture()) {
      var viewer = f.player(1, "Viewer");
      UUID id = viewer.getUniqueId();
      when(f.owners.reputation.getProfile(id)).thenReturn(profile(id, 0));
      f.invoke(viewer, "rep");
      f.owners.drainOwners();
      var replacement = f.player(1, "Replacement");
      f.drain();
      verify(viewer, never()).sendMessage(anyString());
      verify(replacement, never()).sendMessage(anyString());
      assertEquals(
          List.of("rep", "rel"),
          f.command.onTabComplete(viewer, null, "social", new String[] {"R"}));
      assertEquals(
          List.of("history"),
          f.command.onTabComplete(viewer, null, "social", new String[] {"reputation", "h"}));
    }
  }
}
