from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile

root=Path(__file__).resolve().parents[1]
native=root.parent/'StarChronicle-audit/starcore-all-stages'
attempt='native-message-command-focused-1-20261128'
tests=json.loads((root/'run'/attempt/'result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][k]==0 for k in ('failures','errors','skipped'))
frozen=root/'run/message-command-frozen-pair-1-20261128'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

if sys.argv[1]=='freeze':
    frozen.mkdir()
    manifest={}
    for name,source,key in [
        ('chronicle.jar',root/'run/friend-command-frozen-pair-1-20261128/chronicle.jar',None),
        ('native.jar',native/'target/starcore-1.0.0.jar','starcore-1.0.0.jar'),
        ('original-native.jar',native/'target/original-starcore-1.0.0.jar','original-starcore-1.0.0.jar')]:
        original=digest(source)
        if key:assert original==tests['artifacts'][key]
        if key:shutil.copy2(source,frozen/name)
        else:os.link(source,frozen/name)
        assert digest(frozen/name)==original
        manifest[name]={'sha256':original,'bytes':source.stat().st_size,'source':str(source)}
    (frozen/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest));sys.exit()

pair=json.loads((root/'run/message-command-pair-artifacts-1-20261128/result.json').read_text())
assert pair['status']=='VERIFIED'
files={}
for label,name in [('validation',attempt),('pair','message-command-pair-artifacts-1-20261128'),('frozen',frozen.name)]:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class','.mdmp'):
            files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py',
             'run/validate-message-command-20261128.py','run/finalize-message-command-20261128.py',
             'run/message-command-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:digest(path) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,
    'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],
    'artifacts':json.loads((frozen/'manifest.json').read_text()),'fixtures_compiled':pair['fixtures']['count'],
    'limits':['Related tests only; not the full StarCore suite.',
              'Original-player private-message dispatch, fixed reply recipient, confirmed admission, no automatic resend and command binding lifecycle.',
              'No independent JVM persistence migration probe in this batch; no persistence format change.',
              'Guild/private-message storage recovery, other social commands and remaining stages are separate source work.',
              'No Minecraft, Paper, Folia, MySQL, production deployment or long-load acceptance.']}
out=root/'docs/verification/message-command-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=digest(out),files=manifest)
(root/'docs/verification/message-command-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
