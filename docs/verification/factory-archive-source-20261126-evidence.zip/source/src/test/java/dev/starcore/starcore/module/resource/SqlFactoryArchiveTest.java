package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.resource.ProcessingService.*;
import java.lang.reflect.*;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.sqlite.SQLiteDataSource;

class SqlFactoryArchiveTest {
  @TempDir Path directory;
  static final String PREFIX = FactoryRunStore.PREFIX;

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  DataSource database(String engine) {
    if (engine.equals("sqlite")) {
      var db = new SQLiteDataSource();
      db.setUrl("jdbc:sqlite:" + directory.resolve("archive.db"));
      return db;
    }
    var db = new JdbcDataSource();
    db.setURL("jdbc:h2:mem:archive-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
    return db;
  }

  static SqlResourceStateStorage storage(DataSource db, Properties legacy) {
    return new SqlResourceStateStorage(db, legacy, Logger.getLogger("archive-test"));
  }

  static int liveRuns(ResourceModule module) throws Exception {
    var field = ResourceModule.class.getDeclaredField("factoryRuns");
    field.setAccessible(true);
    return ((Map<?, ?>) field.get(module)).size();
  }

  static long archiveCount(DataSource db) throws Exception {
    try (var c = db.getConnection();
        var s = c.createStatement();
        var r = s.executeQuery("SELECT COUNT(*) FROM " + SqlFactoryArchive.TABLE)) {
      r.next();
      return r.getLong(1);
    }
  }

  static FactoryRequest request(FactoryRun r) {
    return new FactoryRequest(
        r.runId(), r.factoryId(), r.nationId(), r.actorId(), r.recipeId(), r.batches());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void frozenV1MovesEveryCompletedProofAtomicallyAndOldIdsReplayAfterRestart(String engine)
      throws Exception {
    var db = database(engine);
    var legacy = FactorySnapshotVersionTest.legacy();
    var original = FactorySnapshotVersionTest.copy(legacy);
    var expected =
        FactorySnapshotVersionTest.restore(legacy, FactoryReceiptValidationTest.SNAPSHOT_ONLY);
    var st = storage(db, legacy);
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    assertEquals(4, liveRuns(module));
    assertEquals("1", st.load().getProperty(PREFIX + "version"));
    assertEquals(0, archiveCount(db));
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals(1, liveRuns(module));
    assertEquals(3, archiveCount(db));
    var saved = st.load();
    assertEquals("3", saved.getProperty(PREFIX + "version"));
    assertEquals("1", saved.getProperty(PREFIX + "count"));
    assertEquals("3", saved.getProperty(PREFIX + "archive-count"));
    assertTrue(saved.size() < 100);
    var restarted = new ResourceModule(storage(db, legacy), FactorySnapshotVersionTest.CLOCK);
    var service = FactoryPersistenceTest.service(restarted, false);
    for (var old : expected.values()) {
      assertEquals(old, service.factoryRun(old.runId()).orElseThrow());
      assertEquals(
          old.completed() ? FactoryStatus.ALREADY_COMPLETED : FactoryStatus.ALREADY_STARTED,
          service.startFactoryRun(request(old)).status());
    }
    assertEquals(1, liveRuns(restarted));
    assertEquals(7, restarted.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(
        FactoryStatus.COMPLETED,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(0, liveRuns(restarted));
    assertEquals(4, archiveCount(db));
    assertEquals(9, restarted.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(4, st.latestProductionSequence());
    assertEquals(original, legacy);
    var file = new ProductionPersistenceTest.MemoryStorage();
    file.state = st.load();
    var unsupported = new ResourceModule(file, FactorySnapshotVersionTest.CLOCK);
    assertTrue(unsupported.authorityDomainId().isBlank());
    assertFalse(unsupported.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals(9, unsupported.amount(FactorySnapshotVersionTest.NATION, "industrial"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void hundredsOfV2RowsArchiveInBoundedRecoveryPagesWithoutLosingTheActiveRun(String engine)
      throws Exception {
    var fixture = FactoryReceiptValidationTest.fixture(513);
    var db = database(engine);
    var st = storage(db, new Properties());
    st.load();
    st.save(fixture.state());
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    var active = fixture.runs().get("active");
    assertTrue(module.grant(active.nationId(), "industrial", 1));
    assertEquals(1, liveRuns(module));
    assertEquals(513, archiveCount(db));
    var after = new ResourceModule(storage(db, new Properties()), FactorySnapshotVersionTest.CLOCK);
    assertFalse(after.authorityDomainId().isBlank());
    assertEquals(1, liveRuns(after));
    assertEquals(active, after.activeFactoryRun(active.factoryId()).orElseThrow());
    assertEquals(fixture.runs().get("batch-256"), after.factoryRun("batch-256").orElseThrow());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void archiveInsertFailureRollsBackAllMigratedRowsInventoryAndCompletion(String engine)
      throws Exception {
    var db = database(engine);
    var legacy = FactorySnapshotVersionTest.legacy();
    var st = storage(db, legacy);
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    var before = st.load();
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.execute(
          engine.equals("sqlite")
              ? "CREATE TRIGGER reject_archive BEFORE INSERT ON "
                  + SqlFactoryArchive.TABLE
                  + " WHEN NEW.run_id='batch-1' BEGIN SELECT RAISE(ABORT,'archive failure'); END"
              : "ALTER TABLE "
                  + SqlFactoryArchive.TABLE
                  + " ADD CONSTRAINT reject_archive CHECK(run_id<>'batch-1')");
    }
    var service = FactoryPersistenceTest.service(module, false);
    assertEquals(
        FactoryStatus.UNKNOWN,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(before, st.load());
    assertEquals(0, archiveCount(db));
    assertEquals(3, st.latestProductionSequence());
    assertEquals(6, module.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.execute(
          engine.equals("sqlite")
              ? "DROP TRIGGER reject_archive"
              : "ALTER TABLE " + SqlFactoryArchive.TABLE + " DROP CONSTRAINT reject_archive");
    }
    assertEquals(
        FactoryStatus.COMPLETED,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(4, archiveCount(db));
    assertEquals(0, liveRuns(module));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void lostCommitAcknowledgementReconcilesTheArchiveWithoutPayingTwice(String engine)
      throws Exception {
    var actual = database(engine);
    var armed = new AtomicBoolean();
    var db =
        (DataSource)
            Proxy.newProxyInstance(
                DataSource.class.getClassLoader(),
                new Class<?>[] {DataSource.class},
                (p, m, a) -> {
                  Object result = invoke(actual, m, a);
                  if (!(result instanceof Connection c)) return result;
                  return Proxy.newProxyInstance(
                      Connection.class.getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (proxy, method, values) -> {
                        Object value = invoke(c, method, values);
                        if (method.getName().equals("commit") && armed.compareAndSet(true, false))
                          throw new SQLException("Committed but acknowledgement lost");
                        return value;
                      });
                });
    var st = storage(db, FactorySnapshotVersionTest.legacy());
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    var service = FactoryPersistenceTest.service(module, false);
    armed.set(true);
    assertEquals(
        FactoryStatus.UNKNOWN,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(4, archiveCount(actual));
    assertEquals(0, liveRuns(module));
    assertEquals(8, module.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(
        FactoryStatus.ALREADY_COMPLETED,
        service.completeFactoryRun("batch-3", FactorySnapshotVersionTest.NATION, null).status());
    assertEquals(4, st.latestProductionSequence());
  }

  static Object invoke(Object target, Method method, Object[] values) throws Throwable {
    try {
      return method.invoke(target, values);
    } catch (InvocationTargetException e) {
      throw e.getCause();
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void archiveKeysKeepCaseDistinctAndMaximumLengthIdentifiers(String engine) throws Exception {
    var fixture = FactoryReceiptValidationTest.fixture(1);
    var p = FactorySnapshotVersionTest.copy(fixture.state());
    var runs = new LinkedHashMap<>(fixture.runs());
    long sequence = 2;
    var ids = List.of("A", "a", "X".repeat(96), "x".repeat(96), "a.b:c_d-e");
    for (String id : ids) {
      var run = FactorySnapshotVersionTest.renamed(runs.get("batch-0"), id, ++sequence);
      runs.put(id, run);
      FactoryReceiptValidationTest.writeReceipt(p, run.productionReceipt());
    }
    FactoryRunStore.write(p, runs, fixture.factories());
    var db = database(engine);
    var st = storage(db, new Properties());
    st.load();
    st.save(p);
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    assertTrue(module.grant(runs.get("active").nationId(), "industrial", 1));
    assertEquals(1, liveRuns(module));
    assertEquals(6, archiveCount(db));
    var restarted =
        new ResourceModule(storage(db, new Properties()), FactorySnapshotVersionTest.CLOCK);
    for (String id : ids) assertEquals(runs.get(id), restarted.factoryRun(id).orElseThrow());
    var before = st.load();
    var altered = new LinkedHashMap<>(runs);
    var old = runs.get("A");
    altered.put(
        "A",
        new FactoryRun(
            old.runId(),
            old.authorityDomainId(),
            old.factoryId(),
            old.nationId(),
            old.actorId(),
            old.recipeId(),
            old.batches(),
            old.inputs(),
            Map.of("industrial", 99L),
            old.startedAt(),
            old.readyAt(),
            old.completedAt(),
            old.completionSequence()));
    var rejected = FactorySnapshotVersionTest.copy(before);
    st.writeFactoryState(rejected, altered, fixture.factories());
    assertThrows(IllegalStateException.class, () -> st.save(rejected));
    assertEquals(before, st.load());
    assertEquals(6, archiveCount(db));
  }

  static Stream<Arguments> corruptions() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(
                        "missing",
                        "payload",
                        "chain",
                        "receipt",
                        "key",
                        "head",
                        "quantity-encoding",
                        "uuid-encoding")
                    .map(kind -> Arguments.of(engine, kind)));
  }

  @ParameterizedTest
  @MethodSource("corruptions")
  void missingOrChangedArchiveEvidenceBlocksRecoveryAndNeverPaysAgain(String engine, String kind)
      throws Exception {
    var db = database(engine);
    var st = storage(db, FactorySnapshotVersionTest.legacy());
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      String sql =
          switch (kind) {
            case "missing" ->
                "DELETE FROM " + SqlFactoryArchive.TABLE + " WHERE archive_sequence=2";
            case "payload" ->
                "UPDATE "
                    + SqlFactoryArchive.TABLE
                    + " SET ready_at=ready_at+1 WHERE archive_sequence=2";
            case "chain" ->
                "UPDATE "
                    + SqlFactoryArchive.TABLE
                    + " SET chain_hash='"
                    + "0".repeat(64)
                    + "' WHERE archive_sequence=2";
            case "receipt" ->
                "UPDATE starcore_resource_production_receipts SET outputs='industrial=99' WHERE"
                    + " sequence=2";
            case "key" ->
                "UPDATE "
                    + SqlFactoryArchive.TABLE
                    + " SET run_key='"
                    + "0".repeat(64)
                    + "' WHERE archive_sequence=2";
            case "head" ->
                "UPDATE starcore_resource_state SET property_value='999' WHERE property_key='"
                    + PREFIX
                    + "archive-count'";
            case "quantity-encoding" ->
                "UPDATE "
                    + SqlFactoryArchive.TABLE
                    + " SET inputs='mineral=03' WHERE archive_sequence=2";
            case "uuid-encoding" ->
                "UPDATE "
                    + SqlFactoryArchive.TABLE
                    + " SET factory_id='0-0-0-0-2' WHERE archive_sequence=2";
            default -> throw new AssertionError(kind);
          };
      s.executeUpdate(sql);
    }
    var after = new ResourceModule(storage(db, new Properties()), FactorySnapshotVersionTest.CLOCK);
    assertTrue(after.authorityDomainId().isBlank());
    assertEquals(
        FactoryStatus.UNAVAILABLE,
        FactoryPersistenceTest.service(after, false)
            .completeFactoryRun("batch-1", FactorySnapshotVersionTest.NATION, null)
            .status());
    assertFalse(after.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals(7, after.amount(FactorySnapshotVersionTest.NATION, "industrial"));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void archivedFormatCannotDowngradeAndMigrationCannotDropOldProofs(String engine)
      throws Exception {
    var db = database(engine);
    var old = FactorySnapshotVersionTest.legacy();
    var st = storage(db, old);
    st.load();
    var factories =
        ResourceStateCodec.snapshotFromProperties(old, ResourceModule.RESOURCE_TYPES).factories();
    var runs =
        new LinkedHashMap<>(
            FactorySnapshotVersionTest.restore(old, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    runs.remove("batch-0");
    var next = FactorySnapshotVersionTest.copy(old);
    st.writeFactoryState(next, runs, factories);
    assertThrows(IllegalStateException.class, () -> st.save(next));
    assertEquals(0, archiveCount(db));
    var module = new ResourceModule(st, FactorySnapshotVersionTest.CLOCK);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    var saved = st.load();
    assertThrows(IllegalStateException.class, () -> st.save(old));
    assertEquals(saved, st.load());
  }
}
