package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.Factory;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.time.Instant;
import java.util.*;

/**
 * Complete immutable finished batches, committed alongside the stockpile and production receipt.
 */
final class SqlFactoryArchive {
  static final String TABLE = "starcore_resource_factory_archive";
  private static final String PREFIX = FactoryRunStore.PREFIX;

  record Head(long count, String hash) {
    static final Head EMPTY = new Head(0, "");

    Head {
      if (count < 0 || (count == 0 ? !hash.isEmpty() : !hash.matches("[0-9a-f]{64}")))
        throw new IllegalStateException("Invalid factory archive head");
    }

    static Head from(Properties p) {
      if (!"3".equals(p.getProperty(PREFIX + "version"))) return EMPTY;
      return new Head(
          Long.parseLong(p.getProperty(PREFIX + "archive-count")),
          Objects.requireNonNull(p.getProperty(PREFIX + "archive-head")));
    }
  }

  private SqlFactoryArchive() {}

  static void ensure(Connection c) throws SQLException {
    try (var s = c.createStatement()) {
      s.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_factory_archive (
            run_key VARCHAR(64) PRIMARY KEY, archive_sequence BIGINT NOT NULL UNIQUE,
            run_id VARCHAR(96) NOT NULL, authority_domain_id VARCHAR(36) NOT NULL,
            factory_id VARCHAR(36) NOT NULL, nation_id VARCHAR(36) NOT NULL,
            actor_id VARCHAR(36), recipe_id VARCHAR(128) NOT NULL, batches INTEGER NOT NULL,
            inputs TEXT NOT NULL, outputs TEXT NOT NULL,
            started_at BIGINT NOT NULL, ready_at BIGINT NOT NULL, completed_at BIGINT NOT NULL,
            completion_sequence BIGINT NOT NULL UNIQUE, row_hash VARCHAR(64) NOT NULL,
            chain_hash VARCHAR(64) NOT NULL)
          """);
    }
  }

  static Head head(Connection c) throws SQLException {
    Properties p = new Properties();
    try (var s =
        c.prepareStatement(
            "SELECT property_key,property_value FROM starcore_resource_state WHERE property_key IN"
                + " (?,?,?)")) {
      s.setString(1, PREFIX + "version");
      s.setString(2, PREFIX + "archive-count");
      s.setString(3, PREFIX + "archive-head");
      try (var rows = s.executeQuery()) {
        while (rows.next()) p.setProperty(rows.getString(1), rows.getString(2));
      }
    }
    return Head.from(p);
  }

  static void validateHead(Connection c, Head expected) throws SQLException {
    try (var s =
        c.prepareStatement(
            "SELECT COUNT(*),COUNT(CASE WHEN archive_sequence BETWEEN 1 AND ? THEN 1 END) FROM "
                + TABLE)) {
      s.setLong(1, expected.count());
      try (var rows = s.executeQuery()) {
        rows.next();
        if (rows.getLong(1) != expected.count() || rows.getLong(2) != expected.count())
          throw new IllegalStateException("Factory archive has a gap or extra row");
      }
    }
    if (expected.count() > 0) {
      try (var s =
          c.prepareStatement("SELECT chain_hash FROM " + TABLE + " WHERE archive_sequence=?")) {
        s.setLong(1, expected.count());
        try (var rows = s.executeQuery()) {
          if (!rows.next() || !expected.hash().equals(rows.getString(1)))
            throw new IllegalStateException("Factory archive tail changed");
        }
      }
    }
  }

  /** Stream bounded pages and match every archived batch to its original completion receipt. */
  static void validateAll(Connection c, Head expected, String domain, Map<UUID, Factory> factories)
      throws SQLException {
    validateHead(c, expected);
    long cursor = 0;
    String chain = "";
    while (cursor < expected.count()) {
      Map<String, FactoryRun> batch = new LinkedHashMap<>();
      try (var s =
          c.prepareStatement(
              "SELECT * FROM "
                  + TABLE
                  + " WHERE archive_sequence>? ORDER BY archive_sequence LIMIT 256")) {
        s.setLong(1, cursor);
        try (var rows = s.executeQuery()) {
          while (rows.next()) {
            if (rows.getLong("archive_sequence") != ++cursor)
              throw new IllegalStateException("Factory archive sequence changed");
            FactoryRun run = read(rows);
            Factory factory = factories.get(run.factoryId());
            if (!domain.equals(run.authorityDomainId())
                || factory == null
                || !factory.ownerNationId().equals(run.nationId()))
              throw new IllegalStateException("Archived factory identity changed");
            chain = hash(chain, Long.toString(cursor), rows.getString("row_hash"));
            if (!chain.equals(rows.getString("chain_hash")))
              throw new IllegalStateException("Factory archive chain changed");
            batch.put(run.runId(), run);
          }
        }
      }
      if (batch.isEmpty()) throw new IllegalStateException("Factory archive truncated");
      SqlProductionReceipts.validateRuns(c, batch);
    }
    if (!expected.hash().equals(chain))
      throw new IllegalStateException("Factory archive head changed");
  }

  static Optional<FactoryRun> find(Connection c, String id) throws SQLException {
    ProductionReceipt.token(id, 96);
    try (var s = c.prepareStatement("SELECT * FROM " + TABLE + " WHERE run_key=?")) {
      s.setString(1, key(id));
      try (var rows = s.executeQuery()) {
        if (!rows.next()) return Optional.empty();
        FactoryRun run = read(rows);
        if (!id.equals(run.runId()))
          throw new IllegalStateException("Factory archive key collision");
        return Optional.of(run);
      }
    }
  }

  static Head append(Connection c, Head head, FactoryRun run) throws SQLException {
    if (!run.completed()) throw new IllegalStateException("Cannot archive an active batch");
    var old = find(c, run.runId());
    if (old.isPresent()) {
      if (!run.equals(old.get())) throw new IllegalStateException("Archived factory batch changed");
      return head;
    }
    if (!SqlProductionReceipts.find(c, run.productionOperationId())
        .filter(run.productionReceipt()::equals)
        .isPresent())
      throw new IllegalStateException("Archived batch has no matching production receipt");
    long sequence = Math.addExact(head.count(), 1);
    String rowHash = fingerprint(run), chain = hash(head.hash(), Long.toString(sequence), rowHash);
    try (var s =
        c.prepareStatement(
            "INSERT INTO "
                + TABLE
                + " (run_key,archive_sequence,run_id,authority_domain_id,factory_id,nation_id,actor_id,recipe_id,batches,inputs,outputs,started_at,ready_at,completed_at,completion_sequence,row_hash,chain_hash)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
      s.setString(1, key(run.runId()));
      s.setLong(2, sequence);
      s.setString(3, run.runId());
      s.setString(4, run.authorityDomainId());
      s.setString(5, run.factoryId().toString());
      s.setString(6, run.nationId().toString());
      s.setString(7, run.actorId() == null ? null : run.actorId().toString());
      s.setString(8, run.recipeId());
      s.setInt(9, run.batches());
      s.setString(10, ResourceTransferReceiptStore.encodeResources(run.inputs()));
      s.setString(11, ResourceTransferReceiptStore.encodeResources(run.outputs()));
      s.setLong(12, run.startedAt().toEpochMilli());
      s.setLong(13, run.readyAt().toEpochMilli());
      s.setLong(14, run.completedAt().toEpochMilli());
      s.setLong(15, run.completionSequence());
      s.setString(16, rowHash);
      s.setString(17, chain);
      if (s.executeUpdate() != 1) throw new SQLException("Factory archive row not inserted");
    }
    return new Head(sequence, chain);
  }

  private static FactoryRun read(ResultSet r) throws SQLException {
    String actor = r.getString("actor_id");
    FactoryRun run =
        new FactoryRun(
            r.getString("run_id"),
            r.getString("authority_domain_id"),
            UUID.fromString(r.getString("factory_id")),
            new NationId(UUID.fromString(r.getString("nation_id"))),
            actor == null ? null : UUID.fromString(actor),
            r.getString("recipe_id"),
            r.getInt("batches"),
            ResourceTransferReceiptStore.decodeResources(r.getString("inputs")),
            ResourceTransferReceiptStore.decodeResources(r.getString("outputs")),
            Instant.ofEpochMilli(r.getLong("started_at")),
            Instant.ofEpochMilli(r.getLong("ready_at")),
            Instant.ofEpochMilli(r.getLong("completed_at")),
            r.getLong("completion_sequence"));
    if (!ResourceModule.RESOURCE_TYPES.containsAll(run.inputs().keySet())
        || !ResourceModule.RESOURCE_TYPES.containsAll(run.outputs().keySet())
        || !run.factoryId().toString().equals(r.getString("factory_id"))
        || !run.nationId().toString().equals(r.getString("nation_id"))
        || !Objects.equals(run.actorId() == null ? null : run.actorId().toString(), actor)
        || !ResourceTransferReceiptStore.encodeResources(run.inputs()).equals(r.getString("inputs"))
        || !ResourceTransferReceiptStore.encodeResources(run.outputs())
            .equals(r.getString("outputs"))
        || !key(run.runId()).equals(r.getString("run_key"))
        || !fingerprint(run).equals(r.getString("row_hash")))
      throw new IllegalStateException("Factory archive row changed");
    return run;
  }

  private static String key(String id) {
    String prefix = FactoryRunStore.rowPrefix(id);
    return prefix.substring((PREFIX + "row.").length(), prefix.length() - 1);
  }

  private static String fingerprint(FactoryRun run) {
    return hash(
        run.runId(),
        run.authorityDomainId(),
        run.factoryId().toString(),
        run.nationId().toString(),
        Objects.toString(run.actorId(), ""),
        run.recipeId(),
        Integer.toString(run.batches()),
        ResourceTransferReceiptStore.encodeResources(run.inputs()),
        ResourceTransferReceiptStore.encodeResources(run.outputs()),
        Long.toString(run.startedAt().toEpochMilli()),
        Long.toString(run.readyAt().toEpochMilli()),
        Long.toString(run.completedAt().toEpochMilli()),
        Long.toString(run.completionSequence()));
  }

  private static String hash(String... values) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      for (String value : values) {
        byte[] raw = value.getBytes(StandardCharsets.UTF_8);
        digest.update(java.nio.ByteBuffer.allocate(4).putInt(raw.length).array());
        digest.update(raw);
      }
      return HexFormat.of().formatHex(digest.digest());
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }
}
