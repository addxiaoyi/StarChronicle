package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.sql.*;
import java.time.Instant;
import java.util.*;

/** Shares its connection and transaction with the national stockpile snapshot. */
final class SqlProductionReceipts {
  private static final String TABLE = "starcore_resource_production_receipts";

  private SqlProductionReceipts() {}

  static void ensure(Connection c) throws SQLException {
    try (var s = c.createStatement()) {
      s.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_production_receipts (
            operation_id VARCHAR(128) PRIMARY KEY, authority_domain_id VARCHAR(36) NOT NULL,
            sequence BIGINT NOT NULL UNIQUE, nation_id VARCHAR(36) NOT NULL,
            actor_id VARCHAR(36), recipe_id VARCHAR(128) NOT NULL, batches INTEGER NOT NULL,
            inputs TEXT NOT NULL, outputs TEXT NOT NULL, committed_at BIGINT NOT NULL)
          """);
    }
  }

  static Properties stateHead(Connection c) throws SQLException {
    Properties p = new Properties();
    try (var s =
        c.prepareStatement(
            "SELECT property_key,property_value FROM starcore_resource_state WHERE property_key IN"
                + " (?,?,?)")) {
      s.setString(1, ProductionReceiptStore.SEQUENCE);
      s.setString(2, ProductionReceiptStore.HEAD);
      s.setString(3, "resource.authority-domain");
      try (var r = s.executeQuery()) {
        while (r.next()) p.setProperty(r.getString(1), r.getString(2));
      }
    }
    return p;
  }

  static ProductionReceipt last(Connection c) throws SQLException {
    try (var s = c.createStatement();
        var r = s.executeQuery("SELECT * FROM " + TABLE + " ORDER BY sequence DESC LIMIT 1")) {
      return r.next() ? read(r) : null;
    }
  }

  static long validate(Connection c, Properties p) throws SQLException {
    long n = ProductionReceiptStore.sequence(p);
    ProductionReceipt last = null;
    // H2 repeatable-read/serializable descending index scans can retain the pre-insert tail.
    // An exact sequence lookup sees this transaction's own receipt; validate the entire range
    // below.
    if (n > 0) {
      try (var s = c.prepareStatement("SELECT * FROM " + TABLE + " WHERE sequence=?")) {
        s.setLong(1, n);
        try (var r = s.executeQuery()) {
          if (r.next()) last = read(r);
        }
      }
    }
    ProductionReceiptStore.validateHead(p, last);
    // Unique sequence plus exactly n rows inside 1..n proves there is no gap or extra tail.
    // Avoid MIN/MAX shortcuts as they have the same H2 visibility issue after a local insert.
    try (var s =
        c.prepareStatement(
            "SELECT COUNT(*),COUNT(CASE WHEN sequence BETWEEN 1 AND ? THEN 1 END) FROM " + TABLE)) {
      s.setLong(1, n);
      try (var r = s.executeQuery()) {
        r.next();
        if (r.getLong(1) != n || r.getLong(2) != n)
          throw new IllegalStateException("Production journal has a gap or an extra sequence");
      }
    }
    return n;
  }

  static Optional<ProductionReceipt> find(Connection c, String id) throws SQLException {
    try (var s = c.prepareStatement("SELECT * FROM " + TABLE + " WHERE operation_id=?")) {
      s.setString(1, id);
      try (var r = s.executeQuery()) {
        return r.next() ? Optional.of(read(r)) : Optional.empty();
      }
    }
  }

  /** Validate the head once, then bind at most 256 factory operation IDs per query. */
  static void validateFactoryProduction(
      Connection c, Properties snapshot, Map<String, FactoryRun> runs) throws SQLException {
    Properties current = stateHead(c);
    for (String key :
        List.of(
            ProductionReceiptStore.SEQUENCE,
            ProductionReceiptStore.HEAD,
            "resource.authority-domain")) {
      if (!Objects.equals(snapshot.getProperty(key), current.getProperty(key)))
        throw new IllegalStateException("Factory snapshot and production journal changed");
    }
    validate(c, current);
    validateRuns(c, runs);
  }

  static void validateRuns(Connection c, Map<String, FactoryRun> runs) throws SQLException {
    var verifier = new FactoryRunStore.ReceiptVerifier(runs);
    var remaining = runs.values().iterator();
    while (remaining.hasNext()) {
      List<String> ids = new ArrayList<>(256);
      while (remaining.hasNext() && ids.size() < 256)
        ids.add(remaining.next().productionOperationId());
      String marks = String.join(",", Collections.nCopies(ids.size(), "?"));
      try (var statement =
          c.prepareStatement("SELECT * FROM " + TABLE + " WHERE operation_id IN (" + marks + ")")) {
        for (int i = 0; i < ids.size(); i++) statement.setString(i + 1, ids.get(i));
        try (var rows = statement.executeQuery()) {
          while (rows.next()) verifier.accept(read(rows));
        }
      }
    }
    verifier.finish();
  }

  static List<ProductionReceipt> after(Connection c, long after, int limit) throws SQLException {
    ProductionReceiptStore.requirePage(after, limit);
    try (var s =
        c.prepareStatement(
            "SELECT * FROM " + TABLE + " WHERE sequence>? ORDER BY sequence LIMIT ?")) {
      s.setLong(1, after);
      s.setInt(2, limit);
      List<ProductionReceipt> result = new ArrayList<>();
      try (var r = s.executeQuery()) {
        while (r.next()) result.add(read(r));
      }
      return List.copyOf(result);
    }
  }

  static void insert(Connection c, ProductionReceipt r) throws SQLException {
    try (var s =
        c.prepareStatement(
            "INSERT INTO "
                + TABLE
                + " (operation_id,authority_domain_id,sequence,nation_id,actor_id,recipe_id,batches,inputs,outputs,committed_at)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?)")) {
      s.setString(1, r.operationId());
      s.setString(2, r.authorityDomainId());
      s.setLong(3, r.sequence());
      s.setString(4, r.nationId().toString());
      s.setString(5, r.actorId() == null ? null : r.actorId().toString());
      s.setString(6, r.recipeId());
      s.setInt(7, r.batches());
      s.setString(8, ResourceTransferReceiptStore.encodeResources(r.inputs()));
      s.setString(9, ResourceTransferReceiptStore.encodeResources(r.outputs()));
      s.setLong(10, r.committedAt().toEpochMilli());
      if (s.executeUpdate() != 1) throw new SQLException("Production receipt was not inserted");
    }
  }

  /** Runs inside writeProperties' transaction, before replacing state. */
  static Properties prepareSnapshot(Connection c, Properties source) throws SQLException {
    Properties next = new Properties();
    next.putAll(source);
    Properties previous = stateHead(c);
    if (source.stringPropertyNames().stream()
        .anyMatch(k -> k.startsWith(ProductionReceiptStore.ROW))) {
      long n = ProductionReceiptStore.validate(source);
      if (last(c) != null || ProductionReceiptStore.sequence(previous) != 0) validate(c, previous);
      for (long i = 1; i <= n; i++) {
        ProductionReceipt receipt = ProductionReceiptStore.read(source, i);
        var old = find(c, receipt.operationId());
        if (old.isPresent()) {
          if (!old.get().equals(receipt))
            throw new IllegalStateException("Conflicting production migration");
        } else insert(c, receipt);
      }
    } else if (!next.containsKey(ProductionReceiptStore.SEQUENCE)) {
      ProductionReceiptStore.preserve(previous, next);
    }
    validate(c, next);
    return next;
  }

  private static ProductionReceipt read(ResultSet r) throws SQLException {
    String actor = r.getString("actor_id");
    return new ProductionReceipt(
        r.getString("operation_id"),
        r.getString("authority_domain_id"),
        r.getLong("sequence"),
        new NationId(UUID.fromString(r.getString("nation_id"))),
        actor == null ? null : UUID.fromString(actor),
        r.getString("recipe_id"),
        r.getInt("batches"),
        ResourceTransferReceiptStore.decodeResources(r.getString("inputs")),
        ResourceTransferReceiptStore.decodeResources(r.getString("outputs")),
        Instant.ofEpochMilli(r.getLong("committed_at")));
  }
}
