package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceTradeLockingTest {
  record Operation(String name, Function<SimpleResourceTradeService, Object> call) {
    @Override
    public String toString() {
      return name;
    }
  }

  static Stream<Operation> operations() {
    var nation = TradeSnapshotValidationTest.EXPORTER;
    var other = TradeSnapshotValidationTest.IMPORTER;
    var agreement = TradeSnapshotValidationTest.AGREEMENT;
    var route = TradeSnapshotValidationTest.ROUTE;
    var embargo = TradeSnapshotValidationTest.EMBARGO;
    var quota = TradeSnapshotValidationTest.QUOTA;
    var type = dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType.IMPORT;
    return Stream.of(
        new Operation("create route", s -> s.createTradeRoute(nation, other, "new")),
        new Operation("find route", s -> s.getTradeRoute(route)),
        new Operation("list routes", s -> s.getTradeRoutes(nation)),
        new Operation("route between", s -> s.getTradeRouteBetween(nation, other)),
        new Operation(
            "create agreement", s -> s.createTradeAgreement(nation, other, "iron", 1, 1.0, 60)),
        new Operation("find agreement", s -> s.getTradeAgreement(agreement)),
        new Operation("list agreements", s -> s.getTradeAgreements(nation)),
        new Operation("execute", s -> s.executeTradeAgreement(agreement)),
        new Operation("cancel", s -> s.cancelTradeAgreement(nation, agreement)),
        new Operation(
            "create embargo", s -> s.createEmbargo(nation, Set.of(other), "iron", 60L, "reason")),
        new Operation("find embargo", s -> s.getEmbargo(embargo)),
        new Operation("embargoes by", s -> s.getEmbargoesBy(nation)),
        new Operation("embargoes against", s -> s.getEmbargoesAgainst(other)),
        new Operation("is embargoed", s -> s.isEmbargoed(nation, other, "iron")),
        new Operation("lift embargo", s -> s.liftEmbargo(nation, embargo)),
        new Operation("create quota", s -> s.createQuota(nation, "iron", 10, 60, type)),
        new Operation("find quota", s -> s.getQuota(quota)),
        new Operation("list quotas", s -> s.getQuotas(nation)),
        new Operation("matching quota", s -> s.getQuota(other, "iron", type)),
        new Operation("use quota", s -> s.useQuota(quota, 1)),
        new Operation(
            "reset",
            s -> {
              s.resetExpiredQuotas();
              return null;
            }),
        new Operation("volume", s -> s.calculateTradeVolume(nation, Duration.ofDays(1))),
        new Operation("snapshot agreements", SimpleResourceTradeService::snapshotAgreements),
        new Operation("snapshot routes", SimpleResourceTradeService::snapshotRoutes),
        new Operation("snapshot embargoes", SimpleResourceTradeService::snapshotEmbargoes),
        new Operation("snapshot quotas", SimpleResourceTradeService::snapshotQuotas),
        new Operation(
            "restore agreements",
            s -> {
              s.restoreAgreements(Map.of());
              return null;
            }),
        new Operation(
            "restore routes",
            s -> {
              s.restoreRoutes(Map.of());
              return null;
            }),
        new Operation(
            "restore embargoes",
            s -> {
              s.restoreEmbargoes(Map.of());
              return null;
            }),
        new Operation(
            "restore quotas",
            s -> {
              s.restoreQuotas(Map.of());
              return null;
            }));
  }

  @ParameterizedTest
  @MethodSource("operations")
  void businessAndRecoveryOperationsWaitForTheInventoryCommitMonitor(Operation operation)
      throws Exception {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    storage.state.putAll(TradeSnapshotValidationTest.validTrade());
    var module = TradeSnapshotValidationTest.module(storage);
    var service = (SimpleResourceTradeService) module.getTradeService();
    var entered = new CountDownLatch(1);
    try (var worker = Executors.newSingleThreadExecutor()) {
      Future<Object> result;
      synchronized (module) {
        result =
            worker.submit(
                () -> {
                  entered.countDown();
                  return operation.call.apply(service);
                });
        assertTrue(entered.await(2, TimeUnit.SECONDS));
        assertThrows(
            TimeoutException.class, () -> result.get(100, TimeUnit.MILLISECONDS), operation.name);
      }
      result.get(2, TimeUnit.SECONDS);
    }
  }

  @Test
  void tradeWaitingOnInventoryDoesNotHoldAnOpposingServiceMonitor() throws Exception {
    var module = TradeSnapshotValidationTest.module(new ProductionPersistenceTest.MemoryStorage());
    assertTrue(module.grant(TradeSnapshotValidationTest.EXPORTER, "industrial", 6));
    var service = (SimpleResourceTradeService) module.getTradeService();
    var agreement =
        service.createTradeAgreement(
            TradeSnapshotValidationTest.EXPORTER,
            TradeSnapshotValidationTest.IMPORTER,
            "industrial",
            2,
            1.0,
            60);
    var entered = new CountDownLatch(1);
    var thread = new AtomicReference<Thread>();
    try (var worker = Executors.newSingleThreadExecutor()) {
      Future<Boolean> result;
      synchronized (module) {
        result =
            worker.submit(
                () -> {
                  thread.set(Thread.currentThread());
                  entered.countDown();
                  return service.executeTradeAgreement(agreement.agreementId());
                });
        assertTrue(entered.await(2, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> result.get(100, TimeUnit.MILLISECONDS));
        var info =
            java.lang.management.ManagementFactory.getThreadMXBean()
                .getThreadInfo(new long[] {thread.get().threadId()}, true, true)[0];
        assertNotNull(info);
        assertEquals(System.identityHashCode(module), info.getLockInfo().getIdentityHashCode());
        for (var monitor : info.getLockedMonitors())
          assertNotEquals(
              System.identityHashCode(service),
              monitor.getIdentityHashCode(),
              "trade waits for inventory while holding the service monitor");
      }
      assertTrue(result.get(2, TimeUnit.SECONDS));
      assertEquals(4, module.amount(TradeSnapshotValidationTest.EXPORTER, "industrial"));
      assertEquals(2, module.amount(TradeSnapshotValidationTest.IMPORTER, "industrial"));
    }
  }

  @Test
  void aQueryQueuedBehindFailedCommitObservesQuarantineAfterTheLockIsReleased() throws Exception {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    var module = TradeSnapshotValidationTest.module(storage);
    var service = module.getTradeService();
    var entered = new CountDownLatch(1);
    try (var worker = Executors.newSingleThreadExecutor()) {
      Future<?> result;
      synchronized (module) {
        result =
            worker.submit(
                () -> {
                  entered.countDown();
                  return service.getQuotas(TradeSnapshotValidationTest.EXPORTER);
                });
        assertTrue(entered.await(2, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> result.get(100, TimeUnit.MILLISECONDS));
        storage.failAfter = true;
        storage.failReadAfterCommit = true;
        assertFalse(module.grant(TradeSnapshotValidationTest.EXPORTER, "industrial", 1));
      }
      var error = assertThrows(ExecutionException.class, () -> result.get(2, TimeUnit.SECONDS));
      assertInstanceOf(IllegalStateException.class, error.getCause());
    }
  }
}
