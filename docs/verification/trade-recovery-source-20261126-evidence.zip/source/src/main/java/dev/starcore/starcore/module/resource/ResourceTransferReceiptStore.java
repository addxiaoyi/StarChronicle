package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

final class ResourceTransferReceiptStore {
  private static final String COUNT = "resource.transfer.count";
  private static final String SEQUENCE = "resource.transfer.sequence";

  private ResourceTransferReceiptStore() {}

  static void append(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    int count = parseCount(properties.getProperty(COUNT));
    properties.setProperty("resource.authority-domain", receipt.authorityDomainId());
    String prefix = "resource.transfer." + count + '.';
    properties.setProperty(prefix + "id", receipt.transactionId());
    properties.setProperty(prefix + "sequence", Long.toString(receipt.sequence()));
    properties.setProperty(prefix + "payer", receipt.payerNationId().toString());
    properties.setProperty(prefix + "receiver", receipt.receiverNationId().toString());
    properties.setProperty(prefix + "resources", encodeResources(receipt.resources()));
    properties.setProperty(prefix + "category", receipt.category().name());
    properties.setProperty(prefix + "description", receipt.description());
    properties.setProperty(prefix + "appliedAt", Long.toString(receipt.appliedAt().toEpochMilli()));
    properties.setProperty(COUNT, Integer.toString(count + 1));
    properties.setProperty(SEQUENCE, Long.toString(receipt.sequence()));
  }

  static Optional<NationResourceTransactionService.TransferReceipt> find(
      Properties properties, String id) {
    int count = parseCount(properties.getProperty(COUNT));
    for (int index = 0; index < count; index++) {
      String prefix = "resource.transfer." + index + '.';
      if (id != null && id.equals(properties.getProperty(prefix + "id"))) {
        return Optional.of(parse(properties, index));
      }
    }
    return Optional.empty();
  }

  static List<NationResourceTransactionService.TransferReceipt> after(
      Properties properties, long sequence, int limit) {
    if (sequence < 0L || limit < 1 || limit > 1000) {
      throw new IllegalArgumentException("sequence must be non-negative and limit must be 1..1000");
    }
    int count = parseCount(properties.getProperty(COUNT));
    List<NationResourceTransactionService.TransferReceipt> result = new ArrayList<>(limit);
    long previousSequence = 0L;
    for (int index = 0; index < count; index++) {
      long receiptSequence = parseSequence(properties, index);
      if (receiptSequence <= previousSequence) {
        throw new IllegalStateException("Resource transfer sequence is invalid or out of order");
      }
      previousSequence = receiptSequence;
      if (receiptSequence > sequence && result.size() < limit) {
        NationResourceTransactionService.TransferReceipt receipt = parse(properties, index);
        if (receipt.sequence() != receiptSequence) {
          throw new IllegalStateException("Resource transfer receipt changed while reading");
        }
        result.add(receipt);
      }
    }
    return List.copyOf(result);
  }

  static long latestSequence(Properties properties) {
    long explicit;
    try {
      explicit = Long.parseLong(properties.getProperty(SEQUENCE, "0"));
    } catch (NumberFormatException error) {
      throw new IllegalStateException("Resource transfer sequence is corrupt", error);
    }
    if (explicit < 0L) throw new IllegalStateException("Resource transfer sequence is negative");
    int count = parseCount(properties.getProperty(COUNT));
    long previousSequence = 0L;
    for (int index = 0; index < count; index++) {
      long sequence = parseSequence(properties, index);
      if (sequence <= previousSequence) {
        throw new IllegalStateException("Resource transfer sequence is invalid or out of order");
      }
      previousSequence = sequence;
    }
    if (explicit != previousSequence) {
      throw new IllegalStateException("Resource transfer cursor does not match receipt history");
    }
    return previousSequence;
  }

  private static long parseSequence(Properties properties, int index) {
    String key = "resource.transfer." + index + ".sequence";
    try {
      long sequence = Long.parseLong(properties.getProperty(key));
      if (sequence < 1L) throw new NumberFormatException("sequence must be positive");
      return sequence;
    } catch (RuntimeException error) {
      throw new IllegalStateException(
          "Resource transfer sequence is corrupt at index " + index, error);
    }
  }

  static int count(Properties properties) {
    return parseCount(properties.getProperty(COUNT));
  }

  /** Visit a complete immutable file journal once, retaining no receipt objects. */
  static void scan(
      Properties properties,
      java.util.function.Consumer<NationResourceTransactionService.TransferReceipt> visitor) {
    int count = parseCount(properties.getProperty(COUNT));
    var names = properties.stringPropertyNames();
    if (count > names.size() / 7) throw new IllegalStateException("Transfer rows missing");
    Set<String> fields =
        Set.of(
            "id",
            "sequence",
            "payer",
            "receiver",
            "resources",
            "category",
            "description",
            "appliedAt");
    for (String key : names) {
      if (!key.startsWith("resource.transfer.") || key.equals(COUNT) || key.equals(SEQUENCE))
        continue;
      String suffix = key.substring("resource.transfer.".length());
      int dot = suffix.indexOf('.');
      try {
        int index = Integer.parseInt(suffix.substring(0, dot));
        if (index < 0
            || index >= count
            || !Integer.toString(index).equals(suffix.substring(0, dot))
            || !fields.contains(suffix.substring(dot + 1))) throw new IllegalArgumentException();
      } catch (RuntimeException invalid) {
        throw new IllegalStateException("Unknown or orphan transfer field: " + key, invalid);
      }
    }
    latestSequence(properties);
    Set<String> ids = new java.util.HashSet<>();
    for (int index = 0; index < count; index++) {
      var receipt = parse(properties, index);
      if (!ids.add(receipt.transactionId()))
        throw new IllegalStateException("Duplicate transfer ID");
      visitor.accept(receipt);
    }
  }

  private static NationResourceTransactionService.TransferReceipt parse(
      Properties properties, int index) {
    String prefix = "resource.transfer." + index + '.';
    try {
      String id = properties.getProperty(prefix + "id");
      String domain = properties.getProperty("resource.authority-domain");
      long sequence = Long.parseLong(properties.getProperty(prefix + "sequence"));
      NationId payer = new NationId(UUID.fromString(properties.getProperty(prefix + "payer")));
      NationId receiver =
          new NationId(UUID.fromString(properties.getProperty(prefix + "receiver")));
      Map<String, Long> resources = decodeResources(properties.getProperty(prefix + "resources"));
      var category =
          NationResourceTransactionService.Category.valueOf(
              properties.getProperty(prefix + "category"));
      String description = properties.getProperty(prefix + "description", "");
      long appliedAt = Long.parseLong(properties.getProperty(prefix + "appliedAt"));
      return new NationResourceTransactionService.TransferReceipt(
          id,
          domain,
          sequence,
          payer,
          receiver,
          resources,
          category,
          description,
          Instant.ofEpochMilli(appliedAt));
    } catch (RuntimeException error) {
      throw new IllegalStateException(
          "Resource transfer receipt is corrupt at index " + index, error);
    }
  }

  static Map<String, Long> decodeResources(String value) {
    Map<String, Long> result = new TreeMap<>();
    if (value == null || value.isBlank())
      throw new IllegalArgumentException("Receipt resources are missing");
    for (String part : value.split(";")) {
      int separator = part.indexOf('=');
      if (separator < 1 || separator == part.length() - 1)
        throw new IllegalArgumentException("Invalid resource receipt");
      String type = part.substring(0, separator);
      long amount = Long.parseLong(part.substring(separator + 1));
      if (type.isBlank() || amount < 1L || result.putIfAbsent(type, amount) != null) {
        throw new IllegalArgumentException("Invalid resource receipt");
      }
    }
    return Map.copyOf(result);
  }

  static String encodeResources(Map<String, Long> resources) {
    return resources.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .map(entry -> entry.getKey() + '=' + entry.getValue())
        .collect(java.util.stream.Collectors.joining(";"));
  }

  private static int parseCount(String raw) {
    int count;
    try {
      count = Integer.parseInt(raw == null ? "0" : raw);
    } catch (NumberFormatException error) {
      throw new IllegalStateException("Resource transfer receipt count is corrupt", error);
    }
    if (count < 0 || count > 5_000_000)
      throw new IllegalStateException("Resource transfer receipt count is invalid");
    return count;
  }
}
