package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

/**
 * Canonical versioned execution ledger stored in the same snapshot as quota usage and route stats.
 */
final class TradeExecutionStore {
  static final String PREFIX = "resource.trade-executions.";

  private TradeExecutionStore() {}

  static void write(Properties state, Map<String, TradeExecution> executions) {
    state.keySet().removeIf(key -> key instanceof String text && text.startsWith(PREFIX));
    state.setProperty(PREFIX + "version", "1");
    state.setProperty(PREFIX + "count", Integer.toString(executions.size()));
    for (var entry : executions.entrySet()) {
      var value = entry.getValue();
      if (!entry.getKey().equals(value.executionId()))
        throw new IllegalStateException("Invalid execution identity");
      writeRow(state, value);
    }
    state.setProperty(PREFIX + "head", fingerprint(state));
  }

  private static void writeRow(Properties state, TradeExecution value) {
    String row = PREFIX + "row." + hash(value.executionId()) + ".";
    put(state, row, "id", value.executionId());
    put(state, row, "agreement", value.agreementId());
    put(state, row, "resource-domain", value.resourceDomain());
    put(state, row, "treasury-domain", value.treasuryDomain());
    put(state, row, "exporter", value.exporter());
    put(state, row, "importer", value.importer());
    put(state, row, "resource", value.resourceId());
    put(state, row, "amount", value.amount());
    put(state, row, "price", value.pricePerUnit());
    put(state, row, "total", value.totalPrice());
    put(state, row, "created", value.createdAt().toEpochMilli());
    put(state, row, "expires", value.expiresAt().toEpochMilli());
    put(state, row, "export-approval", value.exporterApproval());
    put(state, row, "import-approval", value.importerApproval());
    put(state, row, "system", value.system());
    put(state, row, "state", value.state());
    put(state, row, "route", value.routeId());
    put(state, row, "sequence", value.deliverySequence());
    put(
        state,
        row,
        "finished",
        value.finishedAt() == null ? "" : value.finishedAt().toEpochMilli());
    String holds =
        value.reservations().stream()
            .sorted(Comparator.comparing(r -> r.quotaId().toString()))
            .map(r -> r.quotaId() + ":" + r.start().toEpochMilli() + ":" + r.reset().toEpochMilli())
            .collect(java.util.stream.Collectors.joining(";"));
    put(state, row, "reservations", holds);
  }

  static Map<String, TradeExecution> read(Properties state, ResourceStateStorage storage) {
    Set<String> keys = new TreeSet<>();
    for (String key : state.stringPropertyNames()) if (key.startsWith(PREFIX)) keys.add(key);
    if (keys.isEmpty()) return Map.of();
    try {
      if (!"1".equals(state.getProperty(PREFIX + "version"))
          || !fingerprint(state).equals(state.getProperty(PREFIX + "head")))
        throw new IllegalArgumentException("Trade ledger fingerprint/version mismatch");
      int count = Integer.parseInt(state.getProperty(PREFIX + "count"));
      if (count < 0
          || (long) count * 20 + 3 != keys.size()
          || !Integer.toString(count).equals(state.getProperty(PREFIX + "count")))
        throw new IllegalArgumentException("Invalid execution count");
      Map<String, TradeExecution> executions = new LinkedHashMap<>();
      for (String key : keys) {
        if (!key.startsWith(PREFIX + "row.") || !key.endsWith(".id")) continue;
        String row = key.substring(0, key.length() - 2);
        String id = required(state, row + "id");
        List<TradeExecution.QuotaReservation> holds = new ArrayList<>();
        String reservations = required(state, row + "reservations");
        if (!reservations.isEmpty())
          for (String part : reservations.split(";", -1)) {
            String[] pieces = part.split(":", -1);
            if (pieces.length != 3) throw new IllegalArgumentException("Invalid reservation");
            holds.add(
                new TradeExecution.QuotaReservation(
                    UUID.fromString(pieces[0]),
                    Instant.ofEpochMilli(Long.parseLong(pieces[1])),
                    Instant.ofEpochMilli(Long.parseLong(pieces[2]))));
          }
        var value =
            new TradeExecution(
                id,
                UUID.fromString(required(state, row + "agreement")),
                required(state, row + "resource-domain"),
                required(state, row + "treasury-domain"),
                NationId.fromString(required(state, row + "exporter")),
                NationId.fromString(required(state, row + "importer")),
                required(state, row + "resource"),
                Long.parseLong(required(state, row + "amount")),
                Double.parseDouble(required(state, row + "price")),
                new BigDecimal(required(state, row + "total")),
                time(state, row + "created"),
                time(state, row + "expires"),
                uuid(state, row + "export-approval"),
                uuid(state, row + "import-approval"),
                bool(state, row + "system"),
                TradeExecution.State.valueOf(required(state, row + "state")),
                holds,
                uuid(state, row + "route"),
                Long.parseLong(required(state, row + "sequence")),
                required(state, row + "finished").isEmpty() ? null : time(state, row + "finished"));
        if (!value.resourceDomain().equals(state.getProperty("resource.authority-domain"))
            || executions.put(id, value) != null)
          throw new IllegalArgumentException("Execution domain/identity mismatch");
        Properties canonical = new Properties();
        writeRow(canonical, value);
        for (String field : canonical.stringPropertyNames())
          if (!canonical.getProperty(field).equals(state.getProperty(field)))
            throw new IllegalArgumentException("Noncanonical execution field " + field);
      }
      if (executions.size() != count) throw new IllegalArgumentException("Missing execution rows");
      validateReservations(state, executions);
      if (!executions.isEmpty()) {
        if (storage == null)
          throw new IllegalArgumentException("Delivery receipt authority unavailable");
        storage.validateTradeDeliveries(state, executions);
      }
      return Map.copyOf(executions);
    } catch (RuntimeException error) {
      throw new IllegalStateException("Trade execution state requires recovery", error);
    }
  }

  static final class DeliveryVerifier {
    private final Map<String, TradeExecution> expected = new LinkedHashMap<>();
    private final Set<String> missing = new HashSet<>();
    private final Set<String> seen = new HashSet<>();

    DeliveryVerifier(Map<String, TradeExecution> executions) {
      for (var execution : executions.values()) {
        String id = execution.operationId("delivery");
        if (expected.put(id, execution) != null)
          throw new IllegalStateException("Duplicate delivery identity");
        if (execution.state() == TradeExecution.State.COMPLETED) missing.add(id);
      }
    }

    Set<String> ids() {
      return expected.keySet();
    }

    void accept(NationResourceTransactionService.TransferReceipt receipt) {
      var execution = expected.get(receipt.transactionId());
      if (execution == null) return;
      if (!seen.add(receipt.transactionId())
          || !NativeTradeExecution.deliveryMatches(execution, receipt)
          || (execution.state() != TradeExecution.State.COMPLETED
              && execution.state() != TradeExecution.State.PAID))
        throw new IllegalStateException("Trade delivery changed or premature");
      if (execution.state() == TradeExecution.State.COMPLETED
          && (execution.deliverySequence() != receipt.sequence()
              || !execution.finishedAt().equals(receipt.appliedAt())))
        throw new IllegalStateException("Trade completion lacks matching delivery");
      missing.remove(receipt.transactionId());
    }

    void finish() {
      if (!missing.isEmpty()) throw new IllegalStateException("Trade completion receipt missing");
    }
  }

  private static void validateReservations(
      Properties state, Map<String, TradeExecution> executions) {
    var snapshot = ResourceStateCodec.snapshotFromProperties(state, ResourceModule.RESOURCE_TYPES);
    Map<UUID, Long> reserved = new HashMap<>();
    for (var execution : executions.values()) {
      for (var hold : execution.reservations()) {
        var quota = snapshot.quotas().get(hold.quotaId());
        if (quota == null) throw new IllegalArgumentException("Missing reserved quota");
        if (!quota.resourceId().equals(execution.resourceId())
            || !(quota.nationId().equals(execution.exporter())
                    && quota.type()
                        == dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType
                            .EXPORT
                || quota.nationId().equals(execution.importer())
                    && quota.type()
                        == dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType
                            .IMPORT))
          throw new IllegalArgumentException("Reserved quota terms changed");
        if (execution.state() != TradeExecution.State.REJECTED
            && execution.state() != TradeExecution.State.REFUNDED
            && quota.startTime().equals(hold.start())
            && quota.resetTime().equals(hold.reset()))
          reserved.merge(hold.quotaId(), execution.amount(), Math::addExact);
      }
      if (execution.routeId() != null) {
        var route = snapshot.routes().get(execution.routeId());
        if (route == null || !route.connectsBoth(execution.exporter(), execution.importer()))
          throw new IllegalArgumentException("Trade execution route changed");
      }
    }
    for (var entry : reserved.entrySet())
      if (entry.getValue() > snapshot.quotas().get(entry.getKey()).currentAmount())
        throw new IllegalArgumentException("Missing reserved quota usage");
  }

  static String hash(String value) {
    try {
      return HexFormat.of()
          .formatHex(
              MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  private static String fingerprint(Properties state) {
    MessageDigest digest;
    try {
      digest = MessageDigest.getInstance("SHA-256");
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
    state.stringPropertyNames().stream()
        .filter(key -> key.startsWith(PREFIX) && !key.equals(PREFIX + "head"))
        .sorted()
        .forEach(
            key -> {
              String value = state.getProperty(key);
              // Preserve the V1 character-length framing byte for byte without a ledger-sized
              // string.
              digest.update(
                  (key.length() + ":" + key + value.length() + ":" + value)
                      .getBytes(StandardCharsets.UTF_8));
            });
    return HexFormat.of().formatHex(digest.digest());
  }

  private static void put(Properties state, String row, String field, Object value) {
    state.setProperty(row + field, Objects.toString(value, ""));
  }

  private static String required(Properties state, String key) {
    return Objects.requireNonNull(state.getProperty(key), key);
  }

  private static UUID uuid(Properties state, String key) {
    String value = required(state, key);
    return value.isEmpty() ? null : UUID.fromString(value);
  }

  private static Instant time(Properties state, String key) {
    return Instant.ofEpochMilli(Long.parseLong(required(state, key)));
  }

  private static boolean bool(Properties state, String key) {
    String value = required(state, key);
    if (!value.equals("true") && !value.equals("false")) throw new IllegalArgumentException(key);
    return Boolean.parseBoolean(value);
  }
}
