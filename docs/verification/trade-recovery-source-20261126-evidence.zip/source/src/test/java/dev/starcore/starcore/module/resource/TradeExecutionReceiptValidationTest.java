package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class TradeExecutionReceiptValidationTest {
  @TempDir Path directory;
  static final Instant TIME = Instant.parse("2026-11-26T00:00:00Z");
  static final String DOMAIN = new UUID(0, 30).toString();
  static final String TREASURY = new UUID(0, 31).toString();
  static final NationId EXPORTER = new NationId(new UUID(0, 1));
  static final NationId IMPORTER = new NationId(new UUID(0, 2));

  record Fixture(Properties state, Map<String, TradeExecution> executions) {}

  @AfterEach
  void close() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static TradeExecution execution(String id, TradeExecution.State state, long sequence) {
    return new TradeExecution(
        id,
        new UUID(0, 10),
        DOMAIN,
        TREASURY,
        EXPORTER,
        IMPORTER,
        "industrial",
        2,
        2.5,
        new BigDecimal("5.00"),
        TIME,
        TIME.plusSeconds(3600),
        null,
        null,
        true,
        state,
        List.of(),
        null,
        sequence,
        state.terminal() ? TIME.plusSeconds(1) : null);
  }

  static NationResourceTransactionService.TransferReceipt receipt(
      TradeExecution execution, long sequence) {
    var request = NativeTradeExecution.delivery(execution);
    return new NationResourceTransactionService.TransferReceipt(
        request.transactionId(),
        DOMAIN,
        sequence,
        EXPORTER,
        IMPORTER,
        request.resources(),
        request.category(),
        request.description(),
        TIME.plusSeconds(1));
  }

  static Fixture fixture(int count) {
    var state =
        ResourceStateCodec.toProperties(
            Map.of(
                EXPORTER, Map.of("industrial", 100L), IMPORTER, Map.of("industrial", count * 2L)));
    state.setProperty("resource.authority-domain", DOMAIN);
    Map<String, TradeExecution> executions = new LinkedHashMap<>();
    for (int i = 1; i <= count; i++) {
      var execution = execution("complete-" + i, TradeExecution.State.COMPLETED, i);
      executions.put(execution.executionId(), execution);
      ResourceTransferReceiptStore.append(state, receipt(execution, i));
    }
    var paid = execution("paid", TradeExecution.State.PAID, 0);
    executions.put(paid.executionId(), paid);
    ResourceTransferReceiptStore.append(state, receipt(paid, count + 1));
    for (var status :
        List.of(
            TradeExecution.State.AWAITING_APPROVAL,
            TradeExecution.State.PREPARED,
            TradeExecution.State.REFUND_PENDING,
            TradeExecution.State.REJECTED,
            TradeExecution.State.REFUNDED)) {
      var value = execution(status.name(), status, 0);
      executions.put(value.executionId(), value);
    }
    TradeExecutionStore.write(state, executions);
    return new Fixture(state, Map.copyOf(executions));
  }

  static final ResourceStateStorage SNAPSHOT_ONLY =
      new ResourceStateStorage() {
        public Properties load() {
          throw new AssertionError("Do not reopen a file during snapshot validation");
        }

        public void save(Properties ignored) {
          throw new AssertionError("Recovery must not write");
        }
      };

  @Test
  void fileValidatesAllExecutionsAgainstTheAlreadyLoadedSnapshot() {
    var fixture = fixture(513);
    var before = new Properties();
    before.putAll(fixture.state());
    assertEquals(fixture.executions(), TradeExecutionStore.read(fixture.state(), SNAPSHOT_ONLY));
    assertEquals(before, fixture.state());
    assertEquals(
        fixture.executions(),
        TradeExecutionStore.read(new Properties(fixture.state()), SNAPSHOT_ONLY));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "missing",
        "id",
        "resources",
        "payer",
        "receiver",
        "category",
        "description",
        "time",
        "sequence",
        "duplicate",
        "domain",
        "orphan",
        "huge-count",
        "paid-mismatch"
      })
  void fileRejectsMissingConflictingOrHiddenDeliveryEvidence(String damage) {
    var fixture = fixture(3);
    var p = fixture.state();
    String prefix = "resource.transfer.1.";
    switch (damage) {
      case "missing" -> p.remove(prefix + "id");
      case "id" -> p.setProperty(prefix + "id", "unrelated");
      case "resources" -> p.setProperty(prefix + "resources", "industrial=3");
      case "payer" -> p.setProperty(prefix + "payer", new UUID(0, 99).toString());
      case "receiver" -> p.setProperty(prefix + "receiver", new UUID(0, 99).toString());
      case "category" -> p.setProperty(prefix + "category", "RESEARCH");
      case "description" -> p.setProperty(prefix + "description", "changed");
      case "time" -> p.setProperty(prefix + "appliedAt", "1");
      case "sequence" -> p.setProperty(prefix + "sequence", "99");
      case "duplicate" -> p.setProperty(prefix + "id", p.getProperty("resource.transfer.0.id"));
      case "domain" -> p.setProperty("resource.authority-domain", new UUID(0, 99).toString());
      case "orphan" -> p.setProperty("resource.transfer.50.id", "hidden");
      case "huge-count" -> p.setProperty("resource.transfer.count", "5000000");
      case "paid-mismatch" -> p.setProperty("resource.transfer.3.resources", "industrial=9");
      default -> throw new AssertionError();
    }
    assertTimeout(
        Duration.ofSeconds(2),
        () ->
            assertThrows(
                IllegalStateException.class, () -> TradeExecutionStore.read(p, SNAPSHOT_ONLY)));
  }

  @ParameterizedTest
  @EnumSource(
      value = TradeExecution.State.class,
      names = {"AWAITING_APPROVAL", "PREPARED", "REFUND_PENDING", "REJECTED", "REFUNDED"})
  void fileRejectsDeliveryInAStateThatCannotHaveDelivered(TradeExecution.State state) {
    var fixture = fixture(3);
    var execution = fixture.executions().get(state.name());
    ResourceTransferReceiptStore.append(fixture.state(), receipt(execution, 5));
    assertThrows(
        IllegalStateException.class,
        () -> TradeExecutionStore.read(fixture.state(), SNAPSHOT_ONLY));
  }

  @Test
  void versionOneFingerprintRetainsOriginalCharacterFraming() throws Exception {
    var fixture = fixture(3);
    var values = new LinkedHashMap<>(fixture.executions());
    var value = execution("trade:version-one.legacy_1", TradeExecution.State.AWAITING_APPROVAL, 0);
    values.put(value.executionId(), value);
    TradeExecutionStore.write(fixture.state(), values);
    var oldEncoding = new StringBuilder();
    fixture.state().stringPropertyNames().stream()
        .filter(key -> key.startsWith(TradeExecutionStore.PREFIX) && !key.endsWith(".head"))
        .sorted()
        .forEach(
            key -> {
              String text = fixture.state().getProperty(key);
              oldEncoding
                  .append(key.length())
                  .append(':')
                  .append(key)
                  .append(text.length())
                  .append(':')
                  .append(text);
            });
    String oldHead =
        HexFormat.of()
            .formatHex(
                java.security.MessageDigest.getInstance("SHA-256")
                    .digest(
                        oldEncoding.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    assertEquals(oldHead, fixture.state().getProperty(TradeExecutionStore.PREFIX + "head"));
    assertEquals(values, TradeExecutionStore.read(fixture.state(), SNAPSHOT_ONLY));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void productionRouterValidatesFileThenSqlAndKeepsSqlAuthority(String engine) {
    var fixture = fixture(3);
    var db = database(engine);
    var running = new java.util.concurrent.atomic.AtomicBoolean();
    var database =
        new dev.starcore.starcore.core.database.DatabaseService(null, null) {
          public synchronized boolean isRunning() {
            return running.get();
          }

          public synchronized Optional<DataSource> dataSource() {
            return Optional.of(db);
          }
        };
    var persistence =
        new dev.starcore.starcore.core.persistence.PersistenceService(null, null) {
          public Properties loadProperties(String namespace, String name) {
            return fixture.state();
          }

          public void saveProperties(String namespace, String name, Properties value) {
            throw new AssertionError("Validation must not write files");
          }
        };
    var storage =
        new DatabaseAwareResourceStateStorage(
            "test", database, persistence, Logger.getAnonymousLogger());
    assertEquals(fixture.executions(), TradeExecutionStore.read(storage.load(), storage));
    running.set(true);
    var migrated = storage.load();
    assertFalse(
        migrated.containsKey("resource.transfer.0.id"), "SQL receipts are outside the snapshot");
    assertEquals(fixture.executions(), TradeExecutionStore.read(migrated, storage));
    running.set(false);
    assertEquals(fixture.executions(), TradeExecutionStore.read(storage.load(), storage));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void laterBatchFailureRollsBackAndClosesBeforeACompleteRetry(String engine) {
    var fixture = fixture(513);
    var counter = new Counter(database(engine));
    var storage =
        new SqlResourceStateStorage(counter.source(), fixture.state(), Logger.getAnonymousLogger());
    var snapshot = storage.load();
    counter.reset();
    counter.failAtQuery = 2;
    assertThrows(IllegalStateException.class, () -> TradeExecutionStore.read(snapshot, storage));
    assertEquals(1, counter.connections.get());
    assertEquals(1, counter.rollbacks.get());
    assertEquals(0, counter.commits.get());
    assertEquals(1, counter.closes.get());
    counter.reset();
    assertEquals(fixture.executions(), TradeExecutionStore.read(snapshot, storage));
    assertEquals(1, counter.commits.get());
    assertEquals(0, counter.rollbacks.get());
    assertEquals(1, counter.closes.get());
  }

  DataSource database(String engine) {
    if (engine.equals("sqlite")) {
      var source = new org.sqlite.SQLiteDataSource();
      source.setUrl("jdbc:sqlite:" + directory.resolve("trade.db"));
      return source;
    }
    var source = new org.h2.jdbcx.JdbcDataSource();
    source.setURL("jdbc:h2:mem:trade-receipt-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
    return source;
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void sqlChecksMoreThanTwoPagesInOneReadTransactionAndRejectsInteriorChanges(String engine)
      throws Exception {
    var fixture = fixture(513);
    var db = database(engine);
    var counter = new Counter(db);
    var storage =
        new SqlResourceStateStorage(counter.source(), fixture.state(), Logger.getAnonymousLogger());
    var loaded = storage.load();
    counter.reset();
    assertEquals(fixture.executions(), TradeExecutionStore.read(loaded, storage));
    assertEquals(1, counter.connections.get(), "Recovery connections must not grow with history");
    assertTrue(counter.maximumParameters.get() <= 256, "Receipt query must remain bounded");
    assertTrue(counter.receiptQueries.get() <= 3, "No query per execution");
    assertTrue(counter.receiptQueries.get() >= 1);
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.executeUpdate(
          "UPDATE starcore_resource_transfer_receipts SET resources='industrial=999' WHERE"
              + " sequence=257");
    }
    assertThrows(IllegalStateException.class, () -> TradeExecutionStore.read(loaded, storage));
  }

  static java.util.stream.Stream<Arguments> sqlDamage() {
    return java.util.stream.Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                java.util.stream.Stream.of(
                        "missing",
                        "description",
                        "payer",
                        "receiver",
                        "domain",
                        "time",
                        "sequence",
                        "paid-mismatch",
                        "premature",
                        "stale-ledger",
                        "stale-domain")
                    .map(damage -> Arguments.of(engine, damage)));
  }

  @ParameterizedTest
  @MethodSource("sqlDamage")
  void sqlRejectsMissingChangedPrematureOrStaleEvidence(String engine, String damage)
      throws Exception {
    var fixture = fixture(3);
    var db = database(engine);
    var storage = new SqlResourceStateStorage(db, fixture.state(), Logger.getAnonymousLogger());
    var loaded = storage.load();
    if (damage.equals("premature")) {
      storage.saveTransfer(loaded, receipt(fixture.executions().get("PREPARED"), 5));
    } else if (damage.equals("stale-ledger")) {
      var changed = new LinkedHashMap<>(fixture.executions());
      changed.put("next", execution("next", TradeExecution.State.AWAITING_APPROVAL, 0));
      TradeExecutionStore.write(loaded, changed);
      storage.save(loaded);
      loaded = fixture.state();
    } else {
      String statement =
          switch (damage) {
            case "missing" -> "DELETE FROM starcore_resource_transfer_receipts WHERE sequence=2";
            case "description" ->
                "UPDATE starcore_resource_transfer_receipts SET description='changed' WHERE"
                    + " sequence=2";
            case "payer" ->
                "UPDATE starcore_resource_transfer_receipts SET"
                    + " payer_nation_id='00000000-0000-0000-0000-000000000099' WHERE sequence=2";
            case "receiver" ->
                "UPDATE starcore_resource_transfer_receipts SET"
                    + " receiver_nation_id='00000000-0000-0000-0000-000000000099' WHERE sequence=2";
            case "domain" ->
                "UPDATE starcore_resource_transfer_receipts SET"
                    + " authority_domain_id='00000000-0000-0000-0000-000000000099' WHERE"
                    + " sequence=2";
            case "time" ->
                "UPDATE starcore_resource_transfer_receipts SET applied_at=1 WHERE sequence=2";
            case "sequence" ->
                "UPDATE starcore_resource_transfer_receipts SET sequence=99 WHERE sequence=2";
            case "paid-mismatch" ->
                "UPDATE starcore_resource_transfer_receipts SET resources='industrial=99' WHERE"
                    + " sequence=4";
            case "stale-domain" ->
                "UPDATE starcore_resource_state SET"
                    + " property_value='00000000-0000-0000-0000-000000000099' WHERE"
                    + " property_key='resource.authority-domain'";
            default -> throw new AssertionError();
          };
      try (var c = db.getConnection();
          var s = c.createStatement()) {
        s.executeUpdate(statement);
      }
    }
    Properties snapshot = loaded;
    assertThrows(IllegalStateException.class, () -> TradeExecutionStore.read(snapshot, storage));
  }

  static final class Counter {
    final DataSource actual;
    final AtomicInteger connections = new AtomicInteger(),
        receiptQueries = new AtomicInteger(),
        maximumParameters = new AtomicInteger(),
        commits = new AtomicInteger(),
        rollbacks = new AtomicInteger(),
        closes = new AtomicInteger();
    int failAtQuery;

    Counter(DataSource actual) {
      this.actual = actual;
    }

    void reset() {
      connections.set(0);
      receiptQueries.set(0);
      maximumParameters.set(0);
      commits.set(0);
      rollbacks.set(0);
      closes.set(0);
      failAtQuery = 0;
    }

    DataSource source() {
      return (DataSource)
          Proxy.newProxyInstance(
              DataSource.class.getClassLoader(),
              new Class<?>[] {DataSource.class},
              (proxy, method, args) -> {
                Object value = invoke(actual, method, args);
                if (!(value instanceof Connection connection)) return value;
                connections.incrementAndGet();
                return Proxy.newProxyInstance(
                    Connection.class.getClassLoader(),
                    new Class<?>[] {Connection.class},
                    (p, m, a) -> {
                      if (m.getName().equals("commit")) commits.incrementAndGet();
                      if (m.getName().equals("rollback")) rollbacks.incrementAndGet();
                      if (m.getName().equals("close")) closes.incrementAndGet();
                      if (m.getName().equals("prepareStatement")
                          && ((String) a[0])
                              .startsWith("SELECT * FROM starcore_resource_transfer_receipts")) {
                        assertFalse(connection.getAutoCommit());
                        assertEquals(
                            Connection.TRANSACTION_SERIALIZABLE,
                            connection.getTransactionIsolation());
                        if (receiptQueries.incrementAndGet() == failAtQuery)
                          throw new SQLException("Injected later receipt batch read failure");
                        maximumParameters.accumulateAndGet(
                            (int) ((String) a[0]).chars().filter(c -> c == '?').count(), Math::max);
                      }
                      return invoke(connection, m, a);
                    });
              });
    }
  }

  static Object invoke(Object target, Method method, Object[] args) throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException error) {
      throw error.getCause();
    }
  }
}
