package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.ResourceTradeService.ExecutionStatus.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.*;
import dev.starcore.starcore.module.resource.ResourceTradeService.ExecutionRequest;
import dev.starcore.starcore.module.resource.model.*;
import dev.starcore.starcore.module.treasury.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.stream.Stream;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class NativeTradeExecutionRecoveryTest {
  @TempDir Path directory;
  static final NationId IMPORTER = new NationId(new UUID(0, 1));
  static final NationId EXPORTER = new NationId(new UUID(0, 2));
  static final UUID EXPORT_ACTOR = new UUID(0, 4), IMPORT_ACTOR = new UUID(0, 5);

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("resource");
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static Stream<Arguments> boundaries() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(1, 2, 3, 4, 5)
                    .flatMap(
                        point ->
                            Stream.of("before", "after", "unreadable")
                                .map(failure -> Arguments.of(engine, point, failure))));
  }

  static Stream<Arguments> refunds() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(1, 2)
                    .flatMap(
                        point ->
                            Stream.of("before", "after", "unreadable")
                                .map(failure -> Arguments.of(engine, point, failure))));
  }

  @ParameterizedTest
  @MethodSource("refunds")
  void refundCheckpointsCanRestartWithoutPayingOrReleasingTwice(
      String engine, int point, String failure) throws Exception {
    var f = fixture(engine);
    f.storage.arm(4, "before");
    assertEquals(UNKNOWN, f.execute("refund-checkpoint").status());
    assertTrue(f.module.consume(EXPORTER, "industrial", 6));
    f.storage.arm(point, failure);
    var initial = f.service.retryTradeExecution("refund-checkpoint", null);
    assertTrue(Set.of(UNKNOWN, REFUNDED).contains(initial.status()));
    f.restart();
    assertEquals(REFUNDED, f.service.retryTradeExecution("refund-checkpoint", null).status());
    assertEquals(REFUNDED, f.service.retryTradeExecution("refund-checkpoint", null).status());
    f.assertBalances("100.00", "10.00");
    assertEquals(0, f.service.getQuota(f.exportQuota).orElseThrow().currentAmount());
    assertEquals(0, f.service.getQuota(f.importQuota).orElseThrow().currentAmount());
    assertEquals(0, f.module.amount(IMPORTER, "industrial"));
    assertEquals(0, f.service.getTradeRoute(f.route).orElseThrow().totalTradeVolume());
  }

  @ParameterizedTest
  @CsvSource({
    "file,before",
    "file,after",
    "file,unreadable",
    "sqlite,before",
    "sqlite,after",
    "sqlite,unreadable",
    "h2,before",
    "h2,after",
    "h2,unreadable"
  })
  void directQuotaUseReconcilesItsSaveBeforeReturning(String engine, String failure)
      throws Exception {
    var f = fixture(engine);
    f.storage.arm(1, failure);
    if (failure.equals("unreadable")) {
      assertThrows(IllegalStateException.class, () -> f.service.useQuota(f.exportQuota, 3));
      f.storage.unreadable = false;
      assertThrows(IllegalStateException.class, () -> f.service.getQuota(f.exportQuota));
    } else assertEquals(failure.equals("after"), f.service.useQuota(f.exportQuota, 3));
    f.restart();
    assertEquals(
        failure.equals("before") ? 0 : 3,
        f.service.getQuota(f.exportQuota).orElseThrow().currentAmount());
  }

  @Test
  void recoveryTimerResumesApprovedPlayersButNeverApprovesNewProposal() throws Exception {
    var f = fixture("file");
    assertEquals(AWAITING_APPROVAL, f.approve("timer", EXPORT_ACTOR).status());
    f.service.recoverExecutions(32);
    f.assertBalances("100.00", "10.00");
    f.storage.arm(4, "before"); // approval, PREPARED, PAID, delivery.
    assertEquals(UNKNOWN, f.approve("timer", IMPORT_ACTOR).status());
    f.restart();
    f.service.recoverExecutions(1);
    f.assertCompleted("timer");
  }

  @ParameterizedTest
  @CsvSource({
    "file,before",
    "file,after",
    "file,unreadable",
    "sqlite,before",
    "sqlite,after",
    "sqlite,unreadable",
    "h2,before",
    "h2,after",
    "h2,unreadable"
  })
  void savedSecondApprovalResumesWithoutAskingEitherFounderToApproveAgain(
      String engine, String failure) throws Exception {
    var f = fixture(engine);
    assertEquals(AWAITING_APPROVAL, f.approve("consent", EXPORT_ACTOR).status());
    f.storage.arm(1, failure);
    var result = f.approve("consent", IMPORT_ACTOR);
    assertEquals(failure.equals("after") ? COMPLETED : UNKNOWN, result.status());
    f.restart();
    if (failure.equals("before")) {
      f.service.recoverExecutions(32);
      assertEquals(
          AWAITING_APPROVAL, f.service.retryTradeExecution("consent", IMPORT_ACTOR).status());
      assertEquals(COMPLETED, f.approve("consent", IMPORT_ACTOR).status());
    } else {
      f.service.recoverExecutions(32);
      assertEquals(COMPLETED, f.service.retryTradeExecution("consent", EXPORT_ACTOR).status());
    }
    f.assertCompleted("consent");
  }

  @Test
  void concurrentOriginalIdsSerializeAndCompletedEventFailureCannotReplayDelivery()
      throws Exception {
    var f = fixture("file");
    var bus = mock(dev.starcore.starcore.core.event.StarCoreEventBus.class);
    doThrow(new IllegalStateException("subscriber failed")).when(bus).publish(any());
    f.service.setEventBus(bus);
    try (var workers = java.util.concurrent.Executors.newFixedThreadPool(4)) {
      var futures =
          new ArrayList<java.util.concurrent.Future<ResourceTradeService.ExecutionResult>>();
      for (int i = 0; i < 8; i++) futures.add(workers.submit(() -> f.execute("parallel")));
      for (var future : futures)
        assertEquals(COMPLETED, future.get(10, java.util.concurrent.TimeUnit.SECONDS).status());
    }
    f.assertCompleted("parallel");
    verify(bus).publish(any());
  }

  @ParameterizedTest
  @MethodSource("boundaries")
  void eachResourceCheckpointRecoversWithOriginalId(String engine, int point, String failure)
      throws Exception {
    var fixture = fixture(engine);
    fixture.storage.arm(point, failure);
    var initial = fixture.execute("stable");
    assertTrue(Set.of(UNKNOWN, COMPLETED).contains(initial.status()), initial.toString());
    fixture.restart();
    var result = fixture.execute("stable");
    assertEquals(COMPLETED, result.status());
    fixture.assertCompleted("stable");
    assertEquals(COMPLETED, fixture.execute("stable").status());
    fixture.restart();
    fixture.assertCompleted("stable");
    assertEquals(COMPLETED, fixture.service.retryTradeExecution("stable", null).status());
  }

  @ParameterizedTest
  @CsvSource({
    "file,true,false",
    "file,false,false",
    "file,false,true",
    "sqlite,true,false",
    "sqlite,false,false",
    "sqlite,false,true",
    "h2,true,false",
    "h2,false,false",
    "h2,false,true"
  })
  void treasuryFailureIsReconciledWithoutSpeculativeRefund(
      String engine, boolean before, boolean unreadable) throws Exception {
    var fixture = fixture(engine);
    fixture.money.fail(before, unreadable);
    var result = fixture.execute("money");
    assertEquals(before ? REJECTED : unreadable ? UNKNOWN : COMPLETED, result.status());
    fixture.restart();
    result = fixture.execute("money");
    assertEquals(before ? REJECTED : COMPLETED, result.status());
    if (before) {
      fixture.assertBalances("100.00", "10.00");
      assertEquals(0, fixture.service.getQuota(fixture.exportQuota).orElseThrow().currentAmount());
      assertEquals(6, fixture.module.amount(EXPORTER, "industrial"));
    } else fixture.assertCompleted("money");
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void foundersMustBothApproveFrozenIntentAndRetryDoesNotApprove(String engine) throws Exception {
    var f = fixture(engine);
    assertEquals(AWAITING_APPROVAL, f.approve("bilateral", EXPORT_ACTOR).status());
    f.assertBalances("100.00", "10.00");
    assertEquals(0, f.service.getQuota(f.exportQuota).orElseThrow().currentAmount());
    f.restart();
    assertEquals(
        AWAITING_APPROVAL, f.service.retryTradeExecution("bilateral", IMPORT_ACTOR).status());
    f.service.recoverExecutions(32);
    assertNull(f.service.tradeExecution("bilateral").orElseThrow().importerApproval());
    assertEquals(REJECTED, f.approve("bilateral", UUID.randomUUID()).status());
    assertEquals(REJECTED, f.execute("bilateral").status());
    assertEquals(COMPLETED, f.approve("bilateral", IMPORT_ACTOR).status());
    f.restart();
    f.assertCompleted("bilateral");
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void cancelledProposalDoesNotChargeButPaidExecutionSurvivesAgreementRemoval(String engine)
      throws Exception {
    var f = fixture(engine);
    assertEquals(AWAITING_APPROVAL, f.approve("cancelled", EXPORT_ACTOR).status());
    assertTrue(f.service.cancelTradeAgreement(EXPORTER, f.agreement));
    assertEquals(REJECTED, f.approve("cancelled", IMPORT_ACTOR).status());
    f.assertBalances("100.00", "10.00");
    f.agreement =
        f.service.createTradeAgreement(EXPORTER, IMPORTER, "industrial", 2, 2, 3600).agreementId();
    f.clock.time = Instant.now();
    f.storage.arm(4, "before");
    assertEquals(UNKNOWN, f.execute("paid").status());
    assertTrue(f.service.cancelTradeAgreement(EXPORTER, f.agreement));
    assertEquals(COMPLETED, f.service.retryTradeExecution("paid", null).status());
    f.restart();
    f.assertCompleted("paid");
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void refundIsDurableAndDoesNotReleaseNewQuotaWindow(String engine) throws Exception {
    var f = fixture(engine);
    f.storage.arm(4, "before");
    assertEquals(UNKNOWN, f.execute("refund").status());
    assertTrue(f.module.consume(EXPORTER, "industrial", 6));
    assertTrue(f.money.module().withdraw(EXPORTER, new BigDecimal("14.00")));
    assertEquals(UNKNOWN, f.service.retryTradeExecution("refund", null).status());
    assertEquals(
        TradeExecution.State.REFUND_PENDING,
        f.service.tradeExecution("refund").orElseThrow().state());
    var old = f.service.getQuota(f.exportQuota).orElseThrow();
    f.clock.time = old.resetTime().plusMillis(1);
    assertTrue(f.service.useQuota(f.exportQuota, 3));
    f.money.module().deposit(EXPORTER, new BigDecimal("4.00"));
    f.money.fail(false, true);
    assertEquals(UNKNOWN, f.service.retryTradeExecution("refund", null).status());
    f.restart();
    assertEquals(REFUNDED, f.service.retryTradeExecution("refund", null).status());
    assertEquals(3, f.service.getQuota(f.exportQuota).orElseThrow().currentAmount());
    assertEquals(0, f.service.getQuota(f.importQuota).orElseThrow().currentAmount());
    assertEquals(0, f.module.amount(IMPORTER, "industrial"));
    assertEquals(0, f.service.getTradeRoute(f.route).orElseThrow().totalTradeVolume());
    assertEquals(REFUNDED, f.service.retryTradeExecution("refund", null).status());
    f.assertBalances("100.00", "0.00");
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void allMatchingQuotasLimitExecutionAndConflictingIdCannotExecuteAnotherAgreement(String engine)
      throws Exception {
    var f = fixture(engine);
    f.service.createQuota(EXPORTER, "industrial", 1, 3600, ResourceQuota.QuotaType.EXPORT);
    assertEquals(REJECTED, f.execute("limited").status());
    f.assertBalances("100.00", "10.00");
    assertEquals(0, f.service.getQuota(f.exportQuota).orElseThrow().currentAmount());
    var second = f.service.createTradeAgreement(EXPORTER, IMPORTER, "industrial", 1, 1, 3600);
    f.clock.time = Instant.now();
    assertEquals(
        REJECTED,
        f.service
            .executeTradeAgreement(new ExecutionRequest("limited", second.agreementId(), null))
            .status());
    assertEquals(
        COMPLETED,
        f.service
            .executeTradeAgreement(new ExecutionRequest("new", second.agreementId(), null))
            .status());
    f.assertBalances("99.00", "11.00");
  }

  @Test
  void authorityChangeAndMismatchedMoneyReceiptLeaveIntentUnresolved() throws Exception {
    var f = fixture("file");
    f.storage.arm(3, "before");
    assertEquals(UNKNOWN, f.execute("receipt").status());
    var real = f.money.module();
    var treasury =
        mock(TreasuryService.class, withSettings().extraInterfaces(NationTransferService.class));
    var transfers = (NationTransferService) treasury;
    when(treasury.authorityDomainId()).thenReturn(UUID.randomUUID().toString());
    f.attach(treasury);
    assertEquals(UNKNOWN, f.service.retryTradeExecution("receipt", null).status());
    verify(transfers, never()).transfer(any());
    verify(transfers, never()).transferReceipt(any());
    when(treasury.authorityDomainId()).thenReturn(real.authorityDomainId());
    var execution = f.service.tradeExecution("receipt").orElseThrow();
    var debit = NativeTradeExecution.money(execution, false);
    when(transfers.transferReceipt(debit.transactionId()))
        .thenReturn(
            Optional.of(
                new NationTransferService.TransferReceipt(
                    debit.transactionId(),
                    debit.payerId(),
                    debit.receiverId(),
                    debit.amount(),
                    debit.category(),
                    "wrong-description",
                    Instant.now())));
    assertEquals(UNKNOWN, f.service.retryTradeExecution("receipt", null).status());
    verify(transfers, never()).transfer(any());
    assertEquals(6, f.module.amount(EXPORTER, "industrial"));
    f.restart();
    assertEquals(COMPLETED, f.service.retryTradeExecution("receipt", null).status());
    f.assertCompleted("receipt");
  }

  @Test
  void terminalDeliveryAndLedgerCorruptionQuarantineWithoutOverwritingSource() throws Exception {
    var f = fixture("file");
    assertEquals(COMPLETED, f.execute("completed").status());
    var saved = f.storage.load();
    String row = TradeExecutionStore.PREFIX + "row." + TradeExecutionStore.hash("completed") + ".";
    for (String field :
        List.of("amount", "sequence", "state", "resource-domain", "reservations", "unknown")) {
      var corrupt = new Properties();
      corrupt.putAll(saved);
      corrupt.setProperty(row + field, "corrupt");
      f.storage.delegate.save(corrupt);
      f.attach(f.money.module());
      assertEquals("", f.module.authorityDomainId());
      assertThrows(IllegalStateException.class, () -> f.service.tradeExecution("completed"));
      assertFalse(f.module.grant(EXPORTER, "industrial", 1));
      assertEquals(corrupt, f.storage.load());
    }
    f.storage.delegate.save(saved);
    f.restart();
    f.assertCompleted("completed");
  }

  Fixture fixture(String engine) throws Exception {
    var helper = new InventoryCommitRecoveryTest();
    helper.directory = directory.resolve("resources");
    Files.createDirectories(helper.directory);
    return new Fixture(
        new FaultStorage(helper.fixture(engine).storage()),
        new TradeTreasuryFixture(engine, directory.resolve("money")));
  }

  static final class MutableClock extends Clock {
    Instant time = Instant.now();

    public java.time.ZoneId getZone() {
      return ZoneOffset.UTC;
    }

    public Clock withZone(ZoneId zone) {
      return this;
    }

    public Instant instant() {
      return time;
    }
  }

  static final class Fixture {
    final FaultStorage storage;
    final TradeTreasuryFixture money;
    final MutableClock clock = new MutableClock();
    final NationService nations = mock(NationService.class);
    ResourceModule module;
    SimpleResourceTradeService service;
    UUID agreement, exportQuota, importQuota, route;

    Fixture(FaultStorage storage, TradeTreasuryFixture money) throws Exception {
      this.storage = storage;
      this.money = money;
      for (var entry : Map.of(EXPORT_ACTOR, EXPORTER, IMPORT_ACTOR, IMPORTER).entrySet()) {
        var nation = mock(Nation.class);
        when(nation.id()).thenReturn(entry.getValue());
        when(nation.founderId()).thenReturn(entry.getKey());
        when(nations.nationOf(entry.getKey())).thenReturn(Optional.of(nation));
      }
      attach(money.module());
      agreement =
          service.createTradeAgreement(EXPORTER, IMPORTER, "industrial", 2, 2, 3600).agreementId();
      clock.time = Instant.now();
      exportQuota =
          service
              .createQuota(EXPORTER, "industrial", 10, 3600, ResourceQuota.QuotaType.EXPORT)
              .quotaId();
      importQuota =
          service
              .createQuota(IMPORTER, "industrial", 10, 3600, ResourceQuota.QuotaType.IMPORT)
              .quotaId();
      route = service.createTradeRoute(EXPORTER, IMPORTER, "route").routeId();
      long inherited = module.amount(IMPORTER, "industrial");
      if (inherited > 0) assertTrue(module.consume(IMPORTER, "industrial", inherited));
      assertTrue(module.grant(EXPORTER, "industrial", 6));
    }

    void attach(TreasuryService treasury) throws Exception {
      module = new ResourceModule();
      service = new SimpleResourceTradeService(module, treasury, clock);
      TradeSnapshotValidationTest.set(module, "stateStorage", storage);
      TradeSnapshotValidationTest.set(module, "tradeService", service);
      TradeSnapshotValidationTest.set(module, "nationService", nations);
      TradeSnapshotValidationTest.load(module);
    }

    void restart() throws Exception {
      storage.unreadable = false;
      money.restart();
      attach(money.module());
    }

    ResourceTradeService.ExecutionResult execute(String id) {
      return service.executeTradeAgreement(new ExecutionRequest(id, agreement, null));
    }

    ResourceTradeService.ExecutionResult approve(String id, UUID actor) {
      return service.executeTradeAgreement(new ExecutionRequest(id, agreement, actor));
    }

    void assertBalances(String importer, String exporter) {
      assertEquals(new BigDecimal(importer), money.module().balance(IMPORTER));
      assertEquals(new BigDecimal(exporter), money.module().balance(EXPORTER));
    }

    void assertCompleted(String id) {
      var execution = service.tradeExecution(id).orElseThrow();
      assertEquals(TradeExecution.State.COMPLETED, execution.state());
      assertBalances("96.00", "14.00");
      assertEquals(4, module.amount(EXPORTER, "industrial"));
      assertEquals(2, module.amount(IMPORTER, "industrial"));
      assertEquals(2, service.getQuota(exportQuota).orElseThrow().currentAmount());
      assertEquals(2, service.getQuota(importQuota).orElseThrow().currentAmount());
      assertEquals(2, service.getTradeRoute(route).orElseThrow().totalTradeVolume());
      assertTrue(module.transferReceipt(execution.operationId("delivery")).isPresent());
    }
  }

  static final class FaultStorage implements ResourceStateStorage {
    final ResourceStateStorage delegate;
    int remaining;
    String failure;
    boolean unreadable;

    FaultStorage(ResourceStateStorage delegate) {
      this.delegate = delegate;
    }

    void arm(int point, String failure) {
      remaining = point;
      this.failure = failure;
    }

    void check() {
      if (unreadable) throw new IllegalStateException("storage unavailable");
    }

    void write(Runnable action) {
      check();
      boolean fail = remaining > 0 && --remaining == 0;
      if (fail && failure.equals("before")) throw new IllegalStateException("before write");
      action.run();
      if (fail) {
        unreadable = failure.equals("unreadable");
        throw new IllegalStateException("after write");
      }
    }

    public Properties load() {
      check();
      return delegate.load();
    }

    public void save(Properties state) {
      write(() -> delegate.save(state));
    }

    public void saveTransfer(
        Properties state, NationResourceTransactionService.TransferReceipt receipt) {
      write(() -> delegate.saveTransfer(state, receipt));
    }

    public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
      check();
      return delegate.transferReceipt(id);
    }

    public void validateTradeDeliveries(Properties state, Map<String, TradeExecution> executions) {
      check();
      delegate.validateTradeDeliveries(state, executions);
    }

    public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
        long sequence, int limit) {
      check();
      return delegate.transferReceiptsAfter(sequence, limit);
    }

    public long latestTransferSequence() {
      check();
      return delegate.latestTransferSequence();
    }

    public int transferReceiptCount() {
      check();
      return delegate.transferReceiptCount();
    }

    public long latestProductionSequence() {
      check();
      return delegate.latestProductionSequence();
    }

    public Optional<ProductionReceipt> productionReceipt(String id) {
      check();
      return delegate.productionReceipt(id);
    }

    public boolean archivesFactoryRuns() {
      return delegate.archivesFactoryRuns();
    }

    public Optional<FactoryRun> archivedFactoryRun(String id) {
      check();
      return delegate.archivedFactoryRun(id);
    }

    public void writeFactoryState(
        Properties state, Map<String, FactoryRun> runs, Map<UUID, Factory> factories) {
      delegate.writeFactoryState(state, runs, factories);
    }

    public void validateFactoryProduction(Properties state, Map<String, FactoryRun> runs) {
      check();
      delegate.validateFactoryProduction(state, runs);
    }
  }
}
