import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


for label in ('test', 'package', 'sbom'):
    path = root / f'run/trade-recovery-{label}-20261126.log'
    log = path.read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESS' in log and 'BUILD FAILURE' not in log, label
    add(path, 'logs/' + path.name)
log = (root / 'run/trade-recovery-test-20261126.log').read_text(encoding='utf-8')
totals = dict(tests=0, failures=0, errors=0, skipped=0)
groups, suites = {}, {}
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', log):
    path = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(path.read_bytes())
    assert name not in suites
    suites[name] = int(suite.attrib['tests'])
    group = 'resource' if '.resource.' in name else 'treasury' if '.treasury.' in name else 'technology'
    groups[group] = groups.get(group, 0) + suites[name]
    for key in totals:
        totals[key] += int(suite.attrib[key])
    add(path, 'native-final/surefire/' + path.name)
assert totals['tests'] >= 1440 and all(totals[k] == 0 for k in ('failures', 'errors', 'skipped')), totals
new_tests = suites['dev.starcore.starcore.module.resource.TradeExecutionReceiptValidationTest']
assert new_tests == 49
failure_dir = root / 'run/trade-recovery-red-20261126'
for path in failure_dir.iterdir():
    if path.is_file():
        add(path, 'old-classes-red/' + path.name)
red = ET.parse(next(failure_dir.glob('TEST-*.xml'))).getroot()
red_counts = {key: int(red.attrib[key]) for key in totals}
assert red_counts == dict(tests=44, failures=29, errors=0, skipped=0)
contracts = {}
for label, folder in (
    ('capacity', 'trade-recovery-capacity-20261126'),
    ('trade', 'trade-contract-recovery-20261126-2'),
    ('factory', 'factory-contract-trade-recovery-20261126'),
):
    directory = root / 'run' / folder
    contracts[label] = json.loads((directory / 'manifest.json').read_text(encoding='utf-8'))
    assert contracts[label]['status'] == 'PASS'
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java', '.txt'):
            add(path, label + '/' + path.relative_to(directory).as_posix())
failed_contract = root / 'run/trade-contract-recovery-20261126'
failed_manifest = json.loads((failed_contract / 'manifest.json').read_text(encoding='utf-8'))
assert failed_manifest['status'] == 'FAILED'
assert 'Failed to commit metaspace' in (failed_contract / 'third.log').read_text(encoding='utf-8', errors='replace')
for path in failed_contract.rglob('*'):
    if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java', '.txt'):
        add(path, 'memory-failure/' + path.relative_to(failed_contract).as_posix())
add(root / 'hs_err_pid23028.log', 'memory-failure/hs_err_pid23028.log')
for name in ('TradeRecoveryProbe.java', 'run-trade-recovery-capacity.py', 'TradeExecutionProbe.java',
             'run-trade-execution-contract.py', 'FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-trade-recovery-evidence.py')
add(root / 'run/trade-execution-final-ci-20261126.json', 'github/baseline-ci.json')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
sources = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        sources[name] = sha((native / name).read_bytes())
starcore = sha((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle = sha((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore == contracts['capacity']['artifacts']['current.jar'] == contracts['trade']['artifacts']['starcore.jar'] == contracts['factory']['artifacts']['starcore.jar']
assert chronicle == contracts['trade']['artifacts']['starchronicle.jar'] == contracts['factory']['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': '9e15f318779202ae363062115379c86b669c0eb3', 'starcore': 'b427da286621f2f0dc82a4408794fe05f0408cf1'},
    'scope': 'V1 trade recovery uses loaded file receipts or one SQL read transaction with <=256 IDs per batch; canonical row validation and incremental digest; production router; no Minecraft',
    'native_tests': totals, 'tests_by_package': groups, 'new_tests': new_tests,
    'native_source_hashes': sources, 'preserved_old_classes_red': red_counts,
    'preserved_contract_failure': {'status': 'FAILED', 'phase': 'third', 'reason': 'Windows commit memory exhausted: Failed to commit metaspace', 'manifest': failed_manifest},
    'packaging': 'Sequential 256 MiB JVMs; verify uses tested classes, skips recompilation/tests, checks formatting; online SBOM',
    'chronicle_tests': 'Main source unchanged; prior 957-test JAR reused. Baseline 9e15f31 Linux Maven verification #149 succeeded. Current CI checked after push.',
    'artifacts': {'starcore_sha256': starcore, 'starchronicle_sha256': chronicle},
    'contracts': contracts,
    'limits': ['Focused resource/treasury/research suite, no current whole-native-suite or JaCoCo; no MySQL test.',
               'Synthetic immutable V1 executions, real file/SQLite recovery and fixed heap are not ongoing gameplay or long-term capacity certification.',
               'Full trade execution ledger, IDs, quota links and treasury receipts remain resident; no archival or ID removal.',
               'SQL head pinning is a recovery consistency check, not multi-instance linearizability or a shared treasury/resource transaction.',
               'Current Minecraft, full-stack Folia and actual third-party combinations remain pending.']
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: sha(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/trade-recovery-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert sha(archive.read(name)) == expected
summary['evidence_zip_sha256'] = sha(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'trade-recovery-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': groups, 'new_tests': new_tests, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
