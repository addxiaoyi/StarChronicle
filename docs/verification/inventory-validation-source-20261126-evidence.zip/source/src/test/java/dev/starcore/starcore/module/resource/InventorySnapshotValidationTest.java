package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.*;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class InventorySnapshotValidationTest {
  @TempDir Path directory;

  static Stream<String> corruptions() {
    return Stream.of(
        "stock-count-missing",
        "stock-count-negative",
        "stock-count-text",
        "stock-count-short",
        "stock-count-long",
        "stock-duplicate",
        "stock-amount-missing",
        "stock-amount-text",
        "stock-amount-zero",
        "stock-amount-negative",
        "stock-amount-overflow",
        "stock-type-unknown",
        "stock-uuid-short",
        "stock-extra",
        "stock-index-alias",
        "receipt-count-missing",
        "receipt-count-negative",
        "receipt-count-text",
        "receipt-count-short",
        "receipt-count-long",
        "receipt-duplicate",
        "receipt-id-missing",
        "receipt-resource-unknown",
        "receipt-resource-malformed",
        "receipt-resource-number",
        "receipt-resource-empty",
        "receipt-resource-duplicate",
        "receipt-time-missing",
        "receipt-time-text",
        "receipt-operation",
        "receipt-category",
        "receipt-uuid-short",
        "receipt-description-long",
        "receipt-extra",
        "receipt-index-alias");
  }

  static Stream<Arguments> storesAndCorruptions() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(engine -> corruptions().map(corruption -> Arguments.of(engine, corruption)));
  }

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  @ParameterizedTest
  @MethodSource("storesAndCorruptions")
  void malformedInventoryOrRetryProofQuarantinesStorageWithoutOverwritingIt(
      String engine, String corruption) throws Exception {
    var helper = new InventoryCommitRecoveryTest();
    helper.directory = directory;
    var fixture = helper.fixture(engine);
    var module = fixture.module();
    assertEquals(Status.APPLIED, module.consume(request("paid")).status());
    var damaged = fixture.storage().load();
    corrupt(damaged, corruption);
    fixture.storage().save(damaged);
    var before = fixture.storage().load();

    var restarted = fixture.module();
    assertEquals("", restarted.authorityDomainId(), corruption);
    assertFalse(restarted.grant(FactorySnapshotVersionTest.NATION, "luxury", 1));
    assertFalse(restarted.consume(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals(Status.REJECTED, restarted.consume(request("paid")).status());
    assertEquals(Status.REJECTED, restarted.grant(request("other")).status());
    assertThrows(IllegalStateException.class, () -> restarted.transactionReceipt("paid"));
    assertEquals(before, fixture.storage().load());
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "stock-amount-text",
        "stock-count-short",
        "receipt-time-missing",
        "receipt-resource-malformed",
        "receipt-count-short"
      })
  void malformedStateDuringCommitReconciliationNeverEnablesAnotherWrite(String corruption) {
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          boolean damage;

          @Override
          public void save(Properties state) {
            super.save(state);
            if (damage) {
              damage = false;
              corrupt(this.state, corruption);
              throw new IllegalStateException("commit acknowledgement lost with damaged storage");
            }
          }
        };
    var module = new ResourceModule(storage);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 6));
    assertEquals(Status.APPLIED, module.consume(request("paid")).status());
    storage.damage = true;
    assertFalse(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals("", module.authorityDomainId());
    var before = storage.load();
    assertFalse(module.grant(FactorySnapshotVersionTest.NATION, "luxury", 1));
    assertEquals(Status.REJECTED, module.grant(request("other")).status());
    assertThrows(IllegalStateException.class, () -> module.transactionReceipt("paid"));
    assertEquals(before, storage.load());
  }

  @Test
  void validLegacyReceiptWithoutDescriptionKeepsItsOriginalIdAndTimestamp() {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    var module = new ResourceModule(storage);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 6));
    assertEquals(Status.APPLIED, module.consume(request("paid")).status());
    storage.state.remove("transaction.0.description");
    storage.state.setProperty("transaction.0.appliedAt", Long.toString(Long.MAX_VALUE));
    var before = storage.load();
    var restored = new ResourceModule(storage);
    assertFalse(restored.authorityDomainId().isBlank());
    assertEquals(
        Long.MAX_VALUE,
        restored.transactionReceipt("paid").orElseThrow().appliedAt().toEpochMilli());
    assertEquals(Status.ALREADY_APPLIED, restored.consume(request("paid")).status());
    assertEquals(4, restored.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(before, storage.load());
  }

  static TransactionRequest request(String id) {
    return new TransactionRequest(
        id, FactorySnapshotVersionTest.NATION, Map.of("industrial", 2L), Category.RESEARCH, "test");
  }

  static Stream<Arguments> sqlCounts() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(
                        "count",
                        "transaction.count",
                        "factory.count",
                        "agreement.count",
                        "route.count",
                        "embargo.count",
                        "quota.count")
                    .map(key -> Arguments.of(engine, key)));
  }

  @ParameterizedTest
  @MethodSource("sqlCounts")
  void hugeCountsInSqlAreBoundedEvenWhenOldFileMigrationReadsFirst(String engine, String key)
      throws Exception {
    var helper = new SqlFactoryArchiveTest();
    helper.directory = directory;
    var db = helper.database(engine);
    var storage = SqlFactoryArchiveTest.storage(db, FactorySnapshotVersionTest.legacy());
    var module = new ResourceModule(storage, FactorySnapshotVersionTest.CLOCK);
    assertFalse(module.authorityDomainId().isBlank());
    try (var connection = db.getConnection();
        var update =
            connection.prepareStatement(
                "UPDATE starcore_resource_state SET property_value=? WHERE property_key=?")) {
      update.setString(1, Integer.toString(Integer.MAX_VALUE));
      update.setString(2, key);
      assertEquals(1, update.executeUpdate());
    }
    var before = rawState(db);
    assertTimeoutPreemptively(
        java.time.Duration.ofSeconds(2),
        () -> assertThrows(IllegalStateException.class, storage::load));
    assertEquals(before, rawState(db));
  }

  static Properties rawState(javax.sql.DataSource db) throws Exception {
    var state = new Properties();
    try (var connection = db.getConnection();
        var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT property_key, property_value FROM starcore_resource_state")) {
      while (rows.next()) state.setProperty(rows.getString(1), rows.getString(2));
    }
    return state;
  }

  @ParameterizedTest
  @ValueSource(strings = {"count", "transaction.count"})
  void hugeDeclaredCountIsRejectedBeforeTheLegacyDecoderTraversesMissingRows(String key) {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    storage.state.setProperty(key, Integer.toString(Integer.MAX_VALUE));
    var before = storage.load();
    assertTimeoutPreemptively(
        java.time.Duration.ofSeconds(2),
        () -> {
          var module = new ResourceModule(storage);
          assertEquals("", module.authorityDomainId());
          assertFalse(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
        });
    assertEquals(before, storage.load());
  }

  @ParameterizedTest
  @ValueSource(
      strings = {"stockpile.0.amount", "transaction.0.appliedAt", "count", "transaction.count"})
  void nonCanonicalNumbersCannotBeSilentlyNormalizedOnNextSave(String key) {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    var module = new ResourceModule(storage);
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 6));
    assertEquals(Status.APPLIED, module.consume(request("paid")).status());
    storage.state.setProperty(key, "+" + storage.state.getProperty(key));
    var before = storage.load();
    var restarted = new ResourceModule(storage);
    assertEquals("", restarted.authorityDomainId());
    assertFalse(restarted.grant(FactorySnapshotVersionTest.NATION, "industrial", 1));
    assertEquals(before, storage.load());
  }

  @Test
  void validMultiNationMultiResourceSnapshotAndInheritedPropertiesKeepAllProofs() {
    var storage = new ProductionPersistenceTest.MemoryStorage();
    var module = new ResourceModule(storage);
    var other = dev.starcore.starcore.module.nation.model.NationId.random();
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "industrial", 6));
    assertTrue(module.grant(FactorySnapshotVersionTest.NATION, "energy", 4));
    assertTrue(module.grant(other, "mineral", 10));
    var request =
        new TransactionRequest(
            "mixed",
            FactorySnapshotVersionTest.NATION,
            Map.of("industrial", 2L, "energy", 1L),
            Category.RESEARCH,
            "mixed");
    assertEquals(Status.APPLIED, module.consume(request).status());
    assertEquals(
        Status.APPLIED,
        module
            .grant(
                new TransactionRequest(
                    "other", other, Map.of("mineral", 3L), Category.COMPENSATION_REFUND, "other"))
            .status());
    var before = storage.load();
    var inherited = new Properties(before);
    var inheritedStorage =
        new ResourceStateStorage() {
          public Properties load() {
            return inherited;
          }

          public void save(Properties ignored) {
            fail("read-only recovery must not save");
          }
        };
    var restored = new ResourceModule(inheritedStorage);
    assertEquals(4, restored.amount(FactorySnapshotVersionTest.NATION, "industrial"));
    assertEquals(3, restored.amount(FactorySnapshotVersionTest.NATION, "energy"));
    assertEquals(13, restored.amount(other, "mineral"));
    var savedReceipts =
        ResourceStateCodec.snapshotFromProperties(before, ResourceModule.RESOURCE_TYPES).receipts();
    assertEquals(savedReceipts.get("mixed"), restored.transactionReceipt("mixed").orElseThrow());
    assertEquals(savedReceipts.get("other"), restored.transactionReceipt("other").orElseThrow());
    assertEquals(Status.ALREADY_APPLIED, restored.consume(request).status());
    assertEquals(before, storage.load());
  }

  static void copyRow(Properties state, String source, String target) {
    for (String key : state.stringPropertyNames())
      if (key.startsWith(source))
        state.setProperty(target + key.substring(source.length()), state.getProperty(key));
  }

  static void corrupt(Properties state, String corruption) {
    switch (corruption) {
      case "stock-count-missing" -> state.remove("count");
      case "stock-count-negative" -> state.setProperty("count", "-1");
      case "stock-count-text" -> state.setProperty("count", "bad");
      case "stock-count-short" -> state.setProperty("count", "0");
      case "stock-count-long" -> state.setProperty("count", "2");
      case "stock-duplicate" -> {
        state.setProperty("count", "2");
        copyRow(state, "stockpile.0.", "stockpile.1.");
      }
      case "stock-amount-missing" -> state.remove("stockpile.0.amount");
      case "stock-amount-text" -> state.setProperty("stockpile.0.amount", "bad");
      case "stock-amount-zero" -> state.setProperty("stockpile.0.amount", "0");
      case "stock-amount-negative" -> state.setProperty("stockpile.0.amount", "-1");
      case "stock-amount-overflow" ->
          state.setProperty("stockpile.0.amount", "9223372036854775808");
      case "stock-type-unknown" -> state.setProperty("stockpile.0.type", "unknown");
      case "stock-uuid-short" -> state.setProperty("stockpile.0.nationId", "0-0-0-0-1");
      case "stock-extra" -> state.setProperty("stockpile.0.unexpected", "keep");
      case "stock-index-alias" -> copyRow(state, "stockpile.0.", "stockpile.00.");
      case "receipt-count-missing" -> state.remove("transaction.count");
      case "receipt-count-negative" -> state.setProperty("transaction.count", "-1");
      case "receipt-count-text" -> state.setProperty("transaction.count", "bad");
      case "receipt-count-short" -> state.setProperty("transaction.count", "0");
      case "receipt-count-long" -> state.setProperty("transaction.count", "2");
      case "receipt-duplicate" -> {
        state.setProperty("transaction.count", "2");
        copyRow(state, "transaction.0.", "transaction.1.");
      }
      case "receipt-id-missing" -> state.remove("transaction.0.id");
      case "receipt-resource-unknown" ->
          state.setProperty("transaction.0.resources", "industrial=2;unknown=3");
      case "receipt-resource-malformed" ->
          state.setProperty("transaction.0.resources", "industrial=2;broken");
      case "receipt-resource-number" ->
          state.setProperty("transaction.0.resources", "industrial=2;energy=broken");
      case "receipt-resource-empty" -> state.setProperty("transaction.0.resources", "");
      case "receipt-resource-duplicate" ->
          state.setProperty("transaction.0.resources", "industrial=2; INDUSTRIAL =3");
      case "receipt-time-missing" -> state.remove("transaction.0.appliedAt");
      case "receipt-time-text" -> state.setProperty("transaction.0.appliedAt", "bad");
      case "receipt-operation" -> state.setProperty("transaction.0.operation", "unknown");
      case "receipt-category" -> state.setProperty("transaction.0.category", "unknown");
      case "receipt-uuid-short" -> state.setProperty("transaction.0.nationId", "0-0-0-0-1");
      case "receipt-description-long" ->
          state.setProperty("transaction.0.description", "x".repeat(201));
      case "receipt-extra" -> state.setProperty("transaction.0.unexpected", "keep");
      case "receipt-index-alias" -> copyRow(state, "transaction.0.", "transaction.00.");
      default -> throw new AssertionError(corruption);
    }
  }
}
