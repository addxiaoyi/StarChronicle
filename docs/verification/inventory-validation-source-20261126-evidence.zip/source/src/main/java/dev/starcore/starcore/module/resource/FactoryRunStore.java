package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.Factory;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.function.BiConsumer;

/**
 * Stored with the stockpile snapshot in both file and SQL transactions. Never prunes retry keys.
 */
final class FactoryRunStore {
  static final String PREFIX = "resource.factory-runs.";
  private static final String HEAD = PREFIX + "head";

  private FactoryRunStore() {}

  static void write(Properties p, Map<String, FactoryRun> runs, Map<UUID, Factory> factories) {
    write(p, runs, factories, "2", SqlFactoryArchive.Head.EMPTY);
  }

  static void writeArchived(
      Properties p,
      Map<String, FactoryRun> runs,
      Map<UUID, Factory> factories,
      SqlFactoryArchive.Head archive) {
    write(p, runs, factories, "3", archive);
  }

  private static void write(
      Properties p,
      Map<String, FactoryRun> runs,
      Map<UUID, Factory> factories,
      String version,
      SqlFactoryArchive.Head archive) {
    p.keySet().removeIf(key -> key instanceof String text && text.startsWith(PREFIX));
    writeFields(p::setProperty, runs, factories, version, archive);
    p.setProperty(HEAD, fingerprint(p));
  }

  /** V1 row positions are retained only for strict verification of an existing V1 snapshot. */
  private static void writeFields(
      BiConsumer<String, String> field,
      Map<String, FactoryRun> runs,
      Map<UUID, Factory> factories,
      String version,
      SqlFactoryArchive.Head archive) {
    field.accept(PREFIX + "version", version);
    field.accept(PREFIX + "count", Integer.toString(runs.size()));
    if (version.equals("3")) {
      field.accept(PREFIX + "archive-count", Long.toString(archive.count()));
      field.accept(PREFIX + "archive-head", archive.hash());
    }
    Collection<FactoryRun> ordered =
        version.equals("1")
            ? runs.values().stream().sorted(Comparator.comparing(FactoryRun::runId)).toList()
            : runs.values();
    Map<UUID, String> active = new HashMap<>();
    Set<String> keys = new HashSet<>();
    int index = 0;
    for (FactoryRun r : ordered) {
      String k = version.equals("1") ? PREFIX + "row." + index++ + "." : rowPrefix(r.runId());
      if (!r.equals(runs.get(r.runId())) || !keys.add(k))
        throw new IllegalStateException("Conflicting factory run key");
      field.accept(k + "id", r.runId());
      field.accept(k + "domain", r.authorityDomainId());
      field.accept(k + "factory", r.factoryId().toString());
      field.accept(k + "nation", r.nationId().toString());
      field.accept(k + "actor", Objects.toString(r.actorId(), ""));
      field.accept(k + "recipe", r.recipeId());
      field.accept(k + "batches", Integer.toString(r.batches()));
      field.accept(k + "inputs", ResourceTransferReceiptStore.encodeResources(r.inputs()));
      field.accept(k + "outputs", ResourceTransferReceiptStore.encodeResources(r.outputs()));
      field.accept(k + "started", Long.toString(r.startedAt().toEpochMilli()));
      field.accept(k + "ready", Long.toString(r.readyAt().toEpochMilli()));
      field.accept(
          k + "completed", r.completed() ? Long.toString(r.completedAt().toEpochMilli()) : "");
      field.accept(k + "sequence", Long.toString(r.completionSequence()));
      if (!r.completed() && active.put(r.factoryId(), r.runId()) != null)
        throw new IllegalStateException("Multiple active runs for a factory");
    }
    for (Factory f : factories.values()) {
      if (f.isProcessing())
        field.accept(
            PREFIX + "binding." + f.factoryId(),
            active.containsKey(f.factoryId()) ? "run:" + active.get(f.factoryId()) : "legacy");
    }
  }

  /**
   * Lowercase digest keys fit VARCHAR(191), including a maximum-length external run ID, and do not
   * rely on case-sensitive SQL collation. The original ID remains in the row.
   */
  static String rowPrefix(String runId) {
    ProductionReceipt.token(runId, 96);
    try {
      return PREFIX
          + "row."
          + HexFormat.of()
              .formatHex(
                  MessageDigest.getInstance("SHA-256")
                      .digest(runId.getBytes(StandardCharsets.UTF_8)))
          + ".";
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  static Map<String, FactoryRun> read(
      Properties p,
      Map<UUID, Factory> factories,
      Set<String> resources,
      ResourceStateStorage storage) {
    try {
      Set<String> propertyNames = p.stringPropertyNames();
      // The general legacy codec tolerates bad rows. Financial recovery must not drop a factory.
      int factoryCount = Integer.parseInt(p.getProperty("factory.count", "0"));
      if (factoryCount < 0 || factoryCount != factories.size())
        throw new IllegalStateException("Factory snapshot lost or duplicated a row");
      for (String key : propertyNames) {
        if (!key.startsWith("factory.") || key.equals("factory.count")) continue;
        int separator = key.indexOf('.', "factory.".length());
        int index = Integer.parseInt(key.substring("factory.".length(), separator));
        if (index < 0 || index >= factoryCount || !key.startsWith("factory." + index + "."))
          throw new IllegalStateException("Factory row outside snapshot count");
      }
      if (p.getProperty(PREFIX + "version") == null) {
        if (propertyNames.stream().anyMatch(k -> k.startsWith(PREFIX)))
          throw new IllegalStateException("Factory run schema missing");
        return Map.of(); // Old active factories remain blocked for manual review.
      }
      String version = p.getProperty(PREFIX + "version");
      if (!Set.of("1", "2", "3").contains(version)
          || !fingerprint(p, propertyNames).equals(p.getProperty(HEAD)))
        throw new IllegalStateException("Factory state fingerprint mismatch");
      int count = Integer.parseInt(p.getProperty(PREFIX + "count"));
      if (count < 0 || count > 1_000_000)
        throw new IllegalStateException("Invalid factory run count");
      Map<String, FactoryRun> runs = new LinkedHashMap<>();
      Set<UUID> active = new HashSet<>();
      List<String> rowKeys = new ArrayList<>();
      if (!version.equals("1")) {
        for (String key : propertyNames) {
          if (key.startsWith(PREFIX + "row.") && key.endsWith(".id"))
            rowKeys.add(key.substring(0, key.length() - 2));
        }
        if (rowKeys.size() != count) throw new IllegalStateException("Factory run count mismatch");
      }
      for (int i = 0; i < count; i++) {
        String k = version.equals("1") ? PREFIX + "row." + i + "." : rowKeys.get(i);
        String actor = p.getProperty(k + "actor");
        String completed = p.getProperty(k + "completed");
        FactoryRun r =
            new FactoryRun(
                p.getProperty(k + "id"),
                p.getProperty(k + "domain"),
                UUID.fromString(p.getProperty(k + "factory")),
                new NationId(UUID.fromString(p.getProperty(k + "nation"))),
                actor.isEmpty() ? null : UUID.fromString(actor),
                p.getProperty(k + "recipe"),
                Integer.parseInt(p.getProperty(k + "batches")),
                ResourceTransferReceiptStore.decodeResources(p.getProperty(k + "inputs")),
                ResourceTransferReceiptStore.decodeResources(p.getProperty(k + "outputs")),
                Instant.ofEpochMilli(Long.parseLong(p.getProperty(k + "started"))),
                Instant.ofEpochMilli(Long.parseLong(p.getProperty(k + "ready"))),
                completed.isEmpty() ? null : Instant.ofEpochMilli(Long.parseLong(completed)),
                Long.parseLong(p.getProperty(k + "sequence")));
        Factory f = factories.get(r.factoryId());
        if (runs.putIfAbsent(r.runId(), r) != null
            || f == null
            || !f.ownerNationId().equals(r.nationId())
            || !r.authorityDomainId().equals(p.getProperty("resource.authority-domain"))
            || !resources.containsAll(r.inputs().keySet())
            || !resources.containsAll(r.outputs().keySet()))
          throw new IllegalStateException("Conflicting factory run identity");
        if (!r.completed()
            && (!active.add(r.factoryId())
                || !r.recipeId().equals(f.currentRecipeId())
                || !r.startedAt().equals(f.processingStartTime())
                || r.batches() != f.processingBatches())) {
          throw new IllegalStateException("Factory start and state disagree");
        }
      }
      // Verify each unique canonical field without retaining another complete property table.
      // Once every required field matches, equal counts also reject every unexpected field.
      int[] expectedFields = {0};
      writeFields(
          (key, value) -> {
            if (!value.equals(p.getProperty(key)))
              throw new IllegalStateException("Factory run row or binding changed");
            expectedFields[0]++;
          },
          runs,
          factories,
          version,
          SqlFactoryArchive.Head.from(p));
      long actualFields =
          propertyNames.stream().filter(k -> k.startsWith(PREFIX) && !k.equals(HEAD)).count();
      if (actualFields != expectedFields[0])
        throw new IllegalStateException("Factory run metadata missing or unexpected");
      storage.validateFactoryProduction(p, runs);
      return Map.copyOf(runs);
    } catch (RuntimeException invalid) {
      throw new IllegalStateException("Factory state requires recovery", invalid);
    }
  }

  /**
   * One validation pass can check every run without reloading or rescanning the journal per run.
   */
  static final class ReceiptVerifier {
    private final Map<String, FactoryRun> runs;
    private final Set<String> missing = new HashSet<>();

    ReceiptVerifier(Map<String, FactoryRun> runs) {
      this.runs = runs;
      for (FactoryRun run : runs.values()) if (run.completed()) missing.add(run.runId());
    }

    void accept(ProductionReceipt receipt) {
      if (!receipt.operationId().startsWith("factory:")) return;
      FactoryRun run = runs.get(receipt.operationId().substring("factory:".length()));
      if (run == null) return;
      if (!run.completed()
          || !run.productionReceipt().equals(receipt)
          || !missing.remove(run.runId()))
        throw new IllegalStateException("Factory completion receipt changed or premature");
    }

    void finish() {
      if (!missing.isEmpty()) throw new IllegalStateException("Factory completion receipt missing");
    }
  }

  static void verifyMigration(Properties legacy, Properties current, ResourceStateStorage storage) {
    if (legacy.stringPropertyNames().stream().noneMatch(k -> k.startsWith(PREFIX))) return;
    ResourceStateStorage file =
        new ResourceStateStorage() {
          @Override
          public Properties load() {
            return legacy;
          }

          @Override
          public void save(Properties ignored) {
            throw new UnsupportedOperationException();
          }
        };
    var before =
        read(
            legacy,
            ResourceStateCodec.snapshotFromProperties(legacy, ResourceModule.RESOURCE_TYPES)
                .factories(),
            ResourceModule.RESOURCE_TYPES,
            file);
    var after =
        read(
            current,
            ResourceStateCodec.snapshotFromProperties(current, ResourceModule.RESOURCE_TYPES)
                .factories(),
            ResourceModule.RESOURCE_TYPES,
            storage);
    for (FactoryRun old : before.values()) {
      FactoryRun saved = after.get(old.runId());
      if (saved == null) saved = storage.archivedFactoryRun(old.runId()).orElse(null);
      if (saved == null
          || (!old.equals(saved)
              && (old.completed()
                  || !saved.completed()
                  || !old.complete(saved.completedAt(), saved.completionSequence()).equals(saved))))
        throw new IllegalStateException("Legacy factory run differs from active SQL state");
    }
  }

  private static String fingerprint(Properties p) {
    return fingerprint(p, p.stringPropertyNames());
  }

  private static String fingerprint(Properties p, Set<String> propertyNames) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      propertyNames.stream()
          .filter(k -> (k.startsWith(PREFIX) || k.startsWith("factory.")) && !k.equals(HEAD))
          .sorted()
          .forEach(
              k -> {
                // Length framing also covers names containing newlines.
                byte[] key = k.getBytes(StandardCharsets.UTF_8);
                byte[] value = p.getProperty(k).getBytes(StandardCharsets.UTF_8);
                digest.update(java.nio.ByteBuffer.allocate(4).putInt(key.length).array());
                digest.update(key);
                digest.update(java.nio.ByteBuffer.allocate(4).putInt(value.length).array());
                digest.update(value);
              });
      return HexFormat.of().formatHex(digest.digest());
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }
}
