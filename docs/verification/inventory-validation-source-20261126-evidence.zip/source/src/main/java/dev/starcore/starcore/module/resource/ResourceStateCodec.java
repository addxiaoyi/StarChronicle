package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.Category;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.Operation;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.TransactionReceipt;
import dev.starcore.starcore.module.resource.model.Factory;
import dev.starcore.starcore.module.resource.model.ResourceEmbargo;
import dev.starcore.starcore.module.resource.model.ResourceQuota;
import dev.starcore.starcore.module.resource.model.TradeAgreement;
import dev.starcore.starcore.module.resource.model.TradeRoute;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

final class ResourceStateCodec {
  private static final Logger LOGGER = Logger.getLogger(ResourceStateCodec.class.getName());
  private static final String STOCKPILE_COUNT = "count";
  private static final String RECEIPT_COUNT = "transaction.count";
  private static final String FACTORY_COUNT = "factory.count";
  private static final String AGREEMENT_COUNT = "agreement.count";
  private static final String ROUTE_COUNT = "route.count";
  private static final String EMBARGO_COUNT = "embargo.count";
  private static final String QUOTA_COUNT = "quota.count";

  record Snapshot(
      Map<NationId, Map<String, Long>> stockpiles,
      Map<String, TransactionReceipt> receipts,
      Map<UUID, Factory> factories,
      Map<UUID, TradeAgreement> agreements,
      Map<UUID, TradeRoute> routes,
      Map<UUID, ResourceEmbargo> embargoes,
      Map<UUID, ResourceQuota> quotas) {
    Snapshot {
      stockpiles = stockpiles == null ? Map.of() : Map.copyOf(stockpiles);
      receipts = receipts == null ? Map.of() : Map.copyOf(receipts);
      factories = factories == null ? Map.of() : Map.copyOf(factories);
      agreements = agreements == null ? Map.of() : Map.copyOf(agreements);
      routes = routes == null ? Map.of() : Map.copyOf(routes);
      embargoes = embargoes == null ? Map.of() : Map.copyOf(embargoes);
      quotas = quotas == null ? Map.of() : Map.copyOf(quotas);
    }
  }

  private ResourceStateCodec() {}

  static Properties toProperties(Map<NationId, Map<String, Long>> stockpiles) {
    return toProperties(stockpiles, Map.of());
  }

  static Properties toProperties(
      Map<NationId, Map<String, Long>> stockpiles, Map<String, TransactionReceipt> receipts) {
    return toProperties(stockpiles, receipts, Map.of());
  }

  static Properties toProperties(
      Map<NationId, Map<String, Long>> stockpiles,
      Map<String, TransactionReceipt> receipts,
      Map<UUID, Factory> factories) {
    return toProperties(stockpiles, receipts, factories, Map.of());
  }

  static Properties toProperties(
      Map<NationId, Map<String, Long>> stockpiles,
      Map<String, TransactionReceipt> receipts,
      Map<UUID, Factory> factories,
      Map<UUID, TradeAgreement> agreements) {
    return toProperties(stockpiles, receipts, factories, agreements, Map.of(), Map.of(), Map.of());
  }

  static Properties toProperties(
      Map<NationId, Map<String, Long>> stockpiles,
      Map<String, TransactionReceipt> receipts,
      Map<UUID, Factory> factories,
      Map<UUID, TradeAgreement> agreements,
      Map<UUID, TradeRoute> routes,
      Map<UUID, ResourceEmbargo> embargoes,
      Map<UUID, ResourceQuota> quotas) {
    Properties properties = new Properties();
    List<Map.Entry<NationId, Map<String, Long>>> snapshot =
        stockpiles.entrySet().stream()
            .filter(entry -> entry.getValue() != null && !entry.getValue().isEmpty())
            .sorted((left, right) -> left.getKey().toString().compareTo(right.getKey().toString()))
            .toList();
    int stockpileIndex = 0;
    for (Map.Entry<NationId, Map<String, Long>> nationEntry : snapshot) {
      List<Map.Entry<String, Long>> values =
          nationEntry.getValue().entrySet().stream()
              .filter(entry -> entry.getValue() != null && entry.getValue() > 0L)
              .map(entry -> Map.entry(normalizeResource(entry.getKey()), entry.getValue()))
              .filter(entry -> !entry.getKey().isBlank())
              .sorted(Map.Entry.comparingByKey())
              .toList();
      for (Map.Entry<String, Long> value : values) {
        String prefix = "stockpile." + stockpileIndex++ + '.';
        properties.setProperty(prefix + "nationId", nationEntry.getKey().toString());
        properties.setProperty(prefix + "type", value.getKey());
        properties.setProperty(prefix + "amount", String.valueOf(value.getValue()));
      }
    }
    properties.setProperty(STOCKPILE_COUNT, String.valueOf(stockpileIndex));

    List<TransactionReceipt> orderedReceipts =
        receipts.values().stream()
            .sorted((left, right) -> left.transactionId().compareTo(right.transactionId()))
            .toList();
    for (int index = 0; index < orderedReceipts.size(); index++) {
      TransactionReceipt receipt = orderedReceipts.get(index);
      String prefix = "transaction." + index + '.';
      properties.setProperty(prefix + "id", receipt.transactionId());
      properties.setProperty(prefix + "nationId", receipt.nationId().toString());
      properties.setProperty(prefix + "operation", receipt.operation().name());
      properties.setProperty(prefix + "category", receipt.category().name());
      properties.setProperty(prefix + "resources", encodeResources(receipt.resources()));
      properties.setProperty(prefix + "description", receipt.description());
      properties.setProperty(
          prefix + "appliedAt", String.valueOf(receipt.appliedAt().toEpochMilli()));
    }
    properties.setProperty(RECEIPT_COUNT, String.valueOf(orderedReceipts.size()));
    List<Factory> orderedFactories =
        (factories == null ? Map.<UUID, Factory>of() : factories)
            .values().stream()
                .filter(java.util.Objects::nonNull)
                .sorted(java.util.Comparator.comparing(Factory::factoryId))
                .toList();
    for (int index = 0; index < orderedFactories.size(); index++) {
      Factory factory = orderedFactories.get(index);
      String prefix = "factory." + index + '.';
      properties.setProperty(prefix + "id", factory.factoryId().toString());
      properties.setProperty(prefix + "nationId", factory.ownerNationId().toString());
      properties.setProperty(prefix + "name", factory.factoryName());
      properties.setProperty(prefix + "type", factory.type().name());
      properties.setProperty(prefix + "buildTime", factory.buildTime().toEpochMilli() + "");
      properties.setProperty(prefix + "level", Integer.toString(factory.level()));
      properties.setProperty(prefix + "efficiency", Double.toString(factory.efficiency()));
      properties.setProperty(prefix + "operational", Boolean.toString(factory.isOperational()));
      if (factory.currentRecipeId() != null) {
        properties.setProperty(prefix + "recipe", factory.currentRecipeId());
        properties.setProperty(
            prefix + "processingStart", factory.processingStartTime().toEpochMilli() + "");
        properties.setProperty(
            prefix + "processingBatches", Integer.toString(factory.processingBatches()));
      }
    }
    properties.setProperty(FACTORY_COUNT, Integer.toString(orderedFactories.size()));
    List<TradeAgreement> orderedAgreements =
        (agreements == null ? Map.<UUID, TradeAgreement>of() : agreements)
            .values().stream()
                .filter(java.util.Objects::nonNull)
                .sorted(java.util.Comparator.comparing(TradeAgreement::agreementId))
                .toList();
    for (int index = 0; index < orderedAgreements.size(); index++) {
      TradeAgreement agreement = orderedAgreements.get(index);
      String prefix = "agreement." + index + '.';
      properties.setProperty(prefix + "id", agreement.agreementId().toString());
      properties.setProperty(prefix + "exporter", agreement.exporterNationId().toString());
      properties.setProperty(prefix + "importer", agreement.importerNationId().toString());
      properties.setProperty(prefix + "resource", agreement.resourceId());
      properties.setProperty(prefix + "amount", Long.toString(agreement.amount()));
      properties.setProperty(prefix + "price", Double.toString(agreement.pricePerUnit()));
      properties.setProperty(prefix + "start", agreement.startTime().toEpochMilli() + "");
      properties.setProperty(prefix + "expiry", agreement.expiryTime().toEpochMilli() + "");
      properties.setProperty(prefix + "autoRenew", Boolean.toString(agreement.isAutoRenew()));
    }
    properties.setProperty(AGREEMENT_COUNT, Integer.toString(orderedAgreements.size()));

    List<TradeRoute> orderedRoutes =
        (routes == null ? Map.<UUID, TradeRoute>of() : routes)
            .values().stream()
                .filter(java.util.Objects::nonNull)
                .sorted(java.util.Comparator.comparing(TradeRoute::routeId))
                .toList();
    for (int index = 0; index < orderedRoutes.size(); index++) {
      TradeRoute route = orderedRoutes.get(index);
      String prefix = "route." + index + '.';
      properties.setProperty(prefix + "id", route.routeId().toString());
      properties.setProperty(prefix + "origin", route.originNationId().toString());
      properties.setProperty(prefix + "destination", route.destinationNationId().toString());
      properties.setProperty(prefix + "name", route.routeName());
      properties.setProperty(prefix + "established", route.establishedTime().toEpochMilli() + "");
      properties.setProperty(prefix + "efficiency", Double.toString(route.efficiency()));
      properties.setProperty(prefix + "active", Boolean.toString(route.isActive()));
      properties.setProperty(prefix + "volume", Long.toString(route.totalTradeVolume()));
    }
    properties.setProperty(ROUTE_COUNT, Integer.toString(orderedRoutes.size()));

    List<ResourceEmbargo> orderedEmbargoes =
        (embargoes == null ? Map.<UUID, ResourceEmbargo>of() : embargoes)
            .values().stream()
                .filter(java.util.Objects::nonNull)
                .sorted(java.util.Comparator.comparing(ResourceEmbargo::embargoId))
                .toList();
    for (int index = 0; index < orderedEmbargoes.size(); index++) {
      ResourceEmbargo embargo = orderedEmbargoes.get(index);
      String prefix = "embargo." + index + '.';
      properties.setProperty(prefix + "id", embargo.embargoId().toString());
      properties.setProperty(prefix + "initiator", embargo.initiatorNationId().toString());
      properties.setProperty(
          prefix + "targets",
          embargo.targetNationIds().stream()
              .map(NationId::toString)
              .sorted()
              .collect(Collectors.joining(",")));
      properties.setProperty(prefix + "resource", embargo.resourceId());
      properties.setProperty(prefix + "start", embargo.startTime().toEpochMilli() + "");
      if (embargo.expiryTime() != null) {
        properties.setProperty(prefix + "expiry", embargo.expiryTime().toEpochMilli() + "");
      }
      properties.setProperty(prefix + "reason", embargo.reason());
      properties.setProperty(prefix + "active", Boolean.toString(embargo.isActive()));
    }
    properties.setProperty(EMBARGO_COUNT, Integer.toString(orderedEmbargoes.size()));

    List<ResourceQuota> orderedQuotas =
        (quotas == null ? Map.<UUID, ResourceQuota>of() : quotas)
            .values().stream()
                .filter(java.util.Objects::nonNull)
                .sorted(java.util.Comparator.comparing(ResourceQuota::quotaId))
                .toList();
    for (int index = 0; index < orderedQuotas.size(); index++) {
      ResourceQuota quota = orderedQuotas.get(index);
      String prefix = "quota." + index + '.';
      properties.setProperty(prefix + "id", quota.quotaId().toString());
      properties.setProperty(prefix + "nation", quota.nationId().toString());
      properties.setProperty(prefix + "resource", quota.resourceId());
      properties.setProperty(prefix + "max", Long.toString(quota.maxAmount()));
      properties.setProperty(prefix + "current", Long.toString(quota.currentAmount()));
      properties.setProperty(prefix + "start", quota.startTime().toEpochMilli() + "");
      properties.setProperty(prefix + "reset", quota.resetTime().toEpochMilli() + "");
      properties.setProperty(prefix + "type", quota.type().name());
    }
    properties.setProperty(QUOTA_COUNT, Integer.toString(orderedQuotas.size()));
    return properties;
  }

  static Map<NationId, Map<String, Long>> fromProperties(
      Properties properties, Set<String> allowedResourceTypes) {
    return snapshotFromProperties(properties, allowedResourceTypes).stockpiles();
  }

  static Snapshot snapshotFromProperties(Properties properties, Set<String> allowedResourceTypes) {
    Set<String> allowed =
        allowedResourceTypes == null
            ? Set.of()
            : allowedResourceTypes.stream()
                .map(ResourceStateCodec::normalizeResource)
                .filter(value -> !value.isBlank())
                .collect(Collectors.toUnmodifiableSet());
    int count = snapshotCount(properties, STOCKPILE_COUNT);
    Map<NationId, Map<String, Long>> stockpiles = new LinkedHashMap<>();
    for (int index = 0; index < count; index++) {
      String prefix = "stockpile." + index + '.';
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      String type = normalizeResource(properties.getProperty(prefix + "type"));
      long amount = parseLong(properties.getProperty(prefix + "amount"), 0L);
      if (nationId != null && allowed.contains(type) && amount > 0L) {
        stockpiles
            .computeIfAbsent(nationId, ignored -> new LinkedHashMap<>())
            .putIfAbsent(type, amount);
      }
    }

    Map<String, TransactionReceipt> receipts = new LinkedHashMap<>();
    int receiptCount = snapshotCount(properties, RECEIPT_COUNT);
    for (int index = 0; index < receiptCount; index++) {
      String prefix = "transaction." + index + '.';
      TransactionReceipt receipt = parseReceipt(properties, prefix, allowed);
      if (receipt != null) {
        if (receipts.putIfAbsent(receipt.transactionId(), receipt) != null) {
          LOGGER.warning(
              "Resource transaction receipt skipped code=RESOURCE_STATE_DUPLICATE_TRANSACTION_ID"
                  + " prefix="
                  + prefix);
        }
      }
    }

    Map<NationId, Map<String, Long>> immutableStockpiles = new LinkedHashMap<>();
    stockpiles.forEach((nationId, values) -> immutableStockpiles.put(nationId, Map.copyOf(values)));
    Map<UUID, Factory> factories = new LinkedHashMap<>();
    int factoryCount = snapshotCount(properties, FACTORY_COUNT);
    for (int index = 0; index < factoryCount; index++) {
      Factory factory = parseFactory(properties, "factory." + index + '.');
      if (factory != null && factories.putIfAbsent(factory.factoryId(), factory) != null) {
        LOGGER.warning(
            "Resource factory skipped code=RESOURCE_STATE_DUPLICATE_FACTORY_ID index=" + index);
      }
    }

    Map<UUID, TradeAgreement> agreements = new LinkedHashMap<>();
    int agreementCount = snapshotCount(properties, AGREEMENT_COUNT);
    for (int index = 0; index < agreementCount; index++) {
      TradeAgreement agreement = parseAgreement(properties, "agreement." + index + '.');
      if (agreement != null && agreements.putIfAbsent(agreement.agreementId(), agreement) != null) {
        LOGGER.warning(
            "Resource agreement skipped code=RESOURCE_STATE_DUPLICATE_AGREEMENT_ID index=" + index);
      }
    }

    Map<UUID, TradeRoute> routes = new LinkedHashMap<>();
    int routeCount = snapshotCount(properties, ROUTE_COUNT);
    for (int index = 0; index < routeCount; index++) {
      TradeRoute route = parseRoute(properties, "route." + index + '.');
      if (route != null && routes.putIfAbsent(route.routeId(), route) != null) {
        LOGGER.warning(
            "Resource route skipped code=RESOURCE_STATE_DUPLICATE_ROUTE_ID index=" + index);
      }
    }

    Map<UUID, ResourceEmbargo> embargoes = new LinkedHashMap<>();
    int embargoCount = snapshotCount(properties, EMBARGO_COUNT);
    for (int index = 0; index < embargoCount; index++) {
      ResourceEmbargo embargo = parseEmbargo(properties, "embargo." + index + '.');
      if (embargo != null && embargoes.putIfAbsent(embargo.embargoId(), embargo) != null) {
        LOGGER.warning(
            "Resource embargo skipped code=RESOURCE_STATE_DUPLICATE_EMBARGO_ID index=" + index);
      }
    }

    Map<UUID, ResourceQuota> quotas = new LinkedHashMap<>();
    int quotaCount = snapshotCount(properties, QUOTA_COUNT);
    for (int index = 0; index < quotaCount; index++) {
      ResourceQuota quota = parseQuota(properties, "quota." + index + '.');
      if (quota != null && quotas.putIfAbsent(quota.quotaId(), quota) != null) {
        LOGGER.warning(
            "Resource quota skipped code=RESOURCE_STATE_DUPLICATE_QUOTA_ID index=" + index);
      }
    }

    return new Snapshot(
        Map.copyOf(immutableStockpiles),
        Map.copyOf(receipts),
        Map.copyOf(factories),
        Map.copyOf(agreements),
        Map.copyOf(routes),
        Map.copyOf(embargoes),
        Map.copyOf(quotas));
  }

  private static Factory parseFactory(Properties properties, String prefix) {
    try {
      UUID factoryId = UUID.fromString(properties.getProperty(prefix + "id"));
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      String name = properties.getProperty(prefix + "name");
      Factory.FactoryType type =
          Factory.FactoryType.valueOf(properties.getProperty(prefix + "type"));
      Long buildTimeMillis = parseRequiredLong(properties.getProperty(prefix + "buildTime"));
      int level = Integer.parseInt(properties.getProperty(prefix + "level"));
      double efficiency = Double.parseDouble(properties.getProperty(prefix + "efficiency"));
      boolean operational = Boolean.parseBoolean(properties.getProperty(prefix + "operational"));
      String recipe = properties.getProperty(prefix + "recipe");
      String processingStartValue = properties.getProperty(prefix + "processingStart");
      int batches = Integer.parseInt(properties.getProperty(prefix + "processingBatches", "0"));
      Instant processingStart =
          processingStartValue == null
              ? null
              : Instant.ofEpochMilli(Long.parseLong(processingStartValue));
      if (nationId == null || name == null || name.isBlank() || buildTimeMillis == null) {
        return null;
      }
      return new Factory(
          factoryId,
          nationId,
          name,
          type,
          Instant.ofEpochMilli(buildTimeMillis),
          level,
          efficiency,
          operational,
          recipe,
          processingStart,
          batches);
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING, "Resource factory skipped code=RESOURCE_STATE_FACTORY_FAILURE", exception);
      return null;
    }
  }

  private static TradeAgreement parseAgreement(Properties properties, String prefix) {
    try {
      UUID agreementId = UUID.fromString(properties.getProperty(prefix + "id"));
      NationId exporter = parseNationId(properties.getProperty(prefix + "exporter"));
      NationId importer = parseNationId(properties.getProperty(prefix + "importer"));
      String resource = properties.getProperty(prefix + "resource");
      long amount = Long.parseLong(properties.getProperty(prefix + "amount"));
      double price = Double.parseDouble(properties.getProperty(prefix + "price"));
      Long startMillis = parseRequiredLong(properties.getProperty(prefix + "start"));
      Long expiryMillis = parseRequiredLong(properties.getProperty(prefix + "expiry"));
      if (exporter == null
          || importer == null
          || resource == null
          || startMillis == null
          || expiryMillis == null) {
        return null;
      }
      TradeAgreement agreement =
          new TradeAgreement(
              agreementId,
              exporter,
              importer,
              resource,
              amount,
              price,
              Instant.ofEpochMilli(startMillis),
              Instant.ofEpochMilli(expiryMillis));
      agreement.setAutoRenew(
          Boolean.parseBoolean(properties.getProperty(prefix + "autoRenew", "false")));
      return agreement;
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING,
          "Resource agreement skipped code=RESOURCE_STATE_AGREEMENT_FAILURE",
          exception);
      return null;
    }
  }

  private static TradeRoute parseRoute(Properties properties, String prefix) {
    try {
      UUID routeId = UUID.fromString(properties.getProperty(prefix + "id"));
      NationId origin = parseNationId(properties.getProperty(prefix + "origin"));
      NationId destination = parseNationId(properties.getProperty(prefix + "destination"));
      String name = properties.getProperty(prefix + "name");
      Long established = parseRequiredLong(properties.getProperty(prefix + "established"));
      double efficiency = Double.parseDouble(properties.getProperty(prefix + "efficiency"));
      boolean active = Boolean.parseBoolean(properties.getProperty(prefix + "active", "true"));
      long volume = Long.parseLong(properties.getProperty(prefix + "volume", "0"));
      if (origin == null
          || destination == null
          || name == null
          || name.isBlank()
          || established == null) {
        return null;
      }
      return new TradeRoute(
          routeId,
          origin,
          destination,
          name,
          Instant.ofEpochMilli(established),
          efficiency,
          active,
          volume);
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING, "Resource route skipped code=RESOURCE_STATE_ROUTE_FAILURE", exception);
      return null;
    }
  }

  private static ResourceEmbargo parseEmbargo(Properties properties, String prefix) {
    try {
      UUID embargoId = UUID.fromString(properties.getProperty(prefix + "id"));
      NationId initiator = parseNationId(properties.getProperty(prefix + "initiator"));
      Set<NationId> targets = new java.util.HashSet<>();
      for (String value : properties.getProperty(prefix + "targets", "").split(",")) {
        NationId target = parseNationId(value);
        if (target != null) targets.add(target);
      }
      String resource = properties.getProperty(prefix + "resource");
      Long start = parseRequiredLong(properties.getProperty(prefix + "start"));
      String expiryValue = properties.getProperty(prefix + "expiry");
      Long expiry = expiryValue == null ? null : parseRequiredLong(expiryValue);
      String reason = properties.getProperty(prefix + "reason", "未说明");
      boolean active = Boolean.parseBoolean(properties.getProperty(prefix + "active", "true"));
      if (initiator == null
          || targets.isEmpty()
          || resource == null
          || start == null
          || (expiryValue != null && expiry == null)) {
        return null;
      }
      return new ResourceEmbargo(
          embargoId,
          initiator,
          targets,
          resource,
          Instant.ofEpochMilli(start),
          expiry == null ? null : Instant.ofEpochMilli(expiry),
          reason,
          active);
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING, "Resource embargo skipped code=RESOURCE_STATE_EMBARGO_FAILURE", exception);
      return null;
    }
  }

  private static ResourceQuota parseQuota(Properties properties, String prefix) {
    try {
      UUID quotaId = UUID.fromString(properties.getProperty(prefix + "id"));
      NationId nationId = parseNationId(properties.getProperty(prefix + "nation"));
      String resource = properties.getProperty(prefix + "resource");
      long max = Long.parseLong(properties.getProperty(prefix + "max"));
      long current = Long.parseLong(properties.getProperty(prefix + "current", "0"));
      Long start = parseRequiredLong(properties.getProperty(prefix + "start"));
      Long reset = parseRequiredLong(properties.getProperty(prefix + "reset"));
      ResourceQuota.QuotaType type =
          ResourceQuota.QuotaType.valueOf(properties.getProperty(prefix + "type"));
      if (nationId == null || resource == null || start == null || reset == null) return null;
      return new ResourceQuota(
          quotaId,
          nationId,
          resource,
          max,
          current,
          Instant.ofEpochMilli(start),
          Instant.ofEpochMilli(reset),
          type);
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING, "Resource quota skipped code=RESOURCE_STATE_QUOTA_FAILURE", exception);
      return null;
    }
  }

  private static TransactionReceipt parseReceipt(
      Properties properties, String prefix, Set<String> allowed) {
    try {
      String transactionId = properties.getProperty(prefix + "id");
      NationId nationId = parseNationId(properties.getProperty(prefix + "nationId"));
      Operation operation = Operation.valueOf(properties.getProperty(prefix + "operation", ""));
      Category category = Category.valueOf(properties.getProperty(prefix + "category", ""));
      Map<String, Long> resources =
          decodeResources(properties.getProperty(prefix + "resources", ""), allowed);
      Long appliedAtMillis = parseRequiredLong(properties.getProperty(prefix + "appliedAt"));
      if (transactionId == null
          || transactionId.isBlank()
          || nationId == null
          || resources == null
          || resources.isEmpty()
          || appliedAtMillis == null) {
        return null;
      }
      Instant appliedAt = Instant.ofEpochMilli(appliedAtMillis);
      return new TransactionReceipt(
          transactionId,
          nationId,
          resources,
          operation,
          category,
          properties.getProperty(prefix + "description", ""),
          appliedAt);
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING,
          "Resource transaction receipt skipped code=RESOURCE_STATE_RECEIPT_FAILURE prefix="
              + prefix,
          exception);
      return null;
    }
  }

  private static String encodeResources(Map<String, Long> resources) {
    return resources.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .map(entry -> entry.getKey() + '=' + entry.getValue())
        .collect(Collectors.joining(";"));
  }

  private static Map<String, Long> decodeResources(String value, Set<String> allowed) {
    Map<String, Long> resources = new LinkedHashMap<>();
    if (value == null || value.isBlank()) {
      return resources;
    }
    for (String part : value.split(";")) {
      int separator = part.indexOf('=');
      if (separator <= 0 || separator == part.length() - 1) {
        continue;
      }
      String type = normalizeResource(part.substring(0, separator));
      long amount = parseLong(part.substring(separator + 1), 0L);
      if (allowed.contains(type) && amount > 0L) {
        if (resources.putIfAbsent(type, amount) != null) {
          return null;
        }
      }
    }
    return resources;
  }

  private static String normalizeResource(String resourceType) {
    return resourceType == null ? "" : resourceType.trim().toLowerCase(Locale.ROOT);
  }

  private static NationId parseNationId(String value) {
    if (value == null) {
      return null;
    }
    try {
      return new NationId(UUID.fromString(value));
    } catch (IllegalArgumentException exception) {
      return null;
    }
  }

  private static int snapshotCount(Properties properties, String key) {
    int count = parseInt(properties.getProperty(key), 0);
    // SQL migration also uses this legacy decoder before ResourceModule establishes authority.
    // A declared row needs at least one actual field; inherited Properties remain supported.
    if (count > properties.size() && count > properties.stringPropertyNames().size())
      throw new IllegalStateException("Resource snapshot count exceeds input fields: " + key);
    return count;
  }

  private static int parseInt(String value, int fallback) {
    if (value == null) {
      return fallback;
    }
    try {
      return Integer.parseInt(value);
    } catch (NumberFormatException exception) {
      return fallback;
    }
  }

  private static Long parseRequiredLong(String value) {
    if (value == null) {
      return null;
    }
    try {
      return Long.parseLong(value);
    } catch (NumberFormatException exception) {
      LOGGER.log(
          Level.WARNING,
          "Resource state number ignored code=RESOURCE_STATE_NUMBER_FAILURE",
          exception);
      return null;
    }
  }

  private static long parseLong(String value, long fallback) {
    if (value == null) {
      return fallback;
    }
    try {
      return Long.parseLong(value);
    } catch (NumberFormatException exception) {
      return fallback;
    }
  }
}
