import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


final_log = root / 'run/inventory-validation-resource-verify-20261126.log'
text = final_log.read_text(encoding='utf-8', errors='replace')
assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text
totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
by_package = {}
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', text):
    report = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(report.read_bytes())
    package = 'resource' if '.resource.' in name else 'technology'
    by_package[package] = by_package.get(package, 0) + int(suite.attrib['tests'])
    for key in totals:
        totals[key] += int(suite.attrib[key])
    add(report, 'native-final/surefire/' + report.name)
assert by_package['resource'] >= 532
assert all(totals[key] == 0 for key in ('failures', 'errors', 'skipped'))
red_xml = next((root / 'run/inventory-validation-red-20261126').glob('TEST-*.xml'))
red = ET.fromstring(red_xml.read_bytes())
red_totals = {key: int(red.attrib[key]) for key in totals}
assert red_totals == {'tests': 111, 'failures': 110, 'errors': 0, 'skipped': 0}
for path in (root / 'run/inventory-validation-red-20261126').iterdir():
    add(path, 'red/' + path.name)
for directory in (root / 'run').glob('inventory-validation-failure-*'):
    for path in directory.glob('*.xml'):
        add(path, 'prior-failures/' + directory.name + '/' + path.name)
for path in (root / 'run').glob('inventory-validation-*.log'):
    add(path, 'logs/' + path.name)
add(root / 'run/inventory-validation-baseline-ci-20261126.json', 'github/baseline-ci.json')
contracts = {}
for label, dirname in [('factory', 'factory-contract-validation-20261126-1'),
                        ('capacity', 'factory-archive-validation-20261126-1')]:
    directory = root / 'run' / dirname
    manifest = json.loads((directory / 'manifest.json').read_text())
    assert manifest['status'] == 'PASS'
    contracts[label] = manifest
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java'):
            add(path, label + '/' + path.relative_to(directory).as_posix())
for name in ('FactoryRecoveryProbe.java', 'FactoryArchiveProbe.java',
             'run-factory-archive-capacity.py', 'run-factory-stable-capacity.py',
             'run-capacity-contract.py', 'FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-inventory-validation-evidence.py')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
source_hashes = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if name.startswith('src/') and (native / name).is_file():
        add(native / name, 'source/' + name)
        source_hashes[name] = digest((native / name).read_bytes())
starcore_hash = digest((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle_hash = digest((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore_hash == contracts['factory']['artifacts']['starcore.jar'] == contracts['capacity']['artifacts']['current.jar']
assert chronicle_hash == contracts['factory']['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': 'a514475134d46f1a62366d333617b8315a05963f',
                  'starcore': '2d75e908c4f7a077435256c3ea6d42ca4f1da18b'},
    'scope': 'Inventory and transaction snapshot integrity, real file and SQLite/H2 malformed state, fail-closed authority and bounded legacy collection counts; resource regression, packaged factory and capacity contracts; no Minecraft',
    'red_tests': red_totals, 'native_tests': totals, 'tests_by_package': by_package,
    'new_inventory_validation_tests': 132,
    'chronicle_tests': 'Main source unchanged; previous 957-test JAR. Baseline GitHub Linux CI #107 passed. No new local full verify.',
    'artifacts': {'starcore_sha256': starcore_hash, 'starchronicle_sha256': chronicle_hash},
    'contracts': contracts, 'native_source_hashes': source_hashes,
    'coverage': 'No current native full suite or JaCoCo; forkCount=0 and jacoco.skip=true',
    'limits': [
        'Boolean inventory APIs have no stable operation ID: false after persistence failure is unconfirmed, not proof of rollback.',
        'Keyed transactions confirm ALREADY_APPLIED only from a matching restored receipt; otherwise REJECTED is retained for API compatibility.',
        'Unreadable or changed storage authority quarantines writes and receipt queries until validated restart.',
        'Authoritative inventory and transaction recovery is strict; other trade field parsing remains permissive. Valid-format arbitrary tampering is not authenticated.',
        'First legacy migration and file history remain full-size; long concurrent load, MySQL, Folia and actual plugin stack are unverified.'
    ]
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: digest(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/inventory-validation-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(archive.read(name)) == expected
summary['evidence_zip_sha256'] = digest(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'inventory-validation-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': by_package, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
