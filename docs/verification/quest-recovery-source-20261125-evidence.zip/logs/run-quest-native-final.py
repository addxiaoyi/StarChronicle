import os
from pathlib import Path
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')
root=Path(r'C:\Users\Administrator\Documents\StarChronicle-audit\starcore-all-stages')
logs=Path(r'C:\Users\Administrator\Documents\StarChronicle\run')
env=os.environ.copy()
env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']='-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8 -javaagent:C:\\Users\\Administrator\\.m2\\repository\\org\\mockito\\mockito-core\\5.23.0\\mockito-core-5.23.0.jar'
commands=[('quest-recovery-format4.log',['-DspotlessFiles=.*QuestEvidenceService.java,.*QuestEvidenceServiceTest.java','spotless:apply']),
          ('quest-recovery-native-final.log',['-DforkCount=0','-Dtest=QuestEvidenceServiceTest,QuestTrackedRunPersistenceTest,QuestCompletionJournalTest,QuestEvidenceAuthorityTest,QuestEvidenceQueueTest,QuestEvidenceNativeMenuTest,QuestEvidenceFoliaOwnerTest,QuestEvidenceFoliaGuardTest,PlayerQuestTest,QuestPersistenceHandlerTest,PublicApiCompatibilityTest','verify'])]
for name,args in commands:
    with (logs/name).open('wb') as out:
        result=subprocess.run([str(root/'mvnw.cmd'),'-B','-ntp',*args],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    print(name,result.returncode,flush=True)
    if result.returncode: sys.exit(result.returncode)
