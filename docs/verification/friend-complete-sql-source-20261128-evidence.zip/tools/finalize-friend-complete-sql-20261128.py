from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
attempt=sys.argv[2] if len(sys.argv)>2 else 'native-friend-complete-sql-focused-1-20261128'
tests=json.loads((root/'run'/attempt/'result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][k]==0 for k in ('failures','errors','skipped'))
frozen=root/'run/friend-complete-sql-frozen-pair-1-20261128'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
if sys.argv[1]=='freeze':
    frozen.mkdir();manifest={}
    for name,source,key in [
        ('chronicle.jar',root/'run/party-command-frozen-pair-1-20261128/chronicle.jar',None),
        ('native.jar',native/'target/starcore-1.0.0.jar','starcore-1.0.0.jar'),
        ('original-native.jar',native/'target/original-starcore-1.0.0.jar','original-starcore-1.0.0.jar')]:
        original=digest(source)
        if key:assert original==tests['artifacts'][key]
        if key:shutil.copy2(source,frozen/name)
        else:os.link(source,frozen/name)
        assert digest(frozen/name)==original
        manifest[name]={'sha256':original,'bytes':source.stat().st_size,'source':str(source)}
    (frozen/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest));sys.exit()
pair=json.loads((root/'run/friend-complete-sql-pair-artifacts-1-20261128/result.json').read_text());assert pair['status']=='VERIFIED'
replicas=json.loads((root/'run/friend-complete-sql-replicas-1-20261128/result.json').read_text());assert replicas['status']=='VERIFIED'
files={}
folders=[('validation',attempt),('replicas','friend-complete-sql-replicas-1-20261128'),('pair','friend-complete-sql-pair-artifacts-1-20261128'),('frozen',frozen.name)]
for previous in sorted((root/'run').glob('native-friend-complete-sql-focused-*-20261128')):
    if previous.name!=attempt:folders.append(('prior-'+previous.name,previous.name))
for label,name in folders:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class','.mdmp'):files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','tools/verify-friend-complete-sql.py','tools/FriendCompleteSqlProbe.java','tools/FriendStateRecoveryProbe.java','tools/test_snapshot_maven_validation.py','run/snapshot-reuse-tests-20261128.json',
             'run/validate-friend-complete-sql-20261128.py','run/finalize-friend-complete-sql-20261128.py','run/friend-complete-sql-format-20261128.log']:
    files['tools/'+Path(name).name]=root/name
manifest={name:digest(path) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],'artifacts':json.loads((frozen/'manifest.json').read_text()),'fixtures_compiled':pair['fixtures']['count'],'replica_jvms':len(replicas['runs']),
    'limits':['Related tests only, not full StarCore regression. SQLite only; MySQL not run.',
      'Complete logical friend-state commits use a shared SQL gate and expected-state comparison; unchanged row IDs, original times and extension columns are preserved.',
      'Historical one-row friendship retains its undirected meaning without rewriting the original row on no-op saves. Unknown-direction legacy contacts have separate storage and cannot grant consent.',
      'Handled/expired old requests remain unchanged and cannot authorize a stale acceptance; explicit reissue keeps row identity while creating fresh consent/time.',
      'Compatibility snapshot saves merge online statuses; the new complete expected-state API explicitly permits removing supplied stale status entries. External writers that bypass the gate are not globally fenced.',
      'Actual FriendService runtime mutation integration and cross-service import/recovery remain source work, as do other phases.',
      'No Minecraft/Paper/Folia, deployment, live acceptance or sustained mixed-writer load.']}
out=root/'docs/verification/friend-complete-sql-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,expected in manifest.items():assert hashlib.sha256(archive.read(name)).hexdigest()==expected,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=digest(out),files=manifest)
(root/'docs/verification/friend-complete-sql-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
