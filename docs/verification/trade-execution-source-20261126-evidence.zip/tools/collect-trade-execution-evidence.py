import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


for label in ('final-test', 'package', 'sbom'):
    log = (root / f'run/trade-execution-{label}-20261126.log').read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESS' in log and 'BUILD FAILURE' not in log, label
log = (root / 'run/trade-execution-final-test-20261126.log').read_text(encoding='utf-8', errors='replace')
totals = dict(tests=0, failures=0, errors=0, skipped=0)
packages = {}
suites = {}
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', log):
    report = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(report.read_bytes())
    assert name not in suites
    suites[name] = int(suite.attrib['tests'])
    group = 'resource' if '.resource.' in name else 'treasury' if '.treasury.' in name else 'technology'
    packages[group] = packages.get(group, 0) + suites[name]
    for key in totals:
        totals[key] += int(suite.attrib[key])
    add(report, 'native-final/surefire/' + report.name)
assert totals['tests'] >= 1391 and all(totals[k] == 0 for k in ('failures', 'errors', 'skipped')), totals
new_tests = sum(count for name, count in suites.items() if name.endswith(('NativeTradeExecutionRecoveryTest', 'NativeTradeExecutionValidationTest', 'ResourceTradeExecutionCommandTest')))
assert new_tests >= 145
failures = {}
for folder in sorted((root / 'run').glob('trade-execution-*-failure-20261126')):
    counts = dict(tests=0, failures=0, errors=0, skipped=0)
    for path in folder.rglob('*'):
        if path.is_file():
            add(path, 'failures/' + folder.name + '/' + path.relative_to(folder).as_posix())
            if path.name.startswith('TEST-') and path.suffix == '.xml':
                suite = ET.fromstring(path.read_bytes())
                for key in counts:
                    counts[key] += int(suite.attrib[key])
    failures[folder.name] = counts
for path in (root / 'run').glob('trade-execution-*.log'):
    add(path, 'logs/' + path.name)
for path in (root / 'run/trade-execution-candidate-20261126').iterdir():
    if path.is_file():
        add(path, 'prior-success/' + path.name)
add(root / 'run/treasury-recovery-final-ci-20261126.json', 'github/baseline-ci.json')
contracts = {}
for label, folder in (('trade', 'trade-execution-contract-20261126-2'), ('factory', 'factory-contract-trade-execution-20261126-2')):
    directory = root / 'run' / folder
    contracts[label] = json.loads((directory / 'manifest.json').read_text())
    assert contracts[label]['status'] == 'PASS'
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java', '.txt'):
            add(path, label + '/' + path.relative_to(directory).as_posix())
for name in ('TradeExecutionProbe.java', 'run-trade-execution-contract.py', 'FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-trade-execution-evidence.py')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
source_hashes = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        source_hashes[name] = digest((native / name).read_bytes())
starcore_hash = digest((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle_hash = digest((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore_hash == contracts['trade']['artifacts']['starcore.jar'] == contracts['factory']['artifacts']['starcore.jar']
assert chronicle_hash == contracts['trade']['artifacts']['starchronicle.jar'] == contracts['factory']['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': 'd16eb08cd8d1450218c1d8c11d687a9c5dff7925', 'starcore': '7440cb42b436760b6b8b196773eaaeb34e971f30'},
    'scope': 'Native durable national trade intent, bilateral founder approvals, frozen terms, stable payment/delivery/refund IDs, atomic quota reservations and terminal route statistics, direct quota save/reconciliation, public inspect/approve/retry and bounded recovery; no Minecraft',
    'native_tests': totals, 'tests_by_package': packages, 'new_tests': new_tests,
    'native_source_hashes': source_hashes, 'preserved_failures': failures,
    'packaging': 'Sequential 256 MiB JVMs; verify uses tested classes, skips recompilation/tests, checks formatting; separate SBOM',
    'chronicle_tests': 'No main-source change or new local full test. Prior 957-test artifact reused; baseline d16eb08 Linux Maven verification #143 succeeded.',
    'artifacts': {'starcore_sha256': starcore_hash, 'starchronicle_sha256': chronicle_hash},
    'contracts': contracts,
    'coverage': 'Focused native suite, forkCount=0, jacoco.skip=true; no current native full-suite or MySQL certification.',
    'limits': [
        'Recovery protocol across two authorities, not a distributed transaction. Unknown effects retain original IDs; unavailable authorities require recovery and reload.',
        'Memory completion events are best effort; durable resource receipts supply history without fabricated actor contributions.',
        'Execution ledger and treasury receipts remain resident; large-ledger performance and long-term capacity remain pending.',
        'Legacy boolean API is trusted automation. Explicit IDs are required for reliable cross-call replay; no durable guarantee for the non-native compatibility provider.',
        'Direct quota use is synchronous but not keyed for retry; query an uncertain usage after authority recovery.',
        'Local committed reads do not prove multi-instance linearizability. MySQL, Minecraft, full-stack Folia and third-party production combinations remain pending.'
    ]
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: digest(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/trade-execution-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(archive.read(name)) == expected
summary['evidence_zip_sha256'] = digest(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'trade-execution-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': packages, 'new_tests': new_tests, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
