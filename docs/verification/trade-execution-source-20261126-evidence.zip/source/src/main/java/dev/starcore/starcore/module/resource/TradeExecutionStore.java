package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

/**
 * Canonical versioned execution ledger stored in the same snapshot as quota usage and route stats.
 */
final class TradeExecutionStore {
  static final String PREFIX = "resource.trade-executions.";

  private TradeExecutionStore() {}

  static void write(Properties state, Map<String, TradeExecution> executions) {
    state.keySet().removeIf(key -> key instanceof String text && text.startsWith(PREFIX));
    state.setProperty(PREFIX + "version", "1");
    state.setProperty(PREFIX + "count", Integer.toString(executions.size()));
    for (var entry : executions.entrySet()) {
      var value = entry.getValue();
      if (!entry.getKey().equals(value.executionId()))
        throw new IllegalStateException("Invalid execution identity");
      String row = PREFIX + "row." + hash(value.executionId()) + ".";
      put(state, row, "id", value.executionId());
      put(state, row, "agreement", value.agreementId());
      put(state, row, "resource-domain", value.resourceDomain());
      put(state, row, "treasury-domain", value.treasuryDomain());
      put(state, row, "exporter", value.exporter());
      put(state, row, "importer", value.importer());
      put(state, row, "resource", value.resourceId());
      put(state, row, "amount", value.amount());
      put(state, row, "price", value.pricePerUnit());
      put(state, row, "total", value.totalPrice());
      put(state, row, "created", value.createdAt().toEpochMilli());
      put(state, row, "expires", value.expiresAt().toEpochMilli());
      put(state, row, "export-approval", value.exporterApproval());
      put(state, row, "import-approval", value.importerApproval());
      put(state, row, "system", value.system());
      put(state, row, "state", value.state());
      put(state, row, "route", value.routeId());
      put(state, row, "sequence", value.deliverySequence());
      put(
          state,
          row,
          "finished",
          value.finishedAt() == null ? "" : value.finishedAt().toEpochMilli());
      String holds =
          value.reservations().stream()
              .sorted(Comparator.comparing(r -> r.quotaId().toString()))
              .map(
                  r ->
                      r.quotaId() + ":" + r.start().toEpochMilli() + ":" + r.reset().toEpochMilli())
              .collect(java.util.stream.Collectors.joining(";"));
      put(state, row, "reservations", holds);
    }
    state.setProperty(PREFIX + "head", fingerprint(state));
  }

  static Map<String, TradeExecution> read(Properties state, ResourceStateStorage storage) {
    Set<String> keys = new TreeSet<>();
    for (String key : state.stringPropertyNames()) if (key.startsWith(PREFIX)) keys.add(key);
    if (keys.isEmpty()) return Map.of();
    try {
      if (!"1".equals(state.getProperty(PREFIX + "version"))
          || !fingerprint(state).equals(state.getProperty(PREFIX + "head")))
        throw new IllegalArgumentException("Trade ledger fingerprint/version mismatch");
      int count = Integer.parseInt(state.getProperty(PREFIX + "count"));
      if (count < 0 || count > keys.size() / 20)
        throw new IllegalArgumentException("Invalid execution count");
      Map<String, TradeExecution> executions = new LinkedHashMap<>();
      for (String key : keys) {
        if (!key.startsWith(PREFIX + "row.") || !key.endsWith(".id")) continue;
        String row = key.substring(0, key.length() - 2);
        String id = required(state, row + "id");
        List<TradeExecution.QuotaReservation> holds = new ArrayList<>();
        String reservations = required(state, row + "reservations");
        if (!reservations.isEmpty())
          for (String part : reservations.split(";", -1)) {
            String[] pieces = part.split(":", -1);
            if (pieces.length != 3) throw new IllegalArgumentException("Invalid reservation");
            holds.add(
                new TradeExecution.QuotaReservation(
                    UUID.fromString(pieces[0]),
                    Instant.ofEpochMilli(Long.parseLong(pieces[1])),
                    Instant.ofEpochMilli(Long.parseLong(pieces[2]))));
          }
        var value =
            new TradeExecution(
                id,
                UUID.fromString(required(state, row + "agreement")),
                required(state, row + "resource-domain"),
                required(state, row + "treasury-domain"),
                NationId.fromString(required(state, row + "exporter")),
                NationId.fromString(required(state, row + "importer")),
                required(state, row + "resource"),
                Long.parseLong(required(state, row + "amount")),
                Double.parseDouble(required(state, row + "price")),
                new BigDecimal(required(state, row + "total")),
                time(state, row + "created"),
                time(state, row + "expires"),
                uuid(state, row + "export-approval"),
                uuid(state, row + "import-approval"),
                bool(state, row + "system"),
                TradeExecution.State.valueOf(required(state, row + "state")),
                holds,
                uuid(state, row + "route"),
                Long.parseLong(required(state, row + "sequence")),
                required(state, row + "finished").isEmpty() ? null : time(state, row + "finished"));
        if (!value.resourceDomain().equals(state.getProperty("resource.authority-domain"))
            || executions.put(id, value) != null)
          throw new IllegalArgumentException("Execution domain/identity mismatch");
        if (value.state() == TradeExecution.State.COMPLETED) {
          if (storage == null)
            throw new IllegalArgumentException("Delivery receipt authority unavailable");
          var receipt = storage.transferReceipt(value.operationId("delivery")).orElseThrow();
          if (!NativeTradeExecution.deliveryMatches(value, receipt)
              || receipt.sequence() != value.deliverySequence()
              || !receipt.appliedAt().equals(value.finishedAt()))
            throw new IllegalArgumentException("Trade completion lacks matching delivery");
        }
      }
      if (executions.size() != count) throw new IllegalArgumentException("Missing execution rows");
      validateReservations(state, executions);
      Properties canonical = new Properties();
      write(canonical, executions);
      if (!canonical.stringPropertyNames().equals(keys))
        throw new IllegalArgumentException("Unknown or missing execution fields");
      for (String key : keys)
        if (!canonical.getProperty(key).equals(state.getProperty(key)))
          throw new IllegalArgumentException("Noncanonical execution field " + key);
      return Map.copyOf(executions);
    } catch (RuntimeException error) {
      throw new IllegalStateException("Trade execution state requires recovery", error);
    }
  }

  private static void validateReservations(
      Properties state, Map<String, TradeExecution> executions) {
    var snapshot = ResourceStateCodec.snapshotFromProperties(state, ResourceModule.RESOURCE_TYPES);
    Map<UUID, Long> reserved = new HashMap<>();
    for (var execution : executions.values()) {
      for (var hold : execution.reservations()) {
        var quota = snapshot.quotas().get(hold.quotaId());
        if (quota == null) throw new IllegalArgumentException("Missing reserved quota");
        if (!quota.resourceId().equals(execution.resourceId())
            || !(quota.nationId().equals(execution.exporter())
                    && quota.type()
                        == dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType
                            .EXPORT
                || quota.nationId().equals(execution.importer())
                    && quota.type()
                        == dev.starcore.starcore.module.resource.model.ResourceQuota.QuotaType
                            .IMPORT))
          throw new IllegalArgumentException("Reserved quota terms changed");
        if (execution.state() != TradeExecution.State.REJECTED
            && execution.state() != TradeExecution.State.REFUNDED
            && quota.startTime().equals(hold.start())
            && quota.resetTime().equals(hold.reset()))
          reserved.merge(hold.quotaId(), execution.amount(), Math::addExact);
      }
      if (execution.routeId() != null) {
        var route = snapshot.routes().get(execution.routeId());
        if (route == null || !route.connectsBoth(execution.exporter(), execution.importer()))
          throw new IllegalArgumentException("Trade execution route changed");
      }
    }
    for (var entry : reserved.entrySet())
      if (entry.getValue() > snapshot.quotas().get(entry.getKey()).currentAmount())
        throw new IllegalArgumentException("Missing reserved quota usage");
  }

  static String hash(String value) {
    try {
      return HexFormat.of()
          .formatHex(
              MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  private static String fingerprint(Properties state) {
    var text = new StringBuilder();
    state.stringPropertyNames().stream()
        .filter(key -> key.startsWith(PREFIX) && !key.equals(PREFIX + "head"))
        .sorted()
        .forEach(
            key -> {
              String value = state.getProperty(key);
              text.append(key.length())
                  .append(':')
                  .append(key)
                  .append(value.length())
                  .append(':')
                  .append(value);
            });
    return hash(text.toString());
  }

  private static void put(Properties state, String row, String field, Object value) {
    state.setProperty(row + field, Objects.toString(value, ""));
  }

  private static String required(Properties state, String key) {
    return Objects.requireNonNull(state.getProperty(key), key);
  }

  private static UUID uuid(Properties state, String key) {
    String value = required(state, key);
    return value.isEmpty() ? null : UUID.fromString(value);
  }

  private static Instant time(Properties state, String key) {
    return Instant.ofEpochMilli(Long.parseLong(required(state, key)));
  }

  private static boolean bool(Properties state, String key) {
    String value = required(state, key);
    if (!value.equals("true") && !value.equals("false")) throw new IllegalArgumentException(key);
    return Boolean.parseBoolean(value);
  }
}
