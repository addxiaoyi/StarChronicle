package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Immutable intent and recovery checkpoint. Never discard terminal IDs or their frozen terms. */
public record TradeExecution(
    String executionId,
    UUID agreementId,
    String resourceDomain,
    String treasuryDomain,
    NationId exporter,
    NationId importer,
    String resourceId,
    long amount,
    double pricePerUnit,
    BigDecimal totalPrice,
    Instant createdAt,
    Instant expiresAt,
    UUID exporterApproval,
    UUID importerApproval,
    boolean system,
    State state,
    List<QuotaReservation> reservations,
    UUID routeId,
    long deliverySequence,
    Instant finishedAt) {
  public enum State {
    AWAITING_APPROVAL,
    PREPARED,
    PAID,
    REFUND_PENDING,
    COMPLETED,
    REJECTED,
    REFUNDED;

    public boolean terminal() {
      return this == COMPLETED || this == REJECTED || this == REFUNDED;
    }
  }

  public record QuotaReservation(UUID quotaId, Instant start, Instant reset) {
    public QuotaReservation {
      Objects.requireNonNull(quotaId);
      millis(start);
      millis(reset);
      if (!reset.isAfter(start))
        throw new IllegalArgumentException("Invalid quota reservation window");
    }
  }

  public TradeExecution {
    ProductionReceipt.token(executionId, 96);
    Objects.requireNonNull(agreementId);
    domain(resourceDomain);
    domain(treasuryDomain);
    Objects.requireNonNull(exporter);
    Objects.requireNonNull(importer);
    if (exporter.equals(importer)
        || !ResourceModule.RESOURCE_TYPES.contains(resourceId)
        || amount < 1
        || !Double.isFinite(pricePerUnit)
        || pricePerUnit <= 0) throw new IllegalArgumentException("Invalid trade terms");
    BigDecimal computed =
        BigDecimal.valueOf(pricePerUnit)
            .multiply(BigDecimal.valueOf(amount))
            .setScale(2, RoundingMode.HALF_UP);
    if (computed.signum() <= 0
        || computed.compareTo(new BigDecimal("1000000000000000.00")) > 0
        || totalPrice == null
        || computed.compareTo(totalPrice) != 0)
      throw new IllegalArgumentException("Invalid trade price");
    totalPrice = computed;
    millis(createdAt);
    millis(expiresAt);
    if (!expiresAt.isAfter(createdAt)) throw new IllegalArgumentException("Expired trade intent");
    Objects.requireNonNull(state);
    reservations = List.copyOf(reservations);
    if (reservations.stream().map(QuotaReservation::quotaId).distinct().count()
        != reservations.size()) throw new IllegalArgumentException("Duplicate quota reservation");
    if (system && (exporterApproval != null || importerApproval != null))
      throw new IllegalArgumentException("Mixed system and player approvals");
    if (state != State.AWAITING_APPROVAL
        && state != State.REJECTED
        && !system
        && (exporterApproval == null || importerApproval == null))
      throw new IllegalArgumentException("Trade requires both approvals");
    if (state == State.AWAITING_APPROVAL && (!reservations.isEmpty() || routeId != null))
      throw new IllegalArgumentException("Unapproved trade reserved assets");
    if (state.terminal() != (finishedAt != null))
      throw new IllegalArgumentException("Invalid terminal time");
    // Delivery time comes from its own authority clock, which may move backwards.
    if (finishedAt != null) {
      millis(finishedAt);
      if (state != State.COMPLETED && finishedAt.isBefore(createdAt))
        throw new IllegalArgumentException("Invalid completion time");
    }
    if ((state == State.COMPLETED) != (deliverySequence > 0) || deliverySequence < 0)
      throw new IllegalArgumentException("Invalid delivery sequence");
  }

  public boolean involves(NationId nation) {
    return exporter.equals(nation) || importer.equals(nation);
  }

  public boolean approved() {
    return system || exporterApproval != null && importerApproval != null;
  }

  TradeExecution approve(NationId nation, UUID actor) {
    return copy(
        state,
        reservations,
        routeId,
        deliverySequence,
        finishedAt,
        exporter.equals(nation) ? actor : exporterApproval,
        importer.equals(nation) ? actor : importerApproval);
  }

  TradeExecution prepared(List<QuotaReservation> holds, UUID route) {
    return copy(State.PREPARED, holds, route, 0, null, exporterApproval, importerApproval);
  }

  TradeExecution transition(State next, long sequence, Instant finished) {
    boolean allowed =
        switch (state) {
          case AWAITING_APPROVAL -> next == State.REJECTED;
          case PREPARED -> next == State.PAID || next == State.REJECTED;
          case PAID -> next == State.COMPLETED || next == State.REFUND_PENDING;
          case REFUND_PENDING -> next == State.REFUNDED;
          default -> false;
        };
    if (!allowed)
      throw new IllegalStateException("Invalid trade transition " + state + " -> " + next);
    return copy(
        next, reservations, routeId, sequence, finished, exporterApproval, importerApproval);
  }

  private TradeExecution copy(
      State status,
      List<QuotaReservation> holds,
      UUID route,
      long sequence,
      Instant finished,
      UUID exportApproval,
      UUID importApproval) {
    return new TradeExecution(
        executionId,
        agreementId,
        resourceDomain,
        treasuryDomain,
        exporter,
        importer,
        resourceId,
        amount,
        pricePerUnit,
        totalPrice,
        createdAt,
        expiresAt,
        exportApproval,
        importApproval,
        system,
        status,
        holds,
        route,
        sequence,
        finished);
  }

  String operationId(String phase) {
    return "resource-trade:"
        + TradeExecutionStore.hash(resourceDomain + "\n" + treasuryDomain + "\n" + executionId)
        + ":"
        + phase;
  }

  String description() {
    return "Resource trade execution " + executionId + " agreement " + agreementId;
  }

  private static void domain(String value) {
    if (value == null || !UUID.fromString(value).toString().equals(value))
      throw new IllegalArgumentException("Invalid trade authority domain");
  }

  static void millis(Instant time) {
    if (time == null || !time.equals(Instant.ofEpochMilli(time.toEpochMilli())))
      throw new IllegalArgumentException("Trade times use milliseconds");
  }
}
