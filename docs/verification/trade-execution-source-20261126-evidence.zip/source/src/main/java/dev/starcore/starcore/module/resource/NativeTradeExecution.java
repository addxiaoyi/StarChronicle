package dev.starcore.starcore.module.resource;

import static dev.starcore.starcore.module.resource.ResourceTradeService.ExecutionStatus.*;

import dev.starcore.starcore.module.resource.ResourceTradeService.ExecutionRequest;
import dev.starcore.starcore.module.resource.ResourceTradeService.ExecutionResult;
import dev.starcore.starcore.module.resource.TradeExecution.State;
import dev.starcore.starcore.module.resource.model.TradeAgreement;
import dev.starcore.starcore.module.treasury.NationTransferService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.util.*;

/** Runs under the native resource monitor. Every cross-service effect has a persisted intent. */
final class NativeTradeExecution {
  private final ResourceModule module;
  private final SimpleResourceTradeService trades;
  private final TreasuryService treasury;
  private final Clock clock;

  NativeTradeExecution(
      ResourceModule module,
      SimpleResourceTradeService trades,
      TreasuryService treasury,
      Clock clock) {
    this.module = module;
    this.trades = trades;
    this.treasury = treasury;
    this.clock = clock;
  }

  ExecutionResult execute(ExecutionRequest request, boolean approve) {
    TradeExecution execution = null;
    if (!module.nativeTradeStorageAvailable(trades)) return result(UNAVAILABLE, null);
    try {
      execution = module.nativeTradeExecution(request.executionId()).orElse(null);
      if (execution != null) {
        if (!execution.agreementId().equals(request.agreementId())
            || !authorized(execution, request.actorId())) return result(REJECTED, null);
        if (execution.state().terminal()) return terminal(execution);
        if (execution.state() == State.AWAITING_APPROVAL && approve) {
          // Trusted retries never supply a missing player's consent.
          if (request.actorId() == null && !execution.system()) return result(REJECTED, execution);
          var approved = approval(execution, request.actorId());
          if (!approved.equals(execution)) {
            if (!module.saveTradeExecution(approved)) return result(UNKNOWN, execution);
            execution = approved;
          }
        }
      } else {
        if (!approve) return result(REJECTED, null);
        if (!(treasury instanceof NationTransferService) || !domain(treasury.authorityDomainId()))
          return result(UNAVAILABLE, null);
        var agreement = trades.getTradeAgreement(request.agreementId()).orElse(null);
        Instant now = now();
        if (agreement == null
            || !valid(agreement, now)
            || !authorized(agreement, request.actorId())) return result(REJECTED, null);
        execution =
            new TradeExecution(
                request.executionId(),
                request.agreementId(),
                module.authorityDomainId(),
                treasury.authorityDomainId(),
                agreement.exporterNationId(),
                agreement.importerNationId(),
                agreement.resourceId(),
                agreement.amount(),
                agreement.pricePerUnit(),
                BigDecimal.valueOf(agreement.pricePerUnit())
                    .multiply(BigDecimal.valueOf(agreement.amount()))
                    .setScale(2, RoundingMode.HALF_UP),
                now,
                Instant.ofEpochMilli(agreement.expiryTime().toEpochMilli()),
                null,
                null,
                request.actorId() == null,
                State.AWAITING_APPROVAL,
                List.of(),
                null,
                0,
                null);
        execution = approval(execution, request.actorId());
        if (!module.saveTradeExecution(execution)) return result(UNKNOWN, null);
      }
      if (execution.state() == State.AWAITING_APPROVAL) {
        // Retry is not approval, even when the caller happens to be the other founder.
        if (!approve && !execution.approved()) return result(AWAITING_APPROVAL, execution);
        var agreement = trades.getTradeAgreement(execution.agreementId()).orElse(null);
        if (!validIntent(execution, agreement)) {
          var rejected = execution.transition(State.REJECTED, 0, finished(execution));
          return module.saveTradeExecution(rejected)
              ? terminal(rejected)
              : result(UNKNOWN, execution);
        }
        if (!execution.approved()) return result(AWAITING_APPROVAL, execution);
        if (!authorities(execution)) return result(UNKNOWN, execution);
        var holds = trades.reserveExecutionQuotas(execution, now());
        var next =
            holds == null
                ? execution.transition(State.REJECTED, 0, finished(execution))
                : execution.prepared(holds, trades.executionRoute(execution));
        if (!module.saveTradeExecution(next)) return result(UNKNOWN, execution);
        execution = next;
      }
      return resume(execution);
    } catch (RuntimeException unavailable) {
      // No speculative rollback. Recovery always reuses this intent and the original effect IDs.
      return result(UNKNOWN, execution);
    }
  }

  private ExecutionResult resume(TradeExecution execution) {
    if (execution.state().terminal()) return terminal(execution);
    if (!authorities(execution)) return result(UNKNOWN, execution);
    if (execution.state() == State.PREPARED) {
      Money outcome = transferMoney(execution, false);
      if (outcome == Money.UNKNOWN) return result(UNKNOWN, execution);
      var next =
          execution.transition(
              outcome == Money.COMMITTED ? State.PAID : State.REJECTED,
              0,
              outcome == Money.COMMITTED ? null : finished(execution));
      if (outcome == Money.REJECTED) trades.releaseExecutionQuotas(execution);
      if (!module.saveTradeExecution(next)) return result(UNKNOWN, execution);
      execution = next;
      if (execution.state().terminal()) return terminal(execution);
    }
    if (execution.state() == State.PAID) {
      if (!authorities(execution)) return result(UNKNOWN, execution);
      if (!paymentExists(execution)) return result(UNKNOWN, execution);
      var receipt = module.transferReceipt(execution.operationId("delivery"));
      if (receipt.isEmpty()) {
        var transfer = module.transfer(delivery(execution));
        if (!authorities(execution)) return result(UNKNOWN, execution);
        receipt = module.transferReceipt(execution.operationId("delivery"));
        if (receipt.isEmpty()) {
          if (transfer.status() != NationResourceTransactionService.TransferStatus.REJECTED
              && transfer.status()
                  != NationResourceTransactionService.TransferStatus.INSUFFICIENT_RESOURCES)
            return result(UNKNOWN, execution);
          var pending = execution.transition(State.REFUND_PENDING, 0, null);
          if (!module.saveTradeExecution(pending)) return result(UNKNOWN, execution);
          execution = pending;
        }
      }
      if (receipt.isPresent()) {
        if (!deliveryMatches(execution, receipt.get())) return result(UNKNOWN, execution);
        var completed =
            execution.transition(
                State.COMPLETED, receipt.get().sequence(), receipt.get().appliedAt());
        trades.completeExecutionRoute(execution);
        if (!module.saveTradeExecution(completed)) return result(UNKNOWN, execution);
        trades.publishExecution(completed);
        return terminal(completed);
      }
    }
    if (execution.state() == State.REFUND_PENDING) {
      if (!paymentExists(execution)
          || module.transferReceipt(execution.operationId("delivery")).isPresent())
        return result(UNKNOWN, execution);
      if (transferMoney(execution, true) != Money.COMMITTED) return result(UNKNOWN, execution);
      var refunded = execution.transition(State.REFUNDED, 0, finished(execution));
      trades.releaseExecutionQuotas(execution);
      return module.saveTradeExecution(refunded) ? terminal(refunded) : result(UNKNOWN, execution);
    }
    return result(UNKNOWN, execution);
  }

  private Money transferMoney(TradeExecution execution, boolean refund) {
    try {
      if (!authorities(execution)) return Money.UNKNOWN;
      var transfers = (NationTransferService) treasury;
      var request = money(execution, refund);
      var receipt = transfers.transferReceipt(request.transactionId());
      if (receipt.isPresent())
        return authorities(execution) && moneyMatches(request, receipt.get())
            ? Money.COMMITTED
            : Money.UNKNOWN;
      var result = transfers.transfer(request);
      if (!authorities(execution)) return Money.UNKNOWN;
      receipt = transfers.transferReceipt(request.transactionId());
      if (!authorities(execution)) return Money.UNKNOWN;
      if (receipt.isPresent())
        return moneyMatches(request, receipt.get()) ? Money.COMMITTED : Money.UNKNOWN;
      return result != null
              && request.transactionId().equals(result.transactionId())
              && (result.status() == NationTransferService.TransferStatus.INSUFFICIENT_FUNDS
                  || result.status() == NationTransferService.TransferStatus.REJECTED)
          ? Money.REJECTED
          : Money.UNKNOWN;
    } catch (RuntimeException uncertain) {
      return Money.UNKNOWN;
    }
  }

  private boolean paymentExists(TradeExecution execution) {
    if (!authorities(execution)) return false;
    var request = money(execution, false);
    var receipt = ((NationTransferService) treasury).transferReceipt(request.transactionId());
    return authorities(execution) && receipt.filter(r -> moneyMatches(request, r)).isPresent();
  }

  static NationTransferService.TransferRequest money(TradeExecution value, boolean refund) {
    return new NationTransferService.TransferRequest(
        value.operationId(refund ? "refund" : "debit"),
        refund ? value.exporter() : value.importer(),
        refund ? value.importer() : value.exporter(),
        value.totalPrice(),
        NationTransferService.TransferCategory.OTHER,
        value.description() + (refund ? " refund" : " debit"));
  }

  static NationResourceTransactionService.TransferRequest delivery(TradeExecution value) {
    return new NationResourceTransactionService.TransferRequest(
        value.operationId("delivery"),
        value.exporter(),
        value.importer(),
        Map.of(value.resourceId(), value.amount()),
        NationResourceTransactionService.Category.OTHER,
        value.description());
  }

  static boolean deliveryMatches(
      TradeExecution value, NationResourceTransactionService.TransferReceipt receipt) {
    return value.resourceDomain().equals(receipt.authorityDomainId())
        && receipt.matches(delivery(value));
  }

  private static boolean moneyMatches(
      NationTransferService.TransferRequest request,
      NationTransferService.TransferReceipt receipt) {
    return request.transactionId().equals(receipt.transactionId())
        && request.payerId().equals(receipt.payerId())
        && request.receiverId().equals(receipt.receiverId())
        && request.amount().compareTo(receipt.amount()) == 0
        && request.category() == receipt.category()
        && request.description().equals(receipt.description());
  }

  private TradeExecution approval(TradeExecution execution, UUID actor) {
    if (actor == null) return execution;
    if (module.mayTrade(execution.exporter(), actor))
      return execution.approve(execution.exporter(), actor);
    return execution.approve(execution.importer(), actor);
  }

  private boolean authorized(TradeExecution execution, UUID actor) {
    return module.mayTrade(execution.exporter(), actor)
        || module.mayTrade(execution.importer(), actor);
  }

  private boolean authorized(TradeAgreement agreement, UUID actor) {
    return module.mayTrade(agreement.exporterNationId(), actor)
        || module.mayTrade(agreement.importerNationId(), actor);
  }

  private boolean validIntent(TradeExecution execution, TradeAgreement agreement) {
    return agreement != null
        && valid(agreement, now())
        && now().isBefore(execution.expiresAt())
        && execution.exporter().equals(agreement.exporterNationId())
        && execution.importer().equals(agreement.importerNationId())
        && execution.resourceId().equals(agreement.resourceId())
        && execution.amount() == agreement.amount()
        && Double.compare(execution.pricePerUnit(), agreement.pricePerUnit()) == 0
        && (execution.system()
            || (execution.exporterApproval() == null
                    || module.mayTrade(execution.exporter(), execution.exporterApproval()))
                && (execution.importerApproval() == null
                    || module.mayTrade(execution.importer(), execution.importerApproval())));
  }

  private boolean valid(TradeAgreement agreement, Instant now) {
    return !now.isBefore(Instant.ofEpochMilli(agreement.startTime().toEpochMilli()))
        && now.isBefore(agreement.expiryTime())
        && agreement.status() == TradeAgreement.TradeAgreementStatus.ACTIVE
        && !trades.isEmbargoed(
            agreement.exporterNationId(), agreement.importerNationId(), agreement.resourceId())
        && !trades.isEmbargoed(
            agreement.importerNationId(), agreement.exporterNationId(), agreement.resourceId());
  }

  private boolean authorities(TradeExecution execution) {
    return module.nativeTradeStorageAvailable(trades)
        && treasury instanceof NationTransferService
        && execution.resourceDomain().equals(module.authorityDomainId())
        && execution.treasuryDomain().equals(treasury.authorityDomainId());
  }

  private static boolean domain(String value) {
    try {
      return value != null && UUID.fromString(value).toString().equals(value);
    } catch (IllegalArgumentException invalid) {
      return false;
    }
  }

  private Instant now() {
    return Instant.ofEpochMilli(clock.millis());
  }

  private Instant finished(TradeExecution execution) {
    Instant time = now();
    return time.isBefore(execution.createdAt()) ? execution.createdAt() : time;
  }

  private static ExecutionResult result(
      ResourceTradeService.ExecutionStatus status, TradeExecution value) {
    return new ExecutionResult(status, value);
  }

  private static ExecutionResult terminal(TradeExecution execution) {
    return result(
        switch (execution.state()) {
          case COMPLETED -> COMPLETED;
          case REFUNDED -> REFUNDED;
          case REJECTED -> REJECTED;
          default -> throw new IllegalStateException();
        },
        execution);
  }

  private enum Money {
    COMMITTED,
    REJECTED,
    UNKNOWN
  }
}
