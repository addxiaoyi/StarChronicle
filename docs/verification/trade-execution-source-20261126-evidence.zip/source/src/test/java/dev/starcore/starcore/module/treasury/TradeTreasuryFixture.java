package dev.starcore.starcore.module.treasury;

import java.nio.file.Path;

/** Shared real file/SQLite/H2 treasury fixture for cross-module recovery tests. */
public final class TradeTreasuryFixture {
  private final TreasuryCommitRecoveryTest.Fixture fixture;
  private TreasuryModule module;

  public TradeTreasuryFixture(String engine, Path directory) throws Exception {
    java.nio.file.Files.createDirectories(directory);
    var helper = new TreasuryCommitRecoveryTest();
    helper.directory = directory;
    fixture = helper.fixture(engine);
    restart();
  }

  public TreasuryModule module() {
    return module;
  }

  public void fail(boolean before, boolean unreadable) {
    fixture.fault().arm(before, unreadable);
  }

  public void restart() throws Exception {
    fixture.fault().unreadable = false;
    module = TreasuryCommitRecoveryTest.loaded(fixture.storage());
  }
}
