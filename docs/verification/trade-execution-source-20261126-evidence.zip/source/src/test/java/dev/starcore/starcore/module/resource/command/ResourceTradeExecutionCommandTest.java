package dev.starcore.starcore.module.resource.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.*;
import dev.starcore.starcore.module.resource.*;
import dev.starcore.starcore.module.resource.model.TradeAgreement;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.*;

class ResourceTradeExecutionCommandTest {
  final ResourceTradeService trades = mock(ResourceTradeService.class);
  final NationService nations = mock(NationService.class);
  final Player player = mock(Player.class);
  final UUID actor = UUID.randomUUID();
  final Nation nation = new Nation(NationId.random(), "Nation", actor, "Founder");
  final NationId other = NationId.random();
  final UUID agreementId = UUID.randomUUID();
  final ResourceCommand command =
      new ResourceCommand(
          mock(ResourceService.class),
          mock(ResourcePriceService.class),
          trades,
          mock(ResourceReserveService.class),
          mock(ProcessingService.class),
          nations,
          mock(OnlinePlayerDirectory.class));

  @BeforeEach
  void setup() {
    when(player.getUniqueId()).thenReturn(actor);
    when(player.hasPermission("starcore.resource")).thenReturn(true);
    when(player.hasPermission("starcore.resource.admin")).thenReturn(true);
    when(nations.nationOf(actor)).thenReturn(Optional.of(nation));
    var agreement =
        new TradeAgreement(
            agreementId,
            nation.id(),
            other,
            "industrial",
            2,
            2,
            Instant.EPOCH,
            Instant.ofEpochMilli(Long.MAX_VALUE));
    when(trades.getTradeAgreements(nation.id())).thenReturn(List.of(agreement));
    when(trades.tradeExecution("stable")).thenReturn(Optional.of(execution(nation.id())));
    when(trades.executeTradeAgreement(any(ResourceTradeService.ExecutionRequest.class)))
        .thenReturn(
            new ResourceTradeService.ExecutionResult(
                ResourceTradeService.ExecutionStatus.AWAITING_APPROVAL, null));
    when(trades.retryTradeExecution(anyString(), any()))
        .thenReturn(
            new ResourceTradeService.ExecutionResult(
                ResourceTradeService.ExecutionStatus.UNKNOWN, null));
  }

  void run(String... args) {
    command.onCommand(player, mock(Command.class), "resource", args);
  }

  TradeExecution execution(NationId exporter) {
    return new TradeExecution(
        "stable",
        agreementId,
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        exporter,
        other,
        "industrial",
        2,
        2,
        new BigDecimal("4.00"),
        Instant.EPOCH,
        Instant.ofEpochMilli(Long.MAX_VALUE),
        actor,
        null,
        false,
        TradeExecution.State.AWAITING_APPROVAL,
        List.of(),
        null,
        0,
        null);
  }

  @Test
  void executeAndApproveKeepActorAndStableIdWhileRetryCannotApprove() {
    run("trade", "agreements", "execute", agreementId.toString(), "stable");
    run("trade", "executions", "approve", "stable");
    run("trade", "executions", "retry", "stable");
    verify(trades, times(2))
        .executeTradeAgreement(
            new ResourceTradeService.ExecutionRequest("stable", agreementId, actor));
    verify(trades).retryTradeExecution("stable", actor);
    verify(player).sendMessage(contains("保留原编号 stable"));
  }

  @Test
  void administratorCannotOverrideFounderCheck() {
    nation.setFounderId(UUID.randomUUID());
    run("trade", "agreements", "execute", agreementId.toString(), "stable");
    run("trade", "executions", "approve", "stable");
    run("trade", "executions", "retry", "stable");
    verify(trades, never()).executeTradeAgreement(any(ResourceTradeService.ExecutionRequest.class));
    verify(trades, never()).retryTradeExecution(anyString(), any());
  }

  @Test
  void anotherNationsExecutionCannotBeInspectedApprovedOrRetried() {
    when(trades.tradeExecution("stable")).thenReturn(Optional.of(execution(NationId.random())));
    run("trade", "executions", "inspect", "stable");
    run("trade", "executions", "approve", "stable");
    run("trade", "executions", "retry", "stable");
    verify(trades, never()).executeTradeAgreement(any(ResourceTradeService.ExecutionRequest.class));
    verify(trades, never()).retryTradeExecution(anyString(), any());
    verify(player, never()).sendMessage(contains("总价"));
  }

  @Test
  void incompleteOrMalformedArgumentsCauseNoExecution() {
    run("trade");
    run("trade", "executions");
    run("trade", "executions", "approve");
    run("trade", "agreements", "execute", agreementId.toString());
    run("trade", "agreements", "execute", agreementId.toString(), "bad/key");
    run("trade", "executions", "list", "0");
    verify(trades, never()).executeTradeAgreement(any(ResourceTradeService.ExecutionRequest.class));
    verify(trades, never()).retryTradeExecution(anyString(), any());
    verify(trades, never()).tradeExecutions(any(), anyInt(), anyInt());
  }

  @Test
  void lookupFailureDoesNotClaimAbsenceAndCompletionUsesRealNestedCommands() {
    when(trades.tradeExecution("stable")).thenThrow(new IllegalStateException("unavailable"));
    run("trade", "executions", "inspect", "stable");
    verify(player, never()).sendMessage(contains("未找到"));
    assertTrue(
        command
            .onTabComplete(player, mock(Command.class), "resource", new String[] {"trade", ""})
            .contains("executions"));
    assertTrue(
        command
            .onTabComplete(
                player, mock(Command.class), "resource", new String[] {"trade", "agreements", ""})
            .contains("execute"));
    assertTrue(
        command
            .onTabComplete(
                player, mock(Command.class), "resource", new String[] {"trade", "executions", ""})
            .contains("retry"));
  }
}
