package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.logging.Logger;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class NativeTradeExecutionValidationTest {
  @TempDir Path directory;

  @AfterEach
  void closeStorage() {
    AbstractModuleStateStorage.shutdownNamespace("test");
    AbstractModuleStateStorage.shutdownNamespace("resource");
  }

  NativeTradeExecutionRecoveryTest.Fixture fixture() throws Exception {
    var helper = new NativeTradeExecutionRecoveryTest();
    helper.directory = directory;
    var f = helper.fixture("file");
    assertEquals(ResourceTradeService.ExecutionStatus.COMPLETED, f.execute("proof").status());
    return f;
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "id",
        "agreement",
        "resource-domain",
        "treasury-domain",
        "exporter",
        "importer",
        "resource",
        "amount",
        "price",
        "total",
        "created",
        "expires",
        "export-approval",
        "import-approval",
        "system",
        "state",
        "route",
        "sequence",
        "finished",
        "reservations",
        "extra-field"
      })
  void canonicalHashCannotHideInvalidFields(String field) throws Exception {
    var f = fixture();
    var state = f.storage.load();
    state.setProperty(
        TradeExecutionStore.PREFIX + "row." + TradeExecutionStore.hash("proof") + "." + field,
        "invalid");
    rehash(state);
    f.storage.delegate.save(state);
    f.attach(f.money.module());
    assertEquals("", f.module.authorityDomainId());
    assertThrows(IllegalStateException.class, () -> f.service.tradeExecution("proof"));
    assertFalse(f.module.grant(NativeTradeExecutionRecoveryTest.EXPORTER, "industrial", 1));
    assertEquals(state, f.storage.load());
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "quota-usage",
        "quota-owner",
        "quota-window",
        "route-owner",
        "receipt",
        "count",
        "version",
        "missing-field"
      })
  void brokenRelationsOrImpossibleCountsRemainQuarantined(String damage) throws Exception {
    var f = fixture();
    var state = f.storage.load();
    String row = TradeExecutionStore.PREFIX + "row." + TradeExecutionStore.hash("proof") + ".";
    switch (damage) {
      case "quota-usage" -> state.setProperty("quota.0.current", "0");
      case "quota-owner" -> state.setProperty("quota.0.nation", UUID.randomUUID().toString());
      case "quota-window" -> state.setProperty(row + "reservations", f.exportQuota + ":100:50");
      case "route-owner" -> state.setProperty("route.0.origin", UUID.randomUUID().toString());
      case "receipt" -> state.setProperty(row + "sequence", "999");
      case "count" ->
          state.setProperty(
              TradeExecutionStore.PREFIX + "count", Integer.toString(Integer.MAX_VALUE));
      case "version" -> state.setProperty(TradeExecutionStore.PREFIX + "version", "2");
      case "missing-field" -> state.remove(row + "price");
      default -> throw new AssertionError();
    }
    rehash(state);
    f.storage.delegate.save(state);
    assertTimeout(Duration.ofSeconds(2), () -> f.attach(f.money.module()));
    assertEquals("", f.module.authorityDomainId());
    assertEquals(state, f.storage.load());
  }

  @Test
  void inheritedPropertiesRemainReadableWithoutMutatingThem() throws Exception {
    var f = fixture();
    var state = f.storage.load();
    var inherited = new Properties(state);
    assertEquals(
        Map.of("proof", f.service.tradeExecution("proof").orElseThrow()),
        TradeExecutionStore.read(inherited, f.storage));
    assertTrue(inherited.isEmpty());
  }

  @ParameterizedTest
  @CsvSource({"sqlite,true", "sqlite,false", "h2,true", "h2,false"})
  void firstSqlImportValidatesExecutionAndPreservesValidReceipt(String engine, boolean invalid)
      throws Exception {
    var f = fixture();
    var state = f.storage.load();
    if (invalid) {
      state.setProperty(
          TradeExecutionStore.PREFIX + "row." + TradeExecutionStore.hash("proof") + ".sequence",
          "999");
      rehash(state);
    }
    javax.sql.DataSource db;
    if (engine.equals("sqlite")) {
      var source = new org.sqlite.SQLiteDataSource();
      source.setUrl("jdbc:sqlite:" + directory.resolve("import.db"));
      db = source;
    } else {
      var source = new org.h2.jdbcx.JdbcDataSource();
      source.setURL("jdbc:h2:mem:trade-import-" + UUID.randomUUID() + ";DB_CLOSE_DELAY=-1");
      db = source;
    }
    var storage = new SqlResourceStateStorage(db, state, Logger.getAnonymousLogger());
    if (invalid) {
      assertThrows(IllegalStateException.class, storage::load);
      try (var connection = db.getConnection();
          var statement = connection.createStatement();
          var result = statement.executeQuery("SELECT COUNT(*) FROM starcore_resource_state")) {
        assertTrue(result.next());
        assertEquals(0, result.getInt(1));
      }
    } else {
      var loaded = storage.load();
      assertEquals(
          f.service.tradeExecution("proof").orElseThrow(),
          TradeExecutionStore.read(loaded, storage).get("proof"));
    }
  }

  static void rehash(Properties state) throws Exception {
    var method = TradeExecutionStore.class.getDeclaredMethod("fingerprint", Properties.class);
    method.setAccessible(true);
    state.setProperty(TradeExecutionStore.PREFIX + "head", (String) method.invoke(null, state));
  }
}
