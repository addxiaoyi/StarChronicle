package dev.starcore.starcore.module.nation;

import dev.starcore.starcore.core.persistence.AtomicFilePersistence;
import dev.starcore.starcore.module.nation.model.NationId;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Transactional, append-only designated capital authority. The old journal becomes a durable
 * migration fence, so an older plugin cannot silently resume writing a different capital state. The
 * exact original bytes remain in .legacy; only complete legacy lines are imported. Keep the fence,
 * .legacy and .sqlite together when backing up or restoring this authority.
 */
final class NationCapitalDesignationStore {
  private static final String FORMAT = "STARCORE_CAPITAL_SQLITE_V1";
  private static final Object[] MIGRATION_LOCKS = new Object[32];

  static {
    for (int i = 0; i < MIGRATION_LOCKS.length; i++) MIGRATION_LOCKS[i] = new Object();
  }

  private final Path journal;
  private final Path database;
  private final Path legacy;
  private UUID domain;
  private String fence;
  private long observedSequence;

  NationCapitalDesignationStore(Path journal) throws IOException {
    this.journal = Objects.requireNonNull(journal, "journal").toAbsolutePath().normalize();
    this.database = this.journal.resolveSibling(this.journal.getFileName() + ".sqlite");
    this.legacy = this.journal.resolveSibling(this.journal.getFileName() + ".legacy");
    Files.createDirectories(this.journal.getParent());
    synchronized (MIGRATION_LOCKS[Math.floorMod(this.journal.hashCode(), MIGRATION_LOCKS.length)]) {
      // Serialize bootstrap across processes as well as stores in this JVM.
      try (var channel =
              java.nio.channels.FileChannel.open(
                  this.journal.resolveSibling(this.journal.getFileName() + ".lock"),
                  java.nio.file.StandardOpenOption.CREATE,
                  java.nio.file.StandardOpenOption.WRITE);
          var ignored = channel.lock()) {
        initialize();
      }
    }
  }

  synchronized UUID authorityDomainId() {
    return transaction(
        false,
        connection -> {
          head(connection);
          return domain;
        });
  }

  synchronized Optional<NationService.CapitalDesignation> current(NationId nationId) {
    Objects.requireNonNull(nationId, "nationId");
    return transaction(
        false,
        connection -> {
          head(connection);
          return Optional.ofNullable(current(connection, nationId));
        });
  }

  synchronized List<NationService.CapitalDesignation> after(long sequence, int limit) {
<<<<<<< HEAD
    validatePage(sequence, limit);
    if (sequence > latestSequence)
      throw new IllegalStateException("Capital cursor is ahead of restored native journal");
    if (sequence == latestSequence) return List.of();
    if (pageOffsets.isEmpty()) throw corrupt("Missing capital page offsets");
    long firstSequence = Math.addExact(sequence, 1L);
    Map.Entry<Long, Long> pageStart = pageOffsets.floorEntry(firstSequence);
    if (pageStart == null) throw corrupt("Missing capital page offset");
    List<NationService.CapitalDesignation> page = new ArrayList<>(limit);
    long expected = pageStart.getKey();
    try (FileChannel channel = FileChannel.open(journal, StandardOpenOption.READ)) {
      channel.position(pageStart.getValue());
      try (BufferedReader reader =
          new BufferedReader(Channels.newReader(channel, StandardCharsets.US_ASCII))) {
        String line;
        while ((line = reader.readLine()) != null) {
          NationService.CapitalDesignation entry = decode(line);
          if (entry.sequence() != expected++) throw corrupt("Non-contiguous capital sequence");
          if (entry.sequence() >= firstSequence) {
            page.add(entry);
            if (page.size() == limit) break;
          }
        }
      }
    } catch (IOException error) {
      throw new IllegalStateException("Unable to read capital designation history", error);
    }
    if (page.size() != Math.min((long) limit, latestSequence - sequence))
      throw corrupt("Capital history is incomplete");
    return List.copyOf(page);
=======
    if (sequence < 0L || limit < 1 || limit > 1000)
      throw new IllegalArgumentException("sequence must be non-negative and limit must be 1..1000");
    return transaction(
        false,
        connection -> {
          long latest = head(connection);
          if (sequence > latest)
            throw new IllegalStateException(
                "Capital history cursor is ahead of the authority; restore matching backups");
          List<NationService.CapitalDesignation> page = new ArrayList<>(limit);
          try (var query =
              connection.prepareStatement(
                  "SELECT * FROM designations WHERE sequence>? ORDER BY sequence LIMIT ?")) {
            query.setLong(1, sequence);
            query.setInt(2, limit);
            try (var rows = query.executeQuery()) {
              long expected = sequence;
              while (rows.next()) {
                var entry = decode(rows);
                if (entry.sequence() != ++expected) throw corrupt("Non-contiguous capital page");
                page.add(entry);
              }
            }
          }
          if (page.size() != Math.min((long) limit, latest - sequence))
            throw corrupt("Capital page is incomplete");
          return List.copyOf(page);
        });
  }

  synchronized List<NationService.CapitalChangeReceipt> changesAfter(long sequence, int limit) {
    return after(sequence, limit).stream()
        .map(entry -> new NationService.CapitalChangeReceipt(domain, entry))
        .toList();
>>>>>>> origin/codex/national-epic-linux-acceptance-20261125
  }

  synchronized NationService.CapitalDesignation append(
      UUID operationId,
      NationId nationId,
      UUID previousCityId,
      UUID cityId,
      UUID actorId,
      Instant committedAt) {
    Objects.requireNonNull(operationId, "operationId");
    Objects.requireNonNull(nationId, "nationId");
    Objects.requireNonNull(cityId, "cityId");
    Objects.requireNonNull(actorId, "actorId");
    Objects.requireNonNull(committedAt, "committedAt");
    return transaction(
        true,
        connection -> {
          long latest = head(connection);
          try (var query =
              connection.prepareStatement("SELECT * FROM designations WHERE operation=?")) {
            query.setString(1, operationId.toString());
            try (var rows = query.executeQuery()) {
              if (rows.next()) {
                var previous = decode(rows);
                if (!previous.nationId().equals(nationId)
                    || !previous.cityId().equals(cityId)
                    || !previous.actorId().equals(actorId))
                  throw new IllegalStateException(
                      "Capital operation ID is already bound to another request");
                return previous;
              }
            }
          }
          var previous = current(connection, nationId);
          UUID actualPreviousCity = previous == null ? null : previous.cityId();
          if (!Objects.equals(previousCityId, actualPreviousCity))
            throw new IllegalStateException(
                "Capital designation changed before this operation was committed");
          if (cityId.equals(actualPreviousCity))
            throw new IllegalArgumentException("City is already the designated capital");
          var entry =
              new NationService.CapitalDesignation(
                  Math.addExact(latest, 1),
                  operationId,
                  nationId,
                  actualPreviousCity,
                  cityId,
                  actorId,
                  committedAt);
          insert(connection, entry);
          try (var update =
              connection.prepareStatement("UPDATE authority SET sequence=? WHERE id=1")) {
            update.setLong(1, entry.sequence());
            update.executeUpdate();
          }
          return entry;
        });
  }

  private void initialize() throws IOException {
    boolean journalExists = Files.exists(journal, LinkOption.NOFOLLOW_LINKS);
    String marker = journalExists ? readMarker(journal) : null;
    if (marker == null) {
      if (Files.exists(database, LinkOption.NOFOLLOW_LINKS))
        throw corrupt("Migration fence is missing; restore the matching files");
      if (!journalExists && Files.exists(legacy, LinkOption.NOFOLLOW_LINKS))
        throw corrupt("Legacy archive exists without its migration fence");
      // Validate the complete prefix before modifying any legacy data. Preserve the partial tail
      // as evidence, but it was never committed and must not become a designation.
      byte[] bytes = journalExists ? Files.readAllBytes(journal) : new byte[0];
      validateLegacy(bytes, null);
      if (Files.exists(legacy, LinkOption.NOFOLLOW_LINKS)) {
        if (!java.util.Arrays.equals(bytes, Files.readAllBytes(legacy)))
          throw corrupt("Legacy migration archive conflicts with the journal");
      } else AtomicFilePersistence.replace(legacy, temp -> Files.write(temp, bytes));
      marker = FORMAT + "|MIGRATING|" + UUID.randomUUID() + "|" + digest(bytes) + "\n";
      writeFence(marker);
    }
    String[] parts = marker.strip().split("\\|", -1);
    if (parts.length != 4
        || !parts[0].equals(FORMAT)
        || !List.of("MIGRATING", "READY").contains(parts[1])
        || !parts[3].matches("[0-9a-f]{64}")) throw corrupt("Invalid migration fence");
    domain = canonicalUuid(parts[2]);
    if (parts[1].equals("MIGRATING")) {
      byte[] bytes = Files.readAllBytes(legacy);
      if (!digest(bytes).equals(parts[3])) throw corrupt("Legacy migration archive changed");
      try (Connection connection = open(true);
          var statement = connection.createStatement()) {
        statement.execute("BEGIN IMMEDIATE");
        try {
          statement.execute(
              "CREATE TABLE IF NOT EXISTS authority(id INTEGER PRIMARY KEY CHECK(id=1),version"
                  + " INTEGER NOT NULL CHECK(version=1),domain TEXT NOT NULL,sequence INTEGER NOT"
                  + " NULL CHECK(sequence>=0),legacy_sha256 TEXT NOT NULL)");
          statement.execute(
              "CREATE TABLE IF NOT EXISTS designations(sequence INTEGER PRIMARY KEY"
                  + " CHECK(sequence>0),operation TEXT NOT NULL UNIQUE,nation TEXT NOT"
                  + " NULL,previous_city TEXT,city TEXT NOT NULL,actor TEXT NOT NULL,committed_at"
                  + " TEXT NOT NULL,CHECK(previous_city IS NULL OR previous_city<>city))");
          statement.execute(
              "CREATE INDEX IF NOT EXISTS designation_current ON designations(nation,sequence"
                  + " DESC)");
          boolean initialized;
          try (var rows =
              statement.executeQuery("SELECT domain,legacy_sha256 FROM authority WHERE id=1")) {
            initialized = rows.next();
            if (initialized
                && (!domain.toString().equals(rows.getString(1))
                    || !parts[3].equals(rows.getString(2))))
              throw corrupt("Migration database belongs to a different authority");
          }
          if (!initialized) {
            long latest = validateLegacy(bytes, connection);
            try (var insert =
                connection.prepareStatement("INSERT INTO authority VALUES(1,1,?,?,?)")) {
              insert.setString(1, domain.toString());
              insert.setLong(2, latest);
              insert.setString(3, parts[3]);
              insert.executeUpdate();
            }
          }
          validateAll(connection);
          statement.execute("COMMIT");
        } catch (IOException | SQLException | RuntimeException failure) {
          try {
            statement.execute("ROLLBACK");
          } catch (SQLException rollback) {
            failure.addSuppressed(rollback);
          }
          throw failure;
        }
      } catch (SQLException failure) {
        throw new IOException("Cannot migrate capital history", failure);
      }
      marker = FORMAT + "|READY|" + domain + "|" + parts[3] + "\n";
      writeFence(marker);
    }
    fence = marker;
    // Opening an established authority must never create a missing database or silently repair
    // a broken committed sequence from an older backup.
    transaction(
        false,
        connection -> {
          validateAll(connection);
          return null;
        });
  }

  private Connection open(boolean create) throws SQLException, IOException {
    if (!create && !Files.isRegularFile(database, LinkOption.NOFOLLOW_LINKS))
      throw corrupt("Capital database is missing; restore the matching files");
    Connection connection =
        DriverManager.getConnection(
            create
                ? "jdbc:sqlite:" + database
                : "jdbc:sqlite:" + database.toUri().toASCIIString() + "?mode=rw");
    try (var statement = connection.createStatement()) {
      statement.execute("PRAGMA busy_timeout=5000");
      statement.execute("PRAGMA synchronous=FULL");
      if (create) statement.execute("PRAGMA journal_mode=DELETE");
    } catch (SQLException failure) {
      connection.close();
      throw failure;
    }
    return connection;
  }

  private <T> T transaction(boolean write, SqlWork<T> work) {
    try (Connection connection = open(false);
        var statement = connection.createStatement()) {
      statement.execute(write ? "BEGIN IMMEDIATE" : "BEGIN");
      try {
        if (!Objects.equals(fence, readMarker(journal)))
          throw corrupt("Capital authority fence changed");
        T result = work.run(connection);
        statement.execute("COMMIT");
        if (result instanceof NationService.CapitalDesignation entry)
          observedSequence = Math.max(observedSequence, entry.sequence());
        return result;
      } catch (IOException | SQLException | RuntimeException failure) {
        try {
          statement.execute("ROLLBACK");
        } catch (SQLException rollback) {
          failure.addSuppressed(rollback);
        }
        throw failure;
      }
    } catch (IOException | SQLException failure) {
      throw new IllegalStateException("Unable to read or commit capital designation", failure);
    }
  }

  private long head(Connection connection) throws SQLException {
    try (var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT version,domain,sequence,(SELECT COALESCE(MAX(sequence),0) FROM"
                    + " designations),legacy_sha256 FROM authority WHERE id=1")) {
      if (!rows.next() || rows.getInt(1) != 1 || !domain.toString().equals(rows.getString(2)))
        throw corrupt("Missing or replaced capital authority");
      if (fence != null && !fence.strip().split("\\|", -1)[3].equals(rows.getString(5)))
        throw corrupt("Capital migration identity changed");
      long latest = rows.getLong(3);
      if (latest != rows.getLong(4) || latest < observedSequence)
        throw corrupt("Capital head was truncated or rolled back");
      observedSequence = latest;
      return latest;
    }
  }

  private void validateAll(Connection connection) throws SQLException {
    long latest = head(connection), expected = 0;
    Map<NationId, UUID> capitals = new HashMap<>();
    try (var statement = connection.createStatement();
        var rows = statement.executeQuery("SELECT * FROM designations ORDER BY sequence")) {
      while (rows.next()) {
        var entry = decode(rows);
        if (entry.sequence() != ++expected
            || !Objects.equals(capitals.get(entry.nationId()), entry.previousCityId()))
          throw corrupt("Capital history sequence or previous city is inconsistent");
        capitals.put(entry.nationId(), entry.cityId());
      }
    }
    if (expected != latest) throw corrupt("Capital history does not match the committed head");
  }

  private static NationService.CapitalDesignation current(Connection connection, NationId nationId)
      throws SQLException {
    try (var query =
        connection.prepareStatement(
            "SELECT * FROM designations WHERE nation=? ORDER BY sequence DESC LIMIT 1")) {
      query.setString(1, nationId.toString());
      try (var rows = query.executeQuery()) {
        return rows.next() ? decode(rows) : null;
      }
    }
  }

  private static void insert(Connection connection, NationService.CapitalDesignation entry)
      throws SQLException {
    try (var insert =
        connection.prepareStatement("INSERT INTO designations VALUES(?,?,?,?,?,?,?)")) {
      insert.setLong(1, entry.sequence());
      insert.setString(2, entry.operationId().toString());
      insert.setString(3, entry.nationId().toString());
      insert.setString(
          4, entry.previousCityId() == null ? null : entry.previousCityId().toString());
      insert.setString(5, entry.cityId().toString());
      insert.setString(6, entry.actorId().toString());
      insert.setString(7, entry.committedAt().toString());
      insert.executeUpdate();
    }
  }

  private static NationService.CapitalDesignation decode(ResultSet rows) throws SQLException {
    String previous = rows.getString("previous_city");
    return new NationService.CapitalDesignation(
        rows.getLong("sequence"),
        canonicalUuid(rows.getString("operation")),
        NationId.of(canonicalUuid(rows.getString("nation"))),
        previous == null ? null : canonicalUuid(previous),
        canonicalUuid(rows.getString("city")),
        canonicalUuid(rows.getString("actor")),
        Instant.parse(rows.getString("committed_at")));
  }

  private static long validateLegacy(byte[] bytes, Connection connection) throws IOException {
    Map<NationId, UUID> capitals = new HashMap<>();
    java.util.Set<UUID> operations = new java.util.HashSet<>();
    long sequence = 0;
    int start = 0;
    try {
      for (int i = 0; i < bytes.length; i++)
        if (bytes[i] == '\n') {
          String line = new String(bytes, start, i - start, StandardCharsets.US_ASCII);
          String[] fields = line.split("\\|", -1);
          if (fields.length != 7) throw corrupt("Invalid legacy capital record");
          var entry =
              new NationService.CapitalDesignation(
                  Long.parseLong(fields[0]),
                  canonicalUuid(fields[1]),
                  NationId.of(canonicalUuid(fields[2])),
                  fields[3].equals("-") ? null : canonicalUuid(fields[3]),
                  canonicalUuid(fields[4]),
                  canonicalUuid(fields[5]),
                  Instant.ofEpochMilli(Long.parseLong(fields[6])));
          if (entry.sequence() != ++sequence
              || !operations.add(entry.operationId())
              || !Objects.equals(capitals.get(entry.nationId()), entry.previousCityId())
              || entry.cityId().equals(entry.previousCityId()))
            throw corrupt("Inconsistent legacy capital record");
          capitals.put(entry.nationId(), entry.cityId());
          if (connection != null) insert(connection, entry);
          start = i + 1;
        }
    } catch (SQLException failure) {
      throw new IOException("Cannot import legacy capital history", failure);
    }
    return sequence;
  }

  private static String readMarker(Path path) throws IOException {
    try (var input = Files.newInputStream(path)) {
      String prefix = new String(input.readNBytes(512), StandardCharsets.US_ASCII);
      if (!prefix.startsWith(FORMAT)) return null;
      if (!prefix.endsWith("\n") || input.read() != -1)
        throw corrupt("Invalid capital migration fence");
      return prefix;
    }
  }

  private void writeFence(String value) throws IOException {
    AtomicFilePersistence.replace(
        journal, temp -> Files.writeString(temp, value, StandardCharsets.US_ASCII));
  }

  private static String digest(byte[] value) {
    try {
      return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value));
    } catch (NoSuchAlgorithmException impossible) {
      throw new AssertionError(impossible);
    }
  }

  private static UUID canonicalUuid(String value) {
    UUID parsed = UUID.fromString(value);
    if (!parsed.toString().equals(value)) throw corrupt("UUID is not canonical");
    return parsed;
  }

  private static IllegalStateException corrupt(String message) {
    return new IllegalStateException("Capital designation authority is corrupt: " + message);
  }

  @FunctionalInterface
  private interface SqlWork<T> {
    T run(Connection connection) throws SQLException, IOException;
  }
}
