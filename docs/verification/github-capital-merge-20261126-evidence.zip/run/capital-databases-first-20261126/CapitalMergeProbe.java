package io.github.addxiaoyi.starchronicle.integration;

import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.NationId;
import io.github.addxiaoyi.starchronicle.core.RuleEngine;
import io.github.addxiaoyi.starchronicle.history.CommittedHistoryJournal;
import io.github.addxiaoyi.starchronicle.persistence.SqliteStore;
import java.lang.reflect.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.function.Function;

/** Real JAR persistence/consumer contract over disposable copies; fixture nation domain only. */
public class CapitalMergeProbe {
    public static final class Source {
        final Object store;
        final UUID nationDomain;
        Source(Path journal,UUID nationDomain)throws Exception {
            var c=Class.forName("dev.starcore.starcore.module.nation.NationCapitalDesignationStore").getDeclaredConstructor(Path.class);
            c.setAccessible(true);store=c.newInstance(journal);this.nationDomain=nationDomain;
        }
        Object invoke(String name,Class<?>[] types,Object...args)throws Exception {
            var m=store.getClass().getDeclaredMethod(name,types);m.setAccessible(true);return m.invoke(store,args);
        }
        public UUID authorityDomainId(){return nationDomain;}
        public Optional<UUID> capitalHistoryAuthorityDomainId()throws Exception{return Optional.of((UUID)invoke("authorityDomainId",new Class<?>[0]));}
        @SuppressWarnings("unchecked")
        public List<NationService.CapitalDesignation> capitalDesignationsAfter(long after,int limit)throws Exception {
            return (List<NationService.CapitalDesignation>)invoke("after",new Class<?>[]{long.class,int.class},after,limit);
        }
        public List<?> capitalChangesAfter(long after,int limit)throws Exception{return (List<?>)invoke("changesAfter",new Class<?>[]{long.class,int.class},after,limit);}
        void append(long sequence)throws Exception {
            UUID a=new UUID(1,1),b=new UUID(1,2),next=sequence%2==1?a:b,previous=sequence==1?null:sequence%2==1?b:a;
            var result=(NationService.CapitalDesignation)invoke("append",new Class<?>[]{UUID.class,NationId.class,UUID.class,UUID.class,UUID.class,Instant.class},
                    new UUID(2,sequence),NationId.of(new UUID(3,1)),previous,next,new UUID(4,sequence>130?2:1),Instant.parse("2026-11-26T00:00:00.123456789Z").plusSeconds(sequence));
            if(result.sequence()!=sequence)throw new AssertionError("Sequence drift");
        }
    }
    public static void main(String[] args)throws Exception {
        Path folder=Path.of(args[0]);Files.createDirectories(folder);String mode=args[1],step=args[2];
        if(step.equals("refuse")) {
            try {new Source(folder.resolve("capital-designations.log"),new UUID(0,42));throw new AssertionError("Old writer accepted the SQLite fence");}
            catch(InvocationTargetException failure){if(!(failure.getCause() instanceof IllegalStateException))throw failure;System.out.println("OLD_WRITER_REFUSED "+failure.getCause().getMessage());return;}
        }
        var source=new Source(folder.resolve("capital-designations.log"),new UUID(0,42));
        if(step.equals("seed"))for(int n=1;n<=260;n++)source.append(n);
        if(step.equals("append"))source.append(261);
        try(var store=new SqliteStore(folder.resolve("chronicle.db"))) {
            var engine=new RuleEngine(store,List.of(),Clock.systemUTC());var journal=new CommittedHistoryJournal(store);
            int accepted=0;
            if(step.equals("seed")) {
                var collector=new CommittedSourceCollector(key->source);
                for(int n=0;n<10;n++) {
                    int count=engine.acceptCommittedSource(collector.collect(CommittedSourceCollector.Source.CAPITAL,engine.committedSourceCursor("starcore.capital")).orElseThrow(),List.of());
                    accepted+=count;if(count==0)break;if(n==9)throw new AssertionError("Unbounded legacy read");
                }
            } else {
                var type=Class.forName("io.github.addxiaoyi.starchronicle.integration.CapitalHistoryCoordinator");
                var constructor=type.getDeclaredConstructor(RuleEngine.class,Function.class,CommittedHistoryJournal.class);constructor.setAccessible(true);
                var coordinator=constructor.newInstance(engine,(Function<String,Object>)(key->source),journal);
                for(int n=0;n<10;n++) {int count=(int)type.getMethod("poll",Collection.class).invoke(coordinator,List.of());accepted+=count;if(count==0)break;if(n==9)throw new AssertionError("Unbounded journal read");}
            }
            var old=engine.committedSourceCursor("starcore.capital");var current=journal.cursor("starcore.capitals");
            if(old.isPresent()==current.isPresent()||!mode.equals(old.isPresent()?"legacy":"journal"))throw new AssertionError("Wrong capital ledger");
            Map<String,Object> result=new TreeMap<>();
            result.put("mode",mode);result.put("accepted",accepted);result.put("cursor",old.isPresent()?old.get().sequence():current.orElseThrow().sequence());
            result.put("domain",old.isPresent()?old.get().domain():current.orElseThrow().authorityDomain().toString());
            result.put("pending",journal.pending("starcore.capitals",128).size());
            result.put("events",store.transaction(c->{try(var s=c.createStatement();var r=s.executeQuery("SELECT count(*) FROM events")){r.next();return r.getInt(1);}}));
            List<NationService.CapitalDesignation> records=new ArrayList<>();long after=0;
            for(int n=0;n<10;n++){var page=source.capitalDesignationsAfter(after,100);records.addAll(page);if(page.size()<100)break;after=page.getLast().sequence();}
            result.put("records",records);System.out.println(SqliteStore.json(result));
        }
        if(step.equals("seed"))Files.writeString(folder.resolve("capital-designations.log"),"uncommitted-tail",StandardOpenOption.APPEND);
    }
}
