# Essentials GUI ownership and snapshots

The runtime listener uses the scheduler-aware constructor. Its public open methods
are called on the original viewer's owner. Click events cancel immediately; actions
are scheduled after the event and recheck the player session and exact inventory.
Home, warp and balance-ranking menus retain the displayed page and slot snapshot,
so changes to a service cannot redirect an already displayed slot to another name
or account. Requested pages are clamped before index arithmetic.

Ranking data comes from the internal economy asynchronously, or an external Paper
provider on the global executor. Unverified external Folia providers are refused.
At most 28 page names and the viewer's preceding rank are resolved. Online names
are read on each original player's owner; offline profiles are read asynchronously,
including a switch to the owner if the lookup returns an online Player. Failed
name reads use UUID text and the default head. Known names supply both UUID and
name to a detached head profile. Inventory construction and feedback return to
the original viewer's owner. This does not promise client skin-loading behavior.

Only the newest pending request may replace the inventory from which it started.
Closing that inventory, switching menus, quitting, module shutdown, retirement or
reconnecting invalidates the request. Request identities distinguish repeated
opens of the same inventory. Runtime GUI state is one session record; stale quit
and close events remove only the old player's state. Pending home-save callbacks
also retain their original player and request identity.

Book input stores an opaque token containing an independent identity, even when
two consecutive inputs contain equal inventory items. A delayed cleanup restores
only its captured token and never consumes another module's newer input. Module
shutdown clears detached state under a short lock and schedules inventory/book
cleanup after cancelling old business callbacks. Cleanup checks the original
player and exact inventory or book token; it still runs after the module lifetime
ends when the plugin and original player remain available. A view opened during
shutdown is closed before registration. No Bukkit inventory operations run under
the state lock.

Legacy synchronous constructors and public signatures remain available. Their
callers must already own every accessed player and permit synchronous offline
profile I/O. They are not the cross-region runtime entry point.

The source checkpoint passes 607 related tests, including 56 new tests and the
existing two book-input tests newly included in this selection. Tests simulate
distinct executors, retirement, reconnects and reentrant shutdown; the book helper
tests exercise its actual session map with mocked inventories. This is not the
whole StarCore suite, live Paper/Folia acceptance, a full-plugin hot-unload
guarantee, or recovery of inventory restoration failures. Existing asynchronous
home persistence and external-economy result contracts remain in force.
