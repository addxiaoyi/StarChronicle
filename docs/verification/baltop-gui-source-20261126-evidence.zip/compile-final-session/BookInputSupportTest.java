package dev.starcore.starcore.foundation.gui;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class BookInputSupportTest {
  @Test
  void oldCleanupTokenCannotRestoreANewerInputWithEqualInventoryContents() {
    Player player = mock(Player.class);
    PlayerInventory inventory = mock(PlayerInventory.class);
    when(player.getUniqueId()).thenReturn(UUID.randomUUID());
    when(player.getInventory()).thenReturn(inventory);
    try (var ignored = mockConstruction(ItemStack.class)) {
      BookInputSupport.prepare(player, "First", "");
      Object old = BookInputSupport.sessionToken(player);
      BookInputSupport.prepare(player, "Second", "");
      Object current = BookInputSupport.sessionToken(player);
      BookInputSupport.restoreSession(player, old);
      assertThat(BookInputSupport.sessionToken(player)).isSameAs(current);
      BookInputSupport.restoreSession(player, current);
      assertThat(BookInputSupport.sessionToken(player)).isNull();
    }
  }

  @Test
  void retiredPlayerCannotRestoreTheReplacementSessionsBook() {
    UUID id = UUID.randomUUID();
    Player old = mock(Player.class), current = mock(Player.class);
    PlayerInventory oldInventory = mock(PlayerInventory.class),
        currentInventory = mock(PlayerInventory.class);
    when(old.getUniqueId()).thenReturn(id);
    when(current.getUniqueId()).thenReturn(id);
    when(old.getInventory()).thenReturn(oldInventory);
    when(current.getInventory()).thenReturn(currentInventory);
    try (var ignored = mockConstruction(ItemStack.class)) {
      BookInputSupport.prepare(old, "Old", "");
      Object oldToken = BookInputSupport.sessionToken(old);
      BookInputSupport.prepare(current, "Current", "");
      Object currentToken = BookInputSupport.sessionToken(current);
      BookInputSupport.clear(old);
      BookInputSupport.restoreSession(current, oldToken);
      assertThat(BookInputSupport.sessionToken(current)).isSameAs(currentToken);
      BookInputSupport.clear(current);
      verify(oldInventory, org.mockito.Mockito.never()).setItem(any(Integer.class), any());
      verify(currentInventory).setItem(0, null);
    }
  }

  @Test
  void clearRestoresInventoryAfterInterruptedInput() {
    Player player = mock(Player.class);
    PlayerInventory inventory = mock(PlayerInventory.class);
    UUID playerId = UUID.randomUUID();
    ItemStack selectedItem = mock(ItemStack.class);
    ItemStack inputSlotItem = mock(ItemStack.class);
    when(selectedItem.clone()).thenReturn(selectedItem);
    when(inputSlotItem.clone()).thenReturn(inputSlotItem);
    when(player.getUniqueId()).thenReturn(playerId);
    when(player.getInventory()).thenReturn(inventory);
    when(inventory.getHeldItemSlot()).thenReturn(2);
    when(inventory.getItem(2)).thenReturn(selectedItem);
    when(inventory.getItem(0)).thenReturn(inputSlotItem);

    try (var ignored = mockConstruction(ItemStack.class)) {
      BookInputSupport.prepare(player, "Test input", "initial");
      BookInputSupport.clear(player);

      ArgumentCaptor<ItemStack> restoredItems = ArgumentCaptor.forClass(ItemStack.class);
      verify(inventory, times(2)).setItem(any(Integer.class), restoredItems.capture());
      verify(inventory).setHeldItemSlot(2);
      verify(player, times(2)).updateInventory();
      assertThat(restoredItems.getAllValues()).containsExactly(inputSlotItem, selectedItem);
    }
  }

  @Test
  void repeatedClearDoesNotRestoreTheSameSnapshotTwice() {
    Player player = mock(Player.class);
    PlayerInventory inventory = mock(PlayerInventory.class);
    ItemStack heldItem = mock(ItemStack.class);
    when(heldItem.clone()).thenReturn(heldItem);
    when(player.getUniqueId()).thenReturn(UUID.randomUUID());
    when(player.getInventory()).thenReturn(inventory);
    when(inventory.getHeldItemSlot()).thenReturn(0);
    when(inventory.getItem(0)).thenReturn(heldItem);

    try (var ignored = mockConstruction(ItemStack.class)) {
      BookInputSupport.prepare(player, "Test input", "");
      BookInputSupport.clear(player);
      BookInputSupport.clear(player);

      verify(inventory, times(1)).setItem(any(Integer.class), any(ItemStack.class));
      verify(player, times(2)).updateInventory();
    }
  }
}
