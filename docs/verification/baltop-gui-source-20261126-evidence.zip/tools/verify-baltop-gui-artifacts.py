from pathlib import Path
import hashlib,json,re,subprocess,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/'run/baltop-gui-artifacts-20261126';out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
old=root/'run/baltop-gui-baseline-final-20261126/starcore.jar';jar=native/'target/starcore-1.0.0.jar'
classes=native/'target/classes'
types=['essentials/EssentialsModule','essentials/gui/BalTopGui','essentials/gui/HomeGui','essentials/gui/WarpGui','essentials/listener/EssentialsGuiListener','foundation/gui/BookInputSupport']
added=['essentials/baltop/BalTopView','essentials/baltop/BalTopViewLoader']
prefix='dev/starcore/starcore/'
checked={};sources={};apis={}
with zipfile.ZipFile(jar) as archive:
 for kind in types+added:
  name=prefix+kind;directory,stem=name.rsplit('/',1)
  for path in sorted((classes/directory).glob(stem+'*.class')):
   raw=path.read_bytes();relative=path.relative_to(classes).as_posix()
   assert archive.read(relative)==raw and int.from_bytes(raw[6:8],'big')==65,relative
   checked[relative]=sha(raw)
assert len(checked)>=8
paths=['src/main/java/'+prefix+kind+'.java' for kind in types+added]
paths+=['src/test/java/'+prefix+kind+'.java' for kind in ['essentials/gui/BalTopGuiSnapshotTest','essentials/baltop/BalTopViewLoaderTest','essentials/listener/EssentialsGuiOwnershipTest','foundation/gui/BookInputSupportTest']]
for name in paths:
 path=native/name;raw=path.read_bytes()
 for phase in ['compile-final-session','test-regression','package']:
  assert raw==(root/('run/baltop-gui-'+phase+'-20261126')/path.name).read_bytes(),(phase,name)
 sources[name]=sha(raw)
javap=r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin\javap.exe'
for kind in types:
 name=prefix+kind;outputs=[]
 for label,artifact in [('old',old),('current',jar)]:
  result=subprocess.run([javap,'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),name.replace('/','.')],capture_output=True,check=True)
  (out/(label+'-'+kind.rsplit('/',1)[1]+'.txt')).write_bytes(result.stdout)
  declaration=result.stdout.decode().replace('synchronized ','')
  outputs.append(set(re.findall(r'  (public [^\n]+;)\r?\n    descriptor: ([^\r\n]+)',declaration)))
 assert outputs[0] and outputs[0]<=outputs[1],name
 apis[name]={'preserved_methods':len(outputs[0]),'added_methods':[list(v) for v in sorted(outputs[1]-outputs[0])]}
summary={'status':'VERIFIED','starcore_sha256':sha(jar.read_bytes()),'baseline_sha256':sha(old.read_bytes()),'class_hashes':checked,
 'compiled_source_hashes':sources,'public_api':apis,'sbom_components':len(json.loads((native/'target/starcore-1.0.0-sbom.json').read_text())['components']),
 'limits':['Bytecode and API checks are not live Paper/Folia acceptance.','Legacy synchronous APIs require caller ownership and permit offline profile IO.']}
assert summary['sbom_components']==36
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('class_hashes','compiled_source_hashes','public_api')}))
