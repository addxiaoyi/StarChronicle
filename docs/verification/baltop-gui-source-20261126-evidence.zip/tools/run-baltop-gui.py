from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
phase=sys.argv[1];out=root/'run'/('baltop-gui-'+phase+'-20261126');out.mkdir(exist_ok=False)
env=os.environ.copy();env['JAVA_HOME']=r'C:\tmp\jdk21\jdk-21.0.13.1+2'
env['MAVEN_OPTS']=r'-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8'
if phase.startswith('baseline'):
    shutil.copy2(native/'target/starcore-1.0.0.jar',out/'starcore.jar')
if 'test' in phase or phase.startswith('baseline'):env['MAVEN_OPTS']+=r' -javaagent:C:\Users\Administrator\.m2\repository\org\mockito\mockito-core\5.23.0\mockito-core-5.23.0.jar'
base=['cmd.exe','/d','/c',str(native/'mvnw.cmd'),'-o','-B','-ntp','-Djacoco.skip=true']
if phase.startswith('baseline'):args=['-Dmaven.main.skip=true','-DskipTests','test-compile']
elif phase.startswith('compile-tests'):args=['spotless:apply','-Dmaven.main.skip=true','-DskipTests','test-compile']
elif phase.startswith('compile'):args=['spotless:apply','-DskipTests','test-compile']
elif phase.startswith('test'):
    args=['-DforkCount=0','-Dtest='+sys.argv[2],'surefire:test']
elif phase.startswith('package'):args=['-Dmaven.main.skip=true','-Dmaven.test.skip=true','verify']
elif phase=='sbom':
    base.remove('-o')
    args=['cyclonedx:makeAggregateBom@generate-sbom']
else:raise ValueError(phase)
if phase=='package-lowheap':env['MAVEN_OPTS']=env['MAVEN_OPTS'].replace('-Xmx256m','-Xmx128m').replace('ReservedCodeCacheSize=48m','ReservedCodeCacheSize=24m').replace('CompressedClassSpaceSize=32m','CompressedClassSpaceSize=24m')
if phase.startswith(('compile-final','baseline-final')):base.append('-Dmaven.compiler.useIncrementalCompilation=false')
start=time.monotonic()
with (out/'maven.log').open('wb') as log:result=subprocess.run(base+args,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT)
if phase.startswith('baseline') and result.returncode==0:
    with (out/'test.log').open('wb') as log:result=subprocess.run(base+['-DforkCount=0','-Dtest=BalTopGuiSnapshotTest','surefire:test'],cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT)
logtext='\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in out.glob('*.log'))
totals={k:0 for k in ('tests','failures','errors','skipped')}
for suite in re.findall(r'\[INFO\] Running ([\w.$]+)',logtext):
    path=native/'target/surefire-reports'/('TEST-'+suite+'.xml')
    if path.exists():
        (out/'surefire').mkdir(exist_ok=True);shutil.copy2(path,out/'surefire'/path.name)
        data=ET.parse(path).getroot()
        for key in totals:totals[key]+=int(data.attrib.get(key,0))
summary={'exit_code':result.returncode,'totals':totals,'seconds':time.monotonic()-start,'args':base+args}
(out/'result.json').write_text(json.dumps(summary,indent=2))
for name in ('src/main/java/dev/starcore/starcore/foundation/gui/BookInputSupport.java','src/test/java/dev/starcore/starcore/foundation/gui/BookInputSupportTest.java','src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java',
'src/main/java/dev/starcore/starcore/essentials/gui/BalTopGui.java',
'src/main/java/dev/starcore/starcore/essentials/gui/HomeGui.java',
'src/main/java/dev/starcore/starcore/essentials/gui/WarpGui.java',
'src/main/java/dev/starcore/starcore/essentials/baltop/BalTopView.java',
'src/main/java/dev/starcore/starcore/essentials/baltop/BalTopViewLoader.java',
'src/main/java/dev/starcore/starcore/essentials/listener/EssentialsGuiListener.java',
'src/test/java/dev/starcore/starcore/essentials/gui/BalTopGuiSnapshotTest.java',
'src/test/java/dev/starcore/starcore/essentials/baltop/BalTopViewLoaderTest.java',
'src/test/java/dev/starcore/starcore/essentials/listener/EssentialsGuiOwnershipTest.java'):
    path=native/name
    if path.exists():shutil.copy2(path,out/path.name)
print(json.dumps(summary));raise SystemExit(result.returncode)
