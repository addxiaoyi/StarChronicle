from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
phases=['baseline-final','compile','compile-final-session','test-focused','test-regression','package','sbom']
runs={p:json.loads((root/'run'/('baltop-gui-'+p+'-20261126/result.json')).read_text()) for p in phases}
assert runs['baseline-final']['totals']==dict(tests=2,failures=1,errors=1,skipped=0)
assert runs['test-regression']['totals']==dict(tests=607,failures=0,errors=0,skipped=0)
artifacts=json.loads((root/'run/baltop-gui-artifacts-20261126/result.json').read_text())
summary={'status':'VERIFIED','baseline':{'chronicle':'bd4d4b076d437af0596adb3a2909677ddb1db333','starcore':'de4d39761e2360dc77c6b50f1d117b1c7d0167b6'},
 'tests':runs['test-regression']['totals'],'new_tests':56,'existing_book_tests_added_to_selection':2,'runs':runs,
 'artifacts':{'starcore':artifacts['starcore_sha256'],'chronicle':'42c0e27b7726548faf8f2bf330af3de44e44225632645824ccf3ad102c22f071'},
 'api':artifacts['public_api'],'class_hashes':artifacts['class_hashes'],'sbom_components':artifacts['sbom_components'],
 'limits':['No Minecraft, live Paper/Folia, third-party combination or full hot-reload acceptance.',
 '607 related tests, not the whole StarCore suite; existing POM exclusions remain. forkCount=0, jacoco.skip=true, 256 MiB JVM limit.',
 'Package verify and SBOM generation briefly overlapped; both completed successfully. Sources were unchanged and class/API fingerprints were checked after both exited.',
 'Legacy synchronous constructors require caller ownership and permit offline profile IO; the module uses the scheduler-aware listener.',
 'Offline names use asynchronous lookup; unknown external Folia economy is refused. Default heads remain for unresolved names. No skin-loading proof.',
 'Shutdown invalidates pending state and schedules cleanup only for the exact player and inventory/book token. Plugin shutdown or inventory restoration failures are not a full hot-unload recovery guarantee.',
 'Initial compile: 2269 main and 1100 test source files. Final stale-source compile: 6 main and 8 test files. Frozen source and packaged bytecode checks passed.',
 'Chronicle Java unchanged: 1076 local tests and Linux CI #196 belong to the previous checkpoint; previous live evidence is not transferable.',
 'Fetched newer upstream native trade a645272 and Chronicle evidence 78b227f after GUI verification; those changes are not in this checkpoint.']}
files={}
for phase in phases:
 folder=root/'run'/('baltop-gui-'+phase+'-20261126')
 for p in sorted(folder.rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.class'):files[phase+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for p in sorted((root/'run/baltop-gui-artifacts-20261126').rglob('*')):
 if p.is_file():files['artifacts/'+p.name]=p.read_bytes()
for name in ['run/run-baltop-gui.py','run/verify-baltop-gui-artifacts.py','run/finalize-baltop-gui.py',
 'run/nickname-owner-ci-success-20261126.log','run/nickname-owner-ci-20261126.json','run/nickname-owner-delivery-git-20261126.json']:
 files['tools/'+Path(name).name]=(root/name).read_bytes()
for name in ['pom.xml','docs/ESSENTIALS-GUI-OWNERSHIP.md','target/starcore-1.0.0-sbom.json','src/test/java/dev/starcore/starcore/essentials/EssentialsModuleLifecycleTest.java']:
 files['native/'+name]=(native/name).read_bytes()
files['native/change.patch']=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=native)
files['manifest.json']=(json.dumps({'summary':summary,'files':{n:sha(b) for n,b in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
out=root/'docs/verification/baltop-gui-source-20261126-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(m['files'])|{'manifest.json'}
 for name,digest in m['files'].items():assert sha(z.read(name))==digest,name
summary['evidence_files']=len(files);summary['evidence_sha256']=sha(out.read_bytes())
(root/'docs/verification/baltop-gui-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# Essentials 排行榜与 GUI 会话隔离：2026-11-26

排行榜原先在点击时重新读取列表，排名改变后可能指向另一账号；极大页码会在乘法溢出后越界。本次让显示与点击共享固定快照，并按原 Player 所属线程读取名字、构建界面和反馈。家园／星港列表也固定显示页和名称；书本输入、旧退出事件及延迟停用清理按确切会话隔离。未启动 Minecraft。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{summary['artifacts']['starcore']}` |
| Chronicle，Java 未改 | `{summary['artifacts']['chronicle']}` |
| 证据 ZIP | `{summary['evidence_sha256']}` |

[证据包](verification/baltop-gui-source-20261126-evidence.zip)含 **{len(files)} 文件**，[机器摘要](verification/baltop-gui-source-20261126-summary.json)记录每轮结果、冻结源码、构建与 API／类字节检查。归档上一检查点 [Linux CI #196](https://github.com/addxiaoyi/StarChronicle/actions/runs/45767030513) 的成功日志；新检查点 CI 另行记录。

## 行为

- 排行榜最多读取当前页 28 个名字及查看者上一名（最多 29）；自带经济异步读取，外部 Paper 经济在全局线程读取，未验证的外部 Folia 提供者拒绝。在线名字在原目标 owner 获取；离线查询异步，返回 Player 时转回其 owner。失败回退 UUID／默认头像，有真实名字时用 UUID＋名字创建独立头像资料。
- 排行榜、家园和星港均先夹紧页码，再渲染与解释槽位。点击事件即时取消，动作在事件后回原 owner 执行，再检查确切 inventory／会话；刷新成功消息在真正打开后发送。
- 最新请求才可替换发起时的界面；换菜单、关闭、退出、重连、停用或任务退休后不再显示旧结果。请求有独立 identity，同玩家同 inventory 的旧回调不能删除新请求；终止路径释放 pending 引用。
- 运行界面使用单个会话记录。旧 quit／close 只清属于原 Player 的状态，不影响新连接。家园书本保存回原 owner，并带原会话／请求标识；不同书本的编辑不能被当成家园输入。
- 书本 token 每次独立，即使物品完全相同也不复用。停用短锁内排空 detached 状态，先取消旧业务任务，再按原 Player＋inventory／book token 安排清理；并发打开中的界面不遗留未登记状态。Bukkit 库存调用位于锁外。
- 原公开 API 与旧同步构造器保留；旧调用方需拥有所有访问玩家并允许同步资料 I/O。实际模块使用新调度构造器。家园提示改为书本填写／签名。

## 验证与范围

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现对照 | 2 | 1 | 1 | 0 |
| GUI／书本／模块专项 | 71 | 0 | 0 | 0 |
| 最终相关回归 | **607** | **0** | **0** | **0** |

旧实现失败分别是排名更新后点击 UUID 改变，以及 `Integer.MAX_VALUE` 页码产生负索引，均保留。新增 **56 项**：3 快照／头像、21 名字读取与调度、28 GUI 所有权／会话、2 书本 token、2 模块停用顺序／异常；本轮选择还纳入 2 项原有书本测试，因此比此前 549 增加 58。607 项含 560 调度器／Essentials、43 经济／Vault／交易账本及 4 书本测试，不是全库回归，POM 既有排除不变。

首次编译 2,269 主源／1,100 测试源；最终增量编译 6 主源／8 测试源。Spotless、verify 打包、36 组件 SBOM、{len(artifacts['class_hashes'])} 个相关类字节及 6 类旧公开声明／描述符核对通过。每个 Maven JVM 上限 256 MiB、forkCount=0、jacoco.skip=true；打包尾段与独立 SBOM 有短暂重叠，均成功，随后核验最终产物；没有本地覆盖率结论。

Chronicle 主源未变，保留 1,076 项本地及 Linux CI #196 的检查点。线程模拟、类字节与 API 核对不是实服验收；头像加载、全插件在线热卸载、书本恢复异常后的库存保障、其他社交／生命周期、外部经济未知结果及长期容量仍待完成。

本次 fetch 发现上游原生贸易 `a645272`／证据 `78b227f`，尚未包含在上述 GUI 构件；下一步合并并验证其与本分支贸易／恢复协议的兼容性。十阶段目标仍未全部完成。
'''
(root/'docs/BALTOP-GUI-SOURCE-20261126.md').write_text(report,encoding='utf-8')
note=f'2026-11-26 当前 GUI 检查点：[排行榜与会话隔离](BALTOP-GUI-SOURCE-20261126.md)。固定显示／点击快照，按原 owner 读取名字并构建界面，旧 quit、书本与停用清理不消费新会话。新增 56 项，**607 项相关回归通过**；StarCore `{artifacts["starcore_sha256"][:8]}…{artifacts["starcore_sha256"][-6:]}` 打包／36 组件 SBOM／API／类字节通过。Chronicle 保持 1,076 项；继续合入上游新贸易增量，未启动 Minecraft。'
for name in ['README.md','docs/HANDOFF-2026-11-25.md','docs/HANDOFF-2026-11-26.md','docs/REMAINING-WORK.md']:
 p=root/name;t=p.read_text(encoding='utf-8');pos=t.index('\n\n')+2
 inserted=note.replace('(BALTOP-GUI-SOURCE-20261126.md)','(docs/BALTOP-GUI-SOURCE-20261126.md)') if name=='README.md' else note
 p.write_text(t[:pos]+inserted+'\n\n'+t[pos:],encoding='utf-8')
print(json.dumps({'artifacts':summary['artifacts'],'evidence_files':len(files),'evidence_sha256':summary['evidence_sha256']}))
