package dev.starcore.starcore.essentials.gui;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import java.math.BigDecimal;
import java.util.*;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.SkullMeta;
import org.junit.jupiter.api.Test;

class BalTopGuiSnapshotTest {
  @Test
  void clickKeepsTheRenderedEntryAfterRankingsChange() {
    check(false);
  }

  @Test
  void largePageIsClampedBeforeIndexArithmetic() {
    check(true);
  }

  private void check(boolean hugePage) {
    Player viewer = mock(Player.class);
    UUID viewerId = UUID.randomUUID();
    when(viewer.getUniqueId()).thenReturn(viewerId);
    EconomyService economy = mock(EconomyService.class);
    when(economy.getBalance(viewerId)).thenReturn(BigDecimal.ONE);
    BalTopService ranking = new BalTopService();
    UUID first = UUID.randomUUID(), replacement = UUID.randomUUID();
    ranking.updateRankings(Map.of(first, BigDecimal.TEN));
    Inventory inventory = mock(Inventory.class);
    try (var bukkit = mockStatic(Bukkit.class);
        var items =
            mockConstruction(
                ItemStack.class,
                (item, context) -> when(item.getItemMeta()).thenReturn(mock(SkullMeta.class)))) {
      bukkit
          .when(
              () ->
                  Bukkit.createInventory(
                      any(InventoryHolder.class), anyInt(), any(Component.class)))
          .thenReturn(inventory);
      bukkit
          .when(() -> Bukkit.getOfflinePlayer(any(UUID.class)))
          .thenAnswer(
              i -> {
                OfflinePlayer profile = mock(OfflinePlayer.class);
                when(profile.getName()).thenReturn("Original");
                return profile;
              });
      BalTopGui gui = new BalTopGui(viewer, ranking, economy, hugePage ? Integer.MAX_VALUE : 1);
      ranking.updateRankings(Map.of(replacement, BigDecimal.ONE));
      assertNotNull(gui.getEntryFromSlot(10));
      assertEquals(first, gui.getEntryFromSlot(10).playerId());
      assertEquals(BigDecimal.TEN, gui.getEntryFromSlot(10).balance());
    }
  }
}
