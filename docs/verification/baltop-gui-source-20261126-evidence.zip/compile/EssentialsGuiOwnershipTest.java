package dev.starcore.starcore.essentials.listener;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.teleport.TeleportService;
import dev.starcore.starcore.essentials.warp.WarpService;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.gui.BookInputSupport;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.*;

class EssentialsGuiOwnershipTest {
  private static final Object ASYNC = new Object();
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final HomeService homes = mock(HomeService.class);
  private final WarpService warps = mock(WarpService.class);
  private final TeleportService teleports = mock(TeleportService.class);
  private final BalTopService rankings = new BalTopService();
  private final InternalEconomyService economy = mock(InternalEconomyService.class);
  private final Map<UUID, Player> online = new HashMap<>();
  private final Map<Player, State> states = new IdentityHashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private final UUID ranked = UUID.randomUUID();
  private Object owner;
  private boolean active = true;
  private Player viewer;
  private EssentialsGuiListener listener;
  private MockedStatic<Bukkit> bukkit;
  private MockedStatic<BookInputSupport> books;
  private MockedConstruction<ItemStack> items;

  private record Job(Object owner, Runnable body, Runnable retired) {}

  private static class State {
    Inventory inventory = mock(Inventory.class);
    int opens;
    final List<String> messages = new ArrayList<>();
  }

  @BeforeEach
  void setup() {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner);
              OfflinePlayer p = mock(OfflinePlayer.class);
              when(p.getName()).thenReturn("Ranked");
              return p;
            });
    doAnswer(
            i -> {
              jobs.add(new Job(ASYNC, i.getArgument(0), () -> {}));
              return null;
            })
        .when(scheduler)
        .runAsync(any());
    doAnswer(
            i -> {
              jobs.add(
                  new Job(
                      i.getArgument(0),
                      () -> i.<Consumer<Object>>getArgument(1).accept(null),
                      i.getArgument(2)));
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(), any(), any());
    when(economy.getBalance(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner);
              return BigDecimal.ONE;
            });
    when(economy.getAllBalances())
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner);
              return Map.of(ranked, BigDecimal.valueOf(99));
            });
    when(homes.getHomeNames(any(UUID.class))).thenReturn(List.of("base"));
    when(warps.getWarpNames()).thenReturn(List.of("port"));
    when(teleports.canUseWarp(any())).thenReturn(true);
    viewer = player(UUID.randomUUID());
    rankings.updateRankings(Map.of(ranked, BigDecimal.TEN));
    bukkit = mockStatic(Bukkit.class);
    bukkit
        .when(
            () ->
                Bukkit.createInventory(any(InventoryHolder.class), anyInt(), any(Component.class)))
        .thenAnswer(
            i -> {
              assertSame(viewer, owner);
              Inventory inventory = mock(Inventory.class);
              when(inventory.getHolder()).thenReturn(i.getArgument(0));
              when(inventory.getSize()).thenReturn(i.getArgument(1));
              return inventory;
            });
    bukkit
        .when(() -> Bukkit.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              fail("Synchronous profile lookup");
              return null;
            });
    items =
        mockConstruction(
            ItemStack.class,
            (item, context) -> when(item.getItemMeta()).thenReturn(mock(SkullMeta.class)));
    books = mockStatic(BookInputSupport.class);
    listener =
        new EssentialsGuiListener(
            plugin, homes, warps, teleports, rankings, economy, scheduler, () -> active);
  }

  @AfterEach
  void closeMocks() {
    books.close();
    items.close();
    bukkit.close();
  }

  private Player player(UUID id) {
    State state = new State();
    Player player =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (Set.of(
                      "getOpenInventory",
                      "openInventory",
                      "closeInventory",
                      "isOnline",
                      "getName",
                      "sendMessage",
                      "getInventory")
                  .contains(method)) {
                assertSame(i.getMock(), owner, "Foreign player " + method);
                return switch (method) {
                  case "getName" -> "Viewer";
                  case "isOnline" -> online.get(id) == i.getMock();
                  case "getInventory" -> mock(PlayerInventory.class);
                  case "getOpenInventory" -> {
                    InventoryView view = mock(InventoryView.class);
                    when(view.getTopInventory()).thenReturn(state.inventory);
                    yield view;
                  }
                  case "closeInventory" -> {
                    closeEvent((Player) i.getMock(), state.inventory);
                    state.inventory = mock(Inventory.class);
                    yield null;
                  }
                  case "openInventory" -> {
                    state.inventory = i.getArgument(0);
                    state.opens++;
                    yield null;
                  }
                  case "sendMessage" -> {
                    state.messages.add(
                        PlainTextComponentSerializer.plainText().serialize(i.getArgument(0)));
                    yield null;
                  }
                  default -> null;
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    states.put(player, state);
    online.put(id, player);
    return player;
  }

  private void at(Player player, Runnable action) {
    Object previous = owner;
    owner = player;
    try {
      action.run();
    } finally {
      owner = previous;
    }
  }

  private void run(Job job) {
    Object previous = owner;
    owner = job.owner();
    try {
      job.body().run();
    } finally {
      owner = previous;
    }
  }

  private void drain() {
    int limit = 80;
    while (!jobs.isEmpty()) {
      assertTrue(limit-- > 0);
      run(jobs.remove());
    }
  }

  private void openRanking() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    drain();
  }

  private void closeEvent(Player player, Inventory inventory) {
    if (listener == null) return;
    InventoryCloseEvent event = mock(InventoryCloseEvent.class);
    when(event.getPlayer()).thenReturn(player);
    when(event.getInventory()).thenReturn(inventory);
    listener.onInventoryClose(event);
  }

  private InventoryClickEvent click(int slot) {
    Inventory inventory = states.get(viewer).inventory;
    InventoryView view = mock(InventoryView.class);
    when(view.getTopInventory()).thenReturn(inventory);
    when(view.getTitle()).thenReturn("irrelevant");
    InventoryClickEvent event = mock(InventoryClickEvent.class);
    when(event.getWhoClicked()).thenReturn(viewer);
    when(event.getView()).thenReturn(view);
    when(event.getClickedInventory()).thenReturn(inventory);
    when(event.getRawSlot()).thenReturn(slot);
    when(event.getClick()).thenReturn(ClickType.LEFT);
    at(viewer, () -> listener.onInventoryClick(event));
    return event;
  }

  private void quit(Player player) {
    PlayerQuitEvent event = mock(PlayerQuitEvent.class);
    when(event.getPlayer()).thenReturn(player);
    at(player, () -> listener.onPlayerQuit(event));
  }

  @Test
  void openingBuildsOnViewerOwnerAfterAsyncReads() {
    openRanking();
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void openingAnotherMenuInvalidatesQueuedRanking() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    at(viewer, () -> listener.openHomeGui(viewer, 1));
    Inventory expected = states.get(viewer).inventory;
    drain();
    assertSame(expected, states.get(viewer).inventory);
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void foreignInventoryChangeSuppressesTheLateRanking() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    states.get(viewer).inventory = mock(Inventory.class);
    drain();
    assertEquals(0, states.get(viewer).opens);
  }

  @Test
  void closingExpectedInventoryCancelsPendingOpen() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    at(viewer, () -> closeEvent(viewer, states.get(viewer).inventory));
    drain();
    assertEquals(0, states.get(viewer).opens);
  }

  @Test
  void twoRequestsOnlyOpenTheNewestView() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    at(viewer, () -> listener.openBalTopGui(viewer, Integer.MAX_VALUE));
    drain();
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void replacedViewerCannotReceiveTheOldOpen() {
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    Player replacement = player(viewer.getUniqueId());
    drain();
    assertEquals(0, states.get(viewer).opens);
    assertEquals(0, states.get(replacement).opens);
  }

  @Test
  void staleQuitCannotCancelReplacementPendingView() {
    Player old = viewer;
    viewer = player(old.getUniqueId());
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    quit(old);
    drain();
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void clickUsesRenderedSnapshotAfterRankingsChanged() {
    openRanking();
    rankings.updateRankings(Map.of(UUID.randomUUID(), BigDecimal.ZERO));
    click(10);
    assertTrue(states.get(viewer).messages.isEmpty());
    drain();
    assertEquals(List.of("玩家: Ranked", "余额: 10.00"), states.get(viewer).messages);
  }

  @Test
  void refreshProviderReadIsAsyncAndSuccessComesAfterOpen() {
    openRanking();
    click(50);
    assertEquals(1, states.get(viewer).opens);
    drain();
    assertEquals(2, states.get(viewer).opens);
    assertEquals(List.of("排行榜已刷新"), states.get(viewer).messages);
  }

  @Test
  void delayedClickCannotActOnAnotherInventory() {
    openRanking();
    click(10);
    states.get(viewer).inventory = mock(Inventory.class);
    drain();
    assertTrue(states.get(viewer).messages.isEmpty());
  }

  @Test
  void closeInvalidatesPendingOpenAndClosesOnlyOwnedInventory() {
    openRanking();
    listener.close();
    assertEquals(1, jobs.size());
    drain();
    assertNull(states.get(viewer).inventory.getHolder());
    at(viewer, () -> listener.openBalTopGui(viewer, 1));
    drain();
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void lateCleanupCannotCloseANewerInventory() {
    openRanking();
    listener.close();
    Inventory newer = mock(Inventory.class);
    states.get(viewer).inventory = newer;
    drain();
    assertSame(newer, states.get(viewer).inventory);
  }

  @Test
  void inactiveModuleDoesNotOpenOrProcessClicks() {
    openRanking();
    active = false;
    InventoryClickEvent event = click(10);
    verify(event, never()).setCancelled(true);
    at(viewer, () -> listener.openHomeGui(viewer, 1));
    assertEquals(1, states.get(viewer).opens);
  }

  @Test
  void homeClickKeepsDisplayedNameAfterServiceChanges() {
    at(viewer, () -> listener.openHomeGui(viewer, 1));
    when(homes.getHomeNames(viewer.getUniqueId())).thenReturn(List.of("different"));
    click(10);
    drain();
    verify(teleports).teleportToHome(viewer, "base");
  }

  @Test
  void warpClickKeepsDisplayedNameAfterServiceChanges() {
    at(viewer, () -> listener.openWarpGui(viewer, 1));
    when(warps.getWarpNames()).thenReturn(List.of("different"));
    click(10);
    drain();
    verify(teleports).teleportToWarp(viewer, "port");
  }

  @Test
  void homeBookSaveReturnsToOriginalOwnerAfterTheEvent() {
    at(viewer, () -> listener.openHomeGui(viewer, 1));
    click(22);
    drain();
    BookMeta meta = mock(BookMeta.class);
    when(meta.getPages()).thenReturn(List.of("new_home"));
    PlayerEditBookEvent event = mock(PlayerEditBookEvent.class);
    when(event.getPlayer()).thenReturn(viewer);
    when(event.getNewBookMeta()).thenReturn(meta);
    at(viewer, () -> listener.onHomeNameBookEdit(event));
    verify(homes, never()).setHome(any(), anyString());
    drain();
    verify(homes).setHome(viewer, "new_home");
  }

  @Test
  void replacementSessionCannotConsumeOldBookInput() {
    at(viewer, () -> listener.openHomeGui(viewer, 1));
    click(22);
    drain();
    Player replacement = player(viewer.getUniqueId());
    PlayerEditBookEvent event = mock(PlayerEditBookEvent.class);
    when(event.getPlayer()).thenReturn(replacement);
    at(replacement, () -> listener.onHomeNameBookEdit(event));
    verify(event, never()).setCancelled(true);
    verify(homes, never()).setHome(any(), anyString());
  }
}
