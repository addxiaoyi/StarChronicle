package dev.starcore.starcore.essentials.baltop;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.foundation.economy.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.Answers;

class BalTopViewLoaderTest {
  private static final Object ASYNC = new Object(), GLOBAL = new Object();
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final BalTopService rankings = new BalTopService();
  private final Map<UUID, Player> online = new HashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private final List<BalTopView> results = new ArrayList<>();
  private final List<String> failures = new ArrayList<>();
  private EconomyService economy;
  private Player viewer, target;
  private Object owner, rejected;
  private boolean active = true, current = true, folia, lostRegistration;
  private int profileReads;

  private record Job(Object owner, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner);
              profileReads++;
              OfflinePlayer profile = mock(OfflinePlayer.class);
              when(profile.getName())
                  .thenAnswer(
                      call -> {
                        assertSame(ASYNC, owner);
                        return "Offline";
                      });
              return profile;
            });
    when(scheduler.isFolia()).thenAnswer(i -> folia);
    doAnswer(
            i -> {
              queue(ASYNC, i.getArgument(0), () -> {});
              return null;
            })
        .when(scheduler)
        .runAsync(any());
    doAnswer(
            i -> {
              queue(GLOBAL, i.getArgument(0), () -> {});
              return null;
            })
        .when(scheduler)
        .runGlobal(any());
    doAnswer(
            i -> {
              queue(
                  i.getArgument(0),
                  () -> i.<Consumer<Object>>getArgument(1).accept(null),
                  i.getArgument(2));
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(), any(), any());
    viewer = player(UUID.randomUUID(), "Viewer");
    target = player(UUID.randomUUID(), "Target");
    rankings.updateRankings(Map.of(target.getUniqueId(), BigDecimal.TEN));
    useEconomy(true);
  }

  private Player player(UUID id, String name) {
    Player player =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (method.equals("getName") || method.equals("isOnline")) {
                assertSame(i.getMock(), owner, "Foreign player access " + method);
                return method.equals("getName") ? name : online.get(id) == i.getMock();
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    online.put(id, player);
    return player;
  }

  private void useEconomy(boolean internal) {
    economy = internal ? mock(InternalEconomyService.class) : mock(EconomyService.class);
    Object lane = internal ? ASYNC : GLOBAL;
    when(economy.getBalance(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(lane, owner);
              return BigDecimal.ONE;
            });
    when(economy.getAllBalances())
        .thenAnswer(
            i -> {
              assertSame(lane, owner);
              return Map.of(target.getUniqueId(), BigDecimal.valueOf(20));
            });
  }

  private void queue(Object lane, Runnable body, Runnable retired) {
    if (lane == rejected) throw new IllegalStateException("Rejected");
    jobs.add(new Job(lane, body, retired));
    if (lostRegistration) throw new IllegalStateException("Lost registration response");
  }

  private void run(Job job) {
    Object previous = owner;
    owner = job.owner();
    try {
      job.body().run();
    } finally {
      owner = previous;
    }
  }

  private void drain() {
    int limit = 140;
    while (!jobs.isEmpty()) {
      assertTrue(limit-- > 0);
      run(jobs.remove());
    }
  }

  private void load(int page, boolean refresh) {
    owner = viewer;
    try {
      new BalTopViewLoader(plugin, scheduler, () -> active, rankings, economy)
          .load(
              viewer,
              page,
              refresh,
              () -> current,
              view -> {
                assertSame(viewer, owner);
                results.add(view);
              },
              message -> {
                assertSame(viewer, owner);
                failures.add(message);
              });
    } finally {
      owner = null;
    }
  }

  @Test
  void internalEconomyAndEachNameUseTheirOwnExecutor() {
    load(1, false);
    assertTrue(results.isEmpty());
    drain();
    assertEquals(1, results.size());
    assertEquals("Target", results.getFirst().name(target.getUniqueId()));
    assertEquals(BigDecimal.ONE, results.getFirst().viewerBalance());
  }

  @Test
  void externalPaperReadsOnGlobalExecutor() {
    useEconomy(false);
    load(1, true);
    drain();
    assertEquals(1, results.size());
  }

  @Test
  void externalFoliaProviderIsNeverInvoked() {
    useEconomy(false);
    folia = true;
    load(1, true);
    drain();
    verifyNoInteractions(economy);
    assertEquals(1, failures.size());
  }

  @Test
  void offlineProfilesAreReadAsync() {
    online.remove(target.getUniqueId());
    load(1, false);
    drain();
    assertEquals(1, profileReads);
    assertEquals("Offline", results.getFirst().name(target.getUniqueId()));
  }

  @Test
  void emptyRankingsStillReturnTheViewerBalance() {
    rankings.updateRankings(Map.of());
    load(Integer.MAX_VALUE, false);
    drain();
    assertEquals(1, results.getFirst().page());
    assertEquals(0, profileReads);
  }

  @Test
  void namesAreBoundedToClampedPageAndTheViewersPreviousRank() {
    Map<UUID, BigDecimal> balances = new HashMap<>();
    for (int i = 0; i < 100; i++) balances.put(new UUID(0, i + 1), BigDecimal.valueOf(1000 - i));
    rankings.updateRankings(balances);
    load(Integer.MAX_VALUE, false);
    drain();
    assertEquals(4, results.getFirst().page());
    assertEquals(16, profileReads);
    assertEquals(16, results.getFirst().names().size());
  }

  @Test
  void previousRankOutsidePageIsResolvedOnce() {
    Map<UUID, BigDecimal> balances = new HashMap<>();
    for (int i = 0; i < 70; i++) balances.put(new UUID(0, i + 1), BigDecimal.valueOf(1000 - i));
    balances.put(viewer.getUniqueId(), BigDecimal.valueOf(950));
    rankings.updateRankings(balances);
    load(1, false);
    drain();
    assertEquals(29, profileReads);
    assertEquals(29, results.getFirst().names().size());
  }

  @Test
  void sourceMutationCannotChangeTheCapturedRanking() {
    load(1, false);
    run(jobs.remove());
    rankings.updateRankings(Map.of());
    drain();
    assertEquals(1, results.getFirst().entries().size());
  }

  @Test
  void replacedViewerCannotReceiveOldView() {
    load(1, false);
    player(viewer.getUniqueId(), "NewViewer");
    drain();
    assertTrue(results.isEmpty());
  }

  @Test
  void replacedTargetFallsBackWithoutReadingEitherWrongOwner() {
    load(1, false);
    run(jobs.remove());
    player(target.getUniqueId(), "NewTarget");
    drain();
    assertEquals(target.getUniqueId().toString(), results.getFirst().name(target.getUniqueId()));
  }

  @Test
  void retiredTargetCompletesWithUuidFallbackOnce() {
    load(1, false);
    run(jobs.remove());
    Job name = jobs.remove();
    name.retired().run();
    run(name);
    drain();
    assertEquals(1, results.size());
    assertEquals(target.getUniqueId().toString(), results.getFirst().name(target.getUniqueId()));
  }

  @Test
  void retiredViewerDropsTheFinalView() {
    load(1, false);
    run(jobs.remove());
    run(jobs.remove());
    Job show = jobs.remove();
    show.retired().run();
    run(show);
    assertTrue(results.isEmpty());
  }

  @Test
  void duplicateCallbacksCannotRefreshOrPublishTwice() {
    load(1, true);
    Job gather = jobs.remove();
    run(gather);
    run(gather);
    Job name = jobs.remove();
    run(name);
    run(name);
    Job show = jobs.remove();
    run(show);
    run(show);
    verify(economy).getAllBalances();
    assertEquals(1, results.size());
    assertTrue(jobs.isEmpty());
  }

  @Test
  void newRequestInvalidatesOldQueuedWork() {
    load(1, true);
    current = false;
    drain();
    verifyNoInteractions(economy);
    assertTrue(results.isEmpty());
  }

  @Test
  void closedLifetimeDoesNotPublish() {
    load(1, false);
    run(jobs.remove());
    active = false;
    drain();
    assertTrue(results.isEmpty());
  }

  @Test
  void shutdownDuringRefreshDoesNotPublishItsRanking() {
    doAnswer(
            i -> {
              active = false;
              return Map.of();
            })
        .when(economy)
        .getAllBalances();
    load(1, true);
    drain();
    assertEquals(1, rankings.size());
    assertTrue(results.isEmpty());
  }

  @Test
  void rejectedTargetUsesFallback() {
    rejected = target;
    load(1, false);
    drain();
    assertEquals(target.getUniqueId().toString(), results.getFirst().name(target.getUniqueId()));
  }

  @Test
  void failedRegistrationCannotRunItsLateProviderCallback() {
    lostRegistration = true;
    load(1, true);
    lostRegistration = false;
    drain();
    verifyNoInteractions(economy);
    assertTrue(results.isEmpty());
  }

  @Test
  void providerFailureReportsFailureWithoutPublishingView() {
    doThrow(new IllegalStateException("unavailable")).when(economy).getBalance(any(UUID.class));
    load(1, false);
    drain();
    assertTrue(results.isEmpty());
    assertEquals(1, failures.size());
  }

  @Test
  void offlineLookupReturningAPlayerSwitchesToItsOwner() {
    UUID id = target.getUniqueId();
    online.remove(id);
    doAnswer(
            i -> {
              assertSame(ASYNC, owner);
              online.put(id, target);
              return target;
            })
        .when(server)
        .getOfflinePlayer(id);
    load(1, false);
    drain();
    assertEquals("Target", results.getFirst().name(id));
  }
}
