package dev.starcore.starcore.essentials.listener;

import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.command.TeleportGui;
import dev.starcore.starcore.essentials.gui.BalTopGui;
import dev.starcore.starcore.essentials.gui.HomeGui;
import dev.starcore.starcore.essentials.gui.WarpGui;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.teleport.TeleportService;
import dev.starcore.starcore.essentials.warp.WarpService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.gui.BookInputSupport;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.Plugin;

/** Essentials GUI 事件监听器 */
public final class EssentialsGuiListener implements Listener {
  private static final int HOME_FIRST_SLOT = 10;
  private static final int HOME_LAST_SLOT = 16;
  private static final int HOMES_PER_PAGE = 7;
  private final Plugin plugin;
  private final HomeService homeService;
  private final WarpService warpService;
  private final TeleportService teleportService;
  private final BalTopService balTopService;
  private final EconomyService economyService;

  // 追踪打开的 GUI
  private final ConcurrentHashMap<UUID, String> openGuis = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, Inventory> openInventories = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<UUID, Boolean> pendingHomeNames = new ConcurrentHashMap<>();
  private static final String HOME_GUI = "home";
  private static final String WARP_GUI = "warp";
  private static final String BALTOP_GUI = "baltop";
  private static final String TELEPORT_GUI = "teleporter";

  public EssentialsGuiListener(
      Plugin plugin,
      HomeService homeService,
      WarpService warpService,
      TeleportService teleportService,
      BalTopService balTopService,
      EconomyService economyService) {
    this.plugin = plugin;
    this.homeService = homeService;
    this.warpService = warpService;
    this.teleportService = teleportService;
    this.balTopService = balTopService;
    this.economyService = economyService;
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getWhoClicked() instanceof Player player
        && ownsOpenInventory(player, event.getView().getTopInventory())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    String guiType = openGuis.get(player.getUniqueId());
    if (guiType == null || !ownsOpenInventory(player, event.getView().getTopInventory())) {
      return;
    }

    // 取消点击
    event.setCancelled(true);

    var top = event.getView().getTopInventory();
    if (event.getClickedInventory() != top
        || event.getRawSlot() < 0
        || event.getRawSlot() >= top.getSize()
        || (event.getClick() != ClickType.LEFT && event.getClick() != ClickType.RIGHT)) {
      return;
    }

    int slot = event.getRawSlot();
    String title = event.getView().getTitle();

    if (HOME_GUI.equals(guiType) && slot == 22) {
      beginHomeNameInput(player);
      return;
    }

    switch (guiType) {
      case HOME_GUI -> handleHomeGuiClick(player, slot, title, event.getClick() == ClickType.RIGHT);
      case WARP_GUI -> handleWarpGuiClick(player, slot, title);
      case BALTOP_GUI -> handleBalTopGuiClick(player, slot, title);
      case TELEPORT_GUI -> handleTeleportGuiClick(player, slot);
    }
  }

  @EventHandler
  public void onInventoryClose(InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }

    UUID playerId = player.getUniqueId();
    Inventory closed = event.getInventory();
    if (openInventories.remove(playerId, closed)) {
      openGuis.remove(playerId);
    }
  }

  @EventHandler
  public void onHomeNameBookEdit(PlayerEditBookEvent event) {
    UUID playerId = event.getPlayer().getUniqueId();
    if (pendingHomeNames.remove(playerId) == null) return;
    event.setCancelled(true);
    BookInputSupport.restore(event.getPlayer());
    String name = String.join("\n", event.getNewBookMeta().getPages());
    org.bukkit.Bukkit.getScheduler()
        .runTask(
            plugin,
            () -> {
              String invalidReason = HomeService.invalidHomeNameReason(name).orElse(null);
              if (invalidReason != null) {
                event
                    .getPlayer()
                    .sendMessage(
                        Component.text("Invalid home name: " + invalidReason, NamedTextColor.RED));
                openHomeGui(event.getPlayer(), 1);
                return;
              }
              boolean saved = homeService.setHome(event.getPlayer(), name);
              event
                  .getPlayer()
                  .sendMessage(
                      Component.text(
                          saved ? "Home saved." : "Unable to save home.",
                          saved ? NamedTextColor.GREEN : NamedTextColor.RED));
              openHomeGui(event.getPlayer(), 1);
            });
  }

  // ==================== 家园 GUI 处理 ====================

  private void beginHomeNameInput(Player player) {
    pendingHomeNames.put(player.getUniqueId(), true);
    BookInputSupport.prepare(player, "Home name", "");
  }

  private void handleHomeGuiClick(Player player, int slot, String title, boolean secondaryClick) {
    HomeGui.HomeAction action = HomeGui.getActionFromSlot(slot);
    if (secondaryClick && action == HomeGui.HomeAction.TELEPORT_HOME) {
      action = HomeGui.HomeAction.DELETE_HOME;
    }

    switch (action) {
      case CLOSE -> player.closeInventory();
      case SET_HOME -> {
        pendingHomeNames.put(player.getUniqueId(), true);
        BookInputSupport.prepare(player, "Home name", "");
        return;
      }
      case PREV_PAGE -> {
        int page = extractPage(title);
        openHomeGui(player, page - 1);
      }
      case NEXT_PAGE -> {
        int page = extractPage(title);
        openHomeGui(player, page + 1);
      }
      case TELEPORT_HOME -> {
        String homeName = homeNameFromSlot(player, extractPage(title), slot);
        if (homeName != null) {
          player.closeInventory();
          teleportService.teleportToHome(player, homeName);
        }
      }
      case DELETE_HOME -> {
        int page = extractPage(title);
        String homeName = homeNameFromSlot(player, page, slot);
        if (homeName != null) {
          homeService.deleteHome(player, homeName);
          refreshHomeGui(player, page);
        }
      }
      default -> {}
    }
  }

  private String homeNameFromSlot(Player player, int page, int slot) {
    if (slot < HOME_FIRST_SLOT || slot > HOME_LAST_SLOT) {
      return null;
    }
    int index = (Math.max(1, page) - 1) * HOMES_PER_PAGE + slot - HOME_FIRST_SLOT;
    var homeNames = homeService.getHomeNames(player.getUniqueId());
    return index >= 0 && index < homeNames.size() ? homeNames.get(index) : null;
  }

  private void refreshHomeGui(Player player, int requestedPage) {
    int homeCount = homeService.getHomeNames(player.getUniqueId()).size();
    int totalPages = Math.max(1, (homeCount + 6) / 7);
    openHomeGui(player, Math.min(Math.max(1, requestedPage), totalPages));
  }

  // ==================== 传送点 GUI 处理 ====================

  private void handleWarpGuiClick(Player player, int slot, String title) {
    WarpGui.WarpAction action = WarpGui.getActionFromSlot(slot);

    switch (action) {
      case CLOSE -> player.closeInventory();
      case PREV_PAGE -> {
        int page = extractPage(title);
        openWarpGui(player, page - 1);
      }
      case NEXT_PAGE -> {
        int page = extractPage(title);
        openWarpGui(player, page + 1);
      }
      case TELEPORT_WARP -> {
        WarpGui gui = new WarpGui(player, warpService, teleportService, extractPage(title));
        String warpName = gui.getWarpNameFromSlot(slot);
        if (warpName != null) {
          player.closeInventory();
          teleportService.teleportToWarp(player, warpName);
        }
      }
      default -> {}
    }
  }

  // ==================== 财富排行榜 GUI 处理 ====================

  private void handleBalTopGuiClick(Player player, int slot, String title) {
    BalTopGui.BalTopAction action = BalTopGui.getActionFromSlot(slot);

    switch (action) {
      case CLOSE -> player.closeInventory();
      case REFRESH -> {
        int page = extractPage(title);
        // 刷新排行榜
        balTopService.updateRankings(economyService.getAllBalances());
        player.sendMessage(Component.text("排行榜已刷新", NamedTextColor.GREEN));
        openBalTopGui(player, page);
      }
      case PREV_PAGE -> {
        int page = extractPage(title);
        openBalTopGui(player, page - 1);
      }
      case NEXT_PAGE -> {
        int page = extractPage(title);
        openBalTopGui(player, page + 1);
      }
      case VIEW_PLAYER -> {
        BalTopGui gui = new BalTopGui(player, balTopService, economyService, extractPage(title));
        BalTopGui.BalTopAction currentAction = BalTopGui.getActionFromSlot(slot);
        if (currentAction == BalTopGui.BalTopAction.VIEW_PLAYER) {
          BalTopService.BalTopEntry entry = gui.getEntryFromSlot(slot);
          if (entry != null) {
            player.sendMessage(
                Component.text(
                    "玩家: " + player.getServer().getOfflinePlayer(entry.playerId()).getName(),
                    NamedTextColor.GOLD));
            player.sendMessage(
                Component.text(
                    "余额: " + String.format("%.2f", entry.balance().doubleValue()),
                    NamedTextColor.GREEN));
          }
        }
      }
      default -> {}
    }
  }

  // ==================== 综合传送 GUI 处理 ====================

  private void handleTeleportGuiClick(Player player, int slot) {
    TeleportGui.TeleportAction action = TeleportGui.getActionFromSlot(slot);

    switch (action) {
      case CLOSE -> player.closeInventory();
      case SPAWN -> {
        player.closeInventory();
        teleportService.teleportToSpawn(player);
      }
      case HOME_MENU -> {
        openHomeGui(player, 1);
      }
      case WARP_MENU -> {
        if (!teleportService.canUseWarp(player)) {
          player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
          return;
        }
        openWarpGui(player, 1);
      }
      case BACK -> {
        player.closeInventory();
        teleportService.teleportBack(player);
      }
      default -> {}
    }
  }

  // ==================== 辅助方法 ====================

  private int extractPage(String title) {
    // 从标题中提取页码，例如 "家园管理 (第2页)" -> 2
    try {
      int start = title.indexOf("(第");
      int end = title.indexOf("页)");
      if (start != -1 && end != -1) {
        String pageStr = title.substring(start + 2, end);
        return Integer.parseInt(pageStr.trim());
      }
    } catch (Exception e) {
      // 忽略
    }
    return 1;
  }

  public void openHomeGui(Player player, int page) {
    player.closeInventory();
    HomeGui gui = new HomeGui(player, homeService, teleportService, page);
    player.openInventory(gui.getInventory());
    openGuis.put(player.getUniqueId(), HOME_GUI);
    openInventories.put(player.getUniqueId(), gui.getInventory());
  }

  public void openWarpGui(Player player, int page) {
    if (!teleportService.canUseWarp(player)) {
      player.sendMessage(Component.text("你没有权限使用星港", NamedTextColor.RED));
      return;
    }
    player.closeInventory();
    WarpGui gui = new WarpGui(player, warpService, teleportService, page);
    player.openInventory(gui.getInventory());
    openGuis.put(player.getUniqueId(), WARP_GUI);
    openInventories.put(player.getUniqueId(), gui.getInventory());
  }

  public void openBalTopGui(Player player, int page) {
    player.closeInventory();
    BalTopGui gui = new BalTopGui(player, balTopService, economyService, page);
    player.openInventory(gui.getInventory());
    openGuis.put(player.getUniqueId(), BALTOP_GUI);
    openInventories.put(player.getUniqueId(), gui.getInventory());
  }

  public void openTeleporterGui(Player player) {
    player.closeInventory();
    TeleportGui gui = new TeleportGui(player, homeService, warpService, teleportService);
    player.openInventory(gui.getInventory());
    openGuis.put(player.getUniqueId(), TELEPORT_GUI);
    openInventories.put(player.getUniqueId(), gui.getInventory());
  }

  // E-039 修复: 玩家退出时清理 openGuis Map 状态
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    pendingHomeNames.remove(event.getPlayer().getUniqueId());
    BookInputSupport.clear(event.getPlayer());
    openGuis.remove(event.getPlayer().getUniqueId());
    openInventories.remove(event.getPlayer().getUniqueId());
  }

  private boolean ownsOpenInventory(Player player, Inventory inventory) {
    return player != null
        && inventory != null
        && openInventories.get(player.getUniqueId()) == inventory;
  }
}
