package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Properties;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

class FactoryCanonicalRecoveryTest {
  static Properties fixture(boolean v2) throws Exception {
    Properties p = FactorySnapshotVersionTest.legacy();
    if (v2)
      FactorySnapshotVersionTest.rewrite(
          p, FactorySnapshotVersionTest.restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    return p;
  }

  static Stream<Arguments> invalidFields() {
    return Stream.of(false, true)
        .flatMap(
            v2 ->
                Stream.of(
                        "extra-metadata",
                        "extra-binding",
                        "missing-binding",
                        "changed-binding",
                        "same-count-substitution",
                        "noncanonical-count",
                        "noncanonical-quantity",
                        "noncanonical-sequence")
                    .map(kind -> Arguments.of(v2, kind)));
  }

  @ParameterizedTest
  @MethodSource("invalidFields")
  void validFingerprintStillRequiresEveryCanonicalFieldAndNoExtras(boolean v2, String kind)
      throws Exception {
    var p = fixture(v2);
    String prefix = FactoryRunStore.PREFIX;
    String row = v2 ? FactoryRunStore.rowPrefix("batch-0") : prefix + "row.0.";
    String binding = prefix + "binding.00000000-0000-0000-0000-000000000002";
    switch (kind) {
      case "extra-metadata" -> p.setProperty(prefix + "metadata", "unexpected");
      case "extra-binding" ->
          p.setProperty(prefix + "binding.00000000-0000-0000-0000-000000000099", "legacy");
      case "missing-binding" -> assertNotNull(p.remove(binding));
      case "changed-binding" -> p.setProperty(binding, "legacy");
      case "same-count-substitution" -> {
        assertEquals("", p.remove(row + "actor"));
        p.setProperty(row + "unknown", "");
      }
      case "noncanonical-count" -> p.setProperty(prefix + "count", "04");
      case "noncanonical-quantity" -> p.setProperty(row + "inputs", "mineral=03");
      case "noncanonical-sequence" -> p.setProperty(row + "sequence", "01");
      default -> throw new AssertionError(kind);
    }
    FactorySnapshotVersionTest.rehash(p);
    var before = FactorySnapshotVersionTest.copy(p);
    assertThrows(
        IllegalStateException.class,
        () -> FactorySnapshotVersionTest.restore(p, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    assertEquals(before, p);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void inheritedPropertiesStillParticipateInExactValidationWithoutMutation(boolean v2)
      throws Exception {
    var original = fixture(v2);
    var expected =
        FactorySnapshotVersionTest.restore(original, FactoryReceiptValidationTest.SNAPSHOT_ONLY);
    var inherited = new Properties(original);
    // Schema presence has always required an explicit key; all other fields may be inherited.
    inherited.setProperty(
        FactoryRunStore.PREFIX + "version",
        original.getProperty(FactoryRunStore.PREFIX + "version"));
    assertEquals(
        expected,
        FactorySnapshotVersionTest.restore(inherited, FactoryReceiptValidationTest.SNAPSHOT_ONLY));
    assertEquals(1, inherited.size());
    assertEquals(original.stringPropertyNames(), inherited.stringPropertyNames());
    assertEquals(original, fixture(v2));
  }
}
