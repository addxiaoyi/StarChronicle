from pathlib import Path
import hashlib,json,shutil,sqlite3,subprocess,time
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/'run/market-escrow-processes-20261126';out.mkdir(exist_ok=False)
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin');jar=native/'target/starcore-1.0.0.jar'
libraries=sorted((root/'run/paper-epic-1faf2ba2-dungeon-phases-2/libraries').rglob('*.jar'))
cp=';'.join(str(p) for p in [jar,out]+libraries)
source=root/'run/MarketEscrowProbe.java';shutil.copy2(source,out/source.name)
def argfile(name,args):
 p=out/(name+'.args');p.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in args)+'\n');return p
args=argfile('compile',['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp,'-d',out,source])
p=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(args)],capture_output=True)
(out/'compile.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
results=[]
for phase in ['seed','match','cancel','verify','crash-seed','crash-refund','crash-verify','crash-verify']:
 label=f'{len(results)+1}-{phase}';folder=out/('interrupted' if phase.startswith('crash') else 'normal')
 args=argfile(label,['-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-Dfile.encoding=UTF-8','-cp',cp,'dev.starcore.starcore.module.resource.MarketEscrowProbe',folder,phase])
 start=time.monotonic();p=subprocess.run([str(java/'java.exe'),'@'+str(args)],capture_output=True)
 (out/(label+'.log')).write_bytes(p.stdout+p.stderr)
 assert p.returncode==(23 if phase=='crash-refund' else 0),(label,p.returncode)
 assert ('HALT_AFTER_REFUND_BEFORE_ACK' if phase=='crash-refund' else 'MARKET_ESCROW_OK '+phase) in p.stdout.decode(errors='replace')
 results.append({'phase':phase,'exit_code':p.returncode,'seconds':time.monotonic()-start})
facts={}
for label in ['normal','interrupted']:
 with sqlite3.connect((out/label/'orders.sqlite').resolve().as_uri()+'?mode=ro',uri=True) as db:
  assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
  facts[label]={'orders':db.execute('SELECT order_id,sequence,phase,payload FROM orders ORDER BY order_id').fetchall(),'events':db.execute('SELECT count(*) FROM events').fetchone()[0]}
assert {row[2] for row in facts['normal']['orders']}=={'CLOSED'}
assert {row[2] for row in facts['interrupted']['orders']}=={'CANCELLING'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary={'status':'VERIFIED','jar_sha256':sha(jar),'runs':results,'facts':facts,'files':{p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()},'scope':'Actual packaged service and SQLite/fabric/history with deterministic test-double external providers; no Minecraft server.'}
(out/'result.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k not in ('files','facts')}))
