from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/'run/native-market-escrow-artifacts-20261126';out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
jar=native/'target/starcore-1.0.0.jar';old=root/'run/market-escrow-baseline-20261126/starcore-1.0.0.jar'
types=['module/resource/MarketOrderBookService','module/resource/SimpleMarketOrderBookService',
 'module/resource/model/TradeOrder','module/resource/model/TradeOrder$OrderSnapshot',
 'module/resource/ResourceModule','module/resource/command/ResourceCommand',
 'module/resource/TradeHistoryService','module/resource/NationResourceTransactionService']
prefix='dev/starcore/starcore/';classes=native/'target/classes';checked={};apis={}
with zipfile.ZipFile(jar) as archive:
 for kind in types+['module/resource/MarketOrderJournal','module/resource/MarketOrderCodec','module/resource/model/MarketEscrowSnapshot']:
  parent,stem=(prefix+kind).rsplit('/',1)
  for p in (classes/parent).glob(stem+'*.class'):
   name=p.relative_to(classes).as_posix();raw=p.read_bytes()
   assert raw==archive.read(name) and int.from_bytes(raw[6:8],'big')==65
   checked[name]=sha(raw)
sources={};frozen=root/'run/native-market-escrow-test-validated-20261126/source'
for p in frozen.rglob('*.java'):
 name=p.relative_to(frozen).as_posix();assert p.read_bytes()==(native/name).read_bytes(),name;sources[name]=sha(p.read_bytes())
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
for kind in types:
 methods=[]
 for label,artifact in [('old',old),('current',jar)]:
  result=subprocess.run([str(java/'javap.exe'),'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),(prefix+kind).replace('/','.')],capture_output=True,check=True)
  (out/(label+'-'+kind.rsplit('/',1)[-1]+'.txt')).write_bytes(result.stdout)
  methods.append(set(re.findall(r'  (public [^\n]+;)\r?\n    descriptor: ([^\r\n]+)',result.stdout.decode().replace('synchronized ',''))))
 assert methods[0] and methods[0]<=methods[1],(kind,methods[0]-methods[1])
 apis[kind]={'preserved':len(methods[0]),'added':[list(v) for v in sorted(methods[1]-methods[0])]}
sbom=native/'target/starcore-1.0.0-sbom.json'
summary={'status':'VERIFIED','starcore_sha256':sha(jar.read_bytes()),'old_sha256':sha(old.read_bytes()),'class_hashes':checked,'api':apis,'source_hashes':sources,'sbom_sha256':sha(sbom.read_bytes()),'sbom_components':len(json.loads(sbom.read_text())['components'])}
(out/'result.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ('class_hashes','source_hashes')}))
