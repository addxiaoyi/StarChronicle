from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
folders=['native-market-escrow-test-validated-20261126']+[f'native-market-escrow-test-resource-{i}-20261126' for i in range(1,5)]
totals={k:0 for k in ('tests','failures','errors','skipped')};suites={}
for folder in folders:
 result=json.loads((root/'run'/folder/'result.json').read_text());assert result['exit_code']==0
 for p in (root/'run'/folder/'surefire').glob('TEST-*.xml'):
  suite=ET.parse(p).getroot();name=suite.attrib['name'];assert name not in suites,name
  counts={key:int(suite.attrib.get(key,0)) for key in totals};suites[name]=counts
  for key in totals:totals[key]+=counts[key]
assert totals=={'tests':1384,'failures':0,'errors':0,'skipped':0}
artifacts=json.loads((root/'run/native-market-escrow-artifacts-20261126/result.json').read_text())
processes=json.loads((root/'run/market-escrow-processes-20261126/result.json').read_text())
unchanged=json.loads((root/'run/market-escrow-chronicle-unchanged.json').read_text())
assert artifacts['starcore_sha256']==processes['jar_sha256']
summary={'status':'VERIFIED','totals':totals,'suites':suites,'new_tests':43,'artifacts':artifacts,'process_probe':processes,'chronicle':unchanged,
 'scope':['1384 tests in the resource tree and resource role matrix, not the complete StarCore suite.',
 'Eight serial actual-JAR JVM processes with durable deterministic test-double external assets; one intentional Runtime.halt(23), no Minecraft server.',
 'Uncertain reservation, refund and match results remain quarantined. Administrative inspection is read-only; evidence-based resolution is still pending.',
 'The old order book had no durable open orders to import. Pre-upgrade lost escrows cannot be inferred; stop/refund on the old version before deployment.',
 'Backup escrow SQLite/fence, national inventory, trade history, transaction fabric and economy as one stopped/consistent set. Domain checks cannot detect an arbitrary coordinated rollback.',
 'Old JARs do not understand the new escrow journal; do not downgrade with outstanding or unresolved orders.',
 'Closed records/events remain on disk; live filled-order and rate-tracker capacity, all resource/economy provider guarantees and full Folia combinations remain work.'],
 'retained_failures':['test-recovery: 3 failures + 6 errors from Mockito restubbing callbacks and a corruption injector that changed no bytes; corrected fixtures.',
 'test-final: 1 error from a new precision fixture below the existing minimum total; corrected legal terms without relaxing production validation.']}
files={}
for folder in sorted((root/'run').glob('native-market-escrow-*-20261126'))+[root/'run/market-escrow-processes-20261126']:
 for p in folder.rglob('*'):
  if p.is_file() and p.suffix not in ('.jar','.class'):files['run/'+p.relative_to(root/'run').as_posix()]=p
for name in ['run-native-market-escrow.py','verify-native-market-escrow-artifacts.py','MarketEscrowProbe.java','verify-market-escrow-processes.py','finalize-market-escrow.py','market-escrow-chronicle-unchanged.json','market-escrow-test-groups.json']:
 files['scripts/'+name]=root/'run'/name
files['native-sbom.json']=native/'target/starcore-1.0.0-sbom.json'
files['previous-chronicle-ci.json']=root/'run/capital-capacity-ci-20261126.json'
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=native)
archive=root/'docs/verification/market-escrow-source-20261126-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
 z.writestr('tracked-source.patch',patch)
 inventory={name:sha(z.read(name)) for name in z.namelist()}
 z.writestr('evidence-manifest.json',json.dumps(inventory,indent=2))
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(inventory)|{'evidence-manifest.json'}
 for name,digest in inventory.items():assert sha(z.read(name))==digest,name
summary['evidence']={'members':len(inventory)+1,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
(root/'docs/verification/market-escrow-source-20261126-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
core=artifacts['starcore_sha256'];evidence=summary['evidence']['sha256'];members=summary['evidence']['members']
report=f'''# 市场订单与托管恢复源码检查点

市场未成交订单、剩余托管余额和待核对标记此前只在内存，重启会丢失。现在下单、取消和撮合均先保存固定操作凭据；正常订单恢复原ID、创建时间、到期时间、成交均价、数量与精确余额，未知结果冻结并保留证据。**72套件／1,384项相关测试通过，新增43项**。本轮未启动Minecraft，十阶段尚未全部完成。

## 提交与恢复边界

`resource/market-orders.sqlite` 使用独立SQLite事务、FULL同步、2MiB页缓存和磁盘临时存储。`.authority`保存版本与独立域，数据库绑定贸易域及原生资源域；已有库缺标记、READY缺库、错域、未知版本、事件缺行或当前索引损坏拒绝空重置。INITIALIZING只允许恢复空账本。每次更新比较原完整快照，拒绝旧实例重复取消或撮合。

资产调用前保存RESERVING／CANCELLING；双方MATCHING在同一事务保存。返回false或抛异常不被解释为“未变更资产”。重启只恢复OPEN进入价格簿；其他在途状态保留原凭据并隔离，取消、过期、停服和撮合均不会自动再次操作资产。成交提交后，双方新数量／余额同事务保存；保存失败仍保留MATCHING，已COMMITTED成交不会降成待退款或重放。完成快照必须匹配冻结计划。

原生资源预留、返还、交付和交付补偿改用稳定 `market:<operation>:<step>` 资源事务，精确数量不经过生产加成。外部布尔资源接口保留兼容，但未知结果只隔离。买方按原剩余托管分配成交预留，最后一笔释放小数余量；费用上涨超过预留时不成交。当前可变订单数量被改写时拒绝取消；已有到期时间setter保留。

玩家列表／下单／取消显示待核对和完整ID。管理员或控制台可只读运行 `/resource order review`、`/resource order review <完整UUID>`、`/resource order review after:<上一页末尾UUID>`，每页20条，服务API最多128条。权限为 `starcore.resource.admin`。证据中的余额是原操作前记录，不能单凭该数值断言外部资产现状。尚未提供无证据的解冻／退款命令。

## 验证

- 资源目录与资源权限矩阵1,384项全通过，零失败／错误／跳过；不是StarCore全库回归。43项新增覆盖正常与部分成交重启、未知扣款和退款、持久化失败、双订单原子性、旧实例、真实原生资源回执、133条核对分页、标记／域／索引损坏以及只读权限。
- 首次95项测试有9项夹具失败（重复Mockito配置执行旧回调／损坏注入未命中字节）；随后111项有1项精度样本低于现有交易最小金额。均保留原XML／日志；修正测试输入后111项和四批1,273项全部通过。
- Spotless、编译、skip-tests verify、36组件SBOM通过。8类原公开API共177个成员descriptor保留，关键类字节与最终JAR一致。旧公开构造器仍存在，但资产操作要求先配置订单存储；ResourceModule在库存恢复后接线。
- 最终JAR的8个独立串行JVM（128MiB）通过：正常seed→match→cancel→reopen保留原创建时间，买10卖4后只付卖家28、交付4，最后买家969.2。扣款／扣资源各1次，交付1次，存款3次。另一个场景退款成功后 `Runtime.halt(23)`，后续两次重开均保留CANCELLING且存款计数仍为1。资产提供者是独立持久测试替身，不是实际经济插件或实服。
- StarCore JAR SHA `{core}`。Chronicle271份源码／资源／测试与 `b30743d` 一致，JAR仍 `{unchanged['jar_sha256']}`；沿用1,123项本地完整clean verify及[CI #211](https://github.com/addxiaoyi/StarChronicle/actions/runs/45784421331)，未伪称本轮重跑。

## 证据与后续

[摘要](verification/market-escrow-source-20261126-summary.json)和[证据ZIP](verification/market-escrow-source-20261126-evidence.zip)包含{members}成员，SHA `{evidence}`。实际测试XML、失败及成功日志、源快照、构建、API／字节码、SBOM、进程探针及小型SQLite／资产副本逐SHA核验。

升级前旧内存订单没有持久来源，不能据余额反推；应在旧版本正常退款停服后升级。备份／恢复须在停服或一致快照下同时保存订单库及标记、库存、贸易历史、事务fabric和经济余额。域检查不代表能识别任意协调回退。旧JAR不理解新市场账本，有未结或待核对订单时不得降级运行。

未知外部经济结果的有证据核对／处置、订单与限速缓存长期容量、其他owner／生命周期、全栈Paper／Folia组合继续待办。新发现上游资源历史 `3da33a0`／`110f8e8` 待下一检查点兼容合并，本检查点基于StarCore `1b4927d`／Chronicle `db04f92`。未合并主分支或部署生产。
'''
(root/'docs/MARKET-ESCROW-SOURCE-20261126.md').write_text(report,encoding='utf-8')
intro='2026-11-26 当前源码检查点：[市场订单与托管恢复]({link})。**1,384项相关测试／新增43项通过**；订单与精确余额持久化，未知扣款／退款／撮合结果重启仍隔离，管理员只读分页核对。实际JAR八个独立JVM含退款后强制退出验证通过。Chronicle产品保持1,123项检查点，未启动Minecraft；下一步合入新资源历史增量。'
for name in ['README.md','docs/HANDOFF-2026-11-26.md','docs/REMAINING-WORK.md']:
 p=root/name;head,rest=p.read_text(encoding='utf-8').split('\n',1)
 p.write_text(head+'\n\n'+intro.format(link=('docs/' if name=='README.md' else '')+'MARKET-ESCROW-SOURCE-20261126.md')+'\n'+rest,encoding='utf-8')
(native/'docs/MARKET-ESCROW-SOURCE-2026-11-26.md').write_text(report.replace('(verification/', '(https://github.com/addxiaoyi/StarChronicle/blob/codex/plugin-all-stages-20261125/docs/verification/'),encoding='utf-8')
print(json.dumps({'tests':totals,'suites':len(suites),'core':core,'evidence':summary['evidence']},ensure_ascii=False))
