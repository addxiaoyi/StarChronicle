package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.persistence.AtomicFilePersistence;
import dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot;
import dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot.Phase;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Local transactional escrow authority. Claims precede external effects; an interrupted claim is
 * evidence, never permission to repeat an effect. Keep the database and .authority fence together.
 * A pair of match claims/completions is always committed in one SQLite transaction.
 */
final class MarketOrderJournal {
  private static final String FORMAT = "STARCORE_MARKET_ESCROW_V1";
  private static final Object BOOTSTRAP_LOCK = new Object();
  private final Path database;
  private final Path marker;
  private final UUID tradeDomain;
  private final String resourceDomain;
  private UUID domain;
  private long observedSequence;

  MarketOrderJournal(Path database, UUID tradeDomain, String resourceDomain) {
    this.database = Objects.requireNonNull(database).toAbsolutePath().normalize();
    this.marker = this.database.resolveSibling(this.database.getFileName() + ".authority");
    this.tradeDomain = Objects.requireNonNull(tradeDomain);
    this.resourceDomain = Objects.requireNonNull(resourceDomain);
    if (resourceDomain.isBlank()) throw new IllegalStateException("Resource authority unavailable");
    try {
      Files.createDirectories(this.database.getParent());
      synchronized (BOOTSTRAP_LOCK) {
        try (var channel =
                FileChannel.open(
                    marker.resolveSibling(marker.getFileName() + ".lock"),
                    StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE);
            var ignored = channel.lock()) {
          initialize();
        }
      }
    } catch (IOException failure) {
      throw new IllegalStateException("Cannot initialize market escrow authority", failure);
    }
  }

  synchronized MarketEscrowSnapshot reserve(TradeOrder order, BigDecimal money) {
    if (order.status() != TradeOrder.OrderStatus.PENDING || order.filledAmount() != 0)
      throw new IllegalArgumentException("Reservation requires a new order");
    return transaction(
        connection ->
            append(
                connection,
                null,
                order.toSnapshot(),
                money,
                Phase.RESERVING,
                order.orderId(),
                "reserve " + (order.isBuyOrder() ? "money" : "resources")));
  }

  synchronized MarketEscrowSnapshot open(MarketEscrowSnapshot reservation) {
    requirePhase(reservation, Phase.RESERVING);
    return transaction(
        connection ->
            append(
                connection,
                reservation,
                reservation.order(),
                reservation.moneyRemaining(),
                Phase.OPEN,
                reservation.operationId(),
                "reservation confirmed"));
  }

  synchronized MarketEscrowSnapshot claimCancellation(
      MarketEscrowSnapshot expected, TradeOrder order) {
    requirePhase(expected, Phase.OPEN);
    MarketOrderCodec.requireSameAssets(expected.order(), order.toSnapshot());
    return transaction(
        connection ->
            append(
                connection,
                expected,
                order.toSnapshot(),
                expected.moneyRemaining(),
                Phase.CANCELLING,
                order.orderId(),
                "return remaining escrow"));
  }

  synchronized MarketEscrowSnapshot cancelled(MarketEscrowSnapshot claim) {
    requirePhase(claim, Phase.CANCELLING);
    TradeOrder cancelled = TradeOrder.restore(claim.order());
    cancelled.cancel();
    return transaction(
        connection ->
            append(
                connection,
                claim,
                cancelled.toSnapshot(),
                BigDecimal.ZERO,
                Phase.CLOSED,
                claim.operationId(),
                "escrow return confirmed"));
  }

  synchronized List<MarketEscrowSnapshot> claimMatch(
      MarketEscrowSnapshot buy,
      MarketEscrowSnapshot sell,
      TradeOrder buyOrder,
      TradeOrder sellOrder,
      UUID operation,
      String detail) {
    requirePhase(buy, Phase.OPEN);
    requirePhase(sell, Phase.OPEN);
    MarketOrderCodec.requireSameAssets(buy.order(), buyOrder.toSnapshot());
    MarketOrderCodec.requireSameAssets(sell.order(), sellOrder.toSnapshot());
    if (!buyOrder.isBuyOrder()
        || !sellOrder.isSellOrder()
        || !buyOrder.resourceId().equals(sellOrder.resourceId()))
      throw new IllegalArgumentException("Invalid order pair");
    return transaction(
        connection ->
            List.of(
                append(
                    connection,
                    buy,
                    buyOrder.toSnapshot(),
                    buy.moneyRemaining(),
                    Phase.MATCHING,
                    operation,
                    detail),
                append(
                    connection,
                    sell,
                    sellOrder.toSnapshot(),
                    BigDecimal.ZERO,
                    Phase.MATCHING,
                    operation,
                    detail)));
  }

  synchronized List<MarketEscrowSnapshot> matched(
      List<MarketEscrowSnapshot> claims, TradeOrder buy, BigDecimal money, TradeOrder sell) {
    if (claims.size() != 2) throw new IllegalArgumentException("A match needs two claims");
    claims.forEach(claim -> requirePhase(claim, Phase.MATCHING));
    if (!claims.get(0).operationId().equals(claims.get(1).operationId()))
      throw new IllegalStateException("Match operation changed");
    return transaction(
        connection ->
            List.of(
                append(
                    connection,
                    claims.get(0),
                    buy.toSnapshot(),
                    money,
                    buy.remainingAmount() == 0 ? Phase.CLOSED : Phase.OPEN,
                    claims.get(0).operationId(),
                    "match committed"),
                append(
                    connection,
                    claims.get(1),
                    sell.toSnapshot(),
                    BigDecimal.ZERO,
                    sell.remainingAmount() == 0 ? Phase.CLOSED : Phase.OPEN,
                    claims.get(1).operationId(),
                    "match committed")));
  }

  synchronized Optional<MarketEscrowSnapshot> find(UUID id) {
    return transaction(connection -> find(connection, id));
  }

  synchronized List<MarketEscrowSnapshot> activeAfter(UUID after, int limit, boolean reviewsOnly) {
    if (limit < 1 || limit > 128) throw new IllegalArgumentException("limit must be 1..128");
    return transaction(
        connection -> {
          String predicate = reviewsOnly ? "phase NOT IN ('OPEN','CLOSED')" : "phase <> 'CLOSED'";
          try (var query =
              connection.prepareStatement(
                  "SELECT * FROM orders WHERE order_id > ? AND "
                      + predicate
                      + " ORDER BY order_id LIMIT ?")) {
            query.setString(1, after == null ? "" : after.toString());
            query.setInt(2, limit);
            List<MarketEscrowSnapshot> result = new ArrayList<>();
            try (var rows = query.executeQuery()) {
              while (rows.next()) result.add(decode(rows));
            }
            return List.copyOf(result);
          }
        });
  }

  private MarketEscrowSnapshot append(
      Connection connection,
      MarketEscrowSnapshot expected,
      TradeOrder.OrderSnapshot order,
      BigDecimal money,
      Phase phase,
      UUID operation,
      String detail)
      throws SQLException {
    var current = find(connection, order.orderId()).orElse(null);
    if (!Objects.equals(current, expected))
      throw new IllegalStateException("Market escrow changed; reload its original evidence");
    if (expected != null && !expected.order().orderId().equals(order.orderId()))
      throw new IllegalStateException("Market order identity changed");
    ResourceTradeTerms.Validation terms =
        ResourceTradeTerms.validateOrder(
            order.resourceId(), order.totalAmount(), order.pricePerUnit());
    if (!terms.isValid() || !terms.terms().resourceId().equals(order.resourceId()))
      throw new IllegalArgumentException("Invalid durable market terms");
    long sequence = Math.addExact(head(connection), 1);
    var next =
        new MarketEscrowSnapshot(order, money, phase, operation, detail, Instant.now(), sequence);
    String payload = MarketOrderCodec.encode(next);
    try (var insert = connection.prepareStatement("INSERT INTO events VALUES (?, ?, ?)")) {
      insert.setLong(1, sequence);
      insert.setString(2, order.orderId().toString());
      insert.setString(3, payload);
      insert.executeUpdate();
    }
    String sql =
        expected == null
            ? "INSERT INTO orders (sequence,phase,payload,order_id) VALUES (?,?,?,?)"
            : "UPDATE orders SET sequence=?, phase=?, payload=? WHERE order_id=? AND sequence=?";
    try (var update = connection.prepareStatement(sql)) {
      update.setLong(1, sequence);
      update.setString(2, phase.name());
      update.setString(3, payload);
      update.setString(4, order.orderId().toString());
      if (expected != null) update.setLong(5, expected.revision());
      if (update.executeUpdate() != 1) throw new SQLException("Escrow claim failed");
    }
    try (var update = connection.prepareStatement("UPDATE authority SET sequence=? WHERE id=1")) {
      update.setLong(1, sequence);
      if (update.executeUpdate() != 1) throw new SQLException("Escrow head missing");
    }
    return next;
  }

  private Optional<MarketEscrowSnapshot> find(Connection connection, UUID id) throws SQLException {
    try (var query = connection.prepareStatement("SELECT * FROM orders WHERE order_id=?")) {
      query.setString(1, id.toString());
      try (var rows = query.executeQuery()) {
        return rows.next() ? Optional.of(decode(rows)) : Optional.empty();
      }
    }
  }

  private MarketEscrowSnapshot decode(ResultSet row) throws SQLException {
    var entry = MarketOrderCodec.decode(row.getString("payload"));
    if (!entry.order().orderId().toString().equals(row.getString("order_id"))
        || entry.revision() != row.getLong("sequence")
        || !entry.phase().name().equals(row.getString("phase")))
      throw new IllegalStateException("Market escrow index disagrees with its payload");
    return entry;
  }

  private void initialize() throws IOException {
    boolean markerExists = Files.exists(marker, LinkOption.NOFOLLOW_LINKS);
    if (!markerExists) {
      if (Files.exists(database, LinkOption.NOFOLLOW_LINKS))
        throw new IllegalStateException("Market escrow fence missing; restore matching backups");
      domain = UUID.randomUUID();
      writeMarker("INITIALIZING");
    }
    String content = readMarker();
    String[] parts = content.split("\n");
    if (parts.length != 3 || !FORMAT.equals(parts[0]))
      throw new IllegalStateException("Invalid market escrow fence");
    domain = UUID.fromString(parts[1]);
    if (parts[2].equals("INITIALIZING")) {
      try (Connection connection = connect(true)) {
        connection.setAutoCommit(false);
        try (var query = connection.createStatement();
            var rows =
                query.executeQuery("SELECT count(*) FROM sqlite_master WHERE type='table'")) {
          if (rows.next() && rows.getLong(1) == 0) createSchema(connection);
        }
        if (head(connection) != 0)
          throw new IllegalStateException("Unfinished escrow initialization has entries");
        verifyIndexes(connection);
        connection.commit();
      } catch (SQLException failure) {
        throw new IllegalStateException("Cannot create market escrow database", failure);
      }
      writeMarker("READY");
    } else if (!parts[2].equals("READY")) {
      throw new IllegalStateException("Unsupported market escrow fence state");
    }
    transaction(
        connection -> {
          verifyIndexes(connection);
          return null;
        });
  }

  private void createSchema(Connection connection) throws SQLException {
    try (var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE authority (id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL,"
              + " domain TEXT NOT NULL, trade_domain TEXT NOT NULL, resource_domain TEXT NOT NULL,"
              + " sequence INTEGER NOT NULL CHECK(sequence>=0))");
      statement.execute(
          "CREATE TABLE orders (order_id TEXT PRIMARY KEY, sequence INTEGER NOT NULL UNIQUE, phase"
              + " TEXT NOT NULL CHECK(phase IN"
              + " ('RESERVING','OPEN','CANCELLING','MATCHING','CLOSED')), payload TEXT NOT NULL)");
      statement.execute(
          "CREATE TABLE events (sequence INTEGER PRIMARY KEY, order_id TEXT NOT NULL, payload TEXT"
              + " NOT NULL)");
      statement.execute("CREATE INDEX events_order ON events(order_id, sequence)");
      statement.execute("CREATE INDEX orders_phase ON orders(phase, order_id)");
    }
    try (var insert = connection.prepareStatement("INSERT INTO authority VALUES (1,1,?,?,?,0)")) {
      insert.setString(1, domain.toString());
      insert.setString(2, tradeDomain.toString());
      insert.setString(3, resourceDomain);
      insert.executeUpdate();
    }
  }

  private void verifyIndexes(Connection connection) throws SQLException {
    long sequence = head(connection);
    try (var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT count(*), coalesce(max(sequence),0), coalesce(min(sequence),1) FROM"
                    + " events")) {
      if (!rows.next()
          || rows.getLong(1) != sequence
          || rows.getLong(2) != sequence
          || rows.getLong(3) != 1)
        throw new IllegalStateException("Market escrow history is incomplete");
    }
    try (var statement = connection.createStatement();
        var rows =
            statement.executeQuery(
                "SELECT 1 FROM orders o LEFT JOIN events e ON o.sequence=e.sequence WHERE"
                    + " e.sequence IS NULL OR o.order_id<>e.order_id OR o.payload<>e.payload OR"
                    + " o.sequence<>(SELECT max(sequence) FROM events WHERE order_id=o.order_id)"
                    + " UNION ALL SELECT 1 FROM events e LEFT JOIN orders o ON"
                    + " e.order_id=o.order_id WHERE o.order_id IS NULL LIMIT 1")) {
      if (rows.next()) throw new IllegalStateException("Market escrow current state is incomplete");
    }
    // Stream validation; closed history is retained on disk and never loaded into the order book.
    try (var statement = connection.createStatement();
        var rows = statement.executeQuery("SELECT * FROM orders")) {
      while (rows.next()) decode(rows);
    }
  }

  private long head(Connection connection) throws SQLException {
    try (var statement = connection.createStatement();
        var row = statement.executeQuery("SELECT * FROM authority WHERE id=1")) {
      if (!row.next()
          || row.getInt("version") != 1
          || !domain.toString().equals(row.getString("domain"))
          || !tradeDomain.toString().equals(row.getString("trade_domain"))
          || !resourceDomain.equals(row.getString("resource_domain"))
          || row.getLong("sequence") < observedSequence)
        throw new IllegalStateException(
            "Market escrow authority changed; restore matching backups");
      return row.getLong("sequence");
    }
  }

  private <T> T transaction(SqlWork<T> work) {
    try {
      if (!readMarker().equals(markerText("READY")))
        throw new IllegalStateException("Market escrow fence changed");
      try (Connection connection = connect(false)) {
        connection.setAutoCommit(false);
        try {
          head(connection);
          T result = work.run(connection);
          long sequence = head(connection);
          connection.commit();
          observedSequence = sequence;
          return result;
        } catch (SQLException | RuntimeException failure) {
          try {
            connection.rollback();
          } catch (SQLException rollback) {
            failure.addSuppressed(rollback);
          }
          throw failure;
        }
      }
    } catch (IOException | SQLException failure) {
      throw new IllegalStateException("Market escrow storage unavailable", failure);
    }
  }

  private Connection connect(boolean initializing) throws SQLException {
    if (!initializing && !Files.isRegularFile(database, LinkOption.NOFOLLOW_LINKS))
      throw new IllegalStateException("Market escrow database missing; refusing an empty reset");
    Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
    try (var statement = connection.createStatement()) {
      statement.execute("PRAGMA busy_timeout=5000");
      statement.execute("PRAGMA synchronous=FULL");
      statement.execute("PRAGMA cache_size=-2048");
      statement.execute("PRAGMA temp_store=FILE");
      return connection;
    } catch (SQLException failure) {
      connection.close();
      throw failure;
    }
  }

  private String readMarker() throws IOException {
    if (!Files.isRegularFile(marker, LinkOption.NOFOLLOW_LINKS) || Files.size(marker) > 256)
      throw new IllegalStateException("Market escrow authority fence unavailable");
    return Files.readString(marker);
  }

  private String markerText(String state) {
    return FORMAT + "\n" + domain + "\n" + state + "\n";
  }

  private void writeMarker(String state) throws IOException {
    AtomicFilePersistence.replace(marker, path -> Files.writeString(path, markerText(state)));
  }

  private static void requirePhase(MarketEscrowSnapshot entry, Phase phase) {
    if (entry == null || entry.phase() != phase)
      throw new IllegalStateException("Unexpected market escrow phase");
  }

  @FunctionalInterface
  private interface SqlWork<T> {
    T run(Connection connection) throws SQLException;
  }
}
