package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.nio.file.*;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;

/** Actual packaged service/storage; deterministic providers are isolated test doubles, no server. */
public class MarketEscrowProbe {
  static final UUID BUYER=new UUID(1,1), SELLER=new UUID(1,2);
  static final NationId BUY_NATION=NationId.of(new UUID(2,1)), SELL_NATION=NationId.of(new UUID(2,2));
  static Properties state;
  static Path folder;
  static String phase;
  public static void main(String[] args) throws Exception {
    folder=Path.of(args[0]);phase=args[1];Files.createDirectories(folder);
    state=new Properties();
    if(Files.exists(folder.resolve("assets.properties")))try(var in=Files.newInputStream(folder.resolve("assets.properties"))){state.load(in);}
    state.putIfAbsent("money."+BUYER,"1000");state.putIfAbsent("money."+SELLER,"0");
    state.putIfAbsent("resource."+BUY_NATION,"0");state.putIfAbsent("resource."+SELL_NATION,"100");
    EconomyService economy=proxy(EconomyService.class,(method,a)->switch(method){
      case "has" -> money((UUID)a[0]).compareTo((BigDecimal)a[1])>=0;
      case "getBalance" -> money((UUID)a[0]);
      case "withdraw","deposit" -> {
        UUID id=(UUID)a[0];BigDecimal amount=(BigDecimal)a[1];
        state.setProperty("money."+id,(method.equals("withdraw")?money(id).subtract(amount):money(id).add(amount)).toPlainString());
        bump(method);save();
        if(phase.equals("crash-refund")&&method.equals("deposit")){
          System.out.println("HALT_AFTER_REFUND_BEFORE_ACK");System.out.flush();Runtime.getRuntime().halt(23);
        }
        yield true;
      }
      default -> throw new AssertionError(method);
    });
    ResourceService resources=proxy(ResourceService.class,(method,a)->switch(method){
      case "amount" -> quantity((NationId)a[0]);
      case "consume","grant" -> {
        NationId id=(NationId)a[0];long amount=(Long)a[2];
        state.setProperty("resource."+id,Long.toString(quantity(id)+(method.equals("grant")?amount:-amount)));
        bump(method);save();yield true;
      }
      default -> throw new AssertionError(method);
    });
    TradeTaxService taxes=proxy(TradeTaxService.class,(method,a)->switch(method){
      case "calculateTaxBD" -> ((BigDecimal)a[1]).multiply(new BigDecimal("0.10"));
      case "fundTax" -> ((TradeTaxService.TaxReceipt)a[0]).amount();
      default -> throw new AssertionError(method);
    });
    var database=new DatabaseService(null,null){
      @Override public Connection getConnection(){try{return DriverManager.getConnection("jdbc:sqlite:"+folder.resolve("trades.sqlite"));}catch(SQLException e){throw new IllegalStateException(e);}}
    };
    var history=new SimpleTradeHistoryService(database,null);
    var market=new SimpleMarketOrderBookService(resources,economy,taxes);
    market.setTradeHistoryService(history);market.setTransactionFabric(new TransactionFabric(folder.resolve("fabric.properties"),Logger.getAnonymousLogger()));
    market.initializeOrderStorage(folder.resolve("orders.sqlite"));
    switch(phase){
      case "seed" -> {
        market.submitBuyOrder(BUYER,BUY_NATION,"iron",10,8,Instant.parse("2030-01-01T00:00:00.123456789Z"));
        market.submitSellOrder(SELLER,SELL_NATION,"iron",4,7,Instant.parse("2030-01-01T00:00:00.123456789Z"));
        var order=market.getPlayerOrders(BUYER).getFirst();
        state.setProperty("order",order.orderId().toString());state.setProperty("created",order.createdAt().toString());save();
        check(money(BUYER).compareTo(new BigDecimal("912"))==0,"seed escrow");
      }
      case "match" -> {
        check(market.getOrder(UUID.fromString(state.getProperty("order"))).orElseThrow().createdAt().toString().equals(state.getProperty("created")),"time priority");
        check(market.matchOrders("iron")==1,"one match");check(quantity(BUY_NATION)==4,"one grant");
        check(history.tradeChangesAfter(0,128).size()==1,"one history");
      }
      case "cancel" -> {
        check(market.matchOrders("iron")==0,"no replay");check(market.refundOpenOrders()==1,"partial refund");
        check(money(BUYER).compareTo(new BigDecimal("969.2"))==0,"exact balance");
        check(money(SELLER).compareTo(new BigDecimal("28"))==0,"seller payout");
      }
      case "verify" -> {
        check(market.refundOpenOrders()==0&&market.matchOrders("iron")==0,"terminal reopen");
        check(state.getProperty("calls.withdraw").equals("1")&&state.getProperty("calls.consume").equals("1")&&state.getProperty("calls.grant").equals("1")&&state.getProperty("calls.deposit").equals("3"),"exact provider calls");
      }
      case "crash-seed" -> {
        market.submitBuyOrder(BUYER,BUY_NATION,"iron",5,8,Instant.parse("2030-01-01T00:00:00Z"));
        state.setProperty("order",market.getPlayerOrders(BUYER).getFirst().orderId().toString());save();
      }
      case "crash-refund" -> {market.cancelOrder(BUYER,UUID.fromString(state.getProperty("order")));throw new AssertionError("halt not reached");}
      case "crash-verify" -> {
        check(market.requiresReconciliation(UUID.fromString(state.getProperty("order"))),"durable review");
        check(market.refundOpenOrders()==0&&market.matchOrders("iron")==0,"no second effect");
        check(state.getProperty("calls.deposit").equals("1"),"one refund");check(money(BUYER).compareTo(new BigDecimal("1000"))==0,"no minted money");
      }
      default -> throw new AssertionError(phase);
    }
    System.out.println("MARKET_ESCROW_OK "+phase);
  }
  static void check(boolean okay,String message){if(!okay)throw new AssertionError(message);}
  static BigDecimal money(UUID id){return new BigDecimal(state.getProperty("money."+id,"0"));}
  static long quantity(NationId id){return Long.parseLong(state.getProperty("resource."+id,"0"));}
  static void bump(String method){String key="calls."+method;state.setProperty(key,Integer.toString(Integer.parseInt(state.getProperty(key,"0"))+1));}
  static void save(){try(var out=Files.newOutputStream(folder.resolve("assets.properties"))){state.store(out,"test-double external asset ledger");}catch(Exception e){throw new IllegalStateException(e);}}
  interface Handler{Object run(String method,Object[] args)throws Throwable;}
  static <T>T proxy(Class<T> type,Handler handler){return type.cast(Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},(p,m,a)->handler.run(m.getName(),a)));}
}
