package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot.Phase;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MarketOrderPersistenceTest {
  @TempDir Path directory;
  final UUID buyer = UUID.randomUUID();
  final UUID seller = UUID.randomUUID();
  final NationId buyerNation = NationId.random();
  final NationId sellerNation = NationId.random();
  final Map<UUID, BigDecimal> balances = new HashMap<>();
  final Map<NationId, Long> inventory = new HashMap<>();
  EconomyService economy;
  ResourceService resources;
  TradeTaxService taxes;
  final AtomicInteger withdrawals = new AtomicInteger();
  final AtomicInteger deposits = new AtomicInteger();
  final AtomicInteger consumes = new AtomicInteger();
  final AtomicInteger grants = new AtomicInteger();

  @BeforeEach
  void providers() {
    balances.put(buyer, new BigDecimal("1000.00"));
    balances.put(seller, BigDecimal.ZERO);
    inventory.put(sellerNation, 100L);
    inventory.put(buyerNation, 0L);
    economy = mock(EconomyService.class);
    resources = mock(ResourceService.class);
    taxes = mock(TradeTaxService.class);
    when(economy.has(any(), any()))
        .thenAnswer(inv -> balance(inv.getArgument(0)).compareTo(inv.getArgument(1)) >= 0);
    when(economy.withdraw(any(), any()))
        .thenAnswer(
            inv -> {
              UUID id = inv.getArgument(0);
              BigDecimal amount = inv.getArgument(1);
              withdrawals.incrementAndGet();
              if (balance(id).compareTo(amount) < 0) return false;
              balances.put(id, balance(id).subtract(amount));
              return true;
            });
    when(economy.deposit(any(), any()))
        .thenAnswer(
            inv -> {
              UUID id = inv.getArgument(0);
              BigDecimal amount = inv.getArgument(1);
              deposits.incrementAndGet();
              balances.put(id, balance(id).add(amount));
              return true;
            });
    when(resources.amount(any(), anyString()))
        .thenAnswer(inv -> inventory.getOrDefault(inv.getArgument(0), 0L));
    when(resources.consume(any(), anyString(), anyLong()))
        .thenAnswer(
            inv -> {
              NationId nation = inv.getArgument(0);
              long amount = inv.getArgument(2);
              consumes.incrementAndGet();
              long before = inventory.getOrDefault(nation, 0L);
              if (before < amount) return false;
              inventory.put(nation, before - amount);
              return true;
            });
    when(resources.grant(any(), anyString(), anyLong()))
        .thenAnswer(
            inv -> {
              NationId nation = inv.getArgument(0);
              long amount = inv.getArgument(2);
              grants.incrementAndGet();
              inventory.merge(nation, amount, Math::addExact);
              return true;
            });
    when(taxes.calculateTaxBD(anyString(), any(), any()))
        .thenAnswer(inv -> ((BigDecimal) inv.getArgument(1)).multiply(new BigDecimal("0.10")));
  }

  @Test
  void unfilledBuyAndSellRecoverExactIdentityTimeAndEscrowThenReturnOnce() {
    var market = market();
    buy(market, 5);
    sell(market, 5);
    var beforeBuy = market.getPlayerOrders(buyer).getFirst().toSnapshot();
    var beforeSell = market.getPlayerOrders(seller).getFirst().toSnapshot();
    var restored = market();
    assertEquals(beforeBuy, restored.getOrder(beforeBuy.orderId()).orElseThrow().toSnapshot());
    assertEquals(beforeSell, restored.getOrder(beforeSell.orderId()).orElseThrow().toSnapshot());
    assertEquals(1, withdrawals.get());
    assertEquals(1, consumes.get());
    assertTrue(restored.cancelOrder(buyer, beforeBuy.orderId()));
    assertTrue(restored.cancelOrder(seller, beforeSell.orderId()));
    assertMoney("1000", buyer);
    assertEquals(100, inventory.get(sellerNation));
    var twice = market();
    assertEquals(0, twice.refundOpenOrders());
    assertTrue(twice.getPlayerOrders(buyer).isEmpty());
    assertEquals(1, deposits.get());
    assertEquals(1, grants.get());
    assertEquals(Phase.CLOSED, twice.escrowSnapshot(beforeBuy.orderId()).orElseThrow().phase());
  }

  @Test
  void partialFillRestoresRemainingBalanceAndDoesNotReplayTheCompletedSeller() {
    var market = market();
    buy(market, 10);
    sell(market, 4);
    assertEquals(1, market.matchOrders("iron"));
    var original = market.getPlayerOrders(buyer).getFirst().toSnapshot();
    assertEquals(6, original.remainingAmount());
    assertMoney("916.4", buyer);
    assertMoney("28", seller);
    var restored = market();
    assertEquals(original, restored.getOrder(original.orderId()).orElseThrow().toSnapshot());
    assertEquals(0, restored.matchOrders("iron"));
    assertEquals(4, inventory.get(buyerNation));
    assertTrue(restored.cancelOrder(buyer, original.orderId()));
    assertMoney("969.2", buyer);
    assertEquals(0, market().refundOpenOrders());
  }

  @Test
  void finalFillReleasesRoundingRemainderAfterFeeChange() {
    var market = market();
    buy(market, 3);
    sell(market, 1);
    when(taxes.calculateTaxBD(anyString(), any(), any())).thenReturn(BigDecimal.ZERO);
    assertEquals(1, market.matchOrders("iron"));
    var restarted = market();
    sell(restarted, 2);
    assertEquals(1, restarted.matchOrders("iron"));
    assertMoney("979", buyer);
    assertMoney("21", seller);
    assertEquals(3, inventory.get(buyerNation));
    assertEquals(0, market().refundOpenOrders());
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void ambiguousBuyReservationRemainsFrozenAcrossRestarts(boolean throwsFailure) {
    when(economy.withdraw(any(), any()))
        .thenAnswer(
            inv -> {
              withdrawals.incrementAndGet();
              balances.put(buyer, balance(buyer).subtract(inv.getArgument(1)));
              if (throwsFailure) throw new IllegalStateException("lost debit acknowledgement");
              return false;
            });
    var first = market();
    buy(first, 5);
    UUID id = first.getPlayerOrders(buyer).getFirst().orderId();
    for (int i = 0; i < 2; i++) {
      var reopened = market();
      assertTrue(reopened.requiresReconciliation(id));
      assertFalse(reopened.cancelOrder(buyer, id));
      assertEquals(0, reopened.refundOpenOrders());
      assertEquals(Phase.RESERVING, reopened.escrowSnapshot(id).orElseThrow().phase());
      assertTrue(reopened.getOrderBook("iron").getBuyOrders().isEmpty());
    }
    assertEquals(1, withdrawals.get());
    assertEquals(0, deposits.get());
    assertMoney("956", buyer);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void ambiguousSellReservationNeverCreatesRefundableResources(boolean throwsFailure) {
    when(resources.consume(any(), anyString(), anyLong()))
        .thenAnswer(
            inv -> {
              consumes.incrementAndGet();
              inventory.put(sellerNation, 95L);
              if (throwsFailure) throw new IllegalStateException("lost resource acknowledgement");
              return false;
            });
    var first = market();
    sell(first, 5);
    UUID id = first.getPlayerOrders(seller).getFirst().orderId();
    var reopened = market();
    assertTrue(reopened.requiresReconciliation(id));
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(0, grants.get());
    assertEquals(1, consumes.get());
    assertEquals(95, inventory.get(sellerNation));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void ambiguousCancellationCannotRefundTwice(boolean throwsFailure) {
    var market = market();
    buy(market, 5);
    UUID id = market.getPlayerOrders(buyer).getFirst().orderId();
    when(economy.deposit(any(), any()))
        .thenAnswer(
            inv -> {
              deposits.incrementAndGet();
              balances.put(buyer, balance(buyer).add(inv.getArgument(1)));
              if (throwsFailure) throw new IllegalStateException("lost refund acknowledgement");
              return false;
            });
    assertFalse(market.cancelOrder(buyer, id));
    assertMoney("1000", buyer);
    var reopened = market();
    assertFalse(reopened.cancelOrder(buyer, id));
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(1, deposits.get());
    assertEquals(Phase.CANCELLING, reopened.escrowSnapshot(id).orElseThrow().phase());
  }

  @Test
  void reserveClaimMustCommitBeforeAnAssetCallAndFailedConfirmationRetainsIt() throws Exception {
    var market = market();
    sql(
        "CREATE TRIGGER reject_reserve BEFORE INSERT ON orders BEGIN SELECT RAISE(ABORT,'no disk');"
            + " END");
    assertThrows(IllegalStateException.class, () -> buy(market, 5));
    assertEquals(0, withdrawals.get());
    sql("DROP TRIGGER reject_reserve");
    failPhase("OPEN");
    buy(market, 5);
    UUID id = market.getPlayerOrders(buyer).getFirst().orderId();
    assertEquals(1, withdrawals.get());
    sql("DROP TRIGGER fail_phase");
    var reopened = market();
    assertTrue(reopened.requiresReconciliation(id));
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(0, deposits.get());
  }

  @Test
  void refundAcknowledgedButCloseWriteFailsRetainsCancellationEvidence() throws Exception {
    var first = market();
    buy(first, 5);
    UUID id = first.getPlayerOrders(buyer).getFirst().orderId();
    failPhase("CLOSED");
    assertFalse(first.cancelOrder(buyer, id));
    sql("DROP TRIGGER fail_phase");
    var reopened = market();
    assertTrue(reopened.requiresReconciliation(id));
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(1, deposits.get());
    assertMoney("1000", buyer);
  }

  @Test
  void secondMatchClaimFailureRollsBackBothClaimsBeforePayout() throws Exception {
    var first = market();
    buy(first, 5);
    sell(first, 5);
    UUID sellId = first.getPlayerOrders(seller).getFirst().orderId();
    sql(
        "CREATE TRIGGER fail_second BEFORE UPDATE ON orders WHEN NEW.phase='MATCHING' AND"
            + " NEW.order_id='"
            + sellId
            + "' BEGIN SELECT RAISE(ABORT,'second claim'); END");
    assertEquals(0, first.matchOrders("iron"));
    assertEquals(0, deposits.get());
    for (var order : first.getPlayerOrders(buyer))
      assertEquals(Phase.OPEN, first.escrowSnapshot(order.orderId()).orElseThrow().phase());
    assertEquals(Phase.OPEN, first.escrowSnapshot(sellId).orElseThrow().phase());
    sql("DROP TRIGGER fail_second");
    var reopened = market();
    assertEquals(1, reopened.matchOrders("iron"));
    assertEquals(0, market().matchOrders("iron"));
    assertMoney("35", seller);
  }

  @Test
  void committedMatchWithFailedOrderCheckpointNeverRepeatsAssetsOrRefunds() throws Exception {
    var first = market();
    buy(first, 5);
    sell(first, 5);
    failPhase("CLOSED");
    assertEquals(0, first.matchOrders("iron"));
    sql("DROP TRIGGER fail_phase");
    assertEquals(
        EconomyTransactionState.COMMITTED,
        TradeTestStorage.fabric(directory).snapshot().getFirst().state());
    var reopened = market();
    assertEquals(2, reopened.ordersAwaitingReconciliation().size());
    int previousDeposits = deposits.get();
    assertEquals(0, reopened.matchOrders("iron"));
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(previousDeposits, deposits.get());
    assertEquals(1, grants.get());
    assertMoney("35", seller);
    assertEquals(1, TradeTestStorage.history(directory).tradeChangesAfter(0, 128).size());
  }

  @Test
  void interruptionAfterClaimBeforePayoutAndAfterPayoutBothStayFrozen() {
    var first = market();
    buy(first, 5);
    sell(first, 5);
    when(economy.deposit(eq(seller), any()))
        .thenAnswer(
            inv -> {
              deposits.incrementAndGet();
              balances.put(seller, balance(seller).add(inv.getArgument(1)));
              throw new SimulatedPowerLoss();
            });
    assertThrows(SimulatedPowerLoss.class, () -> first.matchOrders("iron"));
    var reopened = market();
    assertEquals(2, reopened.escrowReviews(null, 20).size());
    assertEquals(0, reopened.refundOpenOrders());
    assertEquals(0, reopened.matchOrders("iron"));
    assertEquals(1, deposits.get());
    assertEquals(0, grants.get());
    assertMoney("35", seller);
  }

  @Test
  void staleServiceCannotCancelOrMatchAnAlreadyConsumedSnapshot() {
    var first = market();
    buy(first, 5);
    sell(first, 5);
    var stale = market();
    assertEquals(1, first.matchOrders("iron"));
    assertEquals(0, stale.matchOrders("iron"));
    assertEquals(0, stale.refundOpenOrders());
    assertMoney("35", seller);
    assertEquals(1, grants.get());
  }

  @Test
  void missingDatabaseAndWrongAuthorityRefuseAnEmptyReset() throws Exception {
    var first = market();
    buy(first, 5);
    Path database = directory.resolve("market-orders.sqlite");
    byte[] original = Files.readAllBytes(database);
    Files.delete(database);
    assertThrows(IllegalStateException.class, this::market);
    assertFalse(Files.exists(database));
    Files.write(database, original);
    sql("UPDATE authority SET trade_domain='" + UUID.randomUUID() + "'");
    assertThrows(IllegalStateException.class, this::market);
    assertEquals(1, withdrawals.get());
    assertEquals(0, deposits.get());
  }

  @Test
  void missingOrderFailsStartupValidation() throws Exception {
    var first = market();
    buy(first, 5);
    sql("DELETE FROM orders");
    assertThrows(IllegalStateException.class, this::market);
    assertEquals(0, deposits.get());
  }

  @Test
  void rewrittenCurrentPayloadFailsAgainstAppendOnlyEvidence() throws Exception {
    var first = market();
    buy(first, 5);
    sql("UPDATE orders SET payload=replace(payload,'44.000','44.001')");
    assertThrows(IllegalStateException.class, this::market);
    assertEquals(0, deposits.get());
  }

  @Test
  void preparationFailureLeavesBothDurableClaimsWithoutAnyPayout() throws Exception {
    var first = market();
    buy(first, 5);
    sell(first, 5);
    try (var connection =
            DriverManager.getConnection("jdbc:sqlite:" + directory.resolve("trades.db"));
        var statement = connection.createStatement()) {
      statement.execute(
          "CREATE TRIGGER reject_prepare BEFORE INSERT ON trade_settlement_intents BEGIN SELECT"
              + " RAISE(ABORT,'injected'); END");
    }
    assertEquals(0, first.matchOrders("iron"));
    var restored = market();
    assertEquals(2, restored.escrowReviews(null, 20).size());
    assertEquals(0, restored.refundOpenOrders());
    assertEquals(0, deposits.get());
    assertEquals(0, grants.get());
  }

  @Test
  void nativeResourceEscrowUsesExactReceiptsWithoutProductionBonuses() throws Exception {
    var data = new org.sqlite.SQLiteDataSource();
    data.setUrl("jdbc:sqlite:" + directory.resolve("inventory.sqlite"));
    var storage = FactorySnapshotVersionTest.storage(data, new java.util.Properties());
    ResourceModule module = new ResourceModule(storage);
    assertTrue(module.grant(sellerNation, "mineral", 100));
    var policies = mock(dev.starcore.starcore.module.policy.PolicyService.class);
    when(policies.activePolicyModifier(any(), anyString(), any())).thenReturn(2.0);
    var field = ResourceModule.class.getDeclaredField("policyService");
    field.setAccessible(true);
    field.set(module, policies);
    resources = module;
    var first = market();
    first.submitSellOrder(seller, sellerNation, "mineral", 5, 7, Instant.now().plusSeconds(3600));
    UUID sellId = first.getPlayerOrders(seller).getFirst().orderId();
    assertEquals(95, module.amount(sellerNation, "mineral"));
    assertTrue(module.transactionReceipt("market:" + sellId + ":reserve").isPresent());
    var restartedModule = new ResourceModule(storage);
    field.set(restartedModule, policies);
    resources = restartedModule;
    assertTrue(market().cancelOrder(seller, sellId));
    assertEquals(100, restartedModule.amount(sellerNation, "mineral"));
    assertTrue(restartedModule.transactionReceipt("market:" + sellId + ":cancel").isPresent());
    assertEquals(100, new ResourceModule(storage).amount(sellerNation, "mineral"));
    assertEquals(0, market().refundOpenOrders());
  }

  @Test
  void reviewPagingFindsEveryUnresolvedOrderBeyondTheFirstPage() {
    var history = TradeTestStorage.history(directory);
    var journal =
        new MarketOrderJournal(
            directory.resolve("market-orders.sqlite"),
            history.tradeHistoryAuthorityDomainId(),
            "boolean-resource-provider");
    for (int i = 0; i < 133; i++) {
      var order =
          new TradeOrder(
              UUID.randomUUID(),
              TradeOrder.OrderType.BUY,
              TradeOrder.OrderSource.PLAYER,
              buyer,
              buyerNation,
              "iron",
              1,
              1,
              Instant.now().plusSeconds(3600),
              false);
      journal.reserve(order, BigDecimal.ONE);
    }
    var restored = market();
    assertEquals(133, restored.ordersAwaitingReconciliation().size());
    var first = restored.escrowReviews(null, 128);
    assertEquals(128, first.size());
    var last = restored.escrowReviews(first.getLast().order().orderId(), 128);
    assertEquals(5, last.size());
    assertTrue(restored.escrowReviews(last.getLast().order().orderId(), 128).isEmpty());
    assertEquals(0, restored.refundOpenOrders());
    assertEquals(0, deposits.get());
    assertThrows(IllegalArgumentException.class, () -> restored.escrowReviews(null, 129));
  }

  @Test
  void forgedLiveFillCannotReleaseMoreThanPersistedEscrow() {
    var first = market();
    buy(first, 5);
    TradeOrder order = first.getPlayerOrders(buyer).getFirst();
    order.fill(2);
    assertFalse(first.cancelOrder(buyer, order.orderId()));
    assertEquals(0, deposits.get());
    assertTrue(first.requiresReconciliation(order.orderId()));
    var reopened = market();
    assertEquals(5, reopened.getOrder(order.orderId()).orElseThrow().remainingAmount());
  }

  @Test
  void oldThreeArgumentConstructorCannotReserveUntilStorageIsConfigured() {
    var first = new SimpleMarketOrderBookService(resources, economy, taxes);
    first.setTradeHistoryService(TradeTestStorage.history(directory));
    first.setTransactionFabric(TradeTestStorage.fabric(directory));
    buy(first, 5);
    sell(first, 5);
    assertEquals(0, withdrawals.get());
    assertEquals(0, consumes.get());
    assertTrue(first.getAllOrderBooks().isEmpty());
  }

  @Test
  void knownInsufficientFundsAndResourcesDoNotCreateUnresolvedClaims() {
    balances.put(buyer, BigDecimal.ZERO);
    inventory.put(sellerNation, 0L);
    var first = market();
    buy(first, 5);
    sell(first, 5);
    assertTrue(first.escrowReviews(null, 20).isEmpty());
    assertEquals(0, withdrawals.get());
    assertEquals(0, consumes.get());
  }

  private SimpleMarketOrderBookService market() {
    var service = new SimpleMarketOrderBookService(resources, economy, taxes);
    service.setTradeHistoryService(TradeTestStorage.history(directory));
    service.setTransactionFabric(TradeTestStorage.fabric(directory));
    service.initializeOrderStorage(directory.resolve("market-orders.sqlite"));
    return service;
  }

  private void buy(SimpleMarketOrderBookService service, long amount) {
    service.submitBuyOrder(
        buyer, buyerNation, "iron", amount, 8.0, Instant.now().plusSeconds(3600));
  }

  private void sell(SimpleMarketOrderBookService service, long amount) {
    service.submitSellOrder(
        seller, sellerNation, "iron", amount, 7.0, Instant.now().plusSeconds(3600));
  }

  private BigDecimal balance(UUID id) {
    return balances.getOrDefault(id, BigDecimal.ZERO);
  }

  private void assertMoney(String expected, UUID id) {
    assertEquals(0, new BigDecimal(expected).compareTo(balance(id)));
  }

  private void failPhase(String phase) throws Exception {
    sql(
        "CREATE TRIGGER fail_phase BEFORE UPDATE ON orders WHEN NEW.phase='"
            + phase
            + "' BEGIN SELECT RAISE(ABORT,'injected'); END");
  }

  private void sql(String sql) throws Exception {
    try (var connection =
            DriverManager.getConnection(
                "jdbc:sqlite:" + directory.resolve("market-orders.sqlite"));
        var statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  private static final class SimulatedPowerLoss extends Error {}
}
