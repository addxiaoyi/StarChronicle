package dev.starcore.starcore.module.resource.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Durable escrow evidence. A non-OPEN, non-CLOSED phase requires reconciliation, never replay. */
public record MarketEscrowSnapshot(
    TradeOrder.OrderSnapshot order,
    BigDecimal moneyRemaining,
    Phase phase,
    UUID operationId,
    String detail,
    Instant updatedAt,
    long revision) {
  public enum Phase {
    RESERVING,
    OPEN,
    CANCELLING,
    MATCHING,
    CLOSED
  }

  public MarketEscrowSnapshot {
    Objects.requireNonNull(order, "order");
    Objects.requireNonNull(moneyRemaining, "moneyRemaining");
    Objects.requireNonNull(phase, "phase");
    Objects.requireNonNull(operationId, "operationId");
    Objects.requireNonNull(detail, "detail");
    Objects.requireNonNull(updatedAt, "updatedAt");
    TradeOrder.restore(order);
    if (revision < 1
        || moneyRemaining.signum() < 0
        || moneyRemaining.precision() > 128
        || Math.abs((long) moneyRemaining.scale()) > 128
        || order.source() != TradeOrder.OrderSource.PLAYER
        || order.playerId() == null
        || order.nationId() == null
        || order.expiryTime() == null
        || detail.length() > 16_384
        || (order.type() == TradeOrder.OrderType.SELL && moneyRemaining.signum() != 0)
        || (phase == Phase.CLOSED && moneyRemaining.signum() != 0)) {
      throw new IllegalArgumentException("Invalid market escrow evidence");
    }
    boolean terminal =
        order.status() == TradeOrder.OrderStatus.FILLED
            || order.status() == TradeOrder.OrderStatus.CANCELLED
            || order.status() == TradeOrder.OrderStatus.EXPIRED;
    if ((phase == Phase.CLOSED) != terminal) {
      throw new IllegalArgumentException("Escrow phase does not match order status");
    }
  }

  public boolean requiresReconciliation() {
    return phase != Phase.OPEN && phase != Phase.CLOSED;
  }
}
