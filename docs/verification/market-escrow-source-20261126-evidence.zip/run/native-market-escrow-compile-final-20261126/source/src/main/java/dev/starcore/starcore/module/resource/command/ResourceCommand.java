package dev.starcore.starcore.module.resource.command;

import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.*;
import dev.starcore.starcore.module.resource.model.ResourceEmbargo;
import dev.starcore.starcore.module.resource.model.ResourcePrice;
import dev.starcore.starcore.module.resource.model.TradeAgreement;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.nation.permission.NationPermission;
import dev.starcore.starcore.util.PermissionUtil;
import java.util.*;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** 资源管理命令 命令：/resource <子命令> */
public class ResourceCommand implements CommandExecutor, TabCompleter {
  private static final String PERMISSION_USE = "starcore.resource";
  private static final String PERMISSION_ADMIN = "starcore.resource.admin";
  private static final Logger LOGGER = Logger.getLogger(ResourceCommand.class.getName());

  private final ResourceService resourceService;
  private final ResourcePriceService priceService;
  private final ResourceTradeService tradeService;
  private final ResourceReserveService reserveService;
  private final ProcessingService processingService;
  private final NationService nationService;
  private final OnlinePlayerDirectory onlinePlayerDirectory;

  // 市场交易功能（可选）
  private MarketOrderBookService marketOrderBookService;
  private TradeHistoryService tradeHistoryService;
  private PlayerTradeService playerTradeService;
  private TradeTaxService tradeTaxService;

  public ResourceCommand(
      ResourceService resourceService,
      ResourcePriceService priceService,
      ResourceTradeService tradeService,
      ResourceReserveService reserveService,
      ProcessingService processingService,
      NationService nationService,
      OnlinePlayerDirectory onlinePlayerDirectory) {
    this.resourceService = resourceService;
    this.priceService = priceService;
    this.tradeService = tradeService;
    this.reserveService = reserveService;
    this.processingService = processingService;
    this.nationService = nationService;
    this.onlinePlayerDirectory = onlinePlayerDirectory;
    // 市场交易服务初始化为null，通过setter注入
    this.marketOrderBookService = null;
    this.tradeHistoryService = null;
    this.playerTradeService = null;
    this.tradeTaxService = null;
  }

  /** 设置市场订单簿服务 */
  public void setMarketOrderBookService(MarketOrderBookService service) {
    this.marketOrderBookService = service;
  }

  /** 设置交易历史服务 */
  public void setTradeHistoryService(TradeHistoryService service) {
    this.tradeHistoryService = service;
  }

  /** 设置玩家交易服务 */
  public void setPlayerTradeService(PlayerTradeService service) {
    this.playerTradeService = service;
  }

  /** 设置交易税收服务 */
  public void setTradeTaxService(TradeTaxService service) {
    this.tradeTaxService = service;
  }

  /** 检查市场功能是否可用 */
  private boolean hasMarketFeature() {
    return marketOrderBookService != null;
  }

  /** 检查交易历史功能是否可用 */
  private boolean hasTradeHistoryFeature() {
    return tradeHistoryService != null;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (args.length >= 2
        && args[0].equalsIgnoreCase("order")
        && args[1].equalsIgnoreCase("review")) {
      return handleOrderReview(sender, args);
    }
    if (!(sender instanceof Player player)) {
      if (args.length > 0
          && args[0].equalsIgnoreCase("give")
          && sender.hasPermission(PERMISSION_ADMIN)) {
        return handleGive(sender, args);
      }
      sender.sendMessage("§c该命令只能由玩家执行。");
      return true;
    }

    if (!player.hasPermission(PERMISSION_USE) && !player.hasPermission(PERMISSION_ADMIN)) {
      player.sendMessage("§c你没有使用资源系统的权限。");
      return true;
    }

    if (args.length == 0) {
      return handleInfo(player);
    }

    try {
      String subCommand = args[0].toLowerCase(Locale.ROOT);
      return switch (subCommand) {
        case "info" -> handleInfo(player);
        case "stockpile", "stock" -> handleStockpile(player);
        case "market" -> handleMarket(player);
        case "reserve" -> handleReserve(player, args);
        case "trade" -> handleTrade(player, args);
        case "factory" -> handleFactory(player, args);
        case "process" -> handleProcess(player, args);
        case "order" -> {
          if (!hasMarketFeature()) {
            player.sendMessage("§c市场订单功能暂不可用。");
            yield true;
          }
          yield handleOrder(player, args);
        }
        case "history" -> {
          if (!hasTradeHistoryFeature()) {
            player.sendMessage("§c交易历史功能暂不可用。");
            yield true;
          }
          yield handleHistory(player, args);
        }
        case "give" -> {
          if (!player.hasPermission(PERMISSION_ADMIN)) {
            player.sendMessage("§c你没有使用管理资源命令的权限。");
            yield true;
          }
          yield handleGive(player, args);
        }
        case "help", "?" -> {
          sendHelp(player);
          yield true;
        }
        default -> {
          player.sendMessage("§c未知子命令: " + subCommand);
          sendHelp(player);
          yield true;
        }
      };
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.SEVERE,
          "[ResourceCommand] command failed; player="
              + player.getUniqueId()
              + ", label="
              + label
              + ", args="
              + Arrays.toString(args),
          exception);
      player.sendMessage("§c资源命令执行失败，请稍后重试。");
      return true;
    }
  }

  private boolean handleInfo(Player player) {
    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何Nation中");
      return true;
    }

    Nation nation = nationOpt.get();
    NationId nationId = nation.id();
    Map<String, Long> stockpile = resourceService.stockpile(nationId);

    player.sendMessage("§6§l==== " + nation.name() + " 资源信息 ====");
    // 分隔

    // 显示资源储量
    player.sendMessage("§e资源储量:");
    for (Map.Entry<String, Long> entry : stockpile.entrySet()) {
      String icon = getResourceIcon(entry.getKey());
      player.sendMessage(
          String.format(
              "  %s §f%s: §a%d", icon, formatResourceName(entry.getKey()), entry.getValue()));
    }

    // 显示市场价格
    // 分隔
    player.sendMessage("§e市场价格:");
    for (String resourceType : resourceService.availableResourceTypes()) {
      double price = priceService.getCurrentPrice(resourceType);
      var state = priceService.getMarketState(resourceType);
      String stateColor = getStateColor(state);
      player.sendMessage(
          String.format(
              "  §f%s: §6%.2f %s(%s)",
              formatResourceName(resourceType), price, stateColor, state.displayName()));
    }

    return true;
  }

  private boolean handleStockpile(Player player) {
    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何Nation中");
      return true;
    }

    Nation nation = nationOpt.get();
    NationId nationId = nation.id();
    Map<String, Long> stockpile = resourceService.stockpile(nationId);

    player.sendMessage("§6§l==== 资源储量 ====");
    for (Map.Entry<String, Long> entry : stockpile.entrySet()) {
      String icon = getResourceIcon(entry.getKey());
      player.sendMessage(
          String.format(
              "  %s §f%s: §a%d", icon, formatResourceName(entry.getKey()), entry.getValue()));
    }

    return true;
  }

  private boolean handleMarket(Player player) {
    player.sendMessage("§6§l==== 资源市场 ====");
    // 分隔

    for (String resourceType : resourceService.availableResourceTypes()) {
      var priceOpt = priceService.getPrice(resourceType);
      if (priceOpt.isEmpty()) {
        continue;
      }

      var price = priceOpt.get();
      var state = priceService.getMarketState(resourceType);
      String stateColor = getStateColor(state);
      double trend = priceService.getPriceTrend(resourceType);
      String trendStr =
          trend >= 0
              ? "§a+" + String.format("%.1f", trend) + "%"
              : "§c" + String.format("%.1f", trend) + "%";

      player.sendMessage(String.format("§f%s:", formatResourceName(resourceType)));
      player.sendMessage(String.format("  §7价格: §6%.2f §7趋势: %s", price.currentPrice(), trendStr));
      player.sendMessage(String.format("  §7市场: %s", stateColor + state.displayName()));
      player.sendMessage(String.format("  §7供需比: §f%.2f:%.2f", price.supply(), price.demand()));
      // 分隔
    }

    return true;
  }

  private boolean handleReserve(Player player, String[] args) {
    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何国家中。");
      return true;
    }
    Nation nation = nationOpt.get();
    NationId nationId = nation.id();

    if (args.length < 2) {
      player.sendMessage("§c用法: /resource reserve <info|add|release> [资源] [数量]");
      return true;
    }
    String action = args[1].toLowerCase(Locale.ROOT);
    if (action.equals("info")) {
      return handleReserveInfo(player, nationId);
    }
    if (!action.equals("add") && !action.equals("release")) {
      player.sendMessage("§c未知操作: " + action);
      player.sendMessage("§e可用操作: info, add, release");
      return true;
    }
    if (!requireNationPermission(player, nation, NationPermission.RESOURCE_RESERVE_MANAGE)) {
      return true;
    }
    if (args.length != 4) {
      player.sendMessage("§c用法: /resource reserve " + action + " <资源> <数量>");
      return true;
    }

    long amount;
    try {
      amount = Long.parseLong(args[3]);
    } catch (NumberFormatException exception) {
      player.sendMessage("§c数量必须是整数。");
      return true;
    }

    ResourceTradeTerms.Validation validation = ResourceTradeTerms.validateTransfer(args[2], amount);
    if (!validation.isValid()) {
      player.sendMessage("§c" + describeViolation(validation.violation()));
      return true;
    }
    ResourceTradeTerms terms = validation.terms();
    boolean success =
        action.equals("add")
            ? reserveService.transferToReserve(nationId, terms.resourceId(), terms.amount())
            : reserveService.emergencyRelease(nationId, terms.resourceId(), terms.amount());
    player.sendMessage(success ? "§a储备操作成功。" : "§c储备操作失败，请检查资源数量和储备限制。");
    return true;
  }

  private boolean handleReserveInfo(Player player, NationId nationId) {
    Map<String, Long> reserves = reserveService.getAllReserves(nationId);
    Map<String, Long> goals = reserveService.getAllGoals(nationId);

    player.sendMessage("§6§l==== 战略储备 ====");

    if (reserves.isEmpty()) {
      player.sendMessage("§7暂无储备信息");
      return true;
    }

    double overallProgress = reserveService.getOverallProgress(nationId);
    player.sendMessage(String.format("§7总体完成度: §e%.1f%%", overallProgress * 100));

    for (String resourceId : reserves.keySet()) {
      long reserve = reserves.getOrDefault(resourceId, 0L);
      long goal = goals.getOrDefault(resourceId, 0L);
      double progress = goal > 0 ? (double) reserve / goal : 0;
      String progressBar = createProgressBar(progress);

      player.sendMessage(
          String.format(
              "  %s: %d / %d %s", formatResourceName(resourceId), reserve, goal, progressBar));
    }

    return true;
  }

  private boolean handleTrade(Player player, String[] args) {
    if (args.length < 2 || tradeService == null) {
      player.sendMessage("§e用法: /resource trade <routes|agreements|executions|embargo>");
      return true;
    }
    String action = args[1].toLowerCase(Locale.ROOT);

    switch (action) {
      case "routes" -> {
        return handleTradeRoutes(player);
      }
      case "executions" -> {
        return handleTradeExecutions(player, args);
      }
      case "agreements" -> {
        if (args.length < 3) {
          player.sendMessage("§c用法: /resource trade agreements <list|create|edit|cancel>");
          return true;
        }
        return handleAgreements(player, args);
      }
      case "embargo" -> {
        if (args.length < 3) {
          player.sendMessage("§c用法: /resource trade embargo <list|create|lift|edit>");
          return true;
        }
        return handleEmbargo(player, args);
      }
      default -> {
        player.sendMessage("§c未知操作: " + action);
        return true;
      }
    }
  }

  private boolean handleTradeRoutes(Player player) {
    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何Nation中");
      return true;
    }

    Nation nation = nationOpt.get();
    var routes = tradeService.getTradeRoutes(nation.id());

    player.sendMessage("§6§l==== 贸易路线 ====");

    if (routes.isEmpty()) {
      player.sendMessage("§7暂无贸易路线");
      return true;
    }

    for (var route : routes) {
      String status = route.isActive() ? "§a活跃" : "§c停用";
      player.sendMessage(
          String.format(
              "  §e%s: §f%d%% §7- 状态: %s",
              route.routeName(), (int) (route.efficiency() * 100), status));
    }

    return true;
  }

  private boolean handleAgreements(Player player, String[] args) {
    if (tradeService == null) {
      player.sendMessage("§c贸易服务暂不可用。");
      return true;
    }
    if (args.length < 3) {
      player.sendMessage("§c用法: /resource trade agreements <list|create|edit|cancel>");
      return true;
    }

    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何国家中。");
      return true;
    }
    Nation nation = nationOpt.get();
    String action = args[2].toLowerCase(Locale.ROOT);
    if ((action.equals("create")
            || action.equals("edit")
            || action.equals("cancel")
            || action.equals("execute"))
        && !requireNationPermission(player, nation, NationPermission.RESOURCE_TRADE_MANAGE)) {
      return true;
    }

    return switch (action) {
      case "list" -> handleAgreementsList(player, nation);
      case "create" -> handleAgreementCreate(player, nation, args);
      case "edit" -> handleAgreementEdit(player, nation, args);
      case "execute" -> handleAgreementExecute(player, nation, args);
      case "cancel" -> {
        if (args.length != 4) {
          player.sendMessage("§c用法: /resource trade agreements cancel <协定ID>");
          yield true;
        }
        yield handleAgreementCancel(player, nation, args[3]);
      }
      default -> {
        player.sendMessage("§c未知操作: " + action);
        player.sendMessage("§e可用操作: list, create, edit, cancel");
        yield true;
      }
    };
  }

  private boolean handleAgreementsList(Player player, Nation nation) {
    List<TradeAgreement> agreements = List.copyOf(tradeService.getTradeAgreements(nation.id()));

    player.sendMessage("§6§l==== 贸易协定 ====");
    if (agreements.isEmpty()) {
      player.sendMessage("§7暂无贸易协定");
      player.sendMessage("§e使用 /resource trade agreements create 创建新协定");
      return true;
    }

    List<UUID> agreementIds = agreements.stream().map(TradeAgreement::agreementId).toList();
    for (TradeAgreement agreement : agreements) {
      String status = agreement.isActive() ? "§a生效中" : "§c已过期";
      String counterparty =
          agreement.exporterNationId().equals(nation.id())
              ? getNationDisplayName(agreement.importerNationId())
              : getNationDisplayName(agreement.exporterNationId());
      String role = agreement.exporterNationId().equals(nation.id()) ? "§6出口" : "§9进口";
      String displayedId =
          ResourceObjectIdResolver.shortestUniquePrefix(agreement.agreementId(), agreementIds);

      player.sendMessage(
          String.format(
              "  %s §7[§f%s§7]", formatResourceName(agreement.resourceId()), displayedId));
      player.sendMessage(String.format("    §7对象: %s §7角色: %s", counterparty, role));
      player.sendMessage(
          String.format(
              "    §7数量: §e%d §7单价: §6%.2f §7总计: §a%.2f",
              agreement.amount(),
              agreement.pricePerUnit(),
              agreement.amount() * agreement.pricePerUnit()));
      player.sendMessage(String.format("    §7有效期: §f%s %s", formatExpiryTime(agreement), status));
    }
    return true;
  }

  private boolean handleAgreementExecute(Player player, Nation nation, String[] args) {
    if (args.length != 5) {
      player.sendMessage("§e用法: /resource trade agreements execute <协定ID> <执行编号>");
      player.sendMessage("§7双方当前创始人确认后才付款交货；同一笔贸易重试请使用原执行编号。");
      return true;
    }
    if (!requireTradeFounder(player, nation)) return true;
    var ids =
        tradeService.getTradeAgreements(nation.id()).stream()
            .map(TradeAgreement::agreementId)
            .toList();
    UUID agreement = resolveObjectId(player, args[3], ids, "贸易协定");
    if (agreement != null) {
      var result =
          tradeService.executeTradeAgreement(
              new ResourceTradeService.ExecutionRequest(args[4], agreement, player.getUniqueId()));
      showTradeExecutionResult(player, args[4], result);
    }
    return true;
  }

  private boolean handleTradeExecutions(Player player, String[] args) {
    if (args.length < 3 || args.length > 4) {
      player.sendMessage(
          "§e用法: /resource trade executions <list [页码]|inspect 编号|approve 编号|retry 编号>");
      return true;
    }
    var nation = nationService.nationOf(player.getUniqueId());
    if (nation.isEmpty()) {
      player.sendMessage("§c你不在任何国家中。");
      return true;
    }
    String action = args[2].toLowerCase(Locale.ROOT);
    if (action.equals("list")) {
      int page = args.length == 4 ? Integer.parseInt(args[3]) : 1;
      if (page < 1 || page > Integer.MAX_VALUE / 10) {
        player.sendMessage("§c页码超出范围。");
        return true;
      }
      var values = tradeService.tradeExecutions(nation.get().id(), (page - 1) * 10, 10);
      player.sendMessage("§6贸易执行 第 " + page + " 页");
      for (var value : values) showTradeExecution(player, value);
      if (values.isEmpty()) player.sendMessage("§7本页没有执行记录。");
      return true;
    }
    if (args.length != 4 || !Set.of("inspect", "approve", "retry").contains(action)) {
      player.sendMessage("§e用法: /resource trade executions <inspect|approve|retry> <执行编号>");
      return true;
    }
    var execution = tradeService.tradeExecution(args[3]);
    if (execution.isEmpty() || !execution.get().involves(nation.get().id())) {
      player.sendMessage("§c未找到本国参与的执行记录。");
      return true;
    }
    if (action.equals("inspect")) {
      showTradeExecution(player, execution.get());
      return true;
    }
    if (!requireNationPermission(player, nation.get(), NationPermission.RESOURCE_TRADE_MANAGE)
        || !requireTradeFounder(player, nation.get())) return true;
    var result =
        action.equals("approve")
            ? tradeService.executeTradeAgreement(
                new ResourceTradeService.ExecutionRequest(
                    args[3], execution.get().agreementId(), player.getUniqueId()))
            : tradeService.retryTradeExecution(args[3], player.getUniqueId());
    showTradeExecutionResult(player, args[3], result);
    return true;
  }

  private boolean requireTradeFounder(Player player, Nation nation) {
    if (player.getUniqueId().equals(nation.founderId())) return true;
    player.sendMessage("§c只有当前国家创始人可以批准或重试国家贸易执行。");
    return false;
  }

  private void showTradeExecution(Player player, TradeExecution value) {
    player.sendMessage("§e" + value.executionId() + " §7" + tradeExecutionState(value));
    player.sendMessage(
        "§7出口: "
            + getNationDisplayName(value.exporter())
            + " 进口: "
            + getNationDisplayName(value.importer()));
    player.sendMessage(
        "§7资源: "
            + value.resourceId()
            + " 数量: "
            + value.amount()
            + " 总价: "
            + value.totalPrice().toPlainString());
    if (value.state() == TradeExecution.State.AWAITING_APPROVAL)
      player.sendMessage(
          "§7出口方确认: "
              + (value.exporterApproval() != null)
              + " 进口方确认: "
              + (value.importerApproval() != null));
  }

  private String tradeExecutionState(TradeExecution value) {
    return switch (value.state()) {
      case AWAITING_APPROVAL -> "等待双方确认";
      case PREPARED -> "已预留配额，待核对付款";
      case PAID -> "已付款，待核对交货";
      case REFUND_PENDING -> "退款待完成";
      case COMPLETED -> "已完成";
      case REJECTED -> "已拒绝";
      case REFUNDED -> "已退款";
    };
  }

  private void showTradeExecutionResult(
      Player player, String id, ResourceTradeService.ExecutionResult result) {
    player.sendMessage(
        switch (result.status()) {
          case AWAITING_APPROVAL -> "§e已保存确认，等待另一方创始人使用 /resource trade executions approve " + id;
          case COMPLETED -> "§a该笔贸易已完成。执行编号: " + id;
          case REFUNDED -> "§e未交货，款项已退回。执行编号: " + id;
          case REJECTED -> "§c该执行被拒绝，请核对权限、协定、配额和资金。编号: " + id;
          case UNKNOWN -> "§e执行结果待核对，请保留原编号 " + id + "，使用 executions inspect 或 retry 查询续办。";
          case UNAVAILABLE -> "§c持久贸易服务暂不可用，请保留原编号 " + id + " 稍后重试。";
        });
    if (result.execution() != null) showTradeExecution(player, result.execution());
  }

  private String formatExpiryTime(
      dev.starcore.starcore.module.resource.model.TradeAgreement agreement) {
    if (agreement.expiryTime() == null) {
      return "永久";
    }
    long remainingSeconds =
        agreement.expiryTime().getEpochSecond() - System.currentTimeMillis() / 1000;
    if (remainingSeconds <= 0) {
      return "已过期";
    }
    long days = remainingSeconds / 86400;
    long hours = (remainingSeconds % 86400) / 3600;
    if (days > 0) {
      return days + "天" + hours + "小时";
    } else if (hours > 0) {
      return hours + "小时";
    } else {
      return remainingSeconds / 60 + "分钟";
    }
  }

  private boolean handleAgreementCreate(Player player, Nation nation, String[] args) {
    if (args.length < 7 || args.length > 8) {
      player.sendMessage(
          "§c用法: /resource trade agreements create " + "<对方国家> <资源> <数量> <单价> [有效期(天)]");
      return true;
    }

    Optional<Nation> targetNationOpt = nationService.nationByName(args[3]);
    if (targetNationOpt.isEmpty()) {
      player.sendMessage("§c未找到国家: " + args[3]);
      return true;
    }
    Nation targetNation = targetNationOpt.get();
    if (targetNation.id().equals(nation.id())) {
      player.sendMessage("§c不能与自己的国家创建贸易协定。");
      return true;
    }

    long amount;
    double pricePerUnit;
    long durationDays = 30L;
    try {
      amount = Long.parseLong(args[5]);
      pricePerUnit = Double.parseDouble(args[6]);
      if (args.length == 8) {
        durationDays = Long.parseLong(args[7]);
      }
    } catch (NumberFormatException exception) {
      player.sendMessage("§c数量、单价或有效期格式无效。");
      return true;
    }

    long durationSeconds;
    try {
      durationSeconds = Math.multiplyExact(durationDays, 86_400L);
    } catch (ArithmeticException exception) {
      player.sendMessage("§c有效期数值过大。");
      return true;
    }

    ResourceTradeTerms.Validation validation =
        ResourceTradeTerms.validateAgreement(args[4], amount, pricePerUnit, durationSeconds);
    if (!validation.isValid()) {
      player.sendMessage("§c" + describeViolation(validation.violation()));
      return true;
    }
    ResourceTradeTerms terms = validation.terms();
    TradeAgreement agreement =
        tradeService.createTradeAgreement(
            nation.id(),
            targetNation.id(),
            terms.resourceId(),
            terms.amount(),
            terms.pricePerUnitAsDouble(),
            terms.durationSeconds());

    player.sendMessage("§a贸易协定创建成功。");
    player.sendMessage("  §e协定ID: §f" + agreement.agreementId());
    player.sendMessage("  §e资源: §f" + formatResourceName(terms.resourceId()));
    player.sendMessage("  §e交易对象: §f" + targetNation.name());
    player.sendMessage("  §e总价值: §a" + terms.totalValue().toPlainString());
    return true;
  }

  private boolean handleAgreementEdit(Player player, Nation nation, String[] args) {
    if (args.length < 5 || args.length > 6) {
      player.sendMessage(
          "§c用法: /resource trade agreements edit " + "<协定ID> <amount|price|duration> [新值]");
      return true;
    }

    List<TradeAgreement> agreements = List.copyOf(tradeService.getTradeAgreements(nation.id()));
    UUID agreementId =
        resolveObjectId(
            player, args[3], agreements.stream().map(TradeAgreement::agreementId).toList(), "贸易协定");
    if (agreementId == null) {
      return true;
    }

    String field = args[4].toLowerCase(Locale.ROOT);
    if (!field.equals("amount")
        && !field.equals("数量")
        && !field.equals("price")
        && !field.equals("单价")
        && !field.equals("duration")
        && !field.equals("有效期")) {
      player.sendMessage("§c未知字段: " + field);
      player.sendMessage("§e可用字段: amount, price, duration");
      return true;
    }
    if (args.length == 6) {
      try {
        if (field.equals("amount") || field.equals("数量")) {
          long amount = Long.parseLong(args[5]);
          if (amount <= 0 || amount > ResourceTradeTerms.MAX_AMOUNT) {
            player.sendMessage("§c新数量超出允许范围。");
            return true;
          }
        } else {
          double value = Double.parseDouble(args[5]);
          if (!Double.isFinite(value) || value <= 0) {
            player.sendMessage("§c新值必须是有限正数。");
            return true;
          }
        }
      } catch (NumberFormatException exception) {
        player.sendMessage("§c新值格式无效。");
        return true;
      }
    }

    player.sendMessage("§e当前贸易协定不可原地修改，请取消后重新创建。");
    player.sendMessage("§7协定ID: §f" + agreementId);
    return true;
  }

  private boolean handleAgreementCancel(Player player, Nation nation, String agreementIdInput) {
    List<TradeAgreement> agreements = List.copyOf(tradeService.getTradeAgreements(nation.id()));
    UUID agreementId =
        resolveObjectId(
            player,
            agreementIdInput,
            agreements.stream().map(TradeAgreement::agreementId).toList(),
            "贸易协定");
    if (agreementId == null) {
      return true;
    }

    boolean cancelled = tradeService.cancelTradeAgreement(nation.id(), agreementId);
    player.sendMessage(cancelled ? "§a协定已取消。" : "§c协定取消失败，协定可能已结束。");
    return true;
  }

  private boolean handleEmbargo(Player player, String[] args) {
    if (tradeService == null) {
      player.sendMessage("§c贸易服务暂不可用。");
      return true;
    }
    if (args.length < 3) {
      player.sendMessage("§c用法: /resource trade embargo <list|create|lift|edit>");
      return true;
    }

    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何国家中。");
      return true;
    }
    Nation nation = nationOpt.get();
    String action = args[2].toLowerCase(Locale.ROOT);
    if ((action.equals("create") || action.equals("lift") || action.equals("edit"))
        && !requireNationPermission(player, nation, NationPermission.RESOURCE_TRADE_MANAGE)) {
      return true;
    }

    return switch (action) {
      case "list" -> handleEmbargoList(player, nation);
      case "create" -> handleEmbargoCreate(player, nation, args);
      case "lift" -> {
        if (args.length != 4) {
          player.sendMessage("§c用法: /resource trade embargo lift <禁运ID>");
          yield true;
        }
        yield handleEmbargoLift(player, nation, args[3]);
      }
      case "edit" -> handleEmbargoEdit(player, nation, args);
      default -> {
        player.sendMessage("§c未知操作: " + action);
        player.sendMessage("§e可用操作: list, create, lift, edit");
        yield true;
      }
    };
  }

  private boolean handleEmbargoList(Player player, Nation nation) {
    List<ResourceEmbargo> initiated = List.copyOf(tradeService.getEmbargoesBy(nation.id()));
    List<ResourceEmbargo> against = List.copyOf(tradeService.getEmbargoesAgainst(nation.id()));

    player.sendMessage("§6§l==== 禁运管理 ====");
    if (initiated.isEmpty() && against.isEmpty()) {
      player.sendMessage("§7暂无禁运记录");
      return true;
    }

    if (!initiated.isEmpty()) {
      List<UUID> initiatedIds = initiated.stream().map(ResourceEmbargo::embargoId).toList();
      player.sendMessage("§e--- 我方发起的禁运 ---");
      for (ResourceEmbargo embargo : initiated) {
        String targets =
            embargo.targetNationIds().stream()
                .map(this::getNationDisplayName)
                .collect(Collectors.joining(", "));
        String status = embargo.isActive() ? "§a生效中" : "§c已过期";
        String displayedId =
            ResourceObjectIdResolver.shortestUniquePrefix(embargo.embargoId(), initiatedIds);
        player.sendMessage(
            String.format(
                "  §7[§f%s§7] §c%s §7-> §f%s: §e%s %s",
                displayedId,
                embargo.resourceId(),
                targets,
                embargo.reason() != null ? embargo.reason() : "无原因",
                status));
      }
    }

    if (!against.isEmpty()) {
      List<UUID> againstIds = against.stream().map(ResourceEmbargo::embargoId).toList();
      player.sendMessage("§e--- 针对我方的禁运 ---");
      for (ResourceEmbargo embargo : against) {
        String initiator = getNationDisplayName(embargo.initiatorNationId());
        String status = embargo.isActive() ? "§c生效中" : "§a已解除";
        String displayedId =
            ResourceObjectIdResolver.shortestUniquePrefix(embargo.embargoId(), againstIds);
        player.sendMessage(
            String.format(
                "  §7[§f%s§7] §c%s §7来自 §f%s: §e%s %s",
                displayedId,
                embargo.resourceId(),
                initiator,
                embargo.reason() != null ? embargo.reason() : "无原因",
                status));
      }
    }
    return true;
  }

  private boolean handleEmbargoCreate(Player player, Nation nation, String[] args) {
    if (args.length < 5) {
      player.sendMessage("§c用法: /resource trade embargo create " + "<目标国家> <资源> [有效期(天)] [原因]");
      return true;
    }

    Optional<Nation> targetNationOpt = nationService.nationByName(args[3]);
    if (targetNationOpt.isEmpty()) {
      player.sendMessage("§c未找到国家: " + args[3]);
      return true;
    }
    Nation targetNation = targetNationOpt.get();
    if (targetNation.id().equals(nation.id())) {
      player.sendMessage("§c不能对自己的国家实施禁运。");
      return true;
    }

    String resourceId = ResourceTradeTerms.normalizeResourceId(args[4]);
    if (resourceId == null) {
      player.sendMessage("§c资源 ID 格式无效。");
      return true;
    }

    Long durationSeconds = null;
    int reasonStart = 5;
    if (args.length > 5) {
      try {
        long durationDays = Long.parseLong(args[5]);
        durationSeconds = Math.multiplyExact(durationDays, 86_400L);
        if (durationSeconds < 1 || durationSeconds > ResourceTradeTerms.MAX_DURATION_SECONDS) {
          player.sendMessage("§c禁运有效期必须在 1 到 3650 天之间。");
          return true;
        }
        reasonStart = 6;
      } catch (NumberFormatException ignored) {
        reasonStart = 5;
      } catch (ArithmeticException exception) {
        player.sendMessage("§c禁运有效期数值过大。");
        return true;
      }
    }

    String reason =
        reasonStart < args.length
            ? String.join(" ", Arrays.copyOfRange(args, reasonStart, args.length))
            : "未说明";
    ResourceEmbargo embargo =
        tradeService.createEmbargo(
            nation.id(), Set.of(targetNation.id()), resourceId, durationSeconds, reason);
    player.sendMessage("§a禁运创建成功。");
    player.sendMessage("  §e禁运ID: §f" + embargo.embargoId());
    player.sendMessage("  §e资源: §f" + formatResourceName(resourceId));
    player.sendMessage("  §e目标: §f" + targetNation.name());
    return true;
  }

  private boolean handleEmbargoLift(Player player, Nation nation, String embargoIdInput) {
    List<ResourceEmbargo> initiated = List.copyOf(tradeService.getEmbargoesBy(nation.id()));
    UUID embargoId =
        resolveObjectId(
            player,
            embargoIdInput,
            initiated.stream().map(ResourceEmbargo::embargoId).toList(),
            "禁运");
    if (embargoId == null) {
      return true;
    }

    boolean lifted = tradeService.liftEmbargo(nation.id(), embargoId);
    player.sendMessage(lifted ? "§a禁运已解除。" : "§c禁运解除失败，禁运可能已结束。");
    return true;
  }

  private boolean handleEmbargoEdit(Player player, Nation nation, String[] args) {
    if (args.length < 5) {
      player.sendMessage("§c用法: /resource trade embargo edit " + "<禁运ID> <duration|reason> [值]");
      return true;
    }

    List<ResourceEmbargo> initiated = List.copyOf(tradeService.getEmbargoesBy(nation.id()));
    UUID embargoId =
        resolveObjectId(
            player, args[3], initiated.stream().map(ResourceEmbargo::embargoId).toList(), "禁运");
    if (embargoId == null) {
      return true;
    }

    String field = args[4].toLowerCase(Locale.ROOT);
    if (!field.equals("duration") && !field.equals("reason")) {
      player.sendMessage("§c未知编辑选项: " + field);
      player.sendMessage("§e可用选项: duration, reason");
      return true;
    }
    if (field.equals("duration") && args.length > 5) {
      try {
        long days = Long.parseLong(args[5]);
        long seconds = Math.multiplyExact(days, 86_400L);
        if (seconds < 1 || seconds > ResourceTradeTerms.MAX_DURATION_SECONDS) {
          player.sendMessage("§c有效期超出允许范围。");
          return true;
        }
      } catch (NumberFormatException | ArithmeticException exception) {
        player.sendMessage("§c有效期格式无效。");
        return true;
      }
    }

    player.sendMessage("§e当前禁运不可原地修改，请解除后重新创建。");
    player.sendMessage("§7禁运ID: §f" + embargoId);
    return true;
  }

  private String getNationDisplayName(NationId nationId) {
    return nationService
        .nationById(nationId)
        .map(Nation::name)
        .orElse(nationId.toString().substring(0, 8));
  }

  private boolean handleFactory(Player player, String[] args) {
    if (args.length < 2) {
      player.sendMessage("§e用法: /resource factory <list|recipes|start|collect|status>");
      return true;
    }
    Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
    if (nationOpt.isEmpty()) {
      player.sendMessage("§c你不在任何Nation中");
      return true;
    }

    Nation nation = nationOpt.get();
    String action = args[1].toLowerCase(Locale.ROOT);
    if (action.equals("start") || action.equals("collect") || action.equals("status"))
      return handleFactoryRun(player, nation, action, args);
    if (args.length != 2) {
      player.sendMessage("§e用法: /resource factory <list|recipes>");
      return true;
    }

    switch (action) {
      case "list" -> {
        var factories = processingService.getFactories(nation.id());
        player.sendMessage("§6§l==== 工厂列表 ====");

        if (factories.isEmpty()) {
          player.sendMessage("§7暂无工厂");
          return true;
        }

        for (var factory : factories) {
          String status =
              factory.isOperational() ? (factory.isProcessing() ? "§e加工中" : "§a运营中") : "§c停用";
          player.sendMessage(
              String.format("  §e%s: §f等级%d %s", factory.factoryName(), factory.level(), status));
          player.sendMessage("    §7工厂ID: " + factory.factoryId());
          processingService
              .activeFactoryRun(factory.factoryId())
              .ifPresentOrElse(
                  run -> player.sendMessage("    §7批次: " + run.runId() + "，到期: " + run.readyAt()),
                  () -> {
                    if (factory.isProcessing()) player.sendMessage("    §e旧活动批次缺少冻结凭据，需核对后处理。");
                  });
        }
        return true;
      }
      case "recipes" -> {
        var recipes = processingService.getAllRecipes();
        player.sendMessage("§6§l==== 加工配方 ====");

        for (var recipe : recipes) {
          String inputs =
              recipe.inputs().entrySet().stream()
                  .map(e -> e.getValue() + formatResourceName(e.getKey()))
                  .collect(Collectors.joining("+"));
          String outputs =
              recipe.outputs().entrySet().stream()
                  .map(e -> e.getValue() + formatResourceName(e.getKey()))
                  .collect(Collectors.joining("+"));

          player.sendMessage(
              String.format("  §e%s §7(%s):", recipe.recipeName(), recipe.recipeId()));
          player.sendMessage(String.format("    §7输入: §f%s", inputs));
          player.sendMessage(String.format("    §7输出: §a%s", outputs));
        }
        return true;
      }
      default -> {
        player.sendMessage("§c未知操作: " + action);
        return true;
      }
    }
  }

  private boolean handleFactoryRun(Player player, Nation nation, String action, String[] args) {
    if (action.equals("status")) {
      if (args.length != 3) {
        player.sendMessage("§e用法: /resource factory status <批次编号>");
        return true;
      }
      try {
        var run =
            processingService.factoryRun(args[2]).filter(r -> r.nationId().equals(nation.id()));
        if (run.isEmpty()) player.sendMessage("§e本国未找到该批次。");
        else
          player.sendMessage(
              "§e批次 "
                  + run.get().runId()
                  + "："
                  + (run.get().completed() ? "§a产出已提交" : "§7到期 " + run.get().readyAt()));
      } catch (IllegalArgumentException invalid) {
        player.sendMessage("§c批次编号格式无效。");
      } catch (IllegalStateException unavailable) {
        player.sendMessage("§e批次状态暂不可核实，请保留原编号稍后查询。");
      }
      return true;
    }
    if (!player.getUniqueId().equals(nation.founderId())) {
      player.sendMessage("§c只有当前国家创始人可以开始或收取工厂批次。");
      return true;
    }
    ProcessingService.FactoryResult result;
    try {
      if (action.equals("start")) {
        if (args.length != 6) {
          player.sendMessage("§e用法: /resource factory start <工厂ID> <配方ID> <批次数> <批次编号>");
          return true;
        }
        result =
            processingService.startFactoryRun(
                new ProcessingService.FactoryRequest(
                    args[5],
                    UUID.fromString(args[2]),
                    nation.id(),
                    player.getUniqueId(),
                    args[3],
                    Integer.parseInt(args[4])));
      } else {
        if (args.length != 3) {
          player.sendMessage("§e用法: /resource factory collect <批次编号>");
          return true;
        }
        result = processingService.completeFactoryRun(args[2], nation.id(), player.getUniqueId());
      }
    } catch (IllegalArgumentException invalid) {
      player.sendMessage("§c请核对工厂ID、配方和批次数（1 到 1000000）。批次编号仅可使用字母、数字、点、冒号、下划线及短横线，最长 96 字符。");
      return true;
    }
    player.sendMessage(
        switch (result.status()) {
          case STARTED -> "§a批次已保存，材料已扣除。到期: " + result.run().readyAt();
          case ALREADY_STARTED -> "§a该批次已开始，本次未重复扣料。";
          case COMPLETED -> "§a批次产出已存入国家库存。";
          case ALREADY_COMPLETED -> "§a该批次已完成，本次未重复发料。";
          case NOT_READY -> "§e批次尚未到期: " + result.run().readyAt();
          case BUSY -> "§e工厂已有活动批次，请先查询原批次。";
          case LEGACY_REVIEW_REQUIRED -> "§e旧活动批次缺少冻结凭据，需核对后处理。";
          case INSUFFICIENT_RESOURCES -> "§c国家库存材料不足，本次未开始加工。";
          case REJECTED -> "§c操作被拒绝，请核对工厂、配方、国家权限及批次编号。";
          case UNKNOWN -> "§e保存结果待核对，请保留原批次编号查询或重试，勿换编号提交。";
          case UNAVAILABLE -> "§e工厂存储暂不可用，请保留原批次编号稍后重试。";
        });
    return true;
  }

  private boolean handleOrder(Player player, String[] args) {
    if (marketOrderBookService == null) {
      player.sendMessage("§c市场订单服务暂不可用。");
      return true;
    }
    if (args.length < 2) {
      player.sendMessage("§c用法: /resource order <buy|sell|list|cancel|book>");
      return true;
    }

    String action = args[1].toLowerCase(Locale.ROOT);
    if (action.equals("buy") || action.equals("sell")) {
      Optional<Nation> nationOpt = nationService.nationOf(player.getUniqueId());
      if (nationOpt.isEmpty()) {
        player.sendMessage("§c你不在任何国家中，无法交易。");
        return true;
      }
      Nation nation = nationOpt.get();
      if (!requireNationPermission(player, nation, NationPermission.RESOURCE_MARKET_ORDER)) {
        return true;
      }
      return submitOrder(player, nation.id(), args, action.equals("buy"));
    }

    return switch (action) {
      case "list" -> handleOrderList(player);
      case "cancel" -> {
        if (args.length != 3) {
          player.sendMessage("§c用法: /resource order cancel <订单ID>");
          yield true;
        }
        yield handleOrderCancel(player, args[2]);
      }
      case "book" -> {
        if (args.length != 3) {
          player.sendMessage("§c用法: /resource order book <资源>");
          yield true;
        }
        yield handleOrderBook(player, args[2]);
      }
      default -> {
        player.sendMessage("§c未知操作: " + action);
        player.sendMessage("§e可用操作: list, buy, sell, cancel, book");
        yield true;
      }
    };
  }

  private boolean submitOrder(Player player, NationId nationId, String[] args, boolean buy) {
    if (args.length != 5) {
      player.sendMessage("§c用法: /resource order " + (buy ? "buy" : "sell") + " <资源> <数量> <价格>");
      return true;
    }

    long amount;
    double price;
    try {
      amount = Long.parseLong(args[3]);
      price = Double.parseDouble(args[4]);
    } catch (NumberFormatException exception) {
      player.sendMessage("§c数量或价格格式无效。");
      return true;
    }

    ResourceTradeTerms.Validation validation =
        ResourceTradeTerms.validateOrder(args[2], amount, price);
    if (!validation.isValid()) {
      player.sendMessage("§c" + describeViolation(validation.violation()));
      return true;
    }
    ResourceTradeTerms terms = validation.terms();

    List<TradeOrder> beforeOrders =
        safeOrders(marketOrderBookService.getPlayerOrders(player.getUniqueId()));
    Set<UUID> beforeIds =
        beforeOrders.stream().map(TradeOrder::orderId).collect(Collectors.toSet());
    java.time.Instant expiryTime = java.time.Instant.now().plus(java.time.Duration.ofHours(24));

    Optional<dev.starcore.starcore.module.resource.model.TradeRecord> immediateRecord =
        buy
            ? marketOrderBookService.submitBuyOrder(
                player.getUniqueId(),
                nationId,
                terms.resourceId(),
                terms.amount(),
                terms.pricePerUnitAsDouble(),
                expiryTime)
            : marketOrderBookService.submitSellOrder(
                player.getUniqueId(),
                nationId,
                terms.resourceId(),
                terms.amount(),
                terms.pricePerUnitAsDouble(),
                expiryTime);

    List<TradeOrder> afterOrders =
        safeOrders(marketOrderBookService.getPlayerOrders(player.getUniqueId()));
    TradeOrder created =
        afterOrders.stream()
            .filter(order -> !beforeIds.contains(order.orderId()))
            .findFirst()
            .orElse(null);
    if (created == null && immediateRecord.isEmpty()) {
      player.sendMessage("§c订单提交失败，请检查余额、资源和市场状态。");
      return true;
    }

    if (created != null && marketOrderBookService.requiresReconciliation(created.orderId())) {
      player.sendMessage("§e订单资产结果待核对，已暂停撮合和退款，请联系管理员并保留订单ID。");
      player.sendMessage("§7订单ID: " + created.orderId());
      return true;
    }

    player.sendMessage(immediateRecord.isPresent() ? "§a订单已立即成交。" : "§a订单已提交到订单簿。");
    player.sendMessage(
        "  §7资源: "
            + formatResourceName(terms.resourceId())
            + " §7数量: "
            + terms.amount()
            + " §7价格: "
            + terms.pricePerUnit().toPlainString());
    player.sendMessage("  §7总价值: " + terms.totalValue().toPlainString());
    if (created != null) {
      List<UUID> ids = afterOrders.stream().map(TradeOrder::orderId).toList();
      player.sendMessage(
          "  §7订单ID: " + ResourceObjectIdResolver.shortestUniquePrefix(created.orderId(), ids));
    }
    return true;
  }

  private boolean handleOrderList(Player player) {
    List<TradeOrder> orders =
        safeOrders(marketOrderBookService.getPlayerOrders(player.getUniqueId()));
    player.sendMessage("§6§l==== 我的订单 ====");
    if (orders.isEmpty()) {
      player.sendMessage("§7暂无订单");
      return true;
    }

    List<UUID> orderIds = orders.stream().map(TradeOrder::orderId).toList();
    for (TradeOrder order : orders) {
      String type = order.isBuyOrder() ? "§a买入" : "§c卖出";
      String status =
          marketOrderBookService.requiresReconciliation(order.orderId())
              ? "§e待核对（已暂停）"
              : getOrderStatusText(order.status());
      String displayedId = ResourceObjectIdResolver.shortestUniquePrefix(order.orderId(), orderIds);
      player.sendMessage(
          String.format(
              "  §7[§f%s§7] %s §7%s §f%d @ %.2f %s",
              displayedId,
              type,
              formatResourceName(order.resourceId()),
              order.remainingAmount(),
              order.pricePerUnit(),
              status));
    }
    return true;
  }

  private boolean handleOrderCancel(Player player, String orderIdInput) {
    List<TradeOrder> orders =
        safeOrders(marketOrderBookService.getPlayerOrders(player.getUniqueId()));
    UUID orderId =
        resolveObjectId(
            player, orderIdInput, orders.stream().map(TradeOrder::orderId).toList(), "订单");
    if (orderId == null) {
      return true;
    }

    boolean cancelled = marketOrderBookService.cancelOrder(player.getUniqueId(), orderId);
    if (!cancelled && marketOrderBookService.requiresReconciliation(orderId)) {
      player.sendMessage("§e订单资产结果待核对，已暂停退款，请联系管理员。订单ID: " + orderId);
      return true;
    }
    player.sendMessage(cancelled ? "§a订单已取消，托管资产已返还。" : "§c订单取消失败，订单可能已成交或过期。");
    return true;
  }

  private boolean handleOrderReview(CommandSender sender, String[] args) {
    if (!sender.hasPermission(PERMISSION_ADMIN)) {
      sender.sendMessage("§c你没有查询市场托管凭据的权限。");
      return true;
    }
    if (marketOrderBookService == null) {
      sender.sendMessage("§c市场订单服务暂不可用。");
      return true;
    }
    if (args.length > 3) {
      sender.sendMessage("§e用法: /resource order review [完整订单ID|after:上一页末尾ID]");
      return true;
    }
    try {
      List<dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot> entries;
      boolean single = args.length == 3 && !args[2].startsWith("after:");
      if (single) {
        entries = marketOrderBookService.escrowSnapshot(UUID.fromString(args[2])).stream().toList();
      } else {
        UUID after = args.length == 3 ? UUID.fromString(args[2].substring(6)) : null;
        entries = marketOrderBookService.escrowReviews(after, 20);
      }
      sender.sendMessage("§6市场托管凭据（只读）");
      if (entries.isEmpty()) sender.sendMessage("§7没有匹配的凭据。");
      for (var entry : entries) {
        var order = entry.order();
        sender.sendMessage("§e" + order.orderId() + " §7" + entry.phase() + " / " + order.type());
        sender.sendMessage("§7玩家: " + order.playerId() + " 国家: " + order.nationId());
        sender.sendMessage(
            "§7原始凭据: "
                + order.resourceId()
                + " 剩余数量="
                + order.remainingAmount()
                + " 货币="
                + entry.moneyRemaining().toPlainString());
        sender.sendMessage("§7操作: " + entry.operationId() + " 时间: " + entry.updatedAt());
        if (single) sender.sendMessage("§7步骤/计划: " + entry.detail());
      }
      if (!single && entries.size() == 20)
        sender.sendMessage(
            "§7下一页: /resource order review after:" + entries.getLast().order().orderId());
    } catch (IllegalArgumentException invalid) {
      sender.sendMessage("§c请输入完整且有效的订单 UUID。");
    } catch (RuntimeException failure) {
      LOGGER.log(Level.SEVERE, "Cannot read market escrow evidence", failure);
      sender.sendMessage("§c托管凭据暂不可读，请恢复对应存储后再查询。");
    }
    return true;
  }

  private boolean handleOrderBook(Player player, String resourceIdInput) {
    String resourceId = ResourceTradeTerms.normalizeResourceId(resourceIdInput);
    if (resourceId == null) {
      player.sendMessage("§c资源 ID 格式无效。");
      return true;
    }

    var snapshot = marketOrderBookService.getOrderBookSnapshot(resourceId);
    player.sendMessage("§6§l==== " + formatResourceName(resourceId) + " 订单簿 ====");
    player.sendMessage(
        String.format("  §7最佳买价: §a%.2f §7最佳卖价: §c%.2f", snapshot.bestBid(), snapshot.bestAsk()));
    player.sendMessage(
        String.format("  §7中间价: §f%.2f §7价差: §7%.2f", snapshot.midPrice(), snapshot.spread()));
    player.sendMessage(
        String.format(
            "  §7买单: §a%d §7卖单: §c%d", snapshot.buyOrderCount(), snapshot.sellOrderCount()));
    player.sendMessage(
        String.format(
            "  §7总买入量: §f%s §7总卖出量: §f%s",
            formatNumber(snapshot.totalBuyVolume()), formatNumber(snapshot.totalSellVolume())));
    return true;
  }

  private boolean handleHistory(Player player, String[] args) {
    int page = 1;
    if (args.length > 2) {
      player.sendMessage("§c用法: /resource history [页码]");
      return true;
    }
    if (args.length == 2) {
      try {
        page = Integer.parseInt(args[1]);
      } catch (NumberFormatException exception) {
        player.sendMessage("§c页码必须是整数。");
        return true;
      }
    }
    if (page < 1 || page > 100_000) {
      player.sendMessage("§c页码必须在 1 到 100000 之间。");
      return true;
    }

    int limit = 10;
    int offset = Math.multiplyExact(page - 1, limit);
    var records = tradeHistoryService.getPlayerRecords(player.getUniqueId(), offset, limit);
    player.sendMessage("§6§l==== 交易历史 (第" + page + "页) ====");
    if (records.isEmpty()) {
      player.sendMessage("§7暂无交易记录");
      return true;
    }

    for (var record : records) {
      String type = record.orderType() == TradeOrder.OrderType.BUY ? "§a买入" : "§c卖出";
      String time = record.executedAt().toString().substring(0, 16);
      player.sendMessage(
          String.format(
              "  %s §f%s §7x%d @ %.2f §7= %.2f",
              type,
              formatResourceName(record.resourceId()),
              record.amount(),
              record.pricePerUnit(),
              record.totalValue()));
      player.sendMessage(String.format("    §7时间: §f%s §7税收: §c%.2f", time, record.taxAmount()));
    }
    player.sendMessage("§7使用 /resource history " + (page + 1) + " 查看更多");
    return true;
  }

  private String getOrderStatusText(TradeOrder.OrderStatus status) {
    return switch (status) {
      case PENDING -> "§e待成交";
      case PARTIAL -> "§6部分成交";
      case FILLED -> "§a已完成";
      case CANCELLED -> "§7已取消";
      case EXPIRED -> "§c已过期";
    };
  }

  private boolean handleGive(CommandSender sender, String[] args) {
    if (!sender.hasPermission(PERMISSION_ADMIN)) {
      sender.sendMessage("§c你没有使用管理资源命令的权限。");
      return true;
    }
    if (args.length != 4) {
      sender.sendMessage("§c用法: /resource give <国家名称> <资源> <数量>");
      return true;
    }

    long amount;
    try {
      amount = Long.parseLong(args[3]);
    } catch (NumberFormatException exception) {
      sender.sendMessage("§c数量必须是整数。");
      return true;
    }
    ResourceTradeTerms.Validation validation = ResourceTradeTerms.validateTransfer(args[2], amount);
    if (!validation.isValid()) {
      sender.sendMessage("§c" + describeViolation(validation.violation()));
      return true;
    }

    Optional<Nation> nationOpt = nationService.nationByName(args[1]);
    if (nationOpt.isEmpty()) {
      sender.sendMessage("§c找不到国家: " + args[1]);
      return true;
    }
    ResourceTradeTerms terms = validation.terms();
    Nation nation = nationOpt.get();
    boolean granted = resourceService.grant(nation.id(), terms.resourceId(), terms.amount());
    sender.sendMessage(
        granted
            ? "§a已给予 "
                + nation.name()
                + " "
                + terms.amount()
                + " "
                + formatResourceName(terms.resourceId())
            : "§c资源发放失败。");
    return true;
  }

  private boolean requireNationPermission(
      Player player, Nation nation, NationPermission permission) {
    if (player.hasPermission(PERMISSION_ADMIN)) {
      return true;
    }
    if (!PermissionUtil.hasNationPermission(player, nation.id().value(), permission)) {
      player.sendMessage("§c你没有执行此国家资源操作的权限。");
      return false;
    }
    return true;
  }

  private UUID resolveObjectId(
      Player player, String input, Collection<UUID> ids, String objectName) {
    ResourceObjectIdResolver.Resolution resolution = ResourceObjectIdResolver.resolve(ids, input);
    return switch (resolution.status()) {
      case RESOLVED -> resolution.objectId();
      case INVALID -> {
        player.sendMessage("§c" + objectName + " ID 必须是至少 8 位十六进制前缀或完整 UUID。");
        yield null;
      }
      case NOT_FOUND -> {
        player.sendMessage("§c找不到属于当前操作者的" + objectName + "。");
        yield null;
      }
      case AMBIGUOUS -> {
        player.sendMessage("§c该" + objectName + " ID 匹配多个对象，请输入更多位。");
        yield null;
      }
    };
  }

  private static List<TradeOrder> safeOrders(Collection<TradeOrder> orders) {
    return orders == null ? List.of() : List.copyOf(orders);
  }

  private static String describeViolation(ResourceTradeTerms.Violation violation) {
    return switch (violation) {
      case INVALID_RESOURCE_ID -> "资源 ID 格式无效。";
      case AMOUNT_NON_POSITIVE -> "数量必须大于 0。";
      case AMOUNT_TOO_LARGE -> "数量超过系统上限。";
      case NON_FINITE_PRICE -> "价格不能是 NaN 或 Infinity。";
      case PRICE_NON_POSITIVE -> "价格必须大于 0。";
      case PRICE_TOO_LARGE -> "价格超过系统上限。";
      case TOTAL_TOO_SMALL -> "总价值四舍五入后必须大于 0。";
      case TOTAL_TOO_LARGE -> "总价值超过系统上限。";
      case DURATION_OUT_OF_RANGE -> "有效期超出允许范围。";
    };
  }

  private void sendHelp(Player player) {
    player.sendMessage("§6§l==== 资源命令帮助 ====");
    player.sendMessage("  §e/resource info §7- 查看资源总览");
    player.sendMessage("  §e/resource stockpile §7- 查看资源储量");
    player.sendMessage("  §e/resource market §7- 查看市场价格");
    player.sendMessage("  §e/resource reserve <add|release|info> §7- 管理战略储备");
    player.sendMessage("  §e/resource trade <routes|agreements|executions|embargo> §7- 贸易管理");
    player.sendMessage("  §e/resource trade agreements execute <协定ID> <执行编号> §7- 发起并确认一笔贸易");
    player.sendMessage(
        "  §e/resource trade executions <list|inspect|approve|retry> §7- 查询、确认和续办贸易");
    player.sendMessage("  §e/resource factory <list|recipes|start|collect|status> §7- 工厂管理与批次查询");
    player.sendMessage("  §e/resource process <配方ID> <批次数> <操作编号> §7- 国家即时加工；同一编号可安全重试");
  }

  private boolean handleProcess(Player player, String[] args) {
    if (args.length != 4) {
      player.sendMessage("§e用法: /resource process <配方ID> <批次数> <操作编号>");
      player.sendMessage("§7同一笔加工重试时使用原操作编号；新一笔加工使用新编号。");
      return true;
    }
    var nation = nationService.nationOf(player.getUniqueId());
    if (nation.isEmpty() || !player.getUniqueId().equals(nation.get().founderId())) {
      player.sendMessage("§c只有当前国家创始人可以提交国家即时加工。");
      return true;
    }
    ProcessingService.ProductionRequest request;
    try {
      request =
          new ProcessingService.ProductionRequest(
              args[3], nation.get().id(), player.getUniqueId(), args[1], Integer.parseInt(args[2]));
    } catch (IllegalArgumentException invalid) {
      player.sendMessage("§c批次数须为 1 到 1000000 的整数；操作编号和配方仅可使用字母、数字、点、冒号、下划线及短横线，最长 128 字符。");
      return true;
    }
    var result = processingService.process(request);
    player.sendMessage(
        switch (result.status()) {
          case APPLIED -> "§a国家加工已提交，产出已存入国家库存。编号: " + request.operationId();
          case ALREADY_APPLIED -> "§a该编号的加工已完成，本次未重复扣料或发料。";
          case INSUFFICIENT_RESOURCES -> "§c国家库存材料不足，本次未执行加工。";
          case REJECTED -> "§c加工被拒绝，请核对配方、国家权限和操作编号是否已用于其他加工。";
          case UNKNOWN -> "§e保存结果待核对，请保留原操作编号重试，勿换编号重复提交。";
          case UNAVAILABLE -> "§c加工存储暂不可用，请保留原操作编号稍后重试。";
        });
    return true;
  }

  // ==================== 辅助方法 ====================

  private String getResourceIcon(String resourceId) {
    return switch (resourceId.toLowerCase(Locale.ROOT)) {
      case "food" -> "⚘";
      case "timber" -> "▤";
      case "ore" -> "⚒";
      case "oil" -> "▣";
      case "rare_metal" -> "◆";
      default -> "▣";
    };
  }

  private String formatResourceName(String resourceId) {
    return switch (resourceId.toLowerCase(Locale.ROOT)) {
      case "food" -> "食物";
      case "timber" -> "木材";
      case "ore" -> "矿石";
      case "oil" -> "石油";
      case "rare_metal" -> "稀有金属";
      default -> resourceId;
    };
  }

  private String getStateColor(ResourcePrice.MarketState state) {
    return switch (state) {
      case SHORTAGE -> "§c";
      case HIGH_DEMAND -> "§e";
      case BALANCED -> "§a";
      case LOW_DEMAND -> "§7";
      case OVERSUPPLY -> "§9";
    };
  }

  private String createProgressBar(double progress) {
    int filled = (int) (progress * 10);
    StringBuilder bar = new StringBuilder("§7[");
    for (int i = 0; i < 10; i++) {
      if (i < filled) {
        bar.append(progress >= 1.0 ? "§a█" : "§e█");
      } else {
        bar.append("§8░");
      }
    }
    bar.append("§7] ");
    bar.append(progress >= 1.0 ? "§a完成" : String.format("§e%.0f%%", progress * 100));
    return bar.toString();
  }

  private String formatNumber(long number) {
    if (number >= 1_000_000_000) {
      return String.format("%.1fB", number / 1_000_000_000.0);
    } else if (number >= 1_000_000) {
      return String.format("%.1fM", number / 1_000_000.0);
    } else if (number >= 1_000) {
      return String.format("%.1fK", number / 1_000.0);
    }
    return String.valueOf(number);
  }

  @Override
  public List<String> onTabComplete(
      CommandSender sender, Command command, String alias, String[] args) {
    if (!(sender instanceof Player player)
        || (!player.hasPermission(PERMISSION_USE) && !player.hasPermission(PERMISSION_ADMIN))) {
      return Collections.emptyList();
    }

    try {
      if (args.length == 1) {
        List<String> options =
            new ArrayList<>(
                List.of(
                    "info",
                    "stockpile",
                    "market",
                    "reserve",
                    "price",
                    "agreements",
                    "trade",
                    "embargo",
                    "order",
                    "history",
                    "factory",
                    "process",
                    "help"));
        if (player.hasPermission(PERMISSION_ADMIN)) {
          options.add("give");
        }
        return filterCompletions(args[0], options);
      }

      if (args.length == 2) {
        return switch (args[0].toLowerCase(Locale.ROOT)) {
          case "factory" ->
              filterCompletions(args[1], List.of("list", "recipes", "start", "collect", "status"));
          case "process" ->
              filterCompletions(
                  args[1],
                  processingService.getAllRecipes().stream().map(r -> r.recipeId()).toList());
          case "reserve", "r" -> filterCompletions(args[1], List.of("list", "add", "release"));
          case "trade" ->
              filterCompletions(args[1], List.of("routes", "agreements", "executions", "embargo"));
          case "agreements", "agreement" ->
              filterCompletions(args[1], List.of("list", "create", "edit", "cancel"));
          case "embargo", "embargoes" ->
              filterCompletions(args[1], List.of("list", "create", "lift", "edit"));
          case "order", "orders" ->
              filterCompletions(
                  args[1],
                  player.hasPermission(PERMISSION_ADMIN)
                      ? List.of("list", "buy", "sell", "cancel", "book", "review")
                      : List.of("list", "buy", "sell", "cancel", "book"));
          case "history", "records" ->
              filterCompletions(args[1], List.of("player", "nation", "resource", "recent"));
          default -> Collections.emptyList();
        };
      }

      if (args.length == 3) {
        String root = args[0].toLowerCase(Locale.ROOT);
        String action = args[1].toLowerCase(Locale.ROOT);

        if (root.equals("trade") && action.equals("agreements"))
          return filterCompletions(args[2], List.of("list", "create", "edit", "cancel", "execute"));
        if (root.equals("trade") && action.equals("executions"))
          return filterCompletions(args[2], List.of("list", "inspect", "approve", "retry"));
        if (root.equals("trade") && action.equals("embargo"))
          return filterCompletions(args[2], List.of("list", "create", "lift", "edit"));

        if ((root.equals("reserve") || root.equals("r"))
            && (action.equals("add") || action.equals("release"))) {
          return filterCompletions(args[2], resourceService.availableResourceTypes());
        }

        if ((root.equals("agreements") || root.equals("agreement") || root.equals("trade"))
            && action.equals("create")) {
          return filterCompletions(
              args[2], nationService.nations().stream().map(Nation::name).toList());
        }

        if ((root.equals("agreements") || root.equals("agreement") || root.equals("trade"))
            && (action.equals("edit") || action.equals("cancel"))) {
          if (tradeService == null) {
            return Collections.emptyList();
          }
          Optional<Nation> nation = nationService.nationOf(player.getUniqueId());
          if (nation.isEmpty()) {
            return Collections.emptyList();
          }
          Collection<TradeAgreement> agreements =
              tradeService.getTradeAgreements(nation.orElseThrow().id());
          return filterCompletions(
              args[2],
              ResourceObjectIdResolver.suggestions(
                  agreements.stream().map(TradeAgreement::agreementId).toList()));
        }

        if ((root.equals("embargo") || root.equals("embargoes")) && action.equals("create")) {
          return filterCompletions(
              args[2], nationService.nations().stream().map(Nation::name).toList());
        }

        if ((root.equals("embargo") || root.equals("embargoes"))
            && (action.equals("lift") || action.equals("edit"))) {
          if (tradeService == null) {
            return Collections.emptyList();
          }
          Optional<Nation> nation = nationService.nationOf(player.getUniqueId());
          if (nation.isEmpty()) {
            return Collections.emptyList();
          }
          Collection<ResourceEmbargo> embargoes =
              tradeService.getEmbargoesBy(nation.orElseThrow().id());
          return filterCompletions(
              args[2],
              ResourceObjectIdResolver.suggestions(
                  embargoes.stream().map(ResourceEmbargo::embargoId).toList()));
        }

        if ((root.equals("order") || root.equals("orders"))
            && (action.equals("buy") || action.equals("sell") || action.equals("book"))) {
          return filterCompletions(args[2], resourceService.availableResourceTypes());
        }

        if ((root.equals("order") || root.equals("orders")) && action.equals("cancel")) {
          if (marketOrderBookService == null) {
            return Collections.emptyList();
          }
          List<TradeOrder> orders =
              safeOrders(marketOrderBookService.getPlayerOrders(player.getUniqueId()));
          return filterCompletions(
              args[2],
              ResourceObjectIdResolver.suggestions(
                  orders.stream().map(TradeOrder::orderId).toList()));
        }
      }

      if (args.length == 4) {
        String root = args[0].toLowerCase(Locale.ROOT);
        String action = args[1].toLowerCase(Locale.ROOT);
        if (root.equals("trade") && tradeService != null) {
          var nation = nationService.nationOf(player.getUniqueId());
          if (nation.isEmpty()) return List.of();
          if (action.equals("executions")
              && Set.of("inspect", "approve", "retry").contains(args[2].toLowerCase(Locale.ROOT)))
            return filterCompletions(
                args[3],
                tradeService.tradeExecutions(nation.get().id(), 0, 100).stream()
                    .map(TradeExecution::executionId)
                    .toList());
          if (action.equals("agreements")
              && Set.of("execute", "edit", "cancel").contains(args[2].toLowerCase(Locale.ROOT)))
            return filterCompletions(
                args[3],
                ResourceObjectIdResolver.suggestions(
                    tradeService.getTradeAgreements(nation.get().id()).stream()
                        .map(TradeAgreement::agreementId)
                        .toList()));
        }
        if ((root.equals("agreements")
                || root.equals("agreement")
                || root.equals("trade")
                || root.equals("embargo")
                || root.equals("embargoes"))
            && action.equals("create")) {
          return filterCompletions(args[3], resourceService.availableResourceTypes());
        }
      }

      return Collections.emptyList();
    } catch (RuntimeException exception) {
      LOGGER.log(
          Level.WARNING,
          "[ResourceCommand] tab completion failed; player="
              + player.getUniqueId()
              + ", alias="
              + alias
              + ", args="
              + Arrays.toString(args),
          exception);
      return Collections.emptyList();
    }
  }

  private static List<String> filterCompletions(String input, Collection<String> options) {
    if (options == null) {
      return Collections.emptyList();
    }
    String prefix = input == null ? "" : input.toLowerCase(Locale.ROOT);
    return options.stream()
        .filter(Objects::nonNull)
        .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(prefix))
        .distinct()
        .sorted()
        .toList();
  }
}
