package dev.starcore.starcore.module.resource;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Explicit versioned encoding: timestamps and decimals never pass through floating point JSON. */
final class MarketOrderCodec {
  private MarketOrderCodec() {}

  static String encode(MarketEscrowSnapshot entry) {
    var order = entry.order();
    JsonObject json = new JsonObject();
    json.addProperty("version", 1);
    json.addProperty("id", order.orderId().toString());
    json.addProperty("type", order.type().name());
    json.addProperty("source", order.source().name());
    json.addProperty("player", order.playerId().toString());
    json.addProperty("nation", order.nationId().toString());
    json.addProperty("resource", order.resourceId());
    json.addProperty("price", Double.toString(order.pricePerUnit()));
    json.addProperty("total", order.totalAmount());
    json.addProperty("remaining", order.remainingAmount());
    json.addProperty("created", order.createdAt().toString());
    json.addProperty("expiry", order.expiryTime().toString());
    json.addProperty("status", order.status().name());
    json.addProperty("market", order.isMarketOrder());
    json.addProperty("fillPrice", Double.toString(order.fillPrice()));
    json.addProperty("filled", order.filledAmount());
    json.addProperty("escrow", entry.moneyRemaining().toPlainString());
    json.addProperty("phase", entry.phase().name());
    json.addProperty("operation", entry.operationId().toString());
    json.addProperty("detail", entry.detail());
    json.addProperty("updated", entry.updatedAt().toString());
    json.addProperty("revision", entry.revision());
    return json.toString();
  }

  static MarketEscrowSnapshot decode(String payload) {
    if (payload == null || payload.length() > 32_768)
      throw new IllegalStateException("Invalid market order payload length");
    JsonObject json = JsonParser.parseString(payload).getAsJsonObject();
    if (json.get("version").getAsInt() != 1)
      throw new IllegalStateException("Unsupported market order payload version");
    return new MarketEscrowSnapshot(
        new TradeOrder.OrderSnapshot(
            UUID.fromString(json.get("id").getAsString()),
            TradeOrder.OrderType.valueOf(json.get("type").getAsString()),
            TradeOrder.OrderSource.valueOf(json.get("source").getAsString()),
            UUID.fromString(json.get("player").getAsString()),
            NationId.of(UUID.fromString(json.get("nation").getAsString())),
            json.get("resource").getAsString(),
            Double.parseDouble(json.get("price").getAsString()),
            json.get("total").getAsLong(),
            json.get("remaining").getAsLong(),
            Instant.parse(json.get("created").getAsString()),
            Instant.parse(json.get("expiry").getAsString()),
            TradeOrder.OrderStatus.valueOf(json.get("status").getAsString()),
            json.get("market").getAsBoolean(),
            Double.parseDouble(json.get("fillPrice").getAsString()),
            json.get("filled").getAsLong()),
        new BigDecimal(json.get("escrow").getAsString()),
        MarketEscrowSnapshot.Phase.valueOf(json.get("phase").getAsString()),
        UUID.fromString(json.get("operation").getAsString()),
        json.get("detail").getAsString(),
        Instant.parse(json.get("updated").getAsString()),
        json.get("revision").getAsLong());
  }

  /** The old public expiry setter is supported; it cannot change quantities or escrow identity. */
  static void requireSameAssets(TradeOrder.OrderSnapshot stored, TradeOrder.OrderSnapshot current) {
    var withOriginalExpiry =
        new TradeOrder.OrderSnapshot(
            current.orderId(),
            current.type(),
            current.source(),
            current.playerId(),
            current.nationId(),
            current.resourceId(),
            current.pricePerUnit(),
            current.totalAmount(),
            current.remainingAmount(),
            current.createdAt(),
            stored.expiryTime(),
            current.status(),
            current.isMarketOrder(),
            current.fillPrice(),
            current.filledAmount());
    if (!stored.equals(withOriginalExpiry))
      throw new IllegalStateException("Live order differs from durable escrow evidence");
  }
}
