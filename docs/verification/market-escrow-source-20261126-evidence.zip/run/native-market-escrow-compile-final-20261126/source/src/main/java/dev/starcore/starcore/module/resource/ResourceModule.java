package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.animation.GuiAnimationManager;
import dev.starcore.starcore.foundation.animation.SoundFeedbackManager;
import dev.starcore.starcore.foundation.economy.insurance.EconomyInsuranceService;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.message.MessageService;
import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.module.business.BusinessService;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.policy.PolicyService;
import dev.starcore.starcore.module.policy.model.PolicyEffectScope;
import dev.starcore.starcore.module.resource.command.ResourceCommand;
import dev.starcore.starcore.module.resource.gui.PlayerTradeGuiListener;
import dev.starcore.starcore.module.resource.gui.ResourceMenu;
import dev.starcore.starcore.module.resource.gui.ResourceMenuListener;
import dev.starcore.starcore.module.resource.listener.ResourceListener;
import dev.starcore.starcore.module.resource.model.Factory;
import dev.starcore.starcore.module.resource.model.ProcessingRecipe;
import dev.starcore.starcore.module.resource.model.ResourceType;
import dev.starcore.starcore.module.treasury.TaxationService;
import dev.starcore.starcore.module.treasury.TreasuryService;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class ResourceModule
    implements StarCoreModule, ResourceService, NationResourceTransactionService {
  private static final String FILE_NAME = "resources.properties";

  // 资源类型定义 - 与 ResourceType 枚举对齐
  // 使用小写下划线格式以保持向后兼容
  static final Set<String> RESOURCE_TYPES =
      Set.of(
          ResourceType.MINERAL.name().toLowerCase(), // mineral - 矿产
          ResourceType.AGRICULTURAL.name().toLowerCase(), // agricultural - 农业
          ResourceType.ENERGY.name().toLowerCase(), // energy - 能源
          ResourceType.LUXURY.name().toLowerCase(), // luxury - 奢侈品
          ResourceType.INDUSTRIAL.name().toLowerCase(), // industrial - 工业原料
          ResourceType.CHEMICAL.name().toLowerCase(), // chemical - 化工产品
          ResourceType.STRATEGIC.name().toLowerCase() // strategic - 战略物资
          );

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "resource",
          "资源核心",
          ModuleLayer.MODULE,
          List.of("nation", "treasury"),
          List.of(ResourceService.class, NationResourceTransactionService.class),
          "Owns national strategic resource stockpiles for industry, war, and technology.");

  // 核心储量数据
  private final ConcurrentMap<NationId, ConcurrentMap<String, Long>> stockpiles =
      new ConcurrentHashMap<>();
  private final ConcurrentMap<String, TransactionReceipt> resourceTransactionReceipts =
      new ConcurrentHashMap<>();
  private volatile String resourceAuthorityDomainId = "";
  private volatile boolean resourceStateUncertain;
  // These maps share the stockpile transaction monitor; service callers receive detached factories.
  private final Map<UUID, Factory> nativeFactories = new LinkedHashMap<>();
  private final Map<String, FactoryRun> factoryRuns = new LinkedHashMap<>();
  private final Map<String, TradeExecution> tradeExecutions = new LinkedHashMap<>();
  private java.time.Clock factoryClock = java.time.Clock.systemUTC();
  private ResourceStateStorage stateStorage;
  private PolicyService policyService;
  private NationService nationService;
  private OnlinePlayerDirectory onlinePlayerDirectory;

  // 子服务实例
  private SimpleResourcePriceService priceService;
  private SimpleResourceMonopolyService monopolyService;
  private SimpleResourceTradeService tradeService;
  private SimpleResourceReserveService reserveService;
  private SimpleProcessingService processingService;
  // 市场交易服务
  private SimpleMarketOrderBookService marketOrderBookService;
  private SimpleTradeHistoryService tradeHistoryService;
  private SimplePlayerTradeService playerTradeService;
  private SimpleTradeTaxService tradeTaxService;
  // NPC 市场服务
  private InMemoryNpcMarketExchange npcMarketExchange;
  private NpcMarketSnapshot npcMarketSnapshot;

  // GUI 和监听器
  private ResourceMenu resourceMenu;
  private ResourceMenuListener menuListener;
  private ResourceListener resourceListener;

  // 动画服务
  private GuiAnimationManager animationManager;
  private SoundFeedbackManager soundManager;

  // 语言消息服务
  private MessageService messages;

  // 上下文
  private StarCoreContext context;
  private StarCoreScheduler scheduler;
  private StarCoreEventBus eventBus;
  private JavaPlugin plugin;
  private ServiceRegistry serviceRegistry;
  private final List<BukkitTask> scheduledTasks = new ArrayList<>();

  public ResourceModule() {}

  ResourceModule(ResourceStateStorage stateStorage) {
    this(stateStorage, java.time.Clock.systemUTC());
  }

  ResourceModule(ResourceStateStorage stateStorage, java.time.Clock factoryClock) {
    this.stateStorage = stateStorage;
    this.factoryClock = java.util.Objects.requireNonNull(factoryClock);
    loadState();
  }

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  @Override
  public void enable(StarCoreContext context) {
    this.context = context;
    this.plugin = context.plugin();
    this.scheduler = context.scheduler();
    this.eventBus = context.eventBus();
    this.serviceRegistry = context.serviceRegistry();

    // 初始化动画服务
    this.animationManager = new GuiAnimationManager(plugin);
    this.soundManager = new SoundFeedbackManager(plugin);

    // 初始化消息服务
    this.messages = context.serviceRegistry().require(MessageService.class);

    context.persistenceService().ensureNamespace(metadata().id());
    this.stateStorage =
        new DatabaseAwareResourceStateStorage(
            metadata().id(),
            context.databaseService(),
            context.persistenceService(),
            context.plugin().getLogger());

    // 获取依赖服务
    this.policyService = context.serviceRegistry().find(PolicyService.class).orElse(null);
    this.nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    this.onlinePlayerDirectory =
        context.serviceRegistry().find(OnlinePlayerDirectory.class).orElse(null);

    // 初始化子服务
    initializeServices();

    // 加载状态
    loadState();
    try {
      this.marketOrderBookService.initializeOrderStorage(
          context
              .persistenceService()
              .namespacePath(metadata().id())
              .resolve("market-orders.sqlite"));
    } catch (java.io.IOException failure) {
      throw new IllegalStateException("Market escrow storage directory unavailable", failure);
    }

    // 注册命令
    registerCommands();

    // 注册监听器
    registerListeners();

    // 启动定时任务
    startScheduledTasks();

    // 注册到服务注册表
    registerToServiceRegistry();

    plugin.getLogger().info("ResourceModule enabled successfully");
  }

  /** 初始化所有子服务 */
  private void initializeServices() {
    // 税收服务（最先初始化，其他服务依赖它）
    this.tradeTaxService = new SimpleTradeTaxService(context.databaseService());
    serviceRegistry
        .find(dev.starcore.starcore.module.treasury.TreasuryService.class)
        .ifPresent(this.tradeTaxService::setTreasuryService);

    // 价格服务
    this.priceService = new SimpleResourcePriceService();
    this.priceService.initializeDefaultPrices();

    // 垄断服务
    this.monopolyService = new SimpleResourceMonopolyService(this);
    for (String resourceType : RESOURCE_TYPES) {
      this.monopolyService.registerResourceType(resourceType);
    }

    // 贸易服务
    this.tradeService =
        new SimpleResourceTradeService(
            this, serviceRegistry.find(TreasuryService.class).orElse(null));
    this.tradeService.setEventBus(eventBus);

    // 储备服务
    this.reserveService = new SimpleResourceReserveService(this);

    // 加工服务
    this.processingService = new SimpleProcessingService(this, this.priceService);
    this.processingService.initializeDefaultRecipes();

    // 市场订单簿服务
    this.marketOrderBookService =
        new SimpleMarketOrderBookService(
            this,
            serviceRegistry
                .find(dev.starcore.starcore.foundation.economy.EconomyService.class)
                .orElse(null),
            this.tradeTaxService,
            createResourceTariff(serviceRegistry));
    this.marketOrderBookService.setEventBus(eventBus);
    this.marketOrderBookService.setPriceService(this.priceService);

    // 交易历史服务
    this.tradeHistoryService = new SimpleTradeHistoryService(context.databaseService(), null);
    this.marketOrderBookService.setTradeHistoryService(tradeHistoryService);
    serviceRegistry
        .find(dev.starcore.starcore.foundation.economy.transaction.TransactionFabric.class)
        .ifPresent(this.marketOrderBookService::setTransactionFabric);

    // 玩家交易服务
    this.playerTradeService =
        new SimplePlayerTradeService(
            this,
            serviceRegistry
                .find(dev.starcore.starcore.foundation.economy.EconomyService.class)
                .orElse(null),
            this.tradeTaxService,
            this.marketOrderBookService,
            null,
            serviceRegistry,
            plugin);
    this.playerTradeService.setNationService(nationService);
    this.playerTradeService.setEventBus(eventBus);
    this.playerTradeService.setTradeHistoryService(tradeHistoryService);
    serviceRegistry
        .find(EconomyInsuranceService.class)
        .ifPresent(
            insurance ->
                insurance.registerSettlementHandler(
                    RefundOwner.TRADE,
                    (policy, source) -> this.playerTradeService.settleInsuredTradeRefund(source)));

    // NPC 市场服务（引导储备：与 ResourceModuleNpcMarketRestartTest 的 bootstrap 口径一致）
    dev.starcore.starcore.module.resource.model.NationalReserve bootstrapReserve =
        reserveService.createReserve(dev.starcore.starcore.module.nation.model.NationId.random());
    for (String resourceType : availableResourceTypes()) {
      bootstrapReserve.addReserve(resourceType, 10_000L);
    }
    this.npcMarketExchange =
        new InMemoryNpcMarketExchange(this, bootstrapReserve, java.math.BigDecimal.ZERO);
    this.npcMarketSnapshot = npcMarketExchange.snapshot();

    // GUI
    this.resourceMenu =
        new ResourceMenu(
            this,
            priceService,
            reserveService,
            marketOrderBookService,
            tradeHistoryService,
            playerTradeService,
            nationService,
            animationManager,
            soundManager,
            messages);

    // 监听器
    this.resourceListener =
        new ResourceListener(
            this,
            priceService,
            tradeService,
            reserveService,
            processingService,
            resourceMenu,
            eventBus,
            nationService);

    // GUI 监听器
    this.menuListener =
        new ResourceMenuListener(
            this,
            resourceMenu,
            this,
            priceService,
            reserveService,
            marketOrderBookService,
            tradeHistoryService,
            playerTradeService,
            nationService,
            soundManager,
            messages);
  }

  /** 注册命令 */
  private void registerCommands() {
    if (plugin == null) {
      return;
    }

    var command = plugin.getCommand("resource");
    if (command != null) {
      var resourceCommand =
          new ResourceCommand(
              this,
              priceService,
              tradeService,
              reserveService,
              processingService,
              nationService,
              onlinePlayerDirectory);
      // 设置市场交易服务
      resourceCommand.setMarketOrderBookService(marketOrderBookService);
      resourceCommand.setTradeHistoryService(tradeHistoryService);
      resourceCommand.setPlayerTradeService(playerTradeService);
      resourceCommand.setTradeTaxService(tradeTaxService);
      command.setExecutor(resourceCommand);
      command.setTabCompleter(resourceCommand);
      plugin.getLogger().info("Resource command registered.");
    } else {
      plugin.getLogger().warning("Command 'resource' not found in plugin.yml");
    }

    // 注册打开 GUI 的命令
    var guiCommand = plugin.getCommand("resourcegui");
    if (guiCommand != null) {
      guiCommand.setExecutor(
          (sender, cmd, label, args) -> {
            if (sender instanceof org.bukkit.entity.Player player) {
              resourceMenu.openMainMenu(player);
            } else {
              sender.sendMessage("§c只有玩家可以使用此命令");
            }
            return true;
          });
      plugin.getLogger().info("ResourceGUI command registered.");
    }

    // 注册交易命令
    var tradeCommand = plugin.getCommand("trade");
    if (tradeCommand != null) {
      var tradeCmd = new dev.starcore.starcore.module.resource.command.TradeCommand();
      tradeCmd.setPlayerTradeService(playerTradeService);
      tradeCmd.setNationService(nationService);
      tradeCmd.setEconomyService(
          serviceRegistry
              .find(dev.starcore.starcore.foundation.economy.EconomyService.class)
              .orElse(null));
      tradeCmd.setTradeTaxService(tradeTaxService);
      tradeCommand.setExecutor(tradeCmd);
      tradeCommand.setTabCompleter(tradeCmd);
      plugin.getLogger().info("Trade command registered.");
    } else {
      plugin.getLogger().warning("Command 'trade' not found in plugin.yml");
    }
  }

  /** 注册事件监听器 */
  private void registerListeners() {
    if (plugin == null) {
      return;
    }

    plugin.getServer().getPluginManager().registerEvents(resourceListener, plugin);
    plugin.getServer().getPluginManager().registerEvents(menuListener, plugin);
    plugin.getServer().getPluginManager().registerEvents(new PlayerTradeGuiListener(), plugin);
    plugin.getLogger().info("Resource listeners registered.");

    // 订阅贸易事件
    resourceListener.subscribeToTradeEvents();
  }

  /** 启动定时任务 */
  private void startScheduledTasks() {
    if (scheduler == null) {
      return;
    }

    // 每5分钟刷新所有价格
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              priceService.refreshAllPrices();
            },
            5 * 60 * 20L,
            5 * 60 * 20L));

    // 每10分钟刷新垄断数据
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              monopolyService.refreshMonopolies();
            },
            10 * 60 * 20L,
            10 * 60 * 20L));

    // 每分钟刷新工厂
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              processingService.refreshFactories();
            },
            60 * 20L,
            60 * 20L));

    // 每小时重置过期配额
    scheduledTasks.add(
        scheduler.runSyncTimer(() -> tradeService.recoverExecutions(32), 60 * 20L, 60 * 20L));

    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              tradeService.resetExpiredQuotas();
            },
            60 * 60 * 20L,
            60 * 60 * 20L));

    // 每30秒匹配市场订单
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              marketOrderBookService.matchAllOrders();
            },
            30 * 20L,
            30 * 20L));

    // 每分钟清理过期订单
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              marketOrderBookService.cleanExpiredOrders();
            },
            60 * 20L,
            60 * 20L));

    // 每分钟清理过期玩家交易请求
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              playerTradeService.cleanExpiredOffers();
            },
            60 * 20L,
            60 * 20L));

    // Reconcile a bounded page of prepared trades, including market matches and later refunds.
    scheduledTasks.add(
        scheduler.runSyncTimer(
            () -> {
              try {
                playerTradeService.reconcileTradeHistory();
              } catch (RuntimeException failure) {
                plugin
                    .getLogger()
                    .log(
                        java.util.logging.Level.SEVERE,
                        "Trade history reconciliation failed",
                        failure);
              }
            },
            20L,
            20 * 20L));

    plugin.getLogger().info("Resource scheduled tasks started.");
  }

  /** 注册到服务注册表 */
  private void registerToServiceRegistry() {
    if (serviceRegistry == null) {
      return;
    }

    // 注册 ResourceService 主服务
    serviceRegistry.register(ResourceService.class, this);
    serviceRegistry.register(NationResourceTransactionService.class, this);

    // 注册子服务
    serviceRegistry.register(ResourcePriceService.class, priceService);
    serviceRegistry.register(ResourceMonopolyService.class, monopolyService);
    serviceRegistry.register(ResourceTradeService.class, tradeService);
    serviceRegistry.register(ResourceReserveService.class, reserveService);
    serviceRegistry.register(ProcessingService.class, processingService);
    serviceRegistry.register(MarketOrderBookService.class, marketOrderBookService);
    serviceRegistry.register(TradeHistoryService.class, tradeHistoryService);
    serviceRegistry.register(PlayerTradeService.class, playerTradeService);
    serviceRegistry.register(TradeTaxService.class, tradeTaxService);

    plugin.getLogger().info("Resource services registered to ServiceRegistry.");
  }

  @Override
  public void disable(StarCoreContext context) {
    scheduledTasks.forEach(BukkitTask::cancel);
    scheduledTasks.clear();
    if (resourceListener != null) {
      HandlerList.unregisterAll(resourceListener);
      resourceListener = null;
    }
    if (menuListener != null) {
      HandlerList.unregisterAll(menuListener);
      menuListener = null;
    }
    if (marketOrderBookService != null) {
      marketOrderBookService.refundOpenOrders();
    }
    if (serviceRegistry != null) {
      serviceRegistry.unregister(ResourceService.class);
      serviceRegistry.unregister(NationResourceTransactionService.class);
      serviceRegistry.unregister(ResourcePriceService.class);
      serviceRegistry.unregister(ResourceMonopolyService.class);
      serviceRegistry.unregister(ResourceTradeService.class);
      serviceRegistry.unregister(ResourceReserveService.class);
      serviceRegistry.unregister(ProcessingService.class);
      serviceRegistry.unregister(MarketOrderBookService.class);
      serviceRegistry.unregister(TradeHistoryService.class);
      serviceRegistry.unregister(PlayerTradeService.class);
      serviceRegistry.unregister(TradeTaxService.class);
    }
    flushState();
    plugin.getLogger().info("ResourceModule disabled.");
  }

  // ==================== ResourceService 接口实现 ====================

  @Override
  public Collection<String> availableResourceTypes() {
    return RESOURCE_TYPES.stream().sorted().toList();
  }

  @Override
  public synchronized Map<String, Long> stockpile(NationId nationId) {
    Map<String, Long> values = stockpiles.getOrDefault(nationId, new ConcurrentHashMap<>());
    Map<String, Long> snapshot = new LinkedHashMap<>();
    for (String type : availableResourceTypes()) {
      snapshot.put(type, Math.max(0L, values.getOrDefault(type, 0L)));
    }
    return Map.copyOf(snapshot);
  }

  @Override
  public synchronized long amount(NationId nationId, String resourceType) {
    if (nationId == null) {
      return 0L;
    }
    String type = normalizeResource(resourceType);
    if (!RESOURCE_TYPES.contains(type)) {
      return 0L;
    }
    return stockpiles.getOrDefault(nationId, new ConcurrentHashMap<>()).getOrDefault(type, 0L);
  }

  @Override
  public synchronized boolean grant(NationId nationId, String resourceType, long amount) {
    if (nationId == null || !inventoryWritesAvailable()) {
      return false;
    }
    String type = normalizeResource(resourceType);
    if (!RESOURCE_TYPES.contains(type) || amount <= 0) {
      return false;
    }
    // 应用国策效果加成
    long finalAmount = applyPolicyBonus(nationId, type, amount);
    // audit B-090: finalAmount 因 applyPolicyBonus 乘法可能远超 Long.MAX_VALUE 截断。
    //   safeAdd 截断到 Long.MAX_VALUE 后超出部分丢失但这里能至少不回卷。
    //   为保守起见若 baseAmount 已接近上限则拒绝 grant 以保护玩家产出
    if (amount > Long.MAX_VALUE - (Long.MAX_VALUE >>> 1)) {
      if (plugin != null)
        plugin
            .getLogger()
            .warning(
                "ResourceModule.grant rejected: baseAmount too large to apply policy bonus safely"
                    + " (nation="
                    + nationId
                    + ", type="
                    + type
                    + ", amount="
                    + amount
                    + ")");
      return false;
    }
    boolean hadStockpile = stockpiles.containsKey(nationId);
    ConcurrentMap<String, Long> nationStockpile =
        stockpiles.computeIfAbsent(nationId, ignored -> new ConcurrentHashMap<>());
    Long previous = nationStockpile.get(type);
    nationStockpile.put(type, safeAdd(previous == null ? 0L : previous, finalAmount));
    try {
      flushState();
    } catch (RuntimeException persistenceFailure) {
      restoreGrant(nationId, type, nationStockpile, previous, hadStockpile);
      reconcileResourceState();
      if (plugin != null) {
        plugin
            .getLogger()
            .warning(
                "Resource grant persistence failed (nation="
                    + nationId
                    + ", type="
                    + type
                    + ", amount="
                    + finalAmount
                    + ")");
      }
      return false;
    }

    // Supply must not be visible before the stockpile itself is durable.
    if (priceService != null) {
      priceService.addSupply(type, finalAmount);
    }
    return true;
  }

  /** 应用国策效果加成到资源产出 */
  private long applyPolicyBonus(NationId nationId, String resourceType, long baseAmount) {
    if (policyService == null) {
      return baseAmount;
    }
    // 获取生产加成（通用 production_bonus）
    double modifier =
        policyService.activePolicyModifier(nationId, "production_bonus", PolicyEffectScope.GLOBAL);
    if (modifier <= 0) {
      // audit B-091: modifier<=0 (含 admin 误配负值) 时直接返回原值，避免 baseAmount*(1+负mod) 回卷
      //   修饰加成语义应是非负放大；若需减产应使用其他字段。
      return baseAmount;
    }
    // audit B-091: 防止 baseAmount*(1+mod) 溢出。乘法前先对 modifier 设上限，并对大数用 BigDecimal 计算
    if (modifier > 10.0) modifier = 10.0;
    try {
      java.math.BigDecimal product =
          java.math.BigDecimal.valueOf(baseAmount)
              .multiply(java.math.BigDecimal.valueOf(1.0 + modifier));
      if (product.compareTo(java.math.BigDecimal.valueOf(Long.MAX_VALUE)) > 0) {
        return Long.MAX_VALUE;
      }
      return product.setScale(0, java.math.RoundingMode.HALF_UP).longValueExact();
    } catch (ArithmeticException e) {
      // 理论不会发生
      return baseAmount;
    }
  }

  private void restoreGrant(
      NationId nationId,
      String resourceType,
      ConcurrentMap<String, Long> nationStockpile,
      Long previous,
      boolean hadStockpile) {
    if (previous == null) {
      nationStockpile.remove(resourceType);
    } else {
      nationStockpile.put(resourceType, previous);
    }
    if (!hadStockpile && nationStockpile.isEmpty()) {
      stockpiles.remove(nationId, nationStockpile);
    }
  }

  @Override
  public synchronized boolean consume(NationId nationId, String resourceType, long amount) {
    if (nationId == null || !inventoryWritesAvailable()) {
      return false;
    }
    String type = normalizeResource(resourceType);
    // audit B-092: 区分"资源不存在"与"数量不足"两种 false 原因，便于调用方诊断
    if (!RESOURCE_TYPES.contains(type) || amount <= 0) {
      if (plugin != null)
        plugin
            .getLogger()
            .fine(
                "ResourceModule.consume rejected invalid input (nation="
                    + nationId
                    + ", type="
                    + resourceType
                    + ", amount="
                    + amount
                    + ")");
      return false;
    }
    boolean[] consumed = new boolean[] {false};
    boolean[] exists = new boolean[] {false};
    long[] previous = new long[] {0L};
    ConcurrentMap<String, Long> nationStockpile = stockpiles.get(nationId);
    if (nationStockpile == null) {
      return false;
    }
    nationStockpile.compute(
        type,
        (ignored, current) -> {
          long value = current == null ? 0L : current;
          previous[0] = value;
          if (value > 0) exists[0] = true;
          if (value < amount) {
            return value;
          }
          consumed[0] = true;
          return value - amount;
        });
    if (!consumed[0] && plugin != null) {
      plugin
          .getLogger()
          .fine(
              "ResourceModule.consume insufficient stock (nation="
                  + nationId
                  + ", type="
                  + type
                  + ", amount="
                  + amount
                  + ", exists="
                  + exists[0]
                  + ")");
    }
    if (consumed[0]) {
      // The deduction is not observable until its durable state succeeds.
      try {
        flushState();
      } catch (RuntimeException persistenceFailure) {
        stockpiles.get(nationId).put(type, previous[0]);
        reconcileResourceState();
        if (plugin != null) {
          plugin
              .getLogger()
              .warning(
                  "Resource consume persistence failed (nation="
                      + nationId
                      + ", type="
                      + type
                      + ", amount="
                      + amount
                      + ")");
        }
        return false;
      }
      // Demand must not be visible before the stockpile itself is durable.
      if (priceService != null) {
        priceService.addDemand(type, amount);
      }
    }
    return consumed[0];
  }

  @Override
  public synchronized TransactionResult consume(TransactionRequest request) {
    return applyResourceTransaction(request, Operation.CONSUME);
  }

  @Override
  public synchronized TransactionResult grant(TransactionRequest request) {
    return applyResourceTransaction(request, Operation.GRANT);
  }

  @Override
  public synchronized Optional<TransactionReceipt> transactionReceipt(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      return Optional.empty();
    }
    if (!inventoryWritesAvailable())
      throw new IllegalStateException("Resource transaction state requires storage recovery");
    return Optional.ofNullable(resourceTransactionReceipts.get(transactionId));
  }

  @Override
  public synchronized TransferResult transfer(TransferRequest request) {
    if (request == null) throw new IllegalArgumentException("request must not be null");
    if (resourceAuthorityDomainId.isBlank() || stateStorage == null || resourceStateUncertain) {
      return transferResult(TransferStatus.UNAVAILABLE, request);
    }
    if (resourceTransactionReceipts.containsKey(request.transactionId())) {
      return transferResult(TransferStatus.REJECTED, request);
    }
    Optional<TransferReceipt> existingReceipt;
    try {
      existingReceipt = stateStorage.transferReceipt(request.transactionId());
    } catch (RuntimeException lookupFailure) {
      return transferResult(TransferStatus.UNKNOWN, request);
    }
    TransferReceipt existing = existingReceipt.orElse(null);
    if (existing != null) {
      return transferResult(
          existing.matches(request) ? TransferStatus.ALREADY_APPLIED : TransferStatus.REJECTED,
          request);
    }
    if (!RESOURCE_TYPES.containsAll(request.resources().keySet())) {
      return transferResult(TransferStatus.REJECTED, request);
    }

    ConcurrentMap<String, Long> payer = stockpiles.get(request.payerNationId());
    ConcurrentMap<String, Long> receiver = stockpiles.get(request.receiverNationId());
    Map<String, Long> payerBefore = payer == null ? Map.of() : new LinkedHashMap<>(payer);
    Map<String, Long> receiverBefore = receiver == null ? Map.of() : new LinkedHashMap<>(receiver);
    Map<String, Long> payerAfter = new LinkedHashMap<>(payerBefore);
    Map<String, Long> receiverAfter = new LinkedHashMap<>(receiverBefore);
    for (Map.Entry<String, Long> resource : request.resources().entrySet()) {
      long available = payerBefore.getOrDefault(resource.getKey(), 0L);
      if (available < resource.getValue()) {
        return transferResult(TransferStatus.INSUFFICIENT_RESOURCES, request);
      }
      payerAfter.put(resource.getKey(), available - resource.getValue());
      try {
        receiverAfter.put(
            resource.getKey(),
            Math.addExact(receiverBefore.getOrDefault(resource.getKey(), 0L), resource.getValue()));
      } catch (ArithmeticException overflow) {
        return transferResult(TransferStatus.REJECTED, request);
      }
    }

    long nextSequence;
    try {
      nextSequence = Math.addExact(stateStorage.latestTransferSequence(), 1L);
    } catch (RuntimeException error) {
      return transferResult(TransferStatus.UNAVAILABLE, request);
    }

    payer =
        stockpiles.computeIfAbsent(request.payerNationId(), ignored -> new ConcurrentHashMap<>());
    receiver =
        stockpiles.computeIfAbsent(
            request.receiverNationId(), ignored -> new ConcurrentHashMap<>());
    payer.clear();
    payer.putAll(payerAfter);
    receiver.clear();
    receiver.putAll(receiverAfter);
    TransferReceipt receipt =
        new TransferReceipt(
            request.transactionId(),
            resourceAuthorityDomainId,
            nextSequence,
            request.payerNationId(),
            request.receiverNationId(),
            request.resources(),
            request.category(),
            request.description(),
            java.time.Instant.ofEpochMilli(System.currentTimeMillis()));
    try {
      stateStorage.saveTransfer(snapshotProperties(), receipt);
      discardArchivedFactoryRuns();
    } catch (RuntimeException persistenceFailure) {
      payer.clear();
      payer.putAll(payerBefore);
      receiver.clear();
      receiver.putAll(receiverBefore);
      if (plugin != null) {
        plugin
            .getLogger()
            .log(
                java.util.logging.Level.SEVERE,
                "National resource transfer persistence is uncertain: " + request.transactionId(),
                persistenceFailure);
      }
      reloadStockpilesAfterUncertainTransfer();
      return transferResult(TransferStatus.UNKNOWN, request);
    }
    return transferResult(TransferStatus.APPLIED, request);
  }

  @Override
  public String authorityDomainId() {
    return resourceAuthorityDomainId;
  }

  @Override
  public synchronized Optional<TransferReceipt> transferReceipt(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) return Optional.empty();
    requireTransferStorage();
    return stateStorage.transferReceipt(transactionId);
  }

  @Override
  public synchronized List<TransferReceipt> transferReceiptsAfter(long sequence, int limit) {
    if (sequence < 0L || limit < 1 || limit > 1000) {
      throw new IllegalArgumentException("sequence must be non-negative and limit must be 1..1000");
    }
    requireTransferStorage();
    return stateStorage.transferReceiptsAfter(sequence, limit);
  }

  private void requireTransferStorage() {
    if (stateStorage == null || resourceAuthorityDomainId.isBlank() || resourceStateUncertain)
      throw new IllegalStateException("Resource transfer storage requires recovery");
  }

  private TransferResult transferResult(TransferStatus status, TransferRequest request) {
    return new TransferResult(
        status,
        request.transactionId(),
        stockpile(request.payerNationId()),
        stockpile(request.receiverNationId()));
  }

  private void reloadStockpilesAfterUncertainTransfer() {
    reconcileResourceState();
  }

  private TransactionResult applyResourceTransaction(
      TransactionRequest request, Operation operation) {
    if (request == null) {
      throw new IllegalArgumentException("request must not be null");
    }
    if (!inventoryWritesAvailable())
      return new TransactionResult(
          Status.REJECTED, request.transactionId(), stockpile(request.nationId()));
    TransactionReceipt existing = resourceTransactionReceipts.get(request.transactionId());
    if (existing != null) {
      Status status =
          existing.matches(request, operation) ? Status.ALREADY_APPLIED : Status.REJECTED;
      return new TransactionResult(status, request.transactionId(), stockpile(request.nationId()));
    }
    if (!RESOURCE_TYPES.containsAll(request.resources().keySet())) {
      return new TransactionResult(
          Status.REJECTED, request.transactionId(), stockpile(request.nationId()));
    }

    ConcurrentMap<String, Long> nationStockpile =
        stockpiles.computeIfAbsent(request.nationId(), ignored -> new ConcurrentHashMap<>());
    Map<String, Long> previous = new LinkedHashMap<>();
    Map<String, Long> next = new LinkedHashMap<>();
    for (Map.Entry<String, Long> entry : request.resources().entrySet()) {
      long current = nationStockpile.getOrDefault(entry.getKey(), 0L);
      previous.put(entry.getKey(), current);
      if (operation == Operation.CONSUME) {
        if (current < entry.getValue()) {
          return new TransactionResult(
              Status.INSUFFICIENT_RESOURCES,
              request.transactionId(),
              stockpile(request.nationId()));
        }
        next.put(entry.getKey(), current - entry.getValue());
        continue;
      }
      try {
        next.put(entry.getKey(), Math.addExact(current, entry.getValue()));
      } catch (ArithmeticException overflow) {
        return new TransactionResult(
            Status.REJECTED, request.transactionId(), stockpile(request.nationId()));
      }
    }

    next.forEach(nationStockpile::put);
    TransactionReceipt receipt =
        new TransactionReceipt(
            request.transactionId(),
            request.nationId(),
            request.resources(),
            operation,
            request.category(),
            request.description(),
            java.time.Instant.now());
    resourceTransactionReceipts.put(request.transactionId(), receipt);
    try {
      flushState();
    } catch (RuntimeException persistenceFailure) {
      previous.forEach(nationStockpile::put);
      resourceTransactionReceipts.remove(request.transactionId(), receipt);
      // The storage may have committed before the acknowledgement failed. Restore every
      // coupled collection before another writer can serialize an obsolete inventory.
      reconcileResourceState();
      if (plugin != null) {
        plugin
            .getLogger()
            .warning(
                "Resource transaction persistence failed: "
                    + request.transactionId()
                    + " ("
                    + persistenceFailure.getMessage()
                    + ')');
      }
      TransactionReceipt committed = resourceTransactionReceipts.get(request.transactionId());
      Status status =
          inventoryWritesAvailable() && committed != null && committed.matches(request, operation)
              ? Status.ALREADY_APPLIED
              : Status.REJECTED;
      return new TransactionResult(status, request.transactionId(), stockpile(request.nationId()));
    }

    if (priceService != null) {
      request
          .resources()
          .forEach(
              (type, amount) -> {
                if (operation == Operation.CONSUME) {
                  priceService.addDemand(type, amount);
                } else {
                  priceService.addSupply(type, amount);
                }
              });
    }
    return new TransactionResult(
        Status.APPLIED, request.transactionId(), stockpile(request.nationId()));
  }

  @Override
  public String summary() {
    long total = 0L;
    for (Map<String, Long> stockpile : stockpiles.values()) {
      for (long amount : stockpile.values()) {
        total = safeAdd(total, amount);
      }
    }
    return stockpiles.size() + " nation resource stockpile(s), total units " + total;
  }

  private boolean factoryStorageAvailable() {
    return stateStorage != null && !resourceAuthorityDomainId.isBlank() && !resourceStateUncertain;
  }

  private boolean inventoryWritesAvailable() {
    return !resourceStateUncertain
        && (stateStorage == null || !resourceAuthorityDomainId.isBlank());
  }

  void requireTradeStateAvailable() {
    if (!inventoryWritesAvailable())
      throw new IllegalStateException("Resource trade state requires storage recovery");
  }

  boolean nativeTradeStorageAvailable(SimpleResourceTradeService service) {
    return stateStorage != null
        && inventoryWritesAvailable()
        && !resourceAuthorityDomainId.isBlank()
        && tradeService == service;
  }

  boolean mayTrade(NationId nation, UUID actor) {
    return mayProcess(nation, actor);
  }

  Optional<TradeExecution> nativeTradeExecution(String id) {
    requireFactoryStorage();
    ProductionReceipt.token(id, 96);
    var live = tradeExecutions.get(id);
    if (live != null) return Optional.of(live);
    try {
      return stateStorage.archivedTradeExecution(id);
    } catch (RuntimeException error) {
      resourceStateUncertain = true;
      resourceAuthorityDomainId = "";
      throw error;
    }
  }

  List<TradeExecution> nativeTradeExecutions() {
    requireFactoryStorage();
    return List.copyOf(tradeExecutions.values());
  }

  List<TradeExecution> nativeTradeExecutions(NationId nation, int offset, int limit) {
    requireFactoryStorage();
    var live =
        tradeExecutions.values().stream()
            .filter(value -> value.involves(nation))
            .sorted(SqlTradeArchive.ORDER)
            .toList();
    // At most live.size() rows can precede an archived row. Discard only an archive prefix
    // guaranteed to precede the requested global offset, then merge bounded archive pages.
    long archiveOffset = Math.max(0L, (long) offset - live.size());
    long skip = offset - archiveOffset;
    int liveIndex = 0, archiveIndex = 0;
    List<TradeExecution> archived = List.of();
    List<TradeExecution> result = new ArrayList<>(limit);
    boolean exhausted = false;
    try {
      while (result.size() < limit) {
        if (archiveIndex == archived.size() && !exhausted) {
          archived = stateStorage.archivedTradeExecutions(nation, archiveOffset, 256);
          archiveOffset += archived.size();
          archiveIndex = 0;
          exhausted = archived.size() < 256;
        }
        TradeExecution pending = liveIndex < live.size() ? live.get(liveIndex) : null;
        TradeExecution terminal =
            archiveIndex < archived.size() ? archived.get(archiveIndex) : null;
        if (pending == null && terminal == null) break;
        TradeExecution next;
        if (terminal == null
            || pending != null && SqlTradeArchive.ORDER.compare(pending, terminal) <= 0) {
          next = pending;
          liveIndex++;
        } else {
          next = terminal;
          archiveIndex++;
        }
        if (skip > 0) skip--;
        else result.add(next);
      }
      return List.copyOf(result);
    } catch (RuntimeException error) {
      resourceStateUncertain = true;
      resourceAuthorityDomainId = "";
      throw error;
    }
  }

  /** The caller holds this module's monitor, including quota/route changes in the same write. */
  boolean saveTradeExecution(TradeExecution execution) {
    requireFactoryStorage();
    tradeExecutions.put(execution.executionId(), execution);
    try {
      stateStorage.save(snapshotProperties());
      discardArchivedFactoryRuns();
      return true;
    } catch (RuntimeException uncertain) {
      reconcileResourceState();
      return inventoryWritesAvailable()
          && nativeTradeExecution(execution.executionId()).filter(execution::equals).isPresent();
    }
  }

  boolean saveTradeQuota(dev.starcore.starcore.module.resource.model.ResourceQuota expected) {
    requireFactoryStorage();
    try {
      stateStorage.save(snapshotProperties());
      discardArchivedFactoryRuns();
      return true;
    } catch (RuntimeException uncertain) {
      reconcileResourceState();
      requireTradeStateAvailable();
      var actual = tradeService.getQuota(expected.quotaId()).orElse(null);
      return actual != null
          && actual.currentAmount() == expected.currentAmount()
          && actual.startTime().toEpochMilli() == expected.startTime().toEpochMilli()
          && actual.resetTime().toEpochMilli() == expected.resetTime().toEpochMilli();
    }
  }

  private void requireFactoryStorage() {
    if (!factoryStorageAvailable()) throw new IllegalStateException("Factory storage unavailable");
  }

  private boolean mayProcess(NationId nation, UUID actor) {
    return actor == null
        || (nationService != null
            && nationService
                .nationOf(actor)
                .filter(n -> n.id().equals(nation) && n.founderId().equals(actor))
                .isPresent());
  }

  synchronized Factory buildNativeFactory(NationId nation, String name, Factory.FactoryType type) {
    requireFactoryStorage();
    if (name == null || name.isBlank() || name.length() > 128)
      throw new IllegalArgumentException("Factory name must contain 1..128 characters");
    Factory factory = new Factory(UUID.randomUUID(), nation, name, type);
    nativeFactories.put(factory.factoryId(), factory);
    saveFactoryMetadata(factory.factoryId());
    return factory.copy();
  }

  synchronized Map<UUID, Factory> nativeFactorySnapshot() {
    requireFactoryStorage();
    Map<UUID, Factory> copy = new LinkedHashMap<>();
    nativeFactories.forEach((id, factory) -> copy.put(id, factory.copy()));
    return Map.copyOf(copy);
  }

  synchronized Optional<Factory> nativeFactory(UUID id) {
    requireFactoryStorage();
    return Optional.ofNullable(nativeFactories.get(id)).map(Factory::copy);
  }

  synchronized boolean changeNativeFactory(UUID id, Boolean operational) {
    requireFactoryStorage();
    Factory factory = nativeFactories.get(id);
    if (factory == null) return false;
    if (operational == null) {
      if (!factory.upgrade()) return false;
    } else factory.setOperational(operational);
    saveFactoryMetadata(id);
    return true;
  }

  private void saveFactoryMetadata(UUID id) {
    try {
      stateStorage.save(snapshotProperties());
      discardArchivedFactoryRuns();
    } catch (RuntimeException uncertain) {
      reconcileResourceState();
      throw new IllegalStateException(
          "Factory save uncertain; inspect factory " + id + " before retrying", uncertain);
    }
  }

  synchronized Optional<FactoryRun> factoryRun(String id) {
    requireFactoryStorage();
    ProductionReceipt.token(id, 96);
    FactoryRun live = factoryRuns.get(id);
    return live == null ? stateStorage.archivedFactoryRun(id) : Optional.of(live);
  }

  synchronized Optional<FactoryRun> activeFactoryRun(UUID factoryId) {
    requireFactoryStorage();
    return factoryRuns.values().stream()
        .filter(r -> r.factoryId().equals(factoryId) && !r.completed())
        .findFirst();
  }

  synchronized boolean nativeFactoryReady(UUID id) {
    return activeFactoryRun(id)
        .filter(r -> !factoryClock.instant().isBefore(r.readyAt()))
        .isPresent();
  }

  synchronized ProcessingService.FactoryResult startFactoryRun(
      ProcessingService.FactoryRequest request, ProcessingRecipe recipe) {
    java.util.Objects.requireNonNull(request);
    if (!factoryStorageAvailable())
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    if (!mayProcess(request.nationId(), request.actorId()))
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    FactoryRun old;
    try {
      old = factoryRun(request.runId()).orElse(null);
    } catch (RuntimeException unavailable) {
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    }
    if (old != null) {
      if (!old.matches(request)) return factoryResult(ProcessingService.FactoryStatus.REJECTED);
      return new ProcessingService.FactoryResult(
          old.completed()
              ? ProcessingService.FactoryStatus.ALREADY_COMPLETED
              : ProcessingService.FactoryStatus.ALREADY_STARTED,
          old);
    }
    Factory factory = nativeFactories.get(request.factoryId());
    if (factory == null || !factory.ownerNationId().equals(request.nationId()))
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    if (factory.isProcessing())
      return factoryResult(
          activeFactoryRun(factory.factoryId()).isPresent()
              ? ProcessingService.FactoryStatus.BUSY
              : ProcessingService.FactoryStatus.LEGACY_REVIEW_REQUIRED);
    if (!factory.isOperational()
        || recipe == null
        || !request.recipeId().equals(recipe.recipeId())
        || factory.level() < recipe.requiredFactoryLevel())
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    try {
      if (stateStorage.productionReceipt("factory:" + request.runId()).isPresent())
        return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    } catch (RuntimeException unavailable) {
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    }
    FactoryRun run;
    try {
      Map<String, Long> inputs =
          ProductionReceipt.quantities(recipe.calculateBatchInputs(request.batches()));
      Map<String, Long> outputs =
          ProductionReceipt.quantities(recipe.calculateBatchOutputs(request.batches()));
      if (!RESOURCE_TYPES.containsAll(inputs.keySet())
          || !RESOURCE_TYPES.containsAll(outputs.keySet()))
        return factoryResult(ProcessingService.FactoryStatus.REJECTED);
      long seconds =
          java.math.BigDecimal.valueOf(recipe.calculateBatchProcessingTime(request.batches()))
              .divide(
                  java.math.BigDecimal.valueOf(factory.efficiency()),
                  0,
                  java.math.RoundingMode.CEILING)
              .longValueExact();
      java.time.Instant now = java.time.Instant.ofEpochMilli(factoryClock.millis());
      run =
          new FactoryRun(
              request.runId(),
              resourceAuthorityDomainId,
              request.factoryId(),
              request.nationId(),
              request.actorId(),
              request.recipeId(),
              request.batches(),
              inputs,
              outputs,
              now,
              now.plusSeconds(seconds),
              null,
              0);
    } catch (RuntimeException invalid) {
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    }
    Map<String, Long> after = new LinkedHashMap<>(stockpile(request.nationId()));
    for (var input : run.inputs().entrySet()) {
      long available = after.getOrDefault(input.getKey(), 0L);
      if (available < input.getValue())
        return factoryResult(ProcessingService.FactoryStatus.INSUFFICIENT_RESOURCES);
      after.put(input.getKey(), available - input.getValue());
    }
    stockpiles.put(request.nationId(), new ConcurrentHashMap<>(after));
    nativeFactories.put(
        factory.factoryId(),
        new Factory(
            factory.factoryId(),
            factory.ownerNationId(),
            factory.factoryName(),
            factory.type(),
            factory.buildTime(),
            factory.level(),
            factory.efficiency(),
            factory.isOperational(),
            run.recipeId(),
            run.startedAt(),
            run.batches()));
    factoryRuns.put(run.runId(), run);
    try {
      stateStorage.save(snapshotProperties());
      discardArchivedFactoryRuns();
    } catch (RuntimeException uncertain) {
      reconcileResourceState();
      return factoryResult(ProcessingService.FactoryStatus.UNKNOWN);
    }
    if (priceService != null) run.inputs().forEach(priceService::addDemand);
    return new ProcessingService.FactoryResult(ProcessingService.FactoryStatus.STARTED, run);
  }

  synchronized ProcessingService.FactoryResult completeFactoryRun(
      String runId, NationId nation, UUID actor) {
    ProductionReceipt.token(runId, 96);
    if (!factoryStorageAvailable())
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    FactoryRun run;
    try {
      run = factoryRun(runId).orElse(null);
    } catch (RuntimeException unavailable) {
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    }
    if (run == null || !run.nationId().equals(nation) || !mayProcess(nation, actor))
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    if (run.completed())
      return new ProcessingService.FactoryResult(
          ProcessingService.FactoryStatus.ALREADY_COMPLETED, run);
    java.time.Instant now = java.time.Instant.ofEpochMilli(factoryClock.millis());
    if (now.isBefore(run.readyAt()))
      return new ProcessingService.FactoryResult(ProcessingService.FactoryStatus.NOT_READY, run);
    Map<String, Long> after = new LinkedHashMap<>(stockpile(nation));
    try {
      for (var output : run.outputs().entrySet())
        after.put(
            output.getKey(),
            Math.addExact(after.getOrDefault(output.getKey(), 0L), output.getValue()));
    } catch (ArithmeticException overflow) {
      return factoryResult(ProcessingService.FactoryStatus.REJECTED);
    }
    FactoryRun completed;
    try {
      if (stateStorage.productionReceipt(run.productionOperationId()).isPresent())
        throw new IllegalStateException("Active factory already has a production receipt");
      completed = run.complete(now, Math.addExact(stateStorage.latestProductionSequence(), 1));
    } catch (RuntimeException unavailable) {
      return factoryResult(ProcessingService.FactoryStatus.UNAVAILABLE);
    }
    stockpiles.put(nation, new ConcurrentHashMap<>(after));
    factoryRuns.put(runId, completed);
    nativeFactories.get(run.factoryId()).finishProcessing();
    try {
      stateStorage.saveProduction(snapshotProperties(), completed.productionReceipt());
      discardArchivedFactoryRuns();
    } catch (RuntimeException uncertain) {
      reconcileResourceState();
      return factoryResult(ProcessingService.FactoryStatus.UNKNOWN);
    }
    if (priceService != null) run.outputs().forEach(priceService::addSupply);
    return new ProcessingService.FactoryResult(
        ProcessingService.FactoryStatus.COMPLETED, completed);
  }

  synchronized void refreshNativeFactories() {
    if (!factoryStorageAvailable()) return;
    for (FactoryRun run : List.copyOf(factoryRuns.values())) {
      if (!run.completed() && !factoryClock.instant().isBefore(run.readyAt()))
        completeFactoryRun(run.runId(), run.nationId(), null);
      if (!factoryStorageAvailable()) break;
    }
  }

  synchronized boolean startLegacyNativeFactory(UUID id, ProcessingRecipe recipe, int batches) {
    requireFactoryStorage();
    Factory factory = nativeFactories.get(id);
    if (factory == null || recipe == null || batches < 1) return false;
    int actual = Math.min(batches, recipe.calculateMaxBatches(stockpile(factory.ownerNationId())));
    if (actual < 1 || actual > 1_000_000) return false;
    String runId = "legacy:" + UUID.randomUUID();
    var result =
        startFactoryRun(
            new ProcessingService.FactoryRequest(
                runId, id, factory.ownerNationId(), null, recipe.recipeId(), actual),
            recipe);
    if (result.status() == ProcessingService.FactoryStatus.UNKNOWN)
      throw new IllegalStateException(
          "Factory start uncertain; inspect run " + runId + " before retrying");
    return result.status() == ProcessingService.FactoryStatus.STARTED;
  }

  synchronized Optional<Map<String, Long>> completeNativeFactory(UUID id) {
    var run = activeFactoryRun(id);
    if (run.isEmpty()) return Optional.empty();
    var result = completeFactoryRun(run.get().runId(), run.get().nationId(), null);
    if (result.status() == ProcessingService.FactoryStatus.UNKNOWN)
      throw new IllegalStateException(
          "Factory completion uncertain; inspect run " + run.get().runId());
    return result.status() == ProcessingService.FactoryStatus.COMPLETED
        ? Optional.of(result.run().outputs())
        : Optional.empty();
  }

  private static ProcessingService.FactoryResult factoryResult(
      ProcessingService.FactoryStatus status) {
    return new ProcessingService.FactoryResult(status, null);
  }

  /** Re-read all coupled state before allowing any later snapshot after an uncertain commit. */
  private void reconcileResourceState() {
    try {
      Properties saved = stateStorage.load();
      if (!resourceAuthorityDomainId.equals(saved.getProperty("resource.authority-domain")))
        throw new IllegalStateException("Resource storage domain changed");
      InventorySnapshotValidator.validate(saved, RESOURCE_TYPES);
      TradeSnapshotValidator.validate(saved);
      stateStorage.latestProductionSequence();
      stateStorage.latestTransferSequence();
      var restored = ResourceStateCodec.snapshotFromProperties(saved, RESOURCE_TYPES);
      var runs = FactoryRunStore.read(saved, restored.factories(), RESOURCE_TYPES, stateStorage);
      var executions = TradeExecutionStore.read(saved, stateStorage);
      stockpiles.clear();
      restored
          .stockpiles()
          .forEach((id, amounts) -> stockpiles.put(id, new ConcurrentHashMap<>(amounts)));
      resourceTransactionReceipts.clear();
      resourceTransactionReceipts.putAll(restored.receipts());
      nativeFactories.clear();
      restored.factories().forEach((id, factory) -> nativeFactories.put(id, factory.copy()));
      factoryRuns.clear();
      factoryRuns.putAll(runs);
      tradeExecutions.clear();
      tradeExecutions.putAll(executions);
      if (tradeService != null) {
        tradeService.restoreAgreements(restored.agreements());
        tradeService.restoreRoutes(restored.routes());
        tradeService.restoreEmbargoes(restored.embargoes());
        tradeService.restoreQuotas(restored.quotas());
      }
    } catch (RuntimeException failedReconcile) {
      resourceStateUncertain = true;
      resourceAuthorityDomainId = "";
    }
  }

  synchronized ProcessingService.ProductionResult processProduction(
      ProcessingService.ProductionRequest request,
      dev.starcore.starcore.module.resource.model.ProcessingRecipe recipe) {
    java.util.Objects.requireNonNull(request, "request");
    if (stateStorage == null || resourceAuthorityDomainId.isBlank() || resourceStateUncertain)
      return productionResult(ProcessingService.ProductionStatus.UNAVAILABLE);
    try {
      var old = stateStorage.productionReceipt(request.operationId());
      // A timed completion can only be replayed through its frozen factory run.
      if (request.operationId().startsWith("factory:"))
        return productionResult(ProcessingService.ProductionStatus.REJECTED);
      if (old.isPresent())
        return old.get().matches(request)
            ? new ProcessingService.ProductionResult(
                ProcessingService.ProductionStatus.ALREADY_APPLIED, old.get())
            : productionResult(ProcessingService.ProductionStatus.REJECTED);
    } catch (RuntimeException unavailable) {
      return productionResult(ProcessingService.ProductionStatus.UNAVAILABLE);
    }
    // The service rechecks real authority even when invoked outside the command handler.
    if (request.actorId() != null
        && (nationService == null
            || nationService
                .nationOf(request.actorId())
                .filter(
                    n ->
                        n.id().equals(request.nationId())
                            && n.founderId().equals(request.actorId()))
                .isEmpty())) return productionResult(ProcessingService.ProductionStatus.REJECTED);
    if (recipe == null || !recipe.recipeId().equals(request.recipeId()))
      return productionResult(ProcessingService.ProductionStatus.REJECTED);

    Map<String, Long> inputs;
    Map<String, Long> outputs;
    try {
      inputs = ProductionReceipt.quantities(recipe.calculateBatchInputs(request.batches()));
      outputs = ProductionReceipt.quantities(recipe.calculateBatchOutputs(request.batches()));
      if (!RESOURCE_TYPES.containsAll(inputs.keySet())
          || !RESOURCE_TYPES.containsAll(outputs.keySet()))
        return productionResult(ProcessingService.ProductionStatus.REJECTED);
    } catch (RuntimeException invalid) {
      return productionResult(ProcessingService.ProductionStatus.REJECTED);
    }
    var stockpile = stockpiles.get(request.nationId());
    Map<String, Long> before = stockpile == null ? Map.of() : new LinkedHashMap<>(stockpile);
    Map<String, Long> after = new LinkedHashMap<>(before);
    for (var input : inputs.entrySet()) {
      long available = before.getOrDefault(input.getKey(), 0L);
      if (available < input.getValue())
        return productionResult(ProcessingService.ProductionStatus.INSUFFICIENT_RESOURCES);
      after.put(input.getKey(), available - input.getValue());
    }
    try {
      for (var output : outputs.entrySet())
        after.put(
            output.getKey(),
            Math.addExact(after.getOrDefault(output.getKey(), 0L), output.getValue()));
    } catch (ArithmeticException overflow) {
      return productionResult(ProcessingService.ProductionStatus.REJECTED);
    }

    ProductionReceipt receipt;
    try {
      receipt =
          new ProductionReceipt(
              request.operationId(),
              resourceAuthorityDomainId,
              Math.addExact(stateStorage.latestProductionSequence(), 1),
              request.nationId(),
              request.actorId(),
              request.recipeId(),
              request.batches(),
              inputs,
              outputs,
              java.time.Instant.ofEpochMilli(System.currentTimeMillis()));
    } catch (RuntimeException unavailable) {
      return productionResult(ProcessingService.ProductionStatus.UNAVAILABLE);
    }
    stockpile =
        stockpiles.computeIfAbsent(request.nationId(), ignored -> new ConcurrentHashMap<>());
    stockpile.clear();
    stockpile.putAll(after);
    try {
      stateStorage.saveProduction(snapshotProperties(), receipt);
      discardArchivedFactoryRuns();
    } catch (RuntimeException uncertain) {
      stockpile.clear();
      stockpile.putAll(before);
      reconcileResourceState();
      return productionResult(ProcessingService.ProductionStatus.UNKNOWN);
    }
    if (priceService != null) {
      inputs.forEach(priceService::addDemand);
      outputs.forEach(priceService::addSupply);
    }
    return new ProcessingService.ProductionResult(
        ProcessingService.ProductionStatus.APPLIED, receipt);
  }

  private static ProcessingService.ProductionResult productionResult(
      ProcessingService.ProductionStatus status) {
    return new ProcessingService.ProductionResult(status, null);
  }

  synchronized Optional<ProductionReceipt> productionReceipt(String operationId) {
    if (stateStorage == null || resourceAuthorityDomainId.isBlank() || resourceStateUncertain)
      throw new IllegalStateException("Production storage unavailable");
    return stateStorage.productionReceipt(operationId);
  }

  synchronized List<ProductionReceipt> productionReceiptsAfter(long sequence, int limit) {
    if (stateStorage == null || resourceAuthorityDomainId.isBlank() || resourceStateUncertain)
      throw new IllegalStateException("Production storage unavailable");
    return stateStorage.productionReceiptsAfter(sequence, limit);
  }

  // ==================== 持久化方法 ====================

  private synchronized void flushState() {
    if (!inventoryWritesAvailable())
      throw new IllegalStateException("Resource state requires storage recovery");
    if (stateStorage == null) {
      return;
    }
    try {
      stateStorage.save(snapshotProperties());
      discardArchivedFactoryRuns();
    } catch (RuntimeException failure) {
      if (processingService != null) processingService.markFactoriesDirtyForRetry();
      if (tradeService != null) {
        tradeService.markAgreementsDirtyForRetry();
        tradeService.markRoutesDirtyForRetry();
        tradeService.markEmbargoesDirtyForRetry();
        tradeService.markQuotasDirtyForRetry();
      }
      throw failure;
    }
  }

  private Properties snapshotProperties() {
    Map<java.util.UUID, dev.starcore.starcore.module.resource.model.TradeAgreement> agreements =
        tradeService == null ? Map.of() : tradeService.snapshotAgreements();
    Properties properties =
        ResourceStateCodec.toProperties(
            snapshotStockpiles(),
            Map.copyOf(resourceTransactionReceipts),
            nativeFactories,
            agreements,
            tradeService == null ? Map.of() : tradeService.snapshotRoutes(),
            tradeService == null ? Map.of() : tradeService.snapshotEmbargoes(),
            tradeService == null ? Map.of() : tradeService.snapshotQuotas());
    stateStorage.writeFactoryState(properties, factoryRuns, nativeFactories);
    stateStorage.writeTradeState(properties, tradeExecutions);
    if (!resourceAuthorityDomainId.isBlank()) {
      properties.setProperty("resource.authority-domain", resourceAuthorityDomainId);
    }
    return properties;
  }

  private void discardArchivedFactoryRuns() {
    if (stateStorage.archivesFactoryRuns()) factoryRuns.values().removeIf(FactoryRun::completed);
    if (stateStorage.archivesTradeExecutions())
      tradeExecutions.values().removeIf(value -> value.state().terminal());
  }

  private void loadState() {
    stockpiles.clear();
    resourceTransactionReceipts.clear();
    tradeExecutions.clear();
    Properties properties = stateStorage == null ? new Properties() : stateStorage.load();
    try {
      InventorySnapshotValidator.validate(properties, RESOURCE_TYPES);
      TradeSnapshotValidator.validate(properties);
    } catch (RuntimeException invalidSnapshot) {
      resourceAuthorityDomainId = "";
      resourceStateUncertain = true;
      nativeFactories.clear();
      factoryRuns.clear();
      if (plugin != null) plugin.getLogger().warning(invalidSnapshot.getMessage());
      return;
    }
    ResourceStateCodec.Snapshot snapshot =
        ResourceStateCodec.snapshotFromProperties(properties, RESOURCE_TYPES);
    snapshot
        .stockpiles()
        .forEach(
            (nationId, values) -> {
              ConcurrentMap<String, Long> mutable = new ConcurrentHashMap<>();
              values.forEach(
                  (type, amount) -> {
                    if (RESOURCE_TYPES.contains(type) && amount > 0L) {
                      mutable.put(type, amount);
                    }
                  });
              if (!mutable.isEmpty()) {
                stockpiles.put(nationId, mutable);
              }
            });
    resourceTransactionReceipts.putAll(snapshot.receipts());
    resourceAuthorityDomainId =
        loadAuthorityDomain(properties.getProperty("resource.authority-domain"));
    try {
      if (stateStorage != null) {
        stateStorage.latestTransferSequence();
        stateStorage.latestProductionSequence();
      }
      factoryRuns.clear();
      factoryRuns.putAll(
          FactoryRunStore.read(properties, snapshot.factories(), RESOURCE_TYPES, stateStorage));
      tradeExecutions.putAll(TradeExecutionStore.read(properties, stateStorage));
    } catch (RuntimeException error) {
      resourceAuthorityDomainId = "";
      resourceStateUncertain = true;
      if (plugin != null)
        plugin
            .getLogger()
            .warning("Resource journals or factory state require recovery: " + error.getMessage());
    }
    if (resourceAuthorityDomainId.isBlank()
        && !resourceStateUncertain
        && stateStorage != null
        && properties.getProperty("resource.authority-domain") == null
        && safeTransferReceiptCount() == 0
        && stateStorage.latestProductionSequence() == 0) {
      resourceAuthorityDomainId = UUID.randomUUID().toString();
      try {
        properties.setProperty("resource.authority-domain", resourceAuthorityDomainId);
        stateStorage.save(properties);
      } catch (RuntimeException error) {
        resourceAuthorityDomainId = "";
        if (plugin != null) {
          plugin
              .getLogger()
              .log(
                  java.util.logging.Level.SEVERE,
                  "Resource authority domain could not be durably initialized",
                  error);
        }
      }
    }
    nativeFactories.clear();
    snapshot.factories().forEach((id, factory) -> nativeFactories.put(id, factory.copy()));
    if (tradeService != null) {
      tradeService.restoreAgreements(snapshot.agreements());
      tradeService.restoreRoutes(snapshot.routes());
      tradeService.restoreEmbargoes(snapshot.embargoes());
      tradeService.restoreQuotas(snapshot.quotas());
    }
  }

  private static String loadAuthorityDomain(String value) {
    if (value == null || value.isBlank()) return "";
    try {
      UUID id = UUID.fromString(value);
      return id.toString().equals(value) ? value : "";
    } catch (IllegalArgumentException error) {
      return "";
    }
  }

  private int safeTransferReceiptCount() {
    try {
      return stateStorage.transferReceiptCount();
    } catch (RuntimeException error) {
      resourceAuthorityDomainId = "";
      return -1;
    }
  }

  private Map<NationId, Map<String, Long>> snapshotStockpiles() {
    Map<NationId, Map<String, Long>> snapshot = new LinkedHashMap<>();
    stockpiles.entrySet().stream()
        .sorted((left, right) -> left.getKey().toString().compareTo(right.getKey().toString()))
        .forEach(
            entry -> {
              Map<String, Long> values = new LinkedHashMap<>();
              availableResourceTypes()
                  .forEach(
                      type -> {
                        long amount = entry.getValue().getOrDefault(type, 0L);
                        if (amount > 0L) {
                          values.put(type, amount);
                        }
                      });
              if (!values.isEmpty()) {
                snapshot.put(entry.getKey(), Map.copyOf(values));
              }
            });
    return snapshot;
  }

  private static String normalizeResource(String resourceType) {
    return resourceType == null ? "" : resourceType.trim().toLowerCase(Locale.ROOT);
  }

  private static long safeAdd(long left, long right) {
    long result = left + right;
    if (((left ^ result) & (right ^ result)) < 0) {
      return Long.MAX_VALUE;
    }
    return result;
  }

  // ==================== 公开的访问器方法 ====================

  /** 获取价格服务 */
  public ResourcePriceService getPriceService() {
    return priceService;
  }

  /** 获取垄断服务 */
  public ResourceMonopolyService getMonopolyService() {
    return monopolyService;
  }

  /** 获取贸易服务 */
  public ResourceTradeService getTradeService() {
    return tradeService;
  }

  /** 获取储备服务 */
  public ResourceReserveService getReserveService() {
    return reserveService;
  }

  /** 获取加工服务 */
  public ProcessingService getProcessingService() {
    return processingService;
  }

  /** 获取市场订单簿服务 */
  public MarketOrderBookService getMarketOrderBookService() {
    return marketOrderBookService;
  }

  /** 获取 NPC 市场快照 */
  public NpcMarketSnapshot npcMarketSnapshot() {
    return npcMarketSnapshot;
  }

  /** 获取 NPC 市场交易服务 */
  public NpcMarketExchange npcMarketExchange() {
    return npcMarketExchange;
  }

  /** 获取交易历史服务 */
  public TradeHistoryService getTradeHistoryService() {
    return tradeHistoryService;
  }

  /** 获取玩家交易服务 */
  public PlayerTradeService getPlayerTradeService() {
    return playerTradeService;
  }

  /** 获取交易税收服务 */
  public TradeTaxService getTradeTaxService() {
    return tradeTaxService;
  }

  /** 获取 GUI */
  public ResourceMenu getResourceMenu() {
    return resourceMenu;
  }

  /** 获取插件实例 */
  public JavaPlugin getPlugin() {
    return plugin;
  }

  /** 获取 GUI 监听器 */
  public ResourceMenuListener getMenuListener() {
    return menuListener;
  }

  private ResourceTariff createResourceTariff(ServiceRegistry services) {
    TaxationService taxes = services.find(TaxationService.class).orElse(null);
    if (taxes == null) {
      return null;
    }
    BusinessService businesses = services.find(BusinessService.class).orElse(null);
    ResourceTariff.TradeRecorder recorder =
        businesses == null
            ? (playerId, nationId, type, amount, category) -> true
            : businesses::recordTransaction;
    return new ResourceTariff(taxes::quoteTax, taxes::fundTax, taxes::reverseFundedTax, recorder);
  }
}
