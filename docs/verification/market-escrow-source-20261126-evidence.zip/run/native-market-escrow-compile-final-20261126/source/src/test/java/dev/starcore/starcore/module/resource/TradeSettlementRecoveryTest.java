package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.*;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.NationalReserve;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import dev.starcore.starcore.module.resource.model.TradeSettlementIntent;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TradeSettlementRecoveryTest {
  @TempDir Path directory;

  @Test
  void bothQuickDirectionsRecoverFromCommittedReceiptWithoutNewDelivery() throws Exception {
    Fixture f = fixture();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 20);
    ServiceRegistry services = new ServiceRegistry();
    services.register(TransactionFabric.class, f.fabric);
    var player =
        new SimplePlayerTradeService(
            f.resources, f.economy, f.taxes, null, reserve, services, null);
    NationService nations = mock(NationService.class);
    when(nations.nationOf(f.buyer))
        .thenReturn(Optional.of(new Nation(f.buyerNation, "Buyer", f.buyer, "buyer")));
    player.setNationService(nations);
    player.setTradeHistoryService(f.history);
    failCommits(f.db);
    TradeRecord buy = player.quickBuy(f.buyer, f.buyerNation, "iron", 5).orElseThrow();
    TradeRecord sell = player.quickSell(f.buyer, f.buyerNation, "iron", 5).orElseThrow();
    assertThat(f.fabric.snapshot())
        .hasSize(2)
        .allSatisfy(tx -> assertThat(tx.state()).isEqualTo(EconomyTransactionState.COMMITTED));
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    dropFailure(f.db);
    clearInvocations(f.economy, f.resources);
    SimpleTradeHistoryService restarted = new SimpleTradeHistoryService(f.db, null);
    var recovery = coordinator(restarted, TradeTestStorage.fabric(directory));
    assertThat(recovery.reconcileNextPage().applied()).isEqualTo(2);
    assertThat(recovery.reconcileNextPage().applied()).isZero();
    verifyNoInteractions(f.economy, f.resources);
    assertThat(restarted.getRecord(buy.recordId()).orElseThrow().executedAt())
        .isEqualTo(buy.executedAt());
    assertThat(restarted.getRecord(sell.recordId()).orElseThrow().executedAt())
        .isEqualTo(sell.executedAt());
  }

  @Test
  void acknowledgementFailureRollsBackHistoryAndKeepsPreparationReplayable() throws Exception {
    Fixture f = fixture();
    execute(
        f.db,
        "CREATE TRIGGER fail_ack BEFORE UPDATE ON trade_settlement_intents BEGIN SELECT"
            + " RAISE(ABORT, 'injected checkpoint failure'); END");
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    TradeRecord record = f.player.acceptTrade(f.seller, offer.offerId()).orElseThrow();
    assertThat(f.history.getRecord(record.recordId())).isEmpty();
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(f.history.settlementIntentsAfter(null, 1).getFirst().appliedEvents()).isZero();
    execute(f.db, "DROP TRIGGER fail_ack");
    assertThat(coordinator(f.history, f.fabric).reconcileNextPage().applied()).isEqualTo(1);
    assertThat(f.history.tradeChangesAfter(0, 128)).hasSize(1);
  }

  @Test
  void interruptedPlanSweepIsBoundedAndCyclesWithoutInventingHistory() {
    Fixture f = fixture();
    for (int i = 0; i < 130; i++) {
      f.history.prepareSettlement(
          new TradeSettlementIntent(
              UUID.randomUUID(),
              f.buyer,
              BigDecimal.TEN,
              "interrupted preparation",
              TradeCommitJournalTest.trade(Instant.now()),
              0));
    }
    var recovery = coordinator(f.history, f.fabric);
    var first = recovery.reconcileNextPage();
    assertThat(first.scanned()).isEqualTo(128);
    assertThat(first.unresolved()).isEqualTo(128);
    assertThat(recovery.reconcileNextPage().scanned()).isEqualTo(2);
    assertThat(recovery.reconcileNextPage().scanned()).isEqualTo(128);
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    verifyNoInteractions(f.economy, f.resources);
  }

  @Test
  void directTradeHistoryFailureIsRepairedAfterRestartWithoutAnotherAssetCall() throws Exception {
    Fixture f = fixture();
    failCommits(f.db);
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    TradeRecord completed = f.player.acceptTrade(f.seller, offer.offerId()).orElseThrow();
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(f.fabric.snapshot())
        .singleElement()
        .satisfies(
            tx -> {
              assertThat(tx.state()).isEqualTo(EconomyTransactionState.COMMITTED);
              assertThat(completed.executedAt()).isEqualTo(tx.updatedAt());
              assertThat(tx.metadata().get("trade.operation"))
                  .isEqualTo(offer.offerId().toString());
            });
    assertThat(f.history.settlementIntentsAfter(null, 128))
        .singleElement()
        .extracting(TradeSettlementIntent::appliedEvents)
        .isEqualTo(0);
    assertThat(f.player.acceptTradeResult(UUID.randomUUID(), offer.offerId()).status())
        .isEqualTo(PlayerTradeService.ActionStatus.UNAUTHORIZED);
    assertThat(f.player.acceptTradeResult(f.seller, offer.offerId()).record()).isEqualTo(completed);
    dropFailure(f.db);
    clearInvocations(f.economy, f.resources);
    SimpleTradeHistoryService restarted = new SimpleTradeHistoryService(f.db, null);
    var recovery = coordinator(restarted, TradeTestStorage.fabric(directory));
    assertThat(recovery.reconcileNextPage().applied()).isEqualTo(1);
    assertThat(recovery.reconcileNextPage().applied()).isZero();
    verifyNoInteractions(f.economy, f.resources);
    assertThat(TradeRecordCodec.encode(restarted.getRecord(completed.recordId()).orElseThrow()))
        .isEqualTo(TradeRecordCodec.encode(completed));
    assertThat(restarted.tradeChangesAfter(0, 128))
        .singleElement()
        .satisfies(
            change -> {
              assertThat(change.occurredAt()).isEqualTo(completed.executedAt());
              assertThat(change.committedAt()).isAfterOrEqualTo(completed.executedAt());
            });
  }

  @Test
  void preparationFailureStopsBeforeMoneyOrResourceMutation() throws Exception {
    Fixture f = fixture();
    execute(
        f.db,
        "CREATE TRIGGER fail_preparation BEFORE INSERT ON trade_settlement_intents BEGIN SELECT"
            + " RAISE(ABORT, 'injected preparation failure'); END");
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    assertThatThrownBy(() -> f.player.acceptTrade(f.seller, offer.offerId()))
        .isInstanceOf(IllegalStateException.class);
    verify(f.economy, never()).withdraw(any(), any());
    verify(f.economy, never()).deposit(any(), any());
    verify(f.resources, never()).consume(any(), anyString(), anyLong());
    verify(f.resources, never()).grant(any(), anyString(), anyLong());
    assertThat(f.fabric.snapshot()).isEmpty();
  }

  @Test
  void interruptedPreparationCannotExecuteAgainOrMasqueradeAsCompletion() throws Exception {
    Fixture f = fixture();
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    when(f.economy.withdraw(any(), any()))
        .thenThrow(new IllegalStateException("unknown remote outcome"));
    assertThatThrownBy(() -> f.player.acceptTrade(f.seller, offer.offerId()))
        .isInstanceOf(IllegalStateException.class);
    doReturn(true).when(f.economy).withdraw(any(), any());
    assertThatThrownBy(() -> f.player.acceptTrade(f.seller, offer.offerId()))
        .isInstanceOf(IllegalStateException.class);
    verify(f.economy, times(1)).withdraw(any(), any());
    verify(f.economy, never()).deposit(any(), any());
    var recovery =
        coordinator(new SimpleTradeHistoryService(f.db, null), TradeTestStorage.fabric(directory));
    assertThat(recovery.reconcileNextPage().unresolved()).isEqualTo(1);
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    TradeSettlementIntent intent = f.history.settlementIntentsAfter(null, 128).getFirst();
    assertThatThrownBy(() -> f.history.saveRecord(intent.plannedRecord()))
        .isInstanceOf(IllegalStateException.class);
    assertThat(f.history.getRecord(intent.plannedRecord().recordId())).isEmpty();
  }

  @Test
  void refundTimelineAndCheckpointAreCommittedAtomically() throws Exception {
    Fixture f = fixture();
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    TradeRecord record = f.player.acceptTrade(f.seller, offer.offerId()).orElseThrow();
    TransactionRecord tx = f.fabric.snapshot().getFirst();
    TransactionRecord pending =
        f.fabric.transition(
            tx.transactionId(),
            EconomyTransactionState.REFUND_PENDING,
            "post-settlement refund pending");
    TransactionRecord refunded =
        f.fabric.transition(
            tx.transactionId(), EconomyTransactionState.REFUNDED, "refund confirmed");
    failCommits(f.db);
    var recovery = coordinator(f.history, f.fabric);
    assertThat(recovery.reconcileNextPage().failures()).isEqualTo(1);
    assertThat(f.history.getRecord(record.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecord.TradeRecordStatus.COMPLETED);
    assertThat(f.history.settlementIntentsAfter(null, 1).getFirst().appliedEvents())
        .isEqualTo(tx.events().size());
    dropFailure(f.db);
    assertThat(recovery.reconcileNextPage().applied()).isEqualTo(1);
    assertThat(recovery.reconcileNextPage().applied()).isZero();
    assertThat(f.history.tradeChangesAfter(1, 128))
        .satisfiesExactly(
            change -> {
              assertThat(change.record().status())
                  .isEqualTo(TradeRecord.TradeRecordStatus.DISPUTED);
              assertThat(change.occurredAt()).isEqualTo(pending.updatedAt());
            },
            change -> {
              assertThat(change.record().status())
                  .isEqualTo(TradeRecord.TradeRecordStatus.REFUNDED);
              assertThat(change.occurredAt()).isEqualTo(refunded.updatedAt());
            });
    assertThat(f.history.getRecord(record.recordId()).orElseThrow().executedAt())
        .isEqualTo(record.executedAt());
  }

  @Test
  void refundBeforeAnyCommitDoesNotCreateFictitiousTradeHistory() {
    Fixture f = fixture();
    var recovery = coordinator(f.history, f.fabric);
    TradeRecord planned = TradeCommitJournalTest.trade(Instant.now());
    TransactionRecord tx =
        recovery.prepare(
            UUID.randomUUID(), f.buyer, BigDecimal.TEN, "refund-before-commit", planned);
    f.fabric.transition(tx.transactionId(), EconomyTransactionState.DEBITED, "debited");
    f.fabric.transition(tx.transactionId(), EconomyTransactionState.REFUND_PENDING, "pending");
    f.fabric.transition(tx.transactionId(), EconomyTransactionState.REFUNDED, "restored");
    assertThat(recovery.reconcileNextPage().failures()).isZero();
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(f.history.getRecord(planned.recordId())).isEmpty();
  }

  @Test
  void marketHistoryFailureDoesNotRepeatPayoutOrReleaseConsumedEscrow() throws Exception {
    Fixture f = fixture();
    SimpleMarketOrderBookService market = market(f);
    failCommits(f.db);
    market.submitBuyOrder(f.buyer, f.buyerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    market.submitSellOrder(f.seller, f.sellerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    assertThat(market.matchOrders("iron")).isEqualTo(1);
    assertThat(market.matchOrders("iron")).isZero();
    assertThat(market.refundOpenOrders()).isZero();
    verify(f.economy, times(1)).withdraw(eq(f.buyer), any());
    verify(f.economy, times(1)).deposit(eq(f.seller), any());
    verify(f.resources, times(1)).grant(f.buyerNation, "iron", 5);
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    dropFailure(f.db);
    clearInvocations(f.economy, f.resources);
    assertThat(
            coordinator(
                    new SimpleTradeHistoryService(f.db, null), TradeTestStorage.fabric(directory))
                .reconcileNextPage()
                .applied())
        .isEqualTo(1);
    verifyNoInteractions(f.economy, f.resources);
    assertThat(f.history.tradeChangesAfter(0, 128)).hasSize(1);
  }

  @Test
  void unknownMarketPayoutQuarantinesBothOrdersIncludingCancellationAndShutdown() {
    Fixture f = fixture();
    SimpleMarketOrderBookService market = market(f);
    when(f.economy.deposit(eq(f.seller), any()))
        .thenThrow(new IllegalStateException("unknown payout"));
    market.submitBuyOrder(f.buyer, f.buyerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    market.submitSellOrder(f.seller, f.sellerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    assertThat(market.matchOrders("iron")).isZero();
    assertThat(market.ordersAwaitingReconciliation()).hasSize(2);
    assertThat(market.cancelOrder(f.buyer, market.getPlayerOrders(f.buyer).getFirst().orderId()))
        .isFalse();
    assertThat(market.refundOpenOrders()).isZero();
    assertThat(market.matchOrders("iron")).isZero();
    verify(f.economy, times(1)).deposit(eq(f.seller), any());
    assertThat(f.fabric.snapshot().getFirst().state())
        .isEqualTo(EconomyTransactionState.MANUAL_REVIEW);
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(coordinator(f.history, f.fabric).reconcileNextPage().unresolved()).isEqualTo(1);
  }

  @Test
  void missingDurabilityRejectsPlayerSettlementAndMarketReservation() {
    Fixture f = fixture();
    f.player.setTradeHistoryService(null);
    var offer =
        f.player
            .createTradeOffer(f.buyer, f.buyerNation, f.seller, f.sellerNation, "iron", 5, 20, 300)
            .orElseThrow();
    assertThatThrownBy(() -> f.player.acceptTrade(f.seller, offer.offerId()))
        .isInstanceOf(IllegalStateException.class);
    var market = new SimpleMarketOrderBookService(f.resources, f.economy, f.taxes);
    market.submitBuyOrder(f.buyer, f.buyerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    market.submitSellOrder(f.seller, f.sellerNation, "iron", 5, 20, Instant.now().plusSeconds(300));
    assertThat(market.getAllOrderBooks()).isEmpty();
    verify(f.economy, never()).withdraw(any(), any());
    verify(f.resources, never()).consume(any(), anyString(), anyLong());
  }

  @Test
  void wrongDomainPayloadOrRewrittenTimelineCannotBeReconciled() {
    Fixture f = fixture();
    TradeRecord planned = TradeCommitJournalTest.trade(Instant.now());
    UUID operation = UUID.randomUUID();
    var recovery = coordinator(f.history, f.fabric);
    TransactionRecord reserved =
        recovery.prepare(operation, f.buyer, BigDecimal.TEN, "fingerprint", planned);
    f.history.reconcileSettlement(operation, reserved);
    TransactionRecord otherMetadata =
        new TransactionRecord(
            reserved.transactionId(),
            reserved.accountId(),
            reserved.amount(),
            reserved.owner(),
            reserved.type(),
            reserved.reason(),
            reserved.idempotencyKey(),
            Map.of(),
            reserved.state(),
            reserved.attempts(),
            reserved.createdAt(),
            reserved.updatedAt(),
            reserved.lastError(),
            reserved.events());
    assertThatThrownBy(() -> f.history.reconcileSettlement(operation, otherMetadata))
        .isInstanceOf(IllegalStateException.class);
    List<TransactionEvent> events = new ArrayList<>(reserved.events());
    events.set(
        1, new TransactionEvent(reserved.updatedAt(), reserved.state(), "rewritten receipt"));
    TransactionRecord rewritten =
        new TransactionRecord(
            reserved.transactionId(),
            reserved.accountId(),
            reserved.amount(),
            reserved.owner(),
            reserved.type(),
            reserved.reason(),
            reserved.idempotencyKey(),
            reserved.metadata(),
            reserved.state(),
            reserved.attempts(),
            reserved.createdAt(),
            reserved.updatedAt(),
            reserved.lastError(),
            events);
    assertThatThrownBy(() -> f.history.reconcileSettlement(operation, rewritten))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(
            () ->
                f.history.reconcileSettlement(
                    operation,
                    reserved
                        .transition(EconomyTransactionState.DEBITED, "debit", Instant.now())
                        .transition(EconomyTransactionState.DELIVERED, "deliver", Instant.now())
                        .transition(EconomyTransactionState.COMMITTED, "commit", Instant.now())
                        .transition(EconomyTransactionState.REFUND_PENDING, "refund", Instant.now())
                        .transition(EconomyTransactionState.CREATED, "reuse", Instant.now())
                        .transition(EconomyTransactionState.RESERVED, "reserve", Instant.now())
                        .transition(EconomyTransactionState.DEBITED, "debit", Instant.now())
                        .transition(EconomyTransactionState.DELIVERED, "deliver", Instant.now())
                        .transition(
                            EconomyTransactionState.COMMITTED, "commit again", Instant.now())))
        .isInstanceOf(IllegalStateException.class);
    assertThat(f.history.tradeChangesAfter(0, 128)).isEmpty();
  }

  private Fixture fixture() {
    UUID buyer = UUID.randomUUID();
    UUID seller = UUID.randomUUID();
    NationId buyerNation = NationId.random();
    NationId sellerNation = NationId.random();
    EconomyService economy = mock(EconomyService.class);
    when(economy.has(any(), any())).thenReturn(true);
    when(economy.withdraw(any(), any())).thenReturn(true);
    when(economy.deposit(any(), any())).thenReturn(true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(any(), anyString())).thenReturn(100L);
    when(resources.grant(any(), anyString(), anyLong())).thenReturn(true);
    when(resources.consume(any(), anyString(), anyLong())).thenReturn(true);
    TradeTaxService taxes = mock(TradeTaxService.class);
    when(taxes.calculateTaxBD(anyString(), any(), any())).thenReturn(BigDecimal.ZERO);
    NationService nations = mock(NationService.class);
    when(nations.nationOf(buyer))
        .thenReturn(Optional.of(new Nation(buyerNation, "Buyer", buyer, "buyer")));
    when(nations.nationOf(seller))
        .thenReturn(Optional.of(new Nation(sellerNation, "Seller", seller, "seller")));
    DatabaseService db = TradeTestStorage.database(directory.resolve("trades.db"));
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    TransactionFabric fabric = TradeTestStorage.fabric(directory);
    ServiceRegistry services = new ServiceRegistry();
    services.register(TransactionFabric.class, fabric);
    var player =
        new SimplePlayerTradeService(resources, economy, taxes, null, null, services, null);
    player.setNationService(nations);
    player.setTradeHistoryService(history);
    return new Fixture(
        db,
        history,
        fabric,
        player,
        economy,
        resources,
        taxes,
        buyer,
        seller,
        buyerNation,
        sellerNation);
  }

  private SimpleMarketOrderBookService market(Fixture f) {
    var market = new SimpleMarketOrderBookService(f.resources, f.economy, f.taxes);
    market.setTradeHistoryService(f.history);
    market.setTransactionFabric(f.fabric);
    market.initializeOrderStorage(directory.resolve("market-orders.sqlite"));
    return market;
  }

  private TradeSettlementCoordinator coordinator(
      TradeHistoryService history, TransactionFabric fabric) {
    return new TradeSettlementCoordinator(history, fabric, Logger.getAnonymousLogger());
  }

  private static void failCommits(DatabaseService db) throws Exception {
    execute(
        db,
        "CREATE TRIGGER fail_trade_commit BEFORE INSERT ON trade_history_commits BEGIN SELECT"
            + " RAISE(ABORT, 'injected journal failure'); END");
  }

  private static void dropFailure(DatabaseService db) throws Exception {
    execute(db, "DROP TRIGGER fail_trade_commit");
  }

  private static void execute(DatabaseService db, String sql) throws Exception {
    try (Connection connection = db.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  private record Fixture(
      DatabaseService db,
      SimpleTradeHistoryService history,
      TransactionFabric fabric,
      SimplePlayerTradeService player,
      EconomyService economy,
      ResourceService resources,
      TradeTaxService taxes,
      UUID buyer,
      UUID seller,
      NationId buyerNation,
      NationId sellerNation) {}
}
