package dev.starcore.starcore.module.resource.command;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.player.OnlinePlayerDirectory;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.ProcessingService;
import dev.starcore.starcore.module.resource.ResourcePriceService;
import dev.starcore.starcore.module.resource.ResourceReserveService;
import dev.starcore.starcore.module.resource.ResourceService;
import dev.starcore.starcore.module.resource.ResourceTradeService;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

class ResourceCommandSafetyTest {

  @Test
  void escrowEvidenceRequiresAdminEvenForAnOrdinaryPermittedPlayer() {
    Fixture fixture = fixture();
    var market = mock(dev.starcore.starcore.module.resource.MarketOrderBookService.class);
    fixture.command.setMarketOrderBookService(market);
    fixture.command.onCommand(
        permittedPlayer(), mock(Command.class), "resource", new String[] {"order", "review"});
    fixture.command.onCommand(
        mock(CommandSender.class),
        mock(Command.class),
        "resource",
        new String[] {"order", "review", UUID.randomUUID().toString()});
    verifyNoInteractions(market);
  }

  @Test
  void administratorConsoleCanReadOnlyPageOrInspectEscrowWithoutNationMembership() {
    Fixture fixture = fixture();
    var market = mock(dev.starcore.starcore.module.resource.MarketOrderBookService.class);
    fixture.command.setMarketOrderBookService(market);
    CommandSender console = mock(CommandSender.class);
    when(console.hasPermission("starcore.resource.admin")).thenReturn(true);
    UUID id = UUID.randomUUID();
    fixture.command.onCommand(
        console, mock(Command.class), "resource", new String[] {"order", "review"});
    fixture.command.onCommand(
        console, mock(Command.class), "resource", new String[] {"order", "review", "after:" + id});
    fixture.command.onCommand(
        console, mock(Command.class), "resource", new String[] {"order", "review", id.toString()});
    verify(market).escrowReviews(null, 20);
    verify(market).escrowReviews(id, 20);
    verify(market).escrowSnapshot(id);
    org.mockito.Mockito.verifyNoMoreInteractions(market);
    verifyNoInteractions(fixture.nationService, fixture.resourceService);
  }

  @Test
  void playerSeesReviewStatusInsteadOfAnAcceptedOrRefundedOrder() {
    Fixture fixture = fixture();
    var market = mock(dev.starcore.starcore.module.resource.MarketOrderBookService.class);
    fixture.command.setMarketOrderBookService(market);
    Player player = permittedPlayer();
    UUID id = UUID.randomUUID();
    var order =
        new dev.starcore.starcore.module.resource.model.TradeOrder(
            id,
            dev.starcore.starcore.module.resource.model.TradeOrder.OrderType.BUY,
            dev.starcore.starcore.module.resource.model.TradeOrder.OrderSource.PLAYER,
            player.getUniqueId(),
            NationId.random(),
            "mineral",
            1,
            1,
            java.time.Instant.now().plusSeconds(300),
            false);
    when(market.getPlayerOrders(player.getUniqueId())).thenReturn(List.of(order));
    when(market.requiresReconciliation(id)).thenReturn(true);
    fixture.command.onCommand(
        player, mock(Command.class), "resource", new String[] {"order", "list"});
    fixture.command.onCommand(
        player, mock(Command.class), "resource", new String[] {"order", "cancel", id.toString()});
    assertThat(messages(player))
        .anyMatch(message -> message.contains("待核对（已暂停）"))
        .anyMatch(message -> message.contains("已暂停退款"))
        .noneMatch(message -> message.contains("托管资产已返还"));
  }

  @Test
  void playerWithoutBasePermissionCannotReachServices() {
    Fixture fixture = fixture();
    Player player = mock(Player.class);
    when(player.hasPermission("starcore.resource")).thenReturn(false);
    when(player.hasPermission("starcore.resource.admin")).thenReturn(false);

    fixture.command.onCommand(player, mock(Command.class), "resource", new String[] {"info"});

    verifyNoInteractions(fixture.resourceService);
    verifyNoInteractions(fixture.nationService);
  }

  @Test
  void nonPlayerCannotUseOrdinaryResourceCommands() {
    Fixture fixture = fixture();
    CommandSender console = mock(CommandSender.class);

    fixture.command.onCommand(console, mock(Command.class), "resource", new String[] {"info"});

    verifyNoInteractions(fixture.resourceService);
    verifyNoInteractions(fixture.nationService);
  }

  @Test
  void malformedReserveAmountIsRejectedBeforeServiceCall() {
    Fixture fixture = fixture();
    Player player = adminPlayer();
    Nation nation = mock(Nation.class);
    when(nation.id()).thenReturn(NationId.random());
    when(fixture.nationService.nationOf(player.getUniqueId())).thenReturn(Optional.of(nation));

    fixture.command.onCommand(
        player, mock(Command.class), "resource", new String[] {"reserve", "add", "iron", "NaN"});

    verifyNoInteractions(fixture.reserveService);
    assertThat(messages(player)).anyMatch(message -> message.contains("整数"));
  }

  @Test
  void internalFailureReturnsGenericMessageWithoutLeakingDetails() {
    Fixture fixture = fixture();
    Player player = permittedPlayer();
    Nation nation = mock(Nation.class);
    NationId nationId = NationId.random();
    when(nation.id()).thenReturn(nationId);
    when(nation.name()).thenReturn("Test Nation");
    when(fixture.nationService.nationOf(player.getUniqueId())).thenReturn(Optional.of(nation));
    when(fixture.resourceService.stockpile(nationId)).thenReturn(Map.of());
    when(fixture.resourceService.availableResourceTypes())
        .thenThrow(new IllegalStateException("database password=secret"));

    fixture.command.onCommand(player, mock(Command.class), "resource", new String[] {"info"});

    assertThat(messages(player))
        .anyMatch(message -> message.contains("请稍后重试"))
        .noneMatch(message -> message.contains("password=secret"))
        .noneMatch(message -> message.contains("IllegalStateException"));
  }

  @Test
  void tabCompletionRequiresBasePermission() {
    Fixture fixture = fixture();
    Player player = mock(Player.class);
    when(player.hasPermission("starcore.resource")).thenReturn(false);
    when(player.hasPermission("starcore.resource.admin")).thenReturn(false);

    assertThat(
            fixture.command.onTabComplete(
                player, mock(Command.class), "resource", new String[] {""}))
        .isEmpty();

    verifyNoInteractions(fixture.resourceService);
    verifyNoInteractions(fixture.nationService);
  }

  @Test
  void tabCompletionFailsClosedWhenResourceLookupThrows() {
    Fixture fixture = fixture();
    Player player = permittedPlayer();
    when(fixture.resourceService.availableResourceTypes())
        .thenThrow(new IllegalStateException("lookup failed"));

    assertThat(
            fixture.command.onTabComplete(
                player, mock(Command.class), "resource", new String[] {"reserve", "add", ""}))
        .isEmpty();
  }

  private static Player permittedPlayer() {
    Player player = mock(Player.class);
    when(player.hasPermission("starcore.resource")).thenReturn(true);
    when(player.getUniqueId()).thenReturn(UUID.randomUUID());
    return player;
  }

  private static Player adminPlayer() {
    Player player = mock(Player.class);
    when(player.hasPermission("starcore.resource.admin")).thenReturn(true);
    when(player.getUniqueId()).thenReturn(UUID.randomUUID());
    return player;
  }

  private static List<String> messages(Player player) {
    ArgumentCaptor<String> messages = ArgumentCaptor.forClass(String.class);
    verify(player, atLeastOnce()).sendMessage(messages.capture());
    return messages.getAllValues();
  }

  private static Fixture fixture() {
    ResourceService resourceService = mock(ResourceService.class);
    ResourcePriceService priceService = mock(ResourcePriceService.class);
    ResourceTradeService tradeService = mock(ResourceTradeService.class);
    ResourceReserveService reserveService = mock(ResourceReserveService.class);
    ProcessingService processingService = mock(ProcessingService.class);
    NationService nationService = mock(NationService.class);
    ResourceCommand command =
        new ResourceCommand(
            resourceService,
            priceService,
            tradeService,
            reserveService,
            processingService,
            nationService,
            mock(OnlinePlayerDirectory.class));
    return new Fixture(command, resourceService, reserveService, nationService);
  }

  private record Fixture(
      ResourceCommand command,
      ResourceService resourceService,
      ResourceReserveService reserveService,
      NationService nationService) {}
}
