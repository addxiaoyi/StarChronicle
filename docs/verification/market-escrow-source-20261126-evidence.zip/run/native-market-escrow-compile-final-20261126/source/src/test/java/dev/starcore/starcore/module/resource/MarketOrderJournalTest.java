package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.MarketEscrowSnapshot.Phase;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.DriverManager;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MarketOrderJournalTest {
  @TempDir Path directory;
  final UUID tradeDomain = UUID.randomUUID();
  final String resourceDomain = UUID.randomUUID().toString();

  @Test
  void roundTripKeepsNanosecondsAndAllDecimalDigitsWithoutReinitializingIdentity() {
    var journal = journal();
    Instant created = Instant.parse("2026-11-26T00:00:00.123456789Z");
    var order =
        TradeOrder.restore(
            new TradeOrder.OrderSnapshot(
                UUID.randomUUID(),
                TradeOrder.OrderType.BUY,
                TradeOrder.OrderSource.PLAYER,
                UUID.randomUUID(),
                NationId.random(),
                "iron",
                0.000001,
                9,
                9,
                created,
                created.plusSeconds(3600),
                TradeOrder.OrderStatus.PENDING,
                false,
                0,
                0));
    BigDecimal money = new BigDecimal("0.00001000000000000123456789");
    var reserved = journal.reserve(order, money);
    var open = journal.open(reserved);
    var reopened = journal();
    assertEquals(open, reopened.find(order.orderId()).orElseThrow());
    assertEquals(order.toSnapshot(), TradeOrder.restore(open.order()).toSnapshot());
    assertEquals(money, open.moneyRemaining());
    var closed = reopened.cancelled(reopened.claimCancellation(open, order));
    assertEquals(4, closed.revision());
    assertEquals(Phase.CLOSED, journal().find(order.orderId()).orElseThrow().phase());
    assertTrue(journal().activeAfter(null, 128, false).isEmpty());
  }

  @Test
  void duplicateIdAndStaleClaimCannotAuthorizeAnotherEffect() {
    var first = journal();
    var order = order();
    var reservation = first.reserve(order, BigDecimal.TEN);
    assertThrows(IllegalStateException.class, () -> first.reserve(order, BigDecimal.TEN));
    var open = first.open(reservation);
    var second = journal();
    var claim = second.claimCancellation(open, order);
    assertThrows(IllegalStateException.class, () -> first.claimCancellation(open, order));
    assertThrows(IllegalStateException.class, () -> first.open(reservation));
    assertEquals(claim, first.find(order.orderId()).orElseThrow());
  }

  @ParameterizedTest
  @ValueSource(strings = {"trade", "resource", "version", "sequence", "event", "phase"})
  void authorityOrIndexChangesNeverLoadAsAnEmptyBook(String fault) throws Exception {
    var first = journal();
    var order = order();
    first.open(first.reserve(order, BigDecimal.TEN));
    if (fault.equals("trade")) {
      assertThrows(
          IllegalStateException.class,
          () -> new MarketOrderJournal(database(), UUID.randomUUID(), resourceDomain));
    } else if (fault.equals("resource")) {
      assertThrows(
          IllegalStateException.class,
          () -> new MarketOrderJournal(database(), tradeDomain, UUID.randomUUID().toString()));
    } else {
      switch (fault) {
        case "version" -> sql("UPDATE authority SET version=2");
        case "sequence" -> sql("UPDATE authority SET sequence=1");
        case "event" -> sql("DELETE FROM events WHERE sequence=1");
        case "phase" -> sql("UPDATE orders SET phase='CLOSED'");
        default -> fail();
      }
      byte[] evidence = Files.readAllBytes(database());
      assertThrows(IllegalStateException.class, this::journal);
      assertArrayEquals(evidence, Files.readAllBytes(database()));
    }
  }

  @Test
  void missingFenceDoesNotAdoptAnUnidentifiedExistingDatabase() throws Exception {
    var first = journal();
    first.reserve(order(), BigDecimal.TEN);
    Files.delete(marker());
    byte[] evidence = Files.readAllBytes(database());
    assertThrows(IllegalStateException.class, this::journal);
    assertFalse(Files.exists(marker()));
    assertArrayEquals(evidence, Files.readAllBytes(database()));
  }

  @Test
  void changedFenceIsCheckedBeforeEveryWrite() throws Exception {
    var first = journal();
    Files.writeString(marker(), Files.readString(marker()).replace("READY", "INITIALIZING"));
    byte[] evidence = Files.readAllBytes(database());
    assertThrows(IllegalStateException.class, () -> first.reserve(order(), BigDecimal.TEN));
    assertArrayEquals(evidence, Files.readAllBytes(database()));
  }

  @Test
  void interruptedEmptyBootstrapCanResumeButCannotResetAnEstablishedAuthority() throws Exception {
    journal();
    Files.writeString(marker(), Files.readString(marker()).replace("READY", "INITIALIZING"));
    var resumed = journal();
    assertTrue(resumed.activeAfter(null, 128, false).isEmpty());
    resumed.reserve(order(), BigDecimal.TEN);
    Files.writeString(marker(), Files.readString(marker()).replace("READY", "INITIALIZING"));
    byte[] evidence = Files.readAllBytes(database());
    assertThrows(IllegalStateException.class, this::journal);
    assertArrayEquals(evidence, Files.readAllBytes(database()));
  }

  @Test
  void snapshotRestoreRejectsImpossibleQuantitiesInsteadOfClampingThem() {
    var order = order().toSnapshot();
    assertThrows(
        IllegalArgumentException.class,
        () ->
            TradeOrder.restore(
                new TradeOrder.OrderSnapshot(
                    order.orderId(),
                    order.type(),
                    order.source(),
                    order.playerId(),
                    order.nationId(),
                    order.resourceId(),
                    order.pricePerUnit(),
                    order.totalAmount(),
                    Long.MAX_VALUE,
                    order.createdAt(),
                    order.expiryTime(),
                    order.status(),
                    order.isMarketOrder(),
                    order.fillPrice(),
                    order.filledAmount())));
  }

  private MarketOrderJournal journal() {
    return new MarketOrderJournal(database(), tradeDomain, resourceDomain);
  }

  private Path database() {
    return directory.resolve("orders.sqlite");
  }

  private Path marker() {
    return directory.resolve("orders.sqlite.authority");
  }

  private TradeOrder order() {
    return new TradeOrder(
        UUID.randomUUID(),
        TradeOrder.OrderType.BUY,
        TradeOrder.OrderSource.PLAYER,
        UUID.randomUUID(),
        NationId.random(),
        "iron",
        2,
        5,
        Instant.now().plusSeconds(3600),
        false);
  }

  private void sql(String sql) throws Exception {
    try (var connection = DriverManager.getConnection("jdbc:sqlite:" + database());
        var statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }
}
