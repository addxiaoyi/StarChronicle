package dev.starcore.starcore.event.random;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * Scoped Paper/Folia callbacks. Admitted actions may finish; queued work cannot outlive this scope.
 */
public final class RandomEventRuntime {
  private final Plugin plugin;
  private final Set<Pending<?>> pending = ConcurrentHashMap.newKeySet();
  private final AtomicBoolean closed = new AtomicBoolean();

  public RandomEventRuntime(Plugin plugin) {
    this.plugin = java.util.Objects.requireNonNull(plugin);
  }

  public boolean isActive() {
    return !closed.get() && plugin.isEnabled();
  }

  public <T> CompletableFuture<T> player(Player player, Supplier<T> action) {
    if (player == null) return rejected("Missing original player");
    return submit(
        () -> Bukkit.isOwnedByCurrentRegion(player),
        () ->
            Bukkit.isOwnedByCurrentRegion(player)
                && player.isOnline()
                && plugin.getServer().getPlayer(player.getUniqueId()) == player,
        action,
        task -> player.getScheduler().run(plugin, ignored -> task.run(), task::retire));
  }

  public <T> CompletableFuture<T> global(Supplier<T> action) {
    return submit(
        Bukkit::isGlobalTickThread,
        Bukkit::isGlobalTickThread,
        action,
        task -> plugin.getServer().getGlobalRegionScheduler().run(plugin, ignored -> task.run()));
  }

  public <T> CompletableFuture<T> region(Location location, Function<Location, T> action) {
    return region(location, action, false);
  }

  /** Always yields to the next region tick, used for bounded block batches. */
  public <T> CompletableFuture<T> regionLater(Location location, Function<Location, T> action) {
    return region(location, action, true);
  }

  private <T> CompletableFuture<T> region(
      Location location, Function<Location, T> action, boolean later) {
    if (location == null || location.getWorld() == null) return rejected("Missing effect location");
    Location copy = location.clone();
    return submit(
        () -> !later && Bukkit.isOwnedByCurrentRegion(copy),
        () -> Bukkit.isOwnedByCurrentRegion(copy),
        () -> action.apply(copy),
        task ->
            later
                ? plugin
                    .getServer()
                    .getRegionScheduler()
                    .runDelayed(plugin, copy, ignored -> task.run(), 1L)
                : plugin.getServer().getRegionScheduler().run(plugin, copy, ignored -> task.run()));
  }

  public CompletableFuture<Location> location(Player player, Location supplied) {
    if (supplied != null) return CompletableFuture.completedFuture(supplied.clone());
    return player(player, () -> player.getLocation().clone());
  }

  /** Enumerates globally, then invokes every recipient only on its captured player owner. */
  public CompletableFuture<Void> forPlayers(Consumer<Player> action) {
    return global(() -> List.copyOf(plugin.getServer().getOnlinePlayers()))
        .thenCompose(
            players -> {
              CompletableFuture<?>[] callbacks =
                  players.stream()
                      .map(
                          player ->
                              player(
                                      player,
                                      () -> {
                                        action.accept(player);
                                        return null;
                                      })
                                  .exceptionally(
                                      failure -> {
                                        if (!cancelled(failure))
                                          throw new java.util.concurrent.CompletionException(
                                              failure);
                                        return null;
                                      }))
                      .toArray(CompletableFuture[]::new);
              return CompletableFuture.allOf(callbacks);
            });
  }

  public void shutdown() {
    if (!closed.compareAndSet(false, true)) return;
    List.copyOf(pending).forEach(Pending::retire);
  }

  public static boolean cancelled(Throwable failure) {
    while (failure instanceof java.util.concurrent.CompletionException
        && failure.getCause() != null) failure = failure.getCause();
    return failure instanceof CancellationException;
  }

  private static <T> CompletableFuture<T> rejected(String message) {
    return CompletableFuture.failedFuture(new CancellationException(message));
  }

  private <T> CompletableFuture<T> submit(
      BooleanSupplier inline,
      BooleanSupplier valid,
      Supplier<T> action,
      Function<Pending<T>, ScheduledTask> register) {
    Pending<T> task = new Pending<>(valid, action);
    pending.add(task);
    if (!isActive()) {
      task.retire();
      return task.result;
    }
    try {
      if (inline.getAsBoolean()) task.run();
      else task.attach(register.apply(task));
    } catch (Throwable failure) {
      task.fail(failure);
    }
    return task.result;
  }

  private final class Pending<T> {
    final CompletableFuture<T> result = new CompletableFuture<>();
    final AtomicBoolean claimed = new AtomicBoolean();
    final BooleanSupplier valid;
    final Supplier<T> action;
    ScheduledTask handle;
    boolean backendCancelled;

    Pending(BooleanSupplier valid, Supplier<T> action) {
      this.valid = valid;
      this.action = action;
      result.whenComplete(
          (value, failure) -> {
            pending.remove(this);
            cancelBackend();
          });
    }

    void run() {
      if (!claimed.compareAndSet(false, true) || result.isDone()) return;
      pending.remove(this);
      try {
        if (!isActive() || !valid.getAsBoolean()) {
          result.completeExceptionally(
              new CancellationException("Event owner retired before execution"));
          return;
        }
        result.complete(action.get());
      } catch (Throwable failure) {
        result.completeExceptionally(failure);
      }
    }

    void retire() {
      if (claimed.compareAndSet(false, true))
        result.completeExceptionally(
            new CancellationException("Event callback retired before execution"));
    }

    void fail(Throwable failure) {
      if (claimed.compareAndSet(false, true)) result.completeExceptionally(failure);
    }

    synchronized void attach(ScheduledTask handle) {
      this.handle = handle;
      if (handle == null) retire();
      if (result.isDone()) cancelBackend();
    }

    synchronized void cancelBackend() {
      if (handle == null || backendCancelled) return;
      backendCancelled = true;
      try {
        handle.cancel();
      } catch (IllegalStateException ignored) {
      }
    }
  }
}
