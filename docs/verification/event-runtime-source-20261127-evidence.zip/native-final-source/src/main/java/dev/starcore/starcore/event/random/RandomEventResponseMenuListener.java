package dev.starcore.starcore.event.random;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

/** 随机事件响应菜单监听器 处理玩家在事件响应菜单中的交互 */
public class RandomEventResponseMenuListener implements Listener {

  private final RandomEventService eventService;
  private final Map<UUID, RandomEventResponseMenu> openMenus;
  private final Set<Player> processingPlayers = ConcurrentHashMap.newKeySet();
  private volatile boolean closed;

  public RandomEventResponseMenuListener(RandomEventService eventService) {
    this.eventService = eventService;
    this.openMenus = new ConcurrentHashMap<>(); // Bug修复 #5: 线程安全
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getView().getTopInventory().getHolder() instanceof RandomEventResponseMenu) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.HIGH)
  public void onInventoryClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }

    Inventory top = event.getView().getTopInventory();
    if (!(top.getHolder() instanceof RandomEventResponseMenu menu)) {
      return;
    }

    event.setCancelled(true);
    if (closed
        || !eventService.currentPlayer(player)
        || menu.getPlayer() != player
        || openMenus.get(player.getUniqueId()) != menu
        || top != menu.getInventory()
        || event.getClickedInventory() != top) return;

    int slot = event.getRawSlot();

    // 检查是否是导航按钮
    if (handleNavigation(player, menu, slot)) {
      return;
    }

    // 检查是否是响应选项
    String responseId = menu.getResponseIdAtSlot(slot);
    if (responseId != null) {
      handleResponseSelection(player, menu, responseId);
    }
  }

  /** 处理导航按钮点击 */
  private boolean handleNavigation(Player player, RandomEventResponseMenu menu, int slot) {
    switch (slot) {
      case 45: // 上一页
        RandomEventResponseMenu prevPage = menu.createPrevPage();
        if (prevPage != null) {
          showMenu(prevPage);
          return true;
        }
        break;

      case 53: // 下一页
        RandomEventResponseMenu nextPage = menu.createNextPage();
        if (nextPage != null) {
          showMenu(nextPage);
          return true;
        }
        break;

      case 49: // 关闭按钮
        player.closeInventory();
        player.sendMessage(Component.text("已关闭事件响应，未提交选择。", NamedTextColor.GRAY));
        return true;
    }
    return false;
  }

  /** 处理响应选项选择 */
  private void handleResponseSelection(
      Player player, RandomEventResponseMenu menu, String responseId) {
    UUID playerId = player.getUniqueId();

    // Bug修复 #1: 防止重复点击
    if (!processingPlayers.add(player)) {
      return; // 正在处理中，忽略重复点击
    }

    try {
      RandomEvent event = menu.getEvent();
      RandomEvent.EventResponse response = event.getResponses().get(responseId);

      if (response == null) {
        player.sendMessage(Component.text("§c响应选项不存在！", NamedTextColor.RED));
        return;
      }

      if (!eventService.currentChain(player, menu.getEventChainId())) {
        openMenus.remove(playerId, menu);
        player.sendMessage(Component.text("此事件已过期或不属于当前玩家。", NamedTextColor.RED));
        if (player.getOpenInventory().getTopInventory() == menu.getInventory())
          player.closeInventory();
        return;
      }

      // 检查需求
      if (!response.meetsRequirements(player)) {
        player.sendMessage(Component.text("§c你尚未满足此响应的需求！", NamedTextColor.RED));
        return;
      }

      // Consume this exact UI attempt before any effect can reenter the listener.
      if (!openMenus.remove(playerId, menu)) return;

      // 执行响应
      boolean success =
          eventService.executeResponse(event, responseId, player, player.getLocation());

      if (success) {
        player.sendMessage(Component.text("§a你选择了: " + response.getName(), NamedTextColor.GREEN));
        player.sendMessage(Component.text("§7响应效果已生效。", NamedTextColor.GRAY));

        // 处理后续事件链
        UUID chainId = menu.getEventChainId();
        if (chainId != null) {
          eventService.processChainResponses(chainId, response.getChainEvents());
        }
      } else {
        player.sendMessage(Component.text("§c响应执行失败！", NamedTextColor.RED));
      }

      // 关闭菜单
      if (player.getOpenInventory().getTopInventory() == menu.getInventory())
        player.closeInventory();
    } catch (RuntimeException failure) {
      // An effect can fail after changing state. Keep the attempt consumed and do not retry it.
      openMenus.remove(playerId, menu);
      eventService.logResponseFailure(failure);
      player.sendMessage(Component.text("响应结果未能确认，请联系管理员核对；不要重复提交。", NamedTextColor.RED));
      if (player.getOpenInventory().getTopInventory() == menu.getInventory())
        player.closeInventory();
    } finally {
      processingPlayers.remove(player);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onInventoryClose(InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }

    Inventory inventory = event.getInventory();
    if (inventory.getHolder() instanceof RandomEventResponseMenu menu
        && menu.getPlayer() == player) {
      openMenus.remove(player.getUniqueId(), menu);
    }
  }

  /** 注册打开的菜单 */
  public void registerOpenMenu(RandomEventResponseMenu menu) {
    if (!closed && eventService.currentPlayer(menu.getPlayer()))
      openMenus.put(menu.getPlayer().getUniqueId(), menu);
  }

  void showMenu(RandomEventResponseMenu menu) {
    Player player = menu.getPlayer();
    if (closed || !eventService.currentPlayer(player)) return;
    menu.buildMenu();
    if (closed || !eventService.currentPlayer(player)) return;
    RandomEventResponseMenu previous = openMenus.put(player.getUniqueId(), menu);
    try {
      player.openInventory(menu.getInventory());
    } finally {
      if (player.getOpenInventory().getTopInventory() != menu.getInventory()
          && openMenus.remove(player.getUniqueId(), menu)
          && previous != null
          && previous.getPlayer() == player
          && !closed
          && player.getOpenInventory().getTopInventory() == previous.getInventory())
        openMenus.putIfAbsent(player.getUniqueId(), previous);
    }
  }

  /** 获取玩家打开的菜单 */
  public RandomEventResponseMenu getOpenMenu(Player player) {
    RandomEventResponseMenu menu = openMenus.get(player.getUniqueId());
    return menu != null && menu.getPlayer() == player ? menu : null;
  }

  /** 检查玩家是否有打开的菜单 */
  public boolean hasOpenMenu(Player player) {
    return getOpenMenu(player) != null;
  }

  // audit H-001: 修复 PlayerQuitEvent 未清理 Map 状态导致的内存泄漏和状态泄漏
  @EventHandler
  public void onPlayerQuit(PlayerQuitEvent event) {
    Player player = event.getPlayer();
    RandomEventResponseMenu menu = getOpenMenu(player);
    if (menu != null) openMenus.remove(player.getUniqueId(), menu);
    processingPlayers.remove(player);
  }

  public void shutdown() {
    closed = true;
    openMenus.clear();
    processingPlayers.clear();
    org.bukkit.event.HandlerList.unregisterAll(this);
  }
}
