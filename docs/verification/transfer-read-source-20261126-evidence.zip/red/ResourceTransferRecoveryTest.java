package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.NationResourceTransactionService.*;
import java.nio.file.Path;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class ResourceTransferRecoveryTest {
  @TempDir Path directory;
  private static final NationId PAYER = FactorySnapshotVersionTest.NATION;
  private static final NationId RECEIVER = new NationId(new UUID(0, 101));

  @AfterEach
  void shutdown() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static Stream<Arguments> storesAndCommitFailures() {
    return Stream.of("file", "sqlite", "h2")
        .flatMap(engine -> Stream.of(true, false).map(before -> Arguments.of(engine, before)));
  }

  @ParameterizedTest
  @MethodSource("storesAndCommitFailures")
  void uncertainTransferRetainsBothStocksAndSupportsOriginalIdRecovery(
      String engine, boolean before) throws Exception {
    var helper = new InventoryCommitRecoveryTest();
    helper.directory = directory;
    var fixture = helper.fixture(engine);
    var storage = fixture.storage();
    var seed = storage.load();
    seed.putAll(TradeSnapshotValidationTest.validTrade());
    storage.save(seed);
    var module = TradeSnapshotValidationTest.module(storage);
    var trade = TradeSnapshotValidationTest.encodedTrade(module);
    fixture.fault().arm(before, false);
    assertEquals(TransferStatus.UNKNOWN, module.transfer(request("uncertain")).status());
    assertEquals(before ? 6 : 4, module.amount(PAYER, "industrial"));
    assertEquals(before ? 0 : 2, module.amount(RECEIVER, "industrial"));
    assertEquals(!before, module.transferReceipt("uncertain").isPresent());
    assertEquals(before ? 0 : 1, module.transferReceiptsAfter(0, 10).size());
    assertEquals(trade, TradeSnapshotValidationTest.encodedTrade(module));
    assertEquals(
        before ? TransferStatus.APPLIED : TransferStatus.ALREADY_APPLIED,
        module.transfer(request("uncertain")).status());
    var restarted = TradeSnapshotValidationTest.module(storage);
    assertEquals(TransferStatus.ALREADY_APPLIED, restarted.transfer(request("uncertain")).status());
    assertEquals(4, restarted.amount(PAYER, "industrial"));
    assertEquals(2, restarted.amount(RECEIVER, "industrial"));
    assertEquals(trade, TradeSnapshotValidationTest.encodedTrade(restarted));
    assertEquals(
        fixture.domain(), restarted.transferReceipt("uncertain").orElseThrow().authorityDomainId());
    assertEquals(3, storage.latestProductionSequence());
    for (var run : fixture.runs().values())
      assertEquals(run, restarted.factoryRun(run.runId()).orElseThrow());
  }

  @ParameterizedTest
  @ValueSource(strings = {"file", "sqlite", "h2"})
  void restoredConnectionCannotExposeReceiptsWhileTheModuleRemainsQuarantined(String engine)
      throws Exception {
    var helper = new InventoryCommitRecoveryTest();
    helper.directory = directory;
    var fixture = helper.fixture(engine);
    var module = fixture.module();
    fixture.fault().arm(false, true);
    assertEquals(TransferStatus.UNKNOWN, module.transfer(request("committed")).status());
    assertEquals("", module.authorityDomainId());
    fixture.fault().unreadable = false;
    var persisted = fixture.storage().load();
    assertThrows(IllegalStateException.class, () -> module.transferReceipt("committed"));
    assertThrows(IllegalStateException.class, () -> module.transferReceipt("absent"));
    assertThrows(IllegalStateException.class, () -> module.transferReceiptsAfter(0, 10));
    assertEquals(TransferStatus.UNAVAILABLE, module.transfer(request("new")).status());
    assertEquals(persisted, fixture.storage().load());
    var recovered = fixture.module();
    assertEquals(fixture.domain(), recovered.authorityDomainId());
    assertEquals(TransferStatus.ALREADY_APPLIED, recovered.transfer(request("committed")).status());
    assertEquals(4, recovered.amount(PAYER, "industrial"));
    assertEquals(2, recovered.amount(RECEIVER, "industrial"));
    assertEquals(1, recovered.transferReceiptsAfter(0, 10).size());
    assertTrue(recovered.transferReceipt("absent").isEmpty());
  }

  @Test
  void noStorageIsUnavailableRatherThanProofOfMissingReceipt() {
    var module = new ResourceModule();
    assertThrows(IllegalStateException.class, () -> module.transferReceipt("absent"));
    assertThrows(IllegalStateException.class, () -> module.transferReceiptsAfter(0, 10));
    assertTrue(module.transferReceipt(null).isEmpty());
    assertTrue(module.transferReceipt("  ").isEmpty());
    assertThrows(IllegalArgumentException.class, () -> module.transferReceiptsAfter(-1, 1));
    assertThrows(IllegalArgumentException.class, () -> module.transferReceiptsAfter(0, 1001));
  }

  static Stream<Arguments> readDuringWrite() {
    return Stream.of("none", "before", "after")
        .flatMap(failure -> Stream.of("one", "page").map(read -> Arguments.of(failure, read)));
  }

  @ParameterizedTest
  @MethodSource("readDuringWrite")
  void receiptReadWaitsForTransferCommitAndFullReconciliation(String failure, String reader)
      throws Exception {
    var saving = new CountDownLatch(1);
    var release = new CountDownLatch(1);
    var reading = new CountDownLatch(1);
    var armed = new AtomicBoolean();
    var storage =
        new ProductionPersistenceTest.MemoryStorage() {
          @Override
          public void save(Properties state) {
            if (armed.getAndSet(false)) {
              saving.countDown();
              try {
                if (!release.await(5, TimeUnit.SECONDS))
                  throw new IllegalStateException("test save timeout");
              } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(error);
              }
              failBefore = failure.equals("before");
              failAfter = failure.equals("after");
            }
            super.save(state);
          }
        };
    var module = new ResourceModule(storage);
    assertTrue(module.grant(PAYER, "industrial", 6));
    armed.set(true);
    try (var workers = Executors.newFixedThreadPool(2)) {
      try {
        var write = workers.submit(() -> module.transfer(request("waiting")).status());
        assertTrue(saving.await(5, TimeUnit.SECONDS));
        var read =
            workers.submit(
                () -> {
                  reading.countDown();
                  return reader.equals("one")
                      ? module.transferReceipt("waiting").isPresent()
                      : !module.transferReceiptsAfter(0, 10).isEmpty();
                });
        assertTrue(reading.await(5, TimeUnit.SECONDS));
        assertThrows(TimeoutException.class, () -> read.get(100, TimeUnit.MILLISECONDS));
        release.countDown();
        assertEquals(
            failure.equals("none") ? TransferStatus.APPLIED : TransferStatus.UNKNOWN,
            write.get(5, TimeUnit.SECONDS));
        assertEquals(!failure.equals("before"), read.get(5, TimeUnit.SECONDS));
        assertEquals(failure.equals("before") ? 6 : 4, module.amount(PAYER, "industrial"));
        assertEquals(failure.equals("before") ? 0 : 2, module.amount(RECEIVER, "industrial"));
      } finally {
        release.countDown();
      }
    }
  }

  private static TransferRequest request(String id) {
    return new TransferRequest(id, PAYER, RECEIVER, Map.of("industrial", 2L), Category.OTHER, id);
  }
}
