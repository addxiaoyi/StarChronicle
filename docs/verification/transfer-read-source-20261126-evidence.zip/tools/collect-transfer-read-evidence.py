import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


for label in ('resource-test', 'package', 'sbom'):
    log = (root / f'run/transfer-read-{label}-20261126.log').read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESS' in log and 'BUILD FAILURE' not in log, label
text = (root / 'run/transfer-read-resource-test-20261126.log').read_text(encoding='utf-8', errors='replace')
totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
by_package = {}
new_tests = None
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', text):
    report = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
    suite = ET.fromstring(report.read_bytes())
    package = 'resource' if '.resource.' in name else 'technology'
    by_package[package] = by_package.get(package, 0) + int(suite.attrib['tests'])
    for key in totals:
        totals[key] += int(suite.attrib[key])
    if name.endswith('.ResourceTransferRecoveryTest'):
        new_tests = int(suite.attrib['tests'])
    add(report, 'native-final/surefire/' + report.name)
assert new_tests == 16
assert by_package == {'resource': 1049, 'technology': 13}
assert all(totals[key] == 0 for key in ('failures', 'errors', 'skipped'))
red_xml = next((root / 'run/transfer-read-red-20261126').glob('TEST-*.xml'))
red = ET.fromstring(red_xml.read_bytes())
red_totals = {key: int(red.attrib[key]) for key in totals}
assert red_totals == {'tests': 16, 'failures': 7, 'errors': 0, 'skipped': 0}
for path in (root / 'run/transfer-read-red-20261126').iterdir():
    add(path, 'red/' + path.name)
for directory in (root / 'run').glob('transfer-read-failure-*'):
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.xml', '.java'):
            add(path, 'prior-failures/' + directory.name + '/' + path.relative_to(directory).as_posix())
for path in (root / 'run').glob('transfer-read-*.log'):
    add(path, 'logs/' + path.name)
add(root / 'run/quota-renewal-final-ci-20261126.json', 'github/baseline-ci.json')
directory = root / 'run/factory-contract-transfer-read-20261126-1'
contract = json.loads((directory / 'manifest.json').read_text())
assert contract['status'] == 'PASS'
for path in directory.rglob('*'):
    if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java'):
        add(path, 'factory/' + path.relative_to(directory).as_posix())
for name in ('FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-transfer-read-evidence.py')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
source_hashes = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        source_hashes[name] = digest((native / name).read_bytes())
starcore_hash = digest((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle_hash = digest((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore_hash == contract['artifacts']['starcore.jar']
assert chronicle_hash == contract['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': '92960570f6dec99c34659486a92064db4c69f431',
                  'starcore': '983eec0ed97efe04269753b04fffa9b91b5580a4'},
    'scope': 'Native single/page transfer receipts wait for inventory commit and full reconciliation, throw while authority is unavailable even if storage connectivity returns; exact-ID retry and both-stockpile recovery across file/SQLite/H2; no Minecraft',
    'red_tests': red_totals, 'native_tests': totals, 'tests_by_package': by_package,
    'new_transfer_recovery_tests': new_tests,
    'packaging': 'Separate sequential 256 MiB JVMs for tests and packaging. Fresh verify skips recompilation and tests, uses the tested class output and checks format. Independent online SBOM.',
    'chronicle_tests': 'Main source unchanged; previous 957-test JAR. Baseline Linux Maven verification #133 passed. No new local full verify.',
    'artifacts': {'starcore_sha256': starcore_hash, 'starchronicle_sha256': chronicle_hash},
    'factory_contract': contract, 'native_source_hashes': source_hashes,
    'coverage': 'No current native full suite or JaCoCo; forkCount=0 and jacoco.skip=true',
    'limits': [
        'Native receipt queries throw for missing storage, missing domain or quarantined authority; connectivity alone does not recover the module. Empty IDs and invalid paging retain existing handling.',
        'Transfer failures retain UNKNOWN and require reconciliation/retry under the original ID; this does not create stable trade-agreement execution IDs or cross-service atomicity.',
        'Unsupported default providers do not establish a durable native authority; provider support must be checked independently.',
        'No new synchronous quota persistence, source authentication or multi-writer transaction contract.',
        'Previous 5000-run factory capacity results belong to a preceding exact artifact, not this build.',
        'File/SQLite/H2 and packaged services do not certify Minecraft, MySQL, Folia or third-party plugin stacks.'
    ]
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: digest(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/transfer-read-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()):
        archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(archive.read(name)) == expected
summary['evidence_zip_sha256'] = digest(output.read_bytes())
summary['evidence_files'] = len(files)
(output.parent / 'transfer-read-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': by_package, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
