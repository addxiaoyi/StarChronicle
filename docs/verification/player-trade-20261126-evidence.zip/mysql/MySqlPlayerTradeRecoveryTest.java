package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;

import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.Connection;
import java.util.HashSet;
import java.util.Set;
import javax.sql.DataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

/** Runs the same restart/call-window/atomicity cases on a dedicated empty MySQL catalog. */
@EnabledIfSystemProperty(named = "starcore.mysql.settlement.it", matches = "true")
class MySqlPlayerTradeRecoveryTest extends PlayerTradeRecoveryTest {
  private static final Set<String> TABLES =
      Set.of(
          "starcore_resource_state",
          "starcore_resource_transfer_receipts",
          "starcore_resource_state_migrations",
          "starcore_resource_transfer_history",
          "starcore_resource_revision",
          "starcore_nation_trade_offers",
          "starcore_nation_trade_head",
          "starcore_nation_trade_settlements",
          "starcore_nation_production_head",
          "starcore_nation_production_events",
          "starcore_nation_factory_head",
          "starcore_nation_factory_events",
          "starcore_treasury_state",
          "starcore_player_trade_head",
          "starcore_player_trade_events");
  private MysqlDataSource mysql;
  private boolean owned;

  @Override
  protected DataSource newSource() throws Exception {
    String url = System.getenv("STARCORE_SETTLEMENT_MYSQL_URL");
    assertThat(url).matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/starcore_settlement_it(?:\\?.*)?");
    assertThat(url).doesNotContain("127.0.0.1:3306/");
    mysql = new MysqlDataSource();
    mysql.setURL(url);
    mysql.setUser(System.getenv("STARCORE_SETTLEMENT_MYSQL_USER"));
    mysql.setPassword(System.getenv("STARCORE_SETTLEMENT_MYSQL_PASSWORD"));
    try (var c = mysql.getConnection()) {
      assertThat(c.getCatalog()).isEqualTo("starcore_settlement_it");
      assertThat(c.getMetaData().getDatabaseProductName()).isEqualTo("MySQL");
      try (var s = c.createStatement();
          var r =
              s.executeQuery(
                  "SELECT @@default_storage_engine,@@transaction_isolation,@@sql_mode")) {
        assertThat(r.next()).isTrue();
        assertThat(r.getString(1)).isEqualToIgnoringCase("InnoDB");
        assertThat(r.getString(2)).isEqualTo("REPEATABLE-READ");
        assertThat(r.getString(3)).contains("STRICT_TRANS_TABLES");
      }
      for (String table : tables(c)) {
        assertThat(TABLES).contains(table);
        try (var s = c.createStatement();
            var r = s.executeQuery("SELECT 1 FROM " + table + " LIMIT 1")) {
          assertThat(r.next()).as("Dedicated fixture must be empty: " + table).isFalse();
        }
      }
      try (var s = c.createStatement();
          var r = s.executeQuery("SHOW TRIGGERS")) {
        assertThat(r.next()).as("No preexisting fixture triggers").isFalse();
      }
    }
    owned = true;
    return mysql;
  }

  @AfterEach
  void cleanOwnedFixture() throws Exception {
    if (!owned) return;
    dev.starcore.starcore.core.storage.AbstractModuleStateStorage.shutdownNamespace("test");
    try (var c = mysql.getConnection();
        var s = c.createStatement()) {
      c.setAutoCommit(false);
      for (String table : tables(c)) {
        if (!TABLES.contains(table)) throw new IllegalStateException("Unexpected fixture table");
        s.executeUpdate("DELETE FROM " + table);
      }
      c.commit();
    }
  }

  private Set<String> tables(Connection c) throws Exception {
    var result = new HashSet<String>();
    try (var s = c.createStatement();
        var r = s.executeQuery("SHOW TABLES")) {
      while (r.next()) result.add(r.getString(1));
    }
    return result;
  }
}
