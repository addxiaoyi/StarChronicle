# Trade journal merge compatibility

The merge retains installed `trade_commit_authority` / `trade_commit_log` rows,
domain, sequence, operation IDs, timestamps, baseline flags and encoded payloads.
`historyAuthorityDomainId()` still returns `Optional<UUID>` and
`committedChangesAfter` still returns the existing resource-package record with a
1..100 limit. The upstream UUID-returning domain getter conflicted at the Java
signature level and is named `tradeHistoryAuthorityDomainId()` in this branch.
Consumers of the upstream UUID-returning getter must recompile against the new
name; the archived upstream JAR and evidence are unchanged.

The settlement implementation is `SettlementTradeJournal`. It stores the upstream
`trade_history_authority`, identity, commits and prepared-operation tables.
`tradeChangesAfter` exposes its separate 1..128 sequence and model-package record,
including previous status and actual transaction occurrence time. Never exchange
cursors between these two API streams, even if they share a domain UUID.

For an installed legacy journal, the settlement authority adopts its domain and
seeds only identity snapshots, including pruned query records and original
nanoseconds. It does not invent historical settlement commits. New query, legacy
receipt, settlement receipt and preparation acknowledgement writes share one SQL
transaction. A failure in either journal rolls all of them back. Startup rejects
different domains, missing identities or disagreement between the two journals.
The original log bytes are not rewritten.

Fresh databases and existing upstream databases use the settlement journal alone.
The existing `committedChangesAfter` API adapts those receipts with deterministic
operation UUIDs derived from their domain and sequence, so Chronicle's existing
generic trade source can consume them consistently across restarts. It follows
the generic source's existing historical-import semantics; it is not the separate
technology source's first-install archive-only protocol. No second native log is
created for this mode.

Legacy stores keep their previous explicit `saveRecord(s)` amendment/restoration
behavior for unprepared records. Prepared records require their durable transaction
receipt. Fresh/upstream stores keep strict identical-save semantics; explicit
status amendments use `updateStatus`, and a stale save does not resurrect a pruned
query row. Both modes reject identity rebinding and preserve audit history.

SQL history repair only consumes saved TransactionFabric events and does not call
asset APIs. The upstream market escrow and administrator reconciliation limits
still apply. Database-copy probes, Java API/bytecode checks and unit tests do not
certify live Paper/Folia behavior, MySQL or full cross-system atomic settlement.
After upgrading a legacy database, do not run the old writer against it: its
one-journal writes would leave the new settlement journal inconsistent.

The upstream report COMMITTED-TRADE-HISTORY-2026-11-26.md documents its original
`a645272` build; merged-branch verification is recorded separately in the paired
StarChronicle repository.
