package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.MarketOrderBook;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/** 市场订单簿服务实现 */
public class SimpleMarketOrderBookService implements MarketOrderBookService {
  private final Map<String, MarketOrderBook> orderBooks;
  private final Map<UUID, TradeOrder> allOrders;
  private final Map<UUID, BuyEscrow> buyEscrows;
  private final Map<UUID, List<TradeRecord>> tradeRecords; // 玩家交易记录
  private final Map<String, List<TradeRecord>> resourceTradeHistory; // 资源交易历史

  private final ResourceService resourceService;
  private final EconomyService economyService;
  private final TradeTaxService taxService;
  private final ResourceTariff tariff;
  // 订单速率限制：每玩家每分钟最多下单数
  private static final int MAX_ORDERS_PER_MINUTE = 20;
  private static final long ORDER_COOLDOWN_MS = 60_000L;
  private final Map<UUID, long[]> orderRateTracker = new java.util.concurrent.ConcurrentHashMap<>();

  private StarCoreScheduler scheduler;
  private StarCoreEventBus eventBus;
  private TradeHistoryService tradeHistoryService;
  private TransactionFabric transactionFabric;
  private TradeSettlementCoordinator settlementCoordinator;
  private final Set<UUID> ordersAwaitingReconciliation = ConcurrentHashMap.newKeySet();

  // 价格来源（当订单簿为空时使用）
  private ResourcePriceService priceService;

  public SimpleMarketOrderBookService(
      ResourceService resourceService, EconomyService economyService, TradeTaxService taxService) {
    this(resourceService, economyService, taxService, null);
  }

  SimpleMarketOrderBookService(
      ResourceService resourceService,
      EconomyService economyService,
      TradeTaxService taxService,
      ResourceTariff tariff) {
    this.resourceService = Objects.requireNonNull(resourceService, "resourceService");
    this.economyService = Objects.requireNonNull(economyService, "economyService");
    this.taxService = Objects.requireNonNull(taxService, "taxService");
    this.tariff = tariff;
    this.orderBooks = new ConcurrentHashMap<>();
    this.allOrders = new ConcurrentHashMap<>();
    this.buyEscrows = new ConcurrentHashMap<>();
    this.tradeRecords = new ConcurrentHashMap<>();
    this.resourceTradeHistory = new ConcurrentHashMap<>();
  }

  /** 设置调度器 */
  public void setScheduler(StarCoreScheduler scheduler) {
    this.scheduler = scheduler;
    if (scheduler != null) {
      // 每30秒匹配一次订单
      scheduler.runSyncTimer(() -> matchAllOrders(), 30 * 20L, 30 * 20L);
      // 每分钟清理过期订单
      scheduler.runSyncTimer(() -> cleanExpiredOrders(), 60 * 20L, 60 * 20L);
    }
  }

  /** 设置事件总线 */
  public void setEventBus(StarCoreEventBus eventBus) {
    this.eventBus = eventBus;
  }

  public void setTradeHistoryService(TradeHistoryService tradeHistoryService) {
    this.tradeHistoryService = tradeHistoryService;
    configureSettlementCoordinator();
  }

  public void setTransactionFabric(TransactionFabric transactionFabric) {
    this.transactionFabric = transactionFabric;
    configureSettlementCoordinator();
  }

  private void configureSettlementCoordinator() {
    this.settlementCoordinator =
        tradeHistoryService == null || transactionFabric == null
            ? null
            : new TradeSettlementCoordinator(tradeHistoryService, transactionFabric, logger());
  }

  public Set<UUID> ordersAwaitingReconciliation() {
    return Set.copyOf(ordersAwaitingReconciliation);
  }

  /** 设置价格服务 */
  public void setPriceService(ResourcePriceService priceService) {
    this.priceService = priceService;
  }

  @Override
  public MarketOrderBook getOrderBook(String resourceId) {
    String normalized = requireResourceId(resourceId);
    return orderBooks.computeIfAbsent(normalized, MarketOrderBook::new);
  }

  @Override
  public Collection<MarketOrderBook> getAllOrderBooks() {
    return List.copyOf(orderBooks.values());
  }

  /** 订单速率限制：每玩家每分钟最多 MAX_ORDERS_PER_MINUTE 订单 防止恶意玩家刷订单 */
  private boolean tryAcquireOrderSlot(UUID playerId) {
    if (playerId == null) {
      return true; // 空ID跳过限速（上游已有空值检查）
    }
    long now = System.currentTimeMillis();
    long[] tracker = orderRateTracker.computeIfAbsent(playerId, k -> new long[] {0L, 0L});
    synchronized (tracker) {
      if (now - tracker[0] >= ORDER_COOLDOWN_MS) {
        tracker[0] = now;
        tracker[1] = 1;
        return true;
      }
      if (tracker[1] >= MAX_ORDERS_PER_MINUTE) {
        return false;
      }
      tracker[1]++;
      return true;
    }
  }

  @Override
  public Optional<TradeRecord> submitBuyOrder(
      UUID playerId,
      NationId nationId,
      String resourceId,
      long amount,
      double pricePerUnit,
      Instant expiryTime) {
    if (settlementCoordinator == null) {
      logger()
          .warning(
              "Trade history and transaction fabric are required before reserving market assets");
      return Optional.empty();
    }
    if (playerId == null || nationId == null || expiryTime == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Player, nation and expiry are required"));
      return Optional.empty();
    }
    if (!expiryTime.isAfter(Instant.now())) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Order expiry must be in the future"));
      return Optional.empty();
    }

    ResourceTradeTerms.Validation validation =
        ResourceTradeTerms.validateOrder(resourceId, amount, pricePerUnit);
    if (!validation.isValid()) {
      publishEvent(
          new OrderRejectedEvent(
              playerId,
              String.valueOf(resourceId),
              "Invalid order terms: " + validation.violation()));
      return Optional.empty();
    }
    ResourceTradeTerms terms = validation.terms();
    String resId = terms.resourceId();
    amount = terms.amount();
    pricePerUnit = terms.pricePerUnitAsDouble();
    BigDecimal price = terms.pricePerUnit();
    BigDecimal totalCost = price.multiply(BigDecimal.valueOf(amount));
    BigDecimal tax =
        taxService.calculateTaxBD(resId, totalCost, TradeTaxService.TaxType.TRANSACTION_FEE);
    if (!tryAcquireOrderSlot(playerId)) {
      publishEvent(
          new OrderRejectedEvent(playerId, resId, "Order rate limit exceeded (max 20 per minute)"));
      return Optional.empty();
    }
    MarketOrderBook book = getOrderBook(resId);
    TradeOrder order;
    String rejectionReason;

    synchronized (book) {
      BigDecimal escrowAmount = totalCost.add(tax);
      if (!economyService.has(playerId, escrowAmount)) {
        order = null;
        rejectionReason = "Insufficient funds";
      } else if (!economyService.withdraw(playerId, escrowAmount)) {
        order = null;
        rejectionReason = "Escrow freeze failed";
      } else {
        UUID orderId = UUID.randomUUID();
        order =
            new TradeOrder(
                orderId,
                TradeOrder.OrderType.BUY,
                TradeOrder.OrderSource.PLAYER,
                playerId,
                nationId,
                resId,
                pricePerUnit,
                amount,
                expiryTime,
                false);
        book.addBuyOrder(order);
        allOrders.put(orderId, order);
        buyEscrows.put(orderId, new BuyEscrow(escrowAmount));
        rejectionReason = null;
      }
    }

    if (order == null) {
      publishEvent(new OrderRejectedEvent(playerId, resId, rejectionReason));
      return Optional.empty();
    }
    publishEvent(new OrderSubmittedEvent(order));
    return Optional.empty(); // 订单进入订单簿，等待匹配
  }

  @Override
  public Optional<TradeRecord> submitSellOrder(
      UUID playerId,
      NationId nationId,
      String resourceId,
      long amount,
      double pricePerUnit,
      Instant expiryTime) {
    if (settlementCoordinator == null) {
      logger()
          .warning(
              "Trade history and transaction fabric are required before reserving market assets");
      return Optional.empty();
    }
    if (playerId == null || nationId == null || expiryTime == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Player, nation and expiry are required"));
      return Optional.empty();
    }
    if (!expiryTime.isAfter(Instant.now())) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Order expiry must be in the future"));
      return Optional.empty();
    }

    ResourceTradeTerms.Validation validation =
        ResourceTradeTerms.validateOrder(resourceId, amount, pricePerUnit);
    if (!validation.isValid()) {
      publishEvent(
          new OrderRejectedEvent(
              playerId,
              String.valueOf(resourceId),
              "Invalid order terms: " + validation.violation()));
      return Optional.empty();
    }
    ResourceTradeTerms terms = validation.terms();
    String resId = terms.resourceId();
    amount = terms.amount();
    pricePerUnit = terms.pricePerUnitAsDouble();
    if (!tryAcquireOrderSlot(playerId)) {
      publishEvent(
          new OrderRejectedEvent(playerId, resId, "Order rate limit exceeded (max 20 per minute)"));
      return Optional.empty();
    }
    MarketOrderBook book = getOrderBook(resId);
    TradeOrder order;
    String rejectionReason;

    synchronized (book) {
      if (resourceService.amount(nationId, resId) < amount) {
        order = null;
        rejectionReason = "Insufficient resources";
      } else if (!resourceService.consume(nationId, resId, amount)) {
        order = null;
        rejectionReason = "Escrow freeze (resource) failed";
      } else {
        UUID orderId = UUID.randomUUID();
        order =
            new TradeOrder(
                orderId,
                TradeOrder.OrderType.SELL,
                TradeOrder.OrderSource.PLAYER,
                playerId,
                nationId,
                resId,
                pricePerUnit,
                amount,
                expiryTime,
                false);
        book.addSellOrder(order);
        allOrders.put(orderId, order);
        rejectionReason = null;
      }
    }

    if (order == null) {
      publishEvent(new OrderRejectedEvent(playerId, resId, rejectionReason));
      return Optional.empty();
    }
    publishEvent(new OrderSubmittedEvent(order));
    return Optional.empty(); // 订单进入订单簿，等待匹配
  }

  @Override
  public Optional<TradeRecord> submitMarketBuyOrder(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    if (playerId == null || nationId == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Player and nation are required"));
      return Optional.empty();
    }
    String resId = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (resId == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Invalid order terms: INVALID_RESOURCE_ID"));
      return Optional.empty();
    }
    double marketPrice = getCurrentMarketPrice(resId);
    Instant expiry = Instant.now().plus(Duration.ofMinutes(5));

    // 市价单：使用市场当前价格或基准价格
    if (marketPrice <= 0 && priceService != null) {
      marketPrice = priceService.getCurrentPrice(resId);
    }
    if (marketPrice <= 0) {
      marketPrice = 100.0; // 默认价格
    }

    return submitBuyOrder(playerId, nationId, resId, amount, marketPrice, expiry);
  }

  @Override
  public Optional<TradeRecord> submitMarketSellOrder(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    if (playerId == null || nationId == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Player and nation are required"));
      return Optional.empty();
    }
    String resId = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (resId == null) {
      publishEvent(
          new OrderRejectedEvent(
              playerId, String.valueOf(resourceId), "Invalid order terms: INVALID_RESOURCE_ID"));
      return Optional.empty();
    }
    double marketPrice = getCurrentMarketPrice(resId);
    Instant expiry = Instant.now().plus(Duration.ofMinutes(5));

    if (marketPrice <= 0 && priceService != null) {
      marketPrice = priceService.getCurrentPrice(resId);
    }
    if (marketPrice <= 0) {
      marketPrice = 100.0;
    }

    return submitSellOrder(playerId, nationId, resId, amount, marketPrice, expiry);
  }

  @Override
  public boolean cancelOrder(UUID actorPlayerId, UUID orderId) {
    if (actorPlayerId == null || orderId == null) {
      return false;
    }
    TradeOrder order = allOrders.get(orderId);
    if (order == null
        || order.playerId().isEmpty()
        || !actorPlayerId.equals(order.playerId().orElseThrow())) {
      return false;
    }
    return cancelOrderInternal(orderId);
  }

  private boolean cancelOrderInternal(UUID orderId) {
    TradeOrder order = allOrders.get(orderId);
    if (order == null) {
      return false;
    }
    MarketOrderBook book = getOrderBook(order.resourceId());
    synchronized (book) {
      TradeOrder current = allOrders.get(orderId);
      if (current != order || ordersAwaitingReconciliation.contains(orderId)) {
        return false;
      }

      // The matching path holds this lock, so refund and removal observe one order state.
      if (order.status() != TradeOrder.OrderStatus.PENDING
          && order.status() != TradeOrder.OrderStatus.PARTIAL) {
        return false;
      }

      long remainingAmount = order.remainingAmount();
      UUID playerId = order.playerId().orElse(null);
      NationId nationId = order.nationId().orElse(null);
      BigDecimal buyerRefund = BigDecimal.ZERO;
      boolean sellerResourceRefunded = false;

      // Refund first. A failed refund must leave the order cancellable instead of
      // losing the only reference to its escrow.
      if (remainingAmount > 0 && order.type() == TradeOrder.OrderType.BUY && playerId != null) {
        BuyEscrow escrow = buyEscrows.get(orderId);
        buyerRefund = escrow == null ? BigDecimal.ZERO : escrow.balance();
        if (escrow == null || !deposit(playerId, buyerRefund, "cancel buy order")) {
          return false;
        }
      } else if (remainingAmount > 0
          && order.type() == TradeOrder.OrderType.SELL
          && playerId != null
          && nationId != null) {
        if (!resourceService.grant(nationId, order.resourceId(), remainingAmount)) {
          logger().warning("[cancelOrder] resource refund failed; order=" + orderId);
          return false;
        }
        sellerResourceRefunded = true;
      }

      if (book.removeOrder(orderId)) {
        buyEscrows.remove(orderId);
        order.cancel();
        allOrders.remove(orderId, order);
        publishEvent(new OrderCancelledEvent(order));
        return true;
      }

      rollbackCancelledOrderRefund(
          order, playerId, nationId, buyerRefund, remainingAmount, sellerResourceRefunded);
      return false;
    }
  }

  @Override
  public Optional<TradeOrder> getOrder(UUID orderId) {
    if (orderId == null) {
      return Optional.empty();
    }
    return Optional.ofNullable(allOrders.get(orderId));
  }

  @Override
  public List<TradeOrder> getPlayerOrders(UUID playerId) {
    if (playerId == null) {
      return List.of();
    }
    return allOrders.values().stream()
        .filter(o -> o.playerId().isPresent() && o.playerId().get().equals(playerId))
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeOrder> getNationOrders(NationId nationId) {
    if (nationId == null) {
      return List.of();
    }
    return allOrders.values().stream()
        .filter(o -> o.nationId().isPresent() && o.nationId().get().equals(nationId))
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeOrder> getPlayerOrdersForResource(UUID playerId, String resourceId) {
    String normalized = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (playerId == null || normalized == null) {
      return List.of();
    }
    return allOrders.values().stream()
        .filter(o -> o.playerId().isPresent() && o.playerId().get().equals(playerId))
        .filter(o -> o.resourceId().equals(normalized))
        .collect(Collectors.toList());
  }

  @Override
  public int matchOrders(String resourceId) {
    MarketOrderBook book = findOrderBook(resourceId);
    if (book == null) {
      return 0;
    }
    AtomicInteger matchCount = new AtomicInteger(0);

    // audit B-069: 之前 matchOrders 用 ArrayList 复制订单再 executeMatch(synchronized)，
    // 但 executeMatch 内部仅本方法同步，不阻止并发 submitBuyOrder 同时 addBuyOrder 到同一 book，
    // 导致 matchOrders 复制的快照已过期。修复：在 match 期间对 book 加锁，阻止并发 submit。
    synchronized (book) {
      List<TradeOrder> buyOrders = new ArrayList<>(book.getBuyOrders());
      List<TradeOrder> sellOrders = new ArrayList<>(book.getSellOrders());

      for (TradeOrder buyOrder : buyOrders) {
        if (buyOrder.status() != TradeOrder.OrderStatus.PENDING
                && buyOrder.status() != TradeOrder.OrderStatus.PARTIAL
            || buyOrder.isExpired()) {
          continue;
        }

        for (TradeOrder sellOrder : sellOrders) {
          if (sellOrder.status() != TradeOrder.OrderStatus.PENDING
                  && sellOrder.status() != TradeOrder.OrderStatus.PARTIAL
              || sellOrder.isExpired()) {
            continue;
          }

          if (settlementCoordinator == null
              || ordersAwaitingReconciliation.contains(buyOrder.orderId())
              || ordersAwaitingReconciliation.contains(sellOrder.orderId())
              || buyOrder.remainingAmount() <= 0
              || sellOrder.remainingAmount() <= 0) {
            continue;
          }

          // 检查价格是否匹配：买单价格 >= 卖单价格
          if (buyOrder.pricePerUnit() >= sellOrder.pricePerUnit()) {
            Optional<TradeRecord> record = executeMatch(buyOrder, sellOrder);
            if (record.isPresent()) {
              matchCount.incrementAndGet();
            }
          }
        }
      }
    }

    return matchCount.get();
  }

  /** 执行订单匹配 */
  private synchronized Optional<TradeRecord> executeMatch(
      TradeOrder buyOrder, TradeOrder sellOrder) {
    if (settlementCoordinator == null
        || ordersAwaitingReconciliation.contains(buyOrder.orderId())
        || ordersAwaitingReconciliation.contains(sellOrder.orderId())
        || buyOrder.remainingAmount() <= 0
        || sellOrder.remainingAmount() <= 0
        || buyOrder.isExpired()
        || sellOrder.isExpired()) {
      return Optional.empty();
    }

    // 计算成交数量和价格
    long fillAmount = Math.min(buyOrder.remainingAmount(), sellOrder.remainingAmount());
    // 成交价格：使用卖单价格（价格优先）
    BigDecimal fillPrice = BigDecimal.valueOf(sellOrder.pricePerUnit());
    BigDecimal fillQty = BigDecimal.valueOf(fillAmount);
    BigDecimal totalValue = fillPrice.multiply(fillQty);

    // 计算税收
    BigDecimal taxAmount =
        taxService.calculateTaxBD(
            buyOrder.resourceId(), totalValue, TradeTaxService.TaxType.TRANSACTION_FEE);

    // 执行资金转移
    UUID buyerId = buyOrder.playerId().orElse(null);
    UUID sellerId = sellOrder.playerId().orElse(null);

    if (buyerId != null && sellerId != null) {
      BuyEscrow escrow = buyEscrows.get(buyOrder.orderId());
      if (escrow == null) {
        logger().warning("[executeMatch] missing buy escrow; order=" + buyOrder.orderId());
        return Optional.empty();
      }
      BigDecimal reservedGross = BigDecimal.valueOf(buyOrder.pricePerUnit()).multiply(fillQty);
      BigDecimal reservedFee =
          taxService.calculateTaxBD(
              buyOrder.resourceId(), reservedGross, TradeTaxService.TaxType.TRANSACTION_FEE);
      BigDecimal reserved = reservedGross.add(reservedFee);
      BigDecimal spent = totalValue.add(taxAmount);
      BigDecimal refund = reserved.subtract(spent);
      ResourceTariff.Trade tariffTrade =
          tariff == null
              ? null
              : tariff.prepare(
                  matchFeeId(buyOrder, sellOrder),
                  buyerId,
                  buyOrder.nationId().orElse(null),
                  sellerId,
                  sellOrder.nationId().orElse(null),
                  totalValue);
      BigDecimal tariffAmount = tariffTrade == null ? BigDecimal.ZERO : tariffTrade.tariffAmount();

      if (escrow.balance().compareTo(reserved) < 0) {
        logger().warning("[executeMatch] insufficient buy escrow; order=" + buyOrder.orderId());
        return Optional.empty();
      }
      // Freeze the plan before the first external match side effect.
      TradeRecord planned =
          TradeRecord.createMarketTrade(
              buyerId,
              sellerId,
              buyOrder.nationId().orElse(null),
              sellOrder.nationId().orElse(null),
              buyOrder.resourceId(),
              fillAmount,
              fillPrice.doubleValue(),
              taxAmount.doubleValue(),
              buyOrder.orderId(),
              sellOrder.orderId());

      TransactionRecord settlement =
          settlementCoordinator.prepare(
              matchFeeId(buyOrder, sellOrder),
              buyerId,
              reserved.add(tariffAmount),
              "trade:market:" + matchFeeId(buyOrder, sellOrder),
              planned,
              Map.ofEntries(
                  Map.entry("buyAmount", Long.toString(buyOrder.totalAmount())),
                  Map.entry("sellAmount", Long.toString(sellOrder.totalAmount())),
                  Map.entry("buyFilledBefore", Long.toString(buyOrder.filledAmount())),
                  Map.entry("sellFilledBefore", Long.toString(sellOrder.filledAmount())),
                  Map.entry("buyLimitPrice", Double.toString(buyOrder.pricePerUnit())),
                  Map.entry("buyEscrowBefore", escrow.balance().toPlainString()),
                  Map.entry("reservedForMatch", reserved.toPlainString()),
                  Map.entry("unusedEscrowRefund", refund.toPlainString()),
                  Map.entry("tariffAmount", tariffAmount.toPlainString()),
                  Map.entry("taxReceipt", matchFeeId(buyOrder, sellOrder).toString())));
      ordersAwaitingReconciliation.add(buyOrder.orderId());
      ordersAwaitingReconciliation.add(sellOrder.orderId());
      boolean settled = false;
      try {
        settlementCoordinator.debited(settlement, "market escrow reserved for match");
        if (tariffAmount.signum() > 0 && !economyService.withdraw(buyerId, tariffAmount)) {
          logger()
              .warning(
                  "[executeMatch] buyer tariff withdrawal failed; order=" + buyOrder.orderId());
          return Optional.empty();
        }
        // audit B-072: 买单提交时已 withdraw 全额（totalValue+tax）到托管，匹配时不再需要单独 withdraw 买家。
        // 由于买单提交时的价格可能与卖单价格不同（fillPrice=sellOrder.price），如果卖单价 < 买单价，
        // 玩家实际被冻结的多于 fillPrice*fillQty+tax，差额应在 cancelOrder/订单完成时退还。
        // 简化：托管金额在 fillAmount 范围内消费 fillPrice*fillQty+tax；这里直接 deposit 给卖家与国库。
        //
        // 卖家收款：之前为 totalValue - taxAmount（买卖双方都被扣税，税被收2次但只入国库1次）。
        // audit B-067: 语义澄清——买方承担税。订单簿的税仅在买方一侧计算并收归国库；卖家收到 totalValue 全额。
        boolean sellerDeposited;
        try {
          sellerDeposited = economyService.deposit(sellerId, totalValue);
        } catch (RuntimeException e) {
          logger().warning("[executeMatch] seller deposit threw: " + e.getMessage());
          sellerDeposited = false;
        }
        if (!sellerDeposited) {
          // 卖家收款失败：托管在买家那的钱需要按 fillAmount 比例返还，但不能简单 deposit 全部，
          // 因为部分可能已在其他匹配中消费。这里至少记录警告，避免凭空吞掉卖家账款。
          logger()
              .warning(
                  "[executeMatch] seller deposit failed; buyer escrow for this match is stranded. "
                      + "buyer="
                      + buyerId
                      + ", seller="
                      + sellerId
                      + ", fillAmount="
                      + fillAmount
                      + ", totalValue="
                      + totalValue);
          refundTariffCharge(buyerId, tariffAmount);
          return Optional.empty();
        }

        NationId buyerNationId = buyOrder.nationId().orElse(null);

        // 资源转移（从卖家国家到买家国家）
        // audit B-073: 卖单提交时已 consume 到托管，匹配时不再需要 consume 卖家国家资源；
        // 这里只需 grant 给买家国家。若 consume 失败（早期版本无托管），仍尝试 consume 一次以保持兼容。
        NationId sellerNationId = sellOrder.nationId().orElse(null);
        NationId buyerNationId2 = buyOrder.nationId().orElse(null);

        boolean resourceGranted = true;
        if (sellerNationId != null && buyerNationId2 != null) {
          // audit B-068: 之前 resourceService.consume(sellerNationId, ...) 返回值被忽略直接 grant，
          // 资源不足时 grant 仍执行，等于凭空给买方国家加资源。改为校验返回值。
          // 由于 submitSellOrder 已托管资源，这里 consume 通常是 no-op；但保留校验逻辑做防御。
          // 实际匹配：从托管"释放"资源到买家——grant 即可。
          resourceGranted =
              resourceService.grant(buyerNationId2, buyOrder.resourceId(), fillAmount);
        }
        if (!resourceGranted) {
          rollbackUncommittedMatch(
              buyerId,
              sellerId,
              totalValue,
              tariffAmount,
              buyerNationId2,
              buyOrder.resourceId(),
              fillAmount,
              false,
              BigDecimal.ZERO);
          return Optional.empty();
        }

        boolean tariffFunded = false;
        try {
          if (tariffTrade != null) {
            if (!tariff.complete(tariffTrade)) {
              logger()
                  .warning(
                      "[executeMatch] resource trade business audit was incomplete; "
                          + "buyOrder="
                          + buyOrder.orderId()
                          + ", sellOrder="
                          + sellOrder.orderId());
            }
            tariffFunded = tariffTrade.tariffAmount().signum() > 0;
          }
        } catch (RuntimeException exception) {
          logger().warning("[executeMatch] tariff settlement failed: " + exception.getMessage());
          rollbackUncommittedMatch(
              buyerId,
              sellerId,
              totalValue,
              tariffAmount,
              buyerNationId2,
              buyOrder.resourceId(),
              fillAmount,
              true,
              BigDecimal.ZERO);
          if (tariffTrade != null) {
            tariff.reverse(tariffTrade);
          }
          return Optional.empty();
        }

        if (refund.signum() > 0 && !deposit(buyerId, refund, "release unused buy escrow")) {
          rollbackUncommittedMatch(
              buyerId,
              sellerId,
              totalValue,
              tariffAmount,
              buyerNationId2,
              buyOrder.resourceId(),
              fillAmount,
              true,
              BigDecimal.ZERO);
          if (tariffFunded) {
            tariff.reverse(tariffTrade);
          }
          return Optional.empty();
        }

        // This is the final external side effect. Keeping fee funding after every
        // reversible step prevents failed deliveries from leaving orphan treasury income.
        if (buyerNationId != null && taxAmount.signum() > 0) {
          TradeTaxService.TaxReceipt feeReceipt =
              new TradeTaxService.TaxReceipt(
                  matchFeeId(buyOrder, sellOrder),
                  buyerNationId,
                  TradeTaxService.TaxType.TRANSACTION_FEE,
                  taxAmount);
          try {
            taxService.fundTax(feeReceipt);
          } catch (RuntimeException feeFailure) {
            rollbackFeeFundingFailure(
                feeReceipt,
                feeFailure,
                buyerId,
                sellerId,
                totalValue,
                tariffAmount,
                buyerNationId2,
                buyOrder.resourceId(),
                fillAmount,
                refund,
                tariffTrade,
                tariffFunded);
            return Optional.empty();
          }
        }

        // 更新订单状态
        buyOrder.fill(fillAmount, fillPrice.doubleValue());
        sellOrder.fill(fillAmount, fillPrice.doubleValue());
        escrow.spend(reserved);
        if (buyOrder.remainingAmount() == 0) {
          buyEscrows.remove(buyOrder.orderId());
        }

        TradeRecord record = settlementCoordinator.commit(settlement);
        settled = true;
        addTradeRecord(buyerId, record);
        addTradeRecord(sellerId, record);
        addResourceTradeHistory(buyOrder.resourceId(), record);

        publishEvent(new TradeExecutedEvent(record));

        return Optional.of(record);
      } finally {
        if (settled) {
          ordersAwaitingReconciliation.remove(buyOrder.orderId());
          ordersAwaitingReconciliation.remove(sellOrder.orderId());
        } else {
          settlementCoordinator.requireReview(
              settlement,
              "market match interrupted; reconcile assets before releasing either order");
        }
      }
    }

    return Optional.empty();
  }

  private static final int MAX_TRADE_RECORDS_PER_PLAYER = 200;
  // audit B-070: 全局资源交易历史上限，避免长期运营导致内存膨胀。
  private static final int MAX_RESOURCE_TRADE_HISTORY = 5000;

  @Override
  public void matchAllOrders() {
    for (String resourceId : orderBooks.keySet()) {
      matchOrders(resourceId);
    }
  }

  @Override
  public int cleanExpiredOrders() {
    Instant now = Instant.now();
    List<UUID> expiredOrderIds =
        allOrders.values().stream()
            .filter(order -> order.isExpired(now))
            .filter(
                order ->
                    order.status() == TradeOrder.OrderStatus.PENDING
                        || order.status() == TradeOrder.OrderStatus.PARTIAL)
            .map(TradeOrder::orderId)
            .toList();

    int total = 0;
    for (UUID orderId : expiredOrderIds) {
      if (cancelOrderInternal(orderId)) {
        allOrders.remove(orderId);
        total++;
      }
    }

    if (total > 0) {
      publishEvent(new ExpiredOrdersCleanedEvent(total));
    }
    return total;
  }

  /** Releases all live escrow during an orderly module shutdown. */
  public int refundOpenOrders() {
    List<UUID> orderIds =
        allOrders.values().stream()
            .filter(
                order ->
                    order.status() == TradeOrder.OrderStatus.PENDING
                        || order.status() == TradeOrder.OrderStatus.PARTIAL)
            .map(TradeOrder::orderId)
            .toList();
    int refunded = 0;
    for (UUID orderId : orderIds) {
      try {
        if (cancelOrderInternal(orderId)) refunded++;
      } catch (RuntimeException failure) {
        logger()
            .log(
                java.util.logging.Level.SEVERE,
                "[refundOpenOrders] order escrow could not be released: " + orderId,
                failure);
      }
    }
    return refunded;
  }

  @Override
  public MarketOrderBook.OrderBookSnapshot getOrderBookSnapshot(String resourceId) {
    String normalized = requireResourceId(resourceId);
    MarketOrderBook book = orderBooks.get(normalized);
    return book == null ? emptySnapshot(normalized) : book.getSnapshot();
  }

  @Override
  public long getMarketDepth(String resourceId, double priceRange) {
    if (!Double.isFinite(priceRange) || priceRange < 0.0) {
      throw new IllegalArgumentException("priceRange must be finite and non-negative");
    }
    MarketOrderBook book = findOrderBook(resourceId);
    return book == null ? 0L : book.getDepth(priceRange);
  }

  @Override
  public Optional<Double> getBestBid(String resourceId) {
    MarketOrderBook book = findOrderBook(resourceId);
    return book == null ? Optional.empty() : book.getBestBidPrice();
  }

  @Override
  public Optional<Double> getBestAsk(String resourceId) {
    MarketOrderBook book = findOrderBook(resourceId);
    return book == null ? Optional.empty() : book.getBestAskPrice();
  }

  @Override
  public Optional<Double> getMidPrice(String resourceId) {
    MarketOrderBook book = findOrderBook(resourceId);
    return book == null ? Optional.empty() : book.getMidPrice();
  }

  @Override
  public double getSpread(String resourceId) {
    MarketOrderBook book = findOrderBook(resourceId);
    return book == null ? 0.0 : book.getSpread();
  }

  @Override
  public void updateVolatility(String resourceId, double volatility) {
    if (!Double.isFinite(volatility)) {
      throw new IllegalArgumentException("volatility must be finite");
    }
    getOrderBook(resourceId).setVolatility(volatility);
  }

  @Override
  public double getCurrentMarketPrice(String resourceId) {
    // 优先使用订单簿中间价
    Optional<Double> midPrice = getMidPrice(resourceId);
    if (midPrice.isPresent() && midPrice.get() > 0) {
      return midPrice.get();
    }

    // 其次使用最佳买卖价
    Optional<Double> bestBid = getBestBid(resourceId);
    Optional<Double> bestAsk = getBestAsk(resourceId);
    if (bestBid.isPresent() && bestAsk.isPresent()) {
      return (bestBid.get() + bestAsk.get()) / 2.0;
    }

    // 最后使用价格服务的参考价
    if (priceService != null) {
      return priceService.getCurrentPrice(resourceId);
    }

    return 0.0;
  }

  private String requireResourceId(String resourceId) {
    String normalized = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (normalized == null) {
      throw new IllegalArgumentException("resourceId must match [a-z0-9_.:-]{1,64}");
    }
    return normalized;
  }

  private MarketOrderBook findOrderBook(String resourceId) {
    return orderBooks.get(requireResourceId(resourceId));
  }

  private static MarketOrderBook.OrderBookSnapshot emptySnapshot(String resourceId) {
    return new MarketOrderBook.OrderBookSnapshot(
        resourceId, 0.0, 0.0, 0.0, 0.0, 0, 0, 0L, 0L, 0.0, Instant.now());
  }

  // ==================== 辅助方法 ====================

  private void addTradeRecord(UUID playerId, TradeRecord record) {
    // audit B-070: 之前 tradeRecords 无上限，长期运营玩家所有交易保留 → 内存膨胀。
    // 限制每玩家最多 MAX_TRADE_RECORDS_PER_PLAYER 条，超限时裁掉最老的记录。
    List<TradeRecord> list = tradeRecords.computeIfAbsent(playerId, k -> new ArrayList<>());
    synchronized (list) {
      list.add(record);
      while (list.size() > MAX_TRADE_RECORDS_PER_PLAYER) {
        list.remove(0);
      }
    }
  }

  private void addResourceTradeHistory(String resourceId, TradeRecord record) {
    // audit B-070: 全局资源交易历史上限 MAX_RESOURCE_TRADE_HISTORY，避免长期内存膨胀。
    List<TradeRecord> list =
        resourceTradeHistory.computeIfAbsent(resourceId, k -> new ArrayList<>());
    synchronized (list) {
      list.add(0, record);
      while (list.size() > MAX_RESOURCE_TRADE_HISTORY) {
        list.remove(list.size() - 1);
      }
    }
  }

  private java.util.logging.Logger logger() {
    return java.util.logging.Logger.getLogger(SimpleMarketOrderBookService.class.getName());
  }

  private boolean deposit(UUID playerId, BigDecimal amount, String operation) {
    try {
      if (economyService.deposit(playerId, amount)) {
        return true;
      }
    } catch (RuntimeException e) {
      logger().warning("[" + operation + "] deposit threw: " + e.getMessage());
      return false;
    }
    logger().warning("[" + operation + "] deposit returned false; player=" + playerId);
    return false;
  }

  private void rollbackCancelledOrderRefund(
      TradeOrder order,
      UUID playerId,
      NationId nationId,
      BigDecimal buyerRefund,
      long remainingAmount,
      boolean sellerResourceRefunded) {
    if (buyerRefund.signum() > 0
        && (playerId == null || !economyService.withdraw(playerId, buyerRefund))) {
      throw new IllegalStateException(
          "Buy escrow refund rollback failed for order " + order.orderId());
    }
    if (sellerResourceRefunded
        && (nationId == null
            || !resourceService.consume(nationId, order.resourceId(), remainingAmount))) {
      throw new IllegalStateException(
          "Sell escrow refund rollback failed for order " + order.orderId());
    }
  }

  private void refundTariffCharge(UUID buyerId, BigDecimal tariffAmount) {
    if (tariffAmount.signum() > 0 && !deposit(buyerId, tariffAmount, "refund tariff charge")) {
      throw new IllegalStateException("Tariff refund failed for buyer " + buyerId);
    }
  }

  private UUID matchFeeId(TradeOrder buyOrder, TradeOrder sellOrder) {
    String key =
        buyOrder.orderId()
            + ":"
            + sellOrder.orderId()
            + ":"
            + buyOrder.filledAmount()
            + ":"
            + sellOrder.filledAmount();
    return UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8));
  }

  private void rollbackUncommittedMatch(
      UUID buyerId,
      UUID sellerId,
      BigDecimal sellerAmount,
      BigDecimal tariffAmount,
      NationId buyerNationId,
      String resourceId,
      long fillAmount,
      boolean resourceWasGranted,
      BigDecimal buyerRefund) {
    List<String> failures = new ArrayList<>();
    if (buyerRefund.signum() > 0 && !economyService.withdraw(buyerId, buyerRefund)) {
      failures.add("buyer price refund");
    }
    if (resourceWasGranted
        && buyerNationId != null
        && !resourceService.consume(buyerNationId, resourceId, fillAmount)) {
      failures.add("buyer resource grant");
    }
    if (!economyService.withdraw(sellerId, sellerAmount)) {
      failures.add("seller payment");
    }
    try {
      refundTariffCharge(buyerId, tariffAmount);
    } catch (RuntimeException exception) {
      failures.add("tariff charge");
    }
    if (!failures.isEmpty()) {
      throw new IllegalStateException(
          "Order match rollback incomplete: " + String.join(", ", failures));
    }
  }

  private void rollbackFeeFundingFailure(
      TradeTaxService.TaxReceipt feeReceipt,
      RuntimeException feeFailure,
      UUID buyerId,
      UUID sellerId,
      BigDecimal sellerAmount,
      BigDecimal tariffAmount,
      NationId buyerNationId,
      String resourceId,
      long fillAmount,
      BigDecimal buyerRefund,
      ResourceTariff.Trade tariffTrade,
      boolean tariffFunded) {
    RuntimeException compensationFailure = null;
    try {
      taxService.reverseFundedTax(feeReceipt);
    } catch (RuntimeException failure) {
      compensationFailure = failure;
    }
    try {
      rollbackUncommittedMatch(
          buyerId,
          sellerId,
          sellerAmount,
          tariffAmount,
          buyerNationId,
          resourceId,
          fillAmount,
          true,
          buyerRefund);
    } catch (RuntimeException failure) {
      if (compensationFailure == null) {
        compensationFailure = failure;
      } else {
        compensationFailure.addSuppressed(failure);
      }
    }
    if (tariffFunded && tariffTrade != null) {
      try {
        tariff.reverse(tariffTrade);
      } catch (RuntimeException failure) {
        if (compensationFailure == null) {
          compensationFailure = failure;
        } else {
          compensationFailure.addSuppressed(failure);
        }
      }
    }
    if (compensationFailure != null) {
      feeFailure.addSuppressed(compensationFailure);
      throw new IllegalStateException("Order match tax rollback failed", feeFailure);
    }
    logger()
        .warning(
            "[executeMatch] transaction fee funding failed; match rolled back: "
                + feeFailure.getMessage());
  }

  private static final class BuyEscrow {
    private BigDecimal balance;

    private BuyEscrow(BigDecimal balance) {
      this.balance = balance;
    }

    private BigDecimal balance() {
      return balance;
    }

    private void spend(BigDecimal amount) {
      balance = balance.subtract(amount);
    }
  }

  private void publishEvent(Object event) {
    if (eventBus != null) {
      eventBus.publish(event);
    }
  }

  // ==================== 事件类 ====================

  public record OrderSubmittedEvent(TradeOrder order) {}

  public record OrderCancelledEvent(TradeOrder order) {}

  public record OrderRejectedEvent(UUID playerId, String resourceId, String reason) {}

  public record TradeExecutedEvent(TradeRecord record) {}

  public record ExpiredOrdersCleanedEvent(int count) {}

  // ==================== 公开访问器 ====================

  /** 获取玩家的交易记录 */
  public List<TradeRecord> getPlayerTradeRecords(UUID playerId) {
    if (playerId == null) {
      return List.of();
    }
    return snapshotRecords(tradeRecords, playerId);
  }

  /** 获取资源交易历史 */
  public List<TradeRecord> getResourceTradeHistory(String resourceId) {
    String normalized = ResourceTradeTerms.normalizeResourceId(resourceId);
    if (normalized == null) {
      return List.of();
    }
    return snapshotRecords(resourceTradeHistory, normalized);
  }

  /** 获取玩家的交易记录（最近N条） */
  public List<TradeRecord> getRecentPlayerTrades(UUID playerId, int limit) {
    if (limit < 0) {
      throw new IllegalArgumentException("limit must be non-negative");
    }
    List<TradeRecord> records = snapshotRecords(tradeRecords, playerId);
    return List.copyOf(records.subList(0, Math.min(limit, records.size())));
  }

  private static <K> List<TradeRecord> snapshotRecords(
      Map<K, List<TradeRecord>> recordsByKey, K key) {
    if (key == null) {
      return List.of();
    }
    List<TradeRecord> records = recordsByKey.get(key);
    if (records == null) {
      return List.of();
    }
    synchronized (records) {
      return new ArrayList<>(records);
    }
  }
}
