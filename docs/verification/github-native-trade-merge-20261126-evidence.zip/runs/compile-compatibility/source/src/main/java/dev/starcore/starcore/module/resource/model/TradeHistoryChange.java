package dev.starcore.starcore.module.resource.model;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Immutable SQL commit receipt; sequence is unrelated to the trade's execution time. */
public record TradeHistoryChange(
    UUID authorityDomainId,
    long sequence,
    Instant committedAt,
    Instant occurredAt,
    TradeRecord.TradeRecordStatus previousStatus,
    TradeRecord record) {
  public TradeHistoryChange {
    Objects.requireNonNull(authorityDomainId, "authorityDomainId");
    Objects.requireNonNull(committedAt, "committedAt");
    Objects.requireNonNull(occurredAt, "occurredAt");
    Objects.requireNonNull(record, "record");
    if (sequence <= 0) throw new IllegalArgumentException("sequence must be positive");
  }
}
