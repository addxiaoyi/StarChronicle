package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.TransactionEvent;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.module.resource.model.TradeHistoryChange;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import dev.starcore.starcore.module.resource.model.TradeSettlementIntent;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Serializes SQL writers before reading the head; never allocates sequences outside a commit. */
final class SettlementTradeJournal {
  private final DatabaseService database;
  private final UUID domain;
  private final boolean legacy;

  SettlementTradeJournal(DatabaseService database, boolean legacy) {
    this.legacy = legacy;
    this.database = database;
    initializeTables();
    domain = initializeBaseline();
  }

  UUID domain() {
    try (Connection connection = database.getConnection()) {
      return head(connection).domain();
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot read trade history authority", failure);
    }
  }

  private void initializeTables() {
    try (Connection connection = database.getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS trade_history_authority (
            singleton INTEGER PRIMARY KEY,
            domain_id VARCHAR(36) NOT NULL,
            last_sequence BIGINT NOT NULL,
            initialized INTEGER NOT NULL
          )
          """);
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS trade_history_identity (
            record_id VARCHAR(36) PRIMARY KEY,
            payload TEXT NOT NULL
          )
          """);
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS trade_history_commits (
            sequence_id BIGINT PRIMARY KEY,
            committed_at VARCHAR(40) NOT NULL,
            occurred_at VARCHAR(40) NOT NULL,
            previous_status VARCHAR(20),
            payload TEXT NOT NULL
          )
          """);
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS trade_settlement_intents (
            operation_id VARCHAR(36) PRIMARY KEY,
            record_id VARCHAR(36) NOT NULL UNIQUE,
            account_id VARCHAR(36) NOT NULL,
            amount_text VARCHAR(128) NOT NULL,
            reason TEXT NOT NULL,
            planned_payload TEXT NOT NULL,
            settlement_context TEXT NOT NULL,
            applied_events INTEGER NOT NULL,
            transaction_id VARCHAR(36),
            applied_fingerprint VARCHAR(64)
          )
          """);
      // Startup races must choose one domain. A uniqueness conflict is the only ignored failure.
      try (PreparedStatement insert =
          connection.prepareStatement("INSERT INTO trade_history_authority VALUES (1, ?, 0, 0)")) {
        insert.setString(
            1, (legacy ? TradeCommitJournal.domain(connection) : UUID.randomUUID()).toString());
        try {
          insert.executeUpdate();
        } catch (SQLException conflict) {
          try (ResultSet row =
              statement.executeQuery(
                  "SELECT domain_id FROM trade_history_authority WHERE singleton = 1")) {
            if (!row.next()) throw conflict;
          }
        }
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot initialize trade commit tables", failure);
    }
  }

  void prepare(TradeSettlementIntent intent) {
    if (intent.appliedEvents() != 0)
      throw new IllegalArgumentException("New intent cannot have applied events");
    write(
        connection -> {
          head(connection);
          if (latest(connection, intent.plannedRecord().recordId()).isPresent()) {
            throw new IllegalArgumentException("Trade record already exists");
          }
          try (PreparedStatement insert =
              connection.prepareStatement(
                  """
INSERT INTO trade_settlement_intents
  (operation_id, record_id, account_id, amount_text, reason, planned_payload, settlement_context, applied_events)
VALUES (?, ?, ?, ?, ?, ?, ?, 0)
""")) {
            insert.setString(1, intent.operationId().toString());
            insert.setString(2, intent.plannedRecord().recordId().toString());
            insert.setString(3, intent.accountId().toString());
            insert.setString(4, intent.amount().toPlainString());
            insert.setString(5, intent.reason());
            insert.setString(6, TradeRecordCodec.encode(intent.plannedRecord()));
            insert.setString(7, TradeRecordCodec.context(intent.context()));
            insert.executeUpdate();
          }
          return null;
        });
  }

  List<TradeSettlementIntent> intentsAfter(UUID after, int limit) {
    if (limit < 1 || limit > 128) throw new IllegalArgumentException("limit must be 1..128");
    try (Connection connection = database.getConnection();
        PreparedStatement query =
            connection.prepareStatement(
                """
SELECT * FROM trade_settlement_intents WHERE operation_id > ? ORDER BY operation_id LIMIT ?
""")) {
      head(connection);
      query.setString(1, after == null ? "" : after.toString());
      query.setInt(2, limit);
      List<TradeSettlementIntent> intents = new ArrayList<>();
      try (ResultSet rows = query.executeQuery()) {
        while (rows.next()) intents.add(intent(rows));
      }
      return List.copyOf(intents);
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot read trade settlement plans", failure);
    }
  }

  Optional<TradeRecord> reconcile(
      UUID operationId, TransactionRecord transaction, RecordWriter writer) {
    return write(
        connection -> {
          head(connection);
          TradeSettlementIntent intent;
          String boundTransaction;
          String appliedFingerprint;
          try (PreparedStatement query =
              connection.prepareStatement(
                  "SELECT * FROM trade_settlement_intents WHERE operation_id = ?")) {
            query.setString(1, operationId.toString());
            try (ResultSet row = query.executeQuery()) {
              if (!row.next()) throw new IllegalArgumentException("Missing trade settlement plan");
              intent = intent(row);
              boundTransaction = row.getString("transaction_id");
              appliedFingerprint = row.getString("applied_fingerprint");
            }
          }
          TradeSettlementCoordinator.requireMatchingTransaction(domain, intent, transaction);
          if (boundTransaction != null
              && !boundTransaction.equals(transaction.transactionId().toString())) {
            throw new IllegalStateException("Trade transaction identity changed");
          }
          if (transaction.events().size() < intent.appliedEvents()) {
            throw new IllegalStateException("Trade transaction timeline rolled back");
          }
          if (intent.appliedEvents() > 0
              && !Objects.equals(
                  appliedFingerprint,
                  TradeRecordCodec.timelineFingerprint(
                      transaction.events().subList(0, intent.appliedEvents())))) {
            throw new IllegalStateException("Previously applied trade timeline changed");
          }
          long commitCount =
              transaction.events().stream()
                  .filter(e -> e.state() == EconomyTransactionState.COMMITTED)
                  .count();
          if (commitCount > 1)
            throw new IllegalStateException("Trade transaction was reused after settlement");
          TradeRecord current = latest(connection, intent.plannedRecord().recordId()).orElse(null);
          if (current == null
              && transaction.events().subList(0, intent.appliedEvents()).stream()
                  .anyMatch(event -> event.state() == EconomyTransactionState.COMMITTED)) {
            throw new IllegalStateException("Previously applied trade identity is missing");
          }
          boolean committed = false;
          long sequence = head(connection).sequence();
          for (int i = 0; i < transaction.events().size(); i++) {
            TransactionEvent event = transaction.events().get(i);
            if (event.state() == EconomyTransactionState.COMMITTED) committed = true;
            if (i < intent.appliedEvents() || !committed) continue;
            TradeRecord next =
                switch (event.state()) {
                  case COMMITTED -> TradeRecordCodec.executedAt(intent.plannedRecord(), event.at());
                  case REFUND_PENDING, MANUAL_REVIEW ->
                      current.withStatus(TradeRecord.TradeRecordStatus.DISPUTED, event.message());
                  case REFUNDED ->
                      current.withStatus(TradeRecord.TradeRecordStatus.REFUNDED, event.message());
                  case CANCELLED ->
                      current.withStatus(TradeRecord.TradeRecordStatus.CANCELLED, event.message());
                  default -> current;
                };
            if (next != null
                && (current == null
                    || !TradeRecordCodec.encode(current).equals(TradeRecordCodec.encode(next)))) {
              sequence = append(connection, sequence, current, next, writer, event.at());
              current = next;
            }
          }
          try (PreparedStatement update =
              connection.prepareStatement(
                  """
UPDATE trade_settlement_intents SET applied_events = ?, transaction_id = ?, applied_fingerprint = ? WHERE operation_id = ?
""")) {
            update.setInt(1, transaction.events().size());
            update.setString(2, transaction.transactionId().toString());
            update.setString(3, TradeRecordCodec.timelineFingerprint(transaction.events()));
            update.setString(4, operationId.toString());
            if (update.executeUpdate() != 1)
              throw new SQLException("Trade reconciliation acknowledgement failed");
          }
          return Optional.ofNullable(current);
        });
  }

  private TradeSettlementIntent intent(ResultSet row) throws SQLException {
    TradeRecord planned = TradeRecordCodec.decode(row.getString("planned_payload"));
    if (!planned.recordId().toString().equals(row.getString("record_id"))) {
      throw new IllegalStateException("Trade preparation identity mismatch");
    }
    return new TradeSettlementIntent(
        UUID.fromString(row.getString("operation_id")),
        UUID.fromString(row.getString("account_id")),
        new BigDecimal(row.getString("amount_text")),
        row.getString("reason"),
        planned,
        TradeRecordCodec.context(row.getString("settlement_context")),
        row.getInt("applied_events"));
  }

  private UUID initializeBaseline() {
    return write(
        connection -> {
          Head current = head(connection);
          if (legacy && !current.domain().equals(TradeCommitJournal.domain(connection)))
            throw new IllegalStateException(
                "Trade journal domains disagree; restore matching backups");
          if (!current.initialized()) {
            try (Statement query = connection.createStatement();
                ResultSet rows =
                    query.executeQuery(
                        "SELECT (SELECT COUNT(*) FROM trade_history_identity) + (SELECT COUNT(*)"
                            + " FROM trade_history_commits) + (SELECT COUNT(*) FROM"
                            + " trade_settlement_intents)")) {
              if (!rows.next() || rows.getLong(1) != 0 || current.sequence() != 0) {
                throw new IllegalStateException(
                    "Trade journal exists without initialized authority");
              }
            }
            // Preserve the original legacy nanoseconds and pruned identities; do not manufacture
            // events.
            if (legacy) {
              String cursor = "";
              while (true) {
                List<UUID> ids = new ArrayList<>();
                try (PreparedStatement query =
                    connection.prepareStatement(
                        "SELECT DISTINCT record_id FROM trade_commit_log WHERE record_id>? ORDER BY"
                            + " record_id LIMIT 100")) {
                  query.setString(1, cursor);
                  try (ResultSet rows = query.executeQuery()) {
                    while (rows.next()) ids.add(UUID.fromString(rows.getString(1)));
                  }
                }
                if (ids.isEmpty()) break;
                for (UUID id : ids)
                  seedIdentity(connection, TradeCommitJournal.latest(connection, id).orElseThrow());
                cursor = ids.getLast().toString();
              }
            } else {
              try (Statement query = connection.createStatement();
                  ResultSet rows =
                      query.executeQuery("SELECT * FROM trade_history ORDER BY record_id")) {
                while (rows.next())
                  seedIdentity(
                      connection, SimpleTradeHistoryService.extractRecordFromResultSet(rows));
              }
            }
            try (Statement update = connection.createStatement()) {
              update.executeUpdate(
                  "UPDATE trade_history_authority SET initialized = 1 WHERE singleton = 1");
            }
          }
          try (Statement query = connection.createStatement();
              ResultSet rows =
                  query.executeQuery(
                      "SELECT COALESCE(MAX(sequence_id), 0) FROM trade_history_commits")) {
            if (!rows.next() || rows.getLong(1) != current.sequence()) {
              throw new IllegalStateException("Trade journal head does not match committed tail");
            }
          }
          if (legacy) validateLegacy(connection);
          return current.domain();
        });
  }

  void save(Collection<TradeRecord> records, RecordWriter writer) {
    write(
        connection -> {
          long sequence = head(connection).sequence();
          for (TradeRecord record : records) {
            TradeRecord previous = latest(connection, record.recordId()).orElse(null);
            if (previous != null) {
              if (legacy) {
                requireUnprepared(connection, record.recordId());
                if (!TradeRecordCodec.identity(previous).equals(TradeRecordCodec.identity(record)))
                  throw new IllegalArgumentException(
                      "Trade record identity is already bound to different terms");
                if (!TradeRecordCodec.encode(previous).equals(TradeRecordCodec.encode(record)))
                  sequence = append(connection, sequence, previous, record, writer, Instant.now());
                else writer.write(connection, record);
                continue;
              }
              if (!TradeRecordCodec.encode(previous).equals(TradeRecordCodec.encode(record))) {
                throw new IllegalArgumentException(
                    "Trade identity already exists; use updateStatus for an explicit amendment: "
                        + record.recordId());
              }
              // Includes records removed from the query view: saving an old copy cannot resurrect
              // it.
              continue;
            }
            try (PreparedStatement reserved =
                connection.prepareStatement(
                    "SELECT operation_id FROM trade_settlement_intents WHERE record_id = ?")) {
              reserved.setString(1, record.recordId().toString());
              try (ResultSet row = reserved.executeQuery()) {
                if (row.next())
                  throw new IllegalStateException(
                      "Prepared trade requires its durable transaction receipt");
              }
            }
            sequence = append(connection, sequence, null, record, writer, record.executedAt());
          }
          return null;
        });
  }

  TradeRecord updateStatus(
      UUID recordId, TradeRecord.TradeRecordStatus status, String notes, RecordWriter writer) {
    return write(
        connection -> {
          TradeRecord current =
              latest(connection, recordId)
                  .orElseThrow(
                      () -> new IllegalArgumentException("Trade record not found: " + recordId));
          TradeRecord next = current.withStatus(status, notes);
          if (!TradeRecordCodec.encode(current).equals(TradeRecordCodec.encode(next))) {
            append(connection, head(connection).sequence(), current, next, writer, Instant.now());
          }
          return next;
        });
  }

  Optional<TradeRecord> get(UUID recordId) {
    try (Connection connection = database.getConnection();
        PreparedStatement query =
            connection.prepareStatement(
                """
                SELECT i.payload FROM trade_history_identity i
                JOIN trade_history h ON h.record_id = i.record_id WHERE i.record_id = ?
                """)) {
      head(connection);
      query.setString(1, recordId.toString());
      try (ResultSet row = query.executeQuery()) {
        return row.next()
            ? Optional.of(TradeRecordCodec.decode(row.getString(1)))
            : Optional.empty();
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot read trade history record", failure);
    }
  }

  List<TradeHistoryChange> changesAfter(long after, int limit) {
    if (after < 0 || limit < 1 || limit > 128) {
      throw new IllegalArgumentException("sequence must be nonnegative and limit must be 1..128");
    }
    try (Connection connection = database.getConnection()) {
      connection.setAutoCommit(false);
      try {
        Head current = head(connection);
        if (after > current.sequence())
          throw new IllegalArgumentException("Trade cursor is ahead of source");
        List<TradeHistoryChange> changes = new ArrayList<>();
        try (PreparedStatement query =
            connection.prepareStatement(
                """
                SELECT * FROM trade_history_commits
                WHERE sequence_id > ? AND sequence_id <= ? ORDER BY sequence_id LIMIT ?
                """)) {
          query.setLong(1, after);
          query.setLong(2, current.sequence());
          query.setInt(3, limit);
          try (ResultSet rows = query.executeQuery()) {
            long expected = after;
            while (rows.next()) {
              long sequence = rows.getLong("sequence_id");
              if (sequence != Math.addExact(expected, 1)) {
                throw new IllegalStateException("Gap in committed trade history after " + expected);
              }
              String previous = rows.getString("previous_status");
              changes.add(
                  new TradeHistoryChange(
                      current.domain(),
                      sequence,
                      Instant.parse(rows.getString("committed_at")),
                      Instant.parse(rows.getString("occurred_at")),
                      previous == null ? null : TradeRecord.TradeRecordStatus.valueOf(previous),
                      TradeRecordCodec.decode(rows.getString("payload"))));
              expected = sequence;
            }
            if (changes.size() < limit && expected != current.sequence()) {
              throw new IllegalStateException("Missing committed trade history tail");
            }
          }
        }
        connection.commit();
        return List.copyOf(changes);
      } catch (Exception failure) {
        connection.rollback();
        throw failure;
      } finally {
        connection.setAutoCommit(true);
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot read committed trade history", failure);
    }
  }

  private long append(
      Connection connection,
      long sequence,
      TradeRecord previous,
      TradeRecord next,
      RecordWriter writer,
      Instant occurredAt)
      throws SQLException {
    if (previous != null
        && !TradeRecordCodec.identity(previous).equals(TradeRecordCodec.identity(next))) {
      throw new IllegalArgumentException("Immutable trade identity changed");
    }
    long nextSequence = Math.addExact(sequence, 1);
    String payload = TradeRecordCodec.encode(next);
    writer.write(connection, next);
    try (PreparedStatement insert =
        connection.prepareStatement("INSERT INTO trade_history_commits VALUES (?, ?, ?, ?, ?)")) {
      insert.setLong(1, nextSequence);
      insert.setString(2, Instant.now().toString());
      insert.setString(3, occurredAt.toString());
      insert.setString(4, previous == null ? null : previous.status().name());
      insert.setString(5, payload);
      insert.executeUpdate();
    }
    String sql =
        previous == null
            ? "INSERT INTO trade_history_identity (payload, record_id) VALUES (?, ?)"
            : "UPDATE trade_history_identity SET payload = ? WHERE record_id = ?";
    try (PreparedStatement update = connection.prepareStatement(sql)) {
      update.setString(1, payload);
      update.setString(2, next.recordId().toString());
      if (update.executeUpdate() != 1) throw new SQLException("Trade identity update failed");
    }
    try (PreparedStatement update =
        connection.prepareStatement(
            "UPDATE trade_history_authority SET last_sequence = ? WHERE singleton = 1")) {
      update.setLong(1, nextSequence);
      if (update.executeUpdate() != 1) throw new SQLException("Trade head update failed");
    }
    return nextSequence;
  }

  Optional<TradeRecord> latest(Connection connection, UUID id) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement(
            "SELECT payload FROM trade_history_identity WHERE record_id = ?")) {
      query.setString(1, id.toString());
      try (ResultSet row = query.executeQuery()) {
        return row.next()
            ? Optional.of(TradeRecordCodec.decode(row.getString(1)))
            : Optional.empty();
      }
    }
  }

  private Head head(Connection connection) throws SQLException {
    try (Statement query = connection.createStatement();
        ResultSet row =
            query.executeQuery("SELECT * FROM trade_history_authority WHERE singleton = 1")) {
      if (!row.next()) throw new IllegalStateException("Missing trade history authority");
      UUID currentDomain = UUID.fromString(row.getString("domain_id"));
      if (legacy && !currentDomain.equals(TradeCommitJournal.domain(connection)))
        throw new IllegalStateException("Trade journal domains disagree; restore matching backups");
      long sequence = row.getLong("last_sequence");
      if (sequence < 0
          || (domain != null
              && (!domain.equals(currentDomain) || row.getInt("initialized") != 1))) {
        throw new IllegalStateException("Trade history authority changed or is invalid");
      }
      return new Head(currentDomain, sequence, row.getInt("initialized") == 1);
    }
  }

  private void seedIdentity(Connection connection, TradeRecord record) throws SQLException {
    try (PreparedStatement insert =
        connection.prepareStatement(
            "INSERT INTO trade_history_identity (record_id,payload) VALUES (?,?)")) {
      insert.setString(1, record.recordId().toString());
      insert.setString(2, TradeRecordCodec.encode(record));
      insert.executeUpdate();
    }
  }

  private void validateLegacy(Connection connection) throws SQLException {
    try (Statement query = connection.createStatement();
        ResultSet rows =
            query.executeQuery("SELECT record_id,payload FROM trade_history_identity")) {
      while (rows.next()) {
        UUID id = UUID.fromString(rows.getString(1));
        TradeRecord old =
            TradeCommitJournal.latest(connection, id)
                .orElseThrow(() -> new IllegalStateException("Legacy trade snapshot is missing"));
        if (!TradeRecordCodec.encode(old).equals(rows.getString(2)))
          throw new IllegalStateException("Trade journals disagree; restore matching backups");
      }
    }
    try (Statement query = connection.createStatement();
        ResultSet rows =
            query.executeQuery("SELECT COUNT(DISTINCT record_id) FROM trade_commit_log")) {
      rows.next();
      long expected = rows.getLong(1);
      try (Statement count = connection.createStatement();
          ResultSet identities =
              count.executeQuery("SELECT COUNT(*) FROM trade_history_identity")) {
        identities.next();
        if (expected != identities.getLong(1))
          throw new IllegalStateException("Trade identity inventory disagrees with legacy journal");
      }
    }
  }

  private void requireUnprepared(Connection connection, UUID id) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement(
            "SELECT operation_id FROM trade_settlement_intents WHERE record_id=?")) {
      query.setString(1, id.toString());
      try (ResultSet row = query.executeQuery()) {
        if (row.next())
          throw new IllegalStateException(
              "Prepared trade requires its durable transaction receipt");
      }
    }
  }

  private <T> T write(SqlWork<T> work) {
    try (Connection connection = database.getConnection()) {
      boolean autoCommit = connection.getAutoCommit();
      connection.setAutoCommit(false);
      try {
        // The first statement reserves the SQLite writer (or locks the MySQL singleton row).
        // No deferred read-to-write upgrade, stale cached head, or MAX(sequence)+1 race.
        try (Statement reserve = connection.createStatement()) {
          reserve.executeUpdate(
              "UPDATE trade_history_authority SET last_sequence = last_sequence WHERE singleton ="
                  + " 1");
        }
        T result = work.run(connection);
        connection.commit();
        return result;
      } catch (Exception failure) {
        try {
          connection.rollback();
        } catch (SQLException rollback) {
          failure.addSuppressed(rollback);
        }
        throw failure;
      } finally {
        connection.setAutoCommit(autoCommit);
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Trade history transaction failed", failure);
    }
  }

  private record Head(UUID domain, long sequence, boolean initialized) {}

  @FunctionalInterface
  interface RecordWriter {
    void write(Connection connection, TradeRecord record) throws SQLException;
  }

  @FunctionalInterface
  private interface SqlWork<T> {
    T run(Connection connection) throws SQLException;
  }
}
