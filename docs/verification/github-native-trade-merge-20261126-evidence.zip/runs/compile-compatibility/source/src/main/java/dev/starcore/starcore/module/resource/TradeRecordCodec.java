package dev.starcore.starcore.module.resource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.starcore.starcore.foundation.economy.transaction.TransactionEvent;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/** Versioned, lossless trade payload shared by the SQL journal and transaction preparation. */
final class TradeRecordCodec {
  private TradeRecordCodec() {}

  static String encode(TradeRecord record) {
    JsonObject json = new JsonObject();
    json.addProperty("version", 1);
    json.addProperty("id", record.recordId().toString());
    json.addProperty("type", record.orderType().name());
    json.addProperty("source", record.orderSource().name());
    json.addProperty("seller", record.sellerPlayerId().map(Object::toString).orElse(null));
    json.addProperty("buyer", record.buyerPlayerId().map(Object::toString).orElse(null));
    json.addProperty("sellerNation", record.sellerNationId().map(Object::toString).orElse(null));
    json.addProperty("buyerNation", record.buyerNationId().map(Object::toString).orElse(null));
    json.addProperty("resource", record.resourceId());
    json.addProperty("amount", record.amount());
    json.addProperty("price", Double.toString(record.pricePerUnit()));
    json.addProperty("tax", Double.toString(record.taxAmount()));
    json.addProperty("executedAt", record.executedAt().toString());
    json.addProperty("buyOrder", record.buyOrderId().map(Object::toString).orElse(null));
    json.addProperty("sellOrder", record.sellOrderId().map(Object::toString).orElse(null));
    json.addProperty("status", record.status().name());
    json.addProperty("notes", record.notes().orElse(null));
    return json.toString();
  }

  static TradeRecord decode(String payload) {
    JsonObject json = JsonParser.parseString(payload).getAsJsonObject();
    if (json.get("version").getAsInt() != 1) {
      throw new IllegalStateException("Unsupported trade payload version");
    }
    return new TradeRecord(
        UUID.fromString(json.get("id").getAsString()),
        TradeOrder.OrderType.valueOf(json.get("type").getAsString()),
        TradeOrder.OrderSource.valueOf(json.get("source").getAsString()),
        uuid(json, "seller"),
        uuid(json, "buyer"),
        nation(json, "sellerNation"),
        nation(json, "buyerNation"),
        json.get("resource").getAsString(),
        json.get("amount").getAsLong(),
        Double.parseDouble(json.get("price").getAsString()),
        Double.parseDouble(json.get("tax").getAsString()),
        Instant.parse(json.get("executedAt").getAsString()),
        uuid(json, "buyOrder"),
        uuid(json, "sellOrder"),
        TradeRecord.TradeRecordStatus.valueOf(json.get("status").getAsString()),
        text(json, "notes"));
  }

  static String identity(TradeRecord record) {
    return encode(record.withStatus(TradeRecord.TradeRecordStatus.COMPLETED, null));
  }

  static TradeRecord executedAt(TradeRecord planned, Instant executedAt) {
    JsonObject json = JsonParser.parseString(encode(planned)).getAsJsonObject();
    json.addProperty("executedAt", executedAt.toString());
    return decode(json.toString());
  }

  static String timelineFingerprint(List<TransactionEvent> events) {
    JsonArray timeline = new JsonArray();
    for (TransactionEvent event : events) {
      JsonArray entry = new JsonArray();
      entry.add(event.at().toString());
      entry.add(event.state().name());
      entry.add(event.message());
      timeline.add(entry);
    }
    try {
      return HexFormat.of()
          .formatHex(
              MessageDigest.getInstance("SHA-256")
                  .digest(timeline.toString().getBytes(StandardCharsets.UTF_8)));
    } catch (NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }

  static String context(Map<String, String> context) {
    JsonObject json = new JsonObject();
    new TreeMap<>(context).forEach(json::addProperty);
    return json.toString();
  }

  static Map<String, String> context(String encoded) {
    Map<String, String> context = new TreeMap<>();
    JsonParser.parseString(encoded)
        .getAsJsonObject()
        .entrySet()
        .forEach(entry -> context.put(entry.getKey(), entry.getValue().getAsString()));
    return Map.copyOf(context);
  }

  private static String text(JsonObject json, String key) {
    return json.get(key).isJsonNull() ? null : json.get(key).getAsString();
  }

  private static UUID uuid(JsonObject json, String key) {
    String value = text(json, key);
    return value == null ? null : UUID.fromString(value);
  }

  private static NationId nation(JsonObject json, String key) {
    UUID value = uuid(json, key);
    return value == null ? null : NationId.of(value);
  }
}
