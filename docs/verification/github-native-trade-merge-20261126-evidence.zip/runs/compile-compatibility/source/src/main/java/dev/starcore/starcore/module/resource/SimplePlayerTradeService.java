package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.event.StarCoreEventBus;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.PendingRefund;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import dev.starcore.starcore.module.business.BusinessService;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.NationalReserve;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import dev.starcore.starcore.module.treasury.TaxationService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Supplier;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.bukkit.plugin.Plugin;

/** 玩家交易服务实现 */
public class SimplePlayerTradeService implements PlayerTradeService {
  private static final Pattern RESOURCE_ID_PATTERN = Pattern.compile("[A-Za-z0-9_.:-]{1,64}");

  private final Map<UUID, PlayerTradeOffer> pendingOffers;
  private final Map<UUID, List<UUID>> sentOffers; // 发起者 -> 列表
  private final Map<UUID, List<UUID>> receivedOffers; // 接收者 -> 列表
  private final Map<UUID, TradeRecord> completedTrades;

  private final ResourceService resourceService;
  private final EconomyService economyService;
  private final TradeTaxService taxService;
  private final MarketOrderBookService orderBookService;
  private final NationalReserve marketReserve; // 市场储备（可选）
  private final ServiceRegistry services;
  private TradeSettlementCoordinator settlementCoordinator;
  private final Logger logger; // 日志记录器
  private final RefundLedger refundLedger;
  private final TransactionFabric transactionFabric;
  private NationService nationService;
  private final Map<UUID, ResourceTariff.Trade> tariffTrades;

  private StarCoreScheduler scheduler;
  private StarCoreEventBus eventBus;

  public SimplePlayerTradeService(
      ResourceService resourceService,
      EconomyService economyService,
      TradeTaxService taxService,
      MarketOrderBookService orderBookService,
      Plugin plugin) {
    this(resourceService, economyService, taxService, orderBookService, null, null, plugin);
  }

  public SimplePlayerTradeService(
      ResourceService resourceService,
      EconomyService economyService,
      TradeTaxService taxService,
      MarketOrderBookService orderBookService,
      NationalReserve marketReserve,
      Plugin plugin) {
    this(
        resourceService, economyService, taxService, orderBookService, marketReserve, null, plugin);
  }

  public SimplePlayerTradeService(
      ResourceService resourceService,
      EconomyService economyService,
      TradeTaxService taxService,
      MarketOrderBookService orderBookService,
      NationalReserve marketReserve,
      ServiceRegistry services,
      Plugin plugin) {
    this.resourceService = Objects.requireNonNull(resourceService, "resourceService");
    this.economyService = Objects.requireNonNull(economyService, "economyService");
    this.taxService = Objects.requireNonNull(taxService, "taxService");
    this.orderBookService = orderBookService; // 可选
    this.marketReserve = marketReserve; // 可选的市场储备
    this.services = services;
    this.logger =
        plugin != null
            ? plugin.getLogger()
            : Logger.getLogger(SimplePlayerTradeService.class.getName());
    RefundLedger sharedLedger =
        services == null
            ? null
            : services
                .find(RefundLedgerService.class)
                .map(RefundLedgerService::ledger)
                .orElse(null);
    this.refundLedger =
        sharedLedger != null
            ? sharedLedger
            : plugin == null
                ? null
                : new RefundLedger(
                    plugin.getDataFolder().toPath().resolve("economy/refund-ledger.properties"),
                    this.logger);
    this.transactionFabric =
        services == null ? null : services.find(TransactionFabric.class).orElse(null);
    this.pendingOffers = new ConcurrentHashMap<>();
    this.sentOffers = new ConcurrentHashMap<>();
    this.receivedOffers = new ConcurrentHashMap<>();
    this.completedTrades = new ConcurrentHashMap<>();
    this.tariffTrades = new ConcurrentHashMap<>();

    // ResourceModule injects the scheduler immediately after construction.
  }

  /** 设置调度器 */
  public void setScheduler(StarCoreScheduler scheduler) {
    this.scheduler = scheduler;
    if (scheduler != null) {
      scheduler.runSyncTimer(() -> cleanExpiredOffers(), 60 * 20L, 60 * 20L);
      scheduler.runSyncTimer(this::retryPendingRefunds, 20 * 20L, 20 * 20L);
    }
  }

  /** 设置事件总线 */
  public void setEventBus(StarCoreEventBus eventBus) {
    this.eventBus = eventBus;
  }

  public void setTradeHistoryService(TradeHistoryService tradeHistoryService) {
    this.settlementCoordinator =
        tradeHistoryService == null || transactionFabric == null
            ? null
            : new TradeSettlementCoordinator(tradeHistoryService, transactionFabric, logger);
  }

  /** 注入国家服务。所有涉及国家资源的玩家交易均 fail-closed； 未注入时不会接受任何直接交易或快速买卖。 */
  public void setNationService(NationService nationService) {
    this.nationService = nationService;
  }

  @Override
  public synchronized Optional<PlayerTradeOffer> createTradeOffer(
      UUID initiatorId,
      NationId initiatorNationId,
      UUID targetId,
      NationId targetNationId,
      String resourceId,
      long amount,
      double pricePerUnit,
      long expirySeconds) {
    if (!validateTradeParticipants(
        initiatorId, initiatorNationId, targetId, targetNationId, "createTradeOffer")) {
      return Optional.empty();
    }

    if (initiatorId.equals(targetId)) {
      return Optional.empty(); // 不能与自己交易
    }

    if (resourceId == null || !RESOURCE_ID_PATTERN.matcher(resourceId).matches()) {
      publishEvent(
          new TradeOfferRejectedEvent(initiatorId, targetId, "Invalid resource identifier"));
      return Optional.empty();
    }

    TradeOfferTerms.Validation termsValidation =
        TradeOfferTerms.validate(amount, pricePerUnit, expirySeconds);
    if (!termsValidation.isValid()) {
      publishEvent(
          new TradeOfferRejectedEvent(
              initiatorId, targetId, "Invalid trade terms: " + termsValidation.violation().name()));
      return Optional.empty();
    }

    TradeOfferTerms terms = termsValidation.terms();
    amount = terms.amount();
    pricePerUnit = terms.pricePerUnitAsDouble();
    expirySeconds = terms.expirySeconds();

    String resId = resourceId.toLowerCase(Locale.ROOT);
    UUID offerId = UUID.randomUUID();
    // The shared terms policy performs finite-number validation, hard caps,
    // two-decimal rounding and rounded-zero rejection before any economy call.
    BigDecimal totalValueBd = terms.totalValue();
    double totalValue = totalValueBd.doubleValue();
    BigDecimal transactionFee =
        taxService.calculateTaxBD(resId, totalValueBd, TradeTaxService.TaxType.TRANSACTION_FEE);
    ResourceTariff.Trade tariffTrade =
        prepareTariff(
            offerId, initiatorId, initiatorNationId, targetId, targetNationId, totalValueBd);
    BigDecimal totalTaxBd =
        transactionFee.add(tariffTrade == null ? BigDecimal.ZERO : tariffTrade.tariffAmount());
    double taxAmount = totalTaxBd.setScale(2, RoundingMode.HALF_UP).doubleValue();
    BigDecimal totalCostBd = totalValueBd.add(totalTaxBd).setScale(2, RoundingMode.HALF_UP);

    // 检查发起者资金
    if (!economyService.has(initiatorId, totalCostBd)) {
      publishEvent(new TradeOfferRejectedEvent(initiatorId, targetId, "Insufficient funds"));
      return Optional.empty();
    }

    // B-058: 国家归属与 resource.trade 权限已在服务层验证；此处只读取已授权卖方国家库存。
    if (resourceService.amount(targetNationId, resId) < amount) {
      publishEvent(
          new TradeOfferRejectedEvent(
              initiatorId, targetId, "Seller does not have enough resources"));
      return Optional.empty();
    }

    Instant now = Instant.now();
    Instant expiresAt = now.plusSeconds(expirySeconds);

    PlayerTradeOffer offer =
        new PlayerTradeOffer(
            offerId,
            initiatorId,
            targetId,
            initiatorNationId,
            targetNationId,
            resId,
            amount,
            pricePerUnit,
            totalValue,
            taxAmount,
            now,
            expiresAt,
            PlayerTradeOffer.OfferStatus.PENDING);

    // audit B-060: 之前 sentOffers.computeIfAbsent(initiatorId, k->new ArrayList<>()).add(offerId)
    // 无上限。
    // 恶意玩家可创建无数未完成 offer 使 Map 无限增长。加每玩家未完成 offer 上限（默认 64）。
    final int MAX_PENDING_OFFERS_PER_PLAYER = 64;
    List<UUID> initiatorSent =
        sentOffers.computeIfAbsent(initiatorId, k -> new CopyOnWriteArrayList<>());
    synchronized (initiatorSent) {
      long pending =
          initiatorSent.stream()
              .map(pendingOffers::get)
              .filter(o -> o != null && o.isPending())
              .count();
      if (pending >= MAX_PENDING_OFFERS_PER_PLAYER) {
        publishEvent(
            new TradeOfferRejectedEvent(
                initiatorId,
                targetId,
                "Pending offer limit reached (" + MAX_PENDING_OFFERS_PER_PLAYER + ")"));
        return Optional.empty();
      }
      if (!initiatorSent.contains(offerId)) {
        initiatorSent.add(offerId);
      }
      pendingOffers.put(offerId, offer);
    }
    if (tariffTrade != null) {
      tariffTrades.put(offerId, tariffTrade);
    }
    receivedOffers.computeIfAbsent(targetId, k -> new CopyOnWriteArrayList<>()).add(offerId);

    publishEvent(new TradeOfferCreatedEvent(offer));
    return Optional.of(offer);
  }

  @Override
  public synchronized Optional<TradeRecord> acceptTrade(UUID actorId, UUID offerId) {
    PlayerTradeOffer offer = pendingOffers.get(offerId);
    if (actorId == null
        || offer == null
        || !offer.isPending()
        || !actorId.equals(offer.targetId())) {
      return Optional.empty();
    }

    // 接受时重新读取国家归属和权限，防止报价创建后退国、转国或权限撤销。
    if (!validateTradeParticipants(
        offer.initiatorId(),
        offer.initiatorNationId(),
        offer.targetId(),
        offer.targetNationId(),
        "acceptTrade")) {
      rejectTrade(offer.targetId(), offerId);
      return Optional.empty();
    }

    // 再次检查资源
    final long availableResources;
    try {
      availableResources = resourceService.amount(offer.targetNationId(), offer.resourceId());
    } catch (RuntimeException failure) {
      rejectTrade(offer.targetId(), offerId);
      publishEvent(
          new TradeOfferRejectedEvent(
              offer.initiatorId(), offer.targetId(), "Seller resource lookup failed"));
      return Optional.empty();
    }
    if (availableResources < offer.amount()) {
      rejectTrade(offer.targetId(), offerId);
      return Optional.empty();
    }

    // 执行交易
    ResourceTariff.Trade tariffTrade = tariffTrades.get(offerId);
    BigDecimal totalCost =
        BigDecimal.valueOf(offer.totalValue())
            .add(BigDecimal.valueOf(offer.taxAmount()))
            .setScale(2, RoundingMode.HALF_UP);
    // Persist immutable terms before any external asset operation.
    TradeRecord planned =
        TradeRecord.createPlayerTrade(
            offer.initiatorId(),
            offer.targetId(),
            offer.initiatorNationId(),
            offer.targetNationId(),
            offer.resourceId(),
            offer.amount(),
            offer.pricePerUnit(),
            offer.taxAmount(),
            "Direct trade");
    TransactionRecord fabricTransaction =
        beginFabricTransaction(
            offer.offerId(), offer.initiatorId(), totalCost, "trade:" + offer.offerId(), planned);

    // audit B-057: 之前 withdraw 失败仅返回 Optional.empty()，调用方无法区分"offer不存在"还是"买家余额不足"。
    // 最小修复：失败时记录日志 + 发布 rejected 事件（带原因），仍返回 empty 保持 API 兼容。
    // 买家付款
    if (!economyService.withdraw(offer.initiatorId(), totalCost)) {
      failFabricTransaction(fabricTransaction, "trade buyer debit rejected");
      logger.warning(
          "[acceptTrade] buyer "
              + offer.initiatorId()
              + " withdraw failed (insufficient or transient); offer="
              + offer.offerId());
      publishEvent(
          new TradeOfferRejectedEvent(
              offer.initiatorId(), offer.targetId(), "Buyer withdraw failed"));
      rejectTrade(offer.targetId(), offerId);
      return Optional.empty();
    }
    transitionFabric(fabricTransaction, EconomyTransactionState.DEBITED, "trade buyer debited");

    // audit B-056: 之前卖家收款 = totalValue - taxAmount，但买家已支付 totalValue + taxAmount，
    // 等于税被收 2 次（买家付税、卖家扣税），吞掉 2*税额。
    // 语义澄清："买方承担税"——买家支付 totalValue+税，卖家应得 totalValue 全额（不再扣税）。
    // 修复：卖家收款改为 offer.totalValue()（不再减 taxAmount）。这里保留旧分支注释便于审计。
    boolean sellerPaysTax = false; // 当前游戏语义：买方承担税
    double sellerReceives =
        sellerPaysTax ? (offer.totalValue() - offer.taxAmount()) : offer.totalValue();

    // 卖家收款
    // audit B-054: 之前顺序为 withdraw→deposit→collectTax→consume→grant，任一步崩溃下钱已扣但交易未完成。
    // 最小修复：deposit 失败时把 withdraw 钱退回买家；consume 返回 false 时回滚 deposit+withdraw 并返回 empty。
    boolean sellerDeposited;
    try {
      sellerDeposited =
          economyService.deposit(
              offer.targetId(),
              BigDecimal.valueOf(sellerReceives).setScale(2, RoundingMode.HALF_UP));
    } catch (RuntimeException e) {
      sellerDeposited = false;
      logger.warning("[acceptTrade] seller deposit threw: " + e.getMessage());
    }
    if (!sellerDeposited) {
      boolean buyerRefunded;
      try {
        buyerRefunded = economyService.deposit(offer.initiatorId(), totalCost);
      } catch (RuntimeException failure) {
        buyerRefunded = false;
        logger.warning("[acceptTrade] buyer refund threw: " + failure.getMessage());
      }
      tariffTrades.remove(offerId);
      publishEvent(
          new TradeOfferRejectedEvent(
              offer.initiatorId(), offer.targetId(), "Seller deposit failed"));
      rejectTrade(offer.targetId(), offerId);
      if (!buyerRefunded) {
        transitionFabric(
            fabricTransaction, EconomyTransactionState.REFUND_PENDING, "trade refund pending");
        recordPendingRefund(
            refundTransactionId(fabricTransaction, offer.offerId()),
            offer.initiatorId(),
            totalCost,
            "trade:" + offer.offerId());
        if (refundLedger == null) {
          transitionFabric(
              fabricTransaction,
              EconomyTransactionState.MANUAL_REVIEW,
              "trade refund has no retry ledger");
        }
        throw new IllegalStateException(
            "Buyer refund failed after seller deposit failure for offer " + offerId);
      }
      transitionFabric(
          fabricTransaction, EconomyTransactionState.REFUND_PENDING, "trade refund pending");
      transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "trade compensated");
      logger.warning(
          "[acceptTrade] rolled back buyer withdraw due to seller deposit failure; offer="
              + offerId);
      return Optional.empty();
    }

    // 资源转移
    if (offer.targetNationId() != null && offer.initiatorNationId() != null) {
      // audit B-054: consume 返回值必须校验，失败则回滚已发生的金额转移。
      boolean consumed;
      try {
        consumed =
            resourceService.consume(offer.targetNationId(), offer.resourceId(), offer.amount());
      } catch (RuntimeException e) {
        consumed = false;
        logger.warning("[acceptTrade] consume threw: " + e.getMessage());
      }
      if (!consumed) {
        rollbackMoneyAfterResourceFailure(
            offer,
            totalCost,
            sellerReceives,
            offerId,
            "Resource consume failed",
            fabricTransaction);
        return Optional.empty();
      }
      boolean granted;
      try {
        granted =
            resourceService.grant(offer.initiatorNationId(), offer.resourceId(), offer.amount());
      } catch (RuntimeException exception) {
        granted = false;
        logger.warning("[acceptTrade] grant threw: " + exception.getMessage());
      }
      if (!granted) {
        boolean sellerResourceRestored =
            resourceService.grant(offer.targetNationId(), offer.resourceId(), offer.amount());
        rollbackMoneyAfterResourceFailure(
            offer, totalCost, sellerReceives, offerId, "Resource grant failed", fabricTransaction);
        if (!sellerResourceRestored) {
          throw new IllegalStateException(
              "Seller resource restoration failed after grant failure for offer " + offerId);
        }
        return Optional.empty();
      }
    }

    // 只有资源转移成功后才确认已预扣税款，失败时不会留下国库孤儿账。
    try {
      if (tariffTrade != null) {
        if (!completeTariff(tariffTrade)) {
          logger.warning("Resource trade business audit was incomplete for offer " + offerId);
        }
      }
      BigDecimal tariffAmount = tariffTrade == null ? BigDecimal.ZERO : tariffTrade.tariffAmount();
      BigDecimal transactionFee =
          BigDecimal.valueOf(offer.taxAmount())
              .subtract(tariffAmount)
              .max(BigDecimal.ZERO)
              .setScale(2, RoundingMode.DOWN);
      if (offer.initiatorNationId() != null && transactionFee.signum() > 0) {
        taxService.fundTax(
            new TradeTaxService.TaxReceipt(
                offer.offerId(),
                offer.initiatorNationId(),
                TradeTaxService.TaxType.TRANSACTION_FEE,
                transactionFee));
      }
    } catch (RuntimeException exception) {
      try {
        rollbackAcceptedTrade(offer, totalCost, sellerReceives, fabricTransaction);
        transitionFabric(
            fabricTransaction,
            EconomyTransactionState.REFUND_PENDING,
            "trade tax rollback pending");
        transitionFabric(
            fabricTransaction, EconomyTransactionState.REFUNDED, "trade tax rollback completed");
      } catch (RuntimeException rollbackFailure) {
        exception.addSuppressed(rollbackFailure);
        transitionFabric(
            fabricTransaction,
            EconomyTransactionState.REFUND_PENDING,
            "trade tax rollback requires review");
        transitionFabric(
            fabricTransaction,
            EconomyTransactionState.MANUAL_REVIEW,
            "trade tax rollback requires review");
      }
      if (tariffTrade != null) {
        try {
          reverseTariff(tariffTrade);
        } catch (RuntimeException reversalFailure) {
          exception.addSuppressed(reversalFailure);
        }
      }
      tariffTrades.remove(offerId);
      rejectTrade(offer.targetId(), offerId);
      throw new IllegalStateException(
          "Resource trade tax settlement failed for offer " + offerId, exception);
    }

    // 更新状态
    pendingOffers.put(
        offerId,
        new PlayerTradeOffer(
            offer.offerId(),
            offer.initiatorId(),
            offer.targetId(),
            offer.initiatorNationId(),
            offer.targetNationId(),
            offer.resourceId(),
            offer.amount(),
            offer.pricePerUnit(),
            offer.totalValue(),
            offer.taxAmount(),
            offer.createdAt(),
            offer.expiresAt(),
            PlayerTradeOffer.OfferStatus.ACCEPTED));

    // 清理引用
    removeOfferReferences(offerId);
    tariffTrades.remove(offerId);

    TradeRecord record = settlementCoordinator.commit(fabricTransaction);
    completedTrades.put(offerId, record);
    publishEvent(new TradeAcceptedEvent(offer, record));
    return Optional.of(record);
  }

  @Override
  public synchronized PlayerTradeService.ActionResult acceptTradeResult(
      UUID actorId, UUID offerId) {
    UUID transactionId = transactionIdForOffer(offerId);
    PlayerTradeOffer existingOffer = pendingOffers.get(offerId);
    if (existingOffer != null
        && Objects.equals(actorId, existingOffer.targetId())
        && existingOffer.status() == PlayerTradeOffer.OfferStatus.ACCEPTED
        && transactionState(transactionId) == EconomyTransactionState.COMMITTED) {
      return new PlayerTradeService.ActionResult(
          PlayerTradeService.ActionStatus.APPLIED,
          offerId,
          transactionId,
          completedTrades.get(offerId),
          "Trade already accepted");
    }
    try {
      Optional<TradeRecord> record = acceptTrade(actorId, offerId);
      transactionId = transactionIdForOffer(offerId, transactionId);
      if (record.isPresent()) {
        return new PlayerTradeService.ActionResult(
            PlayerTradeService.ActionStatus.APPLIED,
            offerId,
            transactionId,
            record.orElseThrow(),
            "Trade accepted");
      }
    } catch (RuntimeException failure) {
      transactionId = transactionIdForOffer(offerId, transactionId);
      EconomyTransactionState state = transactionState(transactionId);
      PlayerTradeService.ActionStatus status =
          state == EconomyTransactionState.REFUND_PENDING
              ? PlayerTradeService.ActionStatus.COMPENSATION_PENDING
              : state == EconomyTransactionState.MANUAL_REVIEW
                  ? PlayerTradeService.ActionStatus.MANUAL_REVIEW
                  : PlayerTradeService.ActionStatus.FAILED;
      return new PlayerTradeService.ActionResult(
          status, offerId, transactionId, null, failure.getMessage());
    }

    PlayerTradeOffer offer = pendingOffers.get(offerId);
    if (offer == null) {
      return new PlayerTradeService.ActionResult(
          PlayerTradeService.ActionStatus.NOT_FOUND,
          offerId,
          transactionId,
          null,
          "Trade offer not found");
    }
    if (actorId == null || !actorId.equals(offer.targetId())) {
      return new PlayerTradeService.ActionResult(
          PlayerTradeService.ActionStatus.UNAUTHORIZED,
          offerId,
          transactionId,
          null,
          "Only the target may accept this trade");
    }
    EconomyTransactionState state = transactionState(transactionId);
    PlayerTradeService.ActionStatus status = actionStatusForFailedAccept(offer, state);
    return new PlayerTradeService.ActionResult(
        status, offerId, transactionId, null, "Trade offer was not accepted");
  }

  @Override
  public synchronized boolean rejectTrade(UUID actorId, UUID offerId) {
    PlayerTradeOffer offer = pendingOffers.get(offerId);
    if (actorId == null
        || offer == null
        || !offer.isPending()
        || !actorId.equals(offer.targetId())) {
      return false;
    }

    pendingOffers.put(
        offerId,
        new PlayerTradeOffer(
            offer.offerId(),
            offer.initiatorId(),
            offer.targetId(),
            offer.initiatorNationId(),
            offer.targetNationId(),
            offer.resourceId(),
            offer.amount(),
            offer.pricePerUnit(),
            offer.totalValue(),
            offer.taxAmount(),
            offer.createdAt(),
            offer.expiresAt(),
            PlayerTradeOffer.OfferStatus.REJECTED));

    removeOfferReferences(offerId);
    tariffTrades.remove(offerId);

    publishEvent(new TradeRejectedEvent(offer));
    return true;
  }

  @Override
  public synchronized boolean cancelOffer(UUID actorId, UUID offerId) {
    PlayerTradeOffer offer = pendingOffers.get(offerId);
    if (actorId == null
        || offer == null
        || !offer.isPending()
        || !actorId.equals(offer.initiatorId())) {
      return false;
    }

    pendingOffers.put(
        offerId,
        new PlayerTradeOffer(
            offer.offerId(),
            offer.initiatorId(),
            offer.targetId(),
            offer.initiatorNationId(),
            offer.targetNationId(),
            offer.resourceId(),
            offer.amount(),
            offer.pricePerUnit(),
            offer.totalValue(),
            offer.taxAmount(),
            offer.createdAt(),
            offer.expiresAt(),
            PlayerTradeOffer.OfferStatus.CANCELLED));

    removeOfferReferences(offerId);
    tariffTrades.remove(offerId);

    publishEvent(new TradeOfferCancelledEvent(offer));
    return true;
  }

  @Override
  public Optional<PlayerTradeOffer> getOffer(UUID offerId) {
    return Optional.ofNullable(pendingOffers.get(offerId));
  }

  @Override
  public List<PlayerTradeOffer> getSentOffers(UUID playerId) {
    List<UUID> offerIds = sentOffers.get(playerId);
    if (offerIds == null) {
      return List.of();
    }

    return offerIds.stream()
        .map(pendingOffers::get)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public List<PlayerTradeOffer> getReceivedOffers(UUID playerId) {
    List<UUID> offerIds = receivedOffers.get(playerId);
    if (offerIds == null) {
      return List.of();
    }

    return offerIds.stream()
        .map(pendingOffers::get)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public int getPendingOfferCount(UUID playerId) {
    List<PlayerTradeOffer> received = getReceivedOffers(playerId);
    return (int) received.stream().filter(PlayerTradeOffer::isPending).count();
  }

  @Override
  public synchronized int cleanExpiredOffers() {
    int count = 0;
    for (Map.Entry<UUID, PlayerTradeOffer> entry : pendingOffers.entrySet()) {
      PlayerTradeOffer offer = entry.getValue();
      if (offer.isExpired() && offer.status() == PlayerTradeOffer.OfferStatus.PENDING) {
        pendingOffers.put(
            entry.getKey(),
            new PlayerTradeOffer(
                offer.offerId(),
                offer.initiatorId(),
                offer.targetId(),
                offer.initiatorNationId(),
                offer.targetNationId(),
                offer.resourceId(),
                offer.amount(),
                offer.pricePerUnit(),
                offer.totalValue(),
                offer.taxAmount(),
                offer.createdAt(),
                offer.expiresAt(),
                PlayerTradeOffer.OfferStatus.EXPIRED));
        removeOfferReferences(entry.getKey());
        tariffTrades.remove(entry.getKey());
        count++;
      }
    }

    if (count > 0) {
      publishEvent(new ExpiredOffersCleanedEvent(count));
    }

    return count;
  }

  @Override
  public Optional<TradeRecord> quickBuy(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    if (!validateNationAccess(playerId, nationId, "quickBuy")) {
      return Optional.empty();
    }
    ResourceTradeTerms.Validation terms = ResourceTradeTerms.validateTransfer(resourceId, amount);
    if (!terms.isValid()) {
      publishEvent(
          new TradeOfferRejectedEvent(
              playerId, null, "Invalid quick trade terms: " + terms.violation().name()));
      return Optional.empty();
    }
    UUID transactionId = UUID.randomUUID();
    String resId = terms.terms().resourceId();

    // audit B-063: 之前 marketReserve==null 时直接 resourceService.grant() 给国家发资源，
    // 未扣等价资源 = 凭空刷资源。改为无 marketReserve 时拒绝 quickBuy（除非有明确"系统供给"语义）。
    if (marketReserve == null) {
      logger.warning(
          "[quickBuy] rejected: marketReserve not configured; "
              + "cannot grant resources from thin air (player="
              + playerId
              + ", nation="
              + nationId
              + ")");
      publishEvent(new TradeOfferRejectedEvent(playerId, null, "Market reserve not available"));
      return Optional.empty();
    }

    // 获取市场价格
    double price;
    if (orderBookService != null) {
      price = orderBookService.getCurrentMarketPrice(resId);
    } else {
      price = 100.0; // 默认价格
    }

    ResourceTradeTerms.Validation pricing = ResourceTradeTerms.validateOrder(resId, amount, price);
    if (!pricing.isValid()) {
      publishEvent(
          new TradeOfferRejectedEvent(
              playerId, null, "Invalid quick trade terms: " + pricing.violation().name()));
      return Optional.empty();
    }
    price = pricing.terms().pricePerUnitAsDouble();

    // 获取最佳卖价（如果订单簿可用）
    if (orderBookService != null) {
      Optional<Double> bestAsk = orderBookService.getBestAsk(resId);
      if (bestAsk.isPresent()) {
        price = bestAsk.get();
      }
    }

    // 计算总额
    double totalValue = amount * price;
    if (!Double.isFinite(totalValue)) {
      return Optional.empty();
    }
    double taxAmount =
        taxService.calculateTax(resId, totalValue, TradeTaxService.TaxType.TRANSACTION_FEE);
    double totalCost = totalValue + taxAmount;
    // Persist immutable terms before any external asset operation.
    TradeRecord planned =
        TradeRecord.createPlayerTrade(
            playerId,
            null, // 没有卖家
            nationId,
            null,
            resId,
            amount,
            price,
            taxAmount,
            "Quick buy");
    TransactionRecord fabricTransaction =
        beginFabricTransaction(
            transactionId,
            playerId,
            BigDecimal.valueOf(totalCost).setScale(2, RoundingMode.HALF_UP),
            "trade:quick-buy:" + transactionId,
            planned);

    // 检查资金
    if (!economyService.has(playerId, BigDecimal.valueOf(totalCost))) {
      failFabricTransaction(fabricTransaction, "quick buy funds unavailable");
      return Optional.empty();
    }

    // audit B-062: 之前 withdraw 返回值未检查，余额不足时仍继续发资源/记税 = 玩家不出钱白拿资源。
    if (!economyService.withdraw(playerId, BigDecimal.valueOf(totalCost))) {
      failFabricTransaction(fabricTransaction, "quick buy debit rejected");
      logger.warning("[quickBuy] withdraw failed (insufficient); player=" + playerId);
      return Optional.empty();
    }
    transitionFabric(fabricTransaction, EconomyTransactionState.DEBITED, "quick buy debited");

    // 从市场储备获取资源并发放给玩家
    // audit B-064: 之前 consumeReserve 失败仅 log warning，玩家钱已扣、国家没拿到资源，无回滚。
    // 修复：consumeReserve 失败时把钱退回玩家（deposit），并返回 empty。
    boolean resourceGranted = false;
    try {
      resourceGranted = marketReserve.consumeReserve(resId, amount);
    } catch (RuntimeException e) {
      logger.warning("[quickBuy] consumeReserve threw: " + e.getMessage());
      resourceGranted = false;
    }
    if (resourceGranted) {
      boolean delivered;
      try {
        delivered = resourceService.grant(nationId, resId, amount);
      } catch (RuntimeException exception) {
        delivered = false;
        logger.warning("[quickBuy] resource delivery threw: " + exception.getMessage());
      }
      if (!delivered) {
        marketReserve.addReserve(resId, amount);
        if (!economyService.deposit(
            playerId, BigDecimal.valueOf(totalCost).setScale(2, RoundingMode.HALF_UP))) {
          transitionFabric(
              fabricTransaction,
              EconomyTransactionState.REFUND_PENDING,
              "quick buy refund pending");
          throw new IllegalStateException(
              "Quick buy refund failed after resource delivery failure for " + playerId);
        }
        transitionFabric(
            fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick buy refund pending");
        transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "quick buy refunded");
        logger.warning("[quickBuy] resource delivery failed; reserve and payment restored");
        return Optional.empty();
      }
      logger.info("QuickBuy: Granted " + amount + " " + resId + " to nation " + nationId);
    } else {
      boolean refunded =
          economyService.deposit(
              playerId, BigDecimal.valueOf(totalCost).setScale(2, RoundingMode.HALF_UP));
      publishEvent(new TradeOfferRejectedEvent(playerId, null, "Market reserve consume failed"));
      if (!refunded) {
        transitionFabric(
            fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick buy refund pending");
        throw new IllegalStateException(
            "Quick buy refund failed after reserve consume failure for " + playerId);
      }
      transitionFabric(
          fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick buy refund pending");
      transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "quick buy refunded");
      logger.warning(
          "[quickBuy] rolled back withdraw due to consumeReserve failure; "
              + "player="
              + playerId
              + ", resource="
              + resId
              + ", amount="
              + amount);
      return Optional.empty();
    }

    if (nationId != null && taxAmount > 0) {
      TradeTaxService.TaxReceipt feeReceipt =
          new TradeTaxService.TaxReceipt(
              transactionId,
              nationId,
              TradeTaxService.TaxType.TRANSACTION_FEE,
              BigDecimal.valueOf(taxAmount));
      try {
        taxService.fundTax(feeReceipt);
      } catch (RuntimeException failure) {
        return rollbackQuickBuyTaxFailure(
            feeReceipt,
            playerId,
            nationId,
            resId,
            amount,
            BigDecimal.valueOf(totalCost).setScale(2, RoundingMode.HALF_UP),
            failure,
            fabricTransaction);
      }
    }

    TradeRecord record = settlementCoordinator.commit(fabricTransaction);
    publishEvent(new QuickTradeExecutedEvent(record));
    return Optional.of(record);
  }

  @Override
  public synchronized PlayerTradeService.ActionResult quickBuyResult(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    return executeQuickResult(
        playerId, "trade:quick-buy:", () -> quickBuy(playerId, nationId, resourceId, amount));
  }

  @Override
  public Optional<TradeRecord> quickSell(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    if (!validateNationAccess(playerId, nationId, "quickSell")) {
      return Optional.empty();
    }
    ResourceTradeTerms.Validation terms = ResourceTradeTerms.validateTransfer(resourceId, amount);
    if (!terms.isValid()) {
      publishEvent(
          new TradeOfferRejectedEvent(
              playerId, null, "Invalid quick trade terms: " + terms.violation().name()));
      return Optional.empty();
    }
    UUID transactionId = UUID.randomUUID();
    String resId = terms.terms().resourceId();

    // 检查玩家资源
    if (nationId != null) {
      if (resourceService.amount(nationId, resId) < amount) {
        return Optional.empty();
      }
    }

    // 获取市场价格
    double price;
    if (orderBookService != null) {
      price = orderBookService.getCurrentMarketPrice(resId);
    } else {
      price = 100.0;
    }

    // 获取最佳买价
    if (orderBookService != null) {
      Optional<Double> bestBid = orderBookService.getBestBid(resId);
      if (bestBid.isPresent()) {
        price = bestBid.get();
      }
    }

    ResourceTradeTerms.Validation pricing = ResourceTradeTerms.validateOrder(resId, amount, price);
    if (!pricing.isValid()) {
      publishEvent(
          new TradeOfferRejectedEvent(
              playerId, null, "Invalid quick trade terms: " + pricing.violation().name()));
      return Optional.empty();
    }
    price = pricing.terms().pricePerUnitAsDouble();

    double totalValue = amount * price;
    if (!Double.isFinite(totalValue)) {
      return Optional.empty();
    }
    double taxAmount =
        taxService.calculateTax(resId, totalValue, TradeTaxService.TaxType.TRANSACTION_FEE);
    double netValue = totalValue - taxAmount;
    // Persist immutable terms before any external asset operation.
    TradeRecord planned =
        TradeRecord.createPlayerTrade(
            null, // 没有买家
            playerId,
            null,
            nationId,
            resId,
            amount,
            price,
            taxAmount,
            "Quick sell");
    TransactionRecord fabricTransaction =
        beginFabricTransaction(
            transactionId,
            playerId,
            BigDecimal.valueOf(netValue).setScale(2, RoundingMode.HALF_UP),
            "trade:quick-sell:" + transactionId,
            planned);

    // 扣除资源
    if (nationId != null) {
      if (!resourceService.consume(nationId, resId, amount)) {
        failFabricTransaction(fabricTransaction, "quick sell resource debit rejected");
        return Optional.empty();
      }
    }

    // 收款
    // audit B-065: 之前 consume 国家资源后 deposit 玩家钱，若 deposit 失败玩家没钱入账但国家资源已被扣。
    // 修复：deposit 失败时把资源 grant 回国家，避免凭空损失。
    boolean deposited;
    try {
      deposited =
          economyService.deposit(
              playerId, BigDecimal.valueOf(netValue).setScale(2, RoundingMode.HALF_UP));
    } catch (RuntimeException e) {
      deposited = false;
      logger.warning("[quickSell] deposit threw: " + e.getMessage());
    }
    if (!deposited) {
      boolean resourceRestored = nationId == null || resourceService.grant(nationId, resId, amount);
      publishEvent(new TradeOfferRejectedEvent(playerId, null, "Deposit failed"));
      if (!resourceRestored) {
        failFabricTransaction(fabricTransaction, "quick sell rollback requires review");
        transitionFabric(
            fabricTransaction,
            EconomyTransactionState.MANUAL_REVIEW,
            "quick sell rollback requires review");
        throw new IllegalStateException(
            "Quick sell resource restoration failed for nation "
                + nationId
                + " resource="
                + resId
                + " amount="
                + amount);
      }
      failFabricTransaction(fabricTransaction, "quick sell deposit rejected");
      logger.warning(
          "[quickSell] rolled back consume due to deposit failure; "
              + "player="
              + playerId
              + ", resource="
              + resId
              + ", amount="
              + amount);
      return Optional.empty();
    }

    transitionFabric(fabricTransaction, EconomyTransactionState.DEBITED, "quick sell settled");

    if (nationId != null && taxAmount > 0) {
      TradeTaxService.TaxReceipt feeReceipt =
          new TradeTaxService.TaxReceipt(
              transactionId,
              nationId,
              TradeTaxService.TaxType.TRANSACTION_FEE,
              BigDecimal.valueOf(taxAmount));
      try {
        taxService.fundTax(feeReceipt);
      } catch (RuntimeException failure) {
        return rollbackQuickSellTaxFailure(
            feeReceipt,
            playerId,
            nationId,
            resId,
            amount,
            BigDecimal.valueOf(netValue).setScale(2, RoundingMode.HALF_UP),
            failure,
            fabricTransaction);
      }
    }

    TradeRecord record = settlementCoordinator.commit(fabricTransaction);
    publishEvent(new QuickTradeExecutedEvent(record));
    return Optional.of(record);
  }

  @Override
  public synchronized PlayerTradeService.ActionResult quickSellResult(
      UUID playerId, NationId nationId, String resourceId, long amount) {
    return executeQuickResult(
        playerId, "trade:quick-sell:", () -> quickSell(playerId, nationId, resourceId, amount));
  }

  private PlayerTradeService.ActionResult executeQuickResult(
      UUID playerId, String reasonPrefix, Supplier<Optional<TradeRecord>> action) {
    Instant started = Instant.now();
    try {
      Optional<TradeRecord> record = action.get();
      TransactionRecord transaction = latestQuickTransaction(playerId, reasonPrefix, started);
      if (record.isPresent()) {
        return new PlayerTradeService.ActionResult(
            PlayerTradeService.ActionStatus.APPLIED,
            null,
            transaction == null ? null : transaction.transactionId(),
            record.orElseThrow(),
            "Quick trade completed");
      }
      return quickFailureResult(transaction, "Quick trade was not completed");
    } catch (RuntimeException failure) {
      TransactionRecord transaction = latestQuickTransaction(playerId, reasonPrefix, started);
      PlayerTradeService.ActionResult failed =
          quickFailureResult(transaction, failure.getMessage());
      return failed.status() == PlayerTradeService.ActionStatus.REJECTED && transaction == null
          ? new PlayerTradeService.ActionResult(
              PlayerTradeService.ActionStatus.FAILED, null, null, null, failure.getMessage())
          : failed;
    }
  }

  private PlayerTradeService.ActionResult quickFailureResult(
      TransactionRecord transaction, String message) {
    EconomyTransactionState state = transaction == null ? null : transaction.state();
    PlayerTradeService.ActionStatus status =
        state == EconomyTransactionState.REFUND_PENDING
            ? PlayerTradeService.ActionStatus.COMPENSATION_PENDING
            : state == EconomyTransactionState.MANUAL_REVIEW
                ? PlayerTradeService.ActionStatus.MANUAL_REVIEW
                : state == EconomyTransactionState.REFUNDED
                    ? PlayerTradeService.ActionStatus.COMPENSATED
                    : PlayerTradeService.ActionStatus.REJECTED;
    return new PlayerTradeService.ActionResult(
        status, null, transaction == null ? null : transaction.transactionId(), null, message);
  }

  private TransactionRecord latestQuickTransaction(
      UUID playerId, String reasonPrefix, Instant started) {
    if (transactionFabric == null) return null;
    return transactionFabric.snapshot().stream()
        .filter(record -> record.accountId().equals(playerId))
        .filter(record -> record.reason().startsWith(reasonPrefix))
        .filter(record -> !record.createdAt().isBefore(started))
        .max(java.util.Comparator.comparing(TransactionRecord::updatedAt))
        .orElse(null);
  }

  private Optional<TradeRecord> rollbackQuickBuyTaxFailure(
      TradeTaxService.TaxReceipt feeReceipt,
      UUID playerId,
      NationId nationId,
      String resourceId,
      long amount,
      BigDecimal totalCost,
      RuntimeException fundingFailure,
      TransactionRecord fabricTransaction) {
    List<RuntimeException> failures = new ArrayList<>();
    try {
      taxService.reverseFundedTax(feeReceipt);
    } catch (RuntimeException failure) {
      failures.add(failure);
    }
    boolean resourceReversed;
    try {
      resourceReversed = resourceService.consume(nationId, resourceId, amount);
    } catch (RuntimeException failure) {
      failures.add(failure);
      resourceReversed = false;
    }
    if (!resourceReversed) {
      failures.add(new IllegalStateException("Quick buy resource reversal failed"));
    } else {
      try {
        marketReserve.addReserve(resourceId, amount);
      } catch (RuntimeException failure) {
        failures.add(failure);
      }
    }
    try {
      if (!economyService.deposit(playerId, totalCost)) {
        failures.add(new IllegalStateException("Quick buy payment refund failed"));
      }
    } catch (RuntimeException failure) {
      failures.add(failure);
    }
    if (!failures.isEmpty()) {
      transitionFabric(
          fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick buy refund pending");
      IllegalStateException criticalFailure =
          new IllegalStateException(
              "Quick buy tax settlement rollback failed for " + feeReceipt.transactionId(),
              fundingFailure);
      failures.forEach(criticalFailure::addSuppressed);
      throw criticalFailure;
    }
    publishEvent(new TradeOfferRejectedEvent(playerId, null, "Tax funding failed"));
    logger.warning("[quickBuy] rolled back after tax funding failure; player=" + playerId);
    transitionFabric(
        fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick buy refund pending");
    transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "quick buy refunded");
    return Optional.empty();
  }

  private Optional<TradeRecord> rollbackQuickSellTaxFailure(
      TradeTaxService.TaxReceipt feeReceipt,
      UUID playerId,
      NationId nationId,
      String resourceId,
      long amount,
      BigDecimal netValue,
      RuntimeException fundingFailure,
      TransactionRecord fabricTransaction) {
    List<RuntimeException> failures = new ArrayList<>();
    try {
      taxService.reverseFundedTax(feeReceipt);
    } catch (RuntimeException failure) {
      failures.add(failure);
    }
    try {
      if (!economyService.withdraw(playerId, netValue)) {
        failures.add(new IllegalStateException("Quick sell payment reversal failed"));
      }
    } catch (RuntimeException failure) {
      failures.add(failure);
    }
    try {
      if (!resourceService.grant(nationId, resourceId, amount)) {
        failures.add(new IllegalStateException("Quick sell resource restoration failed"));
      }
    } catch (RuntimeException failure) {
      failures.add(failure);
    }
    if (!failures.isEmpty()) {
      transitionFabric(
          fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick sell refund pending");
      IllegalStateException criticalFailure =
          new IllegalStateException(
              "Quick sell tax settlement rollback failed for " + feeReceipt.transactionId(),
              fundingFailure);
      failures.forEach(criticalFailure::addSuppressed);
      throw criticalFailure;
    }
    publishEvent(new TradeOfferRejectedEvent(playerId, null, "Tax funding failed"));
    logger.warning("[quickSell] rolled back after tax funding failure; player=" + playerId);
    transitionFabric(
        fabricTransaction, EconomyTransactionState.REFUND_PENDING, "quick sell refund pending");
    transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "quick sell refunded");
    return Optional.empty();
  }

  public TradeSettlementCoordinator.RecoveryReport reconcileTradeHistory() {
    if (settlementCoordinator == null)
      return new TradeSettlementCoordinator.RecoveryReport(0, 0, 0, 0);
    return settlementCoordinator.reconcileNextPage();
  }

  private boolean validateTradeParticipants(
      UUID initiatorId,
      NationId initiatorNationId,
      UUID targetId,
      NationId targetNationId,
      String operation) {
    return validateNationAccess(initiatorId, initiatorNationId, operation + ":initiator")
        && validateNationAccess(targetId, targetNationId, operation + ":target");
  }

  private boolean validateNationAccess(UUID playerId, NationId suppliedNationId, String operation) {
    if (playerId == null || suppliedNationId == null) {
      return rejectNationAccess(
          playerId, suppliedNationId, null, operation, "player and nation IDs are required");
    }
    NationService service = nationService;
    if (service == null) {
      logger.severe(
          "[PlayerTrade] rejected "
              + operation
              + ": NationService is unavailable; player="
              + playerId
              + ", suppliedNation="
              + suppliedNationId);
      publishEvent(new TradeOfferRejectedEvent(playerId, null, "Nation service unavailable"));
      return false;
    }

    final Nation nation;
    try {
      nation = service.nationOf(playerId).orElse(null);
    } catch (RuntimeException exception) {
      logger.warning(
          "[PlayerTrade] rejected "
              + operation
              + ": nation lookup failed for player="
              + playerId
              + ": "
              + exception.getMessage());
      publishEvent(new TradeOfferRejectedEvent(playerId, null, "Nation lookup failed"));
      return false;
    }
    NationId actualNationId = nation == null ? null : nation.id();
    if (nation == null || !suppliedNationId.equals(actualNationId) || !nation.hasMember(playerId)) {
      return rejectNationAccess(
          playerId, suppliedNationId, actualNationId, operation, "nation membership mismatch");
    }
    if (!nation.hasPermission(playerId, "resource.trade")) {
      return rejectNationAccess(
          playerId,
          suppliedNationId,
          actualNationId,
          operation,
          "resource.trade permission denied");
    }
    return true;
  }

  private boolean rejectNationAccess(
      UUID playerId,
      NationId suppliedNationId,
      NationId actualNationId,
      String operation,
      String reason) {
    logger.warning(
        "[PlayerTrade] rejected "
            + operation
            + ": "
            + reason
            + "; player="
            + playerId
            + ", suppliedNation="
            + suppliedNationId
            + ", actualNation="
            + actualNationId);
    publishEvent(new TradeOfferRejectedEvent(playerId, null, reason));
    return false;
  }

  private ResourceTariff.Trade prepareTariff(
      UUID offerId,
      UUID buyerId,
      NationId importerId,
      UUID sellerId,
      NationId exporterId,
      BigDecimal grossAmount) {
    ResourceTariff tariff = resolveResourceTariff();
    return tariff == null
        ? null
        : tariff.prepare(offerId, buyerId, importerId, sellerId, exporterId, grossAmount);
  }

  private boolean completeTariff(ResourceTariff.Trade trade) {
    ResourceTariff tariff = resolveResourceTariff();
    if (tariff == null) {
      throw new IllegalStateException("Taxation service became unavailable during trade");
    }
    return tariff.complete(trade);
  }

  private BigDecimal reverseTariff(ResourceTariff.Trade trade) {
    ResourceTariff tariff = resolveResourceTariff();
    if (tariff == null) {
      throw new IllegalStateException("Taxation service became unavailable during rollback");
    }
    return tariff.reverse(trade);
  }

  private ResourceTariff resolveResourceTariff() {
    if (services == null) {
      return null;
    }
    TaxationService taxes = services.find(TaxationService.class).orElse(null);
    if (taxes == null) {
      return null;
    }
    BusinessService businesses = services.find(BusinessService.class).orElse(null);
    ResourceTariff.TradeRecorder recorder =
        businesses == null
            ? (playerId, nationId, type, amount, category) -> true
            : businesses::recordTransaction;
    return new ResourceTariff(taxes::quoteTax, taxes::fundTax, taxes::reverseFundedTax, recorder);
  }

  private void rollbackMoneyAfterResourceFailure(
      PlayerTradeOffer offer,
      BigDecimal totalCost,
      double sellerReceives,
      UUID offerId,
      String reason,
      TransactionRecord fabricTransaction) {
    BigDecimal sellerAmount = BigDecimal.valueOf(sellerReceives).setScale(2, RoundingMode.HALF_UP);
    boolean sellerReversed;
    try {
      sellerReversed = economyService.withdraw(offer.targetId(), sellerAmount);
    } catch (RuntimeException failure) {
      sellerReversed = false;
      logger.warning("[acceptTrade] seller rollback threw: " + failure.getMessage());
    }
    boolean buyerRefunded;
    try {
      buyerRefunded = economyService.deposit(offer.initiatorId(), totalCost);
    } catch (RuntimeException failure) {
      buyerRefunded = false;
      logger.warning("[acceptTrade] buyer refund threw: " + failure.getMessage());
    }
    if (!buyerRefunded) {
      recordPendingRefund(
          refundTransactionId(fabricTransaction, offer.offerId()),
          offer.initiatorId(),
          totalCost,
          "trade:" + offer.offerId());
    }
    tariffTrades.remove(offerId);
    publishEvent(new TradeOfferRejectedEvent(offer.initiatorId(), offer.targetId(), reason));
    rejectTrade(offer.targetId(), offerId);
    transitionFabric(fabricTransaction, EconomyTransactionState.REFUND_PENDING, reason);
    if (!sellerReversed) {
      transitionFabric(
          fabricTransaction, EconomyTransactionState.MANUAL_REVIEW, "seller money rollback failed");
    } else if (buyerRefunded) {
      transitionFabric(fabricTransaction, EconomyTransactionState.REFUNDED, "trade compensated");
    }
    if (!sellerReversed || !buyerRefunded) {
      throw new IllegalStateException(
          "Money rollback was incomplete for offer "
              + offerId
              + " sellerReversed="
              + sellerReversed
              + " buyerRefunded="
              + buyerRefunded
              + " reason="
              + reason);
    }
    logger.warning(
        "[acceptTrade] rolled back money transfers; offer=" + offerId + " reason=" + reason);
  }

  private void rollbackAcceptedTrade(
      PlayerTradeOffer offer,
      BigDecimal totalCost,
      double sellerReceives,
      TransactionRecord fabricTransaction) {
    BigDecimal sellerAmount = BigDecimal.valueOf(sellerReceives).setScale(2, RoundingMode.HALF_UP);
    boolean sellerReversed;
    try {
      sellerReversed = economyService.withdraw(offer.targetId(), sellerAmount);
    } catch (RuntimeException failure) {
      sellerReversed = false;
    }
    boolean buyerRefunded;
    try {
      buyerRefunded = economyService.deposit(offer.initiatorId(), totalCost);
    } catch (RuntimeException failure) {
      buyerRefunded = false;
    }
    if (!buyerRefunded) {
      recordPendingRefund(
          refundTransactionId(fabricTransaction, offer.offerId()),
          offer.initiatorId(),
          totalCost,
          "trade:" + offer.offerId());
    }
    boolean resourcesReversed = true;
    boolean sourceRestored = true;
    if (offer.targetNationId() != null && offer.initiatorNationId() != null) {
      resourcesReversed =
          resourceService.consume(offer.initiatorNationId(), offer.resourceId(), offer.amount());
      if (resourcesReversed) {
        sourceRestored =
            resourceService.grant(offer.targetNationId(), offer.resourceId(), offer.amount());
        if (!sourceRestored) {
          logger.severe(
              "[rollbackAcceptedTrade] CRITICAL: Failed to restore seller resources after consume."
                  + " Initiator: "
                  + offer.initiatorNationId()
                  + " lost "
                  + offer.amount()
                  + " "
                  + offer.resourceId()
                  + " with no recovery possible.");
        }
      }
    }
    if (!sellerReversed || !buyerRefunded || !resourcesReversed || !sourceRestored) {
      throw new IllegalStateException(
          "Resource trade rollback was incomplete for offer "
              + offer.offerId()
              + " sellerReversed="
              + sellerReversed
              + " buyerRefunded="
              + buyerRefunded
              + " resourcesReversed="
              + resourcesReversed
              + " sourceRestored="
              + sourceRestored);
    }
  }

  public boolean settleInsuredTradeRefund(TransactionRecord source) {
    if (source == null
        || source.owner() != RefundOwner.TRADE
        || source.type() != TransactionType.TRADE
        || !source.reason().startsWith("trade:")) {
      return false;
    }
    if (refundLedger != null) {
      refundLedger.markDeliveredByIdentity(
          source.reason(), source.accountId(), source.amount(), source.owner());
    }
    return true;
  }

  /** Retries refunds whose original transaction could not be rolled back completely. */
  public synchronized int retryPendingRefunds() {
    if (refundLedger == null) return 0;
    int delivered = 0;
    Instant now = Instant.now();
    for (PendingRefund refund :
        refundLedger.due(
            now, dev.starcore.starcore.foundation.economy.transaction.RefundOwner.TRADE)) {
      if (refund.owner()
          != dev.starcore.starcore.foundation.economy.transaction.RefundOwner.TRADE) {
        continue;
      }
      try {
        if (economyService.deposit(refund.accountId(), refund.amount())) {
          refundLedger.markDelivered(refund.transactionId());
          transitionRefunded(refund.transactionId(), "trade refund delivered");
          delivered++;
        } else {
          refundLedger.markFailed(
              refund, "deposit failed", RefundLedger.nextRetry(now, refund.attempts() + 1));
        }
      } catch (RuntimeException exception) {
        refundLedger.markFailed(
            refund, exception.getMessage(), RefundLedger.nextRetry(now, refund.attempts() + 1));
        logger.log(
            java.util.logging.Level.WARNING,
            "[Trade] refund retry failed: " + refund.transactionId(),
            exception);
      }
    }
    return delivered;
  }

  private void recordPendingRefund(
      UUID transactionId, UUID accountId, BigDecimal amount, String reason) {
    if (refundLedger == null) {
      logger.severe("[Trade] refund failed and no retry ledger is available: " + transactionId);
      return;
    }
    refundLedger.record(
        new PendingRefund(
                transactionId,
                accountId,
                amount,
                reason,
                0,
                RefundLedger.nextRetry(Instant.now(), 0),
                "deposit failed")
            .ownedBy(dev.starcore.starcore.foundation.economy.transaction.RefundOwner.TRADE));
    logger.severe("[Trade] refund queued for retry: " + transactionId);
  }

  private void transitionRefunded(UUID transactionId, String message) {
    if (transactionFabric == null || transactionId == null) return;
    TransactionRecord record = transactionFabric.find(transactionId).orElse(null);
    if (record == null || record.state() != EconomyTransactionState.REFUND_PENDING) return;
    transitionFabric(record, EconomyTransactionState.REFUNDED, message);
  }

  private void removeOfferReferences(UUID offerId) {
    PlayerTradeOffer offer = pendingOffers.get(offerId);
    if (offer != null) {
      sentOffers.values().forEach(list -> list.remove(offerId));
      receivedOffers.values().forEach(list -> list.remove(offerId));
    }
  }

  private void publishEvent(Object event) {
    if (eventBus != null) {
      eventBus.publish(event);
    }
  }

  private TransactionRecord beginFabricTransaction(
      UUID operationId, UUID accountId, BigDecimal amount, String reason, TradeRecord planned) {
    if (settlementCoordinator == null) {
      throw new IllegalStateException(
          "Durable trade history and transaction fabric are required before settlement");
    }
    return settlementCoordinator.prepare(operationId, accountId, amount, reason, planned);
  }

  private UUID transactionIdForOffer(UUID offerId) {
    if (transactionFabric == null || offerId == null) return null;
    return transactionFabric
        .findByIdempotencyKey("trade-offer:" + offerId)
        .map(TransactionRecord::transactionId)
        .orElse(null);
  }

  private UUID transactionIdForOffer(UUID offerId, UUID current) {
    return current == null ? transactionIdForOffer(offerId) : current;
  }

  private UUID refundTransactionId(TransactionRecord fabricTransaction, UUID fallback) {
    return fabricTransaction == null ? fallback : fabricTransaction.transactionId();
  }

  private PlayerTradeService.ActionStatus actionStatusForFailedAccept(
      PlayerTradeOffer offer, EconomyTransactionState state) {
    if (state == EconomyTransactionState.REFUND_PENDING) {
      return PlayerTradeService.ActionStatus.COMPENSATION_PENDING;
    }
    if (state == EconomyTransactionState.MANUAL_REVIEW) {
      return PlayerTradeService.ActionStatus.MANUAL_REVIEW;
    }
    if (state == EconomyTransactionState.REFUNDED) {
      return PlayerTradeService.ActionStatus.COMPENSATED;
    }
    if (state == EconomyTransactionState.DEBIT_FAILED
        || state == EconomyTransactionState.DELIVERY_FAILED) {
      return PlayerTradeService.ActionStatus.FAILED;
    }
    return offer.isExpired()
        ? PlayerTradeService.ActionStatus.EXPIRED
        : PlayerTradeService.ActionStatus.REJECTED;
  }

  private EconomyTransactionState transactionState(UUID transactionId) {
    if (transactionFabric == null || transactionId == null) return null;
    return transactionFabric.find(transactionId).map(TransactionRecord::state).orElse(null);
  }

  private void transitionFabric(
      TransactionRecord record, EconomyTransactionState next, String message) {
    if (record == null || transactionFabric == null) return;
    TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
    if (current.state() != next && current.state().canTransitionTo(next)) {
      transactionFabric.transition(current.transactionId(), next, message);
    }
  }

  private void failFabricTransaction(TransactionRecord record, String message) {
    if (record == null || transactionFabric == null) return;
    TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
    if (!current.state().isTerminal()) transactionFabric.fail(current.transactionId(), message);
  }

  // ==================== 事件类 ====================

  public record TradeOfferCreatedEvent(PlayerTradeOffer offer) {}

  public record TradeOfferAcceptedEvent(PlayerTradeOffer offer) {}

  public record TradeAcceptedEvent(PlayerTradeOffer offer, TradeRecord record) {}

  public record TradeRejectedEvent(PlayerTradeOffer offer) {}

  public record TradeOfferRejectedEvent(UUID initiatorId, UUID targetId, String reason) {}

  public record TradeOfferCancelledEvent(PlayerTradeOffer offer) {}

  public record ExpiredOffersCleanedEvent(int count) {}

  public record QuickTradeExecutedEvent(TradeRecord record) {}
}
