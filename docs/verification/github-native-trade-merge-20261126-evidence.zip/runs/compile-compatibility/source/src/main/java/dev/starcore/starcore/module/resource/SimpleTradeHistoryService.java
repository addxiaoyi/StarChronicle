package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.database.DatabaseUtils;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import dev.starcore.starcore.module.resource.model.TradeSettlementIntent;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/** 交易历史记录服务实现 */
public class SimpleTradeHistoryService implements TradeHistoryService {
  private final DatabaseService databaseService;
  private final SettlementTradeJournal commitJournal;
  private final boolean legacyJournal;

  // 内存缓存（用于快速查询）
  private final Map<UUID, TradeRecord> recordsById;
  private final Map<UUID, List<UUID>> playerRecords;
  private final Map<String, List<UUID>> nationRecords;
  private final Map<String, List<UUID>> resourceRecords;

  private final String tableName = "trade_history";

  public SimpleTradeHistoryService(DatabaseService databaseService, StarCoreScheduler scheduler) {
    this.databaseService = Objects.requireNonNull(databaseService, "databaseService");
    this.recordsById = new ConcurrentHashMap<>();
    this.playerRecords = new ConcurrentHashMap<>();
    this.nationRecords = new ConcurrentHashMap<>();
    this.resourceRecords = new ConcurrentHashMap<>();

    initializeTable();
    try (Connection connection = databaseService.getConnection()) {
      legacyJournal =
          DatabaseUtils.tableExists(connection, "trade_commit_authority")
              || DatabaseUtils.tableExists(connection, "trade_commit_log");
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot select installed trade journal", failure);
    }
    if (legacyJournal) initializeCommitJournal();
    this.commitJournal = new SettlementTradeJournal(databaseService, legacyJournal);
    loadRecordsFromDatabase();
  }

  /** 初始化数据库表 */
  private void initializeTable() {
    String sql =
        """
        CREATE TABLE IF NOT EXISTS trade_history (
            record_id VARCHAR(36) PRIMARY KEY,
            order_type VARCHAR(10) NOT NULL,
            order_source VARCHAR(20) NOT NULL,
            seller_player_id VARCHAR(36),
            buyer_player_id VARCHAR(36),
            seller_nation_id VARCHAR(36),
            buyer_nation_id VARCHAR(36),
            resource_id VARCHAR(50) NOT NULL,
            amount BIGINT NOT NULL,
            price_per_unit DOUBLE NOT NULL,
            total_value DOUBLE NOT NULL,
            tax_amount DOUBLE NOT NULL,
            net_value DOUBLE NOT NULL,
            executed_at TIMESTAMP NOT NULL,
            buy_order_id VARCHAR(36),
            sell_order_id VARCHAR(36),
            status VARCHAR(20) NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """;

    try (Connection conn = databaseService.getConnection();
        Statement stmt = conn.createStatement()) {
      stmt.execute(sql);
      if (!DatabaseUtils.columnExists(conn, tableName, "executed_at_exact")) {
        try {
          stmt.execute("ALTER TABLE trade_history ADD COLUMN executed_at_exact VARCHAR(40)");
        } catch (SQLException race) {
          if (!DatabaseUtils.columnExists(conn, tableName, "executed_at_exact")) throw race;
        }
      }
      DatabaseUtils.ensureIndex(
          conn, tableName, "idx_trade_player", "buyer_player_id", "seller_player_id");
      DatabaseUtils.ensureIndex(conn, tableName, "idx_trade_resource", "resource_id");
      DatabaseUtils.ensureIndex(conn, tableName, "idx_trade_executed", "executed_at");
      DatabaseUtils.ensureIndex(
          conn, tableName, "idx_trade_nation", "buyer_nation_id", "seller_nation_id");
    } catch (Exception e) {
      throw new RuntimeException("Failed to initialize trade_history table", e);
    }
  }

  /** Migrate existing rows as explicitly labelled baselines in the authority transaction. */
  private void initializeCommitJournal() {
    try (Connection connection = databaseService.getConnection()) {
      connection.setAutoCommit(false);
      try {
        boolean created = TradeCommitJournal.initialize(connection);
        if (created) {
          String cursor = "";
          while (true) {
            List<TradeRecord> page = new ArrayList<>();
            try (var statement =
                connection.prepareStatement(
                    "SELECT * FROM trade_history WHERE record_id>? ORDER BY record_id LIMIT 100")) {
              statement.setString(1, cursor);
              try (var rows = statement.executeQuery()) {
                while (rows.next()) page.add(extractRecordFromResultSet(rows));
              }
            }
            if (page.isEmpty()) break;
            for (var record : page) TradeCommitJournal.append(connection, record, true);
            cursor = page.getLast().recordId().toString();
          }
        }
        connection.commit();
      } catch (Exception error) {
        connection.rollback();
        throw error;
      } finally {
        connection.setAutoCommit(true);
      }
    } catch (Exception error) {
      throw new IllegalStateException("Cannot initialize durable trade commit journal", error);
    }
  }

  @Override
  public Optional<UUID> historyAuthorityDomainId() {
    if (!legacyJournal) return Optional.of(commitJournal.domain());
    try (Connection connection = databaseService.getConnection()) {
      return Optional.of(TradeCommitJournal.domain(connection));
    } catch (SQLException error) {
      throw new IllegalStateException("Cannot read trade authority", error);
    }
  }

  @Override
  public List<TradeHistoryChange> committedChangesAfter(long sequence, int limit) {
    if (sequence < 0 || limit < 1 || limit > 100)
      throw new IllegalArgumentException("Trade commit pages require cursor>=0 and limit 1..100");
    if (!legacyJournal)
      return commitJournal.changesAfter(sequence, limit).stream()
          .map(
              change ->
                  new TradeHistoryChange(
                      change.authorityDomainId(),
                      change.sequence(),
                      UUID.nameUUIDFromBytes(
                          ("StarCore.trade.commit:"
                                  + change.authorityDomainId()
                                  + ":"
                                  + change.sequence())
                              .getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                      change.record(),
                      change.committedAt(),
                      false))
          .toList();
    try (Connection connection = databaseService.getConnection()) {
      return TradeCommitJournal.after(connection, sequence, limit);
    } catch (SQLException error) {
      throw new IllegalStateException("Cannot read committed trade history", error);
    }
  }

  private void loadRecordsFromDatabase() {
    String sql = "SELECT * FROM trade_history ORDER BY executed_at DESC LIMIT 10000";

    try (Connection conn = databaseService.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql)) {

      while (rs.next()) {
        TradeRecord record = authoritativeRecord(conn, rs);
        cacheRecord(record);
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to load trade records from database", e);
    }
  }

  @Override
  public synchronized void saveRecord(TradeRecord record) {
    Objects.requireNonNull(record, "record");
    commitJournal.save(List.of(record), this::persistCommittedRecord);
    commitJournal.get(record.recordId()).ifPresent(this::cacheRecord);
  }

  @Override
  public synchronized void updateStatus(
      UUID recordId, TradeRecord.TradeRecordStatus status, String notes) {
    Objects.requireNonNull(recordId, "recordId");
    Objects.requireNonNull(status, "status");
    TradeRecord updated =
        commitJournal.updateStatus(recordId, status, notes, this::persistCommittedRecord);
    cacheRecord(updated);
  }

  @Override
  public synchronized void saveRecords(Collection<TradeRecord> records) {
    Collection<TradeRecord> batch = Objects.requireNonNull(records, "records");
    batch.forEach(record -> Objects.requireNonNull(record, "record"));
    commitJournal.save(batch, this::persistCommittedRecord);
    batch.forEach(record -> commitJournal.get(record.recordId()).ifPresent(this::cacheRecord));
  }

  private synchronized void cacheRecord(TradeRecord record) {
    TradeRecord previous = recordsById.put(record.recordId(), record);
    if (previous != null) {
      removeRecordFromIndexes(previous);
    }

    // 缓存玩家记录
    record
        .buyerPlayerId()
        .ifPresent(
            id -> {
              cacheIndex(playerRecords, id, record.recordId());
            });
    record
        .sellerPlayerId()
        .filter(id -> !record.buyerPlayerId().filter(id::equals).isPresent())
        .ifPresent(id -> cacheIndex(playerRecords, id, record.recordId()));

    // 缓存国家记录
    record
        .buyerNationId()
        .ifPresent(
            id -> {
              cacheIndex(nationRecords, id.toString(), record.recordId());
            });
    record
        .sellerNationId()
        .filter(id -> !record.buyerNationId().filter(id::equals).isPresent())
        .ifPresent(id -> cacheIndex(nationRecords, id.toString(), record.recordId()));

    // 缓存资源记录
    cacheIndex(resourceRecords, normalizeResource(record.resourceId()), record.recordId());
  }

  private void removeRecordFromIndexes(TradeRecord record) {
    record.buyerPlayerId().ifPresent(id -> removeIndex(playerRecords, id, record.recordId()));
    record.sellerPlayerId().ifPresent(id -> removeIndex(playerRecords, id, record.recordId()));
    record
        .buyerNationId()
        .ifPresent(id -> removeIndex(nationRecords, id.toString(), record.recordId()));
    record
        .sellerNationId()
        .ifPresent(id -> removeIndex(nationRecords, id.toString(), record.recordId()));
    removeIndex(resourceRecords, normalizeResource(record.resourceId()), record.recordId());
  }

  private static <K> void cacheIndex(Map<K, List<UUID>> indexes, K key, UUID recordId) {
    List<UUID> ids = indexes.computeIfAbsent(key, ignored -> new CopyOnWriteArrayList<>());
    ids.remove(recordId);
    ids.add(0, recordId);
  }

  private static <K> void removeIndex(Map<K, List<UUID>> indexes, K key, UUID recordId) {
    List<UUID> ids = indexes.get(key);
    if (ids == null) {
      return;
    }
    ids.remove(recordId);
    if (ids.isEmpty()) {
      indexes.remove(key, ids);
    }
  }

  private void persistCommittedRecord(Connection connection, TradeRecord record)
      throws SQLException {
    persistRecord(connection, record);
    if (legacyJournal) TradeCommitJournal.append(connection, record, false);
  }

  private void persistRecord(Connection conn, TradeRecord record) throws SQLException {
    String updateSql =
        "UPDATE trade_history SET order_type = ?, order_source = ?, seller_player_id = ?,"
            + " buyer_player_id = ?, seller_nation_id = ?, buyer_nation_id = ?, resource_id = ?,"
            + " amount = ?, price_per_unit = ?, total_value = ?, tax_amount = ?, net_value = ?,"
            + " executed_at = ?, buy_order_id = ?, sell_order_id = ?, status = ?, notes = ?,"
            + " executed_at_exact = ? WHERE record_id = ?";
    String insertSql =
        "INSERT INTO trade_history (record_id, order_type, order_source, seller_player_id,"
            + " buyer_player_id, seller_nation_id, buyer_nation_id, resource_id, amount,"
            + " price_per_unit, total_value, tax_amount, net_value, executed_at, buy_order_id,"
            + " sell_order_id, status, notes, executed_at_exact) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,"
            + " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (PreparedStatement update = conn.prepareStatement(updateSql)) {
      setUpdateParameters(update, record);
      if (update.executeUpdate() > 0) {
        return;
      }
    }

    try (PreparedStatement insert = conn.prepareStatement(insertSql)) {
      setRecordParameters(insert, record);
      insert.executeUpdate();
    } catch (SQLException insertFailure) {
      try (PreparedStatement update = conn.prepareStatement(updateSql)) {
        setUpdateParameters(update, record);
        if (update.executeUpdate() == 0) {
          throw insertFailure;
        }
      }
    }
  }

  private void setRecordParameters(PreparedStatement pstmt, TradeRecord record)
      throws SQLException {
    pstmt.setString(1, record.recordId().toString());
    pstmt.setString(2, record.orderType().name());
    pstmt.setString(3, record.orderSource().name());
    pstmt.setString(4, record.sellerPlayerId().map(UUID::toString).orElse(null));
    pstmt.setString(5, record.buyerPlayerId().map(UUID::toString).orElse(null));
    pstmt.setString(6, record.sellerNationId().map(Object::toString).orElse(null));
    pstmt.setString(7, record.buyerNationId().map(Object::toString).orElse(null));
    pstmt.setString(8, record.resourceId());
    pstmt.setLong(9, record.amount());
    pstmt.setDouble(10, record.pricePerUnit());
    pstmt.setDouble(11, record.totalValue());
    pstmt.setDouble(12, record.taxAmount());
    pstmt.setDouble(13, record.netValue());
    pstmt.setTimestamp(14, projectionTimestamp(pstmt.getConnection(), record.executedAt()));
    pstmt.setString(15, record.buyOrderId().map(UUID::toString).orElse(null));
    pstmt.setString(16, record.sellOrderId().map(UUID::toString).orElse(null));
    pstmt.setString(17, record.status().name());
    pstmt.setString(18, record.notes().orElse(null));
    pstmt.setString(19, record.executedAt().toString());
  }

  private void setUpdateParameters(PreparedStatement pstmt, TradeRecord record)
      throws SQLException {
    pstmt.setString(1, record.orderType().name());
    pstmt.setString(2, record.orderSource().name());
    pstmt.setString(3, record.sellerPlayerId().map(UUID::toString).orElse(null));
    pstmt.setString(4, record.buyerPlayerId().map(UUID::toString).orElse(null));
    pstmt.setString(5, record.sellerNationId().map(Object::toString).orElse(null));
    pstmt.setString(6, record.buyerNationId().map(Object::toString).orElse(null));
    pstmt.setString(7, record.resourceId());
    pstmt.setLong(8, record.amount());
    pstmt.setDouble(9, record.pricePerUnit());
    pstmt.setDouble(10, record.totalValue());
    pstmt.setDouble(11, record.taxAmount());
    pstmt.setDouble(12, record.netValue());
    pstmt.setTimestamp(13, projectionTimestamp(pstmt.getConnection(), record.executedAt()));
    pstmt.setString(14, record.buyOrderId().map(UUID::toString).orElse(null));
    pstmt.setString(15, record.sellOrderId().map(UUID::toString).orElse(null));
    pstmt.setString(16, record.status().name());
    pstmt.setString(17, record.notes().orElse(null));
    pstmt.setString(18, record.executedAt().toString());
    pstmt.setString(19, record.recordId().toString());
  }

  @Override
  public synchronized Optional<TradeRecord> getRecord(UUID recordId) {
    if (recordId == null) {
      return Optional.empty();
    }
    try (Connection connection = databaseService.getConnection();
        PreparedStatement query =
            connection.prepareStatement("SELECT * FROM trade_history WHERE record_id=?")) {
      commitJournal.domain();
      query.setString(1, recordId.toString());
      try (ResultSet row = query.executeQuery()) {
        if (!row.next()) return Optional.empty();
        TradeRecord record = authoritativeRecord(connection, row);
        cacheRecord(record);
        return Optional.of(record);
      }
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot read trade history record", failure);
    }
  }

  @Override
  public UUID tradeHistoryAuthorityDomainId() {
    return commitJournal.domain();
  }

  @Override
  public void prepareSettlement(TradeSettlementIntent intent) {
    commitJournal.prepare(Objects.requireNonNull(intent, "intent"));
  }

  @Override
  public List<TradeSettlementIntent> settlementIntentsAfter(UUID after, int limit) {
    return commitJournal.intentsAfter(after, limit);
  }

  @Override
  public synchronized Optional<TradeRecord> reconcileSettlement(
      UUID operationId, TransactionRecord transaction) {
    Optional<TradeRecord> record =
        commitJournal.reconcile(
            Objects.requireNonNull(operationId, "operationId"),
            Objects.requireNonNull(transaction, "transaction"),
            this::persistCommittedRecord);
    record.ifPresent(this::cacheRecord);
    return record;
  }

  @Override
  public List<dev.starcore.starcore.module.resource.model.TradeHistoryChange> tradeChangesAfter(
      long sequence, int limit) {
    return commitJournal.changesAfter(sequence, limit);
  }

  @Override
  public List<TradeRecord> getPlayerRecords(UUID playerId) {
    if (playerId == null) {
      return List.of();
    }
    List<UUID> recordIds = playerRecords.get(playerId);
    if (recordIds == null) {
      return List.of();
    }

    return recordIds.stream()
        .map(recordsById::get)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getPlayerRecords(UUID playerId, int offset, int limit) {
    validatePage(offset, limit);
    return getPlayerRecords(playerId).stream()
        .skip(offset)
        .limit(limit)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getNationRecords(NationId nationId) {
    if (nationId == null) {
      return List.of();
    }
    List<UUID> recordIds = nationRecords.get(nationId.toString());
    if (recordIds == null) {
      return List.of();
    }

    return recordIds.stream()
        .map(recordsById::get)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getNationRecords(NationId nationId, int offset, int limit) {
    validatePage(offset, limit);
    return getNationRecords(nationId).stream()
        .skip(offset)
        .limit(limit)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getResourceRecords(String resourceId) {
    String resource = normalizeResource(resourceId);
    if (resource == null) {
      return List.of();
    }
    List<UUID> recordIds = resourceRecords.get(resource);
    if (recordIds == null) {
      return List.of();
    }

    return recordIds.stream()
        .map(recordsById::get)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getResourceRecords(String resourceId, int offset, int limit) {
    validatePage(offset, limit);
    return getResourceRecords(resourceId).stream()
        .skip(offset)
        .limit(limit)
        .collect(Collectors.toList());
  }

  @Override
  public List<TradeRecord> getRecordsByTimeRange(Instant startTime, Instant endTime) {
    if (!isValidRange(startTime, endTime)) {
      return List.of();
    }
    String sql =
        """
        SELECT * FROM trade_history
        WHERE executed_at BETWEEN ? AND ?
        ORDER BY executed_at DESC
        """;

    List<TradeRecord> records = new ArrayList<>();

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setTimestamp(1, Timestamp.from(startTime));
      pstmt.setTimestamp(2, Timestamp.from(endTime));

      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          records.add(authoritativeRecord(conn, rs));
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to get records by time range", e);
    }

    return records;
  }

  @Override
  public List<TradeRecord> getRecordsAfter(Instant executedAt, UUID recordId, int limit) {
    if ((executedAt == null) != (recordId == null) || limit < 1 || limit > 100) {
      throw new IllegalArgumentException(
          "Trade history cursor must be complete and page size must be 1..100");
    }
    String sql =
        executedAt == null
            ? "SELECT * FROM trade_history WHERE status = ? ORDER BY executed_at ASC, record_id ASC"
                + " LIMIT ?"
            : "SELECT * FROM trade_history WHERE status = ? AND (executed_at > ? OR (executed_at ="
                + " ? AND record_id > ?)) ORDER BY executed_at ASC, record_id ASC LIMIT ?";
    List<TradeRecord> records = new ArrayList<>();
    try (Connection conn = databaseService.getConnection();
        PreparedStatement statement = conn.prepareStatement(sql)) {
      int index = 1;
      statement.setString(index++, TradeRecord.TradeRecordStatus.COMPLETED.name());
      if (executedAt != null) {
        Timestamp cursorTime = projectionTimestamp(conn, executedAt);
        statement.setTimestamp(index++, cursorTime);
        statement.setTimestamp(index++, cursorTime);
        statement.setString(index++, recordId.toString());
      }
      statement.setInt(index, limit);
      try (ResultSet result = statement.executeQuery()) {
        while (result.next()) records.add(authoritativeRecord(conn, result));
      }
    } catch (Exception exception) {
      throw new RuntimeException("Failed to page completed trade records", exception);
    }
    return List.copyOf(records);
  }

  @Override
  public List<TradeRecord> getPlayerRecordsByTimeRange(
      UUID playerId, Instant startTime, Instant endTime) {
    if (playerId == null || !isValidRange(startTime, endTime)) {
      return List.of();
    }
    String sql =
        """
        SELECT * FROM trade_history
        WHERE (buyer_player_id = ? OR seller_player_id = ?)
        AND executed_at BETWEEN ? AND ?
        ORDER BY executed_at DESC
        """;

    List<TradeRecord> records = new ArrayList<>();

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setString(1, playerId.toString());
      pstmt.setString(2, playerId.toString());
      pstmt.setTimestamp(3, Timestamp.from(startTime));
      pstmt.setTimestamp(4, Timestamp.from(endTime));

      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          records.add(authoritativeRecord(conn, rs));
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to get player records by time range", e);
    }

    return records;
  }

  @Override
  public double getPlayerTotalTradeValue(UUID playerId) {
    return getPlayerRecords(playerId).stream()
        .mapToDouble(TradeRecord::totalValue)
        .reduce(0.0, SimpleTradeHistoryService::saturatingAdd);
  }

  @Override
  public int getPlayerTradeCount(UUID playerId) {
    List<UUID> ids = playerRecords.get(playerId);
    return ids == null ? 0 : ids.size();
  }

  @Override
  public List<TradeRecord> getNationToNationRecords(NationId nation1, NationId nation2) {
    if (nation1 == null || nation2 == null) {
      return List.of();
    }
    String sql =
        """
        SELECT * FROM trade_history
        WHERE (buyer_nation_id = ? AND seller_nation_id = ?)
        OR (buyer_nation_id = ? AND seller_nation_id = ?)
        ORDER BY executed_at DESC
        """;

    List<TradeRecord> records = new ArrayList<>();

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setString(1, nation1.toString());
      pstmt.setString(2, nation2.toString());
      pstmt.setString(3, nation2.toString());
      pstmt.setString(4, nation1.toString());

      try (ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
          records.add(authoritativeRecord(conn, rs));
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to get nation-to-nation records", e);
    }

    return records;
  }

  @Override
  public synchronized int deleteOldRecords(Instant before) {
    if (before == null) {
      return 0;
    }
    String sql = "DELETE FROM trade_history WHERE executed_at < ?";

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setTimestamp(1, Timestamp.from(before));
      int deleted = pstmt.executeUpdate();
      if (deleted > 0) {
        removeCachedRecordsBefore(before);
      }
      return deleted;
    } catch (Exception e) {
      throw new RuntimeException("Failed to delete old records", e);
    }
  }

  @Override
  public TradeStatistics getStatistics(Instant startTime, Instant endTime) {
    if (!isValidRange(startTime, endTime)) {
      return emptyStatistics();
    }
    String sql =
        """
        SELECT COUNT(*) as count, SUM(amount) as volume, SUM(total_value) as total_value,
               SUM(tax_amount) as total_tax, AVG(price_per_unit) as avg_price,
               MAX(price_per_unit) as max_price, MIN(price_per_unit) as min_price,
               MIN(executed_at) as oldest, MAX(executed_at) as newest
        FROM trade_history
        WHERE executed_at BETWEEN ? AND ?
        """;

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setTimestamp(1, Timestamp.from(startTime));
      pstmt.setTimestamp(2, Timestamp.from(endTime));

      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          return new TradeStatistics(
              rs.getInt("count"),
              rs.getLong("volume"),
              rs.getDouble("total_value"),
              rs.getDouble("total_tax"),
              rs.getDouble("avg_price"),
              rs.getDouble("max_price"),
              rs.getDouble("min_price"),
              rs.getTimestamp("oldest") != null
                  ? rs.getTimestamp("oldest").toInstant()
                  : Instant.now(),
              rs.getTimestamp("newest") != null
                  ? rs.getTimestamp("newest").toInstant()
                  : Instant.now());
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to get trade statistics", e);
    }

    return new TradeStatistics(0, 0, 0, 0, 0, 0, 0, Instant.now(), Instant.now());
  }

  @Override
  public TradeStatistics getPlayerStatistics(UUID playerId, Instant startTime, Instant endTime) {
    if (playerId == null || !isValidRange(startTime, endTime)) {
      return emptyStatistics();
    }
    String sql =
        """
        SELECT COUNT(*) as count, SUM(amount) as volume, SUM(total_value) as total_value,
               SUM(tax_amount) as total_tax, AVG(price_per_unit) as avg_price,
               MAX(price_per_unit) as max_price, MIN(price_per_unit) as min_price,
               MIN(executed_at) as oldest, MAX(executed_at) as newest
        FROM trade_history
        WHERE (buyer_player_id = ? OR seller_player_id = ?)
        AND executed_at BETWEEN ? AND ?
        """;

    try (Connection conn = databaseService.getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setString(1, playerId.toString());
      pstmt.setString(2, playerId.toString());
      pstmt.setTimestamp(3, Timestamp.from(startTime));
      pstmt.setTimestamp(4, Timestamp.from(endTime));

      try (ResultSet rs = pstmt.executeQuery()) {
        if (rs.next()) {
          return new TradeStatistics(
              rs.getInt("count"),
              rs.getLong("volume"),
              rs.getDouble("total_value"),
              rs.getDouble("total_tax"),
              rs.getDouble("avg_price"),
              rs.getDouble("max_price"),
              rs.getDouble("min_price"),
              rs.getTimestamp("oldest") != null
                  ? rs.getTimestamp("oldest").toInstant()
                  : Instant.now(),
              rs.getTimestamp("newest") != null
                  ? rs.getTimestamp("newest").toInstant()
                  : Instant.now());
        }
      }
    } catch (Exception e) {
      throw new RuntimeException("Failed to get player trade statistics", e);
    }

    return emptyStatistics();
  }

  private void removeCachedRecordsBefore(Instant before) {
    for (TradeRecord record : recordsById.values()) {
      if (record.executedAt().isBefore(before) && recordsById.remove(record.recordId(), record)) {
        removeRecordFromIndexes(record);
      }
    }
  }

  private static void validatePage(int offset, int limit) {
    if (offset < 0 || limit < 0) {
      throw new IllegalArgumentException("offset and limit must be non-negative");
    }
  }

  private static String normalizeResource(String resourceId) {
    if (resourceId == null) {
      return null;
    }
    String normalized = resourceId.trim().toLowerCase(Locale.ROOT);
    return normalized.isEmpty() ? null : normalized;
  }

  private static boolean isValidRange(Instant startTime, Instant endTime) {
    return startTime != null && endTime != null && !endTime.isBefore(startTime);
  }

  private static double saturatingAdd(double left, double right) {
    if (right > 0.0 && left > Double.MAX_VALUE - right) {
      return Double.MAX_VALUE;
    }
    if (right < 0.0 && left < -Double.MAX_VALUE - right) {
      return -Double.MAX_VALUE;
    }
    return left + right;
  }

  private static TradeStatistics emptyStatistics() {
    Instant now = Instant.now();
    return new TradeStatistics(0, 0, 0, 0, 0, 0, 0, now, now);
  }

  static TradeRecord extractRecordFromResultSet(ResultSet rs) throws SQLException {
    TradeOrder.OrderType orderType = TradeOrder.OrderType.valueOf(rs.getString("order_type"));

    return new TradeRecord(
        UUID.fromString(rs.getString("record_id")),
        orderType,
        TradeOrder.OrderSource.valueOf(rs.getString("order_source")),
        rs.getString("seller_player_id") != null
            ? UUID.fromString(rs.getString("seller_player_id"))
            : null,
        rs.getString("buyer_player_id") != null
            ? UUID.fromString(rs.getString("buyer_player_id"))
            : null,
        rs.getString("seller_nation_id") != null
            ? NationId.of(UUID.fromString(rs.getString("seller_nation_id")))
            : null,
        rs.getString("buyer_nation_id") != null
            ? NationId.of(UUID.fromString(rs.getString("buyer_nation_id")))
            : null,
        rs.getString("resource_id"),
        rs.getLong("amount"),
        rs.getDouble("price_per_unit"),
        rs.getDouble("tax_amount"),
        rs.getString("executed_at_exact") == null
            ? rs.getTimestamp("executed_at").toInstant()
            : Instant.parse(rs.getString("executed_at_exact")),
        rs.getString("buy_order_id") != null ? UUID.fromString(rs.getString("buy_order_id")) : null,
        rs.getString("sell_order_id") != null
            ? UUID.fromString(rs.getString("sell_order_id"))
            : null,
        TradeRecord.TradeRecordStatus.valueOf(rs.getString("status")),
        rs.getString("notes"));
  }

  /** Compatibility hook. Each mutation is already synchronously durable before it is cached. */
  public synchronized void persistAllRecords() {
    // Never rewrite historical snapshots during periodic save or shutdown.
  }

  private TradeRecord authoritativeRecord(Connection connection, ResultSet row)
      throws SQLException {
    UUID id = UUID.fromString(row.getString("record_id"));
    TradeRecord snapshot =
        (legacyJournal
                ? TradeCommitJournal.latest(connection, id)
                : commitJournal.latest(connection, id))
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "Trade row has no committed journal snapshot: " + id));
    if (row.getString("executed_at_exact") != null
        ? !TradeRecordCodec.encode(extractRecordFromResultSet(row))
            .equals(TradeRecordCodec.encode(snapshot))
        : !TradeCommitJournal.sameProjection(
            extractRecordFromResultSet(row), snapshot, projectionPrecision(connection)))
      throw new IllegalStateException(
          "Trade state and commit journal disagree; restore matching backups: " + id);
    return snapshot;
  }

  private static java.time.temporal.ChronoUnit projectionPrecision(Connection connection) {
    return DatabaseUtils.detectDatabaseType(connection) == DatabaseUtils.DatabaseType.SQLITE
        ? java.time.temporal.ChronoUnit.MILLIS
        : java.time.temporal.ChronoUnit.SECONDS;
  }

  private static Timestamp projectionTimestamp(Connection connection, Instant time) {
    // Explicit truncation avoids MySQL TIMESTAMP(0) rounding a trade into the next cursor bucket.
    // The journal retains the original precise timestamp.
    return Timestamp.from(time.truncatedTo(projectionPrecision(connection)));
  }
}
