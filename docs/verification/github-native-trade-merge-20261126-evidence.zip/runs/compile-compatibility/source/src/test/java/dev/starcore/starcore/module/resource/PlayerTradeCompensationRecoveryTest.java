package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Duration;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class PlayerTradeCompensationRecoveryTest {
  @TempDir Path tempDir;

  @Test
  void compensatedAcceptClosesTheOfferAndFinishesTheFabricRecord() {
    Fixture fixture = fixture(true);

    PlayerTradeService.ActionResult result =
        fixture.trades.acceptTradeResult(fixture.sellerId, fixture.offer.offerId());

    assertThat(result.status()).isEqualTo(PlayerTradeService.ActionStatus.COMPENSATED);
    assertThat(fixture.trades.getOffer(fixture.offer.offerId()).orElseThrow().status())
        .isEqualTo(PlayerTradeService.PlayerTradeOffer.OfferStatus.REJECTED);
    assertThat(fixture.fabric.snapshot())
        .singleElement()
        .extracting(r -> r.state())
        .isEqualTo(EconomyTransactionState.REFUNDED);
    assertThat(readLedger(fixture).snapshot()).isEmpty();
  }

  @Test
  void failedCompensationIsDurableAndRetryCompletesTheSameFabricTransaction() throws Exception {
    Fixture fixture = fixture(false);

    PlayerTradeService.ActionResult result =
        fixture.trades.acceptTradeResult(fixture.sellerId, fixture.offer.offerId());

    UUID transactionId = result.transactionId();
    assertThat(result.status()).isEqualTo(PlayerTradeService.ActionStatus.COMPENSATION_PENDING);
    assertThat(transactionId).isNotNull();
    assertThat(readLedger(fixture).snapshot())
        .singleElement()
        .satisfies(
            refund -> {
              assertThat(refund.transactionId()).isEqualTo(transactionId);
              assertThat(refund.accountId()).isEqualTo(fixture.buyerId);
              assertThat(refund.reason()).isEqualTo("trade:" + fixture.offer.offerId());
            });
    assertThat(fixture.fabric.find(transactionId).orElseThrow().state())
        .isEqualTo(EconomyTransactionState.REFUND_PENDING);

    doReturn(true).when(fixture.economy).deposit(eq(fixture.buyerId), any(BigDecimal.class));
    Thread.sleep(1_100L);
    assertThat(fixture.trades.retryPendingRefunds()).isEqualTo(1);
    assertThat(fixture.fabric.find(transactionId).orElseThrow().state())
        .isEqualTo(EconomyTransactionState.REFUNDED);
    assertThat(readLedger(fixture).snapshot()).isEmpty();
  }

  @Test
  void acceptingAnAlreadyCommittedOfferIsIdempotentForStructuredCallers() {
    Fixture fixture = fixture(true);
    doReturn(true).when(fixture.economy).deposit(eq(fixture.sellerId), any(BigDecimal.class));

    PlayerTradeService.ActionResult first =
        fixture.trades.acceptTradeResult(fixture.sellerId, fixture.offer.offerId());
    PlayerTradeService.ActionResult second =
        fixture.trades.acceptTradeResult(fixture.sellerId, fixture.offer.offerId());

    assertThat(first.status()).isEqualTo(PlayerTradeService.ActionStatus.APPLIED);
    assertThat(second.status()).isEqualTo(PlayerTradeService.ActionStatus.APPLIED);
    assertThat(second.transactionId()).isEqualTo(first.transactionId());
    assertThat(second.record()).isEqualTo(first.record());
  }

  private Fixture fixture(boolean refundSucceeds) {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNationId = NationId.random();
    NationId sellerNationId = NationId.random();
    Nation buyerNation = new Nation(buyerNationId, "BuyerNation", buyerId, "buyer");
    Nation sellerNation = new Nation(sellerNationId, "SellerNation", sellerId, "seller");

    NationService nations = mock(NationService.class);
    when(nations.nationOf(buyerId)).thenReturn(java.util.Optional.of(buyerNation));
    when(nations.nationOf(sellerId)).thenReturn(java.util.Optional.of(sellerNation));

    EconomyService economy = mock(EconomyService.class);
    when(economy.has(any(), any())).thenReturn(true);
    when(economy.withdraw(any(), any())).thenReturn(true);
    when(economy.deposit(eq(sellerId), any(BigDecimal.class))).thenReturn(false);
    when(economy.deposit(eq(buyerId), any(BigDecimal.class))).thenReturn(refundSucceeds);

    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNationId, "iron")).thenReturn(5L);
    when(resources.consume(sellerNationId, "iron", 5L)).thenReturn(true);
    when(resources.grant(buyerNationId, "iron", 5L)).thenReturn(true);

    TradeTaxService taxes = mock(TradeTaxService.class);
    when(taxes.calculateTaxBD(any(), any(), any())).thenReturn(BigDecimal.ZERO);

    Plugin plugin = mock(Plugin.class);
    when(plugin.getDataFolder()).thenReturn(tempDir.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    ServiceRegistry services = new ServiceRegistry();
    TransactionFabric fabric =
        new TransactionFabric(
            tempDir.resolve("transactions.properties"), Logger.getAnonymousLogger());
    services.register(TransactionFabric.class, fabric);

    SimplePlayerTradeService trades =
        new SimplePlayerTradeService(resources, economy, taxes, null, null, services, plugin);
    trades.setNationService(nations);
    trades.setTradeHistoryService(TradeTestStorage.history(tempDir));
    PlayerTradeService.PlayerTradeOffer offer =
        trades
            .createTradeOffer(
                buyerId,
                buyerNationId,
                sellerId,
                sellerNationId,
                "iron",
                5,
                20.0,
                Duration.ofMinutes(5).toSeconds())
            .orElseThrow();

    Path ledgerFile = tempDir.resolve("economy/refund-ledger.properties");
    return new Fixture(trades, economy, fabric, ledgerFile, buyerId, sellerId, offer);
  }

  private RefundLedger readLedger(Fixture fixture) {
    return new RefundLedger(fixture.ledgerFile, Logger.getAnonymousLogger());
  }

  private record Fixture(
      SimplePlayerTradeService trades,
      EconomyService economy,
      TransactionFabric fabric,
      Path ledgerFile,
      UUID buyerId,
      UUID sellerId,
      PlayerTradeService.PlayerTradeOffer offer) {}
}
