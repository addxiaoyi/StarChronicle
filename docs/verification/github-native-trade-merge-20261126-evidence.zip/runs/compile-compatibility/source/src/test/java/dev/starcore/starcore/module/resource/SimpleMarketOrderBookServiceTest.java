package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.TradeTaxService.TaxReceipt;
import dev.starcore.starcore.module.resource.model.MarketOrderBook;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.treasury.TaxationService.TaxQuote;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;

class SimpleMarketOrderBookServiceTest {
  @org.junit.jupiter.api.io.TempDir java.nio.file.Path tempDir;

  @Test
  void rejectsAlreadyExpiredOrdersBeforeEscrowIsFrozen() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = mock(EconomyService.class);
    ResourceService resources = mock(ResourceService.class);
    SimpleMarketOrderBookService orders =
        newOrders(resources, economy, mock(TradeTaxService.class));

    orders.submitBuyOrder(playerId, nationId, "iron", 5, 10.0, Instant.now().minusSeconds(1));
    orders.submitSellOrder(playerId, nationId, "iron", 5, 10.0, Instant.now().minusSeconds(1));

    assertThat(orders.getPlayerOrders(playerId)).isEmpty();
    verify(economy, never()).withdraw(any(), any());
    verify(resources, never()).consume(any(), anyString(), anyLong());
  }

  @Test
  void doesNotMatchOrdersThatExpireAfterSubmission() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNationId = NationId.random();
    NationId sellerNationId = NationId.random();
    EconomyService economy = mock(EconomyService.class);
    when(economy.has(any(), any())).thenReturn(true);
    when(economy.withdraw(any(), any())).thenReturn(true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNationId, "iron")).thenReturn(5L);
    when(resources.consume(sellerNationId, "iron", 5L)).thenReturn(true);
    TradeTaxService taxes = mock(TradeTaxService.class);
    when(taxes.calculateTaxBD(anyString(), any(), any())).thenReturn(BigDecimal.ZERO);
    SimpleMarketOrderBookService orders = newOrders(resources, economy, taxes);

    orders.submitBuyOrder(buyerId, buyerNationId, "iron", 5, 10.0, Instant.now().plusSeconds(300));
    orders.submitSellOrder(
        sellerId, sellerNationId, "iron", 5, 10.0, Instant.now().plusSeconds(300));
    orders.getPlayerOrders(buyerId).getFirst().setExpiryTime(Instant.now().minusSeconds(1));

    assertThat(orders.matchOrders("iron")).isZero();
    verify(resources, never()).grant(any(), anyString(), anyLong());
  }

  @Test
  void rejectsNegativeRecentTradeLimit() {
    SimpleMarketOrderBookService orders =
        newOrders(
            mock(ResourceService.class), mock(EconomyService.class), mock(TradeTaxService.class));

    assertThatThrownBy(() -> orders.getRecentPlayerTrades(UUID.randomUUID(), -1))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("limit must be non-negative");
  }

  @Test
  void cancellingBuyOrderRefundsTheEntireEscrowIncludingFee() {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    TradeTaxService taxes = percentageTax("10.00");
    SimpleMarketOrderBookService orders = newOrders(mock(ResourceService.class), economy, taxes);

    orders.submitBuyOrder(
        buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(300));
    TradeOrder order = orders.getPlayerOrders(buyerId).getFirst();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("45.00");

    assertThat(orders.cancelOrder(buyerId, order.orderId())).isTrue();

    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("100.00");
  }

  @Test
  void matchingAtBetterPriceRefundsUnusedBuyEscrow() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNation = NationId.random();
    NationId sellerNation = NationId.random();
    LedgerEconomy economy =
        new LedgerEconomy(Map.of(buyerId, new BigDecimal("200.00"), sellerId, BigDecimal.ZERO));
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNation, "iron")).thenReturn(5L);
    when(resources.consume(sellerNation, "iron", 5L)).thenReturn(true);
    when(resources.grant(buyerNation, "iron", 5L)).thenReturn(true);
    SimpleMarketOrderBookService orders = newOrders(resources, economy, percentageTax("10.00"));

    orders.submitBuyOrder(buyerId, buyerNation, "iron", 5, 12.0, Instant.now().plusSeconds(300));
    orders.submitSellOrder(sellerId, sellerNation, "iron", 5, 10.0, Instant.now().plusSeconds(300));

    assertThat(orders.matchOrders("iron")).isOne();

    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("145.00");
    assertThat(economy.getBalance(sellerId)).isEqualByComparingTo("50.00");
  }

  @Test
  void partialFillThenCancelRefundsTheExactRemainingEscrow() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNation = NationId.random();
    NationId sellerNation = NationId.random();
    LedgerEconomy economy =
        new LedgerEconomy(Map.of(buyerId, new BigDecimal("200.00"), sellerId, BigDecimal.ZERO));
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNation, "iron")).thenReturn(4L);
    when(resources.consume(sellerNation, "iron", 4L)).thenReturn(true);
    when(resources.grant(buyerNation, "iron", 4L)).thenReturn(true);
    SimpleMarketOrderBookService orders = newOrders(resources, economy, percentageTax("10.00"));

    orders.submitBuyOrder(buyerId, buyerNation, "iron", 10, 12.0, Instant.now().plusSeconds(300));
    TradeOrder buyOrder = orders.getPlayerOrders(buyerId).getFirst();
    orders.submitSellOrder(sellerId, sellerNation, "iron", 4, 10.0, Instant.now().plusSeconds(300));

    assertThat(orders.matchOrders("iron")).isOne();
    assertThat(orders.cancelOrder(buyerId, buyOrder.orderId())).isTrue();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("156.00");
    assertThat(economy.getBalance(sellerId)).isEqualByComparingTo("40.00");
  }

  @Test
  void expiringBuyOrderRefundsEscrow() {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("10.00"));

    orders.submitBuyOrder(
        buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(60));
    orders.getPlayerOrders(buyerId).getFirst().setExpiryTime(Instant.now().minusSeconds(1));

    assertThat(orders.cleanExpiredOrders()).isOne();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("100.00");
  }

  @Test
  void marketOrdersRejectInvalidResourceIdsWithoutThrowing() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.submitMarketBuyOrder(UUID.randomUUID(), NationId.random(), null, 1))
        .isEmpty();
    assertThat(orders.submitMarketSellOrder(UUID.randomUUID(), NationId.random(), "../iron", 1))
        .isEmpty();
  }

  @Test
  void rejectsInvalidResourceIdsBeforeCreatingOrderBooks() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThatThrownBy(() -> orders.getOrderBook(null))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> orders.getOrderBook("../iron"))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> orders.getOrderBook("   "))
        .isInstanceOf(IllegalArgumentException.class);
    assertThat(orders.getAllOrderBooks()).isEmpty();
  }

  @Test
  void normalizesOrderBookResourceIdsConsistently() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.getOrderBook("  Iron ").resourceId()).isEqualTo("iron");
    assertThat(orders.getOrderBook("IRON")).isSameAs(orders.getOrderBook("iron"));
    assertThat(orders.getAllOrderBooks()).hasSize(1);
  }

  @Test
  void readOnlyMarketQueriesDoNotCreateEmptyOrderBooks() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.matchOrders("iron")).isZero();
    assertThat(orders.getCurrentMarketPrice("iron")).isZero();
    assertThat(orders.getBestBid("iron")).isEmpty();
    assertThat(orders.getBestAsk("iron")).isEmpty();
    assertThat(orders.getMidPrice("iron")).isEmpty();
    assertThat(orders.getSpread("iron")).isZero();
    assertThat(orders.getMarketDepth("iron", 0.1)).isZero();
    assertThat(orders.getOrderBookSnapshot("iron").resourceId()).isEqualTo("iron");
    assertThat(orders.getAllOrderBooks()).isEmpty();
  }

  @Test
  void rejectsInvalidMarketMetricsBeforeCreatingOrderBooks() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThatThrownBy(() -> orders.getMarketDepth("iron", Double.NaN))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> orders.getMarketDepth("iron", -0.1))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> orders.updateVolatility("iron", Double.POSITIVE_INFINITY))
        .isInstanceOf(IllegalArgumentException.class);
    assertThat(orders.getAllOrderBooks()).isEmpty();
  }

  @Test
  void nullQueriesFailClosed() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.getOrder(null)).isEmpty();
    assertThat(orders.getPlayerOrders(null)).isEmpty();
    assertThat(orders.getNationOrders(null)).isEmpty();
    assertThat(orders.getPlayerOrdersForResource(null, null)).isEmpty();
    assertThat(orders.getPlayerOrdersForResource(UUID.randomUUID(), "../iron")).isEmpty();
  }

  @Test
  void nullTradeHistoryQueriesFailClosed() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.getPlayerTradeRecords(null)).isEmpty();
    assertThat(orders.getResourceTradeHistory(null)).isEmpty();
    assertThat(orders.getResourceTradeHistory("../iron")).isEmpty();
  }

  @Test
  void invalidMarketOrderIdentityCannotCreateAnOrderBook() {
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), new LedgerEconomy(Map.of()), percentageTax("10.00"));

    assertThat(orders.submitMarketBuyOrder(null, NationId.random(), "iron", 1)).isEmpty();
    assertThat(orders.submitMarketSellOrder(UUID.randomUUID(), null, "iron", 1)).isEmpty();
    assertThat(orders.getAllOrderBooks()).isEmpty();
  }

  @Test
  void marketOrderDelegationConsumesOnlyOneRateLimitSlotPerOrder() {
    UUID playerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(playerId, new BigDecimal("100000.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("0"));

    for (int index = 0; index < 20; index++) {
      orders.submitMarketBuyOrder(playerId, NationId.random(), "iron", 1);
    }
    orders.submitMarketBuyOrder(playerId, NationId.random(), "iron", 1);

    assertThat(orders.getPlayerOrders(playerId)).hasSize(20);
  }

  @Test
  void invalidOrdersDoNotConsumeThePlayersRateLimit() {
    UUID playerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(playerId, new BigDecimal("100000.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("0"));

    for (int index = 0; index < 20; index++) {
      orders.submitBuyOrder(
          playerId, NationId.random(), "../invalid", 1, 1.0, Instant.now().plusSeconds(300));
    }
    orders.submitBuyOrder(
        playerId, NationId.random(), "iron", 1, 1.0, Instant.now().plusSeconds(300));

    assertThat(orders.getPlayerOrders(playerId)).hasSize(1);
  }

  @Test
  void orderlyShutdownReleasesOpenBuyEscrow() {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("10.00"));

    orders.submitBuyOrder(
        buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(300));

    assertThat(orders.refundOpenOrders()).isOne();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("100.00");
    assertThat(orders.getPlayerOrders(buyerId)).isEmpty();
  }

  @Test
  void crossNationMatchChargesAndFundsTariffOnce() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId importer = NationId.random();
    NationId exporter = NationId.random();
    LedgerEconomy economy =
        new LedgerEconomy(Map.of(buyerId, new BigDecimal("200.00"), sellerId, BigDecimal.ZERO));
    ResourceService resources = tradableResources(importer, exporter, true);
    List<TaxQuote> funded = new java.util.ArrayList<>();
    ResourceTariff tariff = fixedTariff(funded, new java.util.ArrayList<>());
    TradeTaxService transactionFees = percentageTax("10.00");
    SimpleMarketOrderBookService orders = newOrders(resources, economy, transactionFees, tariff);

    orders.submitBuyOrder(buyerId, importer, "iron", 5, 10.0, Instant.now().plusSeconds(300));
    orders.submitSellOrder(sellerId, exporter, "iron", 5, 10.0, Instant.now().plusSeconds(300));

    assertThat(orders.matchOrders("iron")).isOne();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("142.00");
    assertThat(economy.getBalance(sellerId)).isEqualByComparingTo("50.00");
    assertThat(funded)
        .singleElement()
        .satisfies(
            quote -> {
              assertThat(quote.type()).isEqualTo(TaxType.TARIFF);
              assertThat(quote.taxAmount()).isEqualByComparingTo("3.00");
            });
    verify(transactionFees).fundTax(any(TaxReceipt.class));
    verify(transactionFees, never()).collectTax(any(), any(Double.class), any());
  }

  @Test
  void failedResourceDeliveryDoesNotFundOrStrandTariff() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId importer = NationId.random();
    NationId exporter = NationId.random();
    LedgerEconomy economy =
        new LedgerEconomy(Map.of(buyerId, new BigDecimal("200.00"), sellerId, BigDecimal.ZERO));
    List<TaxQuote> funded = new java.util.ArrayList<>();
    List<TaxQuote> reversed = new java.util.ArrayList<>();
    TradeTaxService transactionFees = percentageTax("10.00");
    SimpleMarketOrderBookService orders =
        newOrders(
            tradableResources(importer, exporter, false),
            economy,
            transactionFees,
            fixedTariff(funded, reversed));

    orders.submitBuyOrder(buyerId, importer, "iron", 5, 10.0, Instant.now().plusSeconds(300));
    orders.submitSellOrder(sellerId, exporter, "iron", 5, 10.0, Instant.now().plusSeconds(300));

    assertThat(orders.matchOrders("iron")).isZero();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("145.00");
    assertThat(economy.getBalance(sellerId)).isEqualByComparingTo("0.00");
    assertThat(funded).isEmpty();
    assertThat(reversed).isEmpty();
    verify(transactionFees, never())
        .collectTax(any(), any(Double.class), eq(TradeTaxService.TaxType.TRANSACTION_FEE));
  }

  @Test
  void failedTransactionFeeFundingRollsBackTheUncommittedMatch() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNation = NationId.random();
    NationId sellerNation = NationId.random();
    LedgerEconomy economy =
        new LedgerEconomy(Map.of(buyerId, new BigDecimal("200.00"), sellerId, BigDecimal.ZERO));
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNation, "iron")).thenReturn(5L);
    when(resources.consume(sellerNation, "iron", 5L)).thenReturn(true);
    when(resources.grant(buyerNation, "iron", 5L)).thenReturn(true);
    when(resources.consume(buyerNation, "iron", 5L)).thenReturn(true);
    TradeTaxService taxes = percentageTax("10.00");
    when(taxes.fundTax(any(TaxReceipt.class)))
        .thenThrow(new IllegalStateException("treasury unavailable"));
    when(taxes.reverseFundedTax(any(TaxReceipt.class))).thenReturn(BigDecimal.ZERO);
    SimpleMarketOrderBookService orders = newOrders(resources, economy, taxes);

    orders.submitBuyOrder(buyerId, buyerNation, "iron", 5, 10.0, Instant.now().plusSeconds(300));
    orders.submitSellOrder(sellerId, sellerNation, "iron", 5, 10.0, Instant.now().plusSeconds(300));

    assertThatCode(() -> assertThat(orders.matchOrders("iron")).isZero())
        .doesNotThrowAnyException();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("145.00");
    assertThat(economy.getBalance(sellerId)).isZero();
    verify(resources).consume(buyerNation, "iron", 5L);
    verify(taxes).reverseFundedTax(any(TaxReceipt.class));
    assertThat(orders.getPlayerOrders(buyerId))
        .singleElement()
        .extracting(TradeOrder::status)
        .isEqualTo(TradeOrder.OrderStatus.PENDING);
  }

  @Test
  void cancellationSharesTheOrderBookLockWithMatching() throws Exception {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("10.00"));
    orders.submitBuyOrder(
        buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(300));
    TradeOrder order = orders.getPlayerOrders(buyerId).getFirst();
    CountDownLatch started = new CountDownLatch(1);
    CountDownLatch completed = new CountDownLatch(1);
    AtomicBoolean cancelled = new AtomicBoolean();
    Thread cancellation =
        new Thread(
            () -> {
              started.countDown();
              cancelled.set(orders.cancelOrder(buyerId, order.orderId()));
              completed.countDown();
            });

    synchronized (orders.getOrderBook("iron")) {
      cancellation.start();
      assertThat(started.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(completed.await(100, TimeUnit.MILLISECONDS)).isFalse();
      assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("45.00");
    }
    assertThat(completed.await(1, TimeUnit.SECONDS)).isTrue();
    assertThat(cancelled.get()).isTrue();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("100.00");
  }

  @Test
  void cancellationRestoresEscrowWhenTheOrderBookIndexIsAlreadyMissing() {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("10.00"));
    orders.submitBuyOrder(
        buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(300));
    TradeOrder order = orders.getPlayerOrders(buyerId).getFirst();
    assertThat(orders.getOrderBook("iron").removeOrder(order.orderId())).isTrue();

    assertThat(orders.cancelOrder(buyerId, order.orderId())).isFalse();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("45.00");
    assertThat(orders.getOrder(order.orderId())).contains(order);
  }

  @Test
  void buySubmissionSharesTheOrderBookLockWithMatching() throws Exception {
    UUID buyerId = UUID.randomUUID();
    LedgerEconomy economy = new LedgerEconomy(Map.of(buyerId, new BigDecimal("100.00")));
    SimpleMarketOrderBookService orders =
        newOrders(mock(ResourceService.class), economy, percentageTax("0"));
    MarketOrderBook book = orders.getOrderBook("iron");
    CountDownLatch started = new CountDownLatch(1);
    CountDownLatch completed = new CountDownLatch(1);

    Thread submission =
        new Thread(
            () -> {
              started.countDown();
              orders.submitBuyOrder(
                  buyerId, NationId.random(), "iron", 5, 10.0, Instant.now().plusSeconds(300));
              completed.countDown();
            });

    synchronized (book) {
      submission.start();
      assertThat(started.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(completed.await(100, TimeUnit.MILLISECONDS)).isFalse();
      assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("100.00");
      assertThat(orders.getPlayerOrders(buyerId)).isEmpty();
    }

    assertThat(completed.await(1, TimeUnit.SECONDS)).isTrue();
    assertThat(economy.getBalance(buyerId)).isEqualByComparingTo("50.00");
    assertThat(orders.getPlayerOrders(buyerId)).hasSize(1);
  }

  @Test
  void sellSubmissionSharesTheOrderBookLockWithMatching() throws Exception {
    UUID sellerId = UUID.randomUUID();
    NationId sellerNation = NationId.random();
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(sellerNation, "iron")).thenReturn(5L);
    when(resources.consume(sellerNation, "iron", 5L)).thenReturn(true);
    SimpleMarketOrderBookService orders =
        newOrders(resources, new LedgerEconomy(Map.of()), percentageTax("0"));
    MarketOrderBook book = orders.getOrderBook("iron");
    CountDownLatch started = new CountDownLatch(1);
    CountDownLatch completed = new CountDownLatch(1);

    Thread submission =
        new Thread(
            () -> {
              started.countDown();
              orders.submitSellOrder(
                  sellerId, sellerNation, "iron", 5, 10.0, Instant.now().plusSeconds(300));
              completed.countDown();
            });

    synchronized (book) {
      submission.start();
      assertThat(started.await(1, TimeUnit.SECONDS)).isTrue();
      assertThat(completed.await(100, TimeUnit.MILLISECONDS)).isFalse();
      verify(resources, never()).consume(sellerNation, "iron", 5L);
      assertThat(orders.getPlayerOrders(sellerId)).isEmpty();
    }

    assertThat(completed.await(1, TimeUnit.SECONDS)).isTrue();
    verify(resources).consume(sellerNation, "iron", 5L);
    assertThat(orders.getPlayerOrders(sellerId)).hasSize(1);
  }

  private SimpleMarketOrderBookService newOrders(
      ResourceService resources, EconomyService economy, TradeTaxService taxes) {
    return newOrders(resources, economy, taxes, null);
  }

  private SimpleMarketOrderBookService newOrders(
      ResourceService resources,
      EconomyService economy,
      TradeTaxService taxes,
      ResourceTariff tariff) {
    SimpleMarketOrderBookService orders =
        new SimpleMarketOrderBookService(resources, economy, taxes, tariff);
    orders.setTradeHistoryService(TradeTestStorage.history(tempDir));
    orders.setTransactionFabric(TradeTestStorage.fabric(tempDir));
    return orders;
  }

  private ResourceService tradableResources(
      NationId importer, NationId exporter, boolean deliverySucceeds) {
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(exporter, "iron")).thenReturn(5L);
    when(resources.consume(exporter, "iron", 5L)).thenReturn(true);
    when(resources.grant(importer, "iron", 5L)).thenReturn(deliverySucceeds);
    return resources;
  }

  private ResourceTariff fixedTariff(List<TaxQuote> funded, List<TaxQuote> reversed) {
    return new ResourceTariff(
        (transactionId, nationId, type, payerId, amount) ->
            new TaxQuote(transactionId, nationId, type, payerId, amount, new BigDecimal("3.00")),
        quote -> {
          funded.add(quote);
          return quote.taxAmount();
        },
        quote -> {
          reversed.add(quote);
          return quote.taxAmount();
        },
        (playerId, nationId, type, amount, category) -> true);
  }

  private TradeTaxService percentageTax(String percent) {
    TradeTaxService taxes = mock(TradeTaxService.class);
    BigDecimal rate =
        new BigDecimal(percent).divide(new BigDecimal("100"), 10, RoundingMode.HALF_UP);
    when(taxes.calculateTaxBD(
            anyString(), any(BigDecimal.class), eq(TradeTaxService.TaxType.TRANSACTION_FEE)))
        .thenAnswer(
            invocation ->
                ((BigDecimal) invocation.getArgument(1))
                    .multiply(rate)
                    .setScale(2, RoundingMode.HALF_UP));
    when(taxes.fundTax(any(TaxReceipt.class)))
        .thenAnswer(invocation -> ((TaxReceipt) invocation.getArgument(0)).amount());
    return taxes;
  }

  private static final class LedgerEconomy implements EconomyService {
    private final Map<UUID, BigDecimal> balances = new HashMap<>();

    private LedgerEconomy(Map<UUID, BigDecimal> opening) {
      balances.putAll(opening);
    }

    @Override
    public BigDecimal getBalance(UUID playerId) {
      return balances.getOrDefault(playerId, BigDecimal.ZERO);
    }

    @Override
    public boolean has(UUID playerId, BigDecimal amount) {
      return getBalance(playerId).compareTo(amount) >= 0;
    }

    @Override
    public boolean deposit(UUID playerId, BigDecimal amount) {
      if (amount == null || amount.signum() < 0) return false;
      balances.merge(playerId, amount, BigDecimal::add);
      return true;
    }

    @Override
    public boolean withdraw(UUID playerId, BigDecimal amount) {
      if (amount == null || amount.signum() < 0 || !has(playerId, amount)) return false;
      balances.put(playerId, getBalance(playerId).subtract(amount));
      return true;
    }

    @Override
    public boolean setBalance(UUID playerId, BigDecimal amount) {
      balances.put(playerId, amount);
      return true;
    }

    @Override
    public boolean transfer(UUID from, UUID to, BigDecimal amount) {
      return withdraw(from, amount) && deposit(to, amount);
    }

    @Override
    public Map<UUID, BigDecimal> getAllBalances() {
      return Map.copyOf(balances);
    }

    @Override
    public boolean hasAccount(UUID playerId) {
      return balances.containsKey(playerId);
    }

    @Override
    public void createAccount(UUID playerId) {
      balances.putIfAbsent(playerId, BigDecimal.ZERO);
    }
  }
}
