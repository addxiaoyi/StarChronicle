package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

/** Real local storage for service tests that exercise external settlement decisions. */
final class TradeTestStorage {
  private TradeTestStorage() {}

  static DatabaseService database(Path path) {
    return new DatabaseService(null, null) {
      @Override
      public Connection getConnection() {
        try {
          return DriverManager.getConnection("jdbc:sqlite:" + path);
        } catch (SQLException failure) {
          throw new IllegalStateException(failure);
        }
      }
    };
  }

  static SimpleTradeHistoryService history(Path directory) {
    return new SimpleTradeHistoryService(database(directory.resolve("trades.db")), null);
  }

  static TransactionFabric fabric(Path directory) {
    return new TransactionFabric(
        directory.resolve("transactions.properties"), Logger.getAnonymousLogger());
  }

  static ServiceRegistry services(Path directory) {
    ServiceRegistry services = new ServiceRegistry();
    services.register(TransactionFabric.class, fabric(directory));
    return services;
  }
}
