package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.TradeHistoryChange;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import dev.starcore.starcore.module.resource.model.TradeRecord.TradeRecordStatus;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TradeCommitJournalTest {
  @TempDir Path directory;
  private static final Instant TIME = Instant.parse("2026-11-26T12:00:00.123456789Z");

  @Test
  void lateArrivalAndLateCompletionFollowCommitOrder() {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    TradeRecord recent = trade(TIME);
    TradeRecord late = trade(TIME.minusSeconds(86400));
    TradeRecord disputed =
        trade(TIME.minusSeconds(172800)).withStatus(TradeRecordStatus.DISPUTED, "pending review");
    history.saveRecord(recent);
    assertThat(history.tradeChangesAfter(0, 1)).hasSize(1);
    history.saveRecords(List.of(late, disputed));
    history.updateStatus(disputed.recordId(), TradeRecordStatus.COMPLETED, "review resolved");
    List<TradeHistoryChange> changes = history.tradeChangesAfter(1, 128);
    assertThat(changes).extracting(TradeHistoryChange::sequence).containsExactly(2L, 3L, 4L);
    assertThat(changes)
        .extracting(c -> c.record().recordId())
        .containsExactly(late.recordId(), disputed.recordId(), disputed.recordId());
    assertThat(changes.getLast().previousStatus()).isEqualTo(TradeRecordStatus.DISPUTED);
  }

  @Test
  void restartRetainsDomainNanosecondsAndIdempotency() {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    TradeRecord record = trade(TIME);
    history.saveRecord(record);
    UUID domain = history.tradeHistoryAuthorityDomainId();
    String payload = TradeRecordCodec.encode(history.tradeChangesAfter(0, 1).getFirst().record());
    SimpleTradeHistoryService restarted = new SimpleTradeHistoryService(db, null);
    restarted.saveRecords(List.of(record, record));
    assertThat(restarted.tradeHistoryAuthorityDomainId()).isEqualTo(domain);
    assertThat(restarted.getRecord(record.recordId()).orElseThrow().executedAt()).isEqualTo(TIME);
    assertThat(
            restarted
                .getPlayerRecords(record.buyerPlayerId().orElseThrow())
                .getFirst()
                .executedAt())
        .isEqualTo(TIME);
    assertThat(restarted.tradeChangesAfter(0, 128)).hasSize(1);
    assertThat(TradeRecordCodec.encode(restarted.tradeChangesAfter(0, 1).getFirst().record()))
        .isEqualTo(payload);
  }

  @Test
  void staleSaveCannotOverwriteRefundOrChangeTradeIdentity() {
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(database(), null);
    TradeRecord record = trade(TIME);
    history.saveRecord(record);
    history.updateStatus(record.recordId(), TradeRecordStatus.REFUNDED, "refund confirmed");
    assertThatThrownBy(() -> history.saveRecord(record))
        .isInstanceOf(IllegalArgumentException.class);
    TradeRecord different =
        new TradeRecord(
            record.recordId(),
            record.orderType(),
            record.orderSource(),
            UUID.randomUUID(),
            record.buyerPlayerId().orElseThrow(),
            null,
            null,
            "iron",
            100,
            8,
            0,
            TIME,
            null,
            null,
            "changed");
    assertThatThrownBy(() -> history.saveRecord(different))
        .isInstanceOf(IllegalArgumentException.class);
    assertThat(history.getRecord(record.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecordStatus.REFUNDED);
    assertThat(history.tradeChangesAfter(0, 128)).hasSize(2);
  }

  @Test
  void journalFailureRollsBackBatchViewIdentityAndSequence() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    execute(
        db,
        "CREATE TRIGGER fail_trade_commit BEFORE INSERT ON trade_history_commits WHEN"
            + " NEW.sequence_id = 2 BEGIN SELECT RAISE(ABORT, 'injected commit failure'); END");
    TradeRecord first = trade(TIME);
    TradeRecord second = trade(TIME.plusSeconds(1));
    assertThatThrownBy(() -> history.saveRecords(List.of(first, second)))
        .isInstanceOf(IllegalStateException.class);
    assertThat(history.getRecord(first.recordId())).isEmpty();
    assertThat(history.getRecord(second.recordId())).isEmpty();
    assertThat(history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(history.getPlayerRecords(first.buyerPlayerId().orElseThrow())).isEmpty();
    execute(db, "DROP TRIGGER fail_trade_commit");
    history.saveRecord(second);
    assertThat(history.tradeChangesAfter(0, 128))
        .singleElement()
        .extracting(TradeHistoryChange::sequence)
        .isEqualTo(1L);
  }

  @Test
  void viewFailureAlsoRollsBackAndStatusAmendmentIsAtomic() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    TradeRecord record = trade(TIME);
    history.saveRecord(record);
    execute(
        db,
        "CREATE TRIGGER fail_trade_view BEFORE UPDATE ON trade_history BEGIN SELECT RAISE(ABORT,"
            + " 'injected view failure'); END");
    assertThatThrownBy(
            () -> history.updateStatus(record.recordId(), TradeRecordStatus.REFUNDED, "refund"))
        .isInstanceOf(IllegalStateException.class);
    assertThat(history.getRecord(record.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecordStatus.COMPLETED);
    assertThat(history.tradeChangesAfter(1, 128)).isEmpty();
    execute(db, "DROP TRIGGER fail_trade_view");
    history.updateStatus(record.recordId(), TradeRecordStatus.REFUNDED, "refund");
    assertThat(history.tradeChangesAfter(1, 1).getFirst().previousStatus())
        .isEqualTo(TradeRecordStatus.COMPLETED);
  }

  @Test
  void cleanupKeepsAuditAndDoesNotResurrectDeletedViewFromCache() {
    DatabaseService db = database();
    SimpleTradeHistoryService first = new SimpleTradeHistoryService(db, null);
    TradeRecord record = trade(TIME);
    first.saveRecord(record);
    SimpleTradeHistoryService second = new SimpleTradeHistoryService(db, null);
    assertThat(first.deleteOldRecords(TIME.plusSeconds(1))).isEqualTo(1);
    second.persistAllRecords();
    second.saveRecord(record);
    assertThat(second.getRecord(record.recordId())).isEmpty();
    assertThat(second.tradeChangesAfter(0, 128)).hasSize(1);
    second.updateStatus(record.recordId(), TradeRecordStatus.DISPUTED, "post-retention review");
    assertThat(first.getRecord(record.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecordStatus.DISPUTED);
    first.persistAllRecords();
    assertThat(first.tradeChangesAfter(0, 128)).hasSize(2);
  }

  @Test
  void upgradePreservesLegacyBaselineWithoutInventingCommits() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService old = new SimpleTradeHistoryService(db, null);
    TradeRecord record = trade(TIME);
    old.saveRecord(record);
    execute(db, "DROP TABLE trade_history_commits");
    execute(db, "DROP TABLE trade_history_identity");
    execute(db, "DROP TABLE trade_history_authority");
    execute(db, "UPDATE trade_history SET executed_at_exact = NULL");
    SimpleTradeHistoryService upgraded = new SimpleTradeHistoryService(db, null);
    assertThat(upgraded.tradeChangesAfter(0, 128)).isEmpty();
    upgraded.saveRecord(upgraded.getRecord(record.recordId()).orElseThrow());
    upgraded.persistAllRecords();
    assertThat(upgraded.tradeChangesAfter(0, 128)).isEmpty();
    upgraded.updateStatus(record.recordId(), TradeRecordStatus.REFUNDED, "legacy refund");
    assertThat(upgraded.tradeChangesAfter(0, 128))
        .singleElement()
        .satisfies(
            c -> {
              assertThat(c.sequence()).isEqualTo(1L);
              assertThat(c.previousStatus()).isEqualTo(TradeRecordStatus.COMPLETED);
              assertThat(c.record().executedAt())
                  .isEqualTo(Instant.ofEpochMilli(TIME.toEpochMilli()));
            });
  }

  @Test
  void changesAreBoundedAndGapsOrDomainReplacementFailClosed() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    List<TradeRecord> records = new ArrayList<>();
    for (int i = 0; i < 260; i++) records.add(trade(TIME.minusSeconds(i)));
    history.saveRecords(records);
    assertThat(history.tradeChangesAfter(0, 128)).hasSize(128);
    assertThat(history.tradeChangesAfter(128, 128)).hasSize(128);
    assertThat(history.tradeChangesAfter(256, 128)).hasSize(4);
    assertThatThrownBy(() -> history.tradeChangesAfter(0, 129))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> history.tradeChangesAfter(-1, 10))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> history.tradeChangesAfter(261, 10))
        .isInstanceOf(IllegalArgumentException.class);
    execute(db, "DELETE FROM trade_history_commits WHERE sequence_id = 259");
    assertThatThrownBy(() -> history.tradeChangesAfter(256, 128))
        .isInstanceOf(IllegalStateException.class);
    execute(db, "UPDATE trade_history_authority SET domain_id = '" + UUID.randomUUID() + "'");
    assertThatThrownBy(history::tradeHistoryAuthorityDomainId)
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> history.saveRecord(trade(TIME)))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void missingTailOrAuthorityCannotBeSilentlyReinitialized() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    history.saveRecord(trade(TIME));
    execute(db, "DELETE FROM trade_history_commits");
    assertThatThrownBy(() -> history.tradeChangesAfter(0, 128))
        .isInstanceOf(IllegalStateException.class);
    assertThatThrownBy(() -> new SimpleTradeHistoryService(db, null))
        .isInstanceOf(IllegalStateException.class);
    execute(db, "DELETE FROM trade_history_authority");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(db, null))
        .isInstanceOf(IllegalStateException.class);
  }

  @Test
  void twoInstancesAllocateContinuousSequencesWithoutLostUpdates() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService left = new SimpleTradeHistoryService(db, null);
    SimpleTradeHistoryService right = new SimpleTradeHistoryService(db, null);
    CountDownLatch start = new CountDownLatch(1);
    try (var executor = Executors.newFixedThreadPool(2)) {
      var one =
          executor.submit(
              () -> {
                start.await();
                for (int i = 0; i < 80; i++) left.saveRecord(trade(TIME));
                return null;
              });
      var two =
          executor.submit(
              () -> {
                start.await();
                for (int i = 0; i < 80; i++) right.saveRecord(trade(TIME));
                return null;
              });
      start.countDown();
      one.get(30, TimeUnit.SECONDS);
      two.get(30, TimeUnit.SECONDS);
    }
    assertThat(left.tradeChangesAfter(0, 128)).hasSize(128);
    assertThat(right.tradeChangesAfter(128, 128)).hasSize(32);
    assertThat(right.tradeChangesAfter(160, 128)).isEmpty();
  }

  @Test
  void olderThanTenThousandCachedRecordsCanStillBeAmended() throws Exception {
    DatabaseService db = database();
    SimpleTradeHistoryService history = new SimpleTradeHistoryService(db, null);
    TradeRecord oldest = trade(TIME.minusSeconds(86400));
    history.saveRecord(oldest);
    // Populate a legacy database without retaining 10,000 TradeRecord objects in the test.
    try (Connection connection = db.getConnection();
        var insert =
            connection.prepareStatement(
                """
INSERT INTO trade_history SELECT ?, order_type, order_source, seller_player_id,
  buyer_player_id, seller_nation_id, buyer_nation_id, resource_id, amount,
  price_per_unit, total_value, tax_amount, net_value, ?, buy_order_id, sell_order_id,
          status, notes, created_at, NULL FROM trade_history WHERE record_id = ?
""")) {
      connection.setAutoCommit(false);
      for (int i = 0; i < 10001; i++) {
        insert.setString(1, UUID.randomUUID().toString());
        insert.setTimestamp(2, java.sql.Timestamp.from(TIME.plusSeconds(i)));
        insert.setString(3, oldest.recordId().toString());
        insert.executeUpdate();
      }
      connection.commit();
    }
    execute(db, "DROP TABLE trade_history_commits");
    execute(db, "DROP TABLE trade_history_identity");
    execute(db, "DROP TABLE trade_history_authority");
    SimpleTradeHistoryService restarted = new SimpleTradeHistoryService(db, null);
    restarted.updateStatus(oldest.recordId(), TradeRecordStatus.REFUNDED, "old refund");
    assertThat(restarted.tradeChangesAfter(0, 128)).hasSize(1);
    assertThat(restarted.getRecord(oldest.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecordStatus.REFUNDED);
  }

  private DatabaseService database() {
    return new DatabaseService(null, null) {
      @Override
      public Connection getConnection() {
        try {
          Connection connection =
              DriverManager.getConnection("jdbc:sqlite:" + directory.resolve("history.db"));
          try (var statement = connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout = 10000");
          }
          return connection;
        } catch (SQLException failure) {
          throw new IllegalStateException(failure);
        }
      }
    };
  }

  private static void execute(DatabaseService db, String sql) throws SQLException {
    try (Connection connection = db.getConnection();
        var statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  static TradeRecord trade(Instant time) {
    return new TradeRecord(
        UUID.randomUUID(),
        TradeOrder.OrderType.BUY,
        TradeOrder.OrderSource.PLAYER,
        UUID.randomUUID(),
        UUID.randomUUID(),
        NationId.random(),
        NationId.random(),
        "iron",
        5,
        20.25,
        1.01,
        time,
        null,
        null,
        "native trade");
  }
}
