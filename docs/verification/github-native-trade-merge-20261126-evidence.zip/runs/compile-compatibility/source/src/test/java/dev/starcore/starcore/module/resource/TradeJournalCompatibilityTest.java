package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.foundation.economy.transaction.*;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TradeJournalCompatibilityTest {
  @TempDir Path directory;
  private final Instant time = Instant.parse("2026-11-24T01:02:03.123456789Z");

  private DatabaseService database(boolean legacy) throws Exception {
    DatabaseService db = TradeTestStorage.database(directory.resolve("history.db"));
    if (legacy)
      execute(
          db,
          "CREATE TABLE trade_commit_authority(id INTEGER PRIMARY KEY,domain VARCHAR(36) NOT"
              + " NULL,sequence BIGINT NOT NULL)");
    return db;
  }

  @Test
  void nativeJournalCompatibilityPageIsStableAcrossRestartAndRefund() throws Exception {
    DatabaseService db = database(false);
    var history = new SimpleTradeHistoryService(db, null);
    TradeRecord trade = TradeCommitJournalTest.trade(time);
    history.saveRecord(trade);
    var original = history.committedChangesAfter(0, 100).getFirst();
    assertThat(history.historyAuthorityDomainId())
        .contains(history.tradeHistoryAuthorityDomainId());
    assertThat(original.trade().executedAt()).isEqualTo(time);
    history.updateStatus(trade.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "refund");
    var restarted = new SimpleTradeHistoryService(db, null);
    assertThat(restarted.committedChangesAfter(0, 100).getFirst())
        .usingRecursiveComparison()
        .isEqualTo(original);
    assertThat(restarted.committedChangesAfter(1, 100))
        .singleElement()
        .satisfies(
            change -> {
              assertThat(change.operationId()).isNotEqualTo(original.operationId());
              assertThat(change.trade().status()).isEqualTo(TradeRecord.TradeRecordStatus.REFUNDED);
            });
    assertThatThrownBy(() -> history.committedChangesAfter(0, 101))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void upgradingLegacyReceiptsDoesNotRewriteOriginalBytesOrInventNewCommits() throws Exception {
    DatabaseService db = database(true);
    var history = new SimpleTradeHistoryService(db, null);
    TradeRecord trade = TradeCommitJournalTest.trade(time);
    history.saveRecord(trade);
    var old = history.committedChangesAfter(0, 100);
    var raw = rows(db, "SELECT * FROM trade_commit_log ORDER BY sequence");
    dropSettlement(db);
    var upgraded = new SimpleTradeHistoryService(db, null);
    assertThat(upgraded.committedChangesAfter(0, 100)).usingRecursiveComparison().isEqualTo(old);
    assertThat(rows(db, "SELECT * FROM trade_commit_log ORDER BY sequence")).isEqualTo(raw);
    assertThat(upgraded.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(upgraded.getRecord(trade.recordId()).orElseThrow().executedAt()).isEqualTo(time);
    upgraded.updateStatus(trade.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "late");
    assertThat(upgraded.committedChangesAfter(1, 100)).hasSize(1);
    assertThat(upgraded.tradeChangesAfter(0, 128)).hasSize(1);
    assertThat(rows(db, "SELECT * FROM trade_commit_log WHERE sequence=1")).isEqualTo(raw);
  }

  @Test
  void legacyPrunedIdentitySurvivesUpgradeAndCannotBeRebound() throws Exception {
    DatabaseService db = database(true);
    var history = new SimpleTradeHistoryService(db, null);
    TradeRecord trade = TradeCommitJournalTest.trade(time);
    history.saveRecord(trade);
    history.deleteOldRecords(time.plusSeconds(1));
    dropSettlement(db);
    var upgraded = new SimpleTradeHistoryService(db, null);
    assertThat(upgraded.getRecord(trade.recordId())).isEmpty();
    assertThat(upgraded.committedChangesAfter(0, 100)).hasSize(1);
    assertThatThrownBy(
            () ->
                upgraded.prepareSettlement(
                    new dev.starcore.starcore.module.resource.model.TradeSettlementIntent(
                        UUID.randomUUID(), UUID.randomUUID(), BigDecimal.ONE, "rebind", trade, 0)))
        .isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  void preparedLegacySettlementRollsBothJournalsBackAndRepairsOnce() throws Exception {
    DatabaseService db = database(true);
    var history = new SimpleTradeHistoryService(db, null);
    var fabric = TradeTestStorage.fabric(directory);
    var coordinator = new TradeSettlementCoordinator(history, fabric, Logger.getAnonymousLogger());
    TradeRecord trade = TradeCommitJournalTest.trade(time);
    UUID operation = UUID.randomUUID();
    var tx = coordinator.prepare(operation, UUID.randomUUID(), BigDecimal.TEN, "settle", trade);
    tx = coordinator.debited(tx, "assets debited");
    execute(
        db,
        "CREATE TRIGGER fail_legacy BEFORE INSERT ON trade_commit_log BEGIN SELECT"
            + " RAISE(ABORT,'legacy failure'); END");
    coordinator.commit(tx);
    assertThat(history.tradeChangesAfter(0, 128)).isEmpty();
    assertThat(history.committedChangesAfter(0, 100)).isEmpty();
    assertThat(history.getRecord(trade.recordId())).isEmpty();
    assertThat(history.settlementIntentsAfter(null, 128).getFirst().appliedEvents()).isZero();
    execute(db, "DROP TRIGGER fail_legacy");
    var restarted = new SimpleTradeHistoryService(db, null);
    var recovery =
        new TradeSettlementCoordinator(
            restarted, TradeTestStorage.fabric(directory), Logger.getAnonymousLogger());
    assertThat(recovery.reconcileNextPage().applied()).isEqualTo(1);
    assertThat(recovery.reconcileNextPage().applied()).isZero();
    assertThat(restarted.committedChangesAfter(0, 100)).hasSize(1);
    assertThat(restarted.tradeChangesAfter(0, 128)).hasSize(1);
    assertThatThrownBy(
            () -> restarted.saveRecord(restarted.getRecord(trade.recordId()).orElseThrow()))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("durable transaction");
  }

  @Test
  void incompatibleExistingAuthoritiesRemainUntouched() throws Exception {
    DatabaseService db = database(true);
    var history = new SimpleTradeHistoryService(db, null);
    history.saveRecord(TradeCommitJournalTest.trade(time));
    var old = rows(db, "SELECT * FROM trade_commit_log ORDER BY sequence");
    execute(db, "UPDATE trade_history_authority SET domain_id='" + UUID.randomUUID() + "'");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(db, null))
        .hasStackTraceContaining("domains disagree");
    assertThat(rows(db, "SELECT * FROM trade_commit_log ORDER BY sequence")).isEqualTo(old);
  }

  @Test
  void legacyWriterThatBypassesSettlementJournalIsDetectedOnRestart() throws Exception {
    DatabaseService db = database(true);
    var history = new SimpleTradeHistoryService(db, null);
    TradeRecord trade = TradeCommitJournalTest.trade(time);
    history.saveRecord(trade);
    try (Connection connection = db.getConnection()) {
      connection.setAutoCommit(false);
      TradeCommitJournal.append(
          connection,
          trade.withStatus(TradeRecord.TradeRecordStatus.REFUNDED, "old writer"),
          false);
      connection.commit();
    }
    assertThatThrownBy(() -> new SimpleTradeHistoryService(db, null))
        .hasStackTraceContaining("journals disagree");
  }

  private static void dropSettlement(DatabaseService db) throws SQLException {
    for (String table :
        List.of(
            "trade_history_identity",
            "trade_history_commits",
            "trade_history_authority",
            "trade_settlement_intents")) execute(db, "DROP TABLE " + table);
  }

  private static void execute(DatabaseService db, String sql) throws SQLException {
    try (Connection connection = db.getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(sql);
    }
  }

  private static List<List<Object>> rows(DatabaseService db, String sql) throws SQLException {
    List<List<Object>> values = new ArrayList<>();
    try (Connection connection = db.getConnection();
        Statement statement = connection.createStatement();
        ResultSet rows = statement.executeQuery(sql)) {
      while (rows.next()) {
        List<Object> row = new ArrayList<>();
        for (int i = 1; i <= rows.getMetaData().getColumnCount(); i++) row.add(rows.getObject(i));
        values.add(row);
      }
    }
    return values;
  }
}
