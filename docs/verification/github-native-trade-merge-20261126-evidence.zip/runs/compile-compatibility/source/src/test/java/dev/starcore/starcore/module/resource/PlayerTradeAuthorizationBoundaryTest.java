package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;

class PlayerTradeAuthorizationBoundaryTest {
  @org.junit.jupiter.api.io.TempDir java.nio.file.Path tempDir;

  @Test
  void onlyTargetMayAcceptOrRejectAndOnlyInitiatorMayCancel() {
    Fixture fixture = fixture();
    UUID attacker = UUID.randomUUID();

    assertTrue(fixture.trades.acceptTrade(attacker, fixture.offer.offerId()).isEmpty());
    assertEquals(
        PlayerTradeService.ActionStatus.UNAUTHORIZED,
        fixture.trades.acceptTradeResult(attacker, fixture.offer.offerId()).status());
    assertFalse(fixture.trades.rejectTrade(attacker, fixture.offer.offerId()));
    assertFalse(fixture.trades.cancelOffer(fixture.sellerId, fixture.offer.offerId()));
    verify(fixture.economy, never()).withdraw(any(), any());

    assertTrue(fixture.trades.cancelOffer(fixture.buyerId, fixture.offer.offerId()));
    assertFalse(fixture.trades.cancelOffer(fixture.buyerId, fixture.offer.offerId()));
    assertTrue(fixture.trades.acceptTrade(fixture.sellerId, fixture.offer.offerId()).isEmpty());
  }

  @Test
  void concurrentAcceptSettlesOfferExactlyOnce() throws Exception {
    Fixture fixture = fixture();
    CountDownLatch start = new CountDownLatch(1);
    ExecutorService executor = Executors.newFixedThreadPool(2);
    try {
      Future<Boolean> first =
          executor.submit(
              () -> {
                start.await();
                return fixture
                    .trades
                    .acceptTrade(fixture.sellerId, fixture.offer.offerId())
                    .isPresent();
              });
      Future<Boolean> second =
          executor.submit(
              () -> {
                start.await();
                return fixture
                    .trades
                    .acceptTrade(fixture.sellerId, fixture.offer.offerId())
                    .isPresent();
              });

      start.countDown();
      int successes = (first.get() ? 1 : 0) + (second.get() ? 1 : 0);

      assertEquals(1, successes);
      verify(fixture.economy, times(1)).withdraw(any(), any(BigDecimal.class));
      verify(fixture.economy, times(1)).deposit(any(), any(BigDecimal.class));
      assertEquals(1, fixture.fabric.snapshot().size());
      assertEquals(EconomyTransactionState.COMMITTED, fixture.fabric.snapshot().get(0).state());
      assertEquals(1, fixture.fabric.snapshot().size());
      assertEquals(EconomyTransactionState.COMMITTED, fixture.fabric.snapshot().get(0).state());
    } finally {
      executor.shutdownNow();
    }
  }

  @Test
  void structuredAcceptResultCarriesCommittedRecordAndFabricTransactionId() {
    Fixture fixture = fixture();

    PlayerTradeService.ActionResult result =
        fixture.trades.acceptTradeResult(fixture.sellerId, fixture.offer.offerId());

    assertEquals(PlayerTradeService.ActionStatus.APPLIED, result.status());
    assertTrue(result.record() != null);
    assertTrue(result.transactionId() != null);
    assertEquals(EconomyTransactionState.COMMITTED, fixture.fabric.snapshot().get(0).state());
  }

  private Fixture fixture() {
    UUID buyerId = UUID.randomUUID();
    UUID sellerId = UUID.randomUUID();
    NationId buyerNationId = NationId.random();
    NationId sellerNationId = NationId.random();
    Nation buyerNation = new Nation(buyerNationId, "BuyerNation", buyerId, "buyer");
    Nation sellerNation = new Nation(sellerNationId, "SellerNation", sellerId, "seller");
    NationService nationService = mock(NationService.class);
    when(nationService.nationOf(buyerId)).thenReturn(java.util.Optional.of(buyerNation));
    when(nationService.nationOf(sellerId)).thenReturn(java.util.Optional.of(sellerNation));

    EconomyService economy = mock(EconomyService.class);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = mock(TradeTaxService.class);
    when(economy.has(any(), any())).thenReturn(true);
    when(economy.withdraw(any(), any())).thenReturn(true);
    when(economy.deposit(any(), any())).thenReturn(true);
    when(resources.amount(sellerNationId, "iron")).thenReturn(5L);
    when(resources.consume(sellerNationId, "iron", 5L)).thenReturn(true);
    when(resources.grant(buyerNationId, "iron", 5L)).thenReturn(true);
    when(taxes.calculateTaxBD(any(), any(), any())).thenReturn(BigDecimal.ZERO);

    ServiceRegistry services = new ServiceRegistry();
    TransactionFabric fabric =
        new TransactionFabric(
            java.nio.file.Path.of("target", "trade-fabric-" + UUID.randomUUID() + ".properties"),
            Logger.getAnonymousLogger());
    services.register(TransactionFabric.class, fabric);
    SimplePlayerTradeService trades =
        new SimplePlayerTradeService(resources, economy, taxes, null, null, services, null);
    trades.setNationService(nationService);
    trades.setTradeHistoryService(TradeTestStorage.history(tempDir));
    PlayerTradeService.PlayerTradeOffer offer =
        trades
            .createTradeOffer(
                buyerId,
                buyerNationId,
                sellerId,
                sellerNationId,
                "iron",
                5,
                20.0,
                Duration.ofMinutes(5).toSeconds())
            .orElseThrow();

    return new Fixture(trades, economy, fabric, buyerId, sellerId, offer);
  }

  private record Fixture(
      SimplePlayerTradeService trades,
      EconomyService economy,
      TransactionFabric fabric,
      UUID buyerId,
      UUID sellerId,
      PlayerTradeService.PlayerTradeOffer offer) {}
}
