package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.TradeTaxService.TaxReceipt;
import dev.starcore.starcore.module.resource.model.NationalReserve;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class SimplePlayerQuickTradeTaxTest {
  @TempDir Path tempDir;

  @Test
  void quickBuyMirrorsCompletedTradeInTransactionFabric() throws Exception {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    ServiceRegistry services = new ServiceRegistry();
    TransactionFabric fabric =
        new TransactionFabric(
            tempDir.resolve("trade-transactions.properties"), Logger.getAnonymousLogger());
    services.register(TransactionFabric.class, fabric);
    SimplePlayerTradeService trades =
        new SimplePlayerTradeService(resources, economy, taxes, null, reserve, services, null);
    NationService nations = mock(NationService.class);
    when(nations.nationOf(playerId))
        .thenReturn(java.util.Optional.of(new Nation(nationId, "TradeNation", playerId, "player")));
    trades.setNationService(nations);
    trades.setTradeHistoryService(TradeTestStorage.history(tempDir));

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isPresent();

    assertThat(fabric.snapshot())
        .singleElement()
        .satisfies(
            record -> {
              assertThat(record.owner())
                  .isEqualTo(
                      dev.starcore.starcore.foundation.economy.transaction.RefundOwner.TRADE);
              assertThat(record.type()).isEqualTo(TransactionType.TRADE);
              assertThat(record.state()).isEqualTo(EconomyTransactionState.COMMITTED);
            });
  }

  @Test
  void quickBuyFundsTransactionScopedFeeAfterDelivery() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isPresent();

    verify(taxes).fundTax(any(TaxReceipt.class));
    verify(taxes, never()).collectTax(any(), any(Double.class), any());
    assertThat(reserve.getReserve("iron")).isZero();
  }

  @Test
  void quickBuyDeliveryFailureRestoresReserveAndDoesNotFundFee() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.grant(nationId, "iron", 5)).thenReturn(false);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isEmpty();

    verify(taxes, never()).fundTax(any());
    assertThat(reserve.getReserve("iron")).isEqualTo(5);
    verify(economy).deposit(playerId, new BigDecimal("510.00"));
  }

  @Test
  void quickBuyTaxFundingFailureRestoresPaymentAndResources() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    when(resources.consume(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    when(taxes.fundTax(any())).thenThrow(new IllegalStateException("tax unavailable"));
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isEmpty();

    verify(taxes).reverseFundedTax(any(TaxReceipt.class));
    verify(resources).consume(nationId, "iron", 5);
    verify(economy).deposit(playerId, new BigDecimal("510.00"));
    assertThat(reserve.getReserve("iron")).isEqualTo(5);
  }

  @Test
  void quickSellFundsTransactionScopedFeeOnlyAfterPayment() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(nationId, "iron")).thenReturn(5L);
    when(resources.consume(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(
            resources, economy, taxes, new NationalReserve(NationId.random()), playerId, nationId);

    assertThat(trades.quickSell(playerId, nationId, "iron", 5)).isPresent();

    verify(taxes).fundTax(any(TaxReceipt.class));
    verify(taxes, never()).collectTax(any(), any(Double.class), any());
  }

  @Test
  void quickSellPaymentFailureReturnsResourceAndDoesNotFundFee() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, false);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(nationId, "iron")).thenReturn(5L);
    when(resources.consume(nationId, "iron", 5)).thenReturn(true);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(
            resources, economy, taxes, new NationalReserve(NationId.random()), playerId, nationId);

    assertThat(trades.quickSell(playerId, nationId, "iron", 5)).isEmpty();

    verify(resources).grant(nationId, "iron", 5);
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickSellTaxFundingFailureReversesPaymentAndRestoresResources() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(nationId, "iron")).thenReturn(5L);
    when(resources.consume(nationId, "iron", 5)).thenReturn(true);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    when(taxes.fundTax(any())).thenThrow(new IllegalStateException("tax unavailable"));
    SimplePlayerTradeService trades =
        service(
            resources, economy, taxes, new NationalReserve(NationId.random()), playerId, nationId);

    assertThat(trades.quickSell(playerId, nationId, "iron", 5)).isEmpty();

    verify(taxes).reverseFundedTax(any(TaxReceipt.class));
    verify(economy).withdraw(playerId, new BigDecimal("490.00"));
    verify(resources).grant(nationId, "iron", 5);
  }

  @Test
  void quickTradesRejectNonPositiveAmountsBeforeAnySettlement() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = taxes();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 0)).isEmpty();
    assertThat(trades.quickSell(playerId, nationId, "iron", 0)).isEmpty();

    verify(economy, never()).withdraw(any(), any());
    verify(economy, never()).deposit(any(), any());
    verify(resources, never()).consume(any(), anyString(), anyLong());
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickTradesRejectInvalidResourceTermsBeforeAnySettlement() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = taxes();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);

    assertThat(trades.quickBuy(playerId, nationId, null, 1)).isEmpty();
    assertThat(trades.quickSell(playerId, nationId, "   ", 1)).isEmpty();
    assertThat(trades.quickBuy(playerId, nationId, "iron", ResourceTradeTerms.MAX_AMOUNT + 1))
        .isEmpty();

    verify(economy, never()).withdraw(any(), any());
    verify(economy, never()).deposit(any(), any());
    verify(resources, never()).consume(any(), anyString(), anyLong());
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickBuyNormalizesResourceIdsIndependentlyOfTheDefaultLocale() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.grant(nationId, "iron", 5)).thenReturn(true);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId);
    Locale original = Locale.getDefault();
    try {
      Locale.setDefault(Locale.forLanguageTag("tr-TR"));

      assertThat(trades.quickBuy(playerId, nationId, "IRON", 5)).isPresent();
    } finally {
      Locale.setDefault(original);
    }

    verify(resources).grant(nationId, "iron", 5);
  }

  @Test
  void quickBuyRejectsNonFiniteMarketPricesBeforeSettlement() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = taxes();
    MarketOrderBookService orderBook = mock(MarketOrderBookService.class);
    when(orderBook.getCurrentMarketPrice("iron")).thenReturn(Double.NaN);
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId, orderBook);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isEmpty();

    verify(economy, never()).withdraw(any(), any());
    verify(resources, never()).grant(any(), anyString(), anyLong());
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickBuyRejectsMarketPricesAboveSharedTradeLimitsBeforeSettlement() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    NationalReserve reserve = new NationalReserve(NationId.random());
    reserve.addReserve("iron", 5);
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = taxes();
    MarketOrderBookService orderBook = mock(MarketOrderBookService.class);
    when(orderBook.getCurrentMarketPrice("iron"))
        .thenReturn(ResourceTradeTerms.MAX_UNIT_PRICE.doubleValue() + 1.0);
    SimplePlayerTradeService trades =
        service(resources, economy, taxes, reserve, playerId, nationId, orderBook);

    assertThat(trades.quickBuy(playerId, nationId, "iron", 5)).isEmpty();

    verify(economy, never()).withdraw(any(), any());
    verify(resources, never()).grant(any(), anyString(), anyLong());
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickBuyReserveFailureAndRejectedRefundRaisesCriticalFailure() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, false);
    ResourceService resources = mock(ResourceService.class);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(
            resources, economy, taxes, new NationalReserve(NationId.random()), playerId, nationId);

    assertThatThrownBy(() -> trades.quickBuy(playerId, nationId, "iron", 5))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("Quick buy refund failed");
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickSellPaymentAndResourceRestorationFailureRaisesCriticalFailure() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, false);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(nationId, "iron")).thenReturn(5L);
    when(resources.consume(nationId, "iron", 5)).thenReturn(true);
    when(resources.grant(nationId, "iron", 5)).thenReturn(false);
    TradeTaxService taxes = taxes();
    SimplePlayerTradeService trades =
        service(
            resources, economy, taxes, new NationalReserve(NationId.random()), playerId, nationId);

    assertThatThrownBy(() -> trades.quickSell(playerId, nationId, "iron", 5))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("resource restoration failed");
    verify(taxes, never()).fundTax(any());
  }

  @Test
  void quickSellStructuredResultCarriesCommittedFabricTransaction() {
    UUID playerId = UUID.randomUUID();
    NationId nationId = NationId.random();
    EconomyService economy = economy(true, true);
    ResourceService resources = mock(ResourceService.class);
    when(resources.amount(nationId, "iron")).thenReturn(5L);
    when(resources.consume(nationId, "iron", 5L)).thenReturn(true);
    TradeTaxService taxes = taxes();
    ServiceRegistry services = new ServiceRegistry();
    TransactionFabric fabric =
        new TransactionFabric(
            tempDir.resolve("quick-sell-result.properties"), Logger.getAnonymousLogger());
    services.register(TransactionFabric.class, fabric);
    SimplePlayerTradeService trades =
        new SimplePlayerTradeService(
            resources,
            economy,
            taxes,
            null,
            new NationalReserve(NationId.random()),
            services,
            null);
    NationService nations = mock(NationService.class);
    when(nations.nationOf(playerId))
        .thenReturn(java.util.Optional.of(new Nation(nationId, "TradeNation", playerId, "player")));
    trades.setNationService(nations);
    trades.setTradeHistoryService(TradeTestStorage.history(tempDir));

    PlayerTradeService.ActionResult result = trades.quickSellResult(playerId, nationId, "iron", 5);

    assertThat(result.status()).isEqualTo(PlayerTradeService.ActionStatus.APPLIED);
    assertThat(result.transactionId()).isNotNull();
    assertThat(fabric.find(result.transactionId()).orElseThrow().state())
        .isEqualTo(EconomyTransactionState.COMMITTED);
  }

  private SimplePlayerTradeService service(
      ResourceService resources,
      EconomyService economy,
      TradeTaxService taxes,
      NationalReserve reserve,
      UUID playerId,
      NationId nationId) {
    return service(resources, economy, taxes, reserve, playerId, nationId, null);
  }

  private SimplePlayerTradeService service(
      ResourceService resources,
      EconomyService economy,
      TradeTaxService taxes,
      NationalReserve reserve,
      UUID playerId,
      NationId nationId,
      MarketOrderBookService orderBook) {
    NationService nations = mock(NationService.class);
    Nation nation = new Nation(nationId, "QuickTradeNation", playerId, "player");
    when(nations.nationOf(playerId)).thenReturn(java.util.Optional.of(nation));
    SimplePlayerTradeService service =
        new SimplePlayerTradeService(
            resources,
            economy,
            taxes,
            orderBook,
            reserve,
            TradeTestStorage.services(tempDir),
            null);
    service.setNationService(nations);
    service.setTradeHistoryService(TradeTestStorage.history(tempDir));
    return service;
  }

  private EconomyService economy(boolean withdraws, boolean deposits) {
    EconomyService economy = mock(EconomyService.class);
    when(economy.has(any(), any())).thenReturn(true);
    when(economy.withdraw(any(), any())).thenReturn(withdraws);
    when(economy.deposit(any(), any())).thenReturn(deposits);
    return economy;
  }

  private TradeTaxService taxes() {
    TradeTaxService taxes = mock(TradeTaxService.class);
    when(taxes.calculateTax(anyString(), any(Double.class), any())).thenReturn(10.0);
    when(taxes.fundTax(any())).thenReturn(new BigDecimal("10.00"));
    return taxes;
  }
}
