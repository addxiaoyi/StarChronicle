package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class SimpleTradeHistoryCommitTest {
  @TempDir Path temp;
  private static final Instant TIME = Instant.parse("2026-11-24T00:00:00.123456789Z");

  @Test
  void pagesLateCompletionsAndRefundsInCommitOrderWithoutChangingEarlierEvidence() {
    var database = new FileSqliteDatabaseService(temp.resolve("late.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var early =
        record(1, TIME.minusSeconds(60))
            .withStatus(TradeRecord.TradeRecordStatus.DISPUTED, "pending resolution");
    var later = record(2, TIME);
    history.saveRecords(List.of(early, later));
    var first = history.committedChangesAfter(0, 2);
    history.updateStatus(early.recordId(), TradeRecord.TradeRecordStatus.COMPLETED, "resolved");
    history.updateStatus(later.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "退款|\n💰");
    history.updateStatus(later.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "退款|\n💰");
    var changes = history.committedChangesAfter(2, 100);
    assertThat(first).extracting(TradeHistoryChange::sequence).containsExactly(1L, 2L);
    assertThat(first.getFirst().trade().status()).isEqualTo(TradeRecord.TradeRecordStatus.DISPUTED);
    assertThat(changes).extracting(TradeHistoryChange::sequence).containsExactly(3L, 4L);
    assertThat(changes.getFirst().trade().executedAt()).isEqualTo(early.executedAt());
    assertThat(changes.getLast().trade().notes()).contains("退款|\n💰");
    assertThat(changes).allMatch(c -> !c.baseline() && c.committedAt().isAfter(TIME));
    assertThat(changes).extracting(TradeHistoryChange::operationId).doesNotHaveDuplicates();
    assertThat(history.committedChangesAfter(4, 1)).isEmpty();
  }

  @Test
  void restartPreservesDomainOperationTimestampAndNanosecondsWithoutReemitting() {
    var database = new FileSqliteDatabaseService(temp.resolve("restart.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var record = record(1, TIME).withStatus(TradeRecord.TradeRecordStatus.COMPLETED, null);
    history.saveRecord(record);
    var original = history.committedChangesAfter(0, 100).getFirst();
    var restarted = new SimpleTradeHistoryService(database, null);
    restarted.persistAllRecords();
    restarted.saveRecord(restarted.getRecord(record.recordId()).orElseThrow());
    var replay = restarted.committedChangesAfter(0, 100);
    assertThat(restarted.historyAuthorityDomainId()).isEqualTo(history.historyAuthorityDomainId());
    assertThat(replay).hasSize(1);
    assertThat(replay.getFirst().operationId()).isEqualTo(original.operationId());
    assertThat(replay.getFirst().committedAt()).isEqualTo(original.committedAt());
    assertThat(replay.getFirst().trade()).usingRecursiveComparison().isEqualTo(record);
    assertThat(restarted.getRecordsAfter(null, null, 10).getFirst().executedAt()).isEqualTo(TIME);
    restarted.saveRecord(restarted.getRecordsAfter(null, null, 10).getFirst());
    assertThat(restarted.committedChangesAfter(0, 100)).hasSize(1);
  }

  @Test
  void failedJournalInsertRollsBackEntireBatchSequenceAndCache() throws Exception {
    var database = new FileSqliteDatabaseService(temp.resolve("rollback.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var existing = record(1, TIME);
    history.saveRecord(existing);
    execute(
        database,
        "CREATE TRIGGER reject_commit BEFORE INSERT ON trade_commit_log WHEN NEW.sequence=3 BEGIN"
            + " SELECT RAISE(ABORT,'injected journal failure'); END");
    var addition = record(2, TIME);
    assertThatThrownBy(
            () ->
                history.saveRecords(
                    List.of(
                        existing.withStatus(TradeRecord.TradeRecordStatus.REFUNDED, "reversed"),
                        addition)))
        .isInstanceOf(RuntimeException.class)
        .hasStackTraceContaining("injected journal failure");
    assertThat(history.getRecord(existing.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecord.TradeRecordStatus.COMPLETED);
    assertThat(history.getRecord(addition.recordId())).isEmpty();
    var restarted = new SimpleTradeHistoryService(database, null);
    assertThat(restarted.committedChangesAfter(0, 100)).hasSize(1);
    assertThat(restarted.getRecord(existing.recordId()).orElseThrow().status())
        .isEqualTo(TradeRecord.TradeRecordStatus.COMPLETED);
    execute(database, "DROP TRIGGER reject_commit");
    restarted.saveRecord(addition);
    assertThat(restarted.committedChangesAfter(1, 100).getFirst().sequence()).isEqualTo(2);
  }

  @Test
  void migratesOldRowsInBoundedPagesAndLabelsEveryBaseline() throws Exception {
    var database = new FileSqliteDatabaseService(temp.resolve("migration.db"));
    var history = new SimpleTradeHistoryService(database, null);
    List<TradeRecord> old = new ArrayList<>();
    for (int i = 1; i <= 205; i++) old.add(record(i, TIME));
    history.saveRecords(old);
    execute(database, "DROP TABLE trade_commit_log");
    execute(database, "DROP TABLE trade_commit_authority");
    removeSettlementJournal(database);
    legacyTables(database);
    var migrated = new SimpleTradeHistoryService(database, null);
    List<TradeHistoryChange> baseline = new ArrayList<>();
    for (long cursor = 0; ; ) {
      var page = migrated.committedChangesAfter(cursor, 100);
      if (page.isEmpty()) break;
      baseline.addAll(page);
      cursor = page.getLast().sequence();
    }
    assertThat(baseline).hasSize(205).allMatch(TradeHistoryChange::baseline);
    assertThat(baseline).extracting(c -> c.trade().recordId()).doesNotHaveDuplicates();
    migrated.persistAllRecords();
    migrated.updateStatus(
        old.getFirst().recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "new refund");
    assertThat(migrated.committedChangesAfter(205, 10)).hasSize(1).allMatch(c -> !c.baseline());
    assertThat(new SimpleTradeHistoryService(database, null).committedChangesAfter(205, 10))
        .hasSize(1);
  }

  @Test
  void migrationFailureDoesNotLeavePartiallyInitializedAuthority() throws Exception {
    var database = new FileSqliteDatabaseService(temp.resolve("migration-rollback.db"));
    var history = new SimpleTradeHistoryService(database, null);
    history.saveRecords(List.of(record(1, TIME), record(2, TIME)));
    execute(database, "DELETE FROM trade_commit_log");
    execute(database, "DELETE FROM trade_commit_authority");
    removeSettlementJournal(database);
    execute(
        database,
        "CREATE TRIGGER reject_migration BEFORE INSERT ON trade_commit_log WHEN NEW.sequence=2"
            + " BEGIN SELECT RAISE(ABORT,'injected migration failure'); END");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(database, null))
        .hasStackTraceContaining("injected migration failure");
    try (var c = database.getConnection();
        var s = c.createStatement();
        var rows =
            s.executeQuery(
                "SELECT (SELECT COUNT(*) FROM trade_commit_authority)+(SELECT COUNT(*) FROM"
                    + " trade_commit_log)")) {
      rows.next();
      assertThat(rows.getInt(1)).isZero();
    }
    execute(database, "DROP TRIGGER reject_migration");
    assertThat(new SimpleTradeHistoryService(database, null).committedChangesAfter(0, 100))
        .hasSize(2)
        .allMatch(TradeHistoryChange::baseline);
  }

  @Test
  void rejectsGapsAheadCursorsAndMissingAuthorityInsteadOfSilentlyStartingOver() throws Exception {
    var database = new FileSqliteDatabaseService(temp.resolve("gap.db"));
    var history = new SimpleTradeHistoryService(database, null);
    history.saveRecords(List.of(record(1, TIME), record(2, TIME)));
    assertThatThrownBy(() -> history.committedChangesAfter(3, 10))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("ahead");
    assertThatThrownBy(() -> history.committedChangesAfter(-1, 10))
        .isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> history.committedChangesAfter(0, 101))
        .isInstanceOf(IllegalArgumentException.class);
    execute(database, "DELETE FROM trade_commit_log WHERE sequence=1");
    assertThatThrownBy(() -> history.committedChangesAfter(0, 10))
        .isInstanceOf(IllegalStateException.class)
        .hasMessageContaining("gap");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(database, null))
        .hasStackTraceContaining("inconsistent");
    execute(database, "DELETE FROM trade_commit_authority");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(database, null))
        .hasStackTraceContaining("metadata is missing");
  }

  @Test
  void pruningMutableHistoryKeepsReceiptsAndRejectsRebindingTradeTerms() {
    var database = new FileSqliteDatabaseService(temp.resolve("prune.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var original = record(1, TIME);
    history.saveRecord(original);
    assertThat(history.deleteOldRecords(TIME.plusSeconds(1))).isEqualTo(1);
    assertThat(history.getRecord(original.recordId())).isEmpty();
    assertThat(history.committedChangesAfter(0, 10)).hasSize(1);
    assertThatThrownBy(() -> history.saveRecord(record(1, TIME.plusSeconds(10))))
        .hasStackTraceContaining("different terms");
    assertThat(history.getRecord(original.recordId())).isEmpty();
    history.saveRecord(original);
    assertThat(history.committedChangesAfter(1, 10)).isEmpty();
    history.updateStatus(original.recordId(), TradeRecord.TradeRecordStatus.DISPUTED, "in review");
    assertThat(history.committedChangesAfter(1, 10)).hasSize(1);
  }

  @Test
  void statusUpdateCanLoadRecordOutsideStartupCache() {
    var database = new FileSqliteDatabaseService(temp.resolve("uncached.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var oldest = record(1, TIME.minusSeconds(1));
    List<TradeRecord> records = new ArrayList<>();
    records.add(oldest);
    for (int i = 2; i <= 10001; i++) records.add(record(i, TIME));
    history.saveRecords(records);
    var restarted = new SimpleTradeHistoryService(database, null);
    restarted.updateStatus(
        oldest.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "late refund");
    var change = restarted.committedChangesAfter(10001, 100);
    assertThat(change).hasSize(1);
    assertThat(change.getFirst().trade().recordId()).isEqualTo(oldest.recordId());
    assertThat(change.getFirst().trade().executedAt()).isEqualTo(oldest.executedAt());
    assertThat(change.getFirst().trade().status())
        .isEqualTo(TradeRecord.TradeRecordStatus.REFUNDED);
  }

  @Test
  void mismatchedStateBackupCannotOverrideNewerJournal() throws Exception {
    var database = new FileSqliteDatabaseService(temp.resolve("mismatched.db"));
    var history = new SimpleTradeHistoryService(database, null);
    var record = record(1, TIME);
    history.saveRecord(record);
    history.updateStatus(
        record.recordId(), TradeRecord.TradeRecordStatus.REFUNDED, "confirmed refund");
    execute(database, "UPDATE trade_history SET status='COMPLETED'");
    assertThatThrownBy(() -> new SimpleTradeHistoryService(database, null))
        .hasStackTraceContaining("restore matching backups");
    assertThat(history.committedChangesAfter(1, 10).getFirst().trade().status())
        .isEqualTo(TradeRecord.TradeRecordStatus.REFUNDED);
  }

  private static void execute(FileSqliteDatabaseService database, String sql) throws SQLException {
    try (var c = database.getConnection();
        var s = c.createStatement()) {
      s.execute(sql);
    }
  }

  private static void legacyTables(FileSqliteDatabaseService database) throws SQLException {
    // This suite represents installations of the pre-settlement journal, not a fresh database.
    execute(
        database,
        "CREATE TABLE IF NOT EXISTS trade_commit_authority(id INTEGER PRIMARY KEY,domain"
            + " VARCHAR(36) NOT NULL,sequence BIGINT NOT NULL)");
  }

  private static void removeSettlementJournal(FileSqliteDatabaseService database)
      throws SQLException {
    for (String table :
        List.of(
            "trade_history_identity",
            "trade_history_commits",
            "trade_history_authority",
            "trade_settlement_intents")) execute(database, "DROP TABLE " + table);
  }

  private static TradeRecord record(int id, Instant time) {
    return new TradeRecord(
        new UUID(0, id),
        TradeOrder.OrderType.BUY,
        TradeOrder.OrderSource.MARKET,
        new UUID(1, 1),
        new UUID(2, 1),
        NationId.of(new UUID(3, 1)),
        NationId.of(new UUID(4, 1)),
        "industrial",
        2,
        5.0,
        0.5,
        time,
        new UUID(5, id),
        new UUID(6, id),
        "test trade");
  }

  private static final class FileSqliteDatabaseService extends DatabaseService {
    private final String url;

    private FileSqliteDatabaseService(Path path) {
      super(null, null);
      url = "jdbc:sqlite:" + path;
      try {
        legacyTables(this);
      } catch (SQLException failure) {
        throw new IllegalStateException(failure);
      }
    }

    @Override
    public Connection getConnection() {
      try {
        return DriverManager.getConnection(url);
      } catch (SQLException error) {
        throw new IllegalStateException(error);
      }
    }
  }
}
