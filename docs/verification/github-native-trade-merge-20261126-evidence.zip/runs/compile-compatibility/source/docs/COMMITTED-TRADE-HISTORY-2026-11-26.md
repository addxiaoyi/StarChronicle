# 原生贸易提交日志与恢复

本轮修复按成交时间分页漏掉迟到完成记录、结算后历史写入失败只能打印日志的问题。直接交易、快速买卖和市场撮合现先保存准备记录，成功结算后依据持久事务回执写入连续提交日志。`verify` 为 **7,225 项，零失败／错误，21 项既有跳过**；76 项聚焦回归零失败／错误／跳过，未修改原有测试排除配置。

新 StarCore SHA-256：`b0eacd9fe7bf388f2ae236e5b47c395411121b323b0b9cb93ca13c1cce89bbe4`。与 Chronicle `e53a35d8` 在隔离 Paper 1.21.11-132-c5eb079、Java 21、29659 端口完成三次正常启停。134 笔真实原生服务成交（132 笔直接交易、1 笔快速出售、1 笔市场撮合）；故障注入使第 4 笔已结算、未写历史，重启补录后资金和资源保持不变。独立核对和 11 项证据破坏测试通过。

本轮不是生产部署，也没有认证在线玩家命令／GUI、真实快速购买、第三方经济或全栈 Folia。Chronicle 的贸易来源与贡献尚未接入；此前科技／史诗组合使用的 `44f450ec` 原生构件不能作为本构件的组合证据。完整可移植证据在配套 StarChronicle 分支的 `docs/verification/native-trade-history-linux-20261126-*`。

## 提交协议

- `TradeHistoryService.historyAuthorityDomainId()` 返回固定 UUID；`tradeChangesAfter(sequence, limit)` 返回连续提交序号页，limit 为 1..128，包含完成、争议、退款、取消及显式备注修订。
- `trade_history_authority` 保存域、head 和迁移标记；`trade_history_commits` 为不可变状态快照；`trade_history_identity` 保存每个交易的最新权威身份／状态。查询表、身份、日志、head 在一个 SQL 事务提交。写事务先取得写锁再读 head，避免 SQLite deferred read→write 竞争与双实例重复序号。
- `saveRecord(s)` 只接受新记录或完全相同的幂等记录。修改已有记录须用 `updateStatus`，不能改变买卖主体、国家、资源、数量、单价、税、订单或执行时间。旧缓存不再定期覆盖数据库。
- 旧库首次安装只是身份基线，不补造提交事件或时间。未来状态变化记录 `previousStatus`；已清理查询记录仍可据权威身份修订。`deleteOldRecords` 不删除提交日志、身份或准备记录；重复保存不能复活已清理的查询行。
- `committedAt` 是本次 SQL 日志提交时间，`occurredAt` 是对应原生事务事件时间；补录不会用重启时间替换真实结算时间。新 `executed_at_exact` 保存纳秒执行时间；旧数据缺失时保留原 TIMESTAMP 精度，不虚构纳秒。
- 域变更、游标超前、缺号、尾部丢失、已应用事务时间线被改写均拒绝继续。清理策略必须另行设计，不能直接删审计表。

## 准备与恢复

`prepareSettlement` 以 operationId 一次性占位。`TradeSettlementIntent` 固定记录身份、操作者、结算金额、原因及上下文；市场上下文还保存订单原始／已成交数量、买单限价、成交前托管余额、该次保留量、价差退款及税回执 ID。准备后 `TransactionFabric` 以同一域、operation、payload、context 写 metadata，随后进入 RESERVED。依赖缺失或准备失败会在结算前拒绝；旧 attempt 不能重新执行不具备幂等键的外部资金或资源调用。

正常流程保存 DELIVERED→COMMITTED 后调用 `reconcileSettlement`。若历史写入失败，返回真实已结算回执并记录待补录日志；SQL 准备和文件 COMMITTED 回执已经存在。ResourceModule 每 20 秒扫描至多 128 个 intent，循环核对后续退款。恢复只复制持久证据，完全不调用经济／资源服务。

每次补录同时提交新历史、查询记录、已应用事务事件数和时间线 SHA-256。已完成后 REFUND_PENDING／MANUAL_REVIEW 投影为 DISPUTED，REFUNDED 投影为 REFUNDED；成交前失败／退款不补造完成历史。后续消费者须依据 `TradeRecord.status()` 与 `TradeHistoryChange.previousStatus()` 处理净贡献，不能只累加 COMPLETED。`TradeRecord.economyState()` 的旧退款映射不用于本协议。

结果不明的准备保持可查询，不能自动重扣／重发。市场撮合中断后两张订单进入待核对集合，撮合、取消、到期清理及正常停服退款均不再操作这些订单；事务保留 MANUAL_REVIEW。即使部分旧补偿返回成功也保守要求核对。这项限制防止重复交付，但尚未提供完整的托管恢复／管理员解除流程。市场未撮合订单和托管仍主要在内存；异常进程退出前未开始撮合的托管也需要后续持久化工作。

## 实际验证

```bash
env MAVEN_OPTS='-Xmx768m -XX:+UseSerialGC' ./mvnw -B -ntp -Dspotless.ratchetFrom=HEAD verify
```

本机日志 `target/trade-native-verify-20261126-1.log`；聚焦最后通过 `target/trade-settlement-tests-20261126-6.log`。前轮的依赖未注入、漏 import、Mockito 重置方式和不存在的订单 getter 导致测试／编译失败，日志均保留；没有据此放宽断言或排除测试。完整 verify 前移走旧混合 JaCoCo 数据，正常 fork／Mockito agent／JaCoCo 重新生成；依赖仓库 403、SBOM 依赖元数据警告保留，最终 BUILD SUCCESS。

SQLite 回归覆盖迟到记录、晚转完成、精确时间／重启、重复与改写拒绝、日志／查询／ACK 故障整事务回滚、旧库基线、清理保留、双实例连续序号、10,001 条以上缓存边界、跨页和损坏拒绝。服务回归覆盖直接交易、双向快速交易、市场的准备失败、已结算待补录、退款时间线、未知结果禁止重执行、订单待核对、权限及有界扫描。

Paper 成功目录：`/home/add/starchronicle/run/paper-trade-e53a35d8-20261126-2`。第一次尝试 `...-1` 的控制脚本把预期故障日志误判为异常，整服正常退出但验收失败，保留原结果；第二次只允许注入窗口内指定格式且与 SQL operation／事务 ID 相符的一条错误。逐启动快照、资金／资源、持久事务文件、公开 API、序号日志及准备 checkpoint 均独立核对。

下一步继续 Chronicle 真实贸易历史／贡献／冲正、在线玩家流程、完整订单／托管恢复和生产组合。十阶段目标保持进行中。
