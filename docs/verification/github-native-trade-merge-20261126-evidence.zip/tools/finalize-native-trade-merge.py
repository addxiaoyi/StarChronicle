from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda b:hashlib.sha256(b).hexdigest()
phases=['compile-initial','test-initial','compile-compatibility','test-compatibility','test-regression','test-remainder','package','sbom']
runs={p:json.loads((root/'run'/('native-trade-merge-'+p+'-20261126/result.json')).read_text()) for p in phases}
audit=json.loads((root/'run/native-trade-merge-test-regression-20261126/result-audit.json').read_text())
assert audit['completed_totals']==dict(tests=1553,failures=0,errors=0,skipped=0)
assert runs['test-remainder']['totals']==dict(tests=376,failures=0,errors=0,skipped=0)
verified_suites={}
for phase in ['test-regression','test-remainder']:
 folder=root/'run'/('native-trade-merge-'+phase+'-20261126')
 log=(folder/'maven.log').read_text(encoding='utf-8',errors='replace')
 for name in re.findall(r'Tests run: \d+, Failures: \d+, Errors: \d+, Skipped: \d+, Time elapsed: [^\r\n]+ -- in ([\w.$]+)',log):
  p=folder/'surefire'/('TEST-'+name+'.xml');suite=ET.parse(p).getroot()
  assert not any(int(suite.attrib.get(k,0)) for k in ('failures','errors','skipped'))
  assert name not in verified_suites
  verified_suites[name]={'tests':int(suite.attrib['tests']),'xml_sha256':sha(p.read_bytes()),'phase':phase}
assert sum(v['tests'] for v in verified_suites.values())==1929
artifacts=json.loads((root/'run/native-trade-artifacts-final-20261126/result.json').read_text())
databases=json.loads((root/'run/native-trade-databases-20261126/result.json').read_text())
summary={'status':'VERIFIED_BY_COMPLETED_SUITES_AND_REMAINDER','baselines':{'chronicle':'4cc9b18377a8ca2e1939d8395a8378a0c99e6281','starcore':'9bf59b74f66383036ebafd36ecf7d7f115731458'},
 'merged_upstream':{'chronicle':'78b227f6847294111abc3d309690caa58196c689','starcore':subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=native).decode().strip()},
 'tests':dict(tests=1929,failures=0,errors=0,skipped=0),'completed_suites':verified_suites,'runs':runs,'interrupted_run_audit':audit,
 'new_tests':{'upstream':23,'merge_compatibility':6},'artifacts':artifacts,'databases':databases,
 'limits':['The broad run failed with Java heap OOM after 1553 completed tests. A fresh JVM passed the remaining 376. The failed process remains failed; only completed-suite reports form the 1929 aggregate.',
 'The initial interrupted runner summary copied stale XML for the unfinished suite. result-audit.json and completed_suites supersede that total; raw evidence is preserved.',
 'This is a selected resource/scheduler/Essentials/economy/book regression, not all StarCore tests. Existing POM exclusions and one disabled empty class remain unchanged.',
 'Each JVM was limited to 256 MiB for Maven, 128 MiB for probes, and runs after the GUI checkpoint were serialized; no local coverage result.',
 'No Minecraft, production deployment, third-party economy, MySQL or full Folia verification.',
 'Legacy generic-source import semantics are preserved. Fresh/upstream committedChangesAfter uses deterministic receipt IDs, not the technology archive-only first-install protocol.',
 'The upstream UUID-returning domain getter is renamed tradeHistoryAuthorityDomainId because it conflicts with the installed Optional getter. Upstream consumers need recompilation.',
 'Chronicle product Java/resources unchanged; 1076 local tests and CI #199 remain the preceding product checkpoint. Three updated fixtures compile against the paired jars.']}
files={}
for phase in phases:
 folder=root/'run'/('native-trade-merge-'+phase+'-20261126')
 for p in sorted(folder.rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.class'):files['runs/'+phase+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for label in ['native-trade-artifacts-20261126','native-trade-artifacts-final-20261126','native-trade-databases-20261126','github-trade-merge-docs-20261126']:
 folder=root/'run'/label
 for p in sorted(folder.rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.class','.db','.args') and not p.name.endswith(('-wal','-shm')) and 'upstream-raw' not in p.parts:
   files[label+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for name in ['run/run-native-trade-merge.py','run/merge-trade-source.py','run/verify-native-trade-artifacts.py','run/verify-native-trade-databases.py','run/finalize-native-trade-merge.py',
 'run/TradeJournalUpgradeProbe.java','run/TradeSettlementReopenProbe.java','run/MergedTradeProbe.java','run/baltop-gui-ci-success-20261126.log','run/baltop-gui-ci-20261126.json','run/baltop-gui-delivery-git-20261126.json']:
 files['tools/'+Path(name).name]=(root/name).read_bytes()
for name in ['pom.xml','docs/TRADE-JOURNAL-COMPATIBILITY.md','target/starcore-1.0.0-sbom.json']:
 files['native/'+name]=(native/name).read_bytes()
files['native/change.patch']=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=native)
files['aggregate.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
files['manifest.json']=(json.dumps({'files':{n:sha(b) for n,b in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
out=root/'docs/verification/github-native-trade-merge-20261126-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(m['files'])|{'manifest.json'}
 for name,digest in m['files'].items():assert sha(z.read(name))==digest,name
summary['evidence_files']=len(files);summary['evidence_sha256']=sha(out.read_bytes())
(root/'docs/verification/github-native-trade-merge-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# 原生贸易合并、账本兼容与恢复：2026-11-26

同步 StarCore `a645272` 与 Chronicle `78b227f`，将上游结算前持久准备、连续提交日志和历史补录并入当前分支。已安装的旧贸易账本、游标、操作编号和载荷保持原样；新结算协议与旧日志同事务写入。没有启动 Minecraft。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{artifacts['starcore_sha256']}` |
| Chronicle，产品 Java／资源未改 | `{artifacts['chronicle_sha256']}` |
| 本次证据 ZIP | `{summary['evidence_sha256']}` |

[证据包](verification/github-native-trade-merge-20261126-evidence.zip)含 **{len(files)} 文件**；[机器摘要](verification/github-native-trade-merge-20261126-summary.json)逐套件记录成功来源及 XML 哈希，并保存失败进程、构建、数据库／API 核对与旧 CI #199 日志。上游 [原生贸易实服记录](NATIVE-TRADE-HISTORY.md) 的 7,225 项／21 跳过、134 笔成交和三次 Paper 启停仅属于其原构件。

## 合并后的协议

- 保留旧 `historyAuthorityDomainId(): Optional<UUID>`、`committedChangesAfter(1..100)` 及原 resource 包回执。上游同名 UUID getter 与 Java 旧签名冲突，改名 `tradeHistoryAuthorityDomainId()`，对应 `tradeChangesAfter(1..128)` 和 model 包回执；上游调用该旧 UUID 描述符的代码必须重编译。三个配套夹具已修正并编译通过。
- 已安装旧日志保留域、序号、随机操作 ID、时间、baseline 与原始编码。新 settlement journal 继承域，仅导入身份快照，包含已清理查询行和精确纳秒；不制造旧 settlement 事件。未来查询行、两种日志、head 和准备 ACK 同事务提交。两边域或身份冲突时拒绝继续，不自动覆盖。
- 新装／上游既有库沿用上游日志；旧 API 以域＋序号派生固定操作 ID，让现有 Chronicle 通用来源读取。两种接口的序号空间不能互换。通用来源沿用历史导入语义，不是科技专用来源的首次只归档协议。
- 旧库对未准备记录保留旧 saveRecord(s) 修订／显式恢复行为；新装／上游库保持严格幂等保存，旧副本不复活已清理查询行。准备过的旧库记录也必须通过持久事务回执，不能直接重写身份。
- 直接／快速交易及撮合先持久准备，成功后绑定原 TransactionFabric 时间线；历史失败只补日志，不重扣钱或重发资源。退款／争议保留原贡献凭据并更新净状态；市场未知结果继续隔离，未撮合托管崩溃恢复与管理员解除尚未完成。

## 验证

首轮贸易专项 **78 项通过**，追加 **6 项合并兼容测试通过**。扩大选择运行完成 **1,553 项** 后遇到 Java heap OOM，进程失败；独立 256 MiB JVM 跑完余下 **376 项**。按已完成套件日志及对应 XML 合并，**112 套件、1,929 项、零失败／错误／跳过**。本次新增上游 23 项和兼容 6 项；选择包括资源、调度器、Essentials、自带经济／Vault／交易账本及书本，并非全库回归，未扩大 POM 排除。

保留内存失败的整轮日志。初版采集器误把未完成套件的旧 XML 计入失败轮次总数，原摘要也保留；`result-audit.json` 和本次逐套件清单纠正为当轮真正完成的 1,553。夹具初次有两种同名回执的通配导入冲突，改为显式导入后通过，失败日志保留。产品源码未因这些检查错误放宽校验。

StarCore Java21 增量编译、Spotless、verify 打包、36 组件 SBOM、{len(artifacts['class_hashes'])} 个相关类字节及 **6 类原公开声明／描述符**通过。初轮编译 12 主源／11 测试源，最终增量 1 主源／4 测试源；冻结源码与最终 class 核对通过。各 Maven JVM 上限 256 MiB，独立探针 128 MiB，串行运行，forkCount=0、jacoco.skip=true，无本机覆盖率结论。

数据库副本验证：

- 旧 GUI JAR `08816853…553183` 生成的服务样本：130 笔记录、131 次状态提交、一次查询清理。新 JAR 在两独立 JVM 升级／重开后保持域、131 条提交及 **3 张原表原列全部值**不变；新 settlement 身份表另增。样本是本地服务数据，不是实服交易。
- 上游 boot3 的完整 DB/WAL/SHM 先备份成一致副本，保存 134 笔真实服务成交。新构件两次 JVM 重开／核对均扫描 134、补录 0；**124 张原表原列全部值**和事务文件字节不变。上游证据 **5,524 清单文件／5,525 成员** SHA 全通过。
- 当前 StarCore 实际服务＋Chronicle 实际 collector／RuleEngine，在副本上读取这 134 条提交，记录 **134 条历史、534 条贡献凭据**；第二个 JVM 再读新增 0，数量及游标保持。遵循现有通用历史导入语义，没有在线观众、没有资产调用，不代表在线剧情／奖励或退款资产实服验收。

Chronicle 产品源码未改，保留本地 1,076 项及 [Linux CI #199](https://github.com/addxiaoyi/StarChronicle/actions/runs/45770669493) 的产品检查点；合并提交 CI 另行核对。当前构件的实服、完整托管恢复、其他社交／GUI 与生命周期、外部经济未知结果及长期容量继续待办，十阶段尚未完成。
'''
(root/'docs/GITHUB-NATIVE-TRADE-MERGE-20261126.md').write_text(report,encoding='utf-8')
note=f'2026-11-26 当前合并检查点：[原生贸易日志与兼容恢复](GITHUB-NATIVE-TRADE-MERGE-20261126.md)。合入 StarCore `a645272`／Chronicle `78b227f`，保留旧账本和 API，并加入持久准备及失败补录。**1,929 项相关测试分批完成**；旧库 131 提交和上游 134 成交的独立 JVM 重开保持原数据。StarCore `{artifacts["starcore_sha256"][:8]}…{artifacts["starcore_sha256"][-6:]}`，Chronicle 产品保持 1,076 项检查点。未启动 Minecraft，十阶段继续进行。'
for name in ['README.md','docs/HANDOFF-2026-11-25.md','docs/HANDOFF-2026-11-26.md','docs/REMAINING-WORK.md']:
 p=root/name;t=p.read_text(encoding='utf-8');pos=t.index('\n\n')+2
 inserted=note.replace('(GITHUB-NATIVE-TRADE-MERGE-20261126.md)','(docs/GITHUB-NATIVE-TRADE-MERGE-20261126.md)') if name=='README.md' else note
 p.write_text(t[:pos]+inserted+'\n\n'+t[pos:],encoding='utf-8')
print(json.dumps({'tests':summary['tests'],'suites':len(verified_suites),'evidence_files':len(files),'evidence_sha256':summary['evidence_sha256']}))
