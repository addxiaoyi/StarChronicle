import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.module.resource.*;
import java.nio.file.Path;
import java.sql.*;
import java.util.logging.Logger;

/** Only replays persisted history from the archived transaction file, with no asset services. */
public class TradeSettlementReopenProbe {
  public static void main(String[] args) throws Exception {
    DatabaseService database=new DatabaseService(null,null) {
      @Override public Connection getConnection() {
        try { return DriverManager.getConnection("jdbc:sqlite:"+args[0]); }
        catch(SQLException failure) { throw new IllegalStateException(failure); }
      }
    };
    var history=new SimpleTradeHistoryService(database,null);
    var fabric=new TransactionFabric(Path.of(args[1]),Logger.getAnonymousLogger());
    var recovery=new TradeSettlementCoordinator(history,fabric,Logger.getAnonymousLogger());
    var first=recovery.reconcileNextPage();var second=recovery.reconcileNextPage();
    if(first.failures()!=0||second.failures()!=0||first.unresolved()!=0||second.unresolved()!=0)
      throw new AssertionError("Unexpected unresolved source");
    long cursor=0,count=0;
    while(true) {var page=history.tradeChangesAfter(cursor,128);if(page.isEmpty())break;
      count+=page.size();cursor=page.getLast().sequence();}
    if(first.applied()!=0||second.applied()!=0||count!=134)throw new AssertionError("Unexpected history change");
    System.out.println("{\"commits\":"+count+",\"scanned\":"+(first.scanned()+second.scanned())
        +",\"applied\":0,\"transactions\":"+fabric.snapshot().size()+",\"domain\":\""+history.tradeHistoryAuthorityDomainId()+"\"}");
  }
}
