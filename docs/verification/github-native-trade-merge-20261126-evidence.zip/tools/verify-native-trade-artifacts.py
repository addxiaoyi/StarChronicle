from pathlib import Path
import hashlib,json,re,subprocess,zipfile,sys
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/('run/native-trade-artifacts'+('-'+sys.argv[1] if len(sys.argv)>1 else '')+'-20261126');out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
jar=native/'target/starcore-1.0.0.jar';old=root/'run/github-trade-merge-input-20261126/gui-starcore.jar'
types=['module/resource/ResourceModule','module/resource/SimpleMarketOrderBookService','module/resource/SimplePlayerTradeService',
       'module/resource/SimpleTradeHistoryService','module/resource/TradeHistoryService','module/resource/TradeHistoryChange']
added=['module/resource/TradeCommitJournal','module/resource/SettlementTradeJournal','module/resource/TradeRecordCodec',
       'module/resource/TradeSettlementCoordinator','module/resource/model/TradeHistoryChange','module/resource/model/TradeSettlementIntent']
prefix='dev/starcore/starcore/';classes=native/'target/classes';checked={};apis={}
with zipfile.ZipFile(jar) as archive:
 for kind in types+added:
  name=prefix+kind;parent,stem=name.rsplit('/',1)
  for p in (classes/parent).glob(stem+'*.class'):
   relative=p.relative_to(classes).as_posix();raw=p.read_bytes()
   assert raw==archive.read(relative) and int.from_bytes(raw[6:8],'big')==65
   checked[relative]=sha(raw)
sources={}
frozen=root/'run/native-trade-merge-test-regression-20261126/source'
for p in frozen.rglob('*.java'):
 name=p.relative_to(frozen).as_posix();assert p.read_bytes()==(native/name).read_bytes(),name
 sources[name]=sha(p.read_bytes())
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
for kind in types:
 methods=[]
 for label,artifact in [('old',old),('current',jar)]:
  p=subprocess.run([str(java/'javap.exe'),'-J-Xmx64m','-J-XX:+UseSerialGC','-public','-s','-classpath',str(artifact),(prefix+kind).replace('/','.')],capture_output=True,check=True)
  (out/(label+'-'+kind.rsplit('/',1)[1]+'.txt')).write_bytes(p.stdout)
  methods.append(set(re.findall(r'  (public [^\n]+;)\r?\n    descriptor: ([^\r\n]+)',p.stdout.decode().replace('synchronized ',''))))
 assert methods[0] and methods[0]<=methods[1],(kind,methods[0]-methods[1])
 apis[kind]={'preserved':len(methods[0]),'added':[list(v) for v in sorted(methods[1]-methods[0])]}
libs=sorted((root/'run/paper-epic-1faf2ba2-dungeon-phases-2/libraries').rglob('*.jar'))
product=root/'target/starchronicle-0.1.0-SNAPSHOT.jar'
cp=';'.join(p.as_posix() for p in [jar,product,*libs])
fixtures=[root/'tools'/name for name in ['EpicCampaignPaperFixture.java','TechnologyHistoryPaperFixture.java','TradeHistoryPaperFixture.java']]
argfile=out/'fixtures.args';argfile.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp,'-d',out,*fixtures,root/'run/MergedTradeProbe.java'])+'\n',encoding='utf-8')
p=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC','@'+str(argfile)],capture_output=True)
(out/'fixtures.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
probe_results=[]
for label in ['import','reopen']:
 args=out/(label+'.args');args.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in ['-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-Dfile.encoding=UTF-8','-classpath',cp+';'+str(out),'io.github.addxiaoyi.starchronicle.integration.MergedTradeProbe',root/'run/native-trade-databases-20261126/upstream.db',out/'chronicle.db'])+'\n',encoding='utf-8')
 p=subprocess.run([str(java/'java.exe'),'@'+str(args)],capture_output=True)
 (out/(label+'.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,label
 probe_results.append(json.loads(next(line for line in p.stdout.decode().splitlines() if line.startswith('{'))))
assert probe_results[0]['accepted']==134 and probe_results[1]['accepted']==0
assert probe_results[0]['events']==probe_results[1]['events']==134
assert probe_results[0]['contributions']==probe_results[1]['contributions']>0
summary={'status':'VERIFIED','starcore_sha256':sha(jar.read_bytes()),'old_sha256':sha(old.read_bytes()),'chronicle_sha256':sha(product.read_bytes()),
 'class_hashes':checked,'public_api':apis,'source_hashes':sources,'fixtures':[p.name for p in fixtures],
 'native_chronicle_probe':probe_results,'sbom_components':len(json.loads((native/'target/starcore-1.0.0-sbom.json').read_text())['components']),
 'limits':['Original branch public signatures are preserved; upstream UUID historyAuthorityDomainId is renamed tradeHistoryAuthorityDomainId. Upstream consumers of that descriptor must recompile.',
 'Actual native service and Chronicle collector over a copied archived database in separate JVMs; historical contribution import follows existing generic-source semantics, with no online audience or asset calls.',
 'Fixture compilation is not live acceptance. Existing archived live reports retain their original artifact scope.']}
assert summary['sbom_components']==36
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('class_hashes','public_api','source_hashes')}))
