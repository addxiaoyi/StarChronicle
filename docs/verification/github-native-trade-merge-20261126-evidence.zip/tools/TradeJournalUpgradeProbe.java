import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.resource.SimpleTradeHistoryService;
import dev.starcore.starcore.module.resource.model.TradeOrder;
import dev.starcore.starcore.module.resource.model.TradeRecord;
import java.sql.*;
import java.time.Instant;
import java.util.*;

/** Service-level database-copy probe. Does not start Minecraft or exercise a player settlement. */
public class TradeJournalUpgradeProbe {
  public static void main(String[] args) throws Exception {
    String mode=args[0],url="jdbc:sqlite:"+args[1];
    DatabaseService database=new DatabaseService(null,null) {
      @Override public Connection getConnection() {
        try { return DriverManager.getConnection(url); }
        catch(SQLException failure) { throw new IllegalStateException(failure); }
      }
    };
    var history=new SimpleTradeHistoryService(database,null);
    Instant time=Instant.parse("2026-11-24T01:02:03.123456789Z");
    if(mode.equals("seed")) {
      List<TradeRecord> records=new ArrayList<>();
      for(int i=1;i<=130;i++) records.add(new TradeRecord(new UUID(0,i),TradeOrder.OrderType.BUY,
          TradeOrder.OrderSource.MARKET,new UUID(1,1),new UUID(2,1),null,null,"iron",5,2.0,0.5,
          i==2?time.minusSeconds(10):time,null,null,"legacy probe"));
      history.saveRecords(records);
      history.updateStatus(new UUID(0,1),TradeRecord.TradeRecordStatus.REFUNDED,"confirmed");
      history.deleteOldRecords(time.minusSeconds(1));
    }
    long cursor=0,count=0;
    while(true) {
      var page=history.committedChangesAfter(cursor,100);
      if(page.isEmpty())break;
      count+=page.size();cursor=page.getLast().sequence();
    }
    history.persistAllRecords();
    System.out.println("{\"mode\":\""+mode+"\",\"domain\":\""+history.historyAuthorityDomainId().orElseThrow()
        +"\",\"commits\":"+count+",\"head\":"+cursor+"}");
  }
}
