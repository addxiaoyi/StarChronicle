from pathlib import Path
import hashlib,json,sqlite3,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
out=root/'run/native-trade-databases-20261126';out.mkdir(exist_ok=False)
java=Path(r'C:\tmp\jdk21\jdk-21.0.13.1+2\bin')
old=root/'run/github-trade-merge-input-20261126/gui-starcore.jar';current=native/'target/starcore-1.0.0.jar'
libraries=sorted((root/'run/paper-epic-1faf2ba2-dungeon-phases-2/libraries').rglob('*.jar'));assert len(libraries)>5
sha=lambda b:hashlib.sha256(b).hexdigest()
def argsfile(name,arguments):
 p=out/(name+'.args');p.write_text('\n'.join('"'+str(a).replace('\\','/')+'"' for a in arguments)+'\n',encoding='utf-8');return '@'+str(p)
cp=lambda artifact:';'.join(str(p) for p in [out,artifact,*libraries])
for source,artifact in [('TradeJournalUpgradeProbe.java',old),('TradeSettlementReopenProbe.java',current)]:
 args=argsfile('compile-'+source,['-encoding','UTF-8','-proc:none','--release','21','-classpath',cp(artifact),'-d',out,root/'run'/source])
 r=subprocess.run([str(java/'javac.exe'),'-J-Xmx128m','-J-XX:+UseSerialGC',args],capture_output=True)
 (out/('compile-'+source+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,source
def run(label,artifact,klass,*arguments):
 args=argsfile(label,['-Xmx128m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1','-Dfile.encoding=UTF-8','-classpath',cp(artifact),klass,*arguments])
 r=subprocess.run([str(java/'java.exe'),args],capture_output=True)
 (out/(label+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==0,label
 return json.loads([line for line in r.stdout.decode('utf-8').splitlines() if line.startswith('{')][-1])
def snapshot(path,columns=None):
 with sqlite3.connect(path) as db:
  tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
  if columns is None:columns={t:[r[1] for r in db.execute('PRAGMA table_info("'+t+'")')] for t in tables}
  data={}
  for t,cols in columns.items():
   query='SELECT '+','.join('"'+c.replace('"','""')+'"' for c in cols)+' FROM "'+t.replace('"','""')+'"'
   rows=list(db.execute(query));serialized=sorted(json.dumps(row,ensure_ascii=False,default=lambda v:v.hex()) for row in rows)
   data[t]={'rows':len(rows),'sha256':sha('\n'.join(serialized).encode())}
  return columns,data
legacy=out/'legacy.db'
seed=run('legacy-old-jar',old,'TradeJournalUpgradeProbe','seed',legacy)
assert seed['commits']==131
columns,before=snapshot(legacy)
first=run('legacy-upgrade',current,'TradeJournalUpgradeProbe','reopen',legacy)
assert first['domain']==seed['domain'] and first['commits']==131
assert snapshot(legacy,columns)[1]==before
second=run('legacy-reopen',current,'TradeJournalUpgradeProbe','reopen',legacy)
assert second==first and snapshot(legacy,columns)[1]==before
archive=root/'docs/verification/native-trade-history-linux-20261126-evidence.zip'
prefix='paper-trade-e53a35d8-20261126-2/evidence/boot3.data/StarCore/'
raw=out/'upstream-raw';raw.mkdir()
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('evidence-manifest.json'))
 assert set(z.namelist())==set(manifest)|{'evidence-manifest.json'}
 for name,digest in manifest.items():assert sha(z.read(name))==digest,name
 for name in ('starcore.db','starcore.db-wal','starcore.db-shm','economy/transaction-fabric.properties'):
  data=z.read(prefix+name);(raw/Path(name).name).write_bytes(data)
upstream=out/'upstream.db'
with sqlite3.connect(raw/'starcore.db') as source,sqlite3.connect(upstream) as destination:source.backup(destination)
columns2,before2=snapshot(upstream);assert before2['trade_history_commits']['rows']==134
fabric=raw/'transaction-fabric.properties';fabric_hash=sha(fabric.read_bytes())
up1=run('upstream-upgrade',current,'TradeSettlementReopenProbe',upstream,fabric)
assert snapshot(upstream,columns2)[1]==before2 and sha(fabric.read_bytes())==fabric_hash
up2=run('upstream-reopen',current,'TradeSettlementReopenProbe',upstream,fabric)
assert up1==up2 and snapshot(upstream,columns2)[1]==before2 and sha(fabric.read_bytes())==fabric_hash
summary={'status':'VERIFIED','old_jar':sha(old.read_bytes()),'current_jar':sha(current.read_bytes()),
 'legacy':{'seed':seed,'upgrade':first,'reopen':second,'original_tables':before},
 'upstream':{'upgrade':up1,'reopen':up2,'original_tables':before2,'transaction_file_sha256':fabric_hash},
 'upstream_evidence':{'files':len(manifest),'sha256':sha(archive.read_bytes())},
 'limits':'Independent JVM service probes of database copies; no Minecraft or asset API calls. Legacy sample is synthetic service data, upstream 134-settlement data comes from the archived real service run.'}
(out/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('legacy','upstream')}));print(json.dumps({'legacy_tables':len(before),'upstream_tables':len(before2),'legacy':first,'upstream':up1}))
