package io.github.addxiaoyi.starchronicle.integration;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.module.resource.SimpleTradeHistoryService;
import io.github.addxiaoyi.starchronicle.core.RuleEngine;
import io.github.addxiaoyi.starchronicle.persistence.SqliteStore;
import java.sql.*;
import java.nio.file.Path;
import java.time.Clock;
import java.util.*;

/** Current native service and Chronicle collector over a disposable database copy; no server. */
public class MergedTradeProbe {
  public static void main(String[] args) throws Exception {
    DatabaseService database=new DatabaseService(null,null) {
      @Override public Connection getConnection() {
        try { return DriverManager.getConnection("jdbc:sqlite:"+args[0]); }
        catch(SQLException failure) { throw new IllegalStateException(failure); }
      }
    };
    var history=new SimpleTradeHistoryService(database,null);
    var collector=new CommittedSourceCollector(key->history);
    try(var store=new SqliteStore(Path.of(args[1]))) {
      var engine=new RuleEngine(store,List.of(),Clock.systemUTC());
      int accepted=0;
      for(int i=0;i<10;i++) {
        var page=collector.collect(CommittedSourceCollector.Source.TRADE,engine.committedSourceCursor("starcore.trade")).orElseThrow();
        int count=engine.acceptCommittedSource(page,List.of());accepted+=count;
        if(count==0)break;
        if(i==9)throw new AssertionError("Unbounded source");
      }
      long events=store.transaction(c->{try(var q=c.createStatement();var row=q.executeQuery("SELECT count(*) FROM events")){row.next();return row.getLong(1);}});
      long contributions=store.transaction(c->{try(var q=c.createStatement();var row=q.executeQuery("SELECT count(*) FROM contributions")){row.next();return row.getLong(1);}});
      System.out.println(SqliteStore.json(Map.of("accepted",accepted,"events",events,"contributions",contributions,
          "cursor",engine.committedSourceCursor("starcore.trade").orElseThrow().sequence())));
    }
  }
}
