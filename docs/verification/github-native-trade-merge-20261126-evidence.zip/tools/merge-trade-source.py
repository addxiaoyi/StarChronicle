from pathlib import Path
import re
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
base=native/'src/main/java/dev/starcore/starcore/module/resource'
inputs=root/'run/github-trade-merge-input-20261126'
def replace(s,a,b):
 assert a in s,a
 return s.replace(a,b)
# The installed legacy stream retains its class, codec, receipts and public record type.
(base/'TradeCommitJournal.java').write_text((inputs/'local-TradeCommitJournal.java').read_text(),encoding='utf-8')
s=(inputs/'upstream-TradeCommitJournal.java').read_text()
s=s.replace('TradeCommitJournal','SettlementTradeJournal')
s=replace(s,'  private final UUID domain;','  private final UUID domain;\n  private final boolean legacy;')
s=replace(s,'SettlementTradeJournal(DatabaseService database) {','SettlementTradeJournal(DatabaseService database, boolean legacy) {\n    this.legacy = legacy;')
s=replace(s,'insert.setString(1, UUID.randomUUID().toString());','insert.setString(1, (legacy ? TradeCommitJournal.domain(connection) : UUID.randomUUID()).toString());')
s=replace(s,'Head current = head(connection);\n          if (!current.initialized()) {','Head current = head(connection);\n          if (legacy && !current.domain().equals(TradeCommitJournal.domain(connection)))\n            throw new IllegalStateException("Trade journal domains disagree; restore matching backups");\n          if (!current.initialized()) {')
start=s.index('            // Old records are a baseline')
end=s.index('            try (Statement update',start)
s=s[:start]+'''            // Preserve the original legacy nanoseconds and pruned identities; do not manufacture events.
            if (legacy) {
              String cursor = "";
              while (true) {
                List<UUID> ids = new ArrayList<>();
                try (PreparedStatement query = connection.prepareStatement(
                    "SELECT DISTINCT record_id FROM trade_commit_log WHERE record_id>? ORDER BY record_id LIMIT 100")) {
                  query.setString(1, cursor);
                  try (ResultSet rows = query.executeQuery()) {
                    while (rows.next()) ids.add(UUID.fromString(rows.getString(1)));
                  }
                }
                if (ids.isEmpty()) break;
                for (UUID id : ids) seedIdentity(connection, TradeCommitJournal.latest(connection, id).orElseThrow());
                cursor = ids.getLast().toString();
              }
            } else {
              try (Statement query = connection.createStatement();
                  ResultSet rows = query.executeQuery("SELECT * FROM trade_history ORDER BY record_id")) {
                while (rows.next()) seedIdentity(connection, SimpleTradeHistoryService.extractRecordFromResultSet(rows));
              }
            }
'''+s[end:]
s=replace(s,'          return current.domain();','          if (legacy) validateLegacy(connection);\n          return current.domain();')
s=replace(s,'              if (!TradeRecordCodec.encode(previous).equals(TradeRecordCodec.encode(record))) {','''              if (legacy) {
                requireUnprepared(connection, record.recordId());
                if (!TradeRecordCodec.identity(previous).equals(TradeRecordCodec.identity(record)))
                  throw new IllegalArgumentException("Trade record identity is already bound to different terms");
                if (!TradeRecordCodec.encode(previous).equals(TradeRecordCodec.encode(record)))
                  sequence = append(connection, sequence, previous, record, writer, Instant.now());
                else writer.write(connection, record);
                continue;
              }
              if (!TradeRecordCodec.encode(previous).equals(TradeRecordCodec.encode(record))) {''')
s=replace(s,'      head(connection);\n      query.setString(1, recordId.toString());','      head(connection);\n      query.setString(1, recordId.toString());')
s=replace(s,'  private Optional<TradeRecord> latest(Connection connection, UUID id)', '  Optional<TradeRecord> latest(Connection connection, UUID id)')
point=s.index('  private <T> T write(')
s=s[:point]+'''  private void seedIdentity(Connection connection, TradeRecord record) throws SQLException {
    try (PreparedStatement insert = connection.prepareStatement(
        "INSERT INTO trade_history_identity (record_id,payload) VALUES (?,?)")) {
      insert.setString(1, record.recordId().toString());
      insert.setString(2, TradeRecordCodec.encode(record));
      insert.executeUpdate();
    }
  }

  private void validateLegacy(Connection connection) throws SQLException {
    try (Statement query = connection.createStatement();
        ResultSet rows = query.executeQuery("SELECT record_id,payload FROM trade_history_identity")) {
      while (rows.next()) {
        UUID id = UUID.fromString(rows.getString(1));
        TradeRecord old = TradeCommitJournal.latest(connection, id).orElseThrow(
            () -> new IllegalStateException("Legacy trade snapshot is missing"));
        if (!TradeRecordCodec.encode(old).equals(rows.getString(2)))
          throw new IllegalStateException("Trade journals disagree; restore matching backups");
      }
    }
    try (Statement query = connection.createStatement();
        ResultSet rows = query.executeQuery("SELECT COUNT(DISTINCT record_id) FROM trade_commit_log")) {
      rows.next(); long expected = rows.getLong(1);
      try (Statement count = connection.createStatement();
          ResultSet identities = count.executeQuery("SELECT COUNT(*) FROM trade_history_identity")) {
        identities.next();
        if (expected != identities.getLong(1)) throw new IllegalStateException("Trade identity inventory disagrees with legacy journal");
      }
    }
  }

  private void requireUnprepared(Connection connection, UUID id) throws SQLException {
    try (PreparedStatement query = connection.prepareStatement(
        "SELECT operation_id FROM trade_settlement_intents WHERE record_id=?")) {
      query.setString(1, id.toString());
      try (ResultSet row = query.executeQuery()) {
        if (row.next()) throw new IllegalStateException("Prepared trade requires its durable transaction receipt");
      }
    }
  }

'''+s[point:]
(base/'SettlementTradeJournal.java').write_text(s,encoding='utf-8')
# Resolve text conflicts while retaining local timestamp/query checks and cursor API.
s=(base/'SimpleTradeHistoryService.java').read_text()
parts=[];last=0
for i,m in enumerate(re.finditer(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>>[^\n]+\n',s,re.S)):
 parts.append(s[last:m.start()]);parts.append(m.group(1 if i==5 else 2));last=m.end()
parts.append(s[last:]);assert i==5
s=''.join(parts).replace('import dev.starcore.starcore.module.resource.model.TradeHistoryChange;\n','')
s=replace(s,'private final TradeCommitJournal commitJournal;','private final SettlementTradeJournal commitJournal;\n  private final boolean legacyJournal;')
s=replace(s,'    this.commitJournal = new TradeCommitJournal(databaseService);','''    try (Connection connection = databaseService.getConnection()) {
      legacyJournal = DatabaseUtils.tableExists(connection, "trade_commit_authority")
          || DatabaseUtils.tableExists(connection, "trade_commit_log");
    } catch (SQLException failure) {
      throw new IllegalStateException("Cannot select installed trade journal", failure);
    }
    if (legacyJournal) initializeCommitJournal();
    this.commitJournal = new SettlementTradeJournal(databaseService, legacyJournal);''')
s=replace(s,'  public Optional<UUID> historyAuthorityDomainId() {','  public Optional<UUID> historyAuthorityDomainId() {\n    if (!legacyJournal) return Optional.of(commitJournal.domain());')
s=replace(s,'  public List<TradeHistoryChange> committedChangesAfter(long sequence, int limit) {','''  public List<TradeHistoryChange> committedChangesAfter(long sequence, int limit) {
    if (sequence < 0 || limit < 1 || limit > 100) throw new IllegalArgumentException("Trade commit pages require cursor>=0 and limit 1..100");
    if (!legacyJournal) return commitJournal.changesAfter(sequence, limit).stream().map(change ->
        new TradeHistoryChange(change.authorityDomainId(), change.sequence(),
            UUID.nameUUIDFromBytes(("StarCore.trade.commit:" + change.authorityDomainId() + ":" + change.sequence()).getBytes(java.nio.charset.StandardCharsets.UTF_8)),
            change.record(), change.committedAt(), false)).toList();''')
s=replace(s,'public UUID historyAuthorityDomainId()', 'public UUID tradeHistoryAuthorityDomainId()')
s=replace(s,'public List<TradeHistoryChange> tradeChangesAfter','public List<dev.starcore.starcore.module.resource.model.TradeHistoryChange> tradeChangesAfter')
s=s.replace('this::persistRecord','this::persistCommittedRecord')
point=s.index('  private void persistRecord(Connection')
s=s[:point]+'''  private void persistCommittedRecord(Connection connection, TradeRecord record) throws SQLException {
    persistRecord(connection, record);
    if (legacyJournal) TradeCommitJournal.append(connection, record, false);
  }

'''+s[point:]
s=replace(s,'        TradeCommitJournal.latest(connection, id)','        (legacyJournal ? TradeCommitJournal.latest(connection, id) : commitJournal.latest(connection, id))')
# compare exact field when present; only pre-upgrade rows may have truncated projection timestamps.
s=replace(s,'    if (!TradeCommitJournal.sameProjection(\n        extractRecordFromResultSet(row), snapshot, projectionPrecision(connection)))','''    if (row.getString("executed_at_exact") != null
        ? !TradeRecordCodec.encode(extractRecordFromResultSet(row)).equals(TradeRecordCodec.encode(snapshot))
        : !TradeCommitJournal.sameProjection(extractRecordFromResultSet(row), snapshot, projectionPrecision(connection)))''')
(base/'SimpleTradeHistoryService.java').write_text(s,encoding='utf-8')
s=(base/'TradeHistoryService.java').read_text().replace('import dev.starcore.starcore.module.resource.model.TradeHistoryChange;\n','')
s=replace(s,'default UUID historyAuthorityDomainId()', 'default UUID tradeHistoryAuthorityDomainId()')
s=replace(s,'default List<TradeHistoryChange> tradeChangesAfter', 'default List<dev.starcore.starcore.module.resource.model.TradeHistoryChange> tradeChangesAfter')
(base/'TradeHistoryService.java').write_text(s,encoding='utf-8')
for p in [base/'TradeSettlementCoordinator.java',native/'src/test/java/dev/starcore/starcore/module/resource/TradeCommitJournalTest.java']:
 s=p.read_text().replace('historyAuthorityDomainId','tradeHistoryAuthorityDomainId');p.write_text(s,encoding='utf-8')
print('Resolved legacy and settlement trade journal sources')
