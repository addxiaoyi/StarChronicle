package dev.starcore.starcore.map;

import java.util.*;

/** 区域模型 表示地图上的一个区域 */
public record Region(
    String regionId, // 区域ID
    String name, // 区域名称
    RegionKind kind, // 区域类型
    int x, // X坐标
    int y, // Y坐标
    int z, // Z坐标
    String world, // 世界名称
    String nationId, // 所属国家ID（空表示无主）
    Set<String> connectedRegions, // 连接的区域ID集合
    Map<String, Object> metadata, // 元数据
    boolean enabled, // 是否启用
    boolean visible // 是否可见
    ) {

  /** 创建区域构建器 */
  public static Builder builder(String regionId, String name, RegionKind kind) {
    return new Builder(regionId, name, kind);
  }

  /** 检查区域是否可访问 */
  public boolean isAccessible() {
    return enabled && visible;
  }

  /** 检查是否有国家所有 */
  public boolean hasNation() {
    return nationId != null && !nationId.isEmpty();
  }

  /** 检查是否连接到指定区域 */
  public boolean isConnectedTo(String otherRegionId) {
    return connectedRegions.contains(otherRegionId);
  }

  /** 区域构建器 */
  public static class Builder {
    private final String regionId;
    private final String name;
    private final RegionKind kind;
    private int x = 0;
    private int y = 0;
    private int z = 0;
    private String world = "world";
    private String nationId;
    private Set<String> connectedRegions = new HashSet<>();
    private Map<String, Object> metadata = new HashMap<>();
    private boolean enabled = true;
    private boolean visible = true;

    private Builder(String regionId, String name, RegionKind kind) {
      this.regionId = requireText(regionId, "regionId");
      this.name = requireText(name, "name");
      this.kind = Objects.requireNonNull(kind);
    }

    public Builder position(int x, int y, int z) {
      this.x = x;
      this.y = y;
      this.z = z;
      return this;
    }

    public Builder world(String world) {
      this.world = requireText(world, "world");
      return this;
    }

    public Builder nationId(String nationId) {
      this.nationId = nationId;
      return this;
    }

    public Builder addConnection(String regionId) {
      this.connectedRegions.add(requireText(regionId, "connected region ID"));
      return this;
    }

    public Builder connectedRegions(Set<String> connectedRegions) {
      Objects.requireNonNull(connectedRegions, "connectedRegions");
      this.connectedRegions = new HashSet<>();
      connectedRegions.stream()
          .map(value -> requireText(value, "connected region ID"))
          .forEach(this.connectedRegions::add);
      return this;
    }

    public Builder metadata(String key, Object value) {
      this.metadata.put(
          requireText(key, "metadata key"), Objects.requireNonNull(value, "metadata value"));
      return this;
    }

    public Builder metadata(Map<String, Object> metadata) {
      Objects.requireNonNull(metadata, "metadata");
      metadata.forEach(this::metadata);
      return this;
    }

    public Builder enabled(boolean enabled) {
      this.enabled = enabled;
      return this;
    }

    public Builder visible(boolean visible) {
      this.visible = visible;
      return this;
    }

    public Region build() {
      return new Region(
          regionId,
          name,
          kind,
          x,
          y,
          z,
          world,
          nationId,
          Set.copyOf(connectedRegions),
          Map.copyOf(metadata),
          enabled,
          visible);
    }

    private static String requireText(String value, String field) {
      Objects.requireNonNull(value, field);
      String normalized = value.trim();
      if (normalized.isEmpty()) {
        throw new IllegalArgumentException(field + " must not be blank");
      }
      return normalized;
    }
  }
}
