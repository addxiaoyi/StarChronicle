package dev.starcore.starcore.foundation.animation;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

/** Tracks delayed and repeating Bukkit tasks owned by an animation service. */
final class AnimationTaskTracker {
  private final Plugin plugin;
  private final Object lock = new Object();
  private final Set<BukkitTask> tasks = ConcurrentHashMap.newKeySet();
  private volatile boolean closed;

  AnimationTaskTracker(Plugin plugin) {
    this.plugin = plugin;
  }

  BukkitTask runTaskLater(Runnable action, long delay) {
    AtomicReference<BukkitTask> taskReference = new AtomicReference<>();
    synchronized (lock) {
      if (closed) {
        return null;
      }
      BukkitTask task =
          plugin
              .getServer()
              .getScheduler()
              .runTaskLater(
                  plugin,
                  () -> {
                    try {
                      if (!closed) {
                        action.run();
                      }
                    } finally {
                      BukkitTask completedTask = taskReference.get();
                      if (completedTask != null) {
                        tasks.remove(completedTask);
                      }
                    }
                  },
                  delay);
      taskReference.set(task);
      if (task != null) {
        if (closed) {
          task.cancel();
        } else {
          tasks.add(task);
        }
      }
      return task;
    }
  }

  BukkitTask runTaskTimer(Consumer<BukkitTask> action, long delay, long period) {
    AtomicReference<BukkitTask> taskReference = new AtomicReference<>();
    synchronized (lock) {
      if (closed) {
        return null;
      }
      BukkitTask task =
          plugin
              .getServer()
              .getScheduler()
              .runTaskTimer(
                  plugin,
                  () -> {
                    BukkitTask currentTask = taskReference.get();
                    if (closed) {
                      if (currentTask != null) {
                        currentTask.cancel();
                        tasks.remove(currentTask);
                      }
                      return;
                    }
                    try {
                      action.accept(currentTask);
                    } catch (RuntimeException | Error failure) {
                      if (currentTask != null) {
                        currentTask.cancel();
                      }
                      throw failure;
                    } finally {
                      if (currentTask != null && currentTask.isCancelled()) {
                        tasks.remove(currentTask);
                      }
                    }
                  },
                  delay,
                  period);
      taskReference.set(task);
      if (task != null) {
        if (closed) {
          task.cancel();
        } else {
          tasks.add(task);
        }
      }
      return task;
    }
  }

  boolean isClosed() {
    return closed;
  }

  void shutdown() {
    Set<BukkitTask> activeTasks;
    synchronized (lock) {
      if (closed) {
        return;
      }
      closed = true;
      activeTasks = Set.copyOf(tasks);
      tasks.clear();
    }
    activeTasks.forEach(BukkitTask::cancel);
  }
}
