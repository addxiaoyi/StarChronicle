package dev.starcore.starcore.essentials.data;

import dev.starcore.starcore.core.persistence.AtomicFilePersistence;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.nickname.NicknameService;
import dev.starcore.starcore.essentials.social.SocialService;
import dev.starcore.starcore.essentials.warp.WarpService;
import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/** Essentials 数据管理器 负责保存和加载所有 Essentials 数据 */
public final class EssentialsDataManager {
  private static final String HOME_RECORDS_PATH = "home-records";

  private final Plugin plugin;
  private final File dataFolder;

  private final HomeService homeService;
  private final WarpService warpService;
  private final NicknameService nicknameService;
  private final SocialService socialService;
  private final BalTopService balTopService;
  private final ExecutorService saveExecutor;
  private final Object saveLifecycleLock = new Object();
  private boolean saveExecutorClosed;

  public EssentialsDataManager(
      Plugin plugin,
      HomeService homeService,
      WarpService warpService,
      NicknameService nicknameService,
      SocialService socialService,
      BalTopService balTopService) {
    this(
        plugin,
        homeService,
        warpService,
        nicknameService,
        socialService,
        balTopService,
        createSaveExecutor());
  }

  EssentialsDataManager(
      Plugin plugin,
      HomeService homeService,
      WarpService warpService,
      NicknameService nicknameService,
      SocialService socialService,
      BalTopService balTopService,
      ExecutorService saveExecutor) {
    this.plugin = plugin;
    this.dataFolder = new File(plugin.getDataFolder(), "essentials");
    this.homeService = homeService;
    this.warpService = warpService;
    this.nicknameService = nicknameService;
    this.socialService = socialService;
    this.balTopService = balTopService;
    this.saveExecutor = Objects.requireNonNull(saveExecutor, "saveExecutor");

    // 创建数据文件夹
    if (!dataFolder.exists()) {
      dataFolder.mkdirs();
    }
  }

  /** 加载所有数据 */
  public void loadAll() {
    plugin.getLogger().info("正在加载 Essentials 数据...");

    loadWarps();
    loadPlayerData();
    loadBalTop();

    plugin.getLogger().info("✅ Essentials 数据加载完成");
  }

  /** 保存所有数据 */
  public void saveAll() {
    SaveSnapshot snapshot = captureSaveSnapshot();
    enqueueSave("all", () -> writeSaveSnapshot(snapshot)).join();
  }

  /** Captures Bukkit/service state on the caller thread, then writes files off-thread. */
  public CompletableFuture<Void> saveAllAsync() {
    try {
      SaveSnapshot snapshot = captureSaveSnapshot();
      return enqueueSave("all", () -> writeSaveSnapshot(snapshot));
    } catch (RuntimeException exception) {
      return failedSnapshot("all", exception);
    }
  }

  /** Captures player state before the quit listener clears its in-memory caches. */
  public CompletableFuture<Void> savePlayerDataAsync(UUID playerId) {
    String identity = "player:" + playerId;
    try {
      PlayerSnapshot snapshot = capturePlayerSnapshot(playerId);
      return enqueueSave(identity, () -> writePlayerSnapshot(playerId, snapshot));
    } catch (RuntimeException exception) {
      return failedSnapshot(identity, exception);
    }
  }

  private CompletableFuture<Void> failedSnapshot(String identity, RuntimeException failure) {
    plugin.getLogger().log(Level.SEVERE, "ESSENTIALS_SAVE_SNAPSHOT_FAILED " + identity, failure);
    return CompletableFuture.failedFuture(failure);
  }

  /** Writes the final snapshot after draining queued saves and then closes the writer. */
  public void shutdownAndSave() {
    synchronized (saveLifecycleLock) {
      if (saveExecutorClosed) {
        return;
      }
      saveExecutorClosed = true;
      try {
        SaveSnapshot snapshot = captureSaveSnapshot();
        submitSave("final", () -> writeSaveSnapshot(snapshot));
      } catch (RuntimeException exception) {
        plugin.getLogger().log(Level.SEVERE, "ESSENTIALS_FINAL_SAVE_REJECTED", exception);
      } finally {
        saveExecutor.shutdown();
      }
    }
    awaitSaveExecutorTermination();
  }

  private static ExecutorService createSaveExecutor() {
    return Executors.newSingleThreadExecutor(
        runnable -> {
          Thread thread = new Thread(runnable, "starcore-essentials-data-writer");
          thread.setDaemon(true);
          return thread;
        });
  }

  private CompletableFuture<Void> enqueueSave(String identity, Runnable save) {
    synchronized (saveLifecycleLock) {
      if (saveExecutorClosed) {
        return CompletableFuture.failedFuture(
            new RejectedExecutionException("Essentials data writer is closed"));
      }
      try {
        return submitSave(identity, save);
      } catch (RejectedExecutionException exception) {
        return CompletableFuture.failedFuture(exception);
      }
    }
  }

  private CompletableFuture<Void> submitSave(String identity, Runnable save) {
    return CompletableFuture.runAsync(save, saveExecutor)
        .whenComplete(
            (ignored, failure) -> {
              if (failure != null) {
                Throwable cause =
                    failure instanceof CompletionException && failure.getCause() != null
                        ? failure.getCause()
                        : failure;
                plugin.getLogger().log(Level.SEVERE, "ESSENTIALS_SAVE_FAILED " + identity, cause);
              }
            });
  }

  private void awaitSaveExecutorTermination() {
    try {
      if (!saveExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
        plugin.getLogger().severe("ESSENTIALS_SAVE_SHUTDOWN_TIMEOUT");
        saveExecutor.shutdownNow();
        if (!saveExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
          plugin.getLogger().severe("ESSENTIALS_SAVE_WRITER_STILL_RUNNING");
        }
      }
    } catch (InterruptedException exception) {
      Thread.currentThread().interrupt();
      saveExecutor.shutdownNow();
      plugin.getLogger().severe("ESSENTIALS_SAVE_SHUTDOWN_INTERRUPTED");
    }
  }

  private SaveSnapshot captureSaveSnapshot() {
    Map<String, LocationSnapshot> warps = snapshotLocations(warpService.saveData());
    Map<UUID, PlayerSnapshot> players = new LinkedHashMap<>();
    Set<UUID> playerIds = new LinkedHashSet<>();
    for (Player player : Bukkit.getOnlinePlayers()) {
      playerIds.add(player.getUniqueId());
    }
    playerIds.addAll(homeService.getKnownPlayerIds());
    playerIds.addAll(socialService.getKnownPlayerIds());
    playerIds.addAll(nicknameService.getAllNicknames().keySet());
    for (UUID playerId : playerIds) {
      players.put(playerId, capturePlayerSnapshot(playerId));
    }
    return new SaveSnapshot(warps, players, balTopService.persistenceSnapshot());
  }

  private PlayerSnapshot capturePlayerSnapshot(UUID playerId) {
    Map<String, LocationSnapshot> homes = snapshotLocations(homeService.getPlayerData(playerId));
    Set<UUID> ignored = Set.copyOf(socialService.getPlayerData(playerId));
    return new PlayerSnapshot(homes, nicknameService.getPlayerData(playerId), ignored);
  }

  private static Map<String, LocationSnapshot> snapshotLocations(Map<String, Location> locations) {
    Map<String, LocationSnapshot> snapshot = new LinkedHashMap<>();
    locations.forEach((name, location) -> snapshot.put(name, snapshotLocation(location)));
    return Map.copyOf(snapshot);
  }

  private static LocationSnapshot snapshotLocation(Location location) {
    if (location == null) {
      throw new IllegalStateException("Cannot persist a null location");
    }
    World world = location.getWorld();
    if (world == null) {
      throw new IllegalStateException("Cannot persist a location without a world");
    }
    return new LocationSnapshot(
        world.getName(),
        location.getX(),
        location.getY(),
        location.getZ(),
        location.getYaw(),
        location.getPitch());
  }

  private void writeSaveSnapshot(SaveSnapshot snapshot) {
    plugin.getLogger().info("正在保存 Essentials 数据...");
    List<RuntimeException> failures = new ArrayList<>();
    try {
      writeWarps(snapshot.warps());
    } catch (RuntimeException exception) {
      failures.add(exception);
    }
    snapshot
        .players()
        .forEach(
            (playerId, playerSnapshot) -> {
              try {
                writePlayerSnapshot(playerId, playerSnapshot);
              } catch (RuntimeException exception) {
                failures.add(exception);
              }
            });
    try {
      writeBalTop(snapshot.balTop());
    } catch (RuntimeException exception) {
      failures.add(exception);
    }
    if (!failures.isEmpty()) {
      IllegalStateException failure =
          new IllegalStateException("ESSENTIALS_SAVE_PARTIAL_FAILURE count=" + failures.size());
      failures.forEach(failure::addSuppressed);
      throw failure;
    }
    plugin.getLogger().info("✅ Essentials 数据保存完成");
  }

  private void writeWarps(Map<String, LocationSnapshot> warps) {
    YamlConfiguration config = new YamlConfiguration();
    int invalidEntries = 0;
    for (Map.Entry<String, LocationSnapshot> entry : warps.entrySet()) {
      if (!WarpService.isValidWarpName(entry.getKey())) {
        invalidEntries++;
        continue;
      }
      serializeLocation(config, "warps." + entry.getKey(), entry.getValue());
    }
    if (invalidEntries > 0) {
      plugin.getLogger().warning("ESSENTIALS_WARP_SAVE_SKIPPED invalidEntries=" + invalidEntries);
    }
    saveConfiguration(new File(dataFolder, "warps.yml"), config, "传送点");
  }

  private void writePlayerSnapshot(UUID playerId, PlayerSnapshot snapshot) {
    File playersFolder = new File(dataFolder, "players");
    if (!playersFolder.exists() && !playersFolder.mkdirs() && !playersFolder.isDirectory()) {
      throw new IllegalStateException(
          "ESSENTIALS_PLAYER_DIRECTORY_CREATE_FAILED: " + playersFolder);
    }

    YamlConfiguration config = new YamlConfiguration();
    snapshot
        .homes()
        .forEach(
            (name, location) -> {
              if (HomeService.isValidHomeName(name)) {
                serializeLocation(config, "homes." + name, location);
              } else {
                String recordPath = encodedHomeRecordPath(name);
                serializeLocation(config, recordPath, location);
                config.set(recordPath + ".name", name);
              }
            });
    if (snapshot.nickname() != null) {
      config.set("nickname", snapshot.nickname());
    }
    if (!snapshot.ignored().isEmpty()) {
      config.set("ignored", snapshot.ignored().stream().map(UUID::toString).toList());
    }
    saveConfiguration(
        new File(playersFolder, playerId + ".yml"), config, "玩家数据 (" + playerId + ")");
  }

  private void writeBalTop(BalTopService.PersistenceSnapshot snapshot) {
    YamlConfiguration config = new YamlConfiguration();
    balTopService.saveData(config, snapshot);
    saveConfiguration(new File(dataFolder, "baltop.yml"), config, "财富排行榜");
  }

  private void saveConfiguration(File file, YamlConfiguration config, String description) {
    try {
      AtomicFilePersistence.replace(file.toPath(), temporary -> config.save(temporary.toFile()));
    } catch (IOException exception) {
      throw new UncheckedIOException(
          "ESSENTIALS_FILE_SAVE_FAILED " + description + ": " + file, exception);
    }
  }

  private static void serializeLocation(
      YamlConfiguration config, String path, LocationSnapshot location) {
    config.set(path + ".world", location.worldName());
    config.set(path + ".x", location.x());
    config.set(path + ".y", location.y());
    config.set(path + ".z", location.z());
    config.set(path + ".yaw", location.yaw());
    config.set(path + ".pitch", location.pitch());
  }

  private static String encodedHomeRecordPath(String homeName) {
    String encodedName =
        Base64.getUrlEncoder()
            .withoutPadding()
            .encodeToString(homeName.getBytes(StandardCharsets.UTF_8));
    return HOME_RECORDS_PATH + ".h_" + encodedName;
  }

  /** 加载 Warps */
  private void loadWarps() {
    File warpsFile = new File(dataFolder, "warps.yml");
    YamlConfiguration config = loadYaml(warpsFile, "传送点");
    ConfigurationSection warpsSection = config.getConfigurationSection("warps");

    if (warpsSection == null) {
      return;
    }

    Map<String, Location> warps = new LinkedHashMap<>();

    for (String warpName : warpsSection.getKeys(false)) {
      Location location = deserializeLocation(warpsSection.getConfigurationSection(warpName));
      // Keep invalid entries visible to WarpService so its single validation boundary can report
      // the complete skipped count, including malformed or unloaded-world locations.
      warps.put(warpName, location);
    }

    warpService.loadData(warps);
    plugin.getLogger().info("已加载 " + warpService.getWarpCount() + " 个传送点");
  }

  /** 加载玩家数据 */
  private void loadPlayerData() {
    File playersFolder = new File(dataFolder, "players");
    if (!playersFolder.exists()) {
      return;
    }

    File[] playerFiles = playersFolder.listFiles((dir, name) -> name.endsWith(".yml"));
    if (playerFiles == null) {
      return;
    }

    int loaded = 0;
    for (File playerFile : playerFiles) {
      String fileName = playerFile.getName();
      String uuidString = fileName.substring(0, fileName.length() - 4);

      try {
        UUID playerId = UUID.fromString(uuidString);
        loadPlayerData(playerId, playerFile);
        loaded++;
      } catch (IllegalArgumentException e) {
        plugin.getLogger().warning("无效的玩家文件: " + fileName);
      } catch (IllegalStateException e) {
        plugin.getLogger().log(Level.SEVERE, "ESSENTIALS_PLAYER_LOAD_FAILED file=" + fileName, e);
      }
    }

    plugin.getLogger().info("已加载 " + loaded + " 个玩家数据");
  }

  /** 加载单个玩家数据 */
  public void loadPlayerData(UUID playerId, File file) {
    YamlConfiguration config = loadYaml(file, "玩家数据 (" + playerId + ")");

    // Load encoded records first, then fill gaps from legacy homes.<name> entries.
    Map<String, Location> homes = new HashMap<>();
    ConfigurationSection recordsSection = config.getConfigurationSection(HOME_RECORDS_PATH);
    if (recordsSection != null) {
      for (String recordKey : recordsSection.getKeys(false)) {
        ConfigurationSection record = recordsSection.getConfigurationSection(recordKey);
        if (record == null) {
          continue;
        }
        String homeName = record.getString("name");
        Location location = deserializeLocation(record);
        if (homeName != null && location != null) {
          homes.put(homeName, location);
        }
      }
    }

    ConfigurationSection homesSection = config.getConfigurationSection("homes");
    if (homesSection != null) {
      for (String homeName : homesSection.getKeys(false)) {
        Location location = deserializeLocation(homesSection.getConfigurationSection(homeName));

        if (location != null) {
          homes.putIfAbsent(homeName, location);
        }
      }
    }

    if (recordsSection != null || homesSection != null) {
      homeService.loadPlayerData(playerId, homes);
    }

    // 加载昵称
    if (config.contains("nickname")) {
      String nickname = config.getString("nickname");
      nicknameService.loadPlayerData(playerId, nickname);
    }

    // 加载屏蔽列表
    if (config.contains("ignored")) {
      List<String> ignoredList = config.getStringList("ignored");
      Set<UUID> ignored = new HashSet<>();

      for (String uuidStr : ignoredList) {
        try {
          ignored.add(UUID.fromString(uuidStr));
        } catch (IllegalArgumentException e) {
          // 跳过无效UUID
        }
      }

      socialService.loadPlayerData(playerId, ignored);
    }
  }

  /** 保存单个玩家数据 */
  public void savePlayerData(UUID playerId) {
    PlayerSnapshot snapshot = capturePlayerSnapshot(playerId);
    enqueueSave("player:" + playerId, () -> writePlayerSnapshot(playerId, snapshot)).join();
  }

  /** 序列化位置 */
  /** 反序列化位置 */
  private Location deserializeLocation(ConfigurationSection section) {
    if (section == null) {
      return null;
    }

    String worldName = section.getString("world");
    if (worldName == null || worldName.isBlank()) {
      return null;
    }

    Double x = finiteNumber(section, "x");
    Double y = finiteNumber(section, "y");
    Double z = finiteNumber(section, "z");
    Double yawValue = finiteNumber(section, "yaw");
    Double pitchValue = finiteNumber(section, "pitch");
    if (x == null || y == null || z == null || yawValue == null || pitchValue == null) {
      return null;
    }

    float yaw = yawValue.floatValue();
    float pitch = pitchValue.floatValue();
    if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) {
      return null;
    }

    World world = Bukkit.getWorld(worldName);
    if (world == null) {
      return null;
    }

    return new Location(world, x, y, z, yaw, pitch);
  }

  private static Double finiteNumber(ConfigurationSection section, String key) {
    // Bukkit's previous getDouble behavior treated absent coordinates and orientation as zero.
    // Preserve that legacy default while rejecting values that are present but malformed.
    if (!section.contains(key)) {
      return 0.0;
    }
    Object value = section.get(key);
    if (!(value instanceof Number number)) {
      return null;
    }
    double result = number.doubleValue();
    return Double.isFinite(result) ? result : null;
  }

  private YamlConfiguration loadYaml(File file, String description) {
    AtomicFilePersistence.RecoverySource recoverySource;
    try {
      recoverySource =
          AtomicFilePersistence.recover(file.toPath(), EssentialsDataManager::isValidYaml);
    } catch (IOException exception) {
      throw new IllegalStateException(
          "ESSENTIALS_FILE_RECOVERY_FAILED " + description + ": " + file, exception);
    }

    if (recoverySource == AtomicFilePersistence.RecoverySource.UNRECOVERABLE) {
      throw new IllegalStateException("ESSENTIALS_FILE_UNRECOVERABLE " + description + ": " + file);
    }
    if (recoverySource != AtomicFilePersistence.RecoverySource.CURRENT
        && recoverySource != AtomicFilePersistence.RecoverySource.MISSING) {
      plugin
          .getLogger()
          .warning(
              "ESSENTIALS_FILE_RECOVERED source="
                  + recoverySource
                  + " "
                  + description
                  + ": "
                  + file);
    }
    if (!file.isFile()) {
      return new YamlConfiguration();
    }

    YamlConfiguration configuration = new YamlConfiguration();
    try {
      configuration.load(file);
      return configuration;
    } catch (IOException | InvalidConfigurationException exception) {
      throw new IllegalStateException(
          "ESSENTIALS_FILE_LOAD_FAILED " + description + ": " + file, exception);
    }
  }

  private static boolean isValidYaml(Path path) {
    try {
      YamlConfiguration configuration = new YamlConfiguration();
      configuration.load(path.toFile());
      return true;
    } catch (IOException | InvalidConfigurationException exception) {
      return false;
    }
  }

  /** 加载财富排行榜数据 */
  private void loadBalTop() {
    File balTopFile = new File(dataFolder, "baltop.yml");
    YamlConfiguration config = loadYaml(balTopFile, "财富排行榜");
    balTopService.loadData(config);
    plugin.getLogger().info("已加载财富排行榜数据");
  }

  private record LocationSnapshot(
      String worldName, double x, double y, double z, float yaw, float pitch) {}

  private record PlayerSnapshot(
      Map<String, LocationSnapshot> homes, String nickname, Set<UUID> ignored) {
    private PlayerSnapshot {
      homes = Map.copyOf(homes);
      ignored = Set.copyOf(ignored);
    }
  }

  private record SaveSnapshot(
      Map<String, LocationSnapshot> warps,
      Map<UUID, PlayerSnapshot> players,
      BalTopService.PersistenceSnapshot balTop) {
    private SaveSnapshot {
      warps = Map.copyOf(warps);
      players = Map.copyOf(players);
    }
  }
}
