package dev.starcore.starcore.map;

/** 区域类型枚举 定义地图上的区域类型 */
public enum RegionKind {
  /** 公共节点：公共可访问的节点 */
  public_node("公共节点", "公共可访问"),

  /** 国家首都：国家的首都区域 */
  capital("首都", "国家中心"),

  /** 国家边疆：国家的边界区域 */
  frontier("边疆", "国家边界"),

  /** 中立地带：无主之地 */
  neutral("中立地带", "无主之地"),

  /** 战场：战争区域 */
  battlefield("战场", "战争区域"),

  /** 裂隙入口：裂隙生成区域 */
  rift_entry("裂隙入口", "裂隙生成区域"),

  /** 任务点：任务发生区域 */
  quest_point("任务点", "任务发生区"),

  /** 副本：可进入的副本区域 */
  dungeon("副本", "可进入副本"),

  /** 安全区：PvP保护区域 */
  safe_zone("安全区", "PvP保护"),

  /** 资源点：资源采集区域 */
  resource("资源点", "资源采集"),

  /** 商业区：交易市场 */
  market("商业区", "交易市场");

  private final String displayName;
  private final String description;

  RegionKind(String displayName, String description) {
    this.displayName = displayName;
    this.description = description;
  }

  public String getDisplayName() {
    return displayName;
  }

  public String getDescription() {
    return description;
  }

  /** 检查是否为PvP区域 */
  public boolean isPvPArea() {
    return this == battlefield || this == frontier || this == rift_entry;
  }

  /** 检查是否为安全区域 */
  public boolean isSafeArea() {
    return this == safe_zone || this == capital || this == neutral;
  }

  /** 检查是否可以生成裂隙 */
  public boolean canSpawnRift() {
    return this == public_node || this == neutral || this == rift_entry;
  }
}
