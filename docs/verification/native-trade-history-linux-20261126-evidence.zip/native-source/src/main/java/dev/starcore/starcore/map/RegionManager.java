package dev.starcore.starcore.map;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** 区域管理器 管理所有地图区域 */
public class RegionManager {

  private final Map<String, Region> regions = new ConcurrentHashMap<>();
  private final Map<String, Set<String>> nationRegions = new ConcurrentHashMap<>();
  private final Map<String, Set<String>> worldRegions = new ConcurrentHashMap<>();

  /** 注册区域 */
  public void registerRegion(Region region) {
    Objects.requireNonNull(region, "region");
    Region previous = regions.put(region.regionId(), region);
    if (previous != null) {
      removeFromIndexes(previous);
    }

    if (region.hasNation()) {
      nationRegions
          .computeIfAbsent(region.nationId(), k -> ConcurrentHashMap.newKeySet())
          .add(region.regionId());
    }

    worldRegions
        .computeIfAbsent(region.world(), k -> ConcurrentHashMap.newKeySet())
        .add(region.regionId());
  }

  /** 获取区域 */
  public Optional<Region> getRegion(String regionId) {
    if (regionId == null || regionId.isBlank()) return Optional.empty();
    Region region = regions.get(regionId);
    return region != null && region.isAccessible() ? Optional.of(region) : Optional.empty();
  }

  /** 获取国家的所有区域 */
  public Set<Region> getNationRegions(String nationId) {
    if (nationId == null || nationId.isBlank()) return Set.of();
    Set<String> regionIds = nationRegions.get(nationId);
    if (regionIds == null) return Set.of();

    Set<Region> result = new HashSet<>();
    for (String id : regionIds) {
      Region region = regions.get(id);
      if (region != null && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取世界的所有区域 */
  public Set<Region> getWorldRegions(String world) {
    if (world == null || world.isBlank()) return Set.of();
    Set<String> regionIds = worldRegions.get(world);
    if (regionIds == null) return Set.of();

    Set<Region> result = new HashSet<>();
    for (String id : regionIds) {
      Region region = regions.get(id);
      if (region != null && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取指定类型的区域 */
  public Set<Region> getRegionsByKind(RegionKind kind) {
    if (kind == null) return Set.of();
    Set<Region> result = new HashSet<>();
    for (Region region : regions.values()) {
      if (region.kind() == kind && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取连接到指定区域的区域 */
  public Set<Region> getConnectedRegions(String regionId) {
    if (regionId == null || regionId.isBlank()) return Set.of();
    Region region = regions.get(regionId);
    if (region == null) return Set.of();

    Set<Region> result = new HashSet<>();
    for (String connectedId : region.connectedRegions()) {
      Region connected = regions.get(connectedId);
      if (connected != null && connected.isAccessible()) {
        result.add(connected);
      }
    }
    return result;
  }

  /** 获取可生成裂隙的区域 */
  public Set<Region> getRiftSpawnableRegions() {
    Set<Region> result = new HashSet<>();
    for (Region region : regions.values()) {
      if (region.kind().canSpawnRift() && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取PvP区域 */
  public Set<Region> getPvPRegions() {
    Set<Region> result = new HashSet<>();
    for (Region region : regions.values()) {
      if (region.kind().isPvPArea() && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取安全区域 */
  public Set<Region> getSafeRegions() {
    Set<Region> result = new HashSet<>();
    for (Region region : regions.values()) {
      if (region.kind().isSafeArea() && region.isAccessible()) {
        result.add(region);
      }
    }
    return result;
  }

  /** 获取区域数量 */
  public int getRegionCount() {
    return regions.size();
  }

  /** 获取国家区域数量 */
  public int getNationRegionCount(String nationId) {
    if (nationId == null || nationId.isBlank()) return 0;
    return nationRegions.getOrDefault(nationId, Set.of()).size();
  }

  /** 检查区域是否存在 */
  public boolean regionExists(String regionId) {
    return regionId != null && regions.containsKey(regionId);
  }

  /** 移除区域 */
  public boolean removeRegion(String regionId) {
    Region region = regions.remove(regionId);
    if (region == null) return false;

    removeFromIndexes(region);

    return true;
  }

  private void removeFromIndexes(Region region) {
    if (region.hasNation()) {
      Set<String> ids = nationRegions.get(region.nationId());
      if (ids != null) {
        ids.remove(region.regionId());
        if (ids.isEmpty()) {
          nationRegions.remove(region.nationId(), ids);
        }
      }
    }
    Set<String> worldIds = worldRegions.get(region.world());
    if (worldIds != null) {
      worldIds.remove(region.regionId());
      if (worldIds.isEmpty()) {
        worldRegions.remove(region.world(), worldIds);
      }
    }
  }

  /** 清理所有区域 */
  public void clear() {
    regions.clear();
    nationRegions.clear();
    worldRegions.clear();
  }

  /** 根据坐标查找区域 */
  public Optional<Region> findRegionByPosition(String world, int x, int y, int z) {
    if (world == null || world.isBlank()) return Optional.empty();
    Set<String> regionIds = worldRegions.get(world);
    if (regionIds == null) return Optional.empty();

    for (String id : regionIds) {
      Region region = regions.get(id);
      if (region != null && region.x() == x && region.y() == y && region.z() == z) {
        return Optional.of(region);
      }
    }
    return Optional.empty();
  }

  /** 获取所有区域 */
  public Set<Region> getAllRegions() {
    return Set.copyOf(regions.values());
  }
}
