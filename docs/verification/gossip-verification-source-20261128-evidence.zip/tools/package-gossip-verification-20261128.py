from pathlib import Path
import hashlib,json,subprocess,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda data:hashlib.sha256(data).hexdigest()
tests=json.loads((root/'run/native-gossip-verification-focused-1-20261128/result.json').read_text())
pair=json.loads((root/'run/gossip-verification-pair-artifacts-1-20261128/result.json').read_text())
assert tests['validation_success'] and tests['packaging_executed'] and not tests['source_drift']
assert all(tests['totals'][key]==0 for key in ('failures','errors','skipped'))
assert pair['status']=='VERIFIED'
offline=json.loads((root/'run/gossip-verification-offline-1-20261128/result.json').read_text())
assert offline['status']=='VERIFIED'
files={}
for label,name in [('validation','native-gossip-verification-focused-1-20261128'),('pair','gossip-verification-pair-artifacts-1-20261128'),('frozen','gossip-verification-frozen-pair-1-20261128'),('offline','gossip-verification-offline-1-20261128')]:
    base=root/'run'/name
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix not in ('.jar','.class'):
            files[label+'/'+path.relative_to(base).as_posix()]=path
for name in ['tools/verify-processing-merge-artifacts.py','tools/snapshot-maven-validation.py','run/validate-gossip-verification-20261128.py','run/freeze-gossip-verification-20261128.py','run/package-gossip-verification-20261128.py','run/gossip-verification-format-20261128.log','tools/verify-social-verification.py','tools/SocialVerificationProbe.java']:
    files['tools/'+Path(name).name]=root/name
manifest={name:sha(path.read_bytes()) for name,path in sorted(files.items())}
summary={'status':'VERIFIED','server_started':False,
    'native_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip(),
    'tests':tests['totals'],'required_suites':tests['required_suites'],
    'artifacts':json.loads((root/'run/gossip-verification-frozen-pair-1-20261128/manifest.json').read_text()),
    'fixtures_compiled':pair['fixtures']['count'],'offline_runs':len(offline['runs']),'offline_checks':offline['checks'],
    'limits':['Related tests only; not the entire StarCore suite.',
              'Gossip schema2 and verification commit in one file; persistence still rewrites the entire checkpoint.',
              'Reputation rewards occur after durable processed/debunk status and are never automatically replayed; a crash can omit a reward.',
              'File-only serial JVM probes; no live server, MySQL, full Folia or long concurrent load acceptance.']}
out=root/'docs/verification/gossip-verification-source-20261128-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as archive:
    for name,path in sorted(files.items()):archive.write(path,name)
    archive.writestr('manifest.json',json.dumps({'summary':summary,'files':manifest},ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out) as archive:
    assert set(archive.namelist())==set(manifest)|{'manifest.json'}
    for name,digest in manifest.items():assert sha(archive.read(name))==digest,name
summary.update(evidence_members=len(manifest)+1,evidence_bytes=out.stat().st_size,evidence_sha256=sha(out.read_bytes()),files=manifest)
(root/'docs/verification/gossip-verification-source-20261128-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:summary[key] for key in ('native_commit','tests','evidence_members','evidence_bytes','evidence_sha256')}))
