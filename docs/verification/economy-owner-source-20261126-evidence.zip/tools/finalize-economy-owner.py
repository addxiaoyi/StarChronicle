from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile

root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest();files={};runs={}
def add(path,name):files[name]=path.read_bytes()
for phase in ('baseline','baseline-fixed','compile','test-initial','compile-final','test-final','compile-callback','test-callback','package','sbom','artifacts'):
 directory=root/'run'/('economy-owner-'+phase+'-20261126')
 runs[phase]=json.loads((directory/'result.json').read_text(encoding='utf-8'))
 for path in sorted(directory.rglob('*')):
  if path.is_file() and path.suffix in ('.json','.xml','.java','.log','.txt'):add(path,phase+'/'+path.relative_to(directory).as_posix())
 if phase not in ('baseline','baseline-fixed'):assert runs[phase].get('exit_code',0)==0,phase
totals=dict(tests=0,failures=0,errors=0,skipped=0)
for path in (root/'run/economy-owner-test-callback-20261126/surefire').glob('*.xml'):
 suite=ET.parse(path).getroot()
 for key in totals:totals[key]+=int(suite.get(key,0))
assert totals==runs['test-callback']['totals']==dict(tests=389,failures=0,errors=0,skipped=0)
assert runs['baseline-fixed']['totals']==dict(tests=17,failures=17,errors=0,skipped=0)
assert runs['test-initial']['totals']==dict(tests=382,failures=0,errors=0,skipped=0)
assert runs['test-final']['totals']==dict(tests=387,failures=0,errors=0,skipped=0)
names=['src/main/java/dev/starcore/starcore/essentials/EssentialsModule.java',
 'src/main/java/dev/starcore/starcore/essentials/command/EconomyCommand.java',
 'src/test/java/dev/starcore/starcore/essentials/command/EconomyOwnershipTest.java',
 'src/test/java/dev/starcore/starcore/essentials/command/EconomyCommandThreadingTest.java',
 'src/test/java/dev/starcore/starcore/essentials/EssentialsModuleLifecycleTest.java',
 'src/test/java/dev/starcore/starcore/core/database/MySqlConnectionRecoveryIntegrationTest.java',
 'docs/ECONOMY-COMMAND-OWNERSHIP.md','docs/ESSENTIALS-COMMAND-LIFECYCLE.md']
for name in names+['pom.xml','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties']:add(native/name,'starcore/'+name)
for name in ('starcore-1.0.0-sbom.json','starcore-1.0.0-sbom.xml'):add(native/'target'/name,'sbom/'+name)
for name in ('run-economy-owner.py','verify-economy-owner-artifacts.py','finalize-economy-owner.py'):add(root/'run'/name,'tools/'+name)
for name in ('command-lifecycle-ci-success-20261126.log','command-lifecycle-final-ci-20261126.json','command-lifecycle-delivery-git-20261126.json'):add(root/'run'/name,'previous-command-ci/'+name)
files['starcore/change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=native)
plugin=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
sources=sha((root/'target/starchronicle-0.1.0-SNAPSHOT-sources.jar').read_bytes())
core=sha((native/'target/starcore-1.0.0.jar').read_bytes())
assert core==runs['artifacts']['starcore_sha256']
assert plugin=='1c7b8b010c9d330c15b0882753d54095fb906e42caedb926a81055d643cd78ce'
summary={'date':'2026-11-26','scope':'Pay original-session owner capture and independent feedback, selected-page leaderboard profile lookup, module lifetime and provider-aware snapshot routing. No Minecraft.',
 'baseline_commits':{'starchronicle':'182895c1b153f9ffbe3aa05150c6a403c104a34d','starcore':'6af2a974992bb9b385e67a22bd5c03add99eebb4'},
 'new_tests':33,'tests':totals,'baseline_tests':runs['baseline-fixed']['totals'],'intermediate_tests':runs['test-initial']['totals'],
 'initial_failure':'New test fixture used an ambiguous overloaded Server.getOfflinePlayer argument. Compilation failed before tests; fixed the UUID type and preserved that log. Production was still unchanged for the 17-test baseline.',
 'artifacts':{'starchronicle_sha256':plugin,'sources_sha256':sources,'starcore_sha256':core},'artifact_verification':runs['artifacts'],
 'source_hashes':{name:sha((native/name).read_bytes()) for name in names},
 'limits':['No real Minecraft, MySQL, Vault binary or live Paper/Folia reload.',
  'Pay keeps its existing asynchronous financial provider contract; this does not certify arbitrary Vault provider threading or uncertain transfer results.',
  'InternalEconomyService snapshots are async; other providers keep Paper main-thread refresh. Folia refuses an unverified external refresh but can display already fresh cached entries.',
  'Already admitted UUID transfers may finish after reconnect. Module stop suppresses queued work/late feedback but does not roll back a running financial operation.',
  'Ranking values and names are snapshots sampled at different times, not a cross-player atomic view.',
  'Balance/admin commands, tab-completion names, social calls and the separate periodic ranking refresh remain separate work.',
  '389 selected tests, existing POM exclusions retained, not the complete native suite.',
  'MySQL recovery fixture was adapted and compiled, but the real MySQL acceptance was not run.',
  'Single 256 MiB JVM per operation; forkCount=0, jacoco.skip=true; no local coverage result.',
  'Chronicle main JAR and prior 1021-test local result unchanged. Earlier contracts and regressions retain their own JAR identities.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{k:sha(v) for k,v in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/economy-owner-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
 for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
 manifest=json.loads(archive.read('manifest.json'));assert set(archive.namelist())==set(manifest['files'])|{'manifest.json'}
 for name,digest in manifest['files'].items():assert sha(archive.read(name))==digest
summary['evidence_files']=len(files);summary['evidence_zip_sha256']=sha(output.read_bytes())
(output.parent/'economy-owner-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# 转账与排行榜玩家所有权：源码验证 2026-11-26

原 /pay 在发送者线程读取另一玩家在线状态和名字；排行榜强制使用旧 Bukkit 主线程入口，跨线程／重连后的反馈没有确切会话核验。本次分别采集原玩家信息、隔离金融提交与消息反馈，并按提供者线程能力、当前页及原查看者组织排行榜查询。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{core}` |
| Chronicle，主构件保持 | `{plugin}` |
| Chronicle 源码 JAR | `{sources}` |
| 证据 ZIP | `{summary['evidence_zip_sha256']}` |

基线 Chronicle `182895c`、StarCore `6af2a97`。[证据 ZIP](verification/economy-owner-source-20261126-evidence.zip) **{len(files)} 文件**；[机器摘要](verification/economy-owner-source-20261126-summary.json)。包含源码、失败、所有最终 XML、构建／SBOM／API 与类字节核对、工具，以及上一命令检查点 CI #179 的成功日志和交付 Git 核对。没有启动 Minecraft。

## 行为与边界

- /pay 在发送者 owner 捕获自身身份，目标 owner 采集目标名字后回原发送者 owner 复核会话，再进入异步资金操作。读取玩家前核验 online 与服务器同 UUID 的当前对象；目标退休／注册拒绝、目标采集前重连或发送者最终复核前重连不付款；两位玩家是分别检查，不是原子共同在线判断。
- 金融执行与反馈分开。接收任一玩家的消息调度失败不反转已 COMMITTED 的交易，也不阻止另一通知。已准入转账是 UUID 账户操作，可以在玩家断线／重连后完成，但原会话的消息不能交给新会话。
- 排行榜复制最多 100 条数据、先夹紧页码，每页最多查询 10 个名字；自带 InternalEconomyService 快照异步读取，外部 EconomyService 保持 Paper 主线程刷新。Folia 不调用尚无线程保证的外部刷新，明确显示暂不可用；已经新鲜的缓存可以展示。
- 离线档案异步查询；如果返回在线 Player，只在其 owner 读取名字。缺失名字、退休和注册拒绝使用 UUID。自己的排名和余额来自同一份排名快照，最终不可变消息回原查看者 owner、控制台全局线程或命令方块的捕获位置区域。
- Essentials 传入绑定本次启用的生命周期谓词。停用后旧排队任务不再开始，迟到结果不显示；重启不会激活旧命令实例。正在执行的交易完成账本，不承诺回滚或等待全部在途工作。原构造器保持，额外谓词构造器为新增。

玩家入口仍要求已在发起玩家 owner；排名、名字是不同时间采集的快照，不是跨玩家共同事务。本次保持 /pay 既有的异步经济提供者契约，没有新增持久请求编号、提供者幂等保证或未知转账结果恢复，也没有认证任意 Vault 的线程支持。

## 验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现所有权基线 | 17 | 17 | 0 | 0 |
| 初轮相关回归 | 382 | 0 | 0 | 0 |
| 提供者与模块接线回归 | 387 | 0 | 0 | 0 |
| 补齐玩家回调异常后的最终相关回归 | **389** | **0** | **0** | **0** |

新增 33 项：32 项命令所有权／提供者测试，1 项真实模块启停接线测试。独立 owner 队列断言跨玩家名字／在线／消息访问，禁止旧 Bukkit 调度入口；金融工作在异步队列，外部排行榜刷新验证 Paper 全局路径。覆盖重连、退休／拒绝、重复回调、已提交反馈失败、启动／停用、控制台／命令方块、页码、UUID 回退与旧构造器路由。最终再补充在线名字读取及会话核验抛错，确保单个玩家回调异常仍释放查询并避免付款。

最初新夹具的 getOfflinePlayer 参数缺少 UUID 类型，重载歧义导致测试编译失败；修正后旧实现 17 个失败均为行为断言，原始记录保留。旧经济线程测试适配新的队列／会话核验；MySQL 恢复夹具也已适配并编译，未运行真实 MySQL。没有新增 POM 排除。

Spotless、2,266 主源／1,088 测试源编译、389 项相关回归、独立打包和在线 36 组件 SBOM 通过；最终 5 个相关类与已测 target/classes 字节一致，Java 21 与旧公开方法声明／描述符保持。每次单个 256 MiB JVM、forkCount=0、jacoco.skip=true，无本机覆盖率；389 项不是全库测试。

Chronicle 主构件沿用 NPC 检查点本地 1,021 项结果，本轮未本地重跑；新文档提交后独立跟踪 Linux CI。原 356／339／302／1,131 项和国库、贸易、工厂契约继续保持各自构件边界。StarCore 现有工作流不覆盖非 main 基线草稿 PR。

下一步继续余额／管理命令、名字补全、社交及独立排行榜周期任务；外部提供者线程与不确定结果、其他 runSync／runNextTick 和完整热重载仍待处理。实际 NPC／保护组合、当前实服、全栈 Folia 和长期容量尚待验收；十阶段未全部完成。
'''
(root/'docs/ECONOMY-OWNER-SOURCE-20261126.md').write_text(report,encoding='utf-8')
print(json.dumps({'evidence_files':len(files),'evidence_sha256':summary['evidence_zip_sha256'],'artifacts':summary['artifacts'],'tests':totals}))
