package dev.starcore.starcore.essentials.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.*;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Answers;
import org.mockito.MockedStatic;

/** Owner queues reject foreign entity access and economy work on player/global callbacks. */
class EconomyOwnershipTest {
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final Map<UUID, Player> online = new HashMap<>();
  private final Map<Player, State> states = new IdentityHashMap<>();
  private final Map<UUID, OfflinePlayer> offline = new HashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private final List<String> consoleMessages = new ArrayList<>();
  private Player owner, sender, target, rejectOwner;
  private String mode = "caller";
  private boolean enabled = true, rejectAsync;
  private EconomyService economy;
  private FoliaCompatScheduler scheduler;
  private BalTopService rankings;
  private EconomyCommand command;
  private MockedStatic<Bukkit> bukkit;
  private int transfers;
  private boolean enough = true;

  private static final class State {
    UUID id;
    String name;
    boolean online = true;
    final List<String> messages = new ArrayList<>();
  }

  private record Job(String kind, Player player, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() {
    when(plugin.isEnabled()).thenAnswer(i -> enabled);
    when(plugin.getName()).thenReturn("StarCore");
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(plugin.getServer()).thenReturn(server);
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertEquals("async", mode, "offline profile lookup must not block an owner");
              UUID id = i.getArgument(0);
              return online.containsKey(id) ? online.get(id) : offline.get(id);
            });
    when(server.getScheduler()).thenThrow(new AssertionError("legacy Bukkit scheduler"));
    scheduler =
        mock(
            FoliaCompatScheduler.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("runAtEntity")) {
                Player p = i.getArgument(0);
                if (p == rejectOwner) throw new IllegalStateException("owner rejected");
                Runnable retired = i.getArguments().length == 3 ? i.getArgument(2) : () -> {};
                jobs.add(
                    new Job(
                        "owner",
                        p,
                        () -> i.<Consumer<Object>>getArgument(1).accept(null),
                        retired));
                return null;
              }
              if (method.equals("runAsync") || method.equals("runGlobal")) {
                if (method.equals("runAsync") && rejectAsync)
                  throw new IllegalStateException("async rejected");
                jobs.add(
                    new Job(
                        method.equals("runAsync") ? "async" : "global",
                        null,
                        i.getArgument(0),
                        () -> {}));
                return null;
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    economy =
        mock(
            EconomyService.class,
            i -> {
              if (Set.of("has", "transfer", "getAllBalances", "getBalance")
                  .contains(i.getMethod().getName())) {
                assertEquals("async", mode, "blocking economy work on " + mode);
                return switch (i.getMethod().getName()) {
                  case "has" -> enough;
                  case "transfer" -> {
                    transfers++;
                    yield true;
                  }
                  case "getBalance" -> BigDecimal.TEN;
                  default -> Map.of();
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    rankings = new BalTopService();
    command = new EconomyCommand(plugin, economy, rankings, null, scheduler);
    sender = player("Sender", UUID.randomUUID());
    target = player("Target", UUID.randomUUID());
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(() -> Bukkit.getPlayer("Target")).thenReturn(target);
    bukkit
        .when(() -> Bukkit.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(i -> server.getOfflinePlayer(i.<UUID>getArgument(0)));
  }

  @AfterEach
  void cleanup() {
    bukkit.close();
  }

  private Player player(String name, UUID id) {
    State state = new State();
    state.name = name;
    state.id = id;
    Player p =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (Set.of("getName", "isOnline", "getServer", "sendMessage").contains(method)) {
                assertSame(i.getMock(), owner, "foreign entity " + name + "." + method);
                return switch (method) {
                  case "getName" -> name;
                  case "isOnline" -> state.online;
                  case "getServer" -> server;
                  default -> {
                    state.messages.add(text(i.getArgument(0)));
                    yield null;
                  }
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    states.put(p, state);
    online.put(id, p);
    return p;
  }

  private static String text(Object message) {
    return message instanceof Component c
        ? PlainTextComponentSerializer.plainText().serialize(c)
        : String.valueOf(message);
  }

  private void owned(Player p, Runnable action) {
    Player before = owner;
    String old = mode;
    owner = p;
    mode = "owner";
    try {
      action.run();
    } finally {
      owner = before;
      mode = old;
    }
  }

  private void run(Job job) {
    Player before = owner;
    String old = mode;
    owner = job.player;
    mode = job.kind;
    try {
      job.body.run();
    } finally {
      owner = before;
      mode = old;
    }
  }

  private void drain() {
    int count = 100;
    while (!jobs.isEmpty()) {
      assertTrue(count-- > 0);
      run(jobs.remove());
    }
  }

  private void invoke(CommandSender audience, String name, String... args) {
    Command invoked = mock(Command.class);
    when(invoked.getName()).thenReturn(name);
    if (audience instanceof Player p) owned(p, () -> command.onCommand(p, invoked, name, args));
    else command.onCommand(audience, invoked, name, args);
  }

  private void pay() {
    invoke(sender, "pay", "Target", "25");
  }

  private void admitPay() {
    pay();
    while (!jobs.isEmpty() && !jobs.peek().kind.equals("async")) run(jobs.remove());
    assertFalse(jobs.isEmpty());
  }

  private UUID id(Player p) {
    return states.get(p).id;
  }

  private void disconnected(Player p) {
    states.get(p).online = false;
    online.remove(id(p));
  }

  private CommandSender console() {
    return mock(
        CommandSender.class,
        i -> {
          if (i.getMethod().getName().equals("sendMessage")) {
            assertEquals("global", mode);
            consoleMessages.add(text(i.getArgument(0)));
            return null;
          }
          return Answers.RETURNS_DEFAULTS.answer(i);
        });
  }

  private UUID offline(String name) {
    UUID id = UUID.randomUUID();
    OfflinePlayer p = mock(OfflinePlayer.class);
    when(p.getName())
        .thenAnswer(
            i -> {
              assertEquals("async", mode);
              return name;
            });
    offline.put(id, p);
    return id;
  }

  @Test
  void payCapturesEachNameOnItsOwnerAndRunsLedgerWorkOffThread() {
    pay();
    drain();
    assertEquals(1, transfers);
    assertTrue(states.get(target).messages.stream().anyMatch(s -> s.contains("Sender")));
  }

  @Test
  void targetReconnectionBeforeCaptureDoesNotChargeSender() {
    pay();
    player("Replacement", id(target));
    drain();
    assertEquals(0, transfers);
  }

  @Test
  void senderReconnectionBeforeAdmissionDoesNotCharge() {
    pay();
    player("Replacement", id(sender));
    drain();
    assertEquals(0, transfers);
  }

  @Test
  void targetRetirementBeforeCaptureDoesNotCharge() {
    pay();
    Job pending = jobs.remove();
    assertSame(target, pending.player);
    pending.retired.run();
    drain();
    assertEquals(0, transfers);
  }

  @Test
  void targetSchedulerRejectionDoesNotCharge() {
    rejectOwner = target;
    pay();
    drain();
    assertEquals(0, transfers);
    assertTrue(
        states.get(sender).messages.stream().anyMatch(s -> s.contains("失败") || s.contains("不可用")));
  }

  @Test
  void asyncRejectionReportsToOriginalSender() {
    rejectAsync = true;
    pay();
    drain();
    assertEquals(0, transfers);
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("失败")));
  }

  @Test
  void committedPaySurvivesFeedbackSchedulingFailure(@TempDir Path path) {
    TransactionFabric fabric =
        new TransactionFabric(path.resolve("ledger.properties"), Logger.getAnonymousLogger());
    command = new EconomyCommand(plugin, economy, rankings, fabric, scheduler);
    admitPay();
    rejectOwner = sender;
    drain();
    assertEquals(1, transfers);
    assertEquals(EconomyTransactionState.COMMITTED, fabric.snapshot().getFirst().state());
    assertTrue(states.get(target).messages.stream().anyMatch(s -> s.contains("Sender")));
  }

  @Test
  void admittedPayCanFinishAfterReconnectWithoutOldSessionFeedback() {
    admitPay();
    int before = states.get(sender).messages.size();
    player("Replacement", id(sender));
    drain();
    assertEquals(1, transfers);
    assertEquals(before, states.get(sender).messages.size());
  }

  @Test
  void insufficientBalanceIsCheckedAsynchronously() {
    enough = false;
    pay();
    drain();
    assertEquals(0, transfers);
    assertTrue(states.get(sender).messages.contains("余额不足"));
  }

  @Test
  void leaderboardUsesOfflineNamesOffThreadAndOriginalPlayerForReply() {
    UUID other = offline("Archived");
    rankings.updateRankings(Map.of(other, BigDecimal.TEN, id(sender), BigDecimal.ONE));
    invoke(sender, "baltop");
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("Archived")));
  }

  @Test
  void leaderboardOnlineNamesAreCapturedOnTheirOwnOwners() {
    rankings.updateRankings(Map.of(id(target), BigDecimal.TEN));
    invoke(sender, "baltop");
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("Target")));
  }

  @Test
  void leaderboardConsoleReplyUsesGlobalScheduler() {
    rankings.updateRankings(Map.of(offline("Archived"), BigDecimal.TEN));
    invoke(console(), "baltop");
    drain();
    assertTrue(consoleMessages.stream().anyMatch(s -> s.contains("Archived")));
  }

  @Test
  void leaderboardReconnectCannotReceiveOldReply() {
    rankings.updateRankings(Map.of(offline("Archived"), BigDecimal.TEN));
    invoke(sender, "baltop");
    Player replacement = player("Replacement", id(sender));
    drain();
    assertTrue(states.get(sender).messages.isEmpty());
    assertTrue(states.get(replacement).messages.isEmpty());
  }

  @Test
  void leaderboardRetiredNameLookupUsesStableUuidFallback() {
    rankings.updateRankings(Map.of(id(target), BigDecimal.TEN));
    invoke(sender, "baltop");
    run(jobs.remove());
    Job name = jobs.remove();
    assertSame(target, name.player);
    name.retired.run();
    drain();
    assertTrue(
        states.get(sender).messages.stream().anyMatch(s -> s.contains(id(target).toString())));
  }

  @Test
  void leaderboardOnlyResolvesTheSelectedPageAndClampsLargePage() {
    Map<UUID, BigDecimal> balances = new LinkedHashMap<>();
    List<UUID> ids = new ArrayList<>();
    for (int n = 0; n < 11; n++) {
      UUID id = offline("Archive" + n);
      ids.add(id);
      balances.put(id, BigDecimal.valueOf(100 - n));
    }
    rankings.updateRankings(balances);
    invoke(sender, "baltop", String.valueOf(Integer.MAX_VALUE));
    drain();
    verify(server).getOfflinePlayer(ids.get(10));
    for (int n = 0; n < 10; n++) verify(server, never()).getOfflinePlayer(ids.get(n));
  }

  @Test
  void leaderboardMissingNameUsesUuid() {
    UUID id = offline(null);
    rankings.updateRankings(Map.of(id, BigDecimal.TEN));
    invoke(sender, "baltop");
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains(id.toString())));
  }

  @Test
  void disabledPluginCannotBeginQueuedRankingWork() {
    invoke(sender, "baltop");
    enabled = false;
    drain();
    verify(economy, never()).getAllBalances();
    assertTrue(states.get(sender).messages.isEmpty());
  }

  @Test
  void stoppedModuleCannotBeginAnAdmittedButNotStartedTransfer() {
    boolean[] active = {true};
    command =
        new EconomyCommand(
            plugin,
            economy,
            rankings,
            null,
            scheduler,
            EssentialsPermissions.defaults(),
            () -> active[0]);
    admitPay();
    active[0] = false;
    drain();
    assertEquals(0, transfers);
  }

  @Test
  void alreadyStartedTransferCommitsAcrossModuleStopWithoutFeedback(@TempDir Path path) {
    boolean[] active = {true};
    TransactionFabric fabric =
        new TransactionFabric(path.resolve("ledger.properties"), Logger.getAnonymousLogger());
    command =
        new EconomyCommand(
            plugin,
            economy,
            rankings,
            fabric,
            scheduler,
            EssentialsPermissions.defaults(),
            () -> active[0]);
    doAnswer(
            i -> {
              assertEquals("async", mode);
              transfers++;
              active[0] = false;
              return true;
            })
        .when(economy)
        .transfer(any(), any(), any());
    admitPay();
    int before = states.get(sender).messages.size();
    drain();
    assertEquals(1, transfers);
    assertEquals(EconomyTransactionState.COMMITTED, fabric.snapshot().getFirst().state());
    assertEquals(before, states.get(sender).messages.size());
    assertTrue(states.get(target).messages.isEmpty());
  }

  @Test
  void oldModuleRankingResultIsSuppressed() {
    boolean[] active = {true};
    command =
        new EconomyCommand(
            plugin,
            economy,
            rankings,
            null,
            scheduler,
            EssentialsPermissions.defaults(),
            () -> active[0]);
    rankings.updateRankings(Map.of(offline("Archived"), BigDecimal.TEN));
    invoke(sender, "baltop");
    run(jobs.remove());
    active[0] = false;
    drain();
    assertTrue(states.get(sender).messages.isEmpty());
  }

  @Test
  void targetOwnerCallbackReplayCannotSubmitTwoTransfers() {
    pay();
    Job capture = jobs.remove();
    run(capture);
    run(capture);
    capture.retired.run();
    drain();
    assertEquals(1, transfers);
  }

  @Test
  void leaderboardFailureIsDeliveredOnViewerOwner() {
    doThrow(new IllegalStateException("unavailable")).when(economy).getAllBalances();
    invoke(sender, "baltop");
    drain();
    assertTrue(states.get(sender).messages.stream().anyMatch(s -> s.contains("更新失败")));
  }

  @Test
  void leaderboardNameSchedulerRejectionUsesUuidFallback() {
    rejectOwner = target;
    rankings.updateRankings(Map.of(id(target), BigDecimal.TEN));
    invoke(sender, "baltop");
    drain();
    assertTrue(
        states.get(sender).messages.stream().anyMatch(s -> s.contains(id(target).toString())));
  }

  @Test
  void leaderboardNameCallbackReplayCannotDuplicateReply() {
    rankings.updateRankings(Map.of(id(target), BigDecimal.TEN));
    invoke(sender, "baltop");
    run(jobs.remove());
    Job capture = jobs.remove();
    run(capture);
    run(capture);
    capture.retired.run();
    drain();
    assertEquals(2, states.get(sender).messages.size());
  }

  @Test
  void invalidAmountNeverSchedulesAnotherPlayer() {
    invoke(sender, "pay", "Target", "-1");
    assertTrue(jobs.isEmpty());
    assertEquals(0, transfers);
  }

  @Test
  void commandBlockRankingReplyUsesCapturedRegion() {
    World world = mock(World.class);
    Location location = new Location(world, 2, 65, 3);
    org.bukkit.block.Block block = mock(org.bukkit.block.Block.class);
    when(block.getLocation()).thenReturn(location);
    BlockCommandSender blockSender = mock(BlockCommandSender.class);
    when(blockSender.getBlock()).thenReturn(block);
    doAnswer(
            i -> {
              assertEquals("region", mode);
              return null;
            })
        .when(blockSender)
        .sendMessage(any(Component.class));
    doAnswer(
            i -> {
              Location captured = i.getArgument(0);
              assertNotSame(location, captured);
              assertEquals(location, captured);
              jobs.add(
                  new Job(
                      "region",
                      null,
                      () -> i.<Consumer<Object>>getArgument(1).accept(null),
                      () -> {}));
              return null;
            })
        .when(scheduler)
        .runAtLocation(any(), any());
    invoke(blockSender, "baltop");
    drain();
    verify(blockSender).sendMessage(any(Component.class));
  }
}
