package dev.starcore.starcore.essentials.command;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRequest;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** 经济命令 /bal, /baltop, /pay, /eco */
public final class EconomyCommand implements CommandExecutor, TabCompleter {
  private final Plugin plugin;
  private final EconomyService economyService;
  private final BalTopService balTopService;
  private final TransactionFabric transactionFabric;
  private volatile FoliaCompatScheduler scheduler;
  private final EssentialsPermissions permissions;
  private final BooleanSupplier lifecycleActive;

  public EconomyCommand(Plugin plugin, EconomyService economyService, BalTopService balTopService) {
    this(plugin, economyService, balTopService, null, null, EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric) {
    this(
        plugin,
        economyService,
        balTopService,
        transactionFabric,
        null,
        EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric,
      FoliaCompatScheduler scheduler) {
    this(
        plugin,
        economyService,
        balTopService,
        transactionFabric,
        scheduler,
        EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric,
      FoliaCompatScheduler scheduler,
      EssentialsPermissions permissions) {
    this(
        plugin,
        economyService,
        balTopService,
        transactionFabric,
        scheduler,
        permissions,
        () -> true);
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric,
      FoliaCompatScheduler scheduler,
      EssentialsPermissions permissions,
      BooleanSupplier lifecycleActive) {
    this.plugin = plugin;
    this.economyService = economyService;
    this.balTopService = balTopService;
    this.transactionFabric = transactionFabric;
    this.scheduler = scheduler;
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
    this.lifecycleActive = java.util.Objects.requireNonNull(lifecycleActive, "lifecycleActive");
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    if (!isActive()) return true;
    String commandName = command.getName().toLowerCase(Locale.ROOT);

    switch (commandName) {
      case "balance", "bal", "money" -> handleBalance(sender, args);
      case "baltop" -> handleBalTop(sender, args);
      case "pay" -> handlePay(sender, args);
      case "eco", "economy" -> handleEco(sender, args);
    }

    return true;
  }

  /** 查看余额 */
  private void handleBalance(CommandSender sender, String[] args) {
    Player target;

    if (args.length > 0) {
      // 查看其他玩家
      if (!EssentialsPermissions.permits(sender, permissions.balanceOthers())) {
        sender.sendMessage(Component.text("你没有权限查看其他玩家的余额", NamedTextColor.RED));
        return;
      }

      target = Bukkit.getPlayer(args[0]);
      if (target == null) {
        sender.sendMessage(Component.text("玩家不在线: " + args[0], NamedTextColor.RED));
        return;
      }
    } else {
      // 查看自己
      if (!(sender instanceof Player player)) {
        sender.sendMessage(Component.text("请指定玩家", NamedTextColor.RED));
        return;
      }
      target = player;
    }

    BigDecimal balance = economyService.getBalance(target.getUniqueId());

    sender.sendMessage(
        Component.text(target.getName() + " 的余额: ", NamedTextColor.YELLOW)
            .append(
                Component.text(
                    String.format("%.2f 金币", balance.doubleValue()), NamedTextColor.GREEN)));
  }

  /** Ranking data and offline profiles may block; only detached results cross owner queues. */
  private void handleBalTop(CommandSender sender, String[] args) {
    if (!isActive()) return;
    Audience audience = audience(sender);
    int requestedPage = 1;
    if (args.length > 0) {
      try {
        requestedPage = Integer.parseInt(args[0]);
      } catch (NumberFormatException ignored) {
        /* First page. */
      }
    }
    int page = requestedPage;
    UUID viewer = sender instanceof Player player ? player.getUniqueId() : null;
    try {
      runAsync(
          () -> {
            if (!isActive()) return;
            try {
              if (balTopService.needsUpdate()) {
                balTopService.updateRankings(economyService.getAllBalances());
              }
              prepareBalTop(audience, viewer, page, List.copyOf(balTopService.getTopPlayers(100)));
            } catch (RuntimeException failure) {
              dispatchAudience(
                  audience,
                  () ->
                      sender.sendMessage(
                          Component.text(
                              "财富排行榜更新失败: " + safeMessage(failure), NamedTextColor.RED)));
            }
          });
    } catch (RuntimeException failure) {
      dispatchAudience(
          audience, () -> sender.sendMessage(Component.text("财富排行榜当前不可用", NamedTextColor.RED)));
    }
  }

  private String safeMessage(RuntimeException exception) {
    String message = exception.getMessage();
    return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
  }

  private void prepareBalTop(
      Audience audience, UUID viewer, int requestedPage, List<BalTopService.BalTopEntry> entries) {
    if (entries.isEmpty()) {
      dispatchAudience(
          audience,
          () -> audience.sender.sendMessage(Component.text("暂无排行榜数据", NamedTextColor.YELLOW)));
      return;
    }
    int pages = (entries.size() + 9) / 10;
    int page = Math.max(1, Math.min(requestedPage, pages));
    int start = (page - 1) * 10;
    List<BalTopService.BalTopEntry> selected =
        entries.subList(start, Math.min(start + 10, entries.size()));
    String[] names = new String[selected.size()];
    AtomicInteger remaining = new AtomicInteger(selected.size());
    for (int i = 0; i < selected.size(); i++) {
      int slot = i;
      UUID id = selected.get(i).playerId();
      resolveRankingName(
          id,
          name -> {
            names[slot] = name;
            if (remaining.decrementAndGet() == 0) {
              List<Component> lines = new ArrayList<>();
              lines.add(
                  Component.text(
                      "========== 财富排行榜 (第" + page + "/" + pages + "页) ==========",
                      NamedTextColor.GOLD));
              for (int n = 0; n < selected.size(); n++) {
                int rank = start + n;
                String marker =
                    switch (rank) {
                      case 0 -> "❶";
                      case 1 -> "❷";
                      case 2 -> "❸";
                      default -> "#" + (rank + 1);
                    };
                lines.add(
                    Component.text(
                        String.format(
                            "%s %s - %.2f 金币",
                            marker, names[n], selected.get(n).balance().doubleValue()),
                        NamedTextColor.YELLOW));
              }
              for (int rank = 0; viewer != null && rank < entries.size(); rank++) {
                BalTopService.BalTopEntry entry = entries.get(rank);
                if (entry.playerId().equals(viewer)) {
                  lines.add(
                      Component.text(
                          String.format(
                              "你的排名: #%d (%.2f 金币)", rank + 1, entry.balance().doubleValue()),
                          NamedTextColor.GRAY));
                  break;
                }
              }
              List<Component> result = List.copyOf(lines);
              dispatchAudience(audience, () -> result.forEach(audience.sender::sendMessage));
            }
          });
    }
  }

  private void resolveRankingName(UUID id, Consumer<String> result) {
    String fallback = id.toString();
    AtomicBoolean completed = new AtomicBoolean();
    Consumer<String> once =
        name -> {
          if (completed.compareAndSet(false, true)) result.accept(name);
        };
    try {
      OfflinePlayer profile = plugin.getServer().getOfflinePlayer(id);
      if (profile instanceof Player player) {
        runAtEntity(
            player,
            () -> once.accept(displayName(player.getName(), fallback)),
            () -> once.accept(fallback));
      } else {
        once.accept(displayName(profile == null ? null : profile.getName(), fallback));
      }
    } catch (RuntimeException failure) {
      once.accept(fallback);
    }
  }

  private static String displayName(String name, String fallback) {
    return name == null || name.isBlank() ? fallback : name;
  }

  /** 转账 */
  private void handlePay(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage(Component.text("只有玩家可以使用此命令", NamedTextColor.RED));
      return;
    }

    if (args.length < 2) {
      sender.sendMessage(Component.text("用法: /pay <玩家> <金额>", NamedTextColor.YELLOW));
      return;
    }

    Player target = Bukkit.getPlayer(args[0]);
    if (target == null) {
      sender.sendMessage(Component.text("玩家不在线: " + args[0], NamedTextColor.RED));
      return;
    }

    if (target.equals(player)) {
      sender.sendMessage(Component.text("你不能转账给自己", NamedTextColor.RED));
      return;
    }

    BigDecimal amount;
    try {
      amount = new BigDecimal(args[1]);
    } catch (NumberFormatException e) {
      sender.sendMessage(Component.text("无效的金额: " + args[1], NamedTextColor.RED));
      return;
    }

    if (amount.compareTo(BigDecimal.ZERO) <= 0) {
      sender.sendMessage(Component.text("金额必须大于0", NamedTextColor.RED));
      return;
    }

    UUID playerId = player.getUniqueId();
    UUID targetId = target.getUniqueId();
    String playerName = player.getName();
    runAtEntity(
        target,
        () -> {
          String targetName = target.getName();
          runAtEntity(
              player,
              () -> {
                sender.sendMessage(Component.text("转账处理中...", NamedTextColor.GRAY));
                try {
                  runAsync(
                      () ->
                          executePay(
                              player, target, playerId, targetId, amount, playerName, targetName));
                } catch (RuntimeException schedulingFailure) {
                  dispatchPlayerMessage(player, "转账失败：服务器正在关闭或经济任务不可用", NamedTextColor.RED);
                }
              },
              () -> {});
        },
        () -> dispatchPlayerMessage(player, "转账失败：目标玩家当前不可用", NamedTextColor.RED));
  }

  private void executePay(
      Player sender,
      Player target,
      UUID playerId,
      UUID targetId,
      BigDecimal amount,
      String senderName,
      String targetName) {
    if (!isActive()) return;
    TransactionRecord transaction = null;
    boolean success = false;
    try {
      // Vault providers and transaction persistence may block, so keep the complete
      // durable operation off the Paper/Folia entity thread.
      if (!economyService.has(playerId, amount)) {
        dispatchPlayerMessage(sender, "余额不足", NamedTextColor.RED);
        return;
      }

      transaction = beginPayTransaction(playerId, targetId, amount);
      if (transaction == null && transactionFabric != null) {
        dispatchPlayerMessage(sender, "转账失败：交易台账不可用", NamedTextColor.RED);
        return;
      }

      try {
        success = economyService.transfer(playerId, targetId, amount);
      } catch (RuntimeException exception) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Unable to execute /pay", exception);
        success = false;
      }
      if (success) {
        try {
          completePayTransaction(transaction);
        } catch (RuntimeException ledgerFailure) {
          markPayManualReview(transaction, ledgerFailure);
        }
      } else {
        failPayTransaction(transaction, "pay transfer rejected by economy service");
      }
    } catch (RuntimeException failure) {
      failPayTransaction(transaction, "pay transfer could not be completed");
      plugin
          .getLogger()
          .log(java.util.logging.Level.SEVERE, "Unable to prepare /pay transfer", failure);
      success = false;
    }
    // Feedback availability cannot change a committed financial result.
    dispatchPayResult(sender, target, amount, senderName, targetName, transaction, success);
  }

  private void dispatchPayResult(
      Player sender,
      Player target,
      BigDecimal amount,
      String senderName,
      String targetName,
      TransactionRecord transaction,
      boolean success) {
    runAtEntity(
        sender,
        () -> {
          if (!sender.isOnline()) {
            return;
          }
          if (success) {
            sender.sendMessage(
                Component.text(
                    String.format("已转账 %.2f 金币给 %s", amount.doubleValue(), targetName),
                    NamedTextColor.GREEN));
          } else {
            sender.sendMessage(
                Component.text(
                    transaction == null
                        ? "转账失败"
                        : "转账失败 [交易ID: " + transaction.transactionId() + "]",
                    NamedTextColor.RED));
          }
        });
    if (success) {
      runAtEntity(
          target,
          () -> {
            if (target.isOnline()) {
              target.sendMessage(
                  Component.text(
                      String.format("收到来自 %s 的 %.2f 金币", senderName, amount.doubleValue()),
                      NamedTextColor.GREEN));
            }
          });
    }
  }

  private void dispatchPlayerMessage(Player player, String message, NamedTextColor color) {
    runAtEntity(
        player,
        () -> {
          if (player.isOnline()) {
            player.sendMessage(Component.text(message, color));
          }
        });
  }

  private boolean isActive() {
    return plugin.isEnabled() && lifecycleActive.getAsBoolean();
  }

  private synchronized FoliaCompatScheduler scheduler() {
    if (scheduler == null) scheduler = new FoliaCompatScheduler(plugin);
    return scheduler;
  }

  private void runAsync(Runnable task) {
    scheduler()
        .runAsync(
            () -> {
              if (isActive()) task.run();
            });
  }

  private void runAtEntity(Player player, Runnable task) {
    runAtEntity(player, task, () -> {});
  }

  private void runAtEntity(Player player, Runnable task, Runnable unavailable) {
    if (!isActive()) {
      unavailable.run();
      return;
    }
    AtomicBoolean claimed = new AtomicBoolean();
    Runnable retired =
        () -> {
          if (claimed.compareAndSet(false, true)) unavailable.run();
        };
    try {
      scheduler()
          .runAtEntity(
              player,
              ignored -> {
                if (!claimed.compareAndSet(false, true)) return;
                if (isActive()
                    && player.isOnline()
                    && player.getServer().getPlayer(player.getUniqueId()) == player) task.run();
                else unavailable.run();
              },
              retired);
    } catch (RuntimeException rejected) {
      retired.run();
    }
  }

  private record Audience(CommandSender sender, Location region) {}

  private Audience audience(CommandSender sender) {
    return new Audience(
        sender,
        sender instanceof BlockCommandSender block ? block.getBlock().getLocation().clone() : null);
  }

  private void dispatchAudience(Audience audience, Runnable task) {
    if (audience.sender instanceof Player player) {
      runAtEntity(player, task);
      return;
    }
    Runnable guarded =
        () -> {
          if (isActive()) task.run();
        };
    try {
      if (audience.region != null)
        scheduler().runAtLocation(audience.region, ignored -> guarded.run());
      else scheduler().runGlobal(guarded);
    } catch (RuntimeException ignored) {
      // Reply scheduling cannot alter a completed read or financial operation.
    }
  }

  private TransactionRecord beginPayTransaction(UUID from, UUID to, BigDecimal amount) {
    if (transactionFabric == null) {
      return null;
    }
    String idempotencyKey = "player-transfer:" + from + ":" + to + ":" + UUID.randomUUID();
    TransactionRecord record =
        transactionFabric.begin(
            new TransactionRequest(
                from,
                amount,
                RefundOwner.SYSTEM,
                TransactionType.PLAYER_TRANSFER,
                "pay:" + from + ":" + to,
                idempotencyKey,
                Map.of("from", from.toString(), "to", to.toString())));
    try {
      return transitionPayTransaction(
          record, EconomyTransactionState.RESERVED, "pay transfer reserved");
    } catch (RuntimeException reservationFailure) {
      failPayTransaction(record, "pay transfer reservation could not be persisted");
      throw reservationFailure;
    }
  }

  private void completePayTransaction(TransactionRecord record) {
    if (record == null || transactionFabric == null) {
      return;
    }
    TransactionRecord current =
        transitionPayTransaction(record, EconomyTransactionState.DEBITED, "pay sender debited");
    current =
        transitionPayTransaction(
            current, EconomyTransactionState.DELIVERED, "pay recipient credited");
    transitionPayTransaction(current, EconomyTransactionState.COMMITTED, "pay transfer committed");
  }

  private void failPayTransaction(TransactionRecord record, String message) {
    if (record == null || transactionFabric == null) {
      return;
    }
    try {
      TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
      if (!current.state().isTerminal()) {
        transactionFabric.fail(current.transactionId(), message);
      }
    } catch (RuntimeException failure) {
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Unable to persist /pay failure state; manual review required",
              failure);
    }
  }

  private void markPayManualReview(TransactionRecord record, RuntimeException failure) {
    if (record == null || transactionFabric == null) {
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Pay succeeded but its ledger could not commit",
              failure);
      return;
    }
    try {
      TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
      if (current.state().canTransitionTo(EconomyTransactionState.MANUAL_REVIEW)) {
        transactionFabric.markManualReview(
            current.transactionId(), "pay transfer committed; ledger completion requires review");
      }
    } catch (RuntimeException manualReviewFailure) {
      manualReviewFailure.addSuppressed(failure);
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Unable to mark /pay transaction for manual review",
              manualReviewFailure);
    }
  }

  private TransactionRecord transitionPayTransaction(
      TransactionRecord record, EconomyTransactionState state, String message) {
    if (record == null || transactionFabric == null) {
      return record;
    }
    TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
    if (current.state() == state) {
      return current;
    }
    if (!current.state().canTransitionTo(state)) {
      throw new IllegalStateException(
          "Cannot transition player transfer " + current.state() + " -> " + state);
    }
    return transactionFabric.transition(current.transactionId(), state, message);
  }

  /** 经济管理命令 */
  private void handleEco(CommandSender sender, String[] args) {
    if (!EssentialsPermissions.permits(sender, permissions.economyAdmin())) {
      sender.sendMessage(Component.text("你没有权限使用此命令", NamedTextColor.RED));
      return;
    }

    if (args.length < 3) {
      sender.sendMessage(
          Component.text("用法: /eco <give|take|set> <玩家> <金额>", NamedTextColor.YELLOW));
      return;
    }

    String action = args[0].toLowerCase(Locale.ROOT);
    Player target = Bukkit.getPlayer(args[1]);

    if (target == null) {
      sender.sendMessage(Component.text("玩家不在线: " + args[1], NamedTextColor.RED));
      return;
    }

    BigDecimal amount;
    try {
      amount = new BigDecimal(args[2]);
    } catch (NumberFormatException e) {
      sender.sendMessage(Component.text("无效的金额: " + args[2], NamedTextColor.RED));
      return;
    }

    boolean success =
        switch (action) {
          case "give" -> economyService.deposit(target.getUniqueId(), amount);
          case "take" -> economyService.withdraw(target.getUniqueId(), amount);
          case "set" -> economyService.setBalance(target.getUniqueId(), amount);
          default -> {
            sender.sendMessage(Component.text("无效的操作: " + action, NamedTextColor.RED));
            yield false;
          }
        };

    if (success) {
      BigDecimal newBalance = economyService.getBalance(target.getUniqueId());
      sender.sendMessage(
          Component.text(
              String.format(
                  "已%s %s %.2f 金币，当前余额: %.2f",
                  action.equals("give") ? "给予" : action.equals("take") ? "扣除" : "设置",
                  target.getName(),
                  amount.doubleValue(),
                  newBalance.doubleValue()),
              NamedTextColor.GREEN));
    } else {
      sender.sendMessage(Component.text("操作失败", NamedTextColor.RED));
    }
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    if (!isActive()) return List.of();
    String commandName = command.getName().toLowerCase(Locale.ROOT);

    if (commandName.equals("pay") && args.length == 1) {
      List<String> players = new ArrayList<>();
      for (Player p : Bukkit.getOnlinePlayers()) {
        if (!p.equals(sender)) {
          players.add(p.getName());
        }
      }
      return players;
    }

    if (commandName.equals("eco")) {
      if (args.length == 1) {
        return List.of("give", "take", "set");
      } else if (args.length == 2) {
        List<String> players = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
          players.add(p.getName());
        }
        return players;
      }
    }

    return List.of();
  }
}
