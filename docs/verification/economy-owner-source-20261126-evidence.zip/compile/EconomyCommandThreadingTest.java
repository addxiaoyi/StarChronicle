package dev.starcore.starcore.essentials.command;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;

class EconomyCommandThreadingTest {

  @Test
  void ecoActionNormalizationDoesNotDependOnDefaultLocale() {
    Locale originalLocale = Locale.getDefault();
    try {
      Locale.setDefault(Locale.forLanguageTag("tr-TR"));
      Plugin plugin = mock(Plugin.class);
      when(plugin.isEnabled()).thenReturn(true);
      EconomyService economy = mock(EconomyService.class);
      BalTopService balTop = mock(BalTopService.class);
      CommandSender sender = mock(CommandSender.class);
      Command command = mock(Command.class);
      Player target = mock(Player.class);
      UUID targetId = UUID.randomUUID();
      BigDecimal amount = new BigDecimal("5");

      when(command.getName()).thenReturn("ECO");
      when(sender.hasPermission("starcore.eco.admin")).thenReturn(true);
      when(target.getUniqueId()).thenReturn(targetId);
      when(target.getName()).thenReturn("StarBob");
      when(economy.deposit(targetId, amount)).thenReturn(true);
      when(economy.getBalance(targetId)).thenReturn(new BigDecimal("15"));

      EconomyCommand executor = new EconomyCommand(plugin, economy, balTop);
      try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
        bukkit.when(() -> Bukkit.getPlayer("StarBob")).thenReturn(target);
        executor.onCommand(sender, command, "ECO", new String[] {"GIVE", "StarBob", "5"});
      }

      verify(economy).deposit(targetId, amount);
    } finally {
      Locale.setDefault(originalLocale);
    }
  }

  @Test
  void balTopReadsProfilesAndEconomyOffThreadAndRepliesOnGlobalScheduler() {
    Plugin plugin = mock(Plugin.class);
    when(plugin.isEnabled()).thenReturn(true);
    Server server = mock(Server.class);
    FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
    EconomyService economy = mock(EconomyService.class);
    BalTopService balTop = mock(BalTopService.class);
    CommandSender sender = mock(CommandSender.class);
    Command command = mock(Command.class);
    Map<UUID, BigDecimal> balances = Map.of(UUID.randomUUID(), BigDecimal.TEN);

    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getServer()).thenReturn(server);
    doAnswer(
            i -> {
              i.<Runnable>getArgument(0).run();
              return null;
            })
        .when(scheduler)
        .runGlobal(any());
    when(command.getName()).thenReturn("baltop");
    when(balTop.needsUpdate()).thenReturn(true);
    when(economy.getAllBalances()).thenReturn(balances);
    when(balTop.getTopPlayers(100)).thenReturn(java.util.List.of());

    EconomyCommand executor = new EconomyCommand(plugin, economy, balTop, null, scheduler);
    executor.onCommand(sender, command, "baltop", new String[0]);

    verify(economy, never()).getAllBalances();
    verify(sender, never()).sendMessage(any(Component.class));
    ArgumentCaptor<Runnable> callback = ArgumentCaptor.forClass(Runnable.class);
    verify(scheduler).runAsync(callback.capture());

    callback.getValue().run();

    verify(economy).getAllBalances();
    verify(balTop).updateRankings(balances);
    verify(sender).sendMessage(any(Component.class));
  }

  @Test
  void balTopClampsInvalidPagesBeforeCalculatingStartIndex() {
    Plugin plugin = mock(Plugin.class);
    when(plugin.isEnabled()).thenReturn(true);
    Server server = mock(Server.class);
    FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
    EconomyService economy = mock(EconomyService.class);
    BalTopService balTop = mock(BalTopService.class);
    CommandSender sender = mock(CommandSender.class);
    Command command = mock(Command.class);
    OfflinePlayer offlinePlayer = mock(OfflinePlayer.class);
    List<BalTopService.BalTopEntry> entries =
        java.util.stream.IntStream.range(0, 11)
            .mapToObj(
                index ->
                    new BalTopService.BalTopEntry(
                        UUID.randomUUID(), BigDecimal.valueOf(100 - index)))
            .toList();

    when(plugin.isEnabled()).thenReturn(true);
    when(plugin.getServer()).thenReturn(server);
    doAnswer(
            i -> {
              i.<Runnable>getArgument(0).run();
              return null;
            })
        .when(scheduler)
        .runGlobal(any());
    when(command.getName()).thenReturn("baltop");
    when(balTop.needsUpdate()).thenReturn(false);
    when(balTop.getTopPlayers(100)).thenReturn(entries);
    when(offlinePlayer.getName()).thenReturn("Player");

    EconomyCommand executor = new EconomyCommand(plugin, economy, balTop, null, scheduler);
    ArgumentCaptor<Runnable> callbacks = ArgumentCaptor.forClass(Runnable.class);

    executor.onCommand(sender, command, "baltop", new String[] {"0"});
    verify(scheduler).runAsync(callbacks.capture());
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      when(server.getOfflinePlayer(any(UUID.class))).thenReturn(offlinePlayer);
      assertDoesNotThrow(callbacks.getValue()::run);
    }

    executor.onCommand(sender, command, "baltop", new String[] {"99"});
    verify(scheduler, org.mockito.Mockito.times(2)).runAsync(callbacks.capture());
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      when(server.getOfflinePlayer(any(UUID.class))).thenReturn(offlinePlayer);
      assertDoesNotThrow(callbacks.getValue()::run);
      verify(server, atLeastOnce()).getOfflinePlayer(entries.get(10).playerId());
    }
  }

  @Test
  void balTopDoesNothingAfterPluginDisable() {
    Plugin plugin = mock(Plugin.class);
    when(plugin.isEnabled()).thenReturn(true);
    EconomyService economy = mock(EconomyService.class);
    BalTopService balTop = mock(BalTopService.class);
    CommandSender sender = mock(CommandSender.class);
    Command command = mock(Command.class);
    when(plugin.isEnabled()).thenReturn(false);
    when(command.getName()).thenReturn("baltop");

    EconomyCommand executor = new EconomyCommand(plugin, economy, balTop);
    executor.onCommand(sender, command, "baltop", new String[0]);

    verify(plugin, never()).getServer();
    verify(economy, never()).getAllBalances();
    verify(sender, never()).sendMessage(any(Component.class));
  }

  @Test
  void payRunsAllBlockingEconomyWorkAsynchronouslyAndReportsOnEntitySchedulers(
      @TempDir Path tempDir) throws Exception {
    Plugin plugin = mock(Plugin.class);
    when(plugin.isEnabled()).thenReturn(true);
    EconomyService economy = mock(EconomyService.class);
    BalTopService balTop = mock(BalTopService.class);
    FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
    Player sender = mock(Player.class);
    Player target = mock(Player.class);
    Command command = mock(Command.class);
    UUID senderId = UUID.randomUUID();
    UUID targetId = UUID.randomUUID();
    BigDecimal amount = new BigDecimal("25");

    when(command.getName()).thenReturn("pay");
    when(sender.getUniqueId()).thenReturn(senderId);
    when(sender.getName()).thenReturn("StarAlice");
    when(sender.isOnline()).thenReturn(true);
    when(target.getUniqueId()).thenReturn(targetId);
    when(target.getName()).thenReturn("StarBob");
    when(target.isOnline()).thenReturn(true);
    Server server = mock(Server.class);
    when(sender.getServer()).thenReturn(server);
    when(target.getServer()).thenReturn(server);
    when(server.getPlayer(senderId)).thenReturn(sender);
    when(server.getPlayer(targetId)).thenReturn(target);
    when(economy.has(senderId, amount)).thenReturn(true);
    when(economy.transfer(senderId, targetId, amount)).thenReturn(true);
    doAnswer(
            invocation -> {
              @SuppressWarnings("unchecked")
              Consumer<Object> callback = (Consumer<Object>) invocation.getArgument(1);
              callback.accept(null);
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(Player.class), any(), any());

    Path transactionFile = tempDir.resolve("transactions.properties");
    TransactionFabric fabric =
        new TransactionFabric(transactionFile, java.util.logging.Logger.getLogger("pay-test"));
    EconomyCommand executor = new EconomyCommand(plugin, economy, balTop, fabric, scheduler);
    ArgumentCaptor<Runnable> asyncWork = ArgumentCaptor.forClass(Runnable.class);
    try (MockedStatic<Bukkit> bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getPlayer("StarBob")).thenReturn(target);

      executor.onCommand(sender, command, "pay", new String[] {"StarBob", "25"});

      verify(economy, never()).has(senderId, amount);
      verify(economy, never()).transfer(senderId, targetId, amount);
      assertFalse(Files.exists(transactionFile));
      verify(scheduler).runAsync(asyncWork.capture());

      asyncWork.getValue().run();

      verify(economy).has(senderId, amount);
      verify(economy).transfer(senderId, targetId, amount);
      verify(sender, atLeastOnce()).sendMessage(any(Component.class));
      verify(target).sendMessage(any(Component.class));
      assertEquals(1, fabric.snapshot().size());
      assertEquals(EconomyTransactionState.COMMITTED, fabric.snapshot().get(0).state());
    }
  }
}
