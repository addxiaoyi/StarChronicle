# Essentials command ownership and shutdown

Essentials resolves each command using the plugin's lowercase namespace first, with a bare-name fallback only when the PluginCommand belongs to the same Plugin instance. It never installs its handlers into another plugin's command. Aliases sharing one PluginCommand are bound once.

Each enable installs fresh executor/completer wrappers, retaining the previous handlers. These wrappers become callable only after all services, listeners and timers have initialized. Disable first invalidates every wrapper and releases its service delegate. Captured handlers remain inactive after re-enable, so they cannot mutate the previous home's data or expose its completion results. Inactive commands return a module-unavailable message; inactive completion returns an empty list rather than falling back to platform player-name completion.

Disable restores each previous executor/completer independently and only if that slot still contains its exact installed wrapper. A later replacement from another module is preserved. Partial registration is tracked before either setter, so enable failures also restore commands. The PluginCommand remains registered, including its namespaced labels and aliases; this is handler restoration, not removal from the server command map.

Teardown attempts all command restorations, scheduler cancellation, listener removal and final data-writer shutdown even if a previous cleanup fails. The first exception is rethrown and additional failures are suppressed. A wrapper that cannot be physically restored is still inactive and no longer retains its service delegate. Teardown failure is reported; it is not a claim that every registration was successfully restored.

Enable/disable and command-map changes require the normal server lifecycle context. Command invocation still requires the caller's appropriate player/console context. A callback already admitted before disable may finish, including business effects and asynchronous work; these changes provide neither rollback nor a wait for all command continuations. Other modules' lifecycle, GUI inventory ownership, social/economy remote-player access and full live Paper/Folia hot reload remain separate work.

The later [pay and leaderboard ownership change](ECONOMY-COMMAND-OWNERSHIP.md) gives those two workflows their own enable-lifetime check, original-session replies and provider-aware scheduling. It still permits an already-running transfer to finish, and does not cover every command continuation.

The companion Chronicle repository records exact build identities, the old-implementation regression and final selected test results in docs/COMMAND-LIFECYCLE-SOURCE-20261126.md. These tests instantiate the actual Paper API PluginCommand class with mocked server/services, without starting Minecraft.
