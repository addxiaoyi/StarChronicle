package dev.starcore.starcore.essentials.command;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.foundation.economy.EconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRequest;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** 经济命令 /bal, /baltop, /pay, /eco */
public final class EconomyCommand implements CommandExecutor, TabCompleter {
  private final Plugin plugin;
  private final EconomyService economyService;
  private final BalTopService balTopService;
  private final TransactionFabric transactionFabric;
  private final FoliaCompatScheduler scheduler;
  private final EssentialsPermissions permissions;

  public EconomyCommand(Plugin plugin, EconomyService economyService, BalTopService balTopService) {
    this(plugin, economyService, balTopService, null, null, EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric) {
    this(
        plugin,
        economyService,
        balTopService,
        transactionFabric,
        null,
        EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric,
      FoliaCompatScheduler scheduler) {
    this(
        plugin,
        economyService,
        balTopService,
        transactionFabric,
        scheduler,
        EssentialsPermissions.defaults());
  }

  public EconomyCommand(
      Plugin plugin,
      EconomyService economyService,
      BalTopService balTopService,
      TransactionFabric transactionFabric,
      FoliaCompatScheduler scheduler,
      EssentialsPermissions permissions) {
    this.plugin = plugin;
    this.economyService = economyService;
    this.balTopService = balTopService;
    this.transactionFabric = transactionFabric;
    this.scheduler = scheduler;
    this.permissions = permissions == null ? EssentialsPermissions.defaults() : permissions;
  }

  @Override
  public boolean onCommand(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String label,
      @NotNull String[] args) {
    String commandName = command.getName().toLowerCase(Locale.ROOT);

    switch (commandName) {
      case "balance", "bal", "money" -> handleBalance(sender, args);
      case "baltop" -> handleBalTop(sender, args);
      case "pay" -> handlePay(sender, args);
      case "eco", "economy" -> handleEco(sender, args);
    }

    return true;
  }

  /** 查看余额 */
  private void handleBalance(CommandSender sender, String[] args) {
    Player target;

    if (args.length > 0) {
      // 查看其他玩家
      if (!EssentialsPermissions.permits(sender, permissions.balanceOthers())) {
        sender.sendMessage(Component.text("你没有权限查看其他玩家的余额", NamedTextColor.RED));
        return;
      }

      target = Bukkit.getPlayer(args[0]);
      if (target == null) {
        sender.sendMessage(Component.text("玩家不在线: " + args[0], NamedTextColor.RED));
        return;
      }
    } else {
      // 查看自己
      if (!(sender instanceof Player player)) {
        sender.sendMessage(Component.text("请指定玩家", NamedTextColor.RED));
        return;
      }
      target = player;
    }

    BigDecimal balance = economyService.getBalance(target.getUniqueId());

    sender.sendMessage(
        Component.text(target.getName() + " 的余额: ", NamedTextColor.YELLOW)
            .append(
                Component.text(
                    String.format("%.2f 金币", balance.doubleValue()), NamedTextColor.GREEN)));
  }

  /** 财富排行榜 */
  private void handleBalTop(CommandSender sender, String[] args) {
    if (!plugin.isEnabled()) return;
    try {
      plugin
          .getServer()
          .getScheduler()
          .runTask(
              plugin,
              () -> {
                if (!plugin.isEnabled()) return;
                try {
                  if (balTopService.needsUpdate()) {
                    Map<UUID, BigDecimal> allBalances = economyService.getAllBalances();
                    balTopService.updateRankings(allBalances);
                  }
                  displayBalTop(sender, args);
                } catch (RuntimeException exception) {
                  sender.sendMessage(
                      Component.text("财富排行榜更新失败: " + safeMessage(exception), NamedTextColor.RED));
                }
              });
    } catch (IllegalStateException ignored) {
      // Plugin shutdown raced with command scheduling.
    }
  }

  private String safeMessage(RuntimeException exception) {
    String message = exception.getMessage();
    return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
  }

  /** 显示排行榜 */
  private void displayBalTop(CommandSender sender, String[] args) {
    int page = 1;
    if (args.length > 0) {
      try {
        page = Integer.parseInt(args[0]);
      } catch (NumberFormatException e) {
        page = 1;
      }
    }

    int pageSize = 10;
    List<BalTopService.BalTopEntry> topPlayers = balTopService.getTopPlayers(100);

    if (topPlayers.isEmpty()) {
      sender.sendMessage(Component.text("暂无排行榜数据", NamedTextColor.YELLOW));
      return;
    }

    int totalPages = (topPlayers.size() + pageSize - 1) / pageSize;
    page = Math.max(1, Math.min(page, totalPages));
    int start = (page - 1) * pageSize;

    // 标题
    sender.sendMessage(
        Component.text(
            "========== 财富排行榜 (第" + page + "/" + totalPages + "页) ==========",
            NamedTextColor.GOLD));

    // 显示排名
    int end = Math.min(start + pageSize, topPlayers.size());
    for (int i = start; i < end; i++) {
      BalTopService.BalTopEntry entry = topPlayers.get(i);
      OfflinePlayer player = Bukkit.getOfflinePlayer(entry.playerId());

      String rankEmoji =
          switch (i) {
            case 0 -> "❶";
            case 1 -> "❷";
            case 2 -> "❸";
            default -> String.format("#%d", i + 1);
          };

      sender.sendMessage(
          Component.text(
              String.format(
                  "%s %s - %.2f 金币", rankEmoji, player.getName(), entry.balance().doubleValue()),
              NamedTextColor.YELLOW));
    }

    // 自己的排名
    if (sender instanceof Player player) {
      balTopService
          .getPlayerRank(player.getUniqueId())
          .ifPresent(
              rank -> {
                BigDecimal balance = economyService.getBalance(player.getUniqueId());
                sender.sendMessage(
                    Component.text(
                        String.format("你的排名: #%d (%.2f 金币)", rank, balance.doubleValue()),
                        NamedTextColor.GRAY));
              });
    }
  }

  /** 转账 */
  private void handlePay(CommandSender sender, String[] args) {
    if (!(sender instanceof Player player)) {
      sender.sendMessage(Component.text("只有玩家可以使用此命令", NamedTextColor.RED));
      return;
    }

    if (args.length < 2) {
      sender.sendMessage(Component.text("用法: /pay <玩家> <金额>", NamedTextColor.YELLOW));
      return;
    }

    Player target = Bukkit.getPlayer(args[0]);
    if (target == null || !target.isOnline()) {
      sender.sendMessage(Component.text("玩家不在线: " + args[0], NamedTextColor.RED));
      return;
    }

    if (target.equals(player)) {
      sender.sendMessage(Component.text("你不能转账给自己", NamedTextColor.RED));
      return;
    }

    BigDecimal amount;
    try {
      amount = new BigDecimal(args[1]);
    } catch (NumberFormatException e) {
      sender.sendMessage(Component.text("无效的金额: " + args[1], NamedTextColor.RED));
      return;
    }

    if (amount.compareTo(BigDecimal.ZERO) <= 0) {
      sender.sendMessage(Component.text("金额必须大于0", NamedTextColor.RED));
      return;
    }

    UUID playerId = player.getUniqueId();
    UUID targetId = target.getUniqueId();
    String playerName = player.getName();
    String targetName = target.getName();
    sender.sendMessage(Component.text("转账处理中...", NamedTextColor.GRAY));
    try {
      runAsync(
          () -> executePay(player, target, playerId, targetId, amount, playerName, targetName));
    } catch (RuntimeException schedulingFailure) {
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Unable to schedule /pay transfer",
              schedulingFailure);
      sender.sendMessage(Component.text("转账失败：服务器正在关闭或经济任务不可用", NamedTextColor.RED));
    }
  }

  private void executePay(
      Player sender,
      Player target,
      UUID playerId,
      UUID targetId,
      BigDecimal amount,
      String senderName,
      String targetName) {
    TransactionRecord transaction = null;
    try {
      // Vault providers and transaction persistence may block, so keep the complete
      // durable operation off the Paper/Folia entity thread.
      if (!economyService.has(playerId, amount)) {
        dispatchPlayerMessage(sender, "余额不足", NamedTextColor.RED);
        return;
      }

      transaction = beginPayTransaction(playerId, targetId, amount);
      if (transaction == null && transactionFabric != null) {
        dispatchPlayerMessage(sender, "转账失败：交易台账不可用", NamedTextColor.RED);
        return;
      }

      boolean success;
      try {
        success = economyService.transfer(playerId, targetId, amount);
      } catch (RuntimeException exception) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Unable to execute /pay", exception);
        success = false;
      }
      if (success) {
        try {
          completePayTransaction(transaction);
        } catch (RuntimeException ledgerFailure) {
          markPayManualReview(transaction, ledgerFailure);
        }
      } else {
        failPayTransaction(transaction, "pay transfer rejected by economy service");
      }
      dispatchPayResult(sender, target, amount, senderName, targetName, transaction, success);
    } catch (RuntimeException failure) {
      failPayTransaction(transaction, "pay transfer could not be completed");
      plugin
          .getLogger()
          .log(java.util.logging.Level.SEVERE, "Unable to prepare /pay transfer", failure);
      dispatchPayResult(sender, target, amount, senderName, targetName, transaction, false);
    }
  }

  private void dispatchPayResult(
      Player sender,
      Player target,
      BigDecimal amount,
      String senderName,
      String targetName,
      TransactionRecord transaction,
      boolean success) {
    runAtEntity(
        sender,
        () -> {
          if (!sender.isOnline()) {
            return;
          }
          if (success) {
            sender.sendMessage(
                Component.text(
                    String.format("已转账 %.2f 金币给 %s", amount.doubleValue(), targetName),
                    NamedTextColor.GREEN));
          } else {
            sender.sendMessage(
                Component.text(
                    transaction == null
                        ? "转账失败"
                        : "转账失败 [交易ID: " + transaction.transactionId() + "]",
                    NamedTextColor.RED));
          }
        });
    if (success) {
      runAtEntity(
          target,
          () -> {
            if (target.isOnline()) {
              target.sendMessage(
                  Component.text(
                      String.format("收到来自 %s 的 %.2f 金币", senderName, amount.doubleValue()),
                      NamedTextColor.GREEN));
            }
          });
    }
  }

  private void dispatchPlayerMessage(Player player, String message, NamedTextColor color) {
    runAtEntity(
        player,
        () -> {
          if (player.isOnline()) {
            player.sendMessage(Component.text(message, color));
          }
        });
  }

  private void runAsync(Runnable task) {
    if (scheduler != null) {
      scheduler.runAsync(task);
    } else {
      plugin.getServer().getScheduler().runTaskAsynchronously(plugin, task);
    }
  }

  private void runAtEntity(Player player, Runnable task) {
    if (scheduler != null) {
      scheduler.runAtEntity(player, ignored -> task.run());
    } else {
      plugin.getServer().getScheduler().runTask(plugin, task);
    }
  }

  private TransactionRecord beginPayTransaction(UUID from, UUID to, BigDecimal amount) {
    if (transactionFabric == null) {
      return null;
    }
    String idempotencyKey = "player-transfer:" + from + ":" + to + ":" + UUID.randomUUID();
    TransactionRecord record =
        transactionFabric.begin(
            new TransactionRequest(
                from,
                amount,
                RefundOwner.SYSTEM,
                TransactionType.PLAYER_TRANSFER,
                "pay:" + from + ":" + to,
                idempotencyKey,
                Map.of("from", from.toString(), "to", to.toString())));
    try {
      return transitionPayTransaction(
          record, EconomyTransactionState.RESERVED, "pay transfer reserved");
    } catch (RuntimeException reservationFailure) {
      failPayTransaction(record, "pay transfer reservation could not be persisted");
      throw reservationFailure;
    }
  }

  private void completePayTransaction(TransactionRecord record) {
    if (record == null || transactionFabric == null) {
      return;
    }
    TransactionRecord current =
        transitionPayTransaction(record, EconomyTransactionState.DEBITED, "pay sender debited");
    current =
        transitionPayTransaction(
            current, EconomyTransactionState.DELIVERED, "pay recipient credited");
    transitionPayTransaction(current, EconomyTransactionState.COMMITTED, "pay transfer committed");
  }

  private void failPayTransaction(TransactionRecord record, String message) {
    if (record == null || transactionFabric == null) {
      return;
    }
    try {
      TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
      if (!current.state().isTerminal()) {
        transactionFabric.fail(current.transactionId(), message);
      }
    } catch (RuntimeException failure) {
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Unable to persist /pay failure state; manual review required",
              failure);
    }
  }

  private void markPayManualReview(TransactionRecord record, RuntimeException failure) {
    if (record == null || transactionFabric == null) {
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Pay succeeded but its ledger could not commit",
              failure);
      return;
    }
    try {
      TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
      if (current.state().canTransitionTo(EconomyTransactionState.MANUAL_REVIEW)) {
        transactionFabric.markManualReview(
            current.transactionId(), "pay transfer committed; ledger completion requires review");
      }
    } catch (RuntimeException manualReviewFailure) {
      manualReviewFailure.addSuppressed(failure);
      plugin
          .getLogger()
          .log(
              java.util.logging.Level.SEVERE,
              "Unable to mark /pay transaction for manual review",
              manualReviewFailure);
    }
  }

  private TransactionRecord transitionPayTransaction(
      TransactionRecord record, EconomyTransactionState state, String message) {
    if (record == null || transactionFabric == null) {
      return record;
    }
    TransactionRecord current = transactionFabric.find(record.transactionId()).orElse(record);
    if (current.state() == state) {
      return current;
    }
    if (!current.state().canTransitionTo(state)) {
      throw new IllegalStateException(
          "Cannot transition player transfer " + current.state() + " -> " + state);
    }
    return transactionFabric.transition(current.transactionId(), state, message);
  }

  /** 经济管理命令 */
  private void handleEco(CommandSender sender, String[] args) {
    if (!EssentialsPermissions.permits(sender, permissions.economyAdmin())) {
      sender.sendMessage(Component.text("你没有权限使用此命令", NamedTextColor.RED));
      return;
    }

    if (args.length < 3) {
      sender.sendMessage(
          Component.text("用法: /eco <give|take|set> <玩家> <金额>", NamedTextColor.YELLOW));
      return;
    }

    String action = args[0].toLowerCase(Locale.ROOT);
    Player target = Bukkit.getPlayer(args[1]);

    if (target == null) {
      sender.sendMessage(Component.text("玩家不在线: " + args[1], NamedTextColor.RED));
      return;
    }

    BigDecimal amount;
    try {
      amount = new BigDecimal(args[2]);
    } catch (NumberFormatException e) {
      sender.sendMessage(Component.text("无效的金额: " + args[2], NamedTextColor.RED));
      return;
    }

    boolean success =
        switch (action) {
          case "give" -> economyService.deposit(target.getUniqueId(), amount);
          case "take" -> economyService.withdraw(target.getUniqueId(), amount);
          case "set" -> economyService.setBalance(target.getUniqueId(), amount);
          default -> {
            sender.sendMessage(Component.text("无效的操作: " + action, NamedTextColor.RED));
            yield false;
          }
        };

    if (success) {
      BigDecimal newBalance = economyService.getBalance(target.getUniqueId());
      sender.sendMessage(
          Component.text(
              String.format(
                  "已%s %s %.2f 金币，当前余额: %.2f",
                  action.equals("give") ? "给予" : action.equals("take") ? "扣除" : "设置",
                  target.getName(),
                  amount.doubleValue(),
                  newBalance.doubleValue()),
              NamedTextColor.GREEN));
    } else {
      sender.sendMessage(Component.text("操作失败", NamedTextColor.RED));
    }
  }

  @Override
  public @Nullable List<String> onTabComplete(
      @NotNull CommandSender sender,
      @NotNull Command command,
      @NotNull String alias,
      @NotNull String[] args) {
    String commandName = command.getName().toLowerCase(Locale.ROOT);

    if (commandName.equals("pay") && args.length == 1) {
      List<String> players = new ArrayList<>();
      for (Player p : Bukkit.getOnlinePlayers()) {
        if (!p.equals(sender)) {
          players.add(p.getName());
        }
      }
      return players;
    }

    if (commandName.equals("eco")) {
      if (args.length == 1) {
        return List.of("give", "take", "set");
      } else if (args.length == 2) {
        List<String> players = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
          players.add(p.getName());
        }
        return players;
      }
    }

    return List.of();
  }
}
