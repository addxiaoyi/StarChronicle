package dev.starcore.starcore.core.database;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.config.ConfigurationService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.command.EconomyCommand;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.transaction.EconomyTransactionState;
import dev.starcore.starcore.foundation.economy.transaction.TransactionFabric;
import dev.starcore.starcore.foundation.economy.transaction.TransactionRecord;
import dev.starcore.starcore.foundation.economy.transaction.TransactionType;
import dev.starcore.starcore.module.dynasty.DynastyServiceImpl;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.social.simulation.RelationshipNetwork;
import dev.starcore.starcore.social.simulation.SocialInfluenceServiceImpl;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.ResultSet;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.junit.jupiter.api.io.TempDir;

@EnabledIfSystemProperty(named = "starcore.mysql.recovery.it", matches = "true")
class MySqlConnectionRecoveryIntegrationTest {

  private static final String TABLE = "connection_recovery_it";
  private static final long MARKER_WAIT_SECONDS = 90;
  private static final long RECOVERY_WAIT_SECONDS = 45;

  @Test
  @Timeout(value = 180, unit = TimeUnit.SECONDS)
  void recoversTheDatabasePoolAfterMySqlRestart(@TempDir Path pluginDirectory) throws Exception {
    Path markerDirectory = requiredPath("starcore.mysql.recovery.marker-dir");
    Files.createDirectories(markerDirectory);
    Files.deleteIfExists(markerDirectory.resolve("ready"));
    Files.deleteIfExists(markerDirectory.resolve("outage-observed"));

    JavaPlugin plugin = mock(JavaPlugin.class);
    when(plugin.getDataFolder()).thenReturn(pluginDirectory.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getLogger(getClass().getName()));

    ConfigurationService configuration = mock(ConfigurationService.class);
    when(configuration.databaseEnabled()).thenReturn(true);
    when(configuration.databaseFailFast()).thenReturn(true);
    when(configuration.databaseType()).thenReturn("mysql");
    when(configuration.databaseMysqlHost()).thenReturn("127.0.0.1");
    when(configuration.databaseMysqlPort())
        .thenReturn(integerProperty("starcore.mysql.recovery.port"));
    when(configuration.databaseMysqlDatabase())
        .thenReturn(property("starcore.mysql.recovery.database"));
    when(configuration.databaseMysqlUsername())
        .thenReturn(property("starcore.mysql.recovery.user"));
    when(configuration.databaseMysqlPassword())
        .thenReturn(property("starcore.mysql.recovery.password"));
    when(configuration.databaseMysqlParameters()).thenReturn(recoveryParameters());
    when(configuration.databaseMysqlAllowInsecure()).thenReturn(true);
    when(configuration.databasePoolMaximumPoolSize()).thenReturn(2);
    when(configuration.databasePoolMinimumIdle()).thenReturn(1);
    when(configuration.databasePoolConnectionTimeoutMs()).thenReturn(1_000L);
    when(configuration.databasePoolIdleTimeoutMs()).thenReturn(10_000L);
    when(configuration.databasePoolMaxLifetimeMs()).thenReturn(60_000L);
    when(configuration.databasePoolKeepaliveTimeMs()).thenReturn(0L);
    when(configuration.databasePoolValidationTimeoutMs()).thenReturn(1_000L);
    when(configuration.databasePoolLeakDetectionThresholdMs()).thenReturn(0L);

    DatabaseService database = new DatabaseService(plugin, configuration);
    String previousPluginDirectory = System.getProperty("starcore.plugin.dir");
    System.setProperty("starcore.plugin.dir", pluginDirectory.toString());

    try {
      database.start();
      assertThat(database.isRunning()).isTrue();
      database.execute(
          "CREATE TABLE IF NOT EXISTS "
              + TABLE
              + " (id INT PRIMARY KEY, value VARCHAR(64) NOT NULL)");
      database.update("INSERT INTO " + TABLE + " (id, value) VALUES (?, ?)", 1, "before-restart");
      assertThat(countRows(database)).isEqualTo(1);
      assertThat(readValue(database, 1)).isEqualTo("before-restart");
      verifyDynastySnapshot(database, plugin);
      touch(markerDirectory.resolve("dynasty-snapshot-verified"));
      UUID sourcePlayer = UUID.randomUUID();
      UUID freshFriend = UUID.randomUUID();
      UUID existingFriend = UUID.randomUUID();
      RelationshipNetwork network = mock(RelationshipNetwork.class);
      when(network.getFriends(sourcePlayer)).thenReturn(Set.of(freshFriend, existingFriend));
      when(network.getFriends(freshFriend)).thenReturn(Set.of());
      when(network.getFriends(existingFriend)).thenReturn(Set.of());
      SocialInfluenceServiceImpl influence =
          new SocialInfluenceServiceImpl(plugin, null, network, database);
      database.update(
          "INSERT INTO player_influence (player_id, influence, last_decay) VALUES (?, ?, ?)",
          existingFriend.toString(),
          7,
          123L);
      influence.addInfluence(sourcePlayer, 20, "integration");
      assertThat(influence.getInfluence(freshFriend)).isEqualTo(5);
      assertThat(influence.getInfluence(existingFriend)).isEqualTo(12);
      touch(markerDirectory.resolve("influence-propagation-verified"));
      database.update(
          "ALTER TABLE influence_sources ADD CONSTRAINT reject_injected_source CHECK (source <>"
              + " 'injected')");
      assertThatThrownBy(() -> influence.addInfluence(sourcePlayer, 20, "injected"))
          .hasMessage("SOCIAL_INFLUENCE_WRITE_FAILED");
      for (UUID player : java.util.List.of(sourcePlayer, freshFriend, existingFriend)) {
        assertThatThrownBy(() -> influence.getInfluence(player))
            .hasMessage("SOCIAL_INFLUENCE_RELOAD_REQUIRED");
      }
      SocialInfluenceServiceImpl afterRollback =
          new SocialInfluenceServiceImpl(plugin, null, network, database);
      assertThat(afterRollback.getInfluence(sourcePlayer)).isEqualTo(20);
      assertThat(afterRollback.getInfluence(freshFriend)).isEqualTo(5);
      assertThat(afterRollback.getInfluence(existingFriend)).isEqualTo(12);
      Long sourceCount =
          database.query(
              "SELECT COUNT(*) FROM influence_sources WHERE player_id = ?",
              rows -> {
                try {
                  return rows.next() ? rows.getLong(1) : null;
                } catch (java.sql.SQLException failure) {
                  throw new IllegalStateException(failure);
                }
              },
              sourcePlayer.toString());
      assertThat(sourceCount).isEqualTo(1L);
      touch(markerDirectory.resolve("influence-rollback-verified"));

      PersistenceService persistence = mock(PersistenceService.class);
      when(persistence.loadProperties("economy", "player-balances.properties"))
          .thenReturn(new Properties());
      InternalEconomyService economy =
          new InternalEconomyService(database, persistence, plugin.getLogger());
      economy.start();
      UUID transferSource = UUID.randomUUID();
      UUID transferDestination = UUID.randomUUID();
      UUID untouchedAccount = UUID.randomUUID();
      assertThat(economy.setBalance(transferSource, new BigDecimal("100.00"))).isTrue();
      assertThat(economy.setBalance(transferDestination, BigDecimal.ZERO)).isTrue();
      assertThat(economy.setBalance(untouchedAccount, new BigDecimal("50.00"))).isTrue();
      Path transactionFile =
          pluginDirectory.resolve("economy").resolve("transaction-fabric.properties");
      TransactionFabric transactionFabric =
          new TransactionFabric(transactionFile, plugin.getLogger());
      touch(markerDirectory.resolve("economy-balances-seeded"));
      touch(markerDirectory.resolve("ready"));

      await(markerDirectory.resolve("outage-started"), MARKER_WAIT_SECONDS);
      assertThatThrownBy(() -> countRows(database))
          .as("the existing pool must observe the MySQL outage")
          .isInstanceOf(RuntimeException.class);
      runPayCommand(plugin, economy, transactionFabric, transferSource, transferDestination);
      assertThat(economy.balance(transferSource)).isEqualByComparingTo("100.00");
      assertThat(economy.balance(transferDestination)).isEqualByComparingTo("0.00");
      assertThat(transactionFabric.snapshot()).hasSize(1);
      TransactionRecord outageTransfer = transactionFabric.snapshot().get(0);
      assertThat(outageTransfer.type()).isEqualTo(TransactionType.PLAYER_TRANSFER);
      assertThat(transactionFabric.find(outageTransfer.transactionId()).orElseThrow().state())
          .isEqualTo(EconomyTransactionState.DEBIT_FAILED);
      touch(markerDirectory.resolve("economy-ledger-debit-failed-verified"));
      touch(markerDirectory.resolve("economy-transfer-rejected"));
      touch(markerDirectory.resolve("outage-observed"));

      await(markerDirectory.resolve("server-recovered"), MARKER_WAIT_SECONDS);
      long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(RECOVERY_WAIT_SECONDS);
      RuntimeException lastFailure = null;
      boolean recovered = false;
      while (System.nanoTime() < deadline) {
        try {
          assertThat(readValue(database, 1)).isEqualTo("before-restart");
          recovered = true;
          break;
        } catch (RuntimeException failure) {
          lastFailure = failure;
          Thread.sleep(250L);
        }
      }
      if (!recovered) {
        throw new IllegalStateException(
            "Database pool did not recover before the deadline", lastFailure);
      }

      InternalEconomyService afterOutage =
          new InternalEconomyService(database, persistence, plugin.getLogger());
      afterOutage.start();
      assertThat(afterOutage.balance(transferSource)).isEqualByComparingTo("100.00");
      assertThat(afterOutage.balance(transferDestination)).isEqualByComparingTo("0.00");
      assertThat(afterOutage.balance(untouchedAccount)).isEqualByComparingTo("50.00");

      TransactionFabric recoveredTransactions =
          new TransactionFabric(transactionFile, plugin.getLogger());
      assertThat(recoveredTransactions.find(outageTransfer.transactionId()).orElseThrow().state())
          .isEqualTo(EconomyTransactionState.DEBIT_FAILED);
      runPayCommand(
          plugin, afterOutage, recoveredTransactions, transferSource, transferDestination);
      assertThat(recoveredTransactions.snapshot())
          .extracting(TransactionRecord::type)
          .containsOnly(TransactionType.PLAYER_TRANSFER);
      assertThat(recoveredTransactions.snapshot())
          .extracting(TransactionRecord::state)
          .containsExactlyInAnyOrder(
              EconomyTransactionState.DEBIT_FAILED, EconomyTransactionState.COMMITTED);
      assertThat(afterOutage.balance(transferSource)).isEqualByComparingTo("90.00");
      assertThat(afterOutage.balance(transferDestination)).isEqualByComparingTo("10.00");

      InternalEconomyService restoredEconomy =
          new InternalEconomyService(database, persistence, plugin.getLogger());
      restoredEconomy.start();
      assertThat(restoredEconomy.balance(transferSource)).isEqualByComparingTo("90.00");
      assertThat(restoredEconomy.balance(transferDestination)).isEqualByComparingTo("10.00");
      assertThat(restoredEconomy.balance(untouchedAccount)).isEqualByComparingTo("50.00");
      TransactionFabric restoredTransactions =
          new TransactionFabric(transactionFile, plugin.getLogger());
      assertThat(restoredTransactions.snapshot())
          .extracting(TransactionRecord::state)
          .containsExactlyInAnyOrder(
              EconomyTransactionState.DEBIT_FAILED, EconomyTransactionState.COMMITTED);
      touch(markerDirectory.resolve("economy-ledger-committed-verified"));
      Files.copy(
          transactionFile,
          markerDirectory.resolve("economy-transaction-ledger.properties"),
          StandardCopyOption.REPLACE_EXISTING);
      touch(markerDirectory.resolve("economy-transfer-recovered"));
      database.update("INSERT INTO " + TABLE + " (id, value) VALUES (?, ?)", 2, "after-restart");
      assertThat(countRows(database)).isEqualTo(2);
      assertThat(readValue(database, 1)).isEqualTo("before-restart");
      assertThat(readValue(database, 2)).isEqualTo("after-restart");
      SocialInfluenceServiceImpl restoredInfluence =
          new SocialInfluenceServiceImpl(plugin, null, network, database);
      assertThat(restoredInfluence.getInfluence(sourcePlayer)).isEqualTo(20);
      assertThat(restoredInfluence.getInfluence(freshFriend)).isEqualTo(5);
      assertThat(restoredInfluence.getInfluence(existingFriend)).isEqualTo(12);
      Long decay =
          database.query(
              "SELECT last_decay FROM player_influence WHERE player_id = ?",
              rows -> {
                try {
                  return rows.next() ? rows.getLong(1) : null;
                } catch (java.sql.SQLException failure) {
                  throw new IllegalStateException(failure);
                }
              },
              existingFriend.toString());
      assertThat(decay).isEqualTo(123L);
      touch(markerDirectory.resolve("influence-recovery-verified"));
      assertThat(database.getPoolStats().maxPoolSize()).isEqualTo(2);
      touch(markerDirectory.resolve("recovery-verified"));
    } finally {
      database.stop();
      database.shutdown();
      restoreSystemProperty("starcore.plugin.dir", previousPluginDirectory);
    }
  }

  private void verifyDynastySnapshot(DatabaseService database, JavaPlugin plugin) throws Exception {
    NationId nation = NationId.of(UUID.randomUUID());
    UUID founder = UUID.randomUUID();
    UUID oldHeir = UUID.randomUUID();
    UUID newHeir = UUID.randomUUID();
    database.update(
        "INSERT INTO starcore_dynasties (nation_id, dynasty_name, current_monarch_id, "
            + "current_monarch_name, succession_type, created_at, succession_title) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)",
        nation.toString(),
        "Snapshot",
        founder.toString(),
        "Founder",
        "HEREDITARY",
        1L,
        "Old");
    database.update(
        "INSERT INTO starcore_dynasty_heirs (nation_id, player_id, player_name, position, added_at)"
            + " VALUES (?, ?, ?, ?, ?)",
        nation.toString(),
        oldHeir.toString(),
        "Old",
        1,
        1L);

    var source = database.dataSource().orElseThrow();
    var connection = source.getConnection();
    java.sql.Connection intercepted =
        mock(java.sql.Connection.class, org.mockito.AdditionalAnswers.delegatesTo(connection));
    doAnswer(
            invocation -> {
              try (var other = source.getConnection()) {
                other.setAutoCommit(false);
                try (var update =
                        other.prepareStatement(
                            "UPDATE starcore_dynasties SET succession_title = ? WHERE nation_id ="
                                + " ?");
                    var delete =
                        other.prepareStatement(
                            "DELETE FROM starcore_dynasty_heirs WHERE nation_id = ?");
                    var insert =
                        other.prepareStatement(
                            "INSERT INTO starcore_dynasty_heirs (nation_id, player_id, player_name,"
                                + " position, added_at) VALUES (?, ?, ?, ?, ?)")) {
                  update.setString(1, "New");
                  update.setString(2, nation.toString());
                  update.executeUpdate();
                  delete.setString(1, nation.toString());
                  delete.executeUpdate();
                  insert.setString(1, nation.toString());
                  insert.setString(2, newHeir.toString());
                  insert.setString(3, "New");
                  insert.setInt(4, 1);
                  insert.setLong(5, 1L);
                  insert.executeUpdate();
                }
                other.commit();
              }
              return connection.prepareStatement(invocation.getArgument(0, String.class));
            })
        .when(intercepted)
        .prepareStatement(
            org.mockito.ArgumentMatchers.startsWith("SELECT * FROM starcore_dynasty_heirs"));
    javax.sql.DataSource snapshotSource = mock(javax.sql.DataSource.class);
    when(snapshotSource.getConnection()).thenReturn(intercepted);
    DatabaseService readerDatabase = mock(DatabaseService.class);
    when(readerDatabase.dataSource()).thenReturn(Optional.of(snapshotSource));
    DynastyServiceImpl reader = new DynastyServiceImpl(plugin, readerDatabase, null, null, null);
    reader.loadAll();
    var dynasty = reader.getDynasty(nation).orElseThrow();
    assertThat(dynasty.successionTitle()).isEqualTo("Old");
    assertThat(dynasty.successionOrder())
        .extracting(heir -> heir.playerId())
        .containsExactly(oldHeir);
    String committedTitle =
        database.query(
            "SELECT succession_title FROM starcore_dynasties WHERE nation_id = ?",
            rows -> {
              try {
                return rows.next() ? rows.getString(1) : null;
              } catch (java.sql.SQLException failure) {
                throw new IllegalStateException(failure);
              }
            },
            nation.toString());
    assertThat(committedTitle).isEqualTo("New");
  }

  private int countRows(DatabaseService database) {
    return database.query("SELECT COUNT(*) FROM " + TABLE, this::readCount);
  }

  private String readValue(DatabaseService database, int id) {
    return database.query(
        "SELECT value FROM " + TABLE + " WHERE id = ?",
        result -> {
          try {
            assertThat(result.next()).isTrue();
            return result.getString(1);
          } catch (Exception exception) {
            throw new IllegalStateException("Unable to read connection recovery marker", exception);
          }
        },
        id);
  }

  private int readCount(ResultSet result) {
    try {
      assertThat(result.next()).isTrue();
      return result.getInt(1);
    } catch (Exception exception) {
      throw new IllegalStateException("Unable to read connection recovery row count", exception);
    }
  }

  private static void runPayCommand(
      JavaPlugin plugin,
      InternalEconomyService economy,
      TransactionFabric fabric,
      UUID senderId,
      UUID targetId) {
    Player sender = mock(Player.class);
    Player target = mock(Player.class);
    Command command = mock(Command.class);
    FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
    when(command.getName()).thenReturn("pay");
    when(sender.getUniqueId()).thenReturn(senderId);
    when(sender.getName()).thenReturn("RecoverySender");
    when(sender.isOnline()).thenReturn(true);
    when(target.getUniqueId()).thenReturn(targetId);
    when(target.getName()).thenReturn("RecoveryTarget");
    when(target.isOnline()).thenReturn(true);
    org.bukkit.Server server = mock(org.bukkit.Server.class);
    when(plugin.isEnabled()).thenReturn(true);
    when(sender.getServer()).thenReturn(server);
    when(target.getServer()).thenReturn(server);
    when(server.getPlayer(senderId)).thenReturn(sender);
    when(server.getPlayer(targetId)).thenReturn(target);
    doAnswer(
            invocation -> {
              invocation.<Runnable>getArgument(0).run();
              return null;
            })
        .when(scheduler)
        .runAsync(any(Runnable.class));
    doAnswer(
            invocation -> {
              @SuppressWarnings("unchecked")
              Consumer<Object> callback = invocation.getArgument(1);
              callback.accept(null);
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(Player.class), any(), any());

    EconomyCommand economyCommand =
        new EconomyCommand(plugin, economy, mock(BalTopService.class), fabric, scheduler);
    try (var bukkit = mockStatic(Bukkit.class)) {
      bukkit.when(() -> Bukkit.getPlayer("RecoveryTarget")).thenReturn(target);
      economyCommand.onCommand(sender, command, "pay", new String[] {"RecoveryTarget", "10.00"});
    }
  }

  private static String property(String name) {
    String value = System.getProperty(name);
    if ((value == null || value.isBlank()) && name.equals("starcore.mysql.recovery.password")) {
      value = System.getenv("STARCORE_MYSQL_RECOVERY_PASSWORD");
    }
    if (value == null || value.isBlank()) {
      throw new IllegalArgumentException("Missing integration property: " + name);
    }
    return value;
  }

  private static String recoveryParameters() {
    return System.getProperty(
        "starcore.mysql.recovery.parameters",
        System.getenv()
            .getOrDefault(
                "STARCORE_MYSQL_RECOVERY_PARAMETERS",
                "useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&connectTimeout=1000&socketTimeout=2000"));
  }

  private static int integerProperty(String name) {
    return Integer.parseInt(property(name));
  }

  private static Path requiredPath(String name) {
    return Path.of(property(name)).toAbsolutePath().normalize();
  }

  private static void touch(Path marker) throws IOException {
    Files.writeString(marker, "ok\n");
  }

  private static void await(Path marker, long timeoutSeconds) throws Exception {
    long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds);
    while (System.nanoTime() < deadline) {
      if (Files.isRegularFile(marker)) {
        return;
      }
      Thread.sleep(100L);
    }
    throw new IllegalStateException("Timed out waiting for integration marker: " + marker);
  }

  private static void restoreSystemProperty(String name, String previousValue) {
    if (previousValue == null) {
      System.clearProperty(name);
    } else {
      System.setProperty(name, previousValue);
    }
  }
}
