import java.sql.*;
public class H2IsolationProbe {
 public static void main(String[] args)throws Exception {
  for(int level:new int[]{Connection.TRANSACTION_READ_COMMITTED,Connection.TRANSACTION_REPEATABLE_READ,Connection.TRANSACTION_SERIALIZABLE}) {
   try(var c=DriverManager.getConnection("jdbc:h2:mem:probe"+level)) {
    c.createStatement().execute("CREATE TABLE receipts(id VARCHAR PRIMARY KEY, sequence BIGINT UNIQUE)");
    c.createStatement().execute("INSERT INTO receipts VALUES('first',1)");
    c.setTransactionIsolation(level);c.setAutoCommit(false);
    print(c,level,"before");c.createStatement().execute("INSERT INTO receipts VALUES('second',2)");print(c,level,"after");c.rollback();
   }
  }
 }
 static void print(Connection c,int level,String phase)throws Exception {
  try(var s=c.createStatement();var r=s.executeQuery("SELECT * FROM receipts ORDER BY sequence DESC LIMIT 1")){r.next();System.out.println(level+" "+phase+" last="+r.getString(1)+" seq="+r.getLong(2));}
  try(var s=c.createStatement();var r=s.executeQuery("SELECT COUNT(*),COALESCE(MIN(sequence),0) FROM receipts")){r.next();System.out.println(level+" "+phase+" count="+r.getLong(1));}
  try(var s=c.createStatement();var r=s.executeQuery("SELECT COUNT(*),COALESCE(MIN(sequence),0),COALESCE(MAX(sequence),0) FROM receipts")){r.next();System.out.println(level+" "+phase+" range="+r.getLong(1)+","+r.getLong(2)+","+r.getLong(3));}
  try(var s=c.createStatement();var r=s.executeQuery("SELECT * FROM receipts WHERE sequence=2")){System.out.println(level+" "+phase+" exact-new="+r.next());}
  try(var s=c.createStatement();var r=s.executeQuery("SELECT COUNT(*),COUNT(CASE WHEN sequence BETWEEN 1 AND 2 THEN 1 END) FROM receipts")){r.next();System.out.println(level+" "+phase+" bounded-count="+r.getLong(1)+","+r.getLong(2));}
 }
}
