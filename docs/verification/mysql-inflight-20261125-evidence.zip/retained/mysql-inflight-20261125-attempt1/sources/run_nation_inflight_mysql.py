#!/usr/bin/env python3
"""Interrupt real native production/trade services at a JDBC commit boundary.

Creates one new, labeled, loopback-only MySQL container. Existing containers, files,
and catalogs are refused and retained. Credentials stay in a private directory outside
Git. Requires Java 21, Docker and PyMySQL 1.1.2; never targets a remote/live database.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import re
import secrets
import socket
import ssl
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
IMAGE = 'public.ecr.aws/docker/library/mysql@sha256:8c233bad33d520a7aae1c1e619c3a9775f4a1ba2d463d692fada04ec7f40be00'
WORKER = 'dev.starcore.starcore.module.resource.MySqlNationInFlightWorker'
PHASES = ('start', 'complete', 'cancel', 'trade')
MODES = ('mysql_before', 'jvm_before', 'jvm_after')
TABLES = frozenset(('starcore_resource_state', 'starcore_resource_transfer_receipts',
    'starcore_resource_state_migrations', 'starcore_resource_transfer_history',
    'starcore_resource_revision', 'starcore_nation_trade_offers', 'starcore_nation_trade_head',
    'starcore_nation_trade_settlements', 'starcore_nation_production_head',
    'starcore_nation_production_events', 'starcore_treasury_state'))


def check(value, message):
    if not value:
        raise AssertionError(message)


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def docker(*args, input=None):
    env = {k: v for k, v in os.environ.items() if k not in
           {'DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'}}
    result = subprocess.run(['docker', '--host=unix:///var/run/docker.sock', *map(str, args)],
                            input=input, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=60)
    check(result.returncode == 0, 'Docker operation failed: ' + result.stderr.decode(errors='replace')[-1000:])
    return result.stdout


def inspect(instance):
    name = instance['container']
    check(re.fullmatch(r'starcore-inflight-mysql-[a-z0-9-]+', name), 'Unowned container name')
    identity = docker('inspect', '--format', '{{.Id}}', name).decode().strip()
    check(identity == instance['id'], 'Container identity changed')
    check(docker('inspect', '--format', '{{index .Config.Labels "codex.task"}}', name).decode().strip() == name,
          'Container label changed')
    check(docker('inspect', '--format', '{{.Config.Image}}', name).decode().strip() == IMAGE, 'Container image changed')
    ports = json.loads(docker('inspect', '--format', '{{json .HostConfig.PortBindings}}', name))
    check(ports == {'3306/tcp': [{'HostIp': '127.0.0.1', 'HostPort': str(instance['port'])}]}, 'Container port changed')
    return json.loads(docker('inspect', '--format', '{{json .State}}', name))


def connect(instance, catalog):
    import pymysql
    check(catalog in instance['databases'], 'Unowned catalog')
    # Isolated encrypted loopback transport, without a remote certificate identity claim.
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return pymysql.connect(host='127.0.0.1', port=instance['port'], database=catalog,
                           user='starcore_inflight', password=os.environ['STARCORE_INFLIGHT_MYSQL_PASSWORD'],
                           charset='utf8mb4', ssl=context, connect_timeout=2, read_timeout=5, write_timeout=5)


def wait_ready(instance):
    deadline = time.monotonic() + 60
    while True:
        try:
            with connect(instance, instance['databases'][0]) as db:
                with db.cursor() as c:
                    c.execute('SELECT VERSION(),@@server_uuid,@@innodb_flush_log_at_trx_commit,@@sync_binlog')
                    version, identity, flush, sync = c.fetchone()
                    check(version.startswith('8.4.') and flush == sync == 1, 'Wrong durability settings')
                    return dict(version=version, server_uuid=identity, innodb_flush_log_at_trx_commit=flush, sync_binlog=sync)
        except Exception:
            if time.monotonic() > deadline:
                raise
            time.sleep(.25)


def capture(instance, catalog, connection_id=None):
    with connect(instance, catalog) as db:
        with db.cursor() as c:
            c.execute('SELECT VERSION(),DATABASE(),@@server_uuid,@@transaction_isolation')
            version, database, identity, isolation = c.fetchone()
            check(database == catalog and isolation == 'REPEATABLE-READ', 'Wrong catalog/isolation')
            c.execute("SHOW SESSION STATUS LIKE 'Ssl_cipher'")
            cipher = c.fetchone()[1]
            check(cipher, 'Unencrypted audit connection')
            c.execute('SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME')
            tables = c.fetchall()
            check(set(n for n, _ in tables) == TABLES and all(e == 'InnoDB' for _, e in tables), 'Unexpected tables/engines')
            transactions = []
            if connection_id is not None:
                c.execute('SELECT trx_id,trx_state,trx_mysql_thread_id,trx_rows_modified FROM information_schema.innodb_trx WHERE trx_mysql_thread_id=%s', (connection_id,))
                transactions = [list(r) for r in c.fetchall()]
            c.execute('SHOW TRIGGERS')
            check(not c.fetchall(), 'Unexpected trigger')
            db.commit()
            c.execute('START TRANSACTION WITH CONSISTENT SNAPSHOT, READ ONLY')
            data = {}
            ddl = {}
            for table, _ in tables:
                c.execute('SHOW CREATE TABLE ' + table)
                ddl[table] = c.fetchone()[1]
                c.execute('SELECT * FROM ' + table)
                columns = [column[0] for column in c.description]
                rows = [[None if v is None else str(v) for v in row] for row in c.fetchall()]
                rows.sort(key=lambda row: json.dumps(row, ensure_ascii=False, separators=(',', ':')))
                data[table] = dict(columns=columns, rows=rows)
            db.commit()
    return dict(tables=data, ddl=ddl, server_uuid=identity, version=version, database=database,
                isolation=isolation, ssl_cipher=cipher, transactions=transactions)


def equal(a, b):
    check(a == b, 'Full table snapshot differs')


def process(instance, directory, stage, phase, mode, classpath):
    catalog = f'starcore_inflight_it_{phase}_{mode}'
    env = dict(os.environ, STARCORE_INFLIGHT_MYSQL_USER='starcore_inflight',
               STARCORE_INFLIGHT_MYSQL_URL=f'jdbc:mysql://127.0.0.1:{instance["port"]}/{catalog}?sslMode=REQUIRED&connectTimeout=2000&socketTimeout=5000&serverTimezone=UTC')
    command = [str(Path(env.get('JAVA_HOME', '/usr/lib/jvm/java-21-openjdk-amd64')) / 'bin/java'),
               '-Xmx384m', '-XX:+EnableDynamicAgentLoading', '-cp', classpath, WORKER,
               str(directory), stage, phase, mode]
    stream = (directory / (stage + '.log')).open('xb')
    try:
        worker = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    finally:
        stream.close()
    write(directory / (stage + '-process.json'), dict(pid=worker.pid, started=time.time(), command=command))
    return worker


def normal(worker, directory, stage):
    code = worker.wait(timeout=60)
    write(directory / (stage + '-exit.json'), dict(pid=worker.pid, code=code, finished=time.time()))
    check(code == 0, 'Worker failed at ' + stage + '; inspect retained log')


def marker(directory, name, worker):
    deadline = time.monotonic() + 60
    while not (directory / name).exists():
        check(worker.poll() is None, 'Worker exited before ' + name + '; inspect retained log')
        check(time.monotonic() < deadline, 'Timed out at ' + name)
        time.sleep(.05)
    return read(directory / name)


def kill_mysql(instance):
    before = inspect(instance)
    check(before['Running'], 'Database is not running')
    docker('kill', '--signal', 'KILL', instance['container'])
    killed = inspect(instance)
    check(not killed['Running'] and killed['ExitCode'] == 137 and not killed['OOMKilled'], 'Database was not deliberately killed')
    return dict(before=before, killed=killed, killed_at=time.time())


def restart(instance, lifecycle):
    inspect(instance)
    docker('start', instance['container'])
    meta = wait_ready(instance)
    after = inspect(instance)
    check(after['Running'] and not after['OOMKilled'] and after['StartedAt'] != lifecycle['before']['StartedAt'], 'Missing database restart')
    lifecycle.update(after=after, meta=meta)


def scenario(instance, output, phase, mode, classpath):
    directory = output / f'{phase}-{mode}'
    directory.mkdir()
    catalog = f'starcore_inflight_it_{phase}_{mode}'
    worker = None
    began = time.time()
    try:
        worker = process(instance, directory, 'setup', phase, mode, classpath)
        normal(worker, directory, 'setup')
        baseline = read(directory / 'baseline.json')
        original = capture(instance, catalog)
        write(directory / 'independent-baseline.json', original)
        equal(baseline, original['tables'])
        worker = process(instance, directory, 'operate', phase, mode, classpath)
        gate = marker(directory, 'gate.json', worker)
        check(gate['pid'] == worker.pid and gate['phase'] == phase and gate['mode'] == mode, 'Unexpected commit gate')
        desired = read(directory / 'transaction-view.json')
        check(desired != baseline, 'Commit gate has no real changes')
        # information_schema.innodb_trx may cache observations briefly; use a bounded poll.
        for attempt in range(30):
            observed = capture(instance, catalog, gate['connection_id'])
            if mode == 'jvm_after' or observed['transactions']:
                break
            time.sleep(.1)
        write(directory / 'independent-gate.json', observed)
        if mode == 'jvm_after':
            check(gate['commit_returned_to_wrapper'] and not observed['transactions'], 'Commit did not finish')
            equal(desired, observed['tables'])
        else:
            check(not gate['commit_returned_to_wrapper'], 'Unexpected commit')
            check(len(observed['transactions']) == 1 and int(observed['transactions'][0][3]) > 0,
                  'No independently visible active write transaction')
            equal(baseline, observed['tables'])
        check(worker.poll() is None, 'Worker was not pending at interruption')
        if mode.startswith('jvm_'):
            check((Path('/proc') / str(worker.pid) / 'cwd').resolve() == ROOT, 'Wrong worker process')
            worker.kill()
            code = worker.wait(timeout=15)
            check(code == -9, 'Worker not killed by SIGKILL')
            write(directory / 'operate-exit.json', dict(pid=worker.pid, code=code, killed_at=time.time()))
        lifecycle = kill_mysql(instance)
        write(directory / 'database-killed.json', lifecycle)
        if mode == 'mysql_before':
            (directory / 'release').touch(exist_ok=False)
            outcome = marker(directory, 'outage-outcome.json', worker)
            check(outcome['status'] == 'UNKNOWN', 'Interrupted call incorrectly reported success')
        restart(instance, lifecycle)
        write(directory / 'database-restarted.json', lifecycle)
        recovered = capture(instance, catalog)
        write(directory / 'independent-recovered.json', recovered)
        check(recovered['server_uuid'] == original['server_uuid'], 'Database authority changed')
        equal(original['ddl'], recovered['ddl'])
        equal(desired if mode == 'jvm_after' else baseline, recovered['tables'])
        if mode == 'mysql_before':
            (directory / 'database-restarted').touch(exist_ok=False)
            normal(worker, directory, 'operate')
            check(read(directory / 'stale-writers.json')['inventory_blocked'], 'Uncertain old writer remained usable')
        for stage in ('verify', 'reload'):
            worker = process(instance, directory, stage, phase, mode, classpath)
            normal(worker, directory, stage)
            result = read(directory / (stage + '-result.json'))
            check(result['status'] == 'PASSED' and result['replay'] == 'ALREADY_APPLIED', 'Replay failed')
        final = capture(instance, catalog)
        write(directory / 'independent-final.json', final)
        equal(read(directory / 'verify-after.json'), final['tables'])
        equal(read(directory / 'reload-before.json'), final['tables'])
        equal(read(directory / 'reload-after.json'), final['tables'])
        if mode == 'jvm_after':
            equal(desired, final['tables'])
        proof = dict(status='PASSED', phase=phase, mode=mode, catalog=catalog,
                     database_kills=1, jvm_kills=int(mode.startswith('jvm_')),
                     normal_worker_exits=3 + int(mode == 'mysql_before'),
                     full_table_count=len(TABLES), started=began, finished=time.time(),
                     commit_boundary=gate, files={p.name: sha(p) for p in directory.iterdir() if p.is_file()})
        write(directory / 'result.json', proof)
        print(json.dumps({k: proof[k] for k in ('status', 'phase', 'mode', 'database_kills', 'jvm_kills')}), flush=True)
        return proof
    except BaseException as error:
        # Preserve every failed attempt. Only stop this runner's child, if one is still pending.
        if worker is not None and worker.poll() is None:
            worker.terminate()
            try:
                worker.wait(timeout=10)
            except subprocess.TimeoutExpired:
                worker.kill(); worker.wait(timeout=10)
        write(directory / 'failure.json', dict(status='FAILED', type=type(error).__name__, error=str(error)))
        raise


def prepare(args):
    private = args.private_directory.resolve()
    check(not private.exists(), 'Private directory exists; retain it and select a new one')
    check(not any((p / '.git').exists() for p in (private, *private.parents)), 'Private files must be outside Git')
    check(re.fullmatch(r'starcore-inflight-mysql-[a-z0-9-]+', args.container), 'Invalid owned container name')
    check(args.container not in docker('ps', '-a', '--format', '{{.Names}}').decode().splitlines(), 'Container already exists')
    check(1024 <= args.port <= 65535 and args.port not in (3306, 8000, 8001, 8080, 8081, 8082, 8083, 8085, 9222, 31460, 50002), 'Reserved port')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', args.port))
    docker('image', 'inspect', IMAGE)
    private.mkdir(mode=0o700)
    password = secrets.token_hex(32)
    envfile = private / 'mysql.env'
    with open(envfile, 'x', opener=lambda path, flags: os.open(path, flags, 0o600)) as stream:
        stream.write('MYSQL_ROOT_PASSWORD=' + secrets.token_hex(32) + '\nMYSQL_USER=starcore_inflight\nMYSQL_PASSWORD=' + password + '\nMYSQL_DATABASE=starcore_settlement_it\n')
    databases = ['starcore_settlement_it', *(f'starcore_inflight_it_{p}_{m}' for p in PHASES for m in MODES)]
    identity = docker('run', '-d', '--name', args.container, '--label', 'codex.task=' + args.container,
                      '-p', f'127.0.0.1:{args.port}:3306', '--memory', '768m', '--cpus', '1', '--env-file', envfile,
                      IMAGE, '--innodb-buffer-pool-size=64M', '--max-connections=40').decode().strip()
    instance = dict(container=args.container, id=identity, image=IMAGE, port=args.port, databases=databases)
    write(private / 'preparation.json', instance)
    os.environ['STARCORE_INFLIGHT_MYSQL_PASSWORD'] = password
    wait_ready(instance)
    sql = ["GRANT PROCESS ON *.* TO 'starcore_inflight'@'%';"]
    for catalog in databases[1:]:
        escaped = catalog.replace('_', '\\_')
        sql.extend([f'CREATE DATABASE `{catalog}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;',
                    f"GRANT ALL ON `{escaped}`.* TO 'starcore_inflight'@'%';"])
    docker('exec', '-i', args.container, 'sh', '-c',
           'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql --user=root --protocol=socket', input=('\n'.join(sql) + '\n').encode())
    return instance


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--private-directory', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--container', required=True)
    p.add_argument('--port', type=int, default=33321)
    args = p.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    began = time.time()
    sources = [Path(__file__), ROOT / ('src/test/java/' + WORKER.replace('.', '/') + '.java'),
               ROOT / 'src/test/java/dev/starcore/starcore/module/resource/MySqlNationSettlementIntegrationTest.java']
    (output / 'sources').mkdir()
    for path in sources:
        (output / 'sources' / path.name).write_bytes(path.read_bytes())
    build = ['./mvnw', '-o', '-B', '-ntp', '-DskipTests', 'test-compile', 'dependency:build-classpath', '-Dmdep.outputFile=target/inflight-classpath.txt']
    with (output / 'compile.log').open('xb') as log:
        check(subprocess.run(build, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT).returncode == 0, 'Compile failed')
    classpath = str(ROOT / 'target/test-classes') + ':' + str(ROOT / 'target/classes') + ':' + (ROOT / 'target/inflight-classpath.txt').read_text().strip()
    instance = prepare(args)
    write(output / 'instance.json', instance)
    results = []
    success = False
    try:
        # Corrected native trigger matrix is run first; it owns only its separate empty catalog.
        env = dict(os.environ, STARCORE_SETTLEMENT_MYSQL_USER='starcore_inflight',
                   STARCORE_SETTLEMENT_MYSQL_PASSWORD=os.environ['STARCORE_INFLIGHT_MYSQL_PASSWORD'],
                   STARCORE_SETTLEMENT_MYSQL_URL=f'jdbc:mysql://127.0.0.1:{args.port}/starcore_settlement_it?sslMode=REQUIRED&connectTimeout=2000&socketTimeout=5000&serverTimezone=UTC')
        with (output / 'settlement-runner.log').open('xb') as log:
            code = subprocess.run(['python3', 'tools/run_nation_settlement_mysql.py', '--output', str(output / 'corrected-settlement')],
                                  cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
        check(code == 0, 'Corrected trigger tests failed')
        for phase in PHASES:
            for mode in MODES:
                results.append(scenario(instance, output, phase, mode, classpath))
        success = True
    finally:
        state = inspect(instance)
        if state['Running']:
            docker('stop', '--time', '30', instance['container'])
        final = inspect(instance)
        logs = subprocess.run(['docker', '--host=unix:///var/run/docker.sock', 'logs', instance['container']],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              env={k: v for k, v in os.environ.items() if not k.startswith('DOCKER_')}, timeout=30).stdout
        (output / 'database.log').write_bytes(logs)
        write(output / 'shutdown.json', final)
        manifest = dict(status='PASSED' if success else 'FAILED', started=began, finished=time.time(),
                        native_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                        cases=len(results), database_kills=sum(r['database_kills'] for r in results),
                        jvm_kills=sum(r['jvm_kills'] for r in results),
                        normal_worker_exits=sum(r['normal_worker_exits'] for r in results),
                        boundary='Actual native services with fixture identity adapters; real MySQL and JDBC commit gates; not Paper, live production or hardware power loss',
                        results=[dict(phase=r['phase'], mode=r['mode'], status=r['status']) for r in results],
                        files={p.relative_to(output).as_posix(): sha(p) for p in output.rglob('*') if p.is_file()})
        write(output / 'manifest.json', manifest)
        print(json.dumps({k: manifest[k] for k in ('status', 'cases', 'database_kills', 'jvm_kills', 'normal_worker_exits')}), flush=True)
    check(success and final['ExitCode'] == 0 and not final['OOMKilled'], 'Acceptance did not finish normally')


if __name__ == '__main__':
    main()
