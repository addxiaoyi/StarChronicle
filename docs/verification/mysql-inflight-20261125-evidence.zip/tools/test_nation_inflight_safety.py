#!/usr/bin/env python3
"""Ensure the interruption runner refuses foreign or changed Docker targets before killing."""
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
import run_nation_inflight_mysql as R


class TargetOwnershipTest(unittest.TestCase):
    def setUp(self):
        self.instance = dict(container='starcore-inflight-mysql-safety', id='owned-id', port=33321)
        self.responses = [b'owned-id\n', b'starcore-inflight-mysql-safety\n', (R.IMAGE + '\n').encode(),
                          json.dumps({'3306/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '33321'}]}).encode(),
                          json.dumps({'Running': True}).encode()]

    def rejects(self, index, value):
        self.responses[index] = value
        with patch.object(R, 'docker', side_effect=self.responses) as docker:
            with self.assertRaises(AssertionError):
                R.kill_mysql(self.instance)
            self.assertTrue(all(call.args[0] == 'inspect' for call in docker.call_args_list))

    def test_changed_id(self):
        self.rejects(0, b'foreign-id')

    def test_changed_label(self):
        self.rejects(1, b'another-task')

    def test_changed_image(self):
        self.rejects(2, b'mysql:latest')

    def test_non_loopback_binding(self):
        self.rejects(3, json.dumps({'3306/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '33321'}]}).encode())

    def test_changed_port(self):
        self.rejects(3, json.dumps({'3306/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '3306'}]}).encode())

    def test_stopped_database(self):
        self.rejects(4, json.dumps({'Running': False}).encode())

    def test_unrelated_name(self):
        self.instance['container'] = 'production-mysql'
        with patch.object(R, 'docker') as docker:
            with self.assertRaises(AssertionError):
                R.kill_mysql(self.instance)
            docker.assert_not_called()

    def test_existing_private_evidence_refused_without_docker(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(R, 'docker') as docker:
                with self.assertRaises(AssertionError):
                    R.prepare(SimpleNamespace(private_directory=Path(directory)))
                docker.assert_not_called()

    def test_private_git_location_refused_without_docker(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / '.git').mkdir()
            with patch.object(R, 'docker') as docker:
                with self.assertRaises(AssertionError):
                    R.prepare(SimpleNamespace(private_directory=Path(directory) / 'secret'))
                docker.assert_not_called()


if __name__ == '__main__':
    unittest.main(verbosity=2)
