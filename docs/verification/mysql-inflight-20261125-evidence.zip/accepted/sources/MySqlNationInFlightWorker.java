package dev.starcore.starcore.module.resource;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mysql.cj.jdbc.MysqlDataSource;
import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.treasury.TreasuryModule;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;

/**
 * Separate JVM for real process-interruption acceptance. Only identity/persistence adapters are
 * fixtures. Inventory, treasury, settlement services and SQL storage are production
 * implementations. The JDBC wrapper pauses before/after a real commit; it never fabricates a
 * successful commit or a database error. No SQL data is deleted, and this worker is never included
 * in the plugin JAR.
 */
public final class MySqlNationInFlightWorker {
  private static final Gson JSON =
      new GsonBuilder().serializeNulls().disableHtmlEscaping().create();
  private static final Set<String> TABLES =
      Set.of(
          "starcore_resource_state",
          "starcore_resource_transfer_receipts",
          "starcore_resource_state_migrations",
          "starcore_resource_transfer_history",
          "starcore_resource_revision",
          "starcore_nation_trade_offers",
          "starcore_nation_trade_head",
          "starcore_nation_trade_settlements",
          "starcore_nation_production_head",
          "starcore_nation_production_events",
          "starcore_treasury_state");
  private final Path directory;
  private final String phase, mode, catalog;
  private final MysqlDataSource mysql = new MysqlDataSource();
  private final List<AbstractModuleStateStorage> stores = new ArrayList<>();
  private final AtomicBoolean armed = new AtomicBoolean();
  private final UUID seller, buyer, operation;
  private final Nation selling, buying;
  private final NationService nations = mock(NationService.class);
  private final DataSource source;

  private record Bundle(
      ResourceModule resources,
      SqlResourceStateStorage storage,
      TreasuryModule treasury,
      SimpleNationTradeService trade,
      SimpleNationProductionService production) {}

  private MySqlNationInFlightWorker(Path directory, String phase, String mode) throws Exception {
    this.directory = directory.toRealPath();
    this.phase = phase;
    this.mode = mode;
    assertThat(phase).isIn("start", "complete", "cancel", "trade");
    assertThat(mode).isIn("mysql_before", "jvm_before", "jvm_after");
    catalog = "starcore_inflight_it_" + phase + "_" + mode;
    String url = System.getenv("STARCORE_INFLIGHT_MYSQL_URL");
    assertThat(url).matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/" + catalog + "\\?.*");
    assertThat(url).doesNotContain(":3306/", "password=", "user=");
    mysql.setURL(url);
    mysql.setUser(System.getenv("STARCORE_INFLIGHT_MYSQL_USER"));
    mysql.setPassword(System.getenv("STARCORE_INFLIGHT_MYSQL_PASSWORD"));
    try (var c = mysql.getConnection();
        var s = c.createStatement();
        var r =
            s.executeQuery(
                "SELECT DATABASE(),@@default_storage_engine,@@transaction_isolation,"
                    + "@@innodb_flush_log_at_trx_commit,@@sync_binlog")) {
      assertThat(r.next()).isTrue();
      assertThat(r.getString(1)).isEqualTo(catalog);
      assertThat(r.getString(2)).isEqualToIgnoringCase("InnoDB");
      assertThat(r.getString(3)).isEqualTo("REPEATABLE-READ");
      assertThat(r.getInt(4)).isEqualTo(1);
      assertThat(r.getInt(5)).isEqualTo(1);
    }
    seller = id("seller");
    buyer = id("buyer");
    operation = id("operation");
    selling = new Nation(new NationId(id("selling")), "Selling", seller, "seller");
    buying = new Nation(new NationId(id("buying")), "Buying", buyer, "buyer");
    when(nations.nationOf(seller)).thenReturn(Optional.of(selling));
    when(nations.nationOf(buyer)).thenReturn(Optional.of(buying));
    source = interceptedSource();
  }

  private UUID id(String role) {
    return UUID.nameUUIDFromBytes((catalog + ":" + role).getBytes(StandardCharsets.UTF_8));
  }

  private Bundle bundle(boolean setup) throws Exception {
    var database = mock(DatabaseService.class);
    when(database.dataSource()).thenReturn(Optional.of(source));
    when(database.isRunning()).thenReturn(true);
    String namespace = "mysql-inflight-" + catalog;
    var persistence = mock(PersistenceService.class);
    when(persistence.loadProperties(eq(namespace), anyString())).thenReturn(new Properties());
    var logger = Logger.getLogger(namespace);
    var storage = new SqlResourceStateStorage(namespace, database, persistence, logger);
    stores.add(storage);
    var resources = new ResourceModule(storage);
    var type = Class.forName("dev.starcore.starcore.module.treasury.SqlTreasuryStateStorage");
    var constructor =
        type.getDeclaredConstructor(
            String.class, DatabaseService.class, PersistenceService.class, Logger.class);
    constructor.setAccessible(true);
    var treasuryStore =
        (AbstractModuleStateStorage)
            constructor.newInstance(namespace, database, persistence, logger);
    stores.add(treasuryStore);
    var treasury = new TreasuryModule();
    var field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(treasury, treasuryStore);
    var load = TreasuryModule.class.getDeclaredMethod("loadState");
    load.setAccessible(true);
    load.invoke(treasury);
    Instant baseTime =
        setup
            ? Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS)
            : Instant.parse(
                JSON.fromJson(
                        Files.readString(directory.resolve("clock.json")),
                        com.google.gson.JsonObject.class)
                    .get("instant")
                    .getAsString());
    if (setup) write("clock.json", Map.of("instant", baseTime.toString()));
    var clock = Clock.fixed(baseTime.plusSeconds(setup ? 0 : 120), ZoneOffset.UTC);
    return new Bundle(
        resources,
        storage,
        treasury,
        new SimpleNationTradeService(resources, storage, nations, treasury, clock, () -> true),
        new SimpleNationProductionService(resources, storage, nations, clock, () -> true));
  }

  private DataSource interceptedSource() {
    return (DataSource)
        Proxy.newProxyInstance(
            getClass().getClassLoader(),
            new Class<?>[] {DataSource.class},
            (proxy, method, args) -> {
              Object result = invoke(method, mysql, args);
              if (!(result instanceof Connection connection)) return result;
              var writing = new AtomicBoolean();
              return Proxy.newProxyInstance(
                  getClass().getClassLoader(),
                  new Class<?>[] {Connection.class},
                  (unused, call, parameters) -> {
                    String prefix =
                        phase.equals("trade")
                            ? "INSERT INTO starcore_nation_trade_settlements"
                            : "INSERT INTO starcore_nation_production_events";
                    if (call.getName().equals("prepareStatement")
                        && parameters[0].toString().startsWith(prefix)) writing.set(true);
                    if (call.getName().equals("commit")
                        && writing.get()
                        && armed.compareAndSet(true, false)) {
                      assertThat(connection.getAutoCommit()).isFalse();
                      // A same-connection snapshot proves actual writes occurred before the commit
                      // gate.
                      write("transaction-view.json", snapshot(connection));
                      long connectionId;
                      try (var s = connection.createStatement();
                          var r = s.executeQuery("SELECT CONNECTION_ID()")) {
                        assertThat(r.next()).isTrue();
                        connectionId = r.getLong(1);
                      }
                      boolean committed = mode.equals("jvm_after");
                      Object committedResult =
                          committed ? invoke(call, connection, parameters) : null;
                      write(
                          "gate.json",
                          Map.of(
                              "phase",
                              phase,
                              "mode",
                              mode,
                              "connection_id",
                              connectionId,
                              "commit_returned_to_wrapper",
                              committed,
                              "pid",
                              ProcessHandle.current().pid(),
                              "operation_id",
                              operation.toString()));
                      await("release");
                      return committed ? committedResult : invoke(call, connection, parameters);
                    }
                    return invoke(call, connection, parameters);
                  });
            });
  }

  private static Object invoke(Method method, Object target, Object[] args) throws Throwable {
    try {
      return method.invoke(target, args);
    } catch (InvocationTargetException error) {
      error.getCause().printStackTrace();
      throw error.getCause();
    }
  }

  private static Map<String, Object> snapshot(Connection c) throws Exception {
    var result = new TreeMap<String, Object>();
    var tables = new ArrayList<String>();
    try (var s = c.createStatement();
        var r = s.executeQuery("SHOW TABLES")) {
      while (r.next()) tables.add(r.getString(1));
    }
    assertThat(tables).containsExactlyInAnyOrderElementsOf(TABLES);
    for (String table : tables) {
      var rows = new ArrayList<List<String>>();
      var columns = new ArrayList<String>();
      try (var s = c.createStatement();
          var r = s.executeQuery("SELECT * FROM " + table)) {
        for (int i = 1; i <= r.getMetaData().getColumnCount(); i++)
          columns.add(r.getMetaData().getColumnName(i));
        while (r.next()) {
          var values = new ArrayList<String>();
          for (int i = 1; i <= columns.size(); i++) values.add(r.getString(i));
          rows.add(values);
        }
      }
      rows.sort(Comparator.comparing(JSON::toJson));
      result.put(table, Map.of("columns", columns, "rows", rows));
    }
    return result;
  }

  private Map<String, Object> snapshot() throws Exception {
    try (var c = mysql.getConnection()) {
      c.setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
      c.setAutoCommit(false);
      var result = snapshot(c);
      c.commit();
      return result;
    }
  }

  private void write(String name, Object value) throws Exception {
    Path destination = directory.resolve(name), temporary = directory.resolve(name + ".pending");
    assertThat(destination).doesNotExist();
    Files.writeString(temporary, JSON.toJson(value) + "\n", StandardOpenOption.CREATE_NEW);
    Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE);
  }

  private void await(String name) throws Exception {
    long deadline = System.nanoTime() + 90_000_000_000L;
    while (!Files.exists(directory.resolve(name))) {
      if (System.nanoTime() > deadline)
        throw new SQLException("Timed out waiting for harness " + name);
      Thread.sleep(50);
    }
  }

  private String apply(Bundle b) {
    return switch (phase) {
      case "start" ->
          b.production.start(operation, seller, "industrial_refining", 2).status().name();
      case "complete" -> b.production.complete(operation, seller).status().name();
      case "cancel" -> b.production.cancel(operation, seller).status().name();
      default -> b.trade.acceptOffer(operation, buyer).status().name();
    };
  }

  private void setup() throws Exception {
    try (var c = mysql.getConnection();
        var s = c.createStatement();
        var r = s.executeQuery("SHOW TABLES")) {
      assertThat(r.next()).as("Only an empty dedicated catalog is permitted").isFalse();
    }
    var b = bundle(true);
    assertThat(b.resources.grant(selling.id(), "mineral", 300)).isTrue();
    assertThat(b.resources.grant(selling.id(), "energy", 100)).isTrue();
    assertThat(b.treasury.tryDeposit(selling.id(), new BigDecimal("50.00"))).isTrue();
    assertThat(b.treasury.tryDeposit(buying.id(), new BigDecimal("1000.00"))).isTrue();
    if (phase.equals("trade")) {
      assertThat(b.trade.createOffer(operation, seller, buyer, "mineral", 20, 250, 600).status())
          .isEqualTo(NationTradeService.Status.CREATED);
    } else if (!phase.equals("start")) {
      assertThat(b.production.start(operation, seller, "industrial_refining", 2).status())
          .isEqualTo(NationProductionService.Status.STARTED);
    }
    write("baseline.json", snapshot());
    write(
        "identities.json",
        Map.of(
            "seller",
            seller,
            "buyer",
            buyer,
            "selling",
            selling.id().value(),
            "buying",
            buying.id().value(),
            "operation",
            operation));
  }

  private void operate() throws Exception {
    var b = bundle(false);
    armed.set(true);
    String outcome = apply(b);
    assertThat(mode).isEqualTo("mysql_before"); // JVM modes must be killed before returning.
    assertThat(outcome).isEqualTo("UNKNOWN");
    write("outage-outcome.json", Map.of("status", outcome, "database_down", true));
    await("database-restarted");
    var before = snapshot();
    assertThat(b.resources.grant(selling.id(), "mineral", 1)).isFalse();
    if (phase.equals("trade"))
      assertThat(b.treasury.tryDeposit(buying.id(), BigDecimal.ONE)).isFalse();
    assertThat(snapshot()).isEqualTo(before);
    write(
        "stale-writers.json",
        Map.of("inventory_blocked", true, "treasury_blocked", phase.equals("trade")));
  }

  private void assertOutcome(Bundle b) {
    boolean trade = phase.equals("trade"),
        cancelled = phase.equals("cancel"),
        complete = phase.equals("complete");
    assertThat(b.resources.amount(selling.id(), "mineral"))
        .isEqualTo(trade ? 280 : cancelled ? 300 : 294);
    assertThat(b.resources.amount(selling.id(), "energy")).isEqualTo(trade || cancelled ? 100 : 98);
    assertThat(b.resources.amount(selling.id(), "industrial")).isEqualTo(complete ? 4 : 0);
    assertThat(b.resources.amount(buying.id(), "mineral")).isEqualTo(trade ? 20 : 0);
    assertThat(b.treasury.balance(selling.id())).isEqualByComparingTo(trade ? "100.00" : "50.00");
    assertThat(b.treasury.balance(buying.id())).isEqualByComparingTo(trade ? "950.00" : "1000.00");
    if (trade) {
      var receipt = b.trade.settlement(operation).orElseThrow();
      assertThat(receipt.offer().sellerId()).isEqualTo(seller);
      assertThat(receipt.offer().buyerId()).isEqualTo(buyer);
      assertThat(b.trade.settlementsAfter(receipt.authorityDomain(), 0, 100))
          .containsExactly(receipt);
      assertThat(b.storage.transferReceipt(receipt.offer().transactionId())).isPresent();
      assertThat(b.treasury.transferReceipt(receipt.offer().transactionId())).isPresent();
      assertThat(b.trade.offer(operation).orElseThrow().status())
          .isEqualTo(NationTradeService.OfferStatus.SETTLED);
    } else {
      var run = b.production.run(operation, seller).orElseThrow();
      assertThat(run.run().actorId()).isEqualTo(seller);
      assertThat(run.state())
          .isEqualTo(
              complete
                  ? NationProductionService.State.COMPLETED
                  : cancelled
                      ? NationProductionService.State.CANCELLED
                      : NationProductionService.State.RUNNING);
      var receipts =
          b.production.completionsAfter(
              b.production.completionAuthorityDomain().orElseThrow(), 0, 100);
      assertThat(receipts).hasSize(complete ? 1 : 0);
      if (complete) assertThat(receipts.getFirst().run()).isEqualTo(run.run());
    }
  }

  private void verify(boolean reload) throws Exception {
    String prefix = reload ? "reload" : "verify";
    var b = bundle(false);
    var before = snapshot();
    write(prefix + "-before.json", before);
    String first = apply(b);
    assertThat(first)
        .isEqualTo(
            reload || mode.equals("jvm_after")
                ? "ALREADY_APPLIED"
                : phase.equals("start") ? "STARTED" : "APPLIED");
    assertOutcome(b);
    var after = snapshot();
    write(prefix + "-after.json", after);
    if (reload || mode.equals("jvm_after")) assertThat(after).isEqualTo(before);
    assertThat(apply(b)).isEqualTo("ALREADY_APPLIED");
    assertThat(snapshot()).isEqualTo(after);
    write(
        prefix + "-result.json",
        Map.of(
            "status",
            "PASSED",
            "first",
            first,
            "replay",
            "ALREADY_APPLIED",
            "all_tables_unchanged_on_replay",
            true));
  }

  public static void main(String[] args) throws Exception {
    assertThat(args).hasSize(4);
    var worker = new MySqlNationInFlightWorker(Path.of(args[0]), args[2], args[3]);
    try {
      switch (args[1]) {
        case "setup" -> worker.setup();
        case "operate" -> worker.operate();
        case "verify" -> worker.verify(false);
        case "reload" -> worker.verify(true);
        default -> throw new IllegalArgumentException("Unknown worker stage");
      }
    } finally {
      worker.stores.forEach(AbstractModuleStateStorage::shutdown);
    }
  }
}
