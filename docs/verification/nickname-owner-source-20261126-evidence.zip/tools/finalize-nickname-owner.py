from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path(__file__).resolve().parents[1];native=root.parent/'StarChronicle-audit/starcore-all-stages'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
phases=['baseline','baseline-final','compile','test-initial','compile-final','test-final','compile-final-recovery','test-final-recovery','package','sbom','compile-final-removal','test-final-removal','package-final']
runs={p:json.loads((root/'run'/('nickname-owner-'+p+'-20261126/result.json')).read_text()) for p in phases}
assert runs['baseline-final']['totals']==dict(tests=27,failures=25,errors=0,skipped=0)
assert runs['test-final-removal']['totals']==dict(tests=549,failures=0,errors=0,skipped=0)
artifacts=json.loads((root/'run/nickname-owner-artifacts-final-20261126/result.json').read_text())
summary={'status':'VERIFIED','baseline':{'chronicle':'233f33632adcd4fd5e505d87a0336d8f87a48974','starcore':'6d361fdabdb062d2924cf3bbcce14384cb5f182f'},
 'tests':runs['test-final-removal']['totals'],'new_tests':32,'runs':runs,
 'artifacts':{'starcore':artifacts['starcore_sha256'],'chronicle':'42c0e27b7726548faf8f2bf330af3de44e44225632645824ccf3ad102c22f071'},
 'api':artifacts['public_api'],'class_hashes':artifacts['class_hashes'],'sbom_components':artifacts['sbom_components'],
 'limits':['No Minecraft, live Paper/Folia, third-party combination or full hot-reload acceptance.',
 '549 related tests, not the whole StarCore suite; existing POM exclusions remain. One 256 MiB JVM, forkCount=0, jacoco.skip=true.',
 'Nickname index is committed in memory before display callbacks; display failure does not roll it back. Existing asynchronous persistence contract remains.',
 'Legacy synchronous NicknameCommand constructors require caller ownership and permit synchronous offline profile IO. The runtime module uses the scheduler-aware constructor.',
 'Player-file load failure quarantines writes for the lifetime of that manager, including previously queued writes. Shutdown logs write failure and drains the executor; this is not full-module atomic reload.',
 'Compiled all 2267 main and 1096 test sources, followed by Maven stale-source compilation for recovery changes. Final source count is 1097 tests. Selected frozen sources and packaged classes match.',
 'Chronicle Java unchanged: 1076 local tests and Linux CI #194 belong to 233f336; prior live evidence is not applicable to these artifacts.']}
files={}
for phase in phases:
 for p in sorted((root/'run'/('nickname-owner-'+phase+'-20261126')).rglob('*')):
  if p.is_file() and p.suffix not in ('.jar','.class'):files[phase+'/'+p.relative_to(root/'run'/('nickname-owner-'+phase+'-20261126')).as_posix()]=p.read_bytes()
for folder in ['nickname-owner-artifacts-20261126','nickname-owner-artifacts-final-20261126']:
 for p in sorted((root/'run'/folder).rglob('*')):
  if p.is_file():files[folder+'/'+p.name]=p.read_bytes()
for name in ['run/run-nickname-owner.py','run/verify-nickname-owner-artifacts.py','run/finalize-nickname-owner.py',
 'run/github-technology-merge-ci-success-20261126.log','run/github-technology-merge-ci-20261126.json','run/github-technology-merge-delivery-git-20261126.json']:
 files['tools/'+Path(name).name]=(root/name).read_bytes()
for name in ['pom.xml','docs/NICKNAME-OWNERSHIP.md','target/starcore-1.0.0-sbom.json']:
 files['native/'+name]=(native/name).read_bytes()
files['native/change.patch']=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=native)
files['manifest.json']=(json.dumps({'summary':summary,'files':{n:sha(b) for n,b in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
out=root/'docs/verification/nickname-owner-source-20261126-evidence.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
with zipfile.ZipFile(out) as z:
 m=json.loads(z.read('manifest.json'));assert set(z.namelist())==set(m['files'])|{'manifest.json'}
 for name,digest in m['files'].items():assert sha(z.read(name))==digest,name
summary['evidence_files']=len(files);summary['evidence_sha256']=sha(out.read_bytes())
(root/'docs/verification/nickname-owner-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report=f'''# Essentials 昵称所有权、并发索引与恢复保护：2026-11-26

`/realname` 原先在查询者线程直接读取其他玩家，离线查名也可能阻塞命令线程。昵称的两个 ConcurrentHashMap 不能保证共同原子更新，并发争用可产生两个昵称主人；重复加载还会留下旧反向索引。本次按原玩家 owner 调度查名及反馈，加入会话／生命周期复核，以短锁更新双向索引，并阻止拒绝的玩家文件被后续保存覆盖。没有启动 Minecraft。

| 构件 | SHA-256 |
| --- | --- |
| StarCore | `{summary['artifacts']['starcore']}` |
| Chronicle，本轮 Java 未改 | `{summary['artifacts']['chronicle']}` |
| 证据 ZIP | `{summary['evidence_sha256']}` |

[证据包](verification/nickname-owner-source-20261126-evidence.zip)含 **{len(files)} 文件**，[机器摘要](verification/nickname-owner-source-20261126-summary.json)保存失败／成功 XML、冻结源码、构建、依赖清单及 API／类字节结果，并归档 Chronicle `233f336` 的 [Linux CI #194](https://github.com/addxiaoyi/StarChronicle/actions/runs/45764029889) 成功日志。

## 行为与边界

- 在线名字在确切目标 Player 的 owner 采集；离线资料查询异步执行，若查询期间上线或接口直接返回 Player，再切回该 owner。结果回原玩家会话、控制台全局线程或命令方块已捕获的区域；含空格昵称可用全部参数查询。
- 旧会话、停用、退休、注册异常和重复回调不能发布过期回复；投递前再次核对昵称归属。旧构造器保留同步契约，调用方必须已拥有访问的玩家并允许离线资料 I/O；实际模块接入新构造器。
- 昵称检查、旧索引移除及新索引发布在同一短锁内完成。并发争用只有一个成功者；清理只移除属于该 UUID 的反向索引。空加载（包括文件省略昵称字段）替换旧值，无效／冲突输入保持旧昵称状态并抛错；公开快照保持一致且不可修改。
- Bukkit 显示名操作位于锁外，需要调用方拥有原 Player；显示失败不回滚已准入的内存索引。昵称仍沿用异步保存，不是同步持久提交或客户端送达保证。
- 玩家文件加载失败后，在该数据管理器生命周期内禁止该 UUID 的写入，连失败前排队的保存也受阻。其他玩家仍可保存；修复文件后须通过正常离线重启建立新管理器。同一管理器重复加载不解除隔离。停机按原契约记录保存失败并排空线程，不向调用者承诺抛错；未宣称所有玩家数据重载原子化。

## 验证

| 运行 | tests | failures | errors | skipped |
| --- | ---: | ---: | ---: | ---: |
| 旧实现对照（修正初轮测试编译错误后） | 27 | 25 | 0 | 0 |
| 初轮昵称专项及旧测试 | 75 | 0 | 1 | 0 |
| 加入文件恢复保护 | 548 | 2 | 0 | 0 |
| 修正停机契约后的相关回归 | 548 | 0 | 0 | 0 |
| 补齐文件缺省昵称清理后的最终回归 | **549** | **0** | **0** | **0** |

初轮编译错误为测试中 Object 未转为 CommandSender；专项 1 error 为 Mockito 嵌套取 mock 参数导致未完成桩设置；扩大回归的 2 failures 为测试误要求停机保存抛错。修正测试后全部通过，各轮均独立保留。新增 **32 项**：20 查名所有权／会话、7 并发索引与锁外调用、5 真实临时文件恢复。最终 549 项包括 506 调度器／Essentials、43 自带经济／Vault／交易账本，不是全库回归；保留 POM 既有排除。

首次编译 2,267 主源与 1,096 测试源，之后文件保护增量由 Maven 编译，最终 1,097 测试源。Spotless、独立 verify 打包、36 组件 SBOM、{len(artifacts['class_hashes'])} 个相关类字节和 4 类旧公开声明／描述符核验通过。每次一个 256 MiB JVM，forkCount=0、jacoco.skip=true，无本机覆盖率。

Chronicle 保持 1,076 项本地／Linux CI 通过，科技合并交付的 1,327 个 Git 项目文件和 13 份证据 ZIP 核对通过。旧原生构件的私聊 517 项、经济／传送及国库／贸易／工厂契约各保持原范围；本次类字节和单测不能替代实服。下一步继续排行榜 GUI、其他社交／生命周期、外部经济未知结果与长期容量；当前构件 Paper／Folia 与第三方组合验收仍待办。
'''
(root/'docs/NICKNAME-OWNER-SOURCE-20261126.md').write_text(report,encoding='utf-8')
note=f'2026-11-26 StarCore 当前检查点：[昵称所有权、并发索引与恢复保护](NICKNAME-OWNER-SOURCE-20261126.md)。查名在目标 owner／异步资料线程采集，回复复核原会话与昵称归属；双向昵称索引原子更新，拒绝加载的玩家文件保持隔离。新增 32 项，**549 项相关回归通过**；StarCore `{artifacts["starcore_sha256"][:8]}…{artifacts["starcore_sha256"][-6:]}` 打包／36 组件 SBOM／API／类字节通过。Chronicle 保持 1,076 项与 Linux CI #194 通过。继续 GUI 与剩余源码工作，不启动 Minecraft。'
for name in ['README.md','docs/HANDOFF-2026-11-25.md','docs/HANDOFF-2026-11-26.md','docs/REMAINING-WORK.md']:
 p=root/name;t=p.read_text(encoding='utf-8');pos=t.index('\n\n')+2
 inserted=note.replace('(NICKNAME-OWNER-SOURCE-20261126.md)','(docs/NICKNAME-OWNER-SOURCE-20261126.md)') if name=='README.md' else note
 t=t[:pos]+inserted+'\n\n'+t[pos:]
 if name=='docs/HANDOFF-2026-11-26.md':
  t=t.replace('最新 StarCore 517 项及社交修复见 [私聊报告](SOCIAL-OWNER-SOURCE-20261126.md)','最新 StarCore 549 项及昵称修复见 [昵称报告](NICKNAME-OWNER-SOURCE-20261126.md)',1)
  t=t.replace('经济及 Essentials 私聊／屏蔽所有权已分批修复 | 其他社交、GUI／昵称等调用链','经济及 Essentials 私聊／屏蔽／昵称所有权已分批修复 | 其他社交、GUI 等调用链',1)
  t=t.replace('SOCIAL-OWNER-SOURCE-20261126.md 与 REMAINING-WORK.md','NICKNAME-OWNER-SOURCE-20261126.md 与 REMAINING-WORK.md',1)
  t=t.replace('StarCore `6d361fd`／`dd069f79` 的独立 517 项相关回归通过',f'StarCore 昵称检查点 `{artifacts["starcore_sha256"][:8]}` 的独立 549 项相关回归通过',1)
  t=t.replace('其他社交／GUI／昵称所有权','其他社交／GUI 所有权',1)
 p.write_text(t,encoding='utf-8')
print(json.dumps({'artifacts':summary['artifacts'],'evidence_files':len(files),'evidence_sha256':summary['evidence_sha256']}))
