package dev.starcore.starcore.essentials.command;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.core.scheduler.FoliaCompatScheduler;
import dev.starcore.starcore.essentials.EssentialsPermissions;
import dev.starcore.starcore.essentials.nickname.NicknameService;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.logging.Logger;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.mockito.Answers;
import org.mockito.MockedStatic;

/** Queues model distinct entity owners and the async/global/region executors. */
class NicknameOwnershipTest {
  private static final Object ASYNC = new Object(), GLOBAL = new Object(), REGION = new Object();
  private final Plugin plugin = mock(Plugin.class);
  private final Server server = mock(Server.class);
  private final FoliaCompatScheduler scheduler = mock(FoliaCompatScheduler.class);
  private final NicknameService service = new NicknameService();
  private final Map<UUID, Player> online = new HashMap<>();
  private final Map<UUID, OfflinePlayer> profiles = new HashMap<>();
  private final Map<CommandSender, List<String>> messages = new IdentityHashMap<>();
  private final Deque<Job> jobs = new ArrayDeque<>();
  private Object owner, rejected;
  private boolean enabled = true, lifetime = true, failAfterQueue;
  private Player sender, target;
  private Location queuedRegion;
  private NicknameCommand command;
  private MockedStatic<Bukkit> bukkit;

  private record Job(Object owner, Runnable body, Runnable retired) {}

  @BeforeEach
  void setup() throws Exception {
    when(plugin.getServer()).thenReturn(server);
    when(plugin.isEnabled()).thenAnswer(i -> enabled);
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    when(server.getPlayer(any(UUID.class))).thenAnswer(i -> online.get(i.getArgument(0)));
    when(server.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner, "Offline profile lookup must be async");
              return profiles.get(i.getArgument(0));
            });
    doAnswer(
            i -> {
              enqueue(
                  i.getArgument(0),
                  () -> i.<Consumer<Object>>getArgument(1).accept(null),
                  i.getArgument(2));
              return null;
            })
        .when(scheduler)
        .runAtEntity(any(), any(), any());
    doAnswer(
            i -> {
              enqueue(ASYNC, i.getArgument(0), () -> {});
              return null;
            })
        .when(scheduler)
        .runAsync(any());
    doAnswer(
            i -> {
              enqueue(GLOBAL, i.getArgument(0), () -> {});
              return null;
            })
        .when(scheduler)
        .runGlobal(any());
    doAnswer(
            i -> {
              queuedRegion = i.getArgument(0);
              enqueue(REGION, () -> i.<Consumer<Object>>getArgument(1).accept(null), () -> {});
              return null;
            })
        .when(scheduler)
        .runAtLocation(any(), any());
    sender = player(UUID.randomUUID(), "Sender");
    target = player(UUID.randomUUID(), "Target");
    service.loadPlayerData(target.getUniqueId(), "Alias");
    bukkit = mockStatic(Bukkit.class);
    bukkit
        .when(() -> Bukkit.getPlayer(any(UUID.class)))
        .thenAnswer(i -> online.get(i.getArgument(0)));
    bukkit
        .when(() -> Bukkit.getOfflinePlayer(any(UUID.class)))
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner, "Legacy lookup touched profile on command thread");
              return profiles.get(i.getArgument(0));
            });
    try {
      command =
          NicknameCommand.class
              .getConstructor(
                  NicknameService.class,
                  EssentialsPermissions.class,
                  Plugin.class,
                  FoliaCompatScheduler.class,
                  BooleanSupplier.class)
              .newInstance(
                  service,
                  EssentialsPermissions.defaults(),
                  plugin,
                  scheduler,
                  (BooleanSupplier) () -> lifetime);
    } catch (NoSuchMethodException previous) {
      command = new NicknameCommand(service, EssentialsPermissions.defaults());
    }
  }

  @AfterEach
  void close() {
    bukkit.close();
  }

  private void enqueue(Object lane, Runnable body, Runnable retired) {
    if (lane == rejected) throw new IllegalStateException("Registration rejected");
    jobs.add(new Job(lane, body, retired));
    if (failAfterQueue) throw new IllegalStateException("Registration response lost");
  }

  private Player player(UUID id, String name) {
    Player player =
        mock(
            Player.class,
            i -> {
              String method = i.getMethod().getName();
              if (method.equals("getUniqueId")) return id;
              if (Set.of(
                      "getName",
                      "isOnline",
                      "sendMessage",
                      "hasPermission",
                      "setDisplayName",
                      "setPlayerListName")
                  .contains(method)) {
                assertSame(i.getMock(), owner, "Foreign player access: " + method);
                return switch (method) {
                  case "getName" -> name;
                  case "isOnline" -> online.get(id) == i.getMock();
                  case "hasPermission" -> true;
                  case "sendMessage" -> {
                    record((CommandSender) i.getMock(), i.getArgument(0));
                    yield null;
                  }
                  default -> null;
                };
              }
              return Answers.RETURNS_DEFAULTS.answer(i);
            });
    online.put(id, player);
    messages.put(player, new ArrayList<>());
    return player;
  }

  private void record(CommandSender sender, Object message) {
    messages
        .get(sender)
        .add(
            message instanceof Component c
                ? PlainTextComponentSerializer.plainText().serialize(c)
                : String.valueOf(message));
  }

  private void at(Object lane, Runnable action) {
    Object before = owner;
    owner = lane;
    try {
      action.run();
    } finally {
      owner = before;
    }
  }

  private void run(Job job) {
    at(job.owner(), job.body());
  }

  private void drain() {
    int limit = 30;
    while (!jobs.isEmpty()) {
      assertTrue(limit-- > 0);
      run(jobs.remove());
    }
  }

  private void invoke(CommandSender who, Object lane, String name, String... args) {
    Command cmd = mock(Command.class);
    when(cmd.getName()).thenReturn(name);
    at(lane, () -> command.onCommand(who, cmd, name, args));
  }

  private void query() {
    invoke(sender, sender, "realname", "Alias");
  }

  private void offline(String name) {
    online.remove(target.getUniqueId());
    OfflinePlayer profile = mock(OfflinePlayer.class);
    when(profile.getName())
        .thenAnswer(
            i -> {
              assertSame(ASYNC, owner);
              return name;
            });
    profiles.put(target.getUniqueId(), profile);
  }

  @Test
  void onlineNameReturnsFromTargetOwnerToOriginalSender() {
    query();
    assertTrue(messages.get(sender).isEmpty());
    drain();
    assertEquals(List.of("昵称 Alias 的真实名称是: Target"), messages.get(sender));
  }

  @Test
  void offlineLookupRunsAsyncAndReturnsToSenderOwner() {
    offline("Away");
    query();
    drain();
    assertTrue(messages.get(sender).getFirst().endsWith("Away"));
  }

  @Test
  void unavailableOfflineNameHasOneHonestReply() {
    offline(null);
    query();
    drain();
    assertEquals(List.of("无法获取该玩家的真实名称"), messages.get(sender));
  }

  @Test
  void senderReconnectBeforeLookupSuppressesOldReply() {
    query();
    Player replacement = player(sender.getUniqueId(), "Replacement");
    drain();
    assertTrue(messages.get(sender).isEmpty());
    assertTrue(messages.get(replacement).isEmpty());
  }

  @Test
  void senderReconnectAfterLookupSuppressesQueuedReply() {
    query();
    run(jobs.remove());
    Player replacement = player(sender.getUniqueId(), "Replacement");
    drain();
    assertTrue(messages.get(sender).isEmpty());
    assertTrue(messages.get(replacement).isEmpty());
  }

  @Test
  void targetReconnectDoesNotReadTheRetiredObjectOrReplacement() {
    query();
    player(target.getUniqueId(), "Replacement");
    drain();
    assertEquals(List.of("无法获取该玩家的真实名称"), messages.get(sender));
  }

  @Test
  void retiredTargetReturnsFailureOnTheSenderOwner() {
    query();
    Job queued = jobs.remove();
    queued.retired().run();
    drain();
    assertEquals(List.of("无法获取该玩家的真实名称"), messages.get(sender));
    run(queued);
    assertTrue(jobs.isEmpty());
  }

  @Test
  void disabledLifetimeDropsQueuedWork() {
    query();
    lifetime = false;
    drain();
    assertTrue(messages.get(sender).isEmpty());
  }

  @Test
  void disabledPluginDropsQueuedReply() {
    query();
    run(jobs.remove());
    enabled = false;
    drain();
    assertTrue(messages.get(sender).isEmpty());
  }

  @Test
  void duplicateCallbacksProduceOneReply() {
    query();
    Job read = jobs.remove();
    run(read);
    run(read);
    Job reply = jobs.remove();
    run(reply);
    run(reply);
    assertTrue(jobs.isEmpty());
    assertEquals(1, messages.get(sender).size());
  }

  @Test
  void rejectedTargetReportsUnavailability() {
    rejected = target;
    query();
    drain();
    assertEquals(List.of("无法获取该玩家的真实名称"), messages.get(sender));
  }

  @Test
  void failedRegistrationCannotExecuteItsLateCallback() {
    failAfterQueue = true;
    query();
    failAfterQueue = false;
    drain();
    assertTrue(messages.get(sender).isEmpty());
  }

  @Test
  void changedNicknameBindingCannotPublishStaleIdentity() {
    query();
    run(jobs.remove());
    service.cleanup(target.getUniqueId());
    drain();
    assertEquals(List.of("昵称已变更，请重新查询"), messages.get(sender));
  }

  @Test
  void nicknameWithSpacesCanBeResolved() {
    service.loadPlayerData(target.getUniqueId(), "Two Words");
    invoke(sender, sender, "realname", "Two", "Words");
    drain();
    assertEquals(List.of("昵称 Two Words 的真实名称是: Target"), messages.get(sender));
  }

  @Test
  void lateOfflineLookupFindingAnOnlinePlayerUsesThatOwner() {
    offline("Away");
    query();
    online.put(target.getUniqueId(), target);
    drain();
    assertEquals(List.of("昵称 Alias 的真实名称是: Target"), messages.get(sender));
  }

  @Test
  void offlineLookupReturningPlayerDoesNotReadItAsync() {
    offline("Away");
    query();
    UUID targetId = target.getUniqueId();
    profiles.put(targetId, target);
    doAnswer(
            i -> {
              assertSame(ASYNC, owner);
              online.put(target.getUniqueId(), target);
              return target;
            })
        .when(server)
        .getOfflinePlayer(targetId);
    drain();
    assertEquals(List.of("昵称 Alias 的真实名称是: Target"), messages.get(sender));
  }

  @Test
  void consoleReplyReturnsToGlobalExecutor() {
    ConsoleCommandSender console = mock(ConsoleCommandSender.class);
    messages.put(console, new ArrayList<>());
    doAnswer(
            i -> {
              assertSame(GLOBAL, owner);
              record(console, i.getArgument(0));
              return null;
            })
        .when(console)
        .sendMessage(any(Component.class));
    invoke(console, GLOBAL, "realname", "Alias");
    drain();
    assertEquals(1, messages.get(console).size());
  }

  @Test
  void commandBlockReplyUsesItsCapturedRegion() {
    BlockCommandSender block = mock(BlockCommandSender.class);
    Block state = mock(Block.class);
    Location location = new Location(mock(World.class), 1, 2, 3);
    when(block.getBlock())
        .thenAnswer(
            i -> {
              assertSame(REGION, owner);
              return state;
            });
    when(state.getLocation()).thenReturn(location);
    messages.put(block, new ArrayList<>());
    doAnswer(
            i -> {
              assertSame(REGION, owner);
              record(block, i.getArgument(0));
              return null;
            })
        .when(block)
        .sendMessage(any(Component.class));
    invoke(block, REGION, "realname", "Alias");
    location.setX(999);
    drain();
    assertEquals(1, queuedRegion.getX());
    assertEquals(1, messages.get(block).size());
  }

  @Test
  void disabledCommandCannotChangeNickname() {
    lifetime = false;
    invoke(sender, sender, "nick", "Chosen");
    assertTrue(service.getNickname(sender.getUniqueId()).isEmpty());
    assertTrue(messages.get(sender).isEmpty());
  }

  @Test
  void replacedSenderCannotChangeNickname() {
    player(sender.getUniqueId(), "Replacement");
    invoke(sender, sender, "nick", "Chosen");
    assertTrue(service.getNickname(sender.getUniqueId()).isEmpty());
  }
}
