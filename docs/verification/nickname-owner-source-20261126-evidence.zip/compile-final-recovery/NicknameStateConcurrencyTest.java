package dev.starcore.starcore.essentials.nickname;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;
import java.util.concurrent.*;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;

class NicknameStateConcurrencyTest {
  private final NicknameService service = new NicknameService();

  private Player player(UUID id) {
    Player player = mock(Player.class);
    when(player.getUniqueId()).thenReturn(id);
    when(player.getName()).thenReturn("RealName");
    return player;
  }

  @Test
  void twoOwnersCannotClaimTheSameNicknameConcurrently() throws Exception {
    UUID first = UUID.randomUUID(), second = UUID.randomUUID();
    CyclicBarrier gate = new CyclicBarrier(2);
    Player a = player(first), b = player(second);
    when(a.getUniqueId())
        .thenAnswer(
            i -> {
              gate.await(5, TimeUnit.SECONDS);
              return first;
            });
    when(b.getUniqueId())
        .thenAnswer(
            i -> {
              gate.await(5, TimeUnit.SECONDS);
              return second;
            });
    try (ExecutorService executor = Executors.newFixedThreadPool(2)) {
      Future<Boolean> left = executor.submit(() -> service.setNickname(a, "Shared"));
      Future<Boolean> right = executor.submit(() -> service.setNickname(b, "sHaReD"));
      boolean firstWon = left.get(10, TimeUnit.SECONDS),
          secondWon = right.get(10, TimeUnit.SECONDS);
      assertNotEquals(firstWon, secondWon);
      UUID winner = firstWon ? first : second;
      assertEquals(Set.of(winner), service.getAllNicknames().keySet());
      assertEquals(winner, service.getPlayerByNickname("shared").orElseThrow());
    }
  }

  @Test
  void loadedReplacementRemovesTheOldReverseIndex() {
    UUID id = UUID.randomUUID();
    service.loadPlayerData(id, "Before");
    service.loadPlayerData(id, "After");
    assertTrue(service.getPlayerByNickname("Before").isEmpty());
    assertEquals(id, service.getPlayerByNickname("After").orElseThrow());
  }

  @Test
  void emptyLoadedStateReplacesTheOldNickname() {
    UUID id = UUID.randomUUID();
    for (String empty : Arrays.asList(null, "", " ")) {
      service.loadPlayerData(id, "Before");
      service.loadPlayerData(id, empty);
      assertTrue(service.getAllNicknames().isEmpty());
      assertTrue(service.getPlayerByNickname("Before").isEmpty());
    }
  }

  @Test
  void conflictingLoadPreservesBothPlayersAndCleanupCannotRemoveTheOtherOwner() {
    UUID a = UUID.randomUUID(), b = UUID.randomUUID();
    service.loadPlayerData(a, "Shared");
    service.loadPlayerData(b, "Original");
    Map<UUID, String> before = service.getAllNicknames();
    assertThrows(IllegalArgumentException.class, () -> service.loadPlayerData(b, "SHARED"));
    assertEquals(before, service.getAllNicknames());
    service.cleanup(b);
    assertEquals(a, service.getPlayerByNickname("Shared").orElseThrow());
    assertTrue(service.getPlayerByNickname("Original").isEmpty());
  }

  @Test
  void invalidLoadedNicknamePreservesTheExistingState() {
    UUID id = UUID.randomUUID();
    service.loadPlayerData(id, "Original");
    assertThrows(IllegalArgumentException.class, () -> service.loadPlayerData(id, "invalid!"));
    assertEquals("Original", service.getPlayerData(id));
    assertEquals(id, service.getPlayerByNickname("Original").orElseThrow());
  }

  @Test
  void playerDisplayCallbacksDoNotHoldTheStateLock() throws Exception {
    UUID id = UUID.randomUUID();
    Player player = player(id);
    try (ExecutorService observer = Executors.newSingleThreadExecutor()) {
      doAnswer(
              i -> {
                assertEquals(
                    "Chosen",
                    observer.submit(() -> service.getPlayerData(id)).get(3, TimeUnit.SECONDS));
                return null;
              })
          .when(player)
          .setDisplayName("Chosen");
      assertTrue(service.setNickname(player, "Chosen"));
      doAnswer(
              i -> {
                assertTrue(
                    observer
                        .submit(() -> service.getAllNicknames().isEmpty())
                        .get(3, TimeUnit.SECONDS));
                return null;
              })
          .when(player)
          .setDisplayName("RealName");
      assertTrue(service.removeNickname(player));
    }
  }

  @Test
  void displayFailureKeepsTheCommittedIndexAndDoesNotStealTheName() {
    UUID id = UUID.randomUUID();
    Player player = player(id);
    doThrow(new IllegalStateException("display unavailable")).when(player).setDisplayName("Chosen");
    assertThrows(IllegalStateException.class, () -> service.setNickname(player, "Chosen"));
    assertEquals(id, service.getPlayerByNickname("Chosen").orElseThrow());
    assertFalse(service.setNickname(player(UUID.randomUUID()), "Chosen"));
  }
}
