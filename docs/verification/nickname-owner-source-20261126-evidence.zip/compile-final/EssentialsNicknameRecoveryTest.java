package dev.starcore.starcore.essentials.data;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import dev.starcore.starcore.essentials.baltop.BalTopService;
import dev.starcore.starcore.essentials.home.HomeService;
import dev.starcore.starcore.essentials.nickname.NicknameService;
import dev.starcore.starcore.essentials.social.SocialService;
import dev.starcore.starcore.essentials.warp.WarpService;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.MockedStatic;

class EssentialsNicknameRecoveryTest {
  @TempDir Path directory;
  private final NicknameService nicknames = new NicknameService();
  private final UUID first = UUID.randomUUID(), second = UUID.randomUUID();
  private EssentialsDataManager manager;
  private ExecutorService writer;
  private MockedStatic<Bukkit> bukkit;

  @BeforeEach
  void setup() {
    bukkit = mockStatic(Bukkit.class);
    bukkit.when(Bukkit::getOnlinePlayers).thenReturn(List.of());
    createManager();
  }

  private void createManager() {
    Plugin plugin = mock(Plugin.class);
    when(plugin.getDataFolder()).thenReturn(directory.toFile());
    when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
    writer = Executors.newSingleThreadExecutor();
    manager =
        new EssentialsDataManager(
            plugin,
            new HomeService(3),
            new WarpService(),
            nicknames,
            new SocialService(),
            new BalTopService(),
            writer);
  }

  @AfterEach
  void close() {
    try {
      if (!writer.isShutdown()) {
        try {
          manager.shutdownAndSave();
        } catch (RuntimeException expectedQuarantine) {
        }
      }
    } finally {
      bukkit.close();
    }
  }

  private Path write(UUID id, String text) throws Exception {
    Path path = directory.resolve("essentials/players/" + id + ".yml");
    Files.createDirectories(path.getParent());
    Files.writeString(path, text);
    return path;
  }

  @Test
  void conflictingProfilePreservesDiskDuringDirectPeriodicAndShutdownSaves() throws Exception {
    nicknames.loadPlayerData(first, "Taken");
    nicknames.loadPlayerData(second, "Original");
    Path file = write(second, "nickname: Taken\nignored: []\n");
    byte[] original = Files.readAllBytes(file);
    assertThrows(
        IllegalArgumentException.class, () -> manager.loadPlayerData(second, file.toFile()));
    assertEquals("Original", nicknames.getPlayerData(second));
    assertThrows(CompletionException.class, () -> manager.savePlayerData(second));
    assertThrows(CompletionException.class, manager::saveAll);
    assertTrue(
        Files.readString(directory.resolve("essentials/players/" + first + ".yml"))
            .contains("Taken"));
    assertThrows(RuntimeException.class, manager::shutdownAndSave);
    assertTrue(writer.isTerminated());
    assertArrayEquals(original, Files.readAllBytes(file));
  }

  @Test
  void queuedSaveBeforeRejectedLoadCannotOverwriteOriginalFile() throws Exception {
    CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1);
    writer.submit(
        () -> {
          entered.countDown();
          try {
            release.await(5, TimeUnit.SECONDS);
          } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
          }
        });
    assertTrue(entered.await(3, TimeUnit.SECONDS));
    nicknames.loadPlayerData(second, "Original");
    Path file = write(second, "nickname: invalid!\n");
    byte[] original = Files.readAllBytes(file);
    CompletableFuture<Void> queued = manager.savePlayerDataAsync(second);
    try {
      assertThrows(
          IllegalArgumentException.class, () -> manager.loadPlayerData(second, file.toFile()));
    } finally {
      release.countDown();
    }
    assertThrows(ExecutionException.class, () -> queued.get(5, TimeUnit.SECONDS));
    assertArrayEquals(original, Files.readAllBytes(file));
  }

  @Test
  void malformedYamlAlsoProtectsTheOriginalFromSaving() throws Exception {
    nicknames.loadPlayerData(second, "Original");
    Path file = write(second, "nickname: [unterminated\n");
    byte[] original = Files.readAllBytes(file);
    assertThrows(IllegalStateException.class, () -> manager.loadPlayerData(second, file.toFile()));
    assertThrows(CompletionException.class, () -> manager.savePlayerData(second));
    assertArrayEquals(original, Files.readAllBytes(file));
  }

  @Test
  void repairedSourceRequiresANewManagerBeforeWritesResume() throws Exception {
    nicknames.loadPlayerData(second, "Original");
    Path file = write(second, "nickname: invalid!\n");
    assertThrows(
        IllegalArgumentException.class, () -> manager.loadPlayerData(second, file.toFile()));
    write(second, "nickname: Repaired\n");
    assertThrows(IllegalStateException.class, () -> manager.loadPlayerData(second, file.toFile()));
    assertThrows(RuntimeException.class, manager::shutdownAndSave);
    assertTrue(Files.readString(file).contains("Repaired"));
    createManager();
    manager.loadPlayerData(second, file.toFile());
    manager.savePlayerData(second);
    assertEquals("Repaired", nicknames.getPlayerData(second));
    assertTrue(nicknames.getPlayerByNickname("Original").isEmpty());
  }
}
