# Nickname ownership and state

The scheduler-aware `NicknameCommand` used by Essentials reads an online name on
that exact player's owner. Offline profile lookup runs asynchronously; if it
returns an online `Player`, the name is collected on that player's owner too.
Replies return to the original player session, the console global executor, or
the command block's captured region. A disabled module, replaced player session,
retired task, duplicate callback or failed registration cannot publish an old
reply. The nickname-to-account binding is checked again before replying.

`/realname` joins all nickname arguments, including spaces supported by `/nick`.
The legacy synchronous constructors remain available to callers that already own
all accessed players and allow synchronous offline profile lookup. They are not
the Folia cross-region entry point.

Nickname forward and reverse indexes share one short state lock. Concurrent
claims are exclusive, replacement removes the old reverse binding, and cleanup
only removes a reverse binding owned by that account. Empty loaded state clears
the old nickname. Invalid or conflicting loaded values leave the prior nickname
state unchanged and report an error. State getters return consistent snapshots.
Bukkit display operations execute outside the state lock and require ownership
of the supplied player. A display exception does not roll back the committed
in-memory nickname claim; this is not a durable or network-delivery guarantee.

After a player-file load fails, the data manager preserves that file for the rest
of its lifetime. Saves queued before the failure are rejected too; other player
files can still be written. Correct the source and recreate the manager through
the normal offline restart procedure. Repeated loads on the same quarantined
manager do not release the write barrier.

Unit tests simulate distinct owner executors, retirement and reconnects, actual
concurrent nickname claims, and real temporary player files. They do not certify
live Paper/Folia behavior or a full-module atomic data reload.
