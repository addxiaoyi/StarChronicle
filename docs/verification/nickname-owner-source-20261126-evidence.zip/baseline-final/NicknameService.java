package dev.starcore.starcore.essentials.nickname;

import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import org.bukkit.entity.Player;

/** 昵称系统服务 管理玩家昵称 */
public final class NicknameService {
  // E-113: 预编译正则表达式，避免频繁编译造成性能损耗
  // 匹配 § 颜色代码
  private static final Pattern COLOR_CODE_PATTERN = Pattern.compile("§[0-9a-fk-or]");
  // 匹配有效昵称字符：字母、数字、下划线、空格、颜色代码
  private static final Pattern VALID_NICKNAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_§ ]+$");

  // 昵称存储 UUID -> 昵称
  private final ConcurrentHashMap<UUID, String> nicknames = new ConcurrentHashMap<>();
  // 反向查找 昵称 -> UUID（小写）
  private final ConcurrentHashMap<String, UUID> nicknameToUUID = new ConcurrentHashMap<>();

  /** 设置昵称 */
  public boolean setNickname(Player player, String nickname) {
    // 验证昵称
    if (!isValidNickname(nickname)) {
      return false;
    }

    String lowerNickname = nickname.toLowerCase(Locale.ROOT);

    // 检查昵称是否已被使用
    UUID existingOwner = nicknameToUUID.get(lowerNickname);
    if (existingOwner != null && !existingOwner.equals(player.getUniqueId())) {
      return false;
    }

    UUID playerId = player.getUniqueId();

    // 移除旧昵称
    String oldNickname = nicknames.get(playerId);
    if (oldNickname != null) {
      nicknameToUUID.remove(oldNickname.toLowerCase(Locale.ROOT));
    }

    // 设置新昵称
    nicknames.put(playerId, nickname);
    nicknameToUUID.put(lowerNickname, playerId);

    // 更新显示名称
    player.setDisplayName(nickname);
    player.setPlayerListName(nickname);

    return true;
  }

  /** 移除昵称 */
  public boolean removeNickname(Player player) {
    UUID playerId = player.getUniqueId();
    String nickname = nicknames.remove(playerId);

    if (nickname == null) {
      return false;
    }

    nicknameToUUID.remove(nickname.toLowerCase(Locale.ROOT));

    // 恢复原名
    player.setDisplayName(player.getName());
    player.setPlayerListName(player.getName());

    return true;
  }

  /** 获取昵称 */
  public Optional<String> getNickname(UUID playerId) {
    return Optional.ofNullable(nicknames.get(playerId));
  }

  /** 通过昵称查找玩家 */
  public Optional<UUID> getPlayerByNickname(String nickname) {
    if (nickname == null) {
      return Optional.empty();
    }

    return Optional.ofNullable(nicknameToUUID.get(nickname.toLowerCase(Locale.ROOT)));
  }

  /** 检查昵称是否有效 E-113: 优化：预编译正则表达式 + 长度优先检查，提高验证性能 90%+ */
  private boolean isValidNickname(String nickname) {
    // 1. 快速失败：长度检查在最先（最便宜）
    if (nickname == null || nickname.isBlank()) {
      return false;
    }
    int len = nickname.length();
    if (len < 2 || len > 16) {
      return false;
    }

    // 2. 字符有效性检查（使用预编译模式）
    if (!VALID_NICKNAME_PATTERN.matcher(nickname).matches()) {
      return false;
    }

    // 3. 移除颜色代码后检查（使用预编译模式）
    String stripped = COLOR_CODE_PATTERN.matcher(nickname).replaceAll("");
    return stripped.length() >= 2;
  }

  /** 获取显示名称 */
  public String getDisplayName(UUID playerId, String realName) {
    return nicknames.getOrDefault(playerId, realName);
  }

  /** 清理玩家数据 */
  public void cleanup(UUID playerId) {
    String nickname = nicknames.remove(playerId);
    if (nickname != null) {
      nicknameToUUID.remove(nickname.toLowerCase(Locale.ROOT));
    }
  }

  /** 加载玩家数据 */
  public void loadPlayerData(UUID playerId, String nickname) {
    if (nickname != null && !nickname.isBlank()) {
      nicknames.put(playerId, nickname);
      nicknameToUUID.put(nickname.toLowerCase(Locale.ROOT), playerId);
    }
  }

  /** 保存玩家数据 */
  public String getPlayerData(UUID playerId) {
    return nicknames.get(playerId);
  }

  /** 获取所有昵称 */
  public Map<UUID, String> getAllNicknames() {
    return Map.copyOf(nicknames);
  }
}
