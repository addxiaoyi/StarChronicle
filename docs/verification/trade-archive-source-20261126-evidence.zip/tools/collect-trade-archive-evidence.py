import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
files = {}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def add(path, name):
    files[name] = path.read_bytes()


for label in ('resource-test', 'snapshot-test', 'finance-test', 'package', 'sbom'):
    path = root / f'run/trade-archive-{label}-20261126.log'
    text = path.read_text(encoding='utf-8', errors='replace')
    assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text, label
    add(path, 'logs/' + path.name)
log = '\n'.join((root / f'run/trade-archive-{group}-test-20261126.log').read_text(encoding='utf-8', errors='replace')
                for group in ('resource', 'snapshot', 'finance'))
totals = dict(tests=0, failures=0, errors=0, skipped=0)
groups, suites = {}, {}
grouped = root / 'run/trade-archive-grouped-20261126'
assert json.loads((grouped / 'manifest.json').read_text())['status'] == 'PASS'
add(grouped / 'manifest.json', 'native-final/group-manifest.json')
for name in re.findall(r'\[INFO\] Running ([\w.$]+)', log):
    matches = list(grouped.glob('*/TEST-' + name + '.xml'))
    assert len(matches) == 1, name
    path = matches[0]
    suite = ET.fromstring(path.read_bytes()); assert name not in suites
    suites[name] = int(suite.attrib['tests'])
    group = 'resource' if '.resource.' in name else 'treasury' if '.treasury.' in name else 'technology'
    groups[group] = groups.get(group, 0) + suites[name]
    for key in totals:
        totals[key] += int(suite.attrib[key])
    add(path, 'native-final/surefire/' + path.name)
assert totals['tests'] == 1490 and all(totals[k] == 0 for k in ('failures', 'errors', 'skipped')), totals
new_tests = suites['dev.starcore.starcore.module.resource.TradeExecutionArchiveTest']
assert new_tests >= 50
failures = {}
for folder in (root / 'run').glob('trade-archive-*-failure-20261126'):
    counts = dict(tests=0, failures=0, errors=0, skipped=0)
    for path in folder.rglob('*'):
        if path.is_file():
            add(path, 'failures/' + folder.name + '/' + path.relative_to(folder).as_posix())
            if path.name.startswith('TEST-') and path.suffix == '.xml':
                suite = ET.fromstring(path.read_bytes())
                for key in counts:
                    counts[key] += int(suite.attrib[key])
    failures[folder.name] = counts
contracts = {}
for label, folder in (('capacity', 'trade-archive-capacity-20261126'),
                      ('trade', 'trade-contract-archive-20261126'),
                      ('factory', 'factory-contract-trade-archive-20261126')):
    directory = root / 'run' / folder
    contracts[label] = json.loads((directory / 'manifest.json').read_text(encoding='utf-8'))
    assert contracts[label]['status'] == 'PASS'
    for path in directory.rglob('*'):
        if path.is_file() and path.suffix in ('.json', '.log', '.args', '.java', '.txt'):
            add(path, label + '/' + path.relative_to(directory).as_posix())
for name in ('TradeArchiveProbe.java', 'run-trade-archive-capacity.py', 'TradeExecutionProbe.java',
             'run-trade-execution-contract.py', 'FactoryContractProbe.java', 'run-factory-contract.py'):
    add(root / 'tools' / name, 'tools/' + name)
add(Path(__file__), 'tools/collect-trade-archive-evidence.py')
for name in ('trade-archive-test-compile-20261126.log', 'compile-trade-archive-tests-20261126.cmd',
             'test-trade-archive-final-20261126.cmd', 'test-trade-archive-resource-20261126.cmd',
             'test-trade-archive-snapshot-20261126.cmd', 'test-trade-archive-finance-20261126.cmd',
             'run-trade-archive-groups.py', 'run-trade-archive-package.py',
             'package-trade-archive-20261126.cmd', 'run-trade-archive-artifacts.py'):
    add(root / 'run' / name, 'logs/' + name)
add(root / 'run/trade-recovery-final-ci-20261126.json', 'github/baseline-ci.json')
add(native / 'target/starcore-1.0.0-sbom.json', 'native-final/starcore-1.0.0-sbom.json')
sources = {}
changed = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=native).decode().split('\0')
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=native).decode().split('\0')
for name in sorted(set(changed + added)):
    if (name.startswith('src/') or name.startswith('docs/')) and (native / name).is_file():
        add(native / name, 'source/' + name)
        sources[name] = sha((native / name).read_bytes())
starcore = sha((native / 'target/starcore-1.0.0.jar').read_bytes())
chronicle = sha((root / 'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore == contracts['capacity']['artifacts']['current.jar'] == contracts['trade']['artifacts']['starcore.jar'] == contracts['factory']['artifacts']['starcore.jar']
assert chronicle == contracts['trade']['artifacts']['starchronicle.jar'] == contracts['factory']['artifacts']['starchronicle.jar']
summary = {
    'date': '2026-11-26',
    'baselines': {'chronicle': 'cf3d0143d87a5fcd55237cffb9bda8c20fad3968', 'starcore': '4644931d2b544954dbed9eae71addb512501f2f8'},
    'scope': 'SQL V2 active trade ledger and complete terminal archive, atomic first business-save migration, retained IDs, bounded recovery batches, exact merged pages, original-ID replay and corruption quarantine; no Minecraft',
    'native_tests': totals, 'tests_by_package': groups, 'new_tests': new_tests,
    'native_source_hashes': sources, 'preserved_failures': failures,
    'packaging': 'Compile, three disjoint test groups and verify each use sequential 256 MiB JVMs; verify uses tested classes and checks formatting; separate online SBOM',
    'chronicle_tests': 'Main source unchanged, prior 957-test JAR reused; baseline cf3d014 Linux Maven verification #155 passed. New CI checked after push.',
    'artifacts': {'starcore_sha256': starcore, 'starchronicle_sha256': chronicle}, 'contracts': contracts,
    'limits': ['Focused resource/treasury/research suite, no current whole-native-suite, JaCoCo or MySQL certification.',
               'Old V1 first migration is still loaded in full. Files retain complete V1 ledger. Active executions and treasury receipts remain resident.',
               'Archive recovery scans every record in bounded batches. Deep OFFSET pages and archive count checks are not constant-time.',
               'V2 requires complete SQL backup including archive and receipts; old JAR cannot write V2.',
               'Fixed synthetic load and small JVMs do not certify long-term live load, Minecraft, Folia, actual third-party combinations or multi-instance linearizability.']
}
files['manifest.json'] = (json.dumps({'summary': summary, 'files': {name: sha(raw) for name, raw in sorted(files.items())}}, ensure_ascii=False, indent=2) + '\n').encode()
output = root / 'docs/verification/trade-archive-source-20261126-evidence.zip'
with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, raw in sorted(files.items()): archive.writestr(name, raw)
with zipfile.ZipFile(output) as archive:
    manifest = json.loads(archive.read('manifest.json'))
    assert set(archive.namelist()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items(): assert sha(archive.read(name)) == expected
summary['evidence_zip_sha256'] = sha(output.read_bytes()); summary['evidence_files'] = len(files)
(output.parent / 'trade-archive-source-20261126-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'tests': totals, 'by_package': groups, 'new_tests': new_tests, 'failures': failures, 'artifacts': summary['artifacts'], 'zip': summary['evidence_zip_sha256'], 'files': len(files), 'bytes': output.stat().st_size}))
