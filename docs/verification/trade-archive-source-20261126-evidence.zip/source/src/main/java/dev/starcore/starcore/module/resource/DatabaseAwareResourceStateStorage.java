package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.logging.Logger;

final class DatabaseAwareResourceStateStorage implements ResourceStateStorage {
  private final DatabaseService databaseService;
  private final ResourceStateStorage fileStorage;
  private final ResourceStateStorage sqlStorage;
  private volatile boolean sqlPreferred;

  DatabaseAwareResourceStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    this.databaseService = Objects.requireNonNull(databaseService, "databaseService");
    this.fileStorage = new PersistenceResourceStateStorage(namespace, persistenceService);
    this.sqlStorage =
        new SqlResourceStateStorage(namespace, databaseService, persistenceService, logger);
    this.sqlPreferred = databaseService.isRunning();
  }

  @Override
  public Properties load() {
    return activeStorage().load();
  }

  @Override
  public void save(Properties properties) {
    activeStorage().save(properties);
  }

  @Override
  public boolean archivesTradeExecutions() {
    return activeStorage().archivesTradeExecutions();
  }

  @Override
  public void writeTradeState(Properties state, Map<String, TradeExecution> executions) {
    activeStorage().writeTradeState(state, executions);
  }

  @Override
  public Optional<TradeExecution> archivedTradeExecution(String id) {
    return activeStorage().archivedTradeExecution(id);
  }

  @Override
  public List<TradeExecution> archivedTradeExecutions(
      dev.starcore.starcore.module.nation.model.NationId nation, long offset, int limit) {
    return activeStorage().archivedTradeExecutions(nation, offset, limit);
  }

  @Override
  public boolean archivesFactoryRuns() {
    return activeStorage().archivesFactoryRuns();
  }

  @Override
  public Optional<FactoryRun> archivedFactoryRun(String id) {
    return activeStorage().archivedFactoryRun(id);
  }

  @Override
  public void writeFactoryState(
      Properties state,
      Map<String, FactoryRun> runs,
      Map<java.util.UUID, dev.starcore.starcore.module.resource.model.Factory> factories) {
    activeStorage().writeFactoryState(state, runs, factories);
  }

  @Override
  public void validateFactoryProduction(Properties snapshot, Map<String, FactoryRun> runs) {
    activeStorage().validateFactoryProduction(snapshot, runs);
  }

  @Override
  public void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    activeStorage().saveTransfer(properties, receipt);
  }

  @Override
  public Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    return activeStorage().transferReceipt(id);
  }

  @Override
  public void validateTradeDeliveries(Properties snapshot, Map<String, TradeExecution> executions) {
    activeStorage().validateTradeDeliveries(snapshot, executions);
  }

  @Override
  public List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    return activeStorage().transferReceiptsAfter(sequence, limit);
  }

  @Override
  public long latestTransferSequence() {
    return activeStorage().latestTransferSequence();
  }

  @Override
  public void saveProduction(Properties properties, ProductionReceipt receipt) {
    activeStorage().saveProduction(properties, receipt);
  }

  @Override
  public Optional<ProductionReceipt> productionReceipt(String id) {
    return activeStorage().productionReceipt(id);
  }

  @Override
  public List<ProductionReceipt> productionReceiptsAfter(long sequence, int limit) {
    return activeStorage().productionReceiptsAfter(sequence, limit);
  }

  @Override
  public long latestProductionSequence() {
    return activeStorage().latestProductionSequence();
  }

  @Override
  public int transferReceiptCount() {
    return activeStorage().transferReceiptCount();
  }

  @Override
  public void saveAsync(Properties properties) {
    activeStorage().saveAsync(properties);
  }

  private ResourceStateStorage activeStorage() {
    if (sqlPreferred || databaseService.isRunning()) {
      sqlPreferred = true;
      return sqlStorage;
    }
    return fileStorage;
  }
}
