package dev.starcore.starcore.module.resource;

import dev.starcore.starcore.core.database.DatabaseUtils;
import dev.starcore.starcore.module.nation.model.NationId;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

/** Complete terminal execution proofs. Never deletes or reuses execution identities. */
final class SqlTradeArchive {
  static final String TABLE = "starcore_resource_trade_archive";
  private static final String PREFIX = TradeExecutionStore.PREFIX;
  static final Comparator<TradeExecution> ORDER =
      Comparator.comparing(TradeExecution::createdAt)
          .reversed()
          .thenComparing(TradeExecution::executionId);

  record Head(long count, String hash) {
    static final Head EMPTY = new Head(0, "");

    Head {
      if (count < 0
          || hash == null
          || (count == 0 ? !hash.isEmpty() : !hash.matches("[0-9a-f]{64}")))
        throw new IllegalStateException("Invalid trade archive head");
    }

    static Head from(Properties state) {
      if (!"2".equals(state.getProperty(PREFIX + "version"))) return EMPTY;
      long count = Long.parseLong(state.getProperty(PREFIX + "archive-count"));
      if (!Long.toString(count).equals(state.getProperty(PREFIX + "archive-count")))
        throw new IllegalStateException("Noncanonical trade archive count");
      return new Head(count, state.getProperty(PREFIX + "archive-head"));
    }
  }

  private SqlTradeArchive() {}

  static void ensure(Connection connection) throws SQLException {
    try (var statement = connection.createStatement()) {
      statement.execute(
          """
          CREATE TABLE IF NOT EXISTS starcore_resource_trade_archive (
            execution_key VARCHAR(64) PRIMARY KEY, archive_sequence BIGINT NOT NULL UNIQUE,
            execution_id VARCHAR(96) NOT NULL, exporter_id VARCHAR(36) NOT NULL,
            importer_id VARCHAR(36) NOT NULL, created_at BIGINT NOT NULL,
            sort_id VARCHAR(192) NOT NULL, row_data TEXT NOT NULL,
            row_hash VARCHAR(64) NOT NULL, chain_hash VARCHAR(64) NOT NULL)
          """);
    }
    DatabaseUtils.ensureIndex(
        connection, TABLE, "idx_trade_archive_exporter", "exporter_id", "created_at", "sort_id");
    DatabaseUtils.ensureIndex(
        connection, TABLE, "idx_trade_archive_importer", "importer_id", "created_at", "sort_id");
  }

  static Head head(Connection connection) throws SQLException {
    return Head.from(stateHead(connection));
  }

  static Properties stateHead(Connection connection) throws SQLException {
    var state = new Properties();
    try (var statement =
        connection.prepareStatement(
            "SELECT property_key,property_value FROM starcore_resource_state WHERE property_key IN"
                + " (?,?,?,?)")) {
      var keys =
          List.of(
              "resource.authority-domain",
              PREFIX + "version",
              PREFIX + "archive-count",
              PREFIX + "archive-head");
      for (int index = 0; index < keys.size(); index++)
        statement.setString(index + 1, keys.get(index));
      try (var rows = statement.executeQuery()) {
        while (rows.next()) state.setProperty(rows.getString(1), rows.getString(2));
      }
    }
    return state;
  }

  static void validateHead(Connection connection, Head expected) throws SQLException {
    try (var statement =
        connection.prepareStatement(
            "SELECT COUNT(*),COUNT(CASE WHEN archive_sequence BETWEEN 1 AND ? THEN 1 END) FROM "
                + TABLE)) {
      statement.setLong(1, expected.count());
      try (var rows = statement.executeQuery()) {
        rows.next();
        if (rows.getLong(1) != expected.count() || rows.getLong(2) != expected.count())
          throw new IllegalStateException("Trade archive has a gap or extra row");
      }
    }
    if (expected.count() == 0) return;
    try (var statement =
        connection.prepareStatement(
            "SELECT chain_hash FROM " + TABLE + " WHERE archive_sequence=?")) {
      statement.setLong(1, expected.count());
      try (var rows = statement.executeQuery()) {
        if (!rows.next() || !expected.hash().equals(rows.getString(1)))
          throw new IllegalStateException("Trade archive tail changed");
      }
    }
  }

  static void validateAll(
      Connection connection, Properties snapshot, Map<String, TradeExecution> active)
      throws SQLException {
    var expected = Head.from(snapshot);
    validateHead(connection, expected);
    var reservations = new TradeExecutionStore.ReservationVerifier(snapshot);
    active.values().forEach(reservations::accept);
    String domain = snapshot.getProperty("resource.authority-domain");
    long cursor = 0;
    String chain = "";
    while (cursor < expected.count()) {
      Map<String, TradeExecution> batch = new LinkedHashMap<>();
      try (var statement =
          connection.prepareStatement(
              "SELECT * FROM "
                  + TABLE
                  + " WHERE archive_sequence>? ORDER BY archive_sequence LIMIT 256")) {
        statement.setLong(1, cursor);
        try (var rows = statement.executeQuery()) {
          while (rows.next()) {
            if (rows.getLong("archive_sequence") != ++cursor)
              throw new IllegalStateException("Trade archive sequence changed");
            var value = read(rows);
            if (!value.resourceDomain().equals(domain) || active.containsKey(value.executionId()))
              throw new IllegalStateException("Archived trade domain or live identity changed");
            chain = chain(chain, cursor, rows.getString("row_hash"));
            if (!chain.equals(rows.getString("chain_hash")))
              throw new IllegalStateException("Trade archive chain changed");
            reservations.accept(value);
            batch.put(value.executionId(), value);
          }
        }
      }
      if (batch.isEmpty()) throw new IllegalStateException("Trade archive truncated");
      SqlResourceStateStorage.validateTradeReceipts(connection, batch);
    }
    if (!expected.hash().equals(chain))
      throw new IllegalStateException("Trade archive head changed");
    reservations.finish();
  }

  static Optional<TradeExecution> find(Connection connection, String id, Head head)
      throws SQLException {
    ProductionReceipt.token(id, 96);
    try (var statement = connection.prepareStatement(selected() + " WHERE a.execution_key=?")) {
      statement.setString(1, TradeExecutionStore.hash(id));
      try (var rows = statement.executeQuery()) {
        if (!rows.next()) return Optional.empty();
        var value = readSelected(rows, head);
        if (!id.equals(value.executionId()))
          throw new IllegalStateException("Trade archive identity collision");
        return Optional.of(value);
      }
    }
  }

  static List<TradeExecution> page(
      Connection connection, NationId nation, long offset, int limit, Head head)
      throws SQLException {
    if (nation == null || offset < 0 || limit < 1 || limit > 256)
      throw new IllegalArgumentException("Invalid trade archive page");
    List<TradeExecution> result = new ArrayList<>(limit);
    try (var statement =
        connection.prepareStatement(
            selected()
                + " WHERE (a.exporter_id=? OR a.importer_id=?) ORDER BY a.created_at DESC,a.sort_id"
                + " ASC LIMIT ? OFFSET ?")) {
      statement.setString(1, nation.toString());
      statement.setString(2, nation.toString());
      statement.setInt(3, limit);
      statement.setLong(4, offset);
      try (var rows = statement.executeQuery()) {
        while (rows.next()) {
          var value = readSelected(rows, head);
          if (!value.involves(nation))
            throw new IllegalStateException("Trade archive nation index changed");
          result.add(value);
        }
      }
    }
    return List.copyOf(result);
  }

  private static String selected() {
    return "SELECT a.*,p.chain_hash AS previous_hash FROM "
        + TABLE
        + " a LEFT JOIN "
        + TABLE
        + " p ON p.archive_sequence=a.archive_sequence-1";
  }

  private static TradeExecution readSelected(ResultSet row, Head expected) throws SQLException {
    var value = read(row);
    long sequence = row.getLong("archive_sequence");
    String previous = sequence == 1 ? "" : row.getString("previous_hash");
    if (sequence < 1
        || sequence > expected.count()
        || previous == null
        || !chain(previous, sequence, row.getString("row_hash"))
            .equals(row.getString("chain_hash")))
      throw new IllegalStateException("Trade archive membership changed");
    return value;
  }

  static Head append(Connection connection, Head previous, TradeExecution value)
      throws SQLException {
    if (!value.state().terminal()) throw new IllegalStateException("Cannot archive pending trade");
    var old = find(connection, value.executionId(), previous);
    if (old.isPresent()) {
      if (!old.get().equals(value))
        throw new IllegalStateException("Archived trade cannot be rewritten");
      return previous;
    }
    long sequence = Math.addExact(previous.count(), 1);
    String text = TradeExecutionStore.encode(value), rowHash = TradeExecutionStore.hash(text);
    String chain = chain(previous.hash(), sequence, rowHash);
    try (var statement =
        connection.prepareStatement(
            "INSERT INTO "
                + TABLE
                + " (execution_key,archive_sequence,execution_id,exporter_id,importer_id,created_at,sort_id,row_data,row_hash,chain_hash)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?)")) {
      statement.setString(1, TradeExecutionStore.hash(value.executionId()));
      statement.setLong(2, sequence);
      statement.setString(3, value.executionId());
      statement.setString(4, value.exporter().toString());
      statement.setString(5, value.importer().toString());
      statement.setLong(6, value.createdAt().toEpochMilli());
      statement.setString(7, sortId(value.executionId()));
      statement.setString(8, text);
      statement.setString(9, rowHash);
      statement.setString(10, chain);
      if (statement.executeUpdate() != 1) throw new SQLException("Trade archive row not inserted");
    }
    return new Head(sequence, chain);
  }

  private static TradeExecution read(ResultSet row) throws SQLException {
    String text = row.getString("row_data");
    var value = TradeExecutionStore.decode(text);
    if (!value.state().terminal()
        || !TradeExecutionStore.hash(text).equals(row.getString("row_hash"))
        || !TradeExecutionStore.hash(value.executionId()).equals(row.getString("execution_key"))
        || !value.executionId().equals(row.getString("execution_id"))
        || !value.exporter().toString().equals(row.getString("exporter_id"))
        || !value.importer().toString().equals(row.getString("importer_id"))
        || value.createdAt().toEpochMilli() != row.getLong("created_at")
        || !sortId(value.executionId()).equals(row.getString("sort_id")))
      throw new IllegalStateException("Trade archive row changed");
    return value;
  }

  private static String sortId(String id) {
    // Lowercase hexadecimal preserves ASCII identifier order under case-insensitive SQL collation.
    return HexFormat.of().formatHex(id.getBytes(StandardCharsets.US_ASCII));
  }

  private static String chain(String previous, long sequence, String row) {
    return TradeExecutionStore.hash(previous + ":" + sequence + ":" + row);
  }

  static void requireTransition(TradeExecution old, TradeExecution next) {
    if (old.equals(next)) return;
    if (old.state().terminal()) throw new IllegalStateException("Terminal trade cannot change");
    var from = new Properties();
    var to = new Properties();
    try {
      from.load(new java.io.StringReader(TradeExecutionStore.encode(old)));
      to.load(new java.io.StringReader(TradeExecutionStore.encode(next)));
    } catch (java.io.IOException impossible) {
      throw new IllegalStateException(impossible);
    }
    Set<String> mutable =
        old.state() == TradeExecution.State.AWAITING_APPROVAL
            ? Set.of(
                "export-approval",
                "import-approval",
                "state",
                "reservations",
                "route",
                "sequence",
                "finished")
            : Set.of("state", "sequence", "finished");
    for (String key : from.stringPropertyNames())
      if (!mutable.contains(key) && !from.getProperty(key).equals(to.getProperty(key)))
        throw new IllegalStateException("Frozen trade terms changed");
    boolean allowed =
        switch (old.state()) {
          case AWAITING_APPROVAL ->
              Set.of(
                      TradeExecution.State.AWAITING_APPROVAL,
                      TradeExecution.State.PREPARED,
                      TradeExecution.State.REJECTED)
                  .contains(next.state());
          case PREPARED ->
              next.state() == TradeExecution.State.PAID
                  || next.state() == TradeExecution.State.REJECTED;
          case PAID ->
              next.state() == TradeExecution.State.COMPLETED
                  || next.state() == TradeExecution.State.REFUND_PENDING;
          case REFUND_PENDING -> next.state() == TradeExecution.State.REFUNDED;
          default -> false;
        };
    if (!allowed) throw new IllegalStateException("Invalid trade checkpoint transition");
  }
}
