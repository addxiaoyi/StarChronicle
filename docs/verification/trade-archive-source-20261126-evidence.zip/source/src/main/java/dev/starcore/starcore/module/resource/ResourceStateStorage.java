package dev.starcore.starcore.module.resource;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

interface ResourceStateStorage {
  Properties load();

  void save(Properties properties);

  default boolean archivesTradeExecutions() {
    return false;
  }

  default void writeTradeState(Properties state, Map<String, TradeExecution> executions) {
    TradeExecutionStore.write(state, executions);
  }

  default Optional<TradeExecution> archivedTradeExecution(String id) {
    return Optional.empty();
  }

  default List<TradeExecution> archivedTradeExecutions(
      dev.starcore.starcore.module.nation.model.NationId nation, long offset, int limit) {
    return List.of();
  }

  /** SQL can retain completed batches outside the live snapshot; files keep the complete state. */
  default boolean archivesFactoryRuns() {
    return false;
  }

  default Optional<FactoryRun> archivedFactoryRun(String id) {
    return Optional.empty();
  }

  default void writeFactoryState(
      Properties state,
      Map<String, FactoryRun> runs,
      Map<java.util.UUID, dev.starcore.starcore.module.resource.model.Factory> factories) {
    FactoryRunStore.write(state, runs, factories);
  }

  /** File receipts are checked against the exact already loaded stockpile/run snapshot. */
  default void validateFactoryProduction(Properties snapshot, Map<String, FactoryRun> runs) {
    if ("3".equals(snapshot.getProperty(FactoryRunStore.PREFIX + "version")))
      throw new IllegalStateException("SQL factory archive is required for this snapshot");
    var verifier = new FactoryRunStore.ReceiptVerifier(runs);
    ProductionReceiptStore.validate(snapshot, verifier::accept);
    verifier.finish();
  }

  default void saveProduction(Properties properties, ProductionReceipt receipt) {
    ProductionReceiptStore.preserve(load(), properties);
    ProductionReceiptStore.append(properties, receipt);
    save(properties);
  }

  default Optional<ProductionReceipt> productionReceipt(String id) {
    return ProductionReceiptStore.find(load(), id);
  }

  default List<ProductionReceipt> productionReceiptsAfter(long sequence, int limit) {
    return ProductionReceiptStore.after(load(), sequence, limit);
  }

  default long latestProductionSequence() {
    return ProductionReceiptStore.validate(load());
  }

  default void saveTransfer(
      Properties properties, NationResourceTransactionService.TransferReceipt receipt) {
    Properties previous = load();
    ProductionReceiptStore.preserve(previous, properties);
    for (String key : previous.stringPropertyNames()) {
      if (key.startsWith("resource.transfer.")) {
        properties.setProperty(key, previous.getProperty(key));
      }
    }
    ResourceTransferReceiptStore.append(properties, receipt);
    save(properties);
  }

  default Optional<NationResourceTransactionService.TransferReceipt> transferReceipt(String id) {
    return ResourceTransferReceiptStore.find(load(), id);
  }

  /** Check every execution against the exact loaded file snapshot, without reopening it per row. */
  default void validateTradeDeliveries(
      Properties snapshot, Map<String, TradeExecution> executions) {
    if ("2".equals(snapshot.getProperty(TradeExecutionStore.PREFIX + "version")))
      throw new IllegalStateException("SQL trade archive is required for this snapshot");
    var verifier = new TradeExecutionStore.DeliveryVerifier(executions);
    ResourceTransferReceiptStore.scan(snapshot, verifier::accept);
    verifier.finish();
  }

  default List<NationResourceTransactionService.TransferReceipt> transferReceiptsAfter(
      long sequence, int limit) {
    return ResourceTransferReceiptStore.after(load(), sequence, limit);
  }

  default long latestTransferSequence() {
    return ResourceTransferReceiptStore.latestSequence(load());
  }

  default int transferReceiptCount() {
    return ResourceTransferReceiptStore.count(load());
  }

  default void saveAsync(Properties properties) {
    save(properties);
  }
}
