package dev.starcore.starcore.module.resource;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

class TradeExecutionArchiveTest {
  @TempDir Path directory;
  static final String PREFIX = TradeExecutionStore.PREFIX;

  @AfterEach
  void close() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  record Loaded(ResourceModule module, SimpleResourceTradeService trades) {}

  record Fixture(
      DataSource db,
      SqlResourceStateStorage storage,
      TradeExecutionReceiptValidationTest.Fixture source,
      Loaded loaded) {}

  Fixture fixture(String engine, int count) throws Exception {
    var helper = new TradeExecutionReceiptValidationTest();
    helper.directory = directory;
    var db = helper.database(engine);
    var source = TradeExecutionReceiptValidationTest.fixture(count);
    var storage = new SqlResourceStateStorage(db, source.state(), Logger.getAnonymousLogger());
    return new Fixture(db, storage, source, attach(storage));
  }

  static Loaded attach(ResourceStateStorage storage) throws Exception {
    var module = new ResourceModule();
    var trades = new SimpleResourceTradeService(module, null);
    TradeSnapshotValidationTest.set(module, "stateStorage", storage);
    TradeSnapshotValidationTest.set(module, "tradeService", trades);
    try {
      TradeSnapshotValidationTest.load(module);
    } catch (InvocationTargetException error) {
      if (error.getCause() instanceof RuntimeException failure) throw failure;
      throw error;
    }
    return new Loaded(module, trades);
  }

  static void flush(ResourceModule module) throws Exception {
    var method = ResourceModule.class.getDeclaredMethod("flushState");
    method.setAccessible(true);
    try {
      method.invoke(module);
    } catch (InvocationTargetException error) {
      if (error.getCause() instanceof RuntimeException cause) throw cause;
      throw error;
    }
  }

  static int resident(ResourceModule module) throws Exception {
    var field = ResourceModule.class.getDeclaredField("tradeExecutions");
    field.setAccessible(true);
    return ((Map<?, ?>) field.get(module)).size();
  }

  static void sql(DataSource db, String text) throws Exception {
    try (var connection = db.getConnection();
        var statement = connection.createStatement()) {
      statement.executeUpdate(text);
    }
  }

  static long count(DataSource db, String table) throws Exception {
    try (var connection = db.getConnection();
        var statement = connection.createStatement();
        var rows = statement.executeQuery("SELECT COUNT(*) FROM " + table)) {
      rows.next();
      return rows.getLong(1);
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void legacyMigrationRetainsEveryIdentityWithOnlyPendingExecutionsResident(String engine)
      throws Exception {
    var f = fixture(engine, 513);
    assertEquals(519, resident(f.loaded.module()));
    flush(f.loaded.module());
    assertEquals(4, resident(f.loaded.module()));
    assertEquals(515, count(f.db, SqlTradeArchive.TABLE));
    var state = f.storage.load();
    assertEquals("2", state.getProperty(PREFIX + "version"));
    assertEquals("4", state.getProperty(PREFIX + "count"));
    assertEquals("515", state.getProperty(PREFIX + "archive-count"));
    assertEquals("1", f.source.state().getProperty(PREFIX + "version"), "Old source is preserved");
    var restarted = attach(f.storage);
    assertEquals(4, resident(restarted.module()));
    for (var value : f.source.executions().values())
      assertEquals(value, restarted.trades().tradeExecution(value.executionId()).orElseThrow());
    assertFalse(restarted.trades().tradeExecution("absent").isPresent());
    var expected = f.source.executions().values().stream().sorted(SqlTradeArchive.ORDER).toList();
    for (NationId nation :
        List.of(
            TradeExecutionReceiptValidationTest.EXPORTER,
            TradeExecutionReceiptValidationTest.IMPORTER)) {
      for (int offset : List.of(0, 3, 250, 256, 500, 513, 519, 600)) {
        assertEquals(
            expected.stream().skip(offset).limit(10).toList(),
            restarted.trades().tradeExecutions(nation, offset, 10));
      }
    }
    assertTrue(restarted.trades().tradeExecutions(new NationId(new UUID(0, 99)), 0, 10).isEmpty());
    assertTrue(
        restarted
            .trades()
            .tradeExecutions(TradeExecutionReceiptValidationTest.EXPORTER, Integer.MAX_VALUE, 100)
            .isEmpty());
    flush(restarted.module());
    assertEquals(515, count(f.db, SqlTradeArchive.TABLE));
    assertEquals(state, f.storage.load(), "Unchanged save preserves the canonical snapshot");
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void downgradeAndArchiveRewritesAreRejectedWithoutLosingProof(String engine) throws Exception {
    var f = fixture(engine, 3);
    flush(f.loaded.module());
    var before = f.storage.load();
    assertThrows(IllegalStateException.class, () -> f.storage.save(f.source.state()));
    var values = new LinkedHashMap<>(TradeExecutionStore.read(before, f.storage));
    values.put(
        "complete-1",
        TradeExecutionReceiptValidationTest.execution(
            "complete-1", TradeExecution.State.AWAITING_APPROVAL, 0));
    var changed = new Properties();
    changed.putAll(before);
    f.storage.writeTradeState(changed, values);
    assertThrows(IllegalStateException.class, () -> f.storage.save(changed));
    assertEquals(before, f.storage.load());
    assertEquals(5, count(f.db, SqlTradeArchive.TABLE));
    assertEquals(
        f.source.executions().get("complete-1"),
        f.loaded.trades().tradeExecution("complete-1").orElseThrow());
  }

  static java.util.stream.Stream<Arguments> damages() {
    return java.util.stream.Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                java.util.stream.Stream.of(
                        "missing",
                        "sequence",
                        "row-data",
                        "row-hash",
                        "chain",
                        "id",
                        "exporter",
                        "importer",
                        "created",
                        "sort",
                        "receipt",
                        "premature",
                        "head",
                        "domain")
                    .map(damage -> Arguments.of(engine, damage)));
  }

  @ParameterizedTest
  @MethodSource("damages")
  void damagedArchiveOrDeliveryRejectsRestartAndPreservesStoredEvidence(
      String engine, String damage) throws Exception {
    var f = fixture(engine, 3);
    flush(f.loaded.module());
    String statement =
        switch (damage) {
          case "missing" -> "DELETE FROM " + SqlTradeArchive.TABLE + " WHERE archive_sequence=2";
          case "sequence" ->
              "UPDATE "
                  + SqlTradeArchive.TABLE
                  + " SET archive_sequence=99 WHERE archive_sequence=2";
          case "row-data" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET row_data='bad' WHERE archive_sequence=2";
          case "row-hash" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET row_hash='bad' WHERE archive_sequence=2";
          case "chain" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET chain_hash='bad' WHERE archive_sequence=2";
          case "id" ->
              "UPDATE "
                  + SqlTradeArchive.TABLE
                  + " SET execution_id='bad' WHERE archive_sequence=2";
          case "exporter" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET exporter_id='bad' WHERE archive_sequence=2";
          case "importer" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET importer_id='bad' WHERE archive_sequence=2";
          case "created" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET created_at=1 WHERE archive_sequence=2";
          case "sort" ->
              "UPDATE " + SqlTradeArchive.TABLE + " SET sort_id='bad' WHERE archive_sequence=2";
          case "receipt" ->
              "UPDATE starcore_resource_transfer_receipts SET resources='industrial=99' WHERE"
                  + " sequence=2";
          case "premature" ->
              "UPDATE starcore_resource_transfer_receipts SET transaction_id='"
                  + f.source.executions().get("REFUNDED").operationId("delivery")
                  + "' WHERE sequence=4";
          case "head" ->
              "UPDATE starcore_resource_state SET property_value='bad' WHERE property_key='"
                  + PREFIX
                  + "archive-head'";
          case "domain" ->
              "UPDATE starcore_resource_state SET"
                  + " property_value='00000000-0000-0000-0000-000000000099' WHERE"
                  + " property_key='resource.authority-domain'";
          default -> throw new AssertionError();
        };
    sql(f.db, statement);
    long rows = count(f.db, SqlTradeArchive.TABLE);
    try {
      var restarted = attach(f.storage);
      assertEquals("", restarted.module().authorityDomainId());
      assertFalse(
          restarted.module().grant(TradeExecutionReceiptValidationTest.EXPORTER, "industrial", 1));
      assertThrows(
          IllegalStateException.class, () -> restarted.trades().tradeExecution("complete-1"));
      assertThrows(IllegalStateException.class, () -> flush(restarted.module()));
    } catch (IllegalStateException rejectedBeforeModuleLoad) {
      assertThrows(IllegalStateException.class, () -> attach(f.storage));
    }
    assertEquals(rows, count(f.db, SqlTradeArchive.TABLE));
  }

  @ParameterizedTest
  @CsvSource({"sqlite,false", "sqlite,true", "h2,false", "h2,true"})
  void corruptionDuringPointOrPageReadQuarantinesWrites(String engine, boolean page)
      throws Exception {
    var f = fixture(engine, 3);
    flush(f.loaded.module());
    sql(
        f.db,
        "UPDATE " + SqlTradeArchive.TABLE + " SET row_data='bad' WHERE execution_id='complete-2'");
    assertThrows(
        IllegalStateException.class,
        () -> {
          if (page)
            f.loaded.trades().tradeExecutions(TradeExecutionReceiptValidationTest.EXPORTER, 0, 10);
          else f.loaded.trades().tradeExecution("complete-2");
        });
    assertEquals("", f.loaded.module().authorityDomainId());
    assertFalse(
        f.loaded.module().grant(TradeExecutionReceiptValidationTest.EXPORTER, "industrial", 1));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void terminalReplayDoesNotRepayAndArchiveRetainsQuotaAndRouteEvidence(String engine)
      throws Exception {
    var helper = new NativeTradeExecutionRecoveryTest();
    helper.directory = directory;
    var f = helper.fixture(engine);
    assertEquals(
        ResourceTradeService.ExecutionStatus.COMPLETED, f.execute("archive-replay").status());
    assertEquals(0, resident(f.module));
    f.assertCompleted("archive-replay");
    f.restart();
    assertEquals(0, resident(f.module));
    assertEquals(
        ResourceTradeService.ExecutionStatus.COMPLETED,
        f.service.retryTradeExecution("archive-replay", null).status());
    f.assertCompleted("archive-replay");
    var saved = f.storage.load();
    saved.setProperty("quota.0.current", "0");
    f.storage.delegate.save(saved);
    f.attach(f.money.module());
    assertEquals(
        "", f.module.authorityDomainId(), "Archived quota evidence participates in recovery");
  }

  @ParameterizedTest
  @CsvSource({
    "sqlite,before",
    "sqlite,after",
    "sqlite,unreadable",
    "h2,before",
    "h2,after",
    "h2,unreadable"
  })
  void migrationSaveFailuresRetainTheOldOrWholeNewLedgerForRetry(String engine, String failure)
      throws Exception {
    var f = fixture(engine, 3);
    var fault = new NativeTradeExecutionRecoveryTest.FaultStorage(f.storage);
    var module = attach(fault).module();
    fault.arm(1, failure);
    assertThrows(IllegalStateException.class, () -> flush(module));
    assertEquals(failure.equals("before") ? 0 : 5, count(f.db, SqlTradeArchive.TABLE));
    fault.unreadable = false;
    var restarted = attach(fault);
    for (var value : f.source.executions().values())
      assertEquals(value, restarted.trades().tradeExecution(value.executionId()).orElseThrow());
    flush(restarted.module());
    assertEquals(5, count(f.db, SqlTradeArchive.TABLE));
    assertEquals(4, resident(restarted.module()));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void failedInteriorArchiveInsertRollsBackTheWholeMigration(String engine) throws Exception {
    var f = fixture(engine, 3);
    var remaining = new java.util.concurrent.atomic.AtomicInteger(2);
    DataSource faulty =
        (DataSource)
            java.lang.reflect.Proxy.newProxyInstance(
                DataSource.class.getClassLoader(),
                new Class<?>[] {DataSource.class},
                (proxy, method, args) -> {
                  var result = TradeExecutionReceiptValidationTest.invoke(f.db, method, args);
                  if (!(result instanceof Connection connection)) return result;
                  return java.lang.reflect.Proxy.newProxyInstance(
                      Connection.class.getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (p, m, a) -> {
                        var value = TradeExecutionReceiptValidationTest.invoke(connection, m, a);
                        if (!m.getName().equals("prepareStatement")
                            || !((String) a[0]).startsWith("INSERT INTO " + SqlTradeArchive.TABLE))
                          return value;
                        return java.lang.reflect.Proxy.newProxyInstance(
                            PreparedStatement.class.getClassLoader(),
                            new Class<?>[] {PreparedStatement.class},
                            (s, sm, sa) -> {
                              var executed =
                                  TradeExecutionReceiptValidationTest.invoke(value, sm, sa);
                              if (sm.getName().equals("executeUpdate")
                                  && remaining.decrementAndGet() == 0)
                                throw new SQLException(
                                    "Injected failure after the second archive insert");
                              return executed;
                            });
                      });
                });
    var storage =
        new SqlResourceStateStorage(faulty, f.source.state(), Logger.getAnonymousLogger());
    var loaded = attach(storage);
    var before = storage.load();
    assertThrows(IllegalStateException.class, () -> flush(loaded.module()));
    assertEquals(0, count(f.db, SqlTradeArchive.TABLE));
    assertEquals(before, storage.load());
    flush(loaded.module());
    assertEquals(5, count(f.db, SqlTradeArchive.TABLE));
    assertEquals(4, resident(loaded.module()));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void archiveKeepsAsciiIdentityOrderAndRejectsFileOnlyRestore(String engine) throws Exception {
    var helper = new TradeExecutionReceiptValidationTest();
    helper.directory = directory;
    var state = ResourceStateCodec.toProperties(Map.of());
    state.setProperty("resource.authority-domain", TradeExecutionReceiptValidationTest.DOMAIN);
    Map<String, TradeExecution> values = new LinkedHashMap<>();
    for (String id : List.of("a", "A", "a:1", "A_1", "Z", "z", "0"))
      values.put(
          id, TradeExecutionReceiptValidationTest.execution(id, TradeExecution.State.REJECTED, 0));
    TradeExecutionStore.write(state, values);
    var storage =
        new SqlResourceStateStorage(helper.database(engine), state, Logger.getAnonymousLogger());
    var loaded = attach(storage);
    flush(loaded.module());
    assertEquals(
        values.values().stream().sorted(SqlTradeArchive.ORDER).toList(),
        loaded.trades().tradeExecutions(TradeExecutionReceiptValidationTest.EXPORTER, 0, 100));
    for (String id : values.keySet())
      assertEquals(values.get(id), loaded.trades().tradeExecution(id).orElseThrow());
    assertThrows(
        IllegalStateException.class,
        () ->
            TradeExecutionStore.read(
                storage.load(), TradeExecutionReceiptValidationTest.SNAPSHOT_ONLY));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void recoverySumsCurrentWindowReservationsAcrossLiveAndArchivedExecutions(String engine)
      throws Exception {
    var helper = new NativeTradeExecutionRecoveryTest();
    helper.directory = directory;
    var f = helper.fixture(engine);
    assertEquals(ResourceTradeService.ExecutionStatus.COMPLETED, f.execute("completed").status());
    var completed = f.service.tradeExecution("completed").orElseThrow();
    var prepared =
        new TradeExecution(
            "prepared",
            completed.agreementId(),
            completed.resourceDomain(),
            completed.treasuryDomain(),
            completed.exporter(),
            completed.importer(),
            completed.resourceId(),
            completed.amount(),
            completed.pricePerUnit(),
            completed.totalPrice(),
            completed.createdAt(),
            completed.expiresAt(),
            null,
            null,
            true,
            TradeExecution.State.PREPARED,
            completed.reservations(),
            completed.routeId(),
            0,
            null);
    var state = f.storage.load();
    for (String key : state.stringPropertyNames())
      if (key.startsWith("quota.") && key.endsWith(".current")) state.setProperty(key, "4");
    f.storage.writeTradeState(state, Map.of("prepared", prepared));
    f.storage.save(state);
    f.restart();
    assertFalse(f.module.authorityDomainId().isBlank());
    state = f.storage.load();
    for (String key : state.stringPropertyNames())
      if (key.startsWith("quota.") && key.endsWith(".current")) state.setProperty(key, "2");
    f.storage.save(state);
    f.restart();
    assertEquals(
        "",
        f.module.authorityDomainId(),
        "Neither half of the reservation history can be checked alone");
  }
}
