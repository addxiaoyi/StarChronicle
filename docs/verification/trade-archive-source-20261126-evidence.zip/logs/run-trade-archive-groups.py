import json
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
native = root.parent / 'StarChronicle-audit/starcore-all-stages'
output = root / 'run/trade-archive-grouped-20261126'
output.mkdir(exist_ok=False)
interrupted = root / 'run/trade-archive-interrupted-failure-20261126'
interrupted.mkdir(exist_ok=False)
shutil.copy2(root / 'run/trade-archive-resource-test-20261126.log', interrupted)
(interrupted / 'status.json').write_text(json.dumps({
    'status': 'INCOMPLETE',
    'reason': 'Tool session became unknown and process inventory confirmed no Maven/java process remained. Log has no terminal Maven result; not counted as passing.'
}, indent=2))
manifest = {'status': 'RUNNING', 'groups': {}}
def save():
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
try:
    for group, expected in (('resource', 917), ('snapshot', 376), ('finance', 197)):
        manifest['current'] = group
        save()
        script = root / f'run/test-trade-archive-{group}-20261126.cmd'
        result = subprocess.run(['cmd.exe', '/d', '/c', str(script)], cwd=native)
        log = root / f'run/trade-archive-{group}-test-20261126.log'
        shutil.copy2(log, output)
        text = log.read_text(encoding='utf-8', errors='replace')
        totals = dict(tests=0, failures=0, errors=0, skipped=0)
        folder = output / group
        folder.mkdir()
        for name in re.findall(r'\[INFO\] Running ([\w.$]+)', text):
            path = native / 'target/surefire-reports' / ('TEST-' + name + '.xml')
            shutil.copy2(path, folder)
            suite = ET.fromstring(path.read_bytes())
            for key in totals:
                totals[key] += int(suite.attrib[key])
        manifest['groups'][group] = {'exit_code': result.returncode, **totals}
        save()
        assert result.returncode == 0 and 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text, group
        assert totals == dict(tests=expected, failures=0, errors=0, skipped=0), totals
    manifest['status'] = 'PASS'
except BaseException as error:
    manifest['status'] = 'FAILED'
    manifest['error'] = repr(error)
    raise
finally:
    save()
