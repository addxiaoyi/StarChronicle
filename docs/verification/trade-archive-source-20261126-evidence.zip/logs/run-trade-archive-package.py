import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
assert json.loads((root / 'run/trade-archive-grouped-20261126/manifest.json').read_text())['status'] == 'PASS'
result = subprocess.run(['cmd.exe', '/d', '/c', str(root / 'run/package-trade-archive-20261126.cmd')],
                        cwd=root.parent / 'StarChronicle-audit/starcore-all-stages')
(root / 'run/trade-archive-package-result-20261126.json').write_text(json.dumps({'exit_code': result.returncode}) + '\n')
raise SystemExit(result.returncode)
