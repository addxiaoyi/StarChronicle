@echo off
set "JAVA_HOME=C:\tmp\jdk21\jdk-21.0.13.1+2"
set "MAVEN_OPTS=-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8 -javaagent:C:\Users\Administrator\.m2\repository\org\mockito\mockito-core\5.23.0\mockito-core-5.23.0.jar"
call mvnw.cmd -o -B -ntp -DforkCount=0 -Djacoco.skip=true -Dtest=dev.starcore.starcore.module.resource.**,!TradeSnapshotValidationTest surefire:test > C:\Users\Administrator\Documents\StarChronicle\run\trade-archive-resource-test-20261126.log 2>&1
exit /b %ERRORLEVEL%
