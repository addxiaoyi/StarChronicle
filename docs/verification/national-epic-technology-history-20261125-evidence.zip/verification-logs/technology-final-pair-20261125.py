from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path('/home/add/starchronicle-technology-history')
native = Path('/home/add/starcore-technology-history/target/technology-diplomacy-accepted-starcore-1.0.0.jar')
kind = sys.argv[1]
routes = {'tech': ('DUNGEON', 29691, 'technology-final-journal-1'),
          'trade': ('DUNGEON', 29692, 'technology-final-trade-1'),
          'members': ('DUNGEON', 29693, 'technology-final-member-1'),
          'dungeon': ('DUNGEON', 29694, 'technology-final-epic-1'),
          'war': ('WAR', 29695, 'technology-final-epic-1')}
route, port, attempt = routes[kind]
sha = hashlib.sha256((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes()).hexdigest()
assert sha == '393141d0eb89437717fe0a80bb52817cbf55aec3e0a8f020d833e57b3a41b908'
run = root/'run'/f'paper-epic-{sha[:8]}-{route.lower()}-{attempt}'
env = dict(os.environ, EPIC_MINEFLAYER_MODULE='/home/add/starchronicle/run/epic-client/node_modules/mineflayer',
           STARCHRONICLE_EPIC_FAILURE_LOG='/home/add/starchronicle/run/paper-epic-57345b09-war-linux-2/evidence/boot1.server.log',
           STARCHRONICLE_WEATHER_FAILURE_LOG=str(root/'run/paper-epic-393141d0-war-technology-epic-regression-1/evidence/boot1.server.log'),
           STARCHRONICLE_DIPLOMACY_FAILURE_FIXTURE=str(root/'run/paper-epic-393141d0-dungeon-technology-weather-epic-1/evidence/epic-fixture.jsonl'))
java = '/usr/lib/jvm/java-21-openjdk-amd64'
def call(args, log=None):
    if log:
        with Path(log).open('x') as out:
            subprocess.run(args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
    else:
        subprocess.run(args,cwd=root,env=env,check=True)

prepare = ['python3','tools/prepare-member-paper.py'] if kind == 'members' else ['python3','tools/prepare-epic-paper.py','prepare','--route',route]
prepare += ['--attempt',attempt,'--port',str(port),'--starcore',str(native),'--runtime','/tmp/starcore-mobile-paper-acceptance-20261122d']
if kind == 'members': prepare += ['--java-home',java]
call(prepare)
if kind != 'members': call(['python3','tools/prepare-epic-paper.py','compile','--run',str(run),'--java-home',java])
for boot, phase in enumerate(('first','second','third'),1):
    scenario = phase if kind in ('dungeon','war') else kind+'-'+phase
    command = ['python3','tools/epic-paper-session.py','--run',str(run),'--java-home',java,'--node','/usr/bin/node','--boot',str(boot),'--scenario',scenario]
    if kind in ('dungeon','war'): command.append('--contributions')
    call(command,run/f'evidence/boot{boot}.outer.log')
    print(f'{kind} boot {boot} complete',flush=True)

inspectors = {'tech': 'technology', 'trade': 'trade', 'members': 'member', 'dungeon': 'contribution', 'war': 'contribution'}
prefix = inspectors[kind]
call(['python3',f'tools/inspect-{prefix}-paper.py',str(run)],f'/tmp/starchronicle-technology-accepted-{kind}-inspection-20261125.log')
if kind in ('dungeon','war'):
    call(['python3','tools/inspect-epic-paper.py',str(run)],run/'evidence/independent-inspection.log')
env[{'tech':'STARCHRONICLE_TECHNOLOGY_RUN','trade':'STARCHRONICLE_TRADE_RUN','members':'STARCHRONICLE_MEMBER_RUN','dungeon':'STARCHRONICLE_EPIC_RUN','war':'STARCHRONICLE_EPIC_RUN'}[kind]] = str(run)
call(['python3','-m','unittest','discover','-s','tools','-p',f'test_{prefix}_acceptance.py','-v'],f'/tmp/starchronicle-technology-accepted-{kind}-evidence-20261125.log')
print(json.dumps(dict(kind=kind,run=str(run),status='CHECKED')),flush=True)
