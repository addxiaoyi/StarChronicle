package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.database.DatabaseUtils;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;

/** Complete receipt proofs and append-only refunds, committed with the treasury revision. */
final class SqlTreasuryReceiptArchive {
  static final String TABLE = "starcore_treasury_receipt_archive";
  static final String PREFIX = "receipt-archive.";
  static final String SPENDING = "spending", CREDIT = "credit", TRANSFER = "transfer";

  record Head(long count, String hash) {
    static final Head EMPTY = new Head(0, "");

    Head {
      if (count < 0
          || hash == null
          || (count == 0 ? !hash.isEmpty() : !hash.matches("[0-9a-f]{64}")))
        throw new IllegalStateException("Invalid treasury archive head");
    }

    static Head from(Properties state) {
      if (!enabled(state)) {
        if (state.stringPropertyNames().stream().anyMatch(k -> k.startsWith(PREFIX)))
          throw new IllegalStateException("Unsupported treasury archive version");
        return EMPTY;
      }
      String count = state.getProperty(PREFIX + "count");
      var metadata = new HashSet<String>();
      for (String key : state.stringPropertyNames()) if (key.startsWith(PREFIX)) metadata.add(key);
      if (!metadata.equals(Set.of(PREFIX + "version", PREFIX + "count", PREFIX + "head")))
        throw new IllegalStateException("Invalid treasury archive metadata");
      long value = Long.parseLong(count);
      if (!Long.toString(value).equals(count))
        throw new IllegalStateException("Invalid archive count");
      return new Head(value, state.getProperty(PREFIX + "head"));
    }
  }

  record Entry(String kind, String id, Object receipt) {
    Entry {
      Objects.requireNonNull(receipt);
      if (id == null || id.isBlank())
        throw new IllegalStateException("Invalid treasury receipt ID");
    }

    static List<Entry> of(TreasuryStateCodec.TreasuryState state) {
      var result = new ArrayList<Entry>();
      state.spendingReceipts().forEach((id, value) -> result.add(new Entry(SPENDING, id, value)));
      state.creditReceipts().forEach((id, value) -> result.add(new Entry(CREDIT, id, value)));
      state.transferReceipts().forEach((id, value) -> result.add(new Entry(TRANSFER, id, value)));
      result.sort(Comparator.comparing(Entry::kind).thenComparing(Entry::id));
      return result;
    }

    String key() {
      return hash(kind + ":" + id);
    }

    boolean refunded() {
      return receipt instanceof NationSpendingService.SpendingReceipt r && r.refunded();
    }

    String encode() {
      var state =
          new TreasuryStateCodec.TreasuryState(
              null,
              Map.of(),
              kind.equals(SPENDING)
                  ? Map.of(id, (NationSpendingService.SpendingReceipt) receipt)
                  : Map.of(),
              kind.equals(CREDIT)
                  ? Map.of(id, (NationCreditService.CreditReceipt) receipt)
                  : Map.of(),
              kind.equals(TRANSFER)
                  ? Map.of(id, (NationTransferService.TransferReceipt) receipt)
                  : Map.of());
      Properties properties = TreasuryStateCodec.toProperties(state);
      StringBuilder text = new StringBuilder();
      new TreeSet<>(properties.stringPropertyNames())
          .forEach(
              key ->
                  text.append(key)
                      .append('=')
                      .append(
                          Base64.getEncoder()
                              .encodeToString(
                                  properties.getProperty(key).getBytes(StandardCharsets.UTF_8)))
                      .append('\n'));
      return text.toString();
    }

    static Entry decode(String kind, String id, String text) {
      var properties = new Properties();
      for (String line : text.split("\n")) {
        int equal = line.indexOf('=');
        if (equal < 1) throw new IllegalStateException("Invalid treasury archive encoding");
        String key = line.substring(0, equal);
        String value =
            new String(
                Base64.getDecoder().decode(line.substring(equal + 1)), StandardCharsets.UTF_8);
        if (properties.setProperty(key, value) != null)
          throw new IllegalStateException("Duplicate archive field");
      }
      var entries = of(TreasuryStateValidation.read(properties));
      if (entries.size() != 1) throw new IllegalStateException("Invalid treasury archive receipt");
      var result = entries.getFirst();
      if (!result.kind.equals(kind) || !result.id.equals(id) || !result.encode().equals(text))
        throw new IllegalStateException("Noncanonical treasury archive receipt");
      return result;
    }

    void requireRefundOf(Entry original) {
      if (!kind.equals(SPENDING)
          || !original.kind.equals(SPENDING)
          || !id.equals(original.id)
          || !refunded()
          || original.refunded()) throw new IllegalStateException("Treasury receipt cannot change");
      var old = (NationSpendingService.SpendingReceipt) original.receipt;
      var refunded =
          new NationSpendingService.SpendingReceipt(
              old.transactionId(),
              old.nationId(),
              old.amount(),
              old.category(),
              old.description(),
              old.appliedAt(),
              true);
      if (!new Entry(SPENDING, id, refunded).encode().equals(encode()))
        throw new IllegalStateException("Frozen treasury receipt terms changed");
    }
  }

  private SqlTreasuryReceiptArchive() {}

  static boolean enabled(Properties state) {
    return "1".equals(state.getProperty(PREFIX + "version"));
  }

  static void writeHead(Properties state, Head head) {
    state.setProperty(PREFIX + "version", "1");
    state.setProperty(PREFIX + "count", Long.toString(head.count()));
    state.setProperty(PREFIX + "head", head.hash());
  }

  static void ensure(Connection c) throws SQLException {
    String product = c.getMetaData().getDatabaseProductName().toLowerCase(Locale.ROOT);
    // Base64 preserves unrestricted legacy descriptions but expands their UTF-8 byte length.
    String proofType =
        product.contains("mysql") || product.contains("mariadb") ? "LONGTEXT" : "TEXT";
    try (var statement = c.createStatement()) {
      statement.execute(
              """
              CREATE TABLE IF NOT EXISTS starcore_treasury_receipt_archive (
                archive_sequence BIGINT PRIMARY KEY, receipt_key VARCHAR(64) NOT NULL,
                receipt_kind VARCHAR(16) NOT NULL, transaction_id TEXT NOT NULL,
                authority_domain VARCHAR(36) NOT NULL,
                refund_event INTEGER NOT NULL, row_data %s NOT NULL,
                row_hash VARCHAR(64) NOT NULL, chain_hash VARCHAR(64) NOT NULL,
                UNIQUE(receipt_key, refund_event))
              """
              .formatted(proofType));
    }
    DatabaseUtils.ensureIndex(
        c, TABLE, "idx_treasury_archive_key", "receipt_key", "archive_sequence");
  }

  static void validateHead(Connection c, Head head) throws SQLException {
    try (var statement =
        c.prepareStatement(
            "SELECT COUNT(*),COUNT(CASE WHEN archive_sequence BETWEEN 1 AND ? THEN 1 END) FROM "
                + TABLE)) {
      statement.setLong(1, head.count());
      try (var rows = statement.executeQuery()) {
        rows.next();
        if (rows.getLong(1) != head.count() || rows.getLong(2) != head.count())
          throw new IllegalStateException("Treasury archive has a gap or extra row");
      }
    }
    if (head.count() > 0) {
      try (var statement =
          c.prepareStatement("SELECT chain_hash FROM " + TABLE + " WHERE archive_sequence=?")) {
        statement.setLong(1, head.count());
        try (var rows = statement.executeQuery()) {
          if (!rows.next() || !head.hash().equals(rows.getString(1)))
            throw new IllegalStateException("Treasury archive tail changed");
        }
      }
    }
  }

  private static String selection() {
    return "SELECT a.*,p.chain_hash AS previous_hash,b.receipt_kind AS base_kind,b.transaction_id"
        + " AS base_id,b.row_data AS base_data,b.archive_sequence AS base_sequence FROM "
        + TABLE
        + " a LEFT JOIN "
        + TABLE
        + " p ON p.archive_sequence=a.archive_sequence-1 LEFT JOIN "
        + TABLE
        + " b ON b.receipt_key=a.receipt_key AND b.refund_event=0";
  }

  private static Entry read(ResultSet rows, Head head, String domain) throws SQLException {
    String kind = rows.getString("receipt_kind"),
        id = rows.getString("transaction_id"),
        text = rows.getString("row_data");
    var value = Entry.decode(kind, id, text);
    long sequence = rows.getLong("archive_sequence");
    String previous = sequence == 1 ? "" : rows.getString("previous_hash");
    int refund = rows.getInt("refund_event");
    if (sequence < 1
        || sequence > head.count()
        || previous == null
        || (refund != 0 && refund != 1)
        || !Objects.equals(domain, rows.getString("authority_domain"))
        || !value.key().equals(rows.getString("receipt_key"))
        || !hash(domain + "\n" + text).equals(rows.getString("row_hash"))
        || !chain(previous, sequence, rows.getString("row_hash"))
            .equals(rows.getString("chain_hash")))
      throw new IllegalStateException("Treasury archive receipt changed");
    if (refund == 1) {
      long base = rows.getLong("base_sequence");
      if (base < 1 || base >= sequence)
        throw new IllegalStateException("Treasury refund source missing");
      value.requireRefundOf(
          Entry.decode(
              rows.getString("base_kind"), rows.getString("base_id"), rows.getString("base_data")));
    }
    return value;
  }

  static Optional<Entry> find(Connection c, String kind, String id, Head head, String domain)
      throws SQLException {
    try (var statement =
        c.prepareStatement(
            selection() + " WHERE a.receipt_key=? ORDER BY a.archive_sequence DESC")) {
      statement.setString(1, hash(kind + ":" + id));
      Entry result = null;
      try (var rows = statement.executeQuery()) {
        while (rows.next()) {
          var value = read(rows, head, domain);
          if (!value.kind.equals(kind) || !value.id.equals(id))
            throw new IllegalStateException("Treasury receipt identity collision");
          if (result == null) result = value;
        }
      }
      return Optional.ofNullable(result);
    }
  }

  static void validateAll(Connection c, Properties state) throws SQLException {
    var head = Head.from(state);
    validateHead(c, head);
    if (!enabled(state)) return;
    var decoded = TreasuryStateValidation.readArchived(state);
    if (decoded.authorityDomainId() == null || !Entry.of(decoded).isEmpty())
      throw new IllegalStateException(
          "Archived treasury snapshot contains live receipts or has no authority");
    long cursor = 0;
    String chain = "";
    while (cursor < head.count()) {
      long before = cursor;
      try (var statement =
          c.prepareStatement(
              selection() + " WHERE a.archive_sequence>? ORDER BY a.archive_sequence LIMIT 256")) {
        statement.setLong(1, cursor);
        try (var rows = statement.executeQuery()) {
          while (rows.next()) {
            if (rows.getLong("archive_sequence") != ++cursor)
              throw new IllegalStateException("Treasury archive sequence changed");
            read(rows, head, decoded.authorityDomainId());
            chain = chain(chain, cursor, rows.getString("row_hash"));
            if (!chain.equals(rows.getString("chain_hash")))
              throw new IllegalStateException("Treasury archive chain changed");
          }
        }
      }
      if (before == cursor) throw new IllegalStateException("Treasury archive truncated");
    }
    if (!chain.equals(head.hash()))
      throw new IllegalStateException("Treasury archive head changed");
  }

  static void prepare(Connection c, Properties state, Properties stored) throws SQLException {
    if (!enabled(state)) {
      if (enabled(stored))
        throw new IllegalStateException("Cannot overwrite archived treasury with legacy snapshot");
      validateHead(c, Head.EMPTY);
      return;
    }
    var previous = Head.from(stored);
    if (!previous.equals(Head.from(state)))
      throw new IllegalStateException("Treasury archive head changed before save");
    validateHead(c, previous);
    var next = TreasuryStateValidation.readArchived(state);
    if (next.authorityDomainId() == null
        || (stored.getProperty("authorityDomainId") != null
            && !next.authorityDomainId().equals(stored.getProperty("authorityDomainId"))))
      throw new IllegalStateException("Treasury archive authority changed");
    var values = Entry.of(next);
    Head head = previous;
    if (!enabled(stored)) {
      var candidates = new HashMap<String, Entry>();
      values.forEach(value -> candidates.put(value.key(), value));
      for (var old : Entry.of(TreasuryStateValidation.read(stored))) {
        var value = candidates.get(old.key());
        if (value == null) throw new IllegalStateException("Legacy treasury receipt removed");
        if (!old.encode().equals(value.encode())) value.requireRefundOf(old);
        head = append(c, head, old, next.authorityDomainId());
      }
    }
    for (var value : values) head = append(c, head, value, next.authorityDomainId());
    for (String key : state.stringPropertyNames())
      if (key.startsWith("spending.") || key.startsWith("credit.") || key.startsWith("transfer."))
        state.remove(key);
    for (String kind : List.of(SPENDING, CREDIT, TRANSFER)) state.setProperty(kind + ".count", "0");
    writeHead(state, head);
  }

  private static Head append(Connection c, Head previous, Entry value, String domain)
      throws SQLException {
    var old = find(c, value.kind, value.id, previous, domain);
    int refund = 0;
    if (old.isPresent()) {
      if (old.get().encode().equals(value.encode())) return previous;
      value.requireRefundOf(old.get());
      refund = 1;
    }
    long sequence = Math.addExact(previous.count(), 1);
    String text = value.encode(),
        rowHash = hash(domain + "\n" + text),
        chain = chain(previous.hash(), sequence, rowHash);
    try (var statement =
        c.prepareStatement(
            "INSERT INTO "
                + TABLE
                + " (archive_sequence,receipt_key,receipt_kind,transaction_id,refund_event,row_data,row_hash,chain_hash,authority_domain)"
                + " VALUES (?,?,?,?,?,?,?,?,?)")) {
      statement.setLong(1, sequence);
      statement.setString(2, value.key());
      statement.setString(3, value.kind);
      statement.setString(4, value.id);
      statement.setInt(5, refund);
      statement.setString(6, text);
      statement.setString(7, rowHash);
      statement.setString(8, chain);
      statement.setString(9, domain);
      if (statement.executeUpdate() != 1) throw new SQLException("Treasury archive insert failed");
    }
    return new Head(sequence, chain);
  }

  private static String chain(String previous, long sequence, String row) {
    return hash(previous + ":" + sequence + ":" + row);
  }

  static String hash(String value) {
    try {
      return HexFormat.of()
          .formatHex(
              MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8)));
    } catch (java.security.NoSuchAlgorithmException impossible) {
      throw new IllegalStateException(impossible);
    }
  }
}
