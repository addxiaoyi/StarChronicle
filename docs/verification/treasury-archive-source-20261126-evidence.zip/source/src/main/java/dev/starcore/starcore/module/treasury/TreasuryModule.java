package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.module.ModuleLayer;
import dev.starcore.starcore.core.module.ModuleMetadata;
import dev.starcore.starcore.core.module.StarCoreModule;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.foundation.animation.GuiAnimationManager;
import dev.starcore.starcore.foundation.animation.SoundFeedbackManager;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.transaction.PendingRefund;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedgerService;
import dev.starcore.starcore.foundation.economy.transaction.RefundOwner;
import dev.starcore.starcore.foundation.message.MessageService;
import dev.starcore.starcore.module.economy.EconomyTrendService;
import dev.starcore.starcore.module.economy.gui.EconomyTrendGui;
import dev.starcore.starcore.module.economy.gui.EconomyTrendGuiListener;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.event.NationEventRecord;
import dev.starcore.starcore.module.nation.NationProtection;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.Nation;
import dev.starcore.starcore.module.nation.model.NationId;
import dev.starcore.starcore.module.policy.PolicyService;
import dev.starcore.starcore.module.policy.model.PolicyEffectScope;
import dev.starcore.starcore.module.treasury.BankruptcyService.Restriction;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetBill;
import dev.starcore.starcore.module.treasury.BudgetService.BudgetCategory;
import dev.starcore.starcore.module.treasury.LoanService.NationDebt;
import dev.starcore.starcore.module.treasury.TaxationService.TaxContext;
import dev.starcore.starcore.module.treasury.TaxationService.TaxType;
import dev.starcore.starcore.module.treasury.gui.TreasuryMenu;
import dev.starcore.starcore.module.treasury.gui.TreasuryMenuListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TreasuryModule
    implements StarCoreModule,
        TreasuryService,
        TreasuryRewardService,
        NationSpendingService,
        NationCreditService,
        NationTransferService {
  private static final int SCALE = 2;
  private static final BigDecimal MIN_TREASURY_AMOUNT = new BigDecimal("0.01");
  private static final BigDecimal MAX_TREASURY_BALANCE = new BigDecimal("1000000000000000.00");
  private static final String PLAYER_DEPOSIT_REFUND_REASON_PREFIX = "treasury-player-deposit:";
  private static final long PLAYER_DEPOSIT_REFUND_RETRY_TICKS = 20L * 60L;
  private static final long STATE_REFRESH_INTERVAL_TICKS = 100L;

  public enum PlayerDepositStatus {
    COMPLETED,
    REJECTED,
    REFUNDED,
    REFUND_PENDING,
    MANUAL_REVIEW
  }

  public record PlayerDepositResult(PlayerDepositStatus status, UUID transactionId) {
    public boolean succeeded() {
      return status == PlayerDepositStatus.COMPLETED;
    }
  }

  private static final ModuleMetadata METADATA =
      new ModuleMetadata(
          "treasury",
          "金库核心",
          ModuleLayer.MODULE,
          List.of("nation", "government", "resolution"),
          List.of(
              TreasuryService.class,
              TreasuryRewardService.class,
              NationSpendingService.class,
              NationCreditService.class,
              NationTransferService.class),
          "Owns national finance, tax, budgets, and public debt abstractions.");

  private final ConcurrentMap<NationId, BigDecimal> balances = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, SpendingReceipt> spendingReceipts = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, CreditReceipt> creditReceipts = new ConcurrentHashMap<>();
  private final ConcurrentMap<String, TransferReceipt> transferReceipts = new ConcurrentHashMap<>();
  private volatile String authorityDomainId;
  private volatile boolean stateUncertain;
  private final AtomicLong txSeq = new AtomicLong();
  private final AtomicLong stateGeneration = new AtomicLong();
  private final AtomicBoolean stateRefreshInProgress = new AtomicBoolean();
  private final AtomicBoolean stateRefreshFailureLogged = new AtomicBoolean();
  private TreasuryStateStorage stateStorage;
  private StarCoreScheduler.GlobalRepeatingTask stateRefreshTask;
  private volatile Object stateRefreshToken;
  private volatile boolean stateRefreshEnabled;
  private StarCoreScheduler.GlobalRepeatingTask dailyIncomeTask;
  private volatile Object dailyIncomeToken;
  private StarCoreScheduler.GlobalRepeatingTask taxTask;
  private volatile Object taxToken;
  private StarCoreScheduler.GlobalRepeatingTask playerDepositRefundTask;
  private volatile Object playerDepositRefundToken;
  private RefundLedger refundLedger;
  private volatile StarCoreContext currentContext;
  private PolicyService policyService;

  // 子服务引用（集成模式）
  private TaxationService taxationService;
  private LoanService loanService;
  private BankruptcyService bankruptcyService;
  private BudgetService budgetService;
  private EventService eventService;

  // GUI 相关
  private TreasuryMenu treasuryMenu;
  private TreasuryMenuListener treasuryMenuListener;

  // 经济趋势分析 GUI
  private EconomyTrendService economyTrendService;
  private EconomyTrendGui economyTrendGui;
  private EconomyTrendGuiListener economyTrendGuiListener;

  // 用于从事件上下文解析金额的正则表达式
  private static final Pattern AMOUNT_PATTERN = Pattern.compile("amount=([\\d.]+)");

  @Override
  public ModuleMetadata metadata() {
    return METADATA;
  }

  @Override
  public void enable(StarCoreContext context) {
    this.currentContext = context;
    context.persistenceService().ensureNamespace(metadata().id());
    this.stateStorage =
        new DatabaseAwareTreasuryStateStorage(
            metadata().id(),
            context.databaseService(),
            context.persistenceService(),
            context.plugin().getLogger());
    // 获取 PolicyService 以应用国策效果
    this.policyService = context.serviceRegistry().find(PolicyService.class).orElse(null);
    this.refundLedger =
        context
            .serviceRegistry()
            .find(RefundLedgerService.class)
            .map(RefundLedgerService::ledger)
            .orElse(null);

    // 初始化子服务（如果已注册）
    this.taxationService = context.serviceRegistry().find(TaxationService.class).orElse(null);
    this.loanService = context.serviceRegistry().find(LoanService.class).orElse(null);
    this.bankruptcyService = context.serviceRegistry().find(BankruptcyService.class).orElse(null);
    this.budgetService = context.serviceRegistry().find(BudgetService.class).orElse(null);
    this.eventService = context.serviceRegistry().find(EventService.class).orElse(null);

    // 获取共享服务
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    GuiAnimationManager animationManager =
        context.serviceRegistry().find(GuiAnimationManager.class).orElse(null);
    SoundFeedbackManager soundManager =
        context.serviceRegistry().find(SoundFeedbackManager.class).orElse(null);

    // 初始化经济趋势分析 GUI（先创建，因为 TreasuryMenuListener 需要它）
    this.economyTrendService = new EconomyTrendService(this.eventService, this);
    this.economyTrendGui =
        new EconomyTrendGui(
            economyTrendService, this, nationService, animationManager, soundManager);
    this.economyTrendGuiListener =
        new EconomyTrendGuiListener(
            economyTrendService, this, nationService, economyTrendGui, soundManager);
    context
        .plugin()
        .getServer()
        .getPluginManager()
        .registerEvents(economyTrendGuiListener, context.plugin());

    // 初始化国库 GUI 和监听器
    this.treasuryMenu = new TreasuryMenu(this, this, nationService, animationManager, soundManager);
    this.treasuryMenuListener =
        new TreasuryMenuListener(
            this, treasuryMenu, nationService, soundManager, economyTrendGui, context.plugin());
    context
        .plugin()
        .getServer()
        .getPluginManager()
        .registerEvents(treasuryMenuListener, context.plugin());

    loadState();
    stateRefreshEnabled = true;
    scheduleStateRefresh();
    startDailyIncomeTask(context);
    startTaxTask(context);
    startPlayerDepositRefundTask(context);
  }

  @Override
  public void disable(StarCoreContext context) {
    stateRefreshEnabled = false;
    cancelStateRefresh();
    stopDailyIncomeTask();
    stopTaxTask();
    stopPlayerDepositRefundTask();
    flushState();
    this.currentContext = null;
  }

  @Override
  public synchronized BigDecimal balance(NationId nationId) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    requireStateAvailable();
    return balances.getOrDefault(nationId, BigDecimal.ZERO).setScale(SCALE, RoundingMode.DOWN);
  }

  public boolean depositFromPlayer(UUID playerId, NationId nationId, BigDecimal amount) {
    return depositFromPlayerResult(playerId, nationId, amount).succeeded();
  }

  public PlayerDepositResult depositFromPlayerResult(
      UUID playerId, NationId nationId, BigDecimal amount) {
    if (currentContext == null
        || playerId == null
        || nationId == null
        || amount == null
        || amount.signum() <= 0
        || normalize(amount).signum() <= 0) {
      return new PlayerDepositResult(PlayerDepositStatus.REJECTED, null);
    }
    synchronized (this) {
      if (stateUncertain) return new PlayerDepositResult(PlayerDepositStatus.REJECTED, null);
    }
    UUID transactionId = UUID.randomUUID();
    InternalEconomyService economy = currentContext.economyService();
    if (!economy.withdraw(playerId, amount)) {
      return new PlayerDepositResult(PlayerDepositStatus.REJECTED, transactionId);
    }
    RuntimeException treasuryFailure = null;
    try {
      if (credit(
              new CreditRequest(
                  "treasury:player-deposit:" + transactionId,
                  nationId,
                  amount,
                  CreditCategory.OTHER,
                  "Player deposit " + playerId))
          .applied()) {
        return new PlayerDepositResult(PlayerDepositStatus.COMPLETED, transactionId);
      }
    } catch (RuntimeException failure) {
      treasuryFailure = failure;
    }

    if (treasuryFailure != null) {
      // The credit may already be durable. Keep an operator-visible marker without issuing a
      // second credit to the player; the original treasury ID is derived from this marker's ID.
      var review =
          new PendingRefund(
                  transactionId,
                  playerId,
                  normalize(amount),
                  PLAYER_DEPOSIT_REFUND_REASON_PREFIX + nationId,
                  0,
                  Instant.now(),
                  "Treasury credit outcome unknown: treasury:player-deposit:" + transactionId,
                  true)
              .ownedBy(RefundOwner.NATION);
      try {
        if (refundLedger != null) refundLedger.record(review);
      } catch (RuntimeException ledgerFailure) {
        treasuryFailure.addSuppressed(ledgerFailure);
      }
      logPlayerDepositRecovery(
          Level.SEVERE,
          "code=TREASURY_PLAYER_DEPOSIT_UNKNOWN transactionId="
              + transactionId
              + " player="
              + playerId
              + " nation="
              + nationId
              + " state=MANUAL_REVIEW",
          treasuryFailure);
      return new PlayerDepositResult(PlayerDepositStatus.MANUAL_REVIEW, transactionId);
    }

    RuntimeException refundFailure = null;
    try {
      if (economy.deposit(playerId, amount)) {
        logPlayerDepositRecovery(
            Level.WARNING,
            "code=TREASURY_PLAYER_DEPOSIT_FAILED"
                + " transactionId="
                + transactionId
                + " player="
                + playerId
                + " nation="
                + nationId
                + " amount="
                + amount.toPlainString()
                + " state=REFUNDED",
            treasuryFailure);
        return new PlayerDepositResult(PlayerDepositStatus.REFUNDED, transactionId);
      }
    } catch (RuntimeException failure) {
      refundFailure = failure;
    }

    if (treasuryFailure != null && refundFailure != null) {
      treasuryFailure.addSuppressed(refundFailure);
    }
    RuntimeException recoveryFailure = treasuryFailure != null ? treasuryFailure : refundFailure;
    PendingRefund pendingRefund =
        new PendingRefund(
                transactionId,
                playerId,
                normalize(amount),
                PLAYER_DEPOSIT_REFUND_REASON_PREFIX + nationId,
                0,
                RefundLedger.nextRetry(java.time.Instant.now(), 0),
                "treasury deposit failed and player refund was rejected")
            .ownedBy(RefundOwner.NATION);
    try {
      if (refundLedger == null) {
        logPlayerDepositRecovery(
            Level.SEVERE,
            "code=TREASURY_PLAYER_DEPOSIT_REFUND_UNTRACKED"
                + " transactionId="
                + transactionId
                + " player="
                + playerId
                + " nation="
                + nationId
                + " amount="
                + pendingRefund.amount().toPlainString()
                + " state=MANUAL_REVIEW",
            recoveryFailure);
        return new PlayerDepositResult(PlayerDepositStatus.MANUAL_REVIEW, transactionId);
      }
      refundLedger.record(pendingRefund);
    } catch (RuntimeException ledgerFailure) {
      if (recoveryFailure != null) ledgerFailure.addSuppressed(recoveryFailure);
      logPlayerDepositRecovery(
          Level.SEVERE,
          "code=TREASURY_PLAYER_DEPOSIT_REFUND_LEDGER_FAILURE"
              + " transactionId="
              + transactionId
              + " player="
              + playerId
              + " nation="
              + nationId
              + " amount="
              + pendingRefund.amount().toPlainString()
              + " state=MANUAL_REVIEW",
          ledgerFailure);
      return new PlayerDepositResult(PlayerDepositStatus.MANUAL_REVIEW, transactionId);
    }

    logPlayerDepositRecovery(
        Level.SEVERE,
        "code=TREASURY_PLAYER_DEPOSIT_REFUND_PENDING"
            + " transactionId="
            + transactionId
            + " player="
            + playerId
            + " nation="
            + nationId
            + " amount="
            + pendingRefund.amount().toPlainString()
            + " state=REFUND_PENDING",
        recoveryFailure);
    return new PlayerDepositResult(PlayerDepositStatus.REFUND_PENDING, transactionId);
  }

  int retryPendingPlayerDepositRefunds() {
    return retryPendingPlayerDepositRefunds(java.time.Instant.now());
  }

  int retryPendingPlayerDepositRefunds(java.time.Instant now) {
    if (currentContext == null || refundLedger == null) return 0;
    InternalEconomyService economy = currentContext.economyService();
    java.util.Objects.requireNonNull(now, "now");
    int delivered = 0;
    for (PendingRefund refund : refundLedger.due(now, RefundOwner.NATION)) {
      if (!refund.reason().startsWith(PLAYER_DEPOSIT_REFUND_REASON_PREFIX)) continue;

      // Persist an interruption marker before crediting the account. If the server stops after
      // the balance commit but before the ledger row is removed, restart recovery must not pay it
      // a second time automatically.
      try {
        if (!refundLedger.beginDeliveryAttempt(
            refund.transactionId(),
            "refund delivery was interrupted; verify the account balance before retrying")) {
          continue;
        }
      } catch (RuntimeException ledgerFailure) {
        logPlayerDepositRecovery(
            Level.WARNING,
            "code=TREASURY_PLAYER_DEPOSIT_REFUND_RETRY_NOT_STARTED"
                + " transactionId="
                + refund.transactionId()
                + " player="
                + refund.accountId()
                + " amount="
                + refund.amount().toPlainString()
                + " state=REFUND_PENDING",
            ledgerFailure);
        continue;
      }

      try {
        boolean refundApplied;
        try {
          refundApplied = economy.deposit(refund.accountId(), refund.amount());
        } catch (RuntimeException failure) {
          // The balance operation's outcome is uncertain. Keep the durable manual-review marker.
          logPlayerDepositRecovery(
              Level.WARNING,
              "code=TREASURY_PLAYER_DEPOSIT_REFUND_RETRY_FAILURE"
                  + " transactionId="
                  + refund.transactionId()
                  + " player="
                  + refund.accountId()
                  + " amount="
                  + refund.amount().toPlainString()
                  + " state=MANUAL_REVIEW",
              failure);
          continue;
        }

        if (refundApplied) {
          try {
            refundLedger.markDelivered(refund.transactionId());
            delivered++;
          } catch (RuntimeException ledgerFailure) {
            // The durable interruption marker remains the recovery source if row removal failed.
            logPlayerDepositRecovery(
                Level.SEVERE,
                "code=TREASURY_PLAYER_DEPOSIT_REFUND_LEDGER_FAILURE"
                    + " transactionId="
                    + refund.transactionId()
                    + " player="
                    + refund.accountId()
                    + " amount="
                    + refund.amount().toPlainString()
                    + " state=MANUAL_REVIEW",
                ledgerFailure);
          }
        } else {
          try {
            refundLedger.markFailed(
                refund,
                "player deposit refund retry was rejected",
                RefundLedger.nextRetry(now, refund.attempts() + 1));
          } catch (RuntimeException ledgerFailure) {
            logPlayerDepositRecovery(
                Level.WARNING,
                "code=TREASURY_PLAYER_DEPOSIT_REFUND_RETRY_FAILURE"
                    + " transactionId="
                    + refund.transactionId()
                    + " player="
                    + refund.accountId()
                    + " amount="
                    + refund.amount().toPlainString()
                    + " state=REFUND_PENDING",
                ledgerFailure);
          }
        }
      } finally {
        refundLedger.finishDeliveryAttempt(refund.transactionId());
      }
    }
    return delivered;
  }

  private void startPlayerDepositRefundTask(StarCoreContext context) {
    stopPlayerDepositRefundTask();
    if (refundLedger == null) return;
    Object token = new Object();
    playerDepositRefundToken = token;
    AtomicBoolean pending = new AtomicBoolean();
    playerDepositRefundTask =
        context
            .scheduler()
            .runGlobalRepeatingTask(
                () -> schedulePlayerDepositRefundRetry(context, token, pending),
                PLAYER_DEPOSIT_REFUND_RETRY_TICKS,
                PLAYER_DEPOSIT_REFUND_RETRY_TICKS);
  }

  private void schedulePlayerDepositRefundRetry(
      StarCoreContext context, Object token, AtomicBoolean pending) {
    if (currentContext != context
        || playerDepositRefundToken != token
        || !pending.compareAndSet(false, true)) return;
    try {
      context
          .scheduler()
          .runIoAsync(
              () -> {
                if (currentContext == context && playerDepositRefundToken == token) {
                  retryPendingPlayerDepositRefunds();
                }
                return null;
              })
          .whenComplete(
              (ignored, failure) -> {
                pending.set(false);
                if (failure != null && playerDepositRefundToken == token) {
                  context
                      .plugin()
                      .getLogger()
                      .log(Level.WARNING, "Treasury refund retry task failed", failure);
                }
              });
    } catch (RuntimeException schedulingFailure) {
      pending.set(false);
      context
          .plugin()
          .getLogger()
          .log(Level.WARNING, "Could not schedule treasury refund retry", schedulingFailure);
    }
  }

  private void stopPlayerDepositRefundTask() {
    playerDepositRefundToken = null;
    if (playerDepositRefundTask != null) {
      playerDepositRefundTask.cancel();
      playerDepositRefundTask = null;
    }
  }

  private void logPlayerDepositRecovery(Level level, String message, RuntimeException failure) {
    java.util.logging.Logger logger = getCurrentLogger();
    if (failure == null) {
      logger.log(level, message);
    } else {
      logger.log(level, message, failure);
    }
  }

  public boolean withdrawToPlayer(UUID playerId, NationId nationId, BigDecimal amount) {
    if (currentContext == null
        || playerId == null
        || nationId == null
        || amount == null
        || amount.signum() <= 0
        || !withdraw(nationId, amount)) return false;
    if (currentContext.economyService().deposit(playerId, amount)) return true;
    deposit(nationId, amount);
    return false;
  }

  @Override
  public void deposit(NationId nationId, BigDecimal amount) {
    if (!tryDeposit(nationId, amount)) {
      throw new IllegalStateException(
          "Treasury deposit was rejected or could not be persisted for nation " + nationId);
    }
  }

  @Override
  public synchronized boolean tryDeposit(NationId nationId, BigDecimal amount) {
    if (nationId == null) {
      return false;
    }
    requirePositive(amount);
    return credit(
            new CreditRequest(
                "treasury:deposit:" + UUID.randomUUID(),
                nationId,
                amount,
                CreditCategory.OTHER,
                "Treasury service deposit"),
            "deposit")
        .applied();
  }

  @Override
  public synchronized boolean withdraw(NationId nationId, BigDecimal amount) {
    if (nationId == null) {
      return false;
    }
    requirePositive(amount);
    return spend(
            new SpendRequest(
                "treasury:withdraw:" + UUID.randomUUID(),
                nationId,
                amount,
                SpendingCategory.OTHER,
                "Treasury service withdrawal"),
            "withdraw")
        .applied();
  }

  @Override
  public synchronized SpendResult spend(SpendRequest request) {
    return spend(request, "spend");
  }

  private SpendResult spend(SpendRequest request, String operation) {
    if (request == null) {
      throw new IllegalArgumentException("request must not be null");
    }
    requireStateAvailable();
    SpendingReceipt existing;
    try {
      existing = findSpending(request.transactionId());
    } catch (TreasuryStateConflictException conflict) {
      var persisted = spendingReceipt(request.transactionId()).orElse(null);
      return new SpendResult(
          persisted != null && persisted.matches(request)
              ? SpendingStatus.ALREADY_APPLIED
              : SpendingStatus.REJECTED,
          request.transactionId(),
          balance(request.nationId()));
    }
    if (existing != null) {
      SpendingStatus status =
          existing.matches(request) ? SpendingStatus.ALREADY_APPLIED : SpendingStatus.REJECTED;
      return new SpendResult(status, request.transactionId(), balance(request.nationId()));
    }

    BigDecimal normalized = normalize(request.amount());
    BigDecimal previous = balances.getOrDefault(request.nationId(), BigDecimal.ZERO);
    if (previous.compareTo(normalized) < 0) {
      return new SpendResult(
          SpendingStatus.INSUFFICIENT_FUNDS, request.transactionId(), normalize(previous));
    }

    SpendingReceipt receipt =
        new SpendingReceipt(
            request.transactionId(),
            request.nationId(),
            normalized,
            request.category(),
            request.description(),
            Instant.now());
    BigDecimal next = previous.subtract(normalized);
    balances.put(request.nationId(), next);
    spendingReceipts.put(request.transactionId(), receipt);
    try {
      saveStateSyncOrThrow();
      return new SpendResult(SpendingStatus.APPLIED, request.transactionId(), normalize(next));
    } catch (RuntimeException persistenceFailure) {
      spendingReceipts.remove(request.transactionId(), receipt);
      restoreBalance(request.nationId(), previous);
      reconcileFailure(
          operation, request.nationId(), normalized, request.transactionId(), persistenceFailure);
      SpendingReceipt persisted = spendingReceipt(request.transactionId()).orElse(null);
      return new SpendResult(
          persisted != null && persisted.matches(request)
              ? SpendingStatus.ALREADY_APPLIED
              : SpendingStatus.REJECTED,
          request.transactionId(),
          balance(request.nationId()));
    }
  }

  @Override
  public synchronized Optional<SpendingReceipt> spendingReceipt(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      return Optional.empty();
    }
    requireStateAvailable();
    return queryReceipt(() -> findSpending(transactionId));
  }

  @Override
  public synchronized boolean refund(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      return false;
    }
    requireStateAvailable();
    SpendingReceipt existing;
    try {
      existing = findSpending(transactionId);
    } catch (TreasuryStateConflictException conflict) {
      return spendingReceipt(transactionId).map(SpendingReceipt::refunded).orElse(false);
    }
    if (existing == null) {
      return false;
    }
    if (existing.refunded()) {
      return true;
    }

    BigDecimal previous = balances.getOrDefault(existing.nationId(), BigDecimal.ZERO);
    BigDecimal next = previous.add(normalize(existing.amount()));
    if (next.compareTo(MAX_TREASURY_BALANCE) > 0) {
      return false;
    }

    SpendingReceipt refunded =
        new SpendingReceipt(
            existing.transactionId(),
            existing.nationId(),
            existing.amount(),
            existing.category(),
            existing.description(),
            existing.appliedAt(),
            true);
    balances.put(existing.nationId(), next);
    spendingReceipts.put(transactionId, refunded);
    try {
      saveStateSyncOrThrow();
      return true;
    } catch (RuntimeException persistenceFailure) {
      spendingReceipts.put(transactionId, existing);
      restoreBalance(existing.nationId(), previous);
      reconcileFailure(
          "spending-refund",
          existing.nationId(),
          existing.amount(),
          transactionId,
          persistenceFailure);
      SpendingReceipt persisted = spendingReceipt(transactionId).orElse(null);
      return persisted != null
          && persisted.refunded()
          && persisted.nationId().equals(existing.nationId())
          && persisted.amount().compareTo(existing.amount()) == 0
          && persisted.category() == existing.category()
          && persisted.description().equals(existing.description())
          && persisted.appliedAt().toEpochMilli() == existing.appliedAt().toEpochMilli();
    }
  }

  @Override
  public synchronized CreditResult credit(CreditRequest request) {
    return credit(request, "credit");
  }

  private CreditResult credit(CreditRequest request, String operation) {
    if (request == null) {
      throw new IllegalArgumentException("request must not be null");
    }
    requireStateAvailable();
    CreditReceipt existing;
    try {
      existing = findCredit(request.transactionId());
    } catch (TreasuryStateConflictException conflict) {
      var persisted = creditReceipt(request.transactionId()).orElse(null);
      return new CreditResult(
          persisted != null && persisted.matches(request)
              ? CreditStatus.ALREADY_APPLIED
              : CreditStatus.REJECTED,
          request.transactionId(),
          balance(request.nationId()));
    }
    if (existing != null) {
      CreditStatus status =
          existing.matches(request) ? CreditStatus.ALREADY_APPLIED : CreditStatus.REJECTED;
      return new CreditResult(status, request.transactionId(), balance(request.nationId()));
    }
    if (request.category() == NationCreditService.CreditCategory.TERRITORY_RENT
        && consumeSmokeRentCreditFailure()) {
      return new CreditResult(
          CreditStatus.REJECTED, request.transactionId(), balance(request.nationId()));
    }

    BigDecimal normalized = normalize(request.amount());
    BigDecimal previous = balances.getOrDefault(request.nationId(), BigDecimal.ZERO);
    BigDecimal next = previous.add(normalized);
    if (next.compareTo(MAX_TREASURY_BALANCE) > 0) {
      return new CreditResult(
          CreditStatus.REJECTED, request.transactionId(), balance(request.nationId()));
    }

    CreditReceipt receipt =
        new CreditReceipt(
            request.transactionId(),
            request.nationId(),
            normalized,
            request.category(),
            request.description(),
            Instant.now());
    balances.put(request.nationId(), next);
    creditReceipts.put(request.transactionId(), receipt);
    try {
      saveStateSyncOrThrow();
      return new CreditResult(CreditStatus.APPLIED, request.transactionId(), normalize(next));
    } catch (RuntimeException persistenceFailure) {
      creditReceipts.remove(request.transactionId(), receipt);
      restoreBalance(request.nationId(), previous);
      reconcileFailure(
          operation, request.nationId(), normalized, request.transactionId(), persistenceFailure);
      CreditReceipt persisted = creditReceipt(request.transactionId()).orElse(null);
      return new CreditResult(
          persisted != null && persisted.matches(request)
              ? CreditStatus.ALREADY_APPLIED
              : CreditStatus.REJECTED,
          request.transactionId(),
          balance(request.nationId()));
    }
  }

  private boolean consumeSmokeRentCreditFailure() {
    String marker = System.getProperty("starcore.smoke.rent-credit-fail-file");
    if (marker == null || marker.isBlank()) return false;
    java.nio.file.Path path = java.nio.file.Path.of(marker).toAbsolutePath().normalize();
    try {
      java.nio.file.Files.createDirectories(path.getParent());
      java.nio.file.Files.createFile(path);
      getCurrentLogger().warning("STARCORE smoke: injected one-shot rent credit rejection.");
      return true;
    } catch (java.nio.file.FileAlreadyExistsException alreadyConsumed) {
      return false;
    } catch (java.io.IOException failure) {
      getCurrentLogger()
          .warning("Unable to arm rent credit failure smoke: " + failure.getMessage());
      return false;
    }
  }

  private java.util.logging.Logger getCurrentLogger() {
    return currentContext == null
        ? java.util.logging.Logger.getLogger(TreasuryModule.class.getName())
        : currentContext.plugin().getLogger();
  }

  @Override
  public synchronized Optional<CreditReceipt> creditReceipt(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      return Optional.empty();
    }
    requireStateAvailable();
    return queryReceipt(() -> findCredit(transactionId));
  }

  /** Returns the immutable identity of the persisted treasury data domain, when established. */
  @Override
  public synchronized String authorityDomainId() {
    return stateUncertain ? null : authorityDomainId;
  }

  /**
   * Uses the canonical receipt-backed transfer path instead of withdraw-then-compensate. This keeps
   * both balances and the idempotency receipt under one persistence boundary.
   */
  @Override
  public boolean transfer(NationId from, NationId to, BigDecimal amount) {
    if (from == null || to == null || amount == null || amount.signum() <= 0 || from.equals(to)) {
      return false;
    }
    TransferResult result =
        transfer(
            new TransferRequest(
                "treasury:transfer:" + java.util.UUID.randomUUID(),
                from,
                to,
                amount,
                NationTransferService.TransferCategory.OTHER,
                "Treasury service transfer"));
    return result.applied();
  }

  @Override
  public synchronized TransferResult transfer(TransferRequest request) {
    if (request == null) {
      throw new IllegalArgumentException("request must not be null");
    }
    requireStateAvailable();
    TransferReceipt existing;
    try {
      existing = findTransfer(request.transactionId());
    } catch (TreasuryStateConflictException conflict) {
      var persisted = transferReceipt(request.transactionId()).orElse(null);
      return new TransferResult(
          persisted != null && persisted.matches(request)
              ? TransferStatus.ALREADY_APPLIED
              : TransferStatus.REJECTED,
          request.transactionId(),
          balance(request.payerId()),
          balance(request.receiverId()));
    }
    if (existing != null) {
      TransferStatus status =
          existing.matches(request) ? TransferStatus.ALREADY_APPLIED : TransferStatus.REJECTED;
      return new TransferResult(
          status,
          request.transactionId(),
          balance(request.payerId()),
          balance(request.receiverId()));
    }

    BigDecimal normalized = normalize(request.amount());
    BigDecimal payerPrevious = balances.getOrDefault(request.payerId(), BigDecimal.ZERO);
    BigDecimal receiverPrevious = balances.getOrDefault(request.receiverId(), BigDecimal.ZERO);
    if (payerPrevious.compareTo(normalized) < 0) {
      return new TransferResult(
          TransferStatus.INSUFFICIENT_FUNDS,
          request.transactionId(),
          normalize(payerPrevious),
          normalize(receiverPrevious));
    }
    BigDecimal receiverNext = receiverPrevious.add(normalized);
    if (receiverNext.compareTo(MAX_TREASURY_BALANCE) > 0) {
      return new TransferResult(
          TransferStatus.REJECTED,
          request.transactionId(),
          balance(request.payerId()),
          balance(request.receiverId()));
    }

    BigDecimal payerNext = payerPrevious.subtract(normalized);
    TransferReceipt receipt =
        new TransferReceipt(
            request.transactionId(),
            request.payerId(),
            request.receiverId(),
            normalized,
            request.category(),
            request.description(),
            Instant.now());
    balances.put(request.payerId(), payerNext);
    balances.put(request.receiverId(), receiverNext);
    transferReceipts.put(request.transactionId(), receipt);
    try {
      saveStateSyncOrThrow();
      return new TransferResult(
          TransferStatus.APPLIED,
          request.transactionId(),
          normalize(payerNext),
          normalize(receiverNext));
    } catch (RuntimeException persistenceFailure) {
      transferReceipts.remove(request.transactionId(), receipt);
      restoreBalance(request.payerId(), payerPrevious);
      restoreBalance(request.receiverId(), receiverPrevious);
      reconcileFailure(
          "transfer", request.payerId(), normalized, request.transactionId(), persistenceFailure);
      TransferReceipt persisted = transferReceipt(request.transactionId()).orElse(null);
      return new TransferResult(
          persisted != null && persisted.matches(request)
              ? TransferStatus.ALREADY_APPLIED
              : TransferStatus.REJECTED,
          request.transactionId(),
          balance(request.payerId()),
          balance(request.receiverId()));
    }
  }

  @Override
  public synchronized Optional<TransferReceipt> transferReceipt(String transactionId) {
    if (transactionId == null || transactionId.isBlank()) {
      return Optional.empty();
    }
    requireStateAvailable();
    return queryReceipt(() -> findTransfer(transactionId));
  }

  private SpendingReceipt findSpending(String id) {
    var live = spendingReceipts.get(id);
    return live != null ? live : readArchivedReceipt(id, () -> stateStorage.archivedSpending(id));
  }

  private CreditReceipt findCredit(String id) {
    var live = creditReceipts.get(id);
    return live != null ? live : readArchivedReceipt(id, () -> stateStorage.archivedCredit(id));
  }

  private TransferReceipt findTransfer(String id) {
    var live = transferReceipts.get(id);
    return live != null ? live : readArchivedReceipt(id, () -> stateStorage.archivedTransfer(id));
  }

  private <T> T readArchivedReceipt(String id, java.util.function.Supplier<Optional<T>> query) {
    if (stateStorage == null) return null;
    try {
      return query.get().orElse(null);
    } catch (TreasuryStateConflictException conflict) {
      reconcileFailure("receipt", null, BigDecimal.ZERO, id, conflict);
      throw conflict;
    } catch (RuntimeException failure) {
      stateUncertain = true;
      throw new TreasuryTransactionUncertainException(id, failure);
    }
  }

  private <T> Optional<T> queryReceipt(java.util.function.Supplier<T> query) {
    try {
      return Optional.ofNullable(query.get());
    } catch (TreasuryStateConflictException conflict) {
      return Optional.ofNullable(query.get());
    }
  }

  @Override
  public synchronized String summary() {
    requireStateAvailable();
    BigDecimal total =
        balances.values().stream()
            .reduce(BigDecimal.ZERO, BigDecimal::add)
            .setScale(SCALE, RoundingMode.DOWN);
    return balances.size() + " nation treasury account(s), total balance " + total.toPlainString();
  }

  @Override
  public TreasuryRewardResult reward(
      NationId nationId, BigDecimal amount, String actor, String reason) {
    if (nationId == null) {
      throw new IllegalArgumentException("nationId must not be null");
    }
    requirePositive(amount);
    // audit B-052: 之前先 deposit(amount) 再 recordRewardEvent，若 deposit 成功但事件记录失败，
    // 国库有钱无来源，无法审计。改为先记录事件（先 capture 入账前余额作 balance 字段，
    // 记录入账后的金额由 deposit 后再回填），再 deposit。
    // 这里用更简洁的顺序：先记录"待入账"事件 + 进入 deposit；事件失败不影响 deposit 但记录失败日志。
    // 真正事务化需要 DB 事务支持；最小修复：deposit 改为同步保存后用 try/catch 包住事件记录失败不撤销入账。
    BigDecimal balanceBefore = balance(nationId);
    // audit B-052: 先尝试记录事件（用预估的入账后金额作为 balance 字段），再实际 deposit。
    // 这样即使 deposit 之后服务器崩溃也已经留痕；若 deposit 失败则事件早记一条"幽灵入账"，
    // 接受这种边界，因为 deposit 抛异常的概率远低于事件记录失败的概率。
    BigDecimal normalized = normalize(amount);
    BigDecimal projectedBalance = balanceBefore.add(normalized);
    boolean eventRecorded;
    try {
      eventRecorded = recordRewardEvent(nationId, amount, projectedBalance, actor, reason);
    } catch (RuntimeException e) {
      if (currentContext != null) {
        currentContext
            .plugin()
            .getLogger()
            .warning(
                "[Treasury] reward recordRewardEvent failed before deposit: " + e.getMessage());
      }
      eventRecorded = false;
    }
    deposit(nationId, amount);
    BigDecimal balanceAfter = balance(nationId);
    return new TreasuryRewardResult(nationId, normalized, balanceAfter, eventRecorded);
  }

  private boolean recordRewardEvent(
      NationId nationId, BigDecimal amount, BigDecimal balance, String actor, String reason) {
    EventService eventService =
        currentContext == null
            ? null
            : currentContext.serviceRegistry().find(EventService.class).orElse(null);
    if (eventService == null) {
      return false;
    }
    String displayActor = actor == null || actor.isBlank() ? "STARCORE" : actor.trim();
    String displayReason =
        reason == null || reason.isBlank() ? rewardFallbackReason() : reason.trim();
    eventService.record(
        nationId,
        "treasury.reward",
        rewardMessage(displayActor, amount, displayReason),
        rewardContext(displayActor, amount, balance, reason));
    return true;
  }

  private String rewardMessage(String actor, BigDecimal amount, String reason) {
    MessageService messages =
        currentContext == null
            ? null
            : currentContext.serviceRegistry().find(MessageService.class).orElse(null);
    if (messages == null) {
      return actor
          + " rewarded nation treasury "
          + normalize(amount).toPlainString()
          + ", reason: "
          + reason;
    }
    return messages.format(
        "command.event.message.treasury-reward", actor, normalize(amount).toPlainString(), reason);
  }

  private String rewardFallbackReason() {
    MessageService messages =
        currentContext == null
            ? null
            : currentContext.serviceRegistry().find(MessageService.class).orElse(null);
    return messages == null ? "unspecified" : messages.format("command.event.reason-unspecified");
  }

  private String rewardContext(String actor, BigDecimal amount, BigDecimal balance, String reason) {
    StringBuilder builder =
        new StringBuilder()
            .append("actor=")
            .append(sanitizeContextValue(actor))
            .append(";amount=")
            .append(normalize(amount).toPlainString())
            .append(";balance=")
            .append(balance.toPlainString());
    if (reason != null && !reason.isBlank()) {
      builder.append(";reason=").append(sanitizeContextValue(reason));
    }
    return builder.toString();
  }

  private String sanitizeContextValue(String value) {
    if (value == null) return "";
    StringBuilder sb = new StringBuilder(value.length());
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      switch (c) {
        case ';' -> sb.append(',');
        case '\n', '\r' -> sb.append(' ');
        default -> sb.append(c);
      }
    }
    return sb.toString().trim();
  }

  /** Save and propagate errors so the caller can reconcile the complete canonical state. */
  private void saveStateSyncOrThrow() {
    requireStateAvailable();
    if (stateStorage != null) {
      stateGeneration.incrementAndGet();
      stateStorage.save(stateStorage.writeState(snapshotState()));
      if (stateStorage.archivesReceipts()) {
        spendingReceipts.clear();
        creditReceipts.clear();
        transferReceipts.clear();
      }
    }
  }

  private void scheduleStateRefresh() {
    StarCoreContext context = currentContext;
    if (context == null || stateStorage == null) {
      return;
    }
    if (stateRefreshTask != null) {
      cancelStateRefresh();
      if (stateRefreshTask != null) {
        return;
      }
    }
    Object token = new Object();
    stateRefreshToken = token;
    stateRefreshTask =
        context
            .scheduler()
            .runGlobalRepeatingTask(
                () -> {
                  if (currentContext == context && stateRefreshToken == token) refreshStateAsync();
                },
                STATE_REFRESH_INTERVAL_TICKS,
                STATE_REFRESH_INTERVAL_TICKS);
  }

  private void cancelStateRefresh() {
    stateRefreshToken = null;
    StarCoreScheduler.GlobalRepeatingTask task = stateRefreshTask;
    if (task == null) {
      return;
    }
    try {
      task.cancel();
      stateRefreshTask = null;
    } catch (RuntimeException failure) {
      if (currentContext != null && currentContext.plugin() != null) {
        currentContext
            .plugin()
            .getLogger()
            .log(Level.WARNING, "code=TREASURY_STATE_REFRESH_CANCEL_FAILED", failure);
      }
    }
  }

  private void refreshStateAsync() {
    StarCoreContext activeContext = currentContext;
    TreasuryStateStorage activeStorage = stateStorage;
    Object activeToken = stateRefreshToken;
    if (stateUncertain
        || !stateRefreshEnabled
        || activeToken == null
        || activeContext == null
        || activeStorage == null
        || !stateRefreshInProgress.compareAndSet(false, true)) {
      return;
    }
    long observedGeneration = stateGeneration.get();
    java.util.concurrent.CompletableFuture<Optional<TreasuryStateRefresh>> pendingRefresh;
    try {
      pendingRefresh = activeContext.scheduler().runIoAsync(activeStorage::refreshIfChanged);
    } catch (RuntimeException schedulingFailure) {
      stateRefreshInProgress.set(false);
      activeContext
          .plugin()
          .getLogger()
          .log(Level.WARNING, "Could not schedule treasury state refresh", schedulingFailure);
      return;
    }
    pendingRefresh.whenComplete(
        (refresh, failure) -> {
          if (failure != null) {
            if (stateRefreshFailureLogged.compareAndSet(false, true)) {
              activeContext
                  .plugin()
                  .getLogger()
                  .warning(
                      "[TREASURY_STATE_REFRESH_FAILED] Shared treasury state refresh will"
                          + " retry: "
                          + failure.getMessage());
            }
            stateRefreshInProgress.set(false);
            return;
          }
          stateRefreshFailureLogged.set(false);
          if (refresh.isEmpty()
              || !stateRefreshEnabled
              || currentContext != activeContext
              || stateRefreshToken != activeToken) {
            stateRefreshInProgress.set(false);
            return;
          }
          TreasuryStateRefresh changed = refresh.get();
          TreasuryStateCodec.TreasuryState snapshot;
          try {
            snapshot = readPersistedState(changed.properties());
          } catch (RuntimeException invalidSnapshot) {
            activeContext
                .plugin()
                .getLogger()
                .log(
                    Level.SEVERE,
                    "Rejected invalid refreshed treasury state; keeping the last known"
                        + " snapshot",
                    invalidSnapshot);
            stateRefreshInProgress.set(false);
            return;
          }
          try {
            boolean scheduled =
                activeContext
                    .scheduler()
                    .runGlobalIfAvailable(
                        () -> {
                          try {
                            if (stateRefreshEnabled
                                && currentContext == activeContext
                                && stateRefreshToken == activeToken) {
                              applyRefreshedState(observedGeneration, changed, snapshot);
                            }
                          } finally {
                            stateRefreshInProgress.set(false);
                          }
                        });
            if (!scheduled) stateRefreshInProgress.set(false);
          } catch (RuntimeException schedulingFailure) {
            stateRefreshInProgress.set(false);
            if (stateRefreshEnabled) {
              activeContext
                  .plugin()
                  .getLogger()
                  .warning(
                      "Could not apply refreshed treasury state: "
                          + schedulingFailure.getMessage());
            }
          }
        });
  }

  synchronized boolean refreshStateIfChanged() {
    if (stateUncertain || stateStorage == null) {
      return false;
    }
    long observedGeneration = stateGeneration.get();
    Optional<TreasuryStateRefresh> refresh = stateStorage.refreshIfChanged();
    if (refresh.isEmpty()) {
      return false;
    }
    TreasuryStateRefresh changed = refresh.get();
    TreasuryStateCodec.TreasuryState snapshot = readPersistedState(changed.properties());
    return applyRefreshedState(observedGeneration, changed, snapshot);
  }

  private synchronized boolean applyRefreshedState(
      long observedGeneration,
      TreasuryStateRefresh refresh,
      TreasuryStateCodec.TreasuryState snapshot) {
    if (stateUncertain || stateGeneration.get() != observedGeneration) {
      return false;
    }
    if (authorityDomainId != null && !authorityDomainId.equals(snapshot.authorityDomainId())) {
      return false;
    }
    if (!stateStorage.acceptRefresh(refresh)) {
      return false;
    }
    applyStateSnapshot(snapshot);
    stateGeneration.incrementAndGet();
    return true;
  }

  private void applyStateSnapshot(TreasuryStateCodec.TreasuryState state) {
    if (authorityDomainId != null && !authorityDomainId.equals(state.authorityDomainId())) {
      throw new IllegalStateException("Treasury authority domain changed during state load");
    }
    if (state.authorityDomainId() != null) {
      authorityDomainId = state.authorityDomainId();
    }
    balances.clear();
    balances.putAll(state.balances());
    spendingReceipts.clear();
    spendingReceipts.putAll(state.spendingReceipts());
    creditReceipts.clear();
    creditReceipts.putAll(state.creditReceipts());
    transferReceipts.clear();
    transferReceipts.putAll(state.transferReceipts());
  }

  private void restoreBalance(NationId nationId, BigDecimal previous) {
    if (previous.signum() == 0) {
      balances.remove(nationId);
    } else {
      balances.put(nationId, previous);
    }
  }

  private void logPersistenceFailure(
      String operation, NationId nationId, BigDecimal amount, RuntimeException failure) {
    if (currentContext != null) {
      currentContext
          .plugin()
          .getLogger()
          .log(
              Level.SEVERE,
              "[Treasury] code="
                  + persistenceFailureCode(operation)
                  + " operation="
                  + operation
                  + " reconciled="
                  + !stateUncertain
                  + " nation="
                  + nationId
                  + " amount="
                  + amount.toPlainString()
                  + " txId="
                  + txSeq.incrementAndGet(),
              failure);
    }
  }

  private void reconcileFailure(
      String operation,
      NationId nationId,
      BigDecimal amount,
      String transactionId,
      RuntimeException failure) {
    try {
      if (stateStorage == null) throw new IllegalStateException("Treasury storage unavailable");
      applyStateSnapshot(readPersistedState(stateStorage.load()));
      stateGeneration.incrementAndGet();
    } catch (RuntimeException reloadFailure) {
      stateUncertain = true;
      if (reloadFailure != failure) {
        failure.addSuppressed(reloadFailure);
      }
    }
    logPersistenceFailure(operation, nationId, amount, failure);
    if (stateUncertain) throw new TreasuryTransactionUncertainException(transactionId, failure);
  }

  private void requireStateAvailable() {
    if (stateUncertain)
      throw new IllegalStateException("Treasury is quarantined pending canonical state recovery");
  }

  private static String persistenceFailureCode(String operation) {
    return switch (operation) {
      case "deposit" -> "TREASURY_DEPOSIT_PERSISTENCE_FAILURE";
      case "withdraw" -> "TREASURY_WITHDRAW_PERSISTENCE_FAILURE";
      case "spend" -> "TREASURY_SPEND_PERSISTENCE_FAILURE";
      case "credit" -> "TREASURY_CREDIT_PERSISTENCE_FAILURE";
      case "transfer" -> "TREASURY_TRANSFER_PERSISTENCE_FAILURE";
      default -> "TREASURY_PERSISTENCE_FAILURE";
    };
  }

  private synchronized void flushState() {
    if (stateUncertain || stateStorage == null) {
      return;
    }
    try {
      saveStateSyncOrThrow();
    } catch (RuntimeException failure) {
      reconcileFailure("flush", null, BigDecimal.ZERO, "treasury:flush", failure);
    }
  }

  private TreasuryStateCodec.TreasuryState snapshotState() {
    return new TreasuryStateCodec.TreasuryState(
        authorityDomainId, balances, spendingReceipts, creditReceipts, transferReceipts);
  }

  private TreasuryStateCodec.TreasuryState readPersistedState(java.util.Properties state) {
    return stateStorage == null
        ? TreasuryStateValidation.read(state)
        : stateStorage.readState(state);
  }

  private synchronized void loadState() {
    try {
      java.util.Properties rawState =
          stateStorage == null ? new java.util.Properties() : stateStorage.load();
      TreasuryStateCodec.TreasuryState state = readPersistedState(rawState);
      applyStateSnapshot(state);
      if (authorityDomainId == null && stateIsEmpty(state) && stateStorage != null) {
        if (rawState.containsKey("authorityDomainId")) {
          throw new IllegalStateException("Invalid treasury authority domain marker");
        }
        authorityDomainId = java.util.UUID.randomUUID().toString();
        saveStateSyncOrThrow();
      }
      stateGeneration.incrementAndGet();
      stateUncertain = false;
    } catch (RuntimeException failure) {
      stateUncertain = true;
      throw failure;
    }
  }

  private static boolean stateIsEmpty(TreasuryStateCodec.TreasuryState state) {
    return state.balances().isEmpty()
        && state.spendingReceipts().isEmpty()
        && state.creditReceipts().isEmpty()
        && state.transferReceipts().isEmpty();
  }

  private void startDailyIncomeTask(StarCoreContext context) {
    stopDailyIncomeTask();
    if (!context.configuration().nationDailyIncomeAutoEnabled()) {
      return;
    }
    Duration interval = context.configuration().nationDailyIncomeAutoInterval();
    long intervalTicks = Math.max(20L, Math.min(172_800L, interval.toSeconds() * 20L));
    Object token = new Object();
    dailyIncomeToken = token;
    this.dailyIncomeTask =
        context
            .scheduler()
            .runGlobalRepeatingTask(
                () -> {
                  if (currentContext == context && dailyIncomeToken == token) {
                    settleDailyIncomeAutomatically(context);
                  }
                },
                intervalTicks,
                intervalTicks);
    context
        .plugin()
        .getLogger()
        .info(
            "STARCORE nation daily income auto settlement enabled, intervalTicks=" + intervalTicks);
  }

  private void stopDailyIncomeTask() {
    dailyIncomeToken = null;
    if (dailyIncomeTask != null) {
      dailyIncomeTask.cancel();
      dailyIncomeTask = null;
    }
  }

  private void startTaxTask(StarCoreContext context) {
    stopTaxTask();
    if (!context.configuration().nationTaxEnabled()
        || !context.configuration().nationTaxAutoEnabled()) {
      return;
    }
    Duration interval = context.configuration().nationTaxAutoInterval();
    long intervalTicks = Math.max(20L, Math.min(172_800L, interval.toSeconds() * 20L));
    Object token = new Object();
    taxToken = token;
    this.taxTask =
        context
            .scheduler()
            .runGlobalRepeatingTask(
                () -> {
                  if (currentContext == context && taxToken == token) {
                    settleTaxesAutomatically(context);
                  }
                },
                intervalTicks,
                intervalTicks);
    context
        .plugin()
        .getLogger()
        .info("STARCORE nation player tax auto settlement enabled, intervalTicks=" + intervalTicks);
  }

  private void stopTaxTask() {
    taxToken = null;
    if (taxTask != null) {
      taxTask.cancel();
      taxTask = null;
    }
  }

  private void settleDailyIncomeAutomatically(StarCoreContext context) {
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    EventService eventService = context.serviceRegistry().find(EventService.class).orElse(null);
    if (nationService == null || eventService == null) {
      context
          .plugin()
          .getLogger()
          .warning(
              "STARCORE daily income auto settlement skipped because nation/event service is"
                  + " unavailable.");
      return;
    }
    BigDecimal total = BigDecimal.ZERO;
    int settled = 0;
    for (Nation nation : nationService.nations()) {
      try {
        BigDecimal amount = dailyIncomeAmount(context, nation, nationService);
        if (amount.signum() <= 0) {
          continue;
        }
        deposit(nation.id(), amount);
        BigDecimal balance = balance(nation.id());
        int members = nation.members().size();
        int claims = Math.max(0, nationService.claimCount(nation.id()));
        eventService.record(
            nation.id(),
            "treasury.income",
            incomeMessage(context, amount, members, claims),
            incomeContext(amount, balance, members, claims));
        total = total.add(amount);
        settled++;
      } catch (RuntimeException exception) {
        context
            .plugin()
            .getLogger()
            .log(
                Level.WARNING,
                "Failed to settle STARCORE daily income for nation " + nation.name(),
                exception);
      }
    }
    if (settled > 0) {
      context
          .plugin()
          .getLogger()
          .info(
              "STARCORE auto-settled daily income for "
                  + settled
                  + " nation(s), total "
                  + total.setScale(SCALE, RoundingMode.DOWN).toPlainString());
    }
  }

  private BigDecimal dailyIncomeAmount(
      StarCoreContext context, Nation nation, NationService nationService) {
    BigDecimal base = context.configuration().nationDailyIncomeBaseAmount();
    BigDecimal memberIncome =
        context
            .configuration()
            .nationDailyIncomePerMember()
            .multiply(BigDecimal.valueOf(nation.members().size()));
    BigDecimal claimIncome =
        context
            .configuration()
            .nationDailyIncomePerClaim()
            .multiply(BigDecimal.valueOf(Math.max(0, nationService.claimCount(nation.id()))));
    BigDecimal income = base.add(memberIncome).add(claimIncome).setScale(SCALE, RoundingMode.DOWN);
    // 应用国策加成（交易收入加成）
    return applyPolicyBonus(nation.id(), income);
  }

  /**
   * 应用国策加成到收入
   *
   * @param nationId 国家ID
   * @param baseIncome 基础收入
   * @return 应用加成后的收入
   */
  private BigDecimal applyPolicyBonus(NationId nationId, BigDecimal baseIncome) {
    PolicyService service = resolvePolicyService();
    if (service == null) {
      return baseIncome;
    }
    // 获取交易收入加成
    double modifier =
        service.activePolicyModifier(nationId, "trade_income_bonus", PolicyEffectScope.GLOBAL);
    if (modifier == 0) {
      return baseIncome;
    }
    BigDecimal multiplier = BigDecimal.ONE.add(BigDecimal.valueOf(modifier));
    return baseIncome.multiply(multiplier).setScale(SCALE, RoundingMode.DOWN);
  }

  private PolicyService resolvePolicyService() {
    if (policyService == null && currentContext != null) {
      policyService = currentContext.serviceRegistry().find(PolicyService.class).orElse(null);
    }
    return policyService;
  }

  private String incomeMessage(
      StarCoreContext context, BigDecimal amount, int members, int claims) {
    MessageService messages = context.serviceRegistry().find(MessageService.class).orElse(null);
    if (messages == null) {
      return "STARCORE auto settled nation daily income " + amount.toPlainString();
    }
    return messages.format(
        "command.event.message.treasury-income",
        "STARCORE",
        amount.toPlainString(),
        members,
        claims,
        messages.format("command.event.reason-auto"));
  }

  private String incomeContext(BigDecimal amount, BigDecimal balance, int members, int claims) {
    return "actor=STARCORE;amount="
        + amount.toPlainString()
        + ";balance="
        + balance.toPlainString()
        + ";members="
        + members
        + ";claims="
        + claims
        + ";reason=auto";
  }

  private void settleTaxesAutomatically(StarCoreContext context) {
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    InternalEconomyService economyService = context.economyService();
    if (nationService == null || economyService == null) {
      context
          .plugin()
          .getLogger()
          .warning(
              "STARCORE player tax auto settlement skipped because nation/economy service is"
                  + " unavailable.");
      return;
    }
    EventService eventService = context.serviceRegistry().find(EventService.class).orElse(null);
    BigDecimal total = BigDecimal.ZERO;
    int settled = 0;
    int taxedMembers = 0;
    int skippedMembers = 0;
    int protectedNations = 0;
    Duration protectionDuration =
        Duration.ofDays(
            Math.max(
                0L,
                context
                    .plugin()
                    .getConfig()
                    .getLong("playability.new-nation-protection-days", 7L)));
    for (Nation nation : nationService.nations()) {
      if (NationProtection.isProtected(nation, protectionDuration)) {
        protectedNations++;
        continue;
      }
      try {
        TaxSettlement settlement =
            settleTaxForNation(context, nation, economyService, eventService);
        if (settlement.amount().signum() <= 0) {
          continue;
        }
        total = total.add(settlement.amount());
        taxedMembers += settlement.taxedMembers();
        skippedMembers += settlement.skippedMembers();
        settled++;
      } catch (RuntimeException exception) {
        context
            .plugin()
            .getLogger()
            .log(
                Level.WARNING,
                "Failed to settle STARCORE player tax for nation " + nation.name(),
                exception);
      }
    }
    if (settled > 0 || protectedNations > 0) {
      context
          .plugin()
          .getLogger()
          .info(
              "STARCORE auto-settled player tax for "
                  + settled
                  + " nation(s), protectedNations="
                  + protectedNations
                  + ", taxedMembers="
                  + taxedMembers
                  + ", skippedMembers="
                  + skippedMembers
                  + ", total="
                  + total.setScale(SCALE, RoundingMode.DOWN).toPlainString());
    }
  }

  private TaxSettlement settleTaxForNation(
      StarCoreContext context,
      Nation nation,
      InternalEconomyService economyService,
      EventService eventService) {
    BigDecimal total = BigDecimal.ZERO;
    int taxedMembers = 0;
    int skippedMembers = 0;
    for (var member : nation.members()) {
      BigDecimal memberTax = taxAmountFor(context, economyService.balance(member.playerId()));
      if (memberTax.signum() <= 0) {
        skippedMembers++;
        continue;
      }
      if (!economyService.withdraw(member.playerId(), memberTax)) {
        skippedMembers++;
        continue;
      }
      total = total.add(memberTax);
      taxedMembers++;
    }
    total = total.setScale(SCALE, RoundingMode.DOWN);
    BigDecimal balance = balance(nation.id());
    if (total.signum() <= 0) {
      return new TaxSettlement(total, taxedMembers, skippedMembers, balance);
    }
    deposit(nation.id(), total);
    balance = balance(nation.id());
    if (eventService != null) {
      eventService.record(
          nation.id(),
          "treasury.tax",
          taxMessage(context, total, taxedMembers, skippedMembers),
          taxContext(context, total, balance, taxedMembers, skippedMembers));
    }
    return new TaxSettlement(total, taxedMembers, skippedMembers, balance);
  }

  private BigDecimal taxAmountFor(StarCoreContext context, BigDecimal balance) {
    BigDecimal safeBalance = balance == null ? BigDecimal.ZERO : normalize(balance);
    BigDecimal protectedBalance = context.configuration().nationTaxMinimumBalance();
    BigDecimal taxableBalance =
        safeBalance
            .subtract(protectedBalance)
            .max(BigDecimal.ZERO)
            .setScale(SCALE, RoundingMode.DOWN);
    if (taxableBalance.signum() <= 0) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    BigDecimal percentageTax =
        taxableBalance
            .multiply(context.configuration().nationTaxBalancePercent())
            .divide(new BigDecimal("100.00"), SCALE, RoundingMode.DOWN);
    BigDecimal requested =
        context
            .configuration()
            .nationTaxFixedAmount()
            .add(percentageTax)
            .setScale(SCALE, RoundingMode.DOWN);
    if (requested.signum() <= 0) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    if (requested.compareTo(taxableBalance) <= 0) {
      return requested;
    }
    return context.configuration().nationTaxSkipInsufficientMembers()
        ? BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN)
        : taxableBalance;
  }

  private String taxMessage(
      StarCoreContext context, BigDecimal amount, int taxedMembers, int skippedMembers) {
    MessageService messages = context.serviceRegistry().find(MessageService.class).orElse(null);
    if (messages == null) {
      return "STARCORE auto settled player tax " + amount.toPlainString();
    }
    return messages.format(
        "command.event.message.treasury-tax",
        "STARCORE",
        amount.toPlainString(),
        taxedMembers,
        skippedMembers,
        messages.format("command.event.reason-auto"));
  }

  private String taxContext(
      StarCoreContext context,
      BigDecimal amount,
      BigDecimal balance,
      int taxedMembers,
      int skippedMembers) {
    return "actor=STARCORE;amount="
        + amount.toPlainString()
        + ";balance="
        + balance.toPlainString()
        + ";taxedMembers="
        + taxedMembers
        + ";skippedMembers="
        + skippedMembers
        + ";fixed="
        + context.configuration().nationTaxFixedAmount().toPlainString()
        + ";percent="
        + context.configuration().nationTaxBalancePercent().toPlainString()
        + ";minimumBalance="
        + context.configuration().nationTaxMinimumBalance().toPlainString()
        + ";reason=auto";
  }

  private record TaxSettlement(
      BigDecimal amount, int taxedMembers, int skippedMembers, BigDecimal balance) {}

  // ==================== 税收操作 ====================

  @Override
  public Map<TaxType, TaxationService.TaxConfig> getTaxConfigs(NationId nationId) {
    if (nationId == null) {
      return new EnumMap<>(TaxType.class);
    }
    TaxationService service = resolveTaxationService();
    if (service == null) {
      return new EnumMap<>(TaxType.class);
    }
    return service.getTaxConfigs(nationId);
  }

  @Override
  public TaxationService.TaxConfig getTaxConfig(NationId nationId, TaxType type) {
    if (nationId == null) {
      return null;
    }
    TaxationService service = resolveTaxationService();
    if (service == null) {
      return null;
    }
    return service.getTaxConfig(nationId, type);
  }

  @Override
  public void setTaxConfig(NationId nationId, TaxType type, TaxationService.TaxConfig config) {
    requireNationId(nationId);
    TaxationService service = resolveTaxationService();
    if (service != null) {
      service.setTaxConfig(nationId, type, config);
    }
  }

  @Override
  public BigDecimal collectTax(NationId nationId, TaxType type, TaxContext context) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    TaxationService service = resolveTaxationService();
    if (service == null) {
      return BigDecimal.ZERO;
    }
    return service.collectTax(nationId, type, context);
  }

  @Override
  public Map<TaxType, BigDecimal> collectAllTaxes(NationId nationId, TaxContext context) {
    if (nationId == null) {
      return new EnumMap<>(TaxType.class);
    }
    TaxationService service = resolveTaxationService();
    if (service == null) {
      return new EnumMap<>(TaxType.class);
    }
    return service.collectAllTaxes(nationId, context);
  }

  @Override
  public List<TaxationService.TaxRevenue> getTaxHistory(
      NationId nationId, TaxType type, int limit) {
    if (nationId == null) {
      return List.of();
    }
    TaxationService service = resolveTaxationService();
    if (service == null) {
      return List.of();
    }
    return service.getTaxHistory(nationId, type, limit);
  }

  private TaxationService resolveTaxationService() {
    if (taxationService == null && currentContext != null) {
      taxationService = currentContext.serviceRegistry().find(TaxationService.class).orElse(null);
    }
    return taxationService;
  }

  private void requireNationId(NationId nationId) {
    if (nationId == null) {
      throw new IllegalArgumentException("nationId must not be null");
    }
  }

  private void logUnavailable(String message) {
    if (currentContext != null) {
      currentContext.plugin().getLogger().warning(message);
    }
  }

  private void refreshFinancialServices() {
    if (currentContext == null) {
      return;
    }
    var services = currentContext.serviceRegistry();
    if (loanService == null) {
      loanService = services.find(LoanService.class).orElse(null);
    }
    if (bankruptcyService == null) {
      bankruptcyService = services.find(BankruptcyService.class).orElse(null);
    }
    if (budgetService == null) {
      budgetService = services.find(BudgetService.class).orElse(null);
    }
  }

  // ==================== 贷款/国债操作 ====================

  @Override
  public NationDebt applyForLoan(
      NationId nationId,
      NationId creditorId,
      BigDecimal principal,
      BigDecimal annualInterestRate,
      int totalInstallments) {
    requireNationId(nationId);
    refreshFinancialServices();
    // 贷款服务通过 BankruptcyServiceImpl 内部引用获取
    BankruptcyServiceImpl bankruptcyServiceImpl = getBankruptcyServiceImpl();
    LoanService effectiveLoanService = this.loanService;

    // 如果外部 loanService 不可用，尝试从破产服务获取
    if (effectiveLoanService == null && bankruptcyServiceImpl != null) {
      effectiveLoanService = bankruptcyServiceImpl.getLoanService();
    }

    if (effectiveLoanService == null) {
      throw new IllegalStateException("Loan service not available");
    }
    return effectiveLoanService.applyForLoan(
        nationId, creditorId, principal, annualInterestRate, totalInstallments);
  }

  private BankruptcyServiceImpl getBankruptcyServiceImpl() {
    if (currentContext == null) {
      return null;
    }
    var registry = currentContext.serviceRegistry();
    // 通过模块管理器查找 BankruptcyServiceImpl
    return registry.find(BankruptcyServiceImpl.class).orElse(null);
  }

  @Override
  public boolean repayDebt(UUID debtId, BigDecimal amount) {
    refreshFinancialServices();
    if (loanService == null) {
      return false;
    }
    return loanService.repayDebt(debtId, amount);
  }

  @Override
  public boolean payInstallment(UUID debtId) {
    refreshFinancialServices();
    if (loanService == null) {
      return false;
    }
    return loanService.payInstallment(debtId);
  }

  @Override
  public boolean forgiveDebt(UUID debtId) {
    refreshFinancialServices();
    if (loanService == null) {
      return false;
    }
    return loanService.forgiveDebt(debtId);
  }

  @Override
  public Optional<NationDebt> getDebt(UUID debtId) {
    refreshFinancialServices();
    if (loanService == null) {
      return Optional.empty();
    }
    return loanService.getDebt(debtId);
  }

  @Override
  public List<NationDebt> getDebtsByNation(NationId nationId) {
    if (nationId == null) {
      return List.of();
    }
    refreshFinancialServices();
    if (loanService == null) {
      return List.of();
    }
    return loanService.getDebtsByNation(nationId);
  }

  @Override
  public List<NationDebt> getActiveDebts(NationId nationId) {
    if (nationId == null) {
      return List.of();
    }
    refreshFinancialServices();
    if (loanService == null) {
      return List.of();
    }
    return loanService.getActiveDebts(nationId);
  }

  @Override
  public BigDecimal getTotalDebt(NationId nationId) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    refreshFinancialServices();
    if (loanService == null) {
      return BigDecimal.ZERO;
    }
    return loanService.getTotalDebt(nationId);
  }

  @Override
  public boolean canBorrow(NationId nationId, BigDecimal amount) {
    if (nationId == null) {
      return false;
    }
    refreshFinancialServices();
    if (loanService == null) {
      return false;
    }
    return loanService.canBorrow(nationId, amount);
  }

  @Override
  public BigDecimal getMaxBorrowableAmount(NationId nationId) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    refreshFinancialServices();
    if (loanService == null) {
      return BigDecimal.ZERO;
    }
    return loanService.getMaxBorrowableAmount(nationId);
  }

  @Override
  public int getDebtHealthScore(NationId nationId) {
    if (nationId == null) {
      return 100;
    }
    refreshFinancialServices();
    if (loanService == null) {
      return 100;
    }
    return loanService.getDebtHealthScore(nationId);
  }

  // ==================== 破产操作 ====================

  @Override
  public void enterBankruptcy(NationId nationId, String reason) {
    requireNationId(nationId);
    refreshFinancialServices();
    if (bankruptcyService == null) {
      logUnavailable(
          "Bankruptcy service not available, cannot enter bankruptcy for nation: " + nationId);
      return;
    }
    // 兼容旧调用：使用 EXCESSIVE_DEBT 作为默认值
    bankruptcyService.enterBankruptcy(
        nationId,
        dev.starcore.starcore.module.treasury.BankruptcyService.BankruptcyReason.EXCESSIVE_DEBT,
        reason);
  }

  @Override
  public void enterBankruptcy(
      NationId nationId, BankruptcyService.BankruptcyReason reason, String description) {
    requireNationId(nationId);
    refreshFinancialServices();
    if (bankruptcyService == null) {
      logUnavailable(
          "Bankruptcy service not available, cannot enter bankruptcy for nation: " + nationId);
      return;
    }
    bankruptcyService.enterBankruptcy(nationId, reason, description);
  }

  @Override
  public boolean exitBankruptcy(NationId nationId) {
    if (nationId == null) {
      return false;
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return false;
    }
    return bankruptcyService.exitBankruptcy(nationId);
  }

  @Override
  public boolean isBankrupt(NationId nationId) {
    if (nationId == null) {
      return false;
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return false;
    }
    return bankruptcyService.isBankrupt(nationId);
  }

  @Override
  public Optional<BankruptcyService.BankruptcyRecord> getBankruptcyRecord(NationId nationId) {
    if (nationId == null) {
      return Optional.empty();
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return Optional.empty();
    }
    return Optional.ofNullable(bankruptcyService.getBankruptcyRecord(nationId));
  }

  @Override
  public long getBankruptcyDays(NationId nationId) {
    if (nationId == null) {
      return 0;
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return 0;
    }
    return bankruptcyService.getBankruptcyDays(nationId);
  }

  @Override
  public boolean isRestricted(NationId nationId, BankruptcyService.Restriction restriction) {
    if (nationId == null) {
      return false;
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return false;
    }
    return bankruptcyService.isRestricted(nationId, restriction);
  }

  @Override
  public List<Restriction> getActiveRestrictions(NationId nationId) {
    if (nationId == null) {
      return List.of();
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return List.of();
    }
    return List.copyOf(bankruptcyService.getActiveRestrictions(nationId));
  }

  @Override
  public boolean earlyExitBankruptcy(NationId nationId) {
    if (nationId == null) {
      return false;
    }
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return false;
    }
    return bankruptcyService.earlyExitBankruptcy(nationId);
  }

  @Override
  public List<NationId> getAllBankruptNations() {
    refreshFinancialServices();
    if (bankruptcyService == null) {
      return List.of();
    }
    return bankruptcyService.getAllBankruptNations();
  }

  // ==================== 预算操作 ====================

  @Override
  public BudgetBill createBudgetDraft(NationId nationId, int year, int month) {
    requireNationId(nationId);
    refreshFinancialServices();
    BudgetService effectiveBudgetService = this.budgetService;
    // 如果外部 budgetService 不可用，尝试创建简化实现
    if (effectiveBudgetService == null) {
      throw new IllegalStateException("Budget service not available, cannot create budget draft");
    }
    return effectiveBudgetService.createBudgetDraft(nationId, year, month);
  }

  @Override
  public void addBudgetEntry(
      UUID billId, BudgetCategory category, String description, BigDecimal amount) {
    refreshFinancialServices();
    if (budgetService != null) {
      budgetService.addBudgetEntry(billId, category, description, amount);
    }
  }

  @Override
  public BudgetBill submitBudget(UUID billId) {
    refreshFinancialServices();
    if (budgetService == null) {
      throw new IllegalStateException("Budget service not available, cannot submit budget");
    }
    return budgetService.submitBudget(billId);
  }

  @Override
  public boolean executeBudget(UUID billId) {
    refreshFinancialServices();
    if (budgetService == null) {
      return false;
    }
    return budgetService.executeBudget(billId);
  }

  @Override
  public boolean cancelBudget(UUID billId) {
    refreshFinancialServices();
    if (budgetService == null) {
      return false;
    }
    return budgetService.cancelBudget(billId);
  }

  @Override
  public Optional<BudgetBill> getCurrentBudget(NationId nationId) {
    if (nationId == null) {
      return Optional.empty();
    }
    refreshFinancialServices();
    if (budgetService == null) {
      return Optional.empty();
    }
    return budgetService.getCurrentBudget(nationId);
  }

  @Override
  public List<BudgetBill> getBudgetHistory(NationId nationId, int limit) {
    if (nationId == null) {
      return List.of();
    }
    refreshFinancialServices();
    if (budgetService == null) {
      return List.of();
    }
    return budgetService.getBudgetHistory(nationId, limit);
  }

  @Override
  public BudgetService.BudgetExecutionReport getBudgetExecutionReport(UUID billId) {
    refreshFinancialServices();
    if (budgetService == null) {
      return null;
    }
    return budgetService.getBudgetExecutionReport(billId);
  }

  @Override
  public BigDecimal getMonthlySpending(NationId nationId, int year, int month) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    refreshFinancialServices();
    if (budgetService == null) {
      return BigDecimal.ZERO;
    }
    return budgetService.getMonthlySpending(nationId, year, month);
  }

  @Override
  public BigDecimal getYearlySpending(NationId nationId, int year) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    refreshFinancialServices();
    if (budgetService == null) {
      return BigDecimal.ZERO;
    }
    return budgetService.getYearlySpending(nationId, year);
  }

  // ==================== 综合状态查询 ====================

  @Override
  public FinanceHealthReport getFinanceHealthReport(NationId nationId) {
    requireNationId(nationId);
    refreshFinancialServices();
    BigDecimal currentBalance = balance(nationId);
    BigDecimal totalDebt = getTotalDebt(nationId);
    int debtHealth = getDebtHealthScore(nationId);
    boolean bankrupt = isBankrupt(nationId);
    List<Restriction> restrictions = getActiveRestrictions(nationId);

    // 获取启用的税种
    Map<TaxType, TaxationService.TaxConfig> taxConfigs = getTaxConfigs(nationId);
    List<TaxType> enabledTaxes =
        taxConfigs.entrySet().stream()
            .filter(e -> e.getValue() != null && e.getValue().enabled())
            .map(Map.Entry::getKey)
            .toList();

    // 计算月度收支
    YearMonth now = YearMonth.now();
    BigDecimal monthlyIncome =
        dailyIncomeAmount(currentContext, nationId, now.getYear(), now.getMonthValue());
    BigDecimal monthlyExpense = getMonthlySpending(nationId, now.getYear(), now.getMonthValue());

    // 获取贷款配置中的最大债务限制
    BigDecimal maxDebtLimit =
        loanService != null
            ? loanService.getLoanConfig().maxDebtLimit()
            : new BigDecimal("100000.00");

    return new FinanceHealthReport(
        nationId,
        currentBalance,
        totalDebt,
        maxDebtLimit,
        debtHealth,
        bankrupt,
        restrictions,
        enabledTaxes,
        monthlyIncome,
        monthlyExpense,
        Instant.now());
  }

  private BigDecimal dailyIncomeAmount(
      StarCoreContext context, NationId nationId, int year, int month) {
    if (context == null) {
      return BigDecimal.ZERO;
    }
    NationService nationService = context.serviceRegistry().find(NationService.class).orElse(null);
    if (nationService == null) {
      return BigDecimal.ZERO;
    }
    var nationOpt = nationService.nationById(nationId);
    if (nationOpt.isEmpty()) {
      return BigDecimal.ZERO;
    }
    Nation nation = nationOpt.get();
    BigDecimal base = context.configuration().nationDailyIncomeBaseAmount();
    BigDecimal memberIncome =
        context
            .configuration()
            .nationDailyIncomePerMember()
            .multiply(BigDecimal.valueOf(nation.members().size()));
    BigDecimal claimIncome =
        context
            .configuration()
            .nationDailyIncomePerClaim()
            .multiply(BigDecimal.valueOf(Math.max(0, nationService.claimCount(nationId))));
    return applyPolicyBonus(
        nationId, base.add(memberIncome).add(claimIncome).setScale(SCALE, RoundingMode.DOWN));
  }

  @Override
  public BigDecimal getTodayIncome(NationId nationId) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    if (eventService == null) {
      return BigDecimal.ZERO;
    }
    return calculateTodayAmount(nationId, true);
  }

  @Override
  public BigDecimal getTodayExpense(NationId nationId) {
    if (nationId == null) {
      return BigDecimal.ZERO.setScale(SCALE, RoundingMode.DOWN);
    }
    if (eventService == null) {
      return BigDecimal.ZERO;
    }
    return calculateTodayAmount(nationId, false);
  }

  /**
   * 从事件日志计算今日收支
   *
   * @param nationId 国家ID
   * @param isIncome true=计算收入, false=计算支出
   * @return 今日收支总额
   */
  private BigDecimal calculateTodayAmount(NationId nationId, boolean isIncome) {
    if (eventService == null) {
      return BigDecimal.ZERO;
    }
    LocalDate today = LocalDate.now();
    ZoneId zoneId = ZoneId.systemDefault();

    // 收入事件类型: treasury.income, treasury.tax, treasury.reward
    // 支出事件类型: treasury.expense, treasury.loan_repayment
    List<String> targetTypes =
        isIncome
            ? List.of("treasury.income", "treasury.tax", "treasury.reward")
            : List.of("treasury.expense", "treasury.loan_repayment");

    BigDecimal total = BigDecimal.ZERO;
    for (NationEventRecord record : eventService.eventsOf(nationId)) {
      Instant occurredAt = record.occurredAt();
      LocalDate recordDate = occurredAt.atZone(zoneId).toLocalDate();

      // 只统计今天的事件
      if (!recordDate.equals(today)) {
        continue;
      }

      String type = record.type();
      if (targetTypes.contains(type)) {
        BigDecimal amount = parseAmountFromContext(record.context());
        total = total.add(amount);
      }
    }
    return total.setScale(SCALE, RoundingMode.DOWN);
  }

  /** 从事件上下文字符串中解析金额 上下文格式: actor=...;amount=123.45;balance=... */
  private BigDecimal parseAmountFromContext(String context) {
    if (context == null || context.isBlank()) {
      return BigDecimal.ZERO;
    }
    try {
      Matcher matcher = AMOUNT_PATTERN.matcher(context);
      if (matcher.find()) {
        return new BigDecimal(matcher.group(1)).setScale(SCALE, RoundingMode.DOWN);
      }
    } catch (NumberFormatException ignored) {
    }
    return BigDecimal.ZERO;
  }

  private static BigDecimal normalize(BigDecimal amount) {
    return amount.setScale(SCALE, RoundingMode.DOWN);
  }

  private static void requirePositive(BigDecimal amount) {
    if (amount == null || amount.signum() <= 0 || amount.compareTo(MIN_TREASURY_AMOUNT) < 0) {
      throw new IllegalArgumentException("amount must be at least 0.01");
    }
  }

  // ==================== 经济趋势分析 Getter ====================

  /** 获取经济趋势分析服务 */
  public EconomyTrendService getEconomyTrendService() {
    return economyTrendService;
  }

  /** 获取经济趋势分析 GUI */
  public EconomyTrendGui getEconomyTrendGui() {
    return economyTrendGui;
  }
}
