package dev.starcore.starcore.module.treasury;

import java.util.Optional;
import java.util.Properties;

interface TreasuryStateStorage {
  Properties load();

  void save(Properties properties);

  default TreasuryStateCodec.TreasuryState readState(Properties properties) {
    return TreasuryStateValidation.read(properties);
  }

  default Properties writeState(TreasuryStateCodec.TreasuryState state) {
    return TreasuryStateCodec.toProperties(state);
  }

  default boolean archivesReceipts() {
    return false;
  }

  default Optional<NationSpendingService.SpendingReceipt> archivedSpending(String id) {
    return Optional.empty();
  }

  default Optional<NationCreditService.CreditReceipt> archivedCredit(String id) {
    return Optional.empty();
  }

  default Optional<NationTransferService.TransferReceipt> archivedTransfer(String id) {
    return Optional.empty();
  }

  /** Reads a newer SQL snapshot without changing the revision used by subsequent writes. */
  default Optional<TreasuryStateRefresh> refreshIfChanged() {
    return Optional.empty();
  }

  /** Adopts a refreshed revision only after its owner safely applies the snapshot. */
  default boolean acceptRefresh(TreasuryStateRefresh refresh) {
    return true;
  }

  default void saveAsync(Properties properties) {
    save(properties);
  }
}
