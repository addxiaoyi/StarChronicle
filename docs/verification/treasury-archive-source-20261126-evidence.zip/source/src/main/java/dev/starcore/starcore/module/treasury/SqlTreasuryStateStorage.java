package dev.starcore.starcore.module.treasury;

import dev.starcore.starcore.core.database.DatabaseService;
import dev.starcore.starcore.core.persistence.PersistenceService;
import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.Optional;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;
import javax.sql.DataSource;

final class SqlTreasuryStateStorage extends AbstractModuleStateStorage
    implements TreasuryStateStorage {

  private static final String FILE_NAME = "treasury.properties";
  private static final String TABLE_NAME = "starcore_treasury_state";
  private static final String REVISION_KEY = "__starcore_revision__";
  private long expectedRevision;
  private boolean revisionRowExists;
  private boolean archiveEnabled;
  private SqlTreasuryReceiptArchive.Head archiveHead = SqlTreasuryReceiptArchive.Head.EMPTY;
  private String archiveDomain;

  @Override
  public synchronized boolean archivesReceipts() {
    return archiveEnabled;
  }

  @Override
  public TreasuryStateCodec.TreasuryState readState(Properties properties) {
    return TreasuryStateValidation.readArchived(properties);
  }

  @Override
  public synchronized Properties writeState(TreasuryStateCodec.TreasuryState state) {
    var properties = TreasuryStateCodec.toProperties(state);
    if (state.authorityDomainId() != null)
      SqlTreasuryReceiptArchive.writeHead(properties, archiveHead);
    return properties;
  }

  @Override
  public Optional<NationSpendingService.SpendingReceipt> archivedSpending(String id) {
    return archivedReceipt(SqlTreasuryReceiptArchive.SPENDING, id)
        .map(value -> (NationSpendingService.SpendingReceipt) value.receipt());
  }

  @Override
  public Optional<NationCreditService.CreditReceipt> archivedCredit(String id) {
    return archivedReceipt(SqlTreasuryReceiptArchive.CREDIT, id)
        .map(value -> (NationCreditService.CreditReceipt) value.receipt());
  }

  @Override
  public Optional<NationTransferService.TransferReceipt> archivedTransfer(String id) {
    return archivedReceipt(SqlTreasuryReceiptArchive.TRANSFER, id)
        .map(value -> (NationTransferService.TransferReceipt) value.receipt());
  }

  private synchronized Optional<SqlTreasuryReceiptArchive.Entry> archivedReceipt(
      String kind, String id) {
    if (!archiveEnabled) return Optional.empty();
    try (var connection = openConnection()) {
      beginRead(connection);
      try {
        var snapshot = readDatabaseSnapshot(connection, true);
        if (snapshot.revision() != expectedRevision)
          throw new TreasuryStateConflictException(
              new IllegalStateException("Treasury archive revision changed"));
        var head = SqlTreasuryReceiptArchive.Head.from(snapshot.properties());
        if (!SqlTreasuryReceiptArchive.enabled(snapshot.properties())
            || !head.equals(archiveHead)
            || !java.util.Objects.equals(
                archiveDomain, snapshot.properties().getProperty("authorityDomainId")))
          throw new IllegalStateException("Treasury archive metadata changed");
        SqlTreasuryReceiptArchive.validateHead(connection, head);
        var receipt = SqlTreasuryReceiptArchive.find(connection, kind, id, head, archiveDomain);
        connection.rollback();
        return receipt;
      } catch (Exception error) {
        connection.rollback();
        throw error;
      }
    } catch (TreasuryStateConflictException error) {
      throw error;
    } catch (Exception error) {
      throw new IllegalStateException("Treasury receipt archive unavailable", error);
    }
  }

  SqlTreasuryStateStorage(
      String namespace,
      DatabaseService databaseService,
      PersistenceService persistenceService,
      Logger logger) {
    super(namespace, databaseService, persistenceService, logger);
  }

  // Test constructor.
  SqlTreasuryStateStorage(DataSource dataSource, Properties legacyProperties, Logger logger) {
    this("test", mockDatabaseService(dataSource), mockPersistenceService(legacyProperties), logger);
  }

  private static DatabaseService mockDatabaseService(DataSource dataSource) {
    return new DatabaseService(null, null) {
      @Override
      public synchronized Optional<DataSource> dataSource() {
        return Optional.of(dataSource);
      }

      @Override
      public synchronized boolean isRunning() {
        return true;
      }
    };
  }

  private static PersistenceService mockPersistenceService(Properties properties) {
    return new PersistenceService(null, null) {
      @Override
      public Properties loadProperties(String namespace, String fileName) {
        return properties;
      }

      @Override
      public void saveProperties(String namespace, String fileName, Properties properties) {
        // Test environment: do not persist a fallback file.
      }

      @Override
      public CompletableFuture<Void> savePropertiesAsync(
          String namespace, String fileName, Properties properties) {
        return CompletableFuture.completedFuture(null);
      }
    };
  }

  @Override
  protected String getTableName() {
    return TABLE_NAME;
  }

  @Override
  protected String getFileName() {
    return FILE_NAME;
  }

  @Override
  public synchronized Properties load() {
    try (Connection connection = openConnection()) {
      ensureTable(connection);
      Properties properties = loadFromDatabase(connection);
      if (!properties.isEmpty() || revisionRowExists) {
        return properties;
      }

      // Only import the legacy file before the SQL snapshot has ever been initialized.
      Properties legacy = copy(loadFromProperties());
      if (legacy.isEmpty()) {
        return legacy;
      }

      TreasuryStateValidation.read(legacy);
      writeSnapshot(connection, legacy);
      logger.info("[" + namespace + "] 已从 Properties 迁移数据到 SQL");
      return legacy;
    } catch (Exception exception) {
      return handleSqlLoadFailure(exception);
    }
  }

  @Override
  protected Properties handleSqlLoadFailure(Exception exception) {
    throw new IllegalStateException("Treasury SQL state load failed", exception);
  }

  @Override
  protected void handleSqlWriteFailure(Properties properties, Exception exception) {
    if (exception instanceof TreasuryStateReconciliationException reconciliationException) {
      throw reconciliationException;
    }
    if (exception instanceof SQLException sqlException && isConcurrentWriteConflict(sqlException)) {
      throw new TreasuryStateConflictException(exception);
    }
    throw new IllegalStateException("Treasury SQL state write failed", exception);
  }

  @Override
  protected void ensureTable(Connection connection) throws SQLException {
    SqlTreasuryReceiptArchive.ensure(connection);
    try (Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE IF NOT EXISTS starcore_treasury_state ("
              + "property_key VARCHAR(191) PRIMARY KEY, "
              + "property_value TEXT NOT NULL)");
    }
  }

  @Override
  protected Properties loadFromDatabase(Connection connection) throws SQLException {
    DatabaseSnapshot snapshot = readConsistentSnapshot(connection);
    expectedRevision = snapshot.revision();
    revisionRowExists = snapshot.revisionRowExists();
    archiveEnabled = SqlTreasuryReceiptArchive.enabled(snapshot.properties());
    archiveHead = SqlTreasuryReceiptArchive.Head.from(snapshot.properties());
    archiveDomain = snapshot.properties().getProperty("authorityDomainId");
    return snapshot.properties();
  }

  private static void beginRead(Connection connection) throws SQLException {
    connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
    connection.setAutoCommit(false);
  }

  private DatabaseSnapshot readConsistentSnapshot(Connection connection) throws SQLException {
    beginRead(connection);
    try {
      var snapshot = readDatabaseSnapshot(connection);
      SqlTreasuryReceiptArchive.validateAll(connection, snapshot.properties());
      connection.rollback();
      return snapshot;
    } catch (Exception error) {
      connection.rollback();
      throw error;
    } finally {
      connection.setAutoCommit(true);
    }
  }

  private DatabaseSnapshot readDatabaseSnapshot(Connection connection) throws SQLException {
    return readDatabaseSnapshot(connection, false);
  }

  private DatabaseSnapshot readDatabaseSnapshot(Connection connection, boolean metadataOnly)
      throws SQLException {
    Properties properties = new Properties();
    long revision = 0L;
    boolean hasRevisionRow = false;
    try (PreparedStatement statement =
            connection.prepareStatement(
                "SELECT property_key, property_value FROM "
                    + TABLE_NAME
                    + (metadataOnly
                        ? " WHERE property_key IN"
                              + " ('__starcore_revision__','authorityDomainId','receipt-archive.version','receipt-archive.count','receipt-archive.head')"
                        : "")
                    + " ORDER BY property_key");
        ResultSet rows = statement.executeQuery()) {
      while (rows.next()) {
        String key = rows.getString("property_key");
        String value = rows.getString("property_value");
        if (REVISION_KEY.equals(key)) {
          revision = parseRevision(value);
          hasRevisionRow = true;
        } else {
          properties.setProperty(key, value);
        }
      }
    }
    return new DatabaseSnapshot(properties, revision, hasRevisionRow);
  }

  @Override
  public synchronized Optional<TreasuryStateRefresh> refreshIfChanged() {
    try (Connection connection = openConnection()) {
      if (readRevision(connection) == expectedRevision) {
        return Optional.empty();
      }
      DatabaseSnapshot snapshot = readConsistentSnapshot(connection);
      if (snapshot.revision() == expectedRevision) {
        return Optional.empty();
      }
      return Optional.of(new TreasuryStateRefresh(snapshot.properties(), snapshot.revision()));
    } catch (Exception exception) {
      throw new IllegalStateException("Treasury SQL state refresh failed", exception);
    }
  }

  @Override
  public synchronized boolean acceptRefresh(TreasuryStateRefresh refresh) {
    if (refresh.revision() >= 0L) {
      expectedRevision = refresh.revision();
      revisionRowExists = true;
      archiveEnabled = SqlTreasuryReceiptArchive.enabled(refresh.properties());
      archiveHead = SqlTreasuryReceiptArchive.Head.from(refresh.properties());
      archiveDomain = refresh.properties().getProperty("authorityDomainId");
    }
    return true;
  }

  @Override
  protected synchronized void writeSnapshot(Connection connection, Properties properties)
      throws SQLException {
    boolean previousAutoCommit = connection.getAutoCommit();
    boolean commitAttempted = false;
    boolean committed = false;
    connection.setAutoCommit(false);
    try {
      properties = copy(properties);
      long currentRevision = readRevision(connection);
      if (currentRevision != expectedRevision) {
        throw new SQLException(
            "Stale treasury state snapshot: expected revision "
                + expectedRevision
                + " but database is at "
                + currentRevision);
      }
      long nextRevision = Math.addExact(currentRevision, 1L);
      if (revisionExists(connection)) {
        try (PreparedStatement update =
            connection.prepareStatement(
                "UPDATE "
                    + TABLE_NAME
                    + " SET property_value = ? WHERE property_key = ? AND property_value = ?")) {
          update.setString(1, Long.toString(nextRevision));
          update.setString(2, REVISION_KEY);
          update.setString(3, Long.toString(currentRevision));
          if (update.executeUpdate() != 1) {
            throw new SQLException("Treasury state revision changed during save");
          }
        }
      } else {
        try (PreparedStatement insertRevision =
            connection.prepareStatement(
                "INSERT INTO " + TABLE_NAME + " (property_key, property_value) VALUES (?, ?)")) {
          insertRevision.setString(1, REVISION_KEY);
          insertRevision.setString(2, Long.toString(nextRevision));
          try {
            insertRevision.executeUpdate();
          } catch (SQLException exception) {
            if (isDuplicateKeyViolation(exception)) {
              throw new SQLException(
                  "Treasury state revision changed during save",
                  "40001",
                  exception.getErrorCode(),
                  exception);
            }
            throw exception;
          }
        }
      }
      var stored = readDatabaseSnapshot(connection).properties();
      SqlTreasuryReceiptArchive.prepare(connection, properties, stored);
      try (PreparedStatement delete =
          connection.prepareStatement("DELETE FROM " + TABLE_NAME + " WHERE property_key <> ?")) {
        delete.setString(1, REVISION_KEY);
        delete.executeUpdate();
      }
      try (PreparedStatement insert =
          connection.prepareStatement(
              "INSERT INTO " + TABLE_NAME + " (property_key, property_value) VALUES (?, ?)")) {
        for (String key : properties.stringPropertyNames()) {
          if (REVISION_KEY.equals(key)) {
            continue;
          }
          insert.setString(1, key);
          insert.setString(2, properties.getProperty(key));
          insert.addBatch();
        }
        insert.executeBatch();
      }
      commitAttempted = true;
      connection.commit();
      committed = true;
      expectedRevision = nextRevision;
      revisionRowExists = true;
      archiveEnabled = SqlTreasuryReceiptArchive.enabled(properties);
      archiveHead = SqlTreasuryReceiptArchive.Head.from(properties);
      archiveDomain = properties.getProperty("authorityDomainId");
    } catch (Exception exception) {
      try {
        connection.rollback();
      } catch (SQLException rollbackFailure) {
        exception.addSuppressed(rollbackFailure);
      }
      if (commitAttempted) {
        throw new TreasuryStateReconciliationException(exception);
      }
      throw exception;
    } finally {
      try {
        connection.setAutoCommit(previousAutoCommit);
      } catch (SQLException resetFailure) {
        if (committed) {
          throw new TreasuryStateReconciliationException(resetFailure);
        }
        throw resetFailure;
      }
    }
  }

  static boolean isConcurrentWriteConflict(SQLException exception) {
    for (SQLException current = exception; current != null; current = current.getNextException()) {
      String message = current.getMessage();
      if (message != null
          && (message.startsWith("Stale treasury state snapshot")
              || message.equals("Treasury state revision changed during save"))) {
        return true;
      }

      String sqlState = current.getSQLState();
      if (sqlState != null && (sqlState.startsWith("40") || sqlState.equals("41000"))) {
        return true;
      }

      int errorCode = current.getErrorCode();
      int sqlitePrimaryCode = errorCode & 0xff;
      if (sqlitePrimaryCode == 5
          || sqlitePrimaryCode == 6
          || errorCode == 1205
          || errorCode == 1213) {
        return true;
      }

      if (message != null) {
        String normalized = message.toLowerCase(Locale.ROOT);
        if (normalized.contains("database is locked")
            || normalized.contains("database table is locked")
            || normalized.contains("deadlock")
            || normalized.contains("lock wait timeout")
            || normalized.contains("serialization failure")) {
          return true;
        }
      }
    }
    return false;
  }

  private boolean revisionExists(Connection connection) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement("SELECT 1 FROM " + TABLE_NAME + " WHERE property_key = ?")) {
      query.setString(1, REVISION_KEY);
      try (ResultSet result = query.executeQuery()) {
        return result.next();
      }
    }
  }

  private long readRevision(Connection connection) throws SQLException {
    try (PreparedStatement query =
        connection.prepareStatement(
            "SELECT property_value FROM " + TABLE_NAME + " WHERE property_key = ?")) {
      query.setString(1, REVISION_KEY);
      try (ResultSet result = query.executeQuery()) {
        return result.next() ? parseRevision(result.getString(1)) : 0L;
      }
    }
  }

  private static long parseRevision(String value) throws SQLException {
    try {
      long revision = Long.parseLong(value);
      if (revision < 0) {
        throw new NumberFormatException("negative revision");
      }
      return revision;
    } catch (NumberFormatException exception) {
      throw new SQLException("Invalid treasury state revision", exception);
    }
  }

  private static boolean isDuplicateKeyViolation(SQLException exception) {
    for (SQLException current = exception; current != null; current = current.getNextException()) {
      int errorCode = current.getErrorCode();
      String sqlState = current.getSQLState();
      if (errorCode == 1062 || errorCode == 2601 || errorCode == 2627 || "23505".equals(sqlState)) {
        return true;
      }
    }
    return false;
  }

  private record DatabaseSnapshot(Properties properties, long revision, boolean revisionRowExists) {
    private DatabaseSnapshot {
      properties = copy(properties);
    }

    @Override
    public Properties properties() {
      return copy(properties);
    }
  }
}
