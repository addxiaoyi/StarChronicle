package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.*;

import dev.starcore.starcore.core.storage.AbstractModuleStateStorage;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.*;
import java.time.Instant;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.h2.jdbcx.JdbcDataSource;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.sqlite.SQLiteDataSource;

class TreasuryReceiptArchiveTest {
  @TempDir Path directory;

  @AfterEach
  void close() {
    AbstractModuleStateStorage.shutdownNamespace("test");
  }

  static final String PREFIX = SqlTreasuryReceiptArchive.PREFIX;

  record Fixture(
      DataSource db, SqlTreasuryStateStorage storage, Properties original, TreasuryModule module) {}

  Fixture fixture(String engine, int count) throws Exception {
    DataSource db;
    if (engine.equals("sqlite")) {
      var source = new SQLiteDataSource();
      source.setUrl("jdbc:sqlite:" + directory.resolve("treasury.db"));
      db = source;
    } else {
      var source = new JdbcDataSource();
      source.setURL("jdbc:h2:" + directory.resolve("treasury").toString().replace('\\', '/'));
      db = source;
    }
    var original = seed(count);
    var storage = new SqlTreasuryStateStorage(db, original, Logger.getAnonymousLogger());
    return new Fixture(db, storage, original, TreasuryCommitRecoveryTest.loaded(storage));
  }

  static Properties seed(int count) {
    Map<String, NationSpendingService.SpendingReceipt> spending = new HashMap<>();
    Map<String, NationCreditService.CreditReceipt> credit = new HashMap<>();
    Map<String, NationTransferService.TransferReceipt> transfer = new HashMap<>();
    for (int i = 0; i < count; i++) {
      String id = "receipt-" + i;
      spending.put(
          id,
          new NationSpendingService.SpendingReceipt(
              id,
              TreasuryCommitRecoveryTest.PAYER,
              new BigDecimal("2.00"),
              NationSpendingService.SpendingCategory.RESEARCH,
              "支出\n=\\证据 " + i,
              Instant.EPOCH,
              i % 3 == 0));
      credit.put(
          id,
          new NationCreditService.CreditReceipt(
              id,
              TreasuryCommitRecoveryTest.PAYER,
              new BigDecimal("3.00"),
              NationCreditService.CreditCategory.OTHER,
              "收入 " + i,
              Instant.EPOCH));
      transfer.put(
          id,
          new NationTransferService.TransferReceipt(
              id,
              TreasuryCommitRecoveryTest.PAYER,
              TreasuryCommitRecoveryTest.RECEIVER,
              BigDecimal.ONE,
              NationTransferService.TransferCategory.OTHER,
              "原转账 " + i,
              Instant.EPOCH));
    }
    return TreasuryStateCodec.toProperties(
        new TreasuryStateCodec.TreasuryState(
            TreasuryCommitRecoveryTest.DOMAIN,
            Map.of(
                TreasuryCommitRecoveryTest.PAYER,
                new BigDecimal("100.00"),
                TreasuryCommitRecoveryTest.RECEIVER,
                new BigDecimal("10.00")),
            spending,
            credit,
            transfer));
  }

  static int resident(TreasuryModule module) throws Exception {
    int size = 0;
    for (String name : List.of("spendingReceipts", "creditReceipts", "transferReceipts")) {
      var field = TreasuryModule.class.getDeclaredField(name);
      field.setAccessible(true);
      size += ((Map<?, ?>) field.get(module)).size();
    }
    return size;
  }

  static long count(DataSource db) throws Exception {
    try (var c = db.getConnection();
        var s = c.createStatement();
        var r = s.executeQuery("SELECT COUNT(*) FROM " + SqlTreasuryReceiptArchive.TABLE)) {
      r.next();
      return r.getLong(1);
    }
  }

  static void sql(DataSource db, String text) throws Exception {
    try (var c = db.getConnection();
        var s = c.createStatement()) {
      s.executeUpdate(text);
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void migratesAllKindsWithoutResidentHistoryAndRetainsRefundableProof(String engine)
      throws Exception {
    var f = fixture(engine, 180);
    var original = TreasuryStateValidation.read(f.original);
    assertEquals(540, resident(f.module));
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    assertEquals(0, resident(f.module));
    assertEquals(540, count(f.db));
    var state = f.storage.load();
    assertEquals("1", state.getProperty(PREFIX + "version"));
    assertEquals("0", state.getProperty("spending.count"));
    assertEquals("0", state.getProperty("credit.count"));
    assertEquals("0", state.getProperty("transfer.count"));
    assertNull(f.original.getProperty(PREFIX + "version"));
    var restarted = TreasuryCommitRecoveryTest.loaded(f.storage);
    assertEquals(0, resident(restarted));
    for (int i = 0; i < 180; i++) {
      String id = "receipt-" + i;
      assertEquals(
          original.spendingReceipts().get(id), restarted.spendingReceipt(id).orElseThrow());
      assertEquals(original.creditReceipts().get(id), restarted.creditReceipt(id).orElseThrow());
      assertEquals(
          original.transferReceipts().get(id), restarted.transferReceipt(id).orElseThrow());
    }
    assertEquals(0, resident(restarted));
    assertTrue(restarted.refund("receipt-1"));
    assertTrue(restarted.refund("receipt-1"));
    assertEquals(new BigDecimal("102.00"), restarted.balance(TreasuryCommitRecoveryTest.PAYER));
    assertEquals(541, count(f.db));
    assertTrue(
        TreasuryCommitRecoveryTest.loaded(f.storage)
            .spendingReceipt("receipt-1")
            .orElseThrow()
            .refunded());
    assertThrows(IllegalStateException.class, () -> TreasuryStateValidation.read(state));
    assertThrows(IllegalStateException.class, () -> f.storage.save(f.original));
    assertEquals(0, resident(restarted));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void firstMigrationTriggeredByRefundPreservesOriginalAndAddsRefund(String engine)
      throws Exception {
    var f = fixture(engine, 2);
    assertTrue(f.module.refund("receipt-1"));
    assertEquals(7, count(f.db));
    assertEquals(0, resident(f.module));
    try (var c = f.db.getConnection();
        var s = c.createStatement();
        var rows =
            s.executeQuery(
                "SELECT refund_event,row_data FROM "
                    + SqlTreasuryReceiptArchive.TABLE
                    + " WHERE receipt_kind='spending' AND transaction_id='receipt-1' ORDER BY"
                    + " archive_sequence")) {
      assertTrue(rows.next());
      assertEquals(0, rows.getInt(1));
      assertFalse(
          SqlTreasuryReceiptArchive.Entry.decode("spending", "receipt-1", rows.getString(2))
              .refunded());
      assertTrue(rows.next());
      assertEquals(1, rows.getInt(1));
      assertTrue(
          SqlTreasuryReceiptArchive.Entry.decode("spending", "receipt-1", rows.getString(2))
              .refunded());
      assertFalse(rows.next());
    }
    assertTrue(TreasuryCommitRecoveryTest.loaded(f.storage).refund("receipt-1"));
    assertEquals(7, count(f.db));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void staleWriterReconcilesReceiptAndDoesNotPayOrRefundTwice(String engine) throws Exception {
    var f = fixture(engine, 2);
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    var otherStorage =
        new SqlTreasuryStateStorage(f.db, new Properties(), Logger.getAnonymousLogger());
    var other = TreasuryCommitRecoveryTest.loaded(otherStorage);
    assertTrue(f.module.transfer(TreasuryCommitRecoveryTest.transfer()).applied());
    assertEquals(
        NationTransferService.TransferStatus.ALREADY_APPLIED,
        other.transfer(TreasuryCommitRecoveryTest.transfer()).status());
    assertEquals(new BigDecimal("80.00"), other.balance(TreasuryCommitRecoveryTest.PAYER));
    assertTrue(f.module.refund("receipt-1"));
    assertTrue(other.refund("receipt-1"));
    assertEquals(new BigDecimal("82.00"), other.balance(TreasuryCommitRecoveryTest.PAYER));
    assertEquals(8, count(f.db));
    assertEquals(0, resident(other));
  }

  static Stream<Arguments> damage() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Stream.of(
                        "missing",
                        "row",
                        "hash",
                        "chain",
                        "identity",
                        "sequence",
                        "domain",
                        "head",
                        "version",
                        "refund")
                    .map(damage -> Arguments.of(engine, damage)));
  }

  @ParameterizedTest
  @MethodSource("damage")
  void corruptedHistoryCannotEstablishAuthority(String engine, String damage) throws Exception {
    var f = fixture(engine, 3);
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    switch (damage) {
      case "missing" ->
          sql(f.db, "DELETE FROM " + SqlTreasuryReceiptArchive.TABLE + " WHERE archive_sequence=2");
      case "row" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET row_data='broken' WHERE archive_sequence=2");
      case "hash" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET row_hash='broken' WHERE archive_sequence=2");
      case "chain" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET chain_hash='broken' WHERE archive_sequence=2");
      case "identity" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET transaction_id='changed' WHERE archive_sequence=2");
      case "sequence" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET archive_sequence=0 WHERE archive_sequence=2");
      case "domain" ->
          sql(
              f.db,
              "UPDATE starcore_treasury_state SET"
                  + " property_value='00000000-0000-0000-0000-000000000099' WHERE"
                  + " property_key='authorityDomainId'");
      case "head" ->
          sql(
              f.db,
              "UPDATE starcore_treasury_state SET property_value='1' WHERE"
                  + " property_key='receipt-archive.count'");
      case "version" ->
          sql(
              f.db,
              "DELETE FROM starcore_treasury_state WHERE property_key LIKE 'receipt-archive.%'");
      case "refund" ->
          sql(
              f.db,
              "UPDATE "
                  + SqlTreasuryReceiptArchive.TABLE
                  + " SET refund_event=1 WHERE archive_sequence=2");
    }
    long before = count(f.db);
    assertThrows(IllegalStateException.class, () -> TreasuryCommitRecoveryTest.loaded(f.storage));
    assertEquals(before, count(f.db));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void corruptedPointReadQuarantinesSubsequentOperations(String engine) throws Exception {
    var f = fixture(engine, 3);
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    sql(
        f.db,
        "UPDATE "
            + SqlTreasuryReceiptArchive.TABLE
            + " SET row_hash='changed' WHERE receipt_kind='credit' AND transaction_id='receipt-1'");
    assertThrows(
        TreasuryTransactionUncertainException.class, () -> f.module.creditReceipt("receipt-1"));
    assertNull(f.module.authorityDomainId());
    assertThrows(
        IllegalStateException.class,
        () -> f.module.tryDeposit(TreasuryCommitRecoveryTest.PAYER, BigDecimal.ONE));
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    assertEquals(9, count(f.db));
  }

  static Stream<Arguments> commits() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Arrays.stream(TreasuryCommitRecoveryTest.Action.values())
                    .flatMap(
                        action ->
                            Stream.of(true, false)
                                .map(before -> Arguments.of(engine, action, before))));
  }

  static Stream<Arguments> unknownCommits() {
    return Stream.of("sqlite", "h2")
        .flatMap(
            engine ->
                Arrays.stream(TreasuryCommitRecoveryTest.Action.values())
                    .map(action -> Arguments.of(engine, action)));
  }

  @ParameterizedTest
  @MethodSource("unknownCommits")
  void unreadableArchivedCommitRetainsOriginalIdAndQuarantinesUntilReload(
      String engine, TreasuryCommitRecoveryTest.Action action) throws Exception {
    var helper = new TreasuryCommitRecoveryTest();
    helper.directory = directory;
    var f = helper.fixture(engine);
    var module = TreasuryCommitRecoveryTest.loaded(f.storage());
    TreasuryCommitRecoveryTest.invoke(module, "flushState");
    f.fault().arm(false, true);
    var failure =
        assertThrows(TreasuryTransactionUncertainException.class, () -> action.apply(module));
    assertNotNull(failure.transactionId());
    assertFalse(failure.transactionId().isBlank());
    assertNull(module.authorityDomainId());
    f.fault().unreadable = false;
    var durable = f.storage().load();
    assertThrows(IllegalStateException.class, () -> module.creditReceipt("preserved-credit"));
    assertThrows(
        IllegalStateException.class, () -> module.balance(TreasuryCommitRecoveryTest.PAYER));
    assertFalse(module.refreshStateIfChanged());
    TreasuryCommitRecoveryTest.invoke(module, "flushState");
    assertEquals(durable, f.storage().load());
    var restarted = TreasuryCommitRecoveryTest.loaded(f.storage());
    action.balances(restarted, true);
    assertTrue(action.observed(restarted));
    assertEquals(0, resident(restarted));
    if (action != TreasuryCommitRecoveryTest.Action.DEPOSIT
        && action != TreasuryCommitRecoveryTest.Action.WITHDRAW) {
      assertTrue(action.apply(restarted));
      action.balances(restarted, true);
    }
  }

  @ParameterizedTest
  @MethodSource("commits")
  void archivedTransactionsReconcileBeforeAndAfterCommitFailures(
      String engine, TreasuryCommitRecoveryTest.Action action, boolean before) throws Exception {
    var helper = new TreasuryCommitRecoveryTest();
    helper.directory = directory;
    var f = helper.fixture(engine);
    var module = TreasuryCommitRecoveryTest.loaded(f.storage());
    TreasuryCommitRecoveryTest.invoke(module, "flushState");
    assertEquals(0, resident(module));
    f.fault().arm(before, false);
    assertEquals(!before, action.apply(module));
    action.balances(module, !before);
    assertEquals(!before, action.observed(module));
    assertEquals(0, resident(module));
    var restarted = TreasuryCommitRecoveryTest.loaded(f.storage());
    action.balances(restarted, !before);
    assertTrue(restarted.creditReceipt("preserved-credit").isPresent());
    assertTrue(restarted.transferReceipt("preserved-transfer").isPresent());
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void interiorMigrationFailureRollsBackArchiveBalanceAndRevision(String engine) throws Exception {
    var f = fixture(engine, 3);
    var armed = new java.util.concurrent.atomic.AtomicBoolean();
    var inserted = new java.util.concurrent.atomic.AtomicInteger();
    var source =
        (DataSource)
            java.lang.reflect.Proxy.newProxyInstance(
                getClass().getClassLoader(),
                new Class<?>[] {DataSource.class},
                (proxy, method, args) -> {
                  Object value = TreasuryCommitRecoveryTest.forward(f.db, method, args);
                  if (!(value instanceof Connection actual)) return value;
                  return java.lang.reflect.Proxy.newProxyInstance(
                      getClass().getClassLoader(),
                      new Class<?>[] {Connection.class},
                      (p, call, values) -> {
                        Object result = TreasuryCommitRecoveryTest.forward(actual, call, values);
                        if (!call.getName().equals("prepareStatement")
                            || !values[0]
                                .toString()
                                .startsWith("INSERT INTO " + SqlTreasuryReceiptArchive.TABLE))
                          return result;
                        var statement = (PreparedStatement) result;
                        return java.lang.reflect.Proxy.newProxyInstance(
                            getClass().getClassLoader(),
                            new Class<?>[] {PreparedStatement.class},
                            (q, execute, parameters) -> {
                              Object written =
                                  TreasuryCommitRecoveryTest.forward(
                                      statement, execute, parameters);
                              if (execute.getName().equals("executeUpdate")
                                  && armed.get()
                                  && inserted.incrementAndGet() == 2) {
                                armed.set(false);
                                throw new SQLException("after interior archive insert");
                              }
                              return written;
                            });
                      });
                });
    var storage =
        new SqlTreasuryStateStorage(source, new Properties(), Logger.getAnonymousLogger());
    var module = TreasuryCommitRecoveryTest.loaded(storage);
    var before = storage.load();
    armed.set(true);
    assertFalse(module.tryDeposit(TreasuryCommitRecoveryTest.PAYER, BigDecimal.ONE));
    assertEquals(before, storage.load());
    assertEquals(0, count(f.db));
    assertEquals(9, resident(module));
    assertTrue(module.tryDeposit(TreasuryCommitRecoveryTest.PAYER, BigDecimal.ONE));
    assertEquals(10, count(f.db));
    assertEquals(0, resident(module));
  }

  @ParameterizedTest
  @ValueSource(strings = {"sqlite", "h2"})
  void existingArchivedTermsCannotBeOverwrittenOrRefundReversed(String engine) throws Exception {
    var f = fixture(engine, 3);
    TreasuryCommitRecoveryTest.invoke(f.module, "flushState");
    var state = f.storage.load();
    var original = f.module.spendingReceipt("receipt-1").orElseThrow();
    assertTrue(f.module.refund("receipt-1"));
    var snapshot =
        new TreasuryStateCodec.TreasuryState(
            TreasuryCommitRecoveryTest.DOMAIN,
            Map.of(
                TreasuryCommitRecoveryTest.PAYER,
                new BigDecimal("102.00"),
                TreasuryCommitRecoveryTest.RECEIVER,
                new BigDecimal("10.00")),
            Map.of("receipt-1", original),
            Map.of(),
            Map.of());
    var current = f.storage.load();
    assertThrows(IllegalStateException.class, () -> f.storage.save(f.storage.writeState(snapshot)));
    assertEquals(current, f.storage.load());
    assertThrows(IllegalStateException.class, () -> f.storage.save(state));
    assertTrue(f.module.spendingReceipt("receipt-1").orElseThrow().refunded());
    assertEquals(10, count(f.db));
  }
}
