package dev.starcore.starcore.module.treasury;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.core.StarCoreContext;
import dev.starcore.starcore.core.config.ConfigurationService;
import dev.starcore.starcore.core.scheduler.StarCoreScheduler;
import dev.starcore.starcore.core.service.ServiceRegistry;
import dev.starcore.starcore.foundation.economy.InternalEconomyService;
import dev.starcore.starcore.foundation.economy.transaction.RefundLedger;
import dev.starcore.starcore.module.event.EventService;
import dev.starcore.starcore.module.nation.NationService;
import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

class TreasuryPeriodicThreadingTest {
  @Test
  void allFourPeriodicJobsUseGlobalTimers() throws Exception {
    Fixture fixture = new Fixture();
    fixture.installStorage();
    fixture.start("scheduleStateRefresh");
    fixture.start("startDailyIncomeTask");
    fixture.start("startTaxTask");
    fixture.start("startPlayerDepositRefundTask");

    assertEquals(4, fixture.timers.size());
    verify(fixture.scheduler).runGlobalRepeatingTask(any(), eq(100L), eq(100L));
    verify(fixture.scheduler).runGlobalRepeatingTask(any(), eq(1_200L), eq(1_200L));
    verify(fixture.scheduler, times(2)).runGlobalRepeatingTask(any(), eq(600L), eq(600L));
    verify(fixture.scheduler, never()).runSyncTimer(any(), anyLong(), anyLong());
    verify(fixture.module, never()).retryPendingPlayerDepositRefunds();
  }

  @Test
  void dailyIncomeAndTaxRejectOldTimersEvenWhenContextIsReused() throws Exception {
    Fixture fixture = new Fixture();
    fixture.start("startDailyIncomeTask");
    fixture.start("startTaxTask");
    fixture.timers.get(0).run();
    fixture.timers.get(1).run();
    verify(fixture.nations, times(2)).nations();

    fixture.start("stopDailyIncomeTask");
    fixture.start("stopTaxTask");
    fixture.start("startDailyIncomeTask");
    fixture.start("startTaxTask");
    fixture.timers.get(0).run();
    fixture.timers.get(1).run();
    verify(fixture.nations, times(2)).nations();
    fixture.timers.get(2).run();
    fixture.timers.get(3).run();
    verify(fixture.nations, times(4)).nations();
  }

  @Test
  void disableCancelsAllTimersAndDiscardsTheirQueuedCallbacks() throws Exception {
    Fixture fixture = new Fixture();
    fixture.installStorage();
    fixture.start("scheduleStateRefresh");
    fixture.start("startDailyIncomeTask");
    fixture.start("startTaxTask");
    fixture.start("startPlayerDepositRefundTask");

    fixture.module.disable(fixture.context);
    fixture.timers.forEach(Runnable::run);

    for (StarCoreScheduler.GlobalRepeatingTask task : fixture.tasks) verify(task).cancel();
    assertEquals(0, fixture.io.size());
    verify(fixture.nations, never()).nations();
    verify(fixture.module, never()).retryPendingPlayerDepositRefunds();
  }

  @Test
  void refundTimerOnlyQueuesOneIoOperationUntilCompletion() throws Exception {
    Fixture fixture = new Fixture();
    fixture.start("startPlayerDepositRefundTask");
    fixture.timers.get(0).run();
    fixture.timers.get(0).run();
    assertEquals(1, fixture.io.size());
    verify(fixture.module, never()).retryPendingPlayerDepositRefunds();

    fixture.io.get(0).get();
    fixture.pending.get(0).complete(null);
    verify(fixture.module).retryPendingPlayerDepositRefunds();
    fixture.timers.get(0).run();
    assertEquals(2, fixture.io.size());
  }

  @Test
  void oldRefundIoIsDiscardedWhenItsTaskRestarts() throws Exception {
    Fixture fixture = new Fixture();
    fixture.start("startPlayerDepositRefundTask");
    fixture.timers.get(0).run();
    fixture.start("stopPlayerDepositRefundTask");
    fixture.start("startPlayerDepositRefundTask");

    fixture.io.get(0).get();
    fixture.pending.get(0).complete(null);
    fixture.timers.get(0).run();
    fixture.timers.get(1).run();
    assertEquals(2, fixture.io.size());
    verify(fixture.module, never()).retryPendingPlayerDepositRefunds();
    fixture.io.get(1).get();
    verify(fixture.module).retryPendingPlayerDepositRefunds();
  }

  @Test
  void failedRefundIoReleasesTimerSlot() throws Exception {
    Fixture fixture = new Fixture();
    fixture.start("startPlayerDepositRefundTask");
    fixture.timers.get(0).run();
    fixture.pending.get(0).completeExceptionally(new IllegalStateException("ledger unavailable"));
    fixture.timers.get(0).run();
    assertEquals(2, fixture.io.size());
  }

  @Test
  void refreshedStateWaitsForGlobalApplyAndRejectsOldLifetime() throws Exception {
    Fixture fixture = new Fixture();
    fixture.installStorage();
    fixture.start("scheduleStateRefresh");
    fixture.timers.get(0).run();
    fixture.finishRefresh(0);
    assertEquals(1, fixture.global.size());
    assertEquals(0, fixture.module.balance(fixture.nationId).signum());

    fixture.start("cancelStateRefresh");
    fixture.start("scheduleStateRefresh");
    fixture.global.get(0).run();
    assertEquals(0, fixture.module.balance(fixture.nationId).signum());
    fixture.timers.get(0).run();
    assertEquals(1, fixture.io.size());
    fixture.timers.get(1).run();
    fixture.finishRefresh(1);
    assertEquals(2, fixture.global.size());
    fixture.global.get(1).run();
    assertEquals(0, fixture.module.balance(fixture.nationId).compareTo(new BigDecimal("50.00")));
    verify(fixture.storage, times(1)).acceptRefresh(any());
    verify(fixture.scheduler, never()).runSync(any());
  }

  @Test
  void rejectedGlobalApplyDoesNotWedgeFutureRefreshes() throws Exception {
    Fixture fixture = new Fixture();
    fixture.installStorage();
    when(fixture.scheduler.runGlobalIfAvailable(any())).thenReturn(false);
    fixture.start("scheduleStateRefresh");
    fixture.timers.get(0).run();
    fixture.finishRefresh(0);
    fixture.timers.get(0).run();
    assertEquals(2, fixture.io.size());
    assertEquals(0, fixture.module.balance(fixture.nationId).signum());
  }

  @Test
  void rejectedIoSchedulingReleasesRefundAndRefreshSlots() throws Exception {
    Fixture fixture = new Fixture();
    fixture.installStorage();
    fixture.start("startPlayerDepositRefundTask");
    fixture.start("scheduleStateRefresh");
    doAnswer(
            invocation -> {
              throw new IllegalStateException("executor unavailable");
            })
        .when(fixture.scheduler)
        .runIoAsync(any());
    fixture.timers.forEach(Runnable::run);
    fixture.bindIo();
    fixture.timers.forEach(Runnable::run);
    assertEquals(2, fixture.io.size());
  }

  private static final class Fixture {
    final TreasuryModule module = spy(new TreasuryModule());
    final StarCoreScheduler scheduler = mock(StarCoreScheduler.class);
    final ConfigurationService configuration = mock(ConfigurationService.class);
    final JavaPlugin plugin = mock(JavaPlugin.class);
    final NationService nations = mock(NationService.class);
    final TreasuryStateStorage storage = mock(TreasuryStateStorage.class);
    final NationId nationId = NationId.random();
    final ServiceRegistry services = new ServiceRegistry();
    final StarCoreContext context = mock(StarCoreContext.class);
    final List<Runnable> timers = new ArrayList<>();
    final List<StarCoreScheduler.GlobalRepeatingTask> tasks = new ArrayList<>();
    final List<Runnable> global = new ArrayList<>();
    final List<Supplier<?>> io = new ArrayList<>();
    final List<CompletableFuture<Object>> pending = new ArrayList<>();

    Fixture() throws Exception {
      services.register(NationService.class, nations);
      services.register(EventService.class, mock(EventService.class));
      when(context.scheduler()).thenReturn(scheduler);
      when(context.configuration()).thenReturn(configuration);
      when(context.plugin()).thenReturn(plugin);
      when(context.serviceRegistry()).thenReturn(services);
      when(context.economyService()).thenReturn(mock(InternalEconomyService.class));
      when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
      when(plugin.getConfig()).thenReturn(new org.bukkit.configuration.file.YamlConfiguration());
      when(configuration.nationDailyIncomeAutoEnabled()).thenReturn(true);
      when(configuration.nationDailyIncomeAutoInterval()).thenReturn(Duration.ofSeconds(30));
      when(configuration.nationTaxEnabled()).thenReturn(true);
      when(configuration.nationTaxAutoEnabled()).thenReturn(true);
      when(configuration.nationTaxAutoInterval()).thenReturn(Duration.ofSeconds(30));
      set(module, "currentContext", context);
      set(module, "refundLedger", mock(RefundLedger.class));
      doReturn(0).when(module).retryPendingPlayerDepositRefunds();
      doAnswer(
              invocation -> {
                timers.add(invocation.getArgument(0));
                var task = mock(StarCoreScheduler.GlobalRepeatingTask.class);
                tasks.add(task);
                return task;
              })
          .when(scheduler)
          .runGlobalRepeatingTask(any(), anyLong(), anyLong());
      doAnswer(
              invocation -> {
                global.add(invocation.getArgument(0));
                return true;
              })
          .when(scheduler)
          .runGlobalIfAvailable(any());
      bindIo();
    }

    void bindIo() {
      doAnswer(
              invocation -> {
                io.add(invocation.getArgument(0));
                CompletableFuture<Object> future = new CompletableFuture<>();
                pending.add(future);
                return future;
              })
          .when(scheduler)
          .runIoAsync(any());
    }

    void installStorage() throws Exception {
      set(module, "stateStorage", storage);
      set(module, "stateRefreshEnabled", true);
      when(storage.refreshIfChanged())
          .thenReturn(
              Optional.of(
                  new TreasuryStateRefresh(
                      TreasuryStateCodec.toProperties(Map.of(nationId, new BigDecimal("50.00"))),
                      1L)));
      when(storage.acceptRefresh(any())).thenReturn(true);
      when(storage.readState(any())).thenCallRealMethod();
    }

    void finishRefresh(int index) {
      pending.get(index).complete(io.get(index).get());
    }

    void start(String name) throws Exception {
      if (name.startsWith("start")) {
        invoke(module, name, new Class<?>[] {StarCoreContext.class}, context);
      } else {
        invoke(module, name, new Class<?>[0]);
      }
    }
  }

  private static void set(Object target, String name, Object value) throws Exception {
    Field field = TreasuryModule.class.getDeclaredField(name);
    field.setAccessible(true);
    field.set(target, value);
  }

  private static void invoke(Object target, String name, Class<?>[] types, Object... args)
      throws Exception {
    Method method = TreasuryModule.class.getDeclaredMethod(name, types);
    method.setAccessible(true);
    method.invoke(target, args);
  }
}
