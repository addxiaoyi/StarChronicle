package dev.starcore.starcore.module.treasury;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import dev.starcore.starcore.module.nation.model.NationId;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.sqlite.SQLiteDataSource;

class SqlTreasuryStateStorageTest {
  @TempDir Path tempDir;

  @Test
  void sqlWriteFailureIsSurfacedInsteadOfReportedAsSuccessfulFileFallback() throws Exception {
    DataSource dataSource = mock(DataSource.class);
    when(dataSource.getConnection()).thenThrow(new SQLException("database unavailable"));
    SqlTreasuryStateStorage storage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());

    try {
      assertThatThrownBy(() -> storage.save(new Properties()))
          .isInstanceOf(IllegalStateException.class)
          .hasMessage("Treasury SQL state write failed")
          .hasCauseInstanceOf(SQLException.class);
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void sqlLoadFailureDoesNotExposeStalePropertiesSnapshot() throws Exception {
    DataSource dataSource = mock(DataSource.class);
    when(dataSource.getConnection()).thenThrow(new SQLException("database unavailable"));
    Properties legacy = new Properties();
    legacy.setProperty("balance.example", "100.00");
    SqlTreasuryStateStorage storage =
        new SqlTreasuryStateStorage(dataSource, legacy, Logger.getAnonymousLogger());

    try {
      assertThatThrownBy(storage::load)
          .isInstanceOf(IllegalStateException.class)
          .hasMessage("Treasury SQL state load failed")
          .hasCauseInstanceOf(SQLException.class);
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void staleInstanceCannotOverwriteNewerTreasurySnapshot() {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury.db"));
    SqlTreasuryStateStorage first =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    SqlTreasuryStateStorage second =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());

    try {
      first.load();
      second.load();
      Properties firstSnapshot = new Properties();
      firstSnapshot.setProperty("balance.first", "100.00");
      first.save(firstSnapshot);

      Properties staleSnapshot = new Properties();
      staleSnapshot.setProperty("balance.second", "50.00");
      assertThatThrownBy(() -> second.save(staleSnapshot))
          .isInstanceOf(TreasuryStateConflictException.class)
          .hasMessageContaining("code=TREASURY_STATE_CONFLICT");

      Properties current = second.load();
      assertThat(current.getProperty("balance.first")).isEqualTo("100.00");
      assertThat(current.getProperty("balance.second")).isNull();
      current.setProperty("balance.second", "50.00");
      second.save(current);

      Properties committed = first.load();
      assertThat(committed.getProperty("balance.first")).isEqualTo("100.00");
      assertThat(committed.getProperty("balance.second")).isEqualTo("50.00");
    } finally {
      first.shutdown();
      second.shutdown();
    }
  }

  @Test
  void simultaneousInitialWritersCannotSilentlyReplaceEachOther() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-race.db"));
    SqlTreasuryStateStorage first =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    SqlTreasuryStateStorage second =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    ExecutorService executor = Executors.newFixedThreadPool(2);
    CountDownLatch ready = new CountDownLatch(2);
    CountDownLatch start = new CountDownLatch(1);

    try {
      first.load();
      second.load();
      Future<Boolean> firstWrite =
          executor.submit(() -> saveAfterBarrier(first, "first", ready, start));
      Future<Boolean> secondWrite =
          executor.submit(() -> saveAfterBarrier(second, "second", ready, start));
      ready.await();
      start.countDown();

      assertThat(firstWrite.get()).isNotEqualTo(secondWrite.get());
      Properties committed = first.load();
      assertThat(committed.stringPropertyNames()).hasSize(1);
      assertThat(
              committed.getProperty("writer.first") != null
                  || committed.getProperty("writer.second") != null)
          .isTrue();
    } finally {
      start.countDown();
      executor.shutdownNow();
      first.shutdown();
      second.shutdown();
    }
  }

  @Test
  void readsAndUpgradesExistingSnapshotWithoutRevisionRow() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-legacy-schema.db"));
    try (Connection connection = dataSource.getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE starcore_treasury_state ("
              + "property_key VARCHAR(191) PRIMARY KEY, property_value TEXT NOT NULL)");
      statement.execute(
          "INSERT INTO starcore_treasury_state (property_key, property_value) "
              + "VALUES ('balance.legacy', '75.00')");
    }
    SqlTreasuryStateStorage storage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());

    try {
      Properties loaded = storage.load();
      assertThat(loaded).containsEntry("balance.legacy", "75.00");
      loaded.setProperty("balance.new", "25.00");
      storage.save(loaded);

      assertThat(storage.load())
          .containsEntry("balance.legacy", "75.00")
          .containsEntry("balance.new", "25.00");
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void emptyInitializedSqlSnapshotDoesNotReimportStaleLegacyProperties() {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-empty-snapshot.db"));
    Properties legacy = new Properties();
    legacy.setProperty("balance.stale", "75.00");
    SqlTreasuryStateStorage storage =
        new SqlTreasuryStateStorage(dataSource, legacy, Logger.getAnonymousLogger());

    try {
      assertThat(storage.load()).containsEntry("balance.stale", "75.00");
      storage.save(new Properties());

      assertThat(storage.load()).isEmpty();
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void malformedRevisionFailsClosedWithoutUsingLegacyFileSnapshot() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-invalid-revision.db"));
    try (Connection connection = dataSource.getConnection();
        Statement statement = connection.createStatement()) {
      statement.execute(
          "CREATE TABLE starcore_treasury_state ("
              + "property_key VARCHAR(191) PRIMARY KEY, property_value TEXT NOT NULL)");
      statement.execute(
          "INSERT INTO starcore_treasury_state (property_key, property_value) "
              + "VALUES ('__starcore_revision__', 'invalid')");
    }
    Properties legacy = new Properties();
    legacy.setProperty("count", "1");
    SqlTreasuryStateStorage storage =
        new SqlTreasuryStateStorage(dataSource, legacy, Logger.getAnonymousLogger());

    try {
      assertThatThrownBy(storage::load)
          .isInstanceOf(IllegalStateException.class)
          .hasMessage("Treasury SQL state load failed");
    } finally {
      storage.shutdown();
    }
  }

  @Test
  void treasuryModuleReloadsCanonicalStateAfterConcurrentWriteConflict() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-module-conflict.db"));
    SqlTreasuryStateStorage firstStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    SqlTreasuryStateStorage secondStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    TreasuryModule first = treasuryModule(firstStorage);
    TreasuryModule second = treasuryModule(secondStorage);
    NationId firstNation = NationId.random();
    NationId secondNation = NationId.random();

    try {
      loadTreasuryState(first);
      loadTreasuryState(second);

      assertThat(first.tryDeposit(firstNation, new BigDecimal("100.00"))).isTrue();

      assertThat(second.tryDeposit(secondNation, new BigDecimal("50.00"))).isFalse();
      assertThat(second.balance(firstNation)).isEqualByComparingTo("100.00");
      assertThat(second.balance(secondNation)).isEqualByComparingTo("0.00");

      assertThat(second.tryDeposit(secondNation, new BigDecimal("50.00"))).isTrue();
      loadTreasuryState(first);
      assertThat(first.balance(firstNation)).isEqualByComparingTo("100.00");
      assertThat(first.balance(secondNation)).isEqualByComparingTo("50.00");
    } finally {
      firstStorage.shutdown();
      secondStorage.shutdown();
    }
  }

  @Test
  void transferConflictReloadsCommittedReceiptBeforeSameIdRetry() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-transfer-conflict.db"));
    SqlTreasuryStateStorage firstStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    SqlTreasuryStateStorage secondStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    TreasuryModule first = treasuryModule(firstStorage);
    TreasuryModule second = treasuryModule(secondStorage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "concurrent-transfer-1",
            payer,
            receiver,
            new BigDecimal("25.00"),
            NationTransferService.TransferCategory.OTHER,
            "conflict regression");

    try {
      loadTreasuryState(first);
      assertThat(first.tryDeposit(payer, new BigDecimal("100.00"))).isTrue();
      assertThat(first.tryDeposit(receiver, new BigDecimal("10.00"))).isTrue();
      loadTreasuryState(second);

      assertThat(first.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.APPLIED);

      NationTransferService.TransferResult staleAttempt = second.transfer(request);
      assertThat(staleAttempt.status())
          .isEqualTo(NationTransferService.TransferStatus.ALREADY_APPLIED);
      assertThat(staleAttempt.payerBalanceAfter()).isEqualByComparingTo("75.00");
      assertThat(staleAttempt.receiverBalanceAfter()).isEqualByComparingTo("35.00");

      assertThat(second.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.ALREADY_APPLIED);
      assertThat(second.balance(payer)).isEqualByComparingTo("75.00");
      assertThat(second.balance(receiver)).isEqualByComparingTo("35.00");
    } finally {
      firstStorage.shutdown();
      secondStorage.shutdown();
    }
  }

  @Test
  void transferReconcilesWhenCommitSucceedsButStorageAcknowledgementIsLost() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-lost-ack.db"));
    SqlTreasuryStateStorage sqlStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    CommitThenFailStorage uncertainStorage = new CommitThenFailStorage(sqlStorage);
    TreasuryModule module = treasuryModule(uncertainStorage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "lost-ack-transfer",
            payer,
            receiver,
            new BigDecimal("25.00"),
            NationTransferService.TransferCategory.OTHER,
            "lost acknowledgement regression");

    try {
      loadTreasuryState(module);
      assertThat(module.tryDeposit(payer, new BigDecimal("100.00"))).isTrue();
      assertThat(module.tryDeposit(receiver, new BigDecimal("10.00"))).isTrue();
      uncertainStorage.failNextAcknowledgement();

      assertThat(module.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.ALREADY_APPLIED);
      assertThat(module.balance(payer)).isEqualByComparingTo("75.00");
      assertThat(module.balance(receiver)).isEqualByComparingTo("35.00");
      assertThat(module.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.ALREADY_APPLIED);
    } finally {
      sqlStorage.shutdown();
    }
  }

  @Test
  void idleTreasuryInstanceRefreshesSharedBalancesAndTransferReceipts() throws Exception {
    SQLiteDataSource dataSource = new SQLiteDataSource();
    dataSource.setUrl("jdbc:sqlite:" + tempDir.resolve("treasury-proactive-refresh.db"));
    SqlTreasuryStateStorage firstStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    SqlTreasuryStateStorage secondStorage =
        new SqlTreasuryStateStorage(dataSource, new Properties(), Logger.getAnonymousLogger());
    TreasuryModule first = treasuryModule(firstStorage);
    TreasuryModule second = treasuryModule(secondStorage);
    NationId payer = NationId.random();
    NationId receiver = NationId.random();
    NationTransferService.TransferRequest request =
        new NationTransferService.TransferRequest(
            "shared-transfer-refresh",
            payer,
            receiver,
            new BigDecimal("25.00"),
            NationTransferService.TransferCategory.OTHER,
            "shared refresh regression");

    try {
      loadTreasuryState(first);
      loadTreasuryState(second);
      assertThat(first.tryDeposit(payer, new BigDecimal("100.00"))).isTrue();
      assertThat(first.tryDeposit(receiver, new BigDecimal("10.00"))).isTrue();

      assertThat(second.refreshStateIfChanged()).isTrue();
      assertThat(second.balance(payer)).isEqualByComparingTo("100.00");
      assertThat(second.balance(receiver)).isEqualByComparingTo("10.00");
      assertThat(second.refreshStateIfChanged()).isFalse();

      assertThat(first.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.APPLIED);
      assertThat(second.refreshStateIfChanged()).isTrue();
      assertThat(second.transfer(request).status())
          .isEqualTo(NationTransferService.TransferStatus.ALREADY_APPLIED);
      assertThat(second.balance(payer)).isEqualByComparingTo("75.00");
      assertThat(second.balance(receiver)).isEqualByComparingTo("35.00");

      assertThat(second.tryDeposit(payer, new BigDecimal("5.00"))).isTrue();
      assertThat(first.refreshStateIfChanged()).isTrue();
      assertThat(first.balance(payer)).isEqualByComparingTo("80.00");
    } finally {
      firstStorage.shutdown();
      secondStorage.shutdown();
    }
  }

  @Test
  void localMutationWinsOverRefreshSnapshotThatWasAlreadyInFlight() throws Exception {
    TreasuryStateStorage storage =
        new TreasuryStateStorage() {
          @Override
          public Properties load() {
            return new Properties();
          }

          @Override
          public void save(Properties properties) {}
        };
    TreasuryModule module = treasuryModule(storage);
    NationId localNation = NationId.random();
    NationId remoteNation = NationId.random();
    Properties remoteProperties =
        TreasuryStateCodec.toProperties(
            java.util.Map.of(
                localNation, new BigDecimal("80.00"), remoteNation, new BigDecimal("40.00")));

    loadTreasuryState(module);
    Field generationField = TreasuryModule.class.getDeclaredField("stateGeneration");
    generationField.setAccessible(true);
    long observedGeneration =
        ((java.util.concurrent.atomic.AtomicLong) generationField.get(module)).get();
    assertThat(module.tryDeposit(localNation, new BigDecimal("10.00"))).isTrue();

    TreasuryStateRefresh refresh = new TreasuryStateRefresh(remoteProperties, 1L);
    TreasuryStateCodec.TreasuryState snapshot =
        TreasuryStateCodec.stateFromProperties(refresh.properties());
    Method applyRefresh =
        TreasuryModule.class.getDeclaredMethod(
            "applyRefreshedState",
            long.class,
            TreasuryStateRefresh.class,
            TreasuryStateCodec.TreasuryState.class);
    applyRefresh.setAccessible(true);

    assertThat(applyRefresh.invoke(module, observedGeneration, refresh, snapshot)).isEqualTo(false);
    assertThat(module.balance(localNation)).isEqualByComparingTo("10.00");
    assertThat(module.balance(remoteNation)).isEqualByComparingTo("0.00");
  }

  private static TreasuryModule treasuryModule(TreasuryStateStorage storage)
      throws ReflectiveOperationException {
    TreasuryModule module = new TreasuryModule();
    Field field = TreasuryModule.class.getDeclaredField("stateStorage");
    field.setAccessible(true);
    field.set(module, storage);
    return module;
  }

  private static void loadTreasuryState(TreasuryModule module) throws ReflectiveOperationException {
    Method method = TreasuryModule.class.getDeclaredMethod("loadState");
    method.setAccessible(true);
    method.invoke(module);
  }

  private static boolean saveAfterBarrier(
      SqlTreasuryStateStorage storage, String writer, CountDownLatch ready, CountDownLatch start)
      throws InterruptedException {
    ready.countDown();
    start.await();
    Properties snapshot = new Properties();
    snapshot.setProperty("writer." + writer, "committed");
    try {
      storage.save(snapshot);
      return true;
    } catch (TreasuryStateConflictException conflict) {
      return false;
    }
  }

  private static final class CommitThenFailStorage implements TreasuryStateStorage {
    private final TreasuryStateStorage delegate;
    private final AtomicBoolean failNextAcknowledgement = new AtomicBoolean();

    private CommitThenFailStorage(TreasuryStateStorage delegate) {
      this.delegate = delegate;
    }

    @Override
    public Properties load() {
      return delegate.load();
    }

    @Override
    public TreasuryStateCodec.TreasuryState readState(Properties properties) {
      return delegate.readState(properties);
    }

    @Override
    public Properties writeState(TreasuryStateCodec.TreasuryState state) {
      return delegate.writeState(state);
    }

    @Override
    public boolean archivesReceipts() {
      return delegate.archivesReceipts();
    }

    @Override
    public java.util.Optional<NationSpendingService.SpendingReceipt> archivedSpending(String id) {
      return delegate.archivedSpending(id);
    }

    @Override
    public java.util.Optional<NationCreditService.CreditReceipt> archivedCredit(String id) {
      return delegate.archivedCredit(id);
    }

    @Override
    public java.util.Optional<NationTransferService.TransferReceipt> archivedTransfer(String id) {
      return delegate.archivedTransfer(id);
    }

    @Override
    public void save(Properties properties) {
      delegate.save(properties);
      if (failNextAcknowledgement.compareAndSet(true, false)) {
        throw new TreasuryStateReconciliationException(
            new IllegalStateException("simulated lost commit acknowledgement"));
      }
    }

    private void failNextAcknowledgement() {
      failNextAcknowledgement.set(true);
    }
  }
}
