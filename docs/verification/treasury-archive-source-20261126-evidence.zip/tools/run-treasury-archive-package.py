import json
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
assert json.loads((root/'run/treasury-archive-final-tests-20261126/manifest.json').read_text())['status']=='PASS'
script=root/'run/package-treasury-archive-20261126.cmd'
script.write_text((root/'run/package-trade-archive-20261126.cmd').read_text().replace('trade-archive-', 'treasury-archive-'),newline='\r\n')
result=subprocess.run(['cmd.exe','/d','/c',str(script)],cwd=root.parent/'StarChronicle-audit/starcore-all-stages')
(root/'run/treasury-archive-package-result-20261126.json').write_text(json.dumps({'exit_code':result.returncode})+'\n')
raise SystemExit(result.returncode)
