@echo off
set "JAVA_HOME=C:\tmp\jdk21\jdk-21.0.13.1+2"
set "MAVEN_OPTS=-Xmx256m -Xss512k -XX:+UseSerialGC -XX:ActiveProcessorCount=1 -XX:TieredStopAtLevel=1 -XX:ReservedCodeCacheSize=48m -XX:CompressedClassSpaceSize=32m -Dfile.encoding=UTF-8"
call mvnw.cmd -o -B -ntp spotless:apply -DskipTests test-compile > C:\Users\Administrator\Documents\StarChronicle\run\treasury-archive-compile-20261126.log 2>&1
exit /b %ERRORLEVEL%
