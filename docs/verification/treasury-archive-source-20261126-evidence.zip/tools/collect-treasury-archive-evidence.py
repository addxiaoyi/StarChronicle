import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root=Path(__file__).resolve().parents[1]
native=root.parent/'StarChronicle-audit/starcore-all-stages'
files={};sha=lambda raw:hashlib.sha256(raw).hexdigest()
def add(path,name):files[name]=path.read_bytes()
groups=root/'run/treasury-archive-final-tests-20261126'
assert json.loads((groups/'manifest.json').read_text())['status']=='PASS'
totals=dict(tests=0,failures=0,errors=0,skipped=0);packages={};suites={}
for group in ('finance','resource','snapshot'):
 log=groups/f'treasury-archive-{group}-test-20261126.log'
 text=log.read_text(encoding='utf-8',errors='replace')
 assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text
 add(log,'logs/'+log.name)
 for name in re.findall(r'\[INFO\] Running ([\w.$]+)',text):
  path=groups/group/('TEST-'+name+'.xml');suite=ET.fromstring(path.read_bytes())
  assert name not in suites;suites[name]=int(suite.attrib['tests'])
  package='resource' if '.resource.' in name else 'treasury' if '.treasury.' in name else 'technology'
  packages[package]=packages.get(package,0)+suites[name]
  for key in totals:totals[key]+=int(suite.attrib[key])
  add(path,'native-final/surefire/'+path.name)
assert totals==dict(tests=1558,failures=0,errors=0,skipped=0),totals
assert suites['dev.starcore.starcore.module.treasury.TreasuryReceiptArchiveTest']==68
add(groups/'manifest.json','native-final/group-manifest.json')
for label in ('compile','final-compile','proof-compile','package','sbom'):
 path=root/f'run/treasury-archive-{label}-20261126.log';text=path.read_text(encoding='utf-8',errors='replace')
 assert 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text,label
 add(path,'logs/'+path.name)
failure_counts={}
for folder in (root/'run').glob('treasury-archive-*-failure-20261126'):
 counts=dict(tests=0,failures=0,errors=0,skipped=0)
 for path in folder.rglob('*'):
  if path.is_file():
   add(path,'failures/'+folder.name+'/'+path.relative_to(folder).as_posix())
   if path.name.startswith('TEST-') and path.suffix=='.xml':
    suite=ET.fromstring(path.read_bytes())
    for key in counts:counts[key]+=int(suite.attrib[key])
 failure_counts[folder.name]=counts
contracts={}
for label,folder in (('capacity','treasury-archive-capacity-final-20261126'),('treasury','treasury-contract-archive-20261126'),('trade','trade-contract-treasury-archive-20261126'),('factory','factory-contract-treasury-archive-20261126')):
 directory=root/'run'/folder;contract=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
 assert contract['status']=='PASS';contracts[label]=contract
 for path in directory.rglob('*'):
  if path.is_file() and path.suffix in ('.json','.log','.args','.java','.py','.txt'):
   add(path,label+'/'+path.relative_to(directory).as_posix())
for name in ('TreasuryArchiveProbe.java','run-treasury-archive-capacity.py','verify-treasury-archive.py','TreasuryRecoveryProbe.java','run-treasury-recovery-contract.py','TradeExecutionProbe.java','run-trade-execution-contract.py','FactoryContractProbe.java','run-factory-contract.py'):
 add(root/'tools'/name,'tools/'+name)
add(Path(__file__),'tools/collect-treasury-archive-evidence.py')
for name in ('compile-treasury-archive-20261126.cmd','compile-treasury-archive-final-20261126.cmd','compile-treasury-archive-proof-20261126.cmd','run-treasury-archive-final-tests.py','run-treasury-archive-package.py','package-treasury-archive-20261126.cmd','run-treasury-archive-artifacts.py'):
 add(root/'run'/name,'tools/'+name)
add(root/'run/treasury-archive-baseline-20261126/chronicle-ci.json','github/baseline-ci.json')
add(native/'target/starcore-1.0.0-sbom.json','native-final/starcore-1.0.0-sbom.json')
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=native).decode().split('\0')
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=native).decode().split('\0')
sources={}
for name in sorted(set(changed+added)):
 if name.startswith(('src/','docs/')) and (native/name).is_file():
  add(native/name,'source/'+name);sources[name]=sha((native/name).read_bytes())
starcore=sha((native/'target/starcore-1.0.0.jar').read_bytes());chronicle=sha((root/'target/starchronicle-0.1.0-SNAPSHOT.jar').read_bytes())
assert starcore==contracts['capacity']['artifacts']['current.jar']
for name in ('treasury','trade','factory'):assert starcore==contracts[name]['artifacts']['starcore.jar']
for name in ('trade','factory'):assert chronicle==contracts[name]['artifacts']['starchronicle.jar']
summary={'date':'2026-11-26','baselines':{'chronicle':'7d608ef46deaf95e63ca963648a67b5fbfd3d1ba','starcore':'2e633cbe8df37458aca7f563853ea96604265a6c'},
 'scope':'Complete append-only treasury receipt history and refunds; SQL active snapshot retains balances and archive head, indexed original-ID reads, atomic revision/migration, bounded recovery and corruption quarantine. No Minecraft.',
 'native_tests':totals,'tests_by_package':packages,'new_tests':68,'native_source_hashes':sources,'preserved_failures':failure_counts,
 'packaging':'Serial 256 MiB compile, three disjoint test groups and verify from tested classes; separate online SBOM.',
 'chronicle_tests':'Main sources unchanged; reuse earlier 957-test JAR. Baseline 7d608ef Linux Maven verification #157 passed. New commit CI checked after push.',
 'artifacts':{'starcore_sha256':starcore,'starchronicle_sha256':chronicle},'contracts':contracts,
 'limits':['Current focused suite, not whole StarCore/JaCoCo/MySQL certification.',
 'Files and old SQL without an authority domain retain complete legacy history. First migration still loads all legacy receipts.',
 'Startup and revision refresh scan the entire archive in batches; archive count checks and balances remain proportional to stored data.',
 'Full SQL backup required; standalone Properties and old JAR cannot safely restore/write archived state.',
 'Synthetic fixed fixture, small heap and separate JVMs do not certify long-running live load, Minecraft, Folia, actual third-party combinations or multi-instance linearizable reads.']}
files['manifest.json']=(json.dumps({'summary':summary,'files':{name:sha(raw) for name,raw in sorted(files.items())}},ensure_ascii=False,indent=2)+'\n').encode()
output=root/'docs/verification/treasury-archive-source-20261126-evidence.zip'
with zipfile.ZipFile(output,'x',zipfile.ZIP_DEFLATED) as archive:
 for name,raw in sorted(files.items()):archive.writestr(name,raw)
with zipfile.ZipFile(output) as archive:
 recorded=json.loads(archive.read('manifest.json'));assert set(archive.namelist())==set(recorded['files'])|{'manifest.json'}
 for name,digest in recorded['files'].items():assert sha(archive.read(name))==digest
summary['evidence_zip_sha256']=sha(output.read_bytes());summary['evidence_files']=len(files)
(output.parent/'treasury-archive-source-20261126-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'tests':totals,'by_package':packages,'new_tests':68,'failures':failure_counts,'artifacts':summary['artifacts'],'zip':summary['evidence_zip_sha256'],'files':len(files),'bytes':output.stat().st_size}))
