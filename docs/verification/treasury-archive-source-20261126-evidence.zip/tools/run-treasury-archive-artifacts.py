import hashlib
import json
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
native=root.parent/'StarChronicle-audit/starcore-all-stages'
assert json.loads((root/'run/treasury-archive-package-result-20261126.json').read_text())['exit_code']==0
jar=native/'target/starcore-1.0.0.jar';previous=root/'run/treasury-archive-baseline-20261126/starcore.jar'
assert hashlib.sha256(jar.read_bytes()).hexdigest()!=hashlib.sha256(previous.read_bytes()).hexdigest()
common=['--starcore',str(jar),'--runtime','C:/tmp/starsupply-v11-paper-optional-stack-20261122','--java-home','C:/tmp/jdk21/jdk-21.0.13.1+2']
jobs=[
 ('capacity','run-treasury-archive-capacity.py',['--previous',str(previous),'--output',str(root/'run/treasury-archive-capacity-final-20261126'),'--per-kind','500']),
 ('treasury','run-treasury-recovery-contract.py',['--output',str(root/'run/treasury-contract-archive-20261126'),'--heap-mb','48']),
 ('trade','run-trade-execution-contract.py',['--chronicle',str(root/'target/starchronicle-0.1.0-SNAPSHOT.jar'),'--output',str(root/'run/trade-contract-treasury-archive-20261126'),'--heap-mb','48']),
 ('factory','run-factory-contract.py',['--chronicle',str(root/'target/starchronicle-0.1.0-SNAPSHOT.jar'),'--output',str(root/'run/factory-contract-treasury-archive-20261126'),'--heap-mb','48'])]
manifest={'status':'RUNNING','jobs':{}}
def save():(root/'run/treasury-archive-artifacts-result-20261126.json').write_text(json.dumps(manifest,indent=2)+'\n')
try:
 for label,tool,args in jobs:
  manifest['current']=label;save()
  result=subprocess.run([sys.executable,str(root/'tools'/tool),*common,*args],cwd=root)
  manifest['jobs'][label]=result.returncode;save();assert result.returncode==0,label
 manifest['status']='PASS'
except BaseException as error:
 manifest['status']='FAILED';manifest['error']=repr(error);raise
finally:save()
