import json
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
native=root.parent/'StarChronicle-audit/starcore-all-stages'
assert json.loads((root/'run/treasury-archive-final-compile-result-20261126.json').read_text())['exit_code']==0
assert json.loads((root/'run/treasury-archive-proof-compile-result-20261126.json').read_text())['exit_code']==0
output=root/'run/treasury-archive-final-tests-20261126';output.mkdir(exist_ok=False)
manifest={'status':'RUNNING','groups':{}}
def save():(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
try:
    for group,expected in (('finance',265),('resource',917),('snapshot',376)):
        script=root/f'run/test-treasury-archive-{group}-20261126.cmd'
        prior=(root/f'run/test-trade-archive-{group}-20261126.cmd').read_text()
        script.write_text(prior.replace('trade-archive-', 'treasury-archive-'),newline='\r\n')
        manifest['current']=group;save()
        result=subprocess.run(['cmd.exe','/d','/c',str(script)],cwd=native)
        log=root/f'run/treasury-archive-{group}-test-20261126.log';shutil.copy2(log,output)
        text=log.read_text(encoding='utf-8',errors='replace');counts=dict(tests=0,failures=0,errors=0,skipped=0)
        folder=output/group;folder.mkdir()
        for name in re.findall(r'\[INFO\] Running ([\w.$]+)',text):
            path=native/'target/surefire-reports'/('TEST-'+name+'.xml');shutil.copy2(path,folder)
            suite=ET.fromstring(path.read_bytes())
            for key in counts:counts[key]+=int(suite.attrib[key])
        manifest['groups'][group]={'exit_code':result.returncode,**counts};save()
        assert result.returncode==0 and 'BUILD SUCCESS' in text and 'BUILD FAILURE' not in text, group
        assert counts==dict(tests=expected,failures=0,errors=0,skipped=0),counts
    manifest['status']='PASS'
except BaseException as error:
    manifest['status']='FAILED';manifest['error']=repr(error);raise
finally:save()
